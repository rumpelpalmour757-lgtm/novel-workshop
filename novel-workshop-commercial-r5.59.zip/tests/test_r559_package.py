#!/usr/bin/env python3
"""r5.59: the version is the same everywhere, and the release notes say what this release did.

r5.58 pinned its version in test_r558_package.py; from r5.59 on that file checks that the r5.58 entries stay in the
changelog and the verification notes as history, and the current version is pinned here, the same way.

The release notes are checked for what they must cover: where the release comes from (the author uploaded the Cangjie
skill, the claude-skills collection, Scrapling and BJM v1.8 and asked the coordinator what the workshop could use; the
coordinator wrote a plan; the author read it and decided: the items put to him as the coordinator suggested, section 3
as written; the visual pipeline without Scrapling, its gaps closed with the standard library and a page reader of its
own; three items from BJM; the two AI side panels of the workbench removed; all given in the coordinator's words, not
quoted); what each part changed (the technique card, self-correction for dialogue and scenes, the locked sections and
the dialogue and scene anchors, the three BJM items, the visual pipeline, the workbench); what the coordinator decided
on the way, item by item, with the note that the author can change it; where the work differs from the plan's text;
the incompatible changes; the fixes; what did not change (the five bound scripts, the delivery gate card, the
constitution's text, the style cards); how to upgrade; and what was not verified. The test counts the notes give are
checked against the test files. The README must stay under its byte budget; QUICKSTART must no longer tell anyone to
set up either side panel.

The paired scenario tests and the writing anchors had no result at first: the notes said "结果待补" for them, and for
the upgrade and packaging sections, which a later step fills in. When they have results, these checks change, the way
test_r558_package.py changed in r5.58. They did so once in r5.59: the first batch of the paired scenario tests and the
anchors ran; on the two stage-4 questions r5.58 was judged right four times out of four and this version partly right
four times out of four, all four for taking the new exception at stage 4, and the author chose to narrow it. So the
section on the paired scenario tests no longer says only "结果待补": it gives the first batch (how it was done, what
happened on the way, the table, the anchors, what did worse and why, the narrowing) and pins "第二批（收窄以后的重测）
结果待补" for the retest on new questions; the release notes gain "对照测试以后改的", and the maker's decision item 3
says its "先留着、不登记" is withdrawn (the number of items stays 19). The upgrade and packaging sections still said
"结果待补" then.

They changed a second time in r5.59, when everything that was still to come had come. The narrowed sentence went
through three rounds of wording fixes; the retest then ran on that text (7 new scenarios, each answered twice with
r5.58 and twice with this version: r5.58 right 8, partly right 5, wrong 1; this version right 14); the author decided
that the other weak spots of the first batch are recorded as they are, with no rule changed in this release; the
author read the whole locked sentence next to the r5.58 sentence and approved it on 2026-11-20; the upgrade and
rollback rehearsals and the packaging were done. So the sections on the paired scenario tests, the upgrade and the
packaging no longer wait for a result, and the checks that held "结果待补", "发布以前还要请作者看过" and "这几处还没定" in
place are turned round: those phrases must be gone, and the figures must be there. A check of the kind "no result yet,
so the section may not hold figures" cannot hold once there are results; in its place the table of the second batch is
counted against the totals the notes give, and the notes must say what the figures do not show (the grading points
follow this version's text, r5.58 has no such exception, so the gap on those scenarios does not show that r5.58 is
worse; one model set the questions, answered and graded; none of it shows better writing).

Two checkers then went over the notes of that step, and a few statements were made exact; the checks gained the phrases
that hold them in place. The third round of wording fixes did not go the way of the first two (implementer, two
reviewers, fixer): one reviewer of the second round and its fixer gave the same wording, the coordinator put it in, the
suites ran, and nobody reviewed that text again; "每一轮都是实现人改" said otherwise and is gone. Every answering
instance of the second batch read its own question file, which lies outside its package, so the notes no longer say
that none read a file outside the package. The masking in the second batch was not complete (most answers of this
version name the exception that only this version has), and the notes say so. The fallback fixed at the narrowing
(withdraw the whole exception if the retest still shows stage 4 taken into it) is worded the same way in both pages.
The README gave only the retest, which went well for this version; it now also says that the first batch had other
spots worse than r5.58 and that no rule was changed for them. The private-material check was run again after the
packaging, so the sentence that it was still to be run is gone. The number of files the notes give for the ZIP is
checked against the manifest (its entries and the manifest itself).

They changed a third time in r5.59, before packaging. Nobody had read the final wording of the locked sentence word by
word after the third round of fixes, and the notes said so ("这一版条文没有再请两位核对人核一遍"); they also said that
each of the 11 situations walked through the chapter gate had one way to act when the final text is read word by word
("照最后的条文逐字读，各只有一种做法"), which nobody had checked on the final text. Two checkers then read the final
sentence against 21 situations, one of them walking the chapter gate on synthetic material. In 19 both found one way
to act. In one (the author hands a text back at stage 6 and only asks whether it will do) there are two ways in, and
they end in the same place. In one (a chapter that goes to the teacher, the revision awaiting confirmation, the author
bringing back a late batch of teacher comments together with his own revised text) two sentences point opposite ways,
the two checkers judged it differently, and the gate lets both ways through. The sentence is locked and the author had
approved it before this was found, so it was not changed: the notes record that situation as a known issue of this
release, say which way this release goes, and leave the wording to the next release. The checks that held the two old
sentences in place hold the new ones, and the old ones must be gone; the counts the notes give must add up (21
situations: the 11 and 10 more; 19 and the other two); both pages must name the known issue; and a phrase that claims
there is no ambiguity ("没有歧义") may not appear. The release ZIP was built again after this step, and the notes say
so. The record of the author's approval is kept in the maintenance notes, and the notes say that too.

The author's own replies of 2026-11-19 and 2026-11-20 are kept in the maintenance notes, outside the package, and no
page may quote them. That is checked in the maintenance environment, against those notes, not here. A first version of
this file held fingerprints of the replies (length, CRC-32 of the first letters, SHA-256); the replies are short, and
the release review matched one of them by guessing in under a second, so a fingerprint would let anyone confirm a
guess at the author's words. These tests only check that the notes say what they must; they do not show that the
workshop corrects itself better, that the technique card is more useful, or that anything writes better.
"""
import json
import os
from pathlib import Path
import re
import sys
import unittest

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
VERSION = "2026-11-19-r5.59"
TITLE = "小说写作工坊 r5.59"
PREVIOUS = "2026-11-16-r5.58"
PAGES = ("README.md", "QUICKSTART.md", "USAGE.md", "EXAMPLES.md", "skills/novel-workshop/SKILL.md")
WHAT = ("技法卡模板换成完整的一张卡；对白和场景的自我纠错（出了问题先归因、整理一次交作者定、作者划掉的不再提、"
        "作者在审稿阶段交回自己改过的稿子不重开初稿、作者改过的节拍卡留成示范）；维护时保护作者权限的几节原文上锁、"
        "加了对白和场景的写作对照例（标了不许加台词的，查得出新加台词）；视觉链路补上跳转、robots.txt、同站间隔几处漏洞，"
        "加了自带读页；"
        "写作台删掉两个 AI 侧栏")
README_LINE = "版本：小说写作工坊 r5.59（`2026-11-19-r5.59`）。在 r5.58 上做几件事：" + WHAT + "。"
SKILL_LINE = "小说写作工坊 r5.59（`2026-11-19-r5.59`）。在 r5.58 上做几件事：" + WHAT + "。"
BOUND_SCRIPTS = ("`workflow_guard.py`", "`punctuation_lint.py`", "`prose_lint.py`", "`fact_guard.py`", "`project_state.py`")
README_BUDGET = 24000  # bytes; test_r554_dialogue.py and test_r520_review_repairs.py hold the same budget

def read(path):
    return (ROOT / path).read_text(encoding="utf-8")


def newest_entry(text):
    """The text of the first '## ' section of a changelog-like page, heading included."""
    parts = re.split(r"(?m)^(?=## )", text)
    return parts[1] if len(parts) > 1 else ""


def part(text, heading):
    """From a '### ' heading to the next '### ' heading ("" if the heading is missing)."""
    start = text.find("\n### " + heading)
    if start < 0:
        return ""
    end = text.find("\n### ", start + 1)
    return text[start:] if end < 0 else text[start:end]


def version_line(page):
    """The line of a page that states its version."""
    return next((line for line in read(page).splitlines() if "`" + VERSION + "`" in line), "")


class Version(unittest.TestCase):
    def test_the_version_is_the_same_everywhere(self):
        for page in PAGES:
            self.assertIn("`" + VERSION + "`", read(page), page)
        manifest = json.loads(read("PACKAGE-MANIFEST.json"))
        self.assertEqual((manifest["version"], manifest["date"]), (VERSION, "2026-11-19"))
        verification = newest_entry(read("VERIFICATION.md"))
        self.assertTrue(verification.startswith("## " + VERSION + " 的验证"), verification[:60])
        self.assertIn("\n小说写作工坊 · `" + VERSION + "`\n", verification)
        self.assertTrue(newest_entry(read("CHANGELOG.md")).startswith("## %s（%s）" % (VERSION, TITLE)))
        # The trailing sentence changed with r5.59: the learning loop and the demonstration memory read a few more
        # fields now, so "章节门、学习循环、示范记忆和对白声纹检查照旧" no longer held; and a run that finishes on the
        # author's own pass is recorded author_reviewed, where r5.58 wrote self_checked for the same events (release
        # review: "旧记录照读" alone read as if nothing recorded differently).
        self.assertIn("\n" + SKILL_LINE + "章节门和对白声纹检查照旧；学习循环、示范记忆多认几个字段，旧记录照读；学习循环凭作者"
                      "本人的通过收尾的一轮记 `author_reviewed`（r5.58 记 `self_checked`）。",
                      read("skills/novel-workshop/SKILL.md"))

    def test_the_title_names_this_release_and_no_page_calls_it_a_candidate(self):
        for page in ("README.md", "skills/novel-workshop/SKILL.md"):
            self.assertIn(TITLE, version_line(page), page)
        for page in PAGES:
            line = version_line(page)
            self.assertNotIn("候选", line.split("`" + VERSION + "`")[0], page)  # what the page says this release is
            self.assertNotIn("`" + PREVIOUS + "`", line.split("。")[0], page)
        for page in ("CHANGELOG.md", "VERIFICATION.md"):
            heading = newest_entry(read(page)).splitlines()[0]
            self.assertNotIn("候选", heading, page)

    def test_the_readme_says_what_this_release_did(self):
        readme = read("README.md")
        self.assertLess(len(readme.encode("utf-8")), README_BUDGET)
        self.assertIn("\n" + README_LINE + "\n", readme)
        current = next(p for p in re.split(r"(?m)^(?=## )", readme) if p.startswith("## 本版"))
        self.assertTrue(current.startswith("## 本版（r5.59）"), current[:40])
        for phrase in ("技法卡", "试写三样", "仓颉 Skill", "先归因", "整理一次交作者定", "不重开初稿", "节拍卡留成示范",
                       "宪法正文没改", "`protected_sections`", "措辞作者还没看过", "标了不许加台词的，`detail_check.py`",
                       "工坊自己发的请求每一跳查地址", "robots.txt", "隔 1 秒", "自带读页", "两个 AI 侧栏删了",
                       "local-workbench.md", "[CHANGELOG.md](CHANGELOG.md)",
                       "开始时版本 NWC-1.8，现在 NWC-1.8", "登记表变了",
                       # r5.59, after the second batch (see the module docstring): the retest ran, so the sentence that
                       # said "成对场景重测结果待补" gives its figures, says where the rest is and what they do not show
                       "成对场景重测见 VERIFICATION.md", "7 个新场景每版两次", "r5.58 对 8、部分对 5、错 1",
                       "这一版 14 份都对", "评分要点照这一版条文写", "同一个模型出题答题评分", "不说明写得更好",
                       # r5.59, review of the step above (see the module docstring): the README gave only the retest;
                       # the first batch had other spots worse than r5.58, and no rule was changed for them
                       "第一批另有几处不如 r5.58，没改规则"):
            self.assertIn(phrase, current, phrase)
        # r5.59, after the paired scenario tests (see the module docstring): the first batch ran, so the README no
        # longer said "成对场景测试结果待补"; after the second batch nothing in it is still to come
        self.assertNotIn("成对场景测试结果待补", current)
        self.assertNotIn("结果待补", readme)
        history = readme.split("## 历次版本", 1)[1].split("\n## ", 1)[0]
        self.assertIn("- **r5.58**：", history)  # the release before moves into the list, as r5.57 did
        self.assertLess(history.index("- **r5.58**："), history.index("- **r5.57**："))
        # release review: r5.58's own notes said that two scenarios did worse than r5.57; the line keeps that figure
        self.assertIn("2 个场景不如 r5.57", next(l for l in history.splitlines() if l.startswith("- **r5.58**：")))

    def test_no_page_tells_anyone_to_set_up_a_side_panel(self):
        readme, quick = read("README.md"), read("QUICKSTART.md")
        workbench = next(line for line in readme.splitlines() if line.startswith("另附本地工作台"))
        self.assertIn("工作台不联网、不调用模型", workbench)
        self.assertNotIn("Gemini", workbench)
        for phrase in ("Google AI 订阅", "官方 ACP 程序", "acp-check.mjs", "check-acp.cmd", "可选接 Gemini", "“改稿建议”"):
            self.assertNotIn(phrase, quick, phrase)
        self.assertIn("写作台不联网、不调用模型；r5.59 起没有 AI 侧栏，以前存在本机的密钥和记录在哪里、怎样删，见 "
                      "[本地工作台](skills/novel-workshop/references/local-workbench.md)“r5.59 起没有 AI 侧栏”。", quick)
        self.assertIn("\n## r5.59 起没有 AI 侧栏\n", read("skills/novel-workshop/references/local-workbench.md"))

    def test_quickstart_says_delivery_records_carry_over_from_r558(self):
        self.assertIn("从合并候选、r5.55、r5.56、r5.57 或 r5.58 升级的，交付记录照旧。", read("QUICKSTART.md"))


class ReleaseNotes(unittest.TestCase):
    def setUp(self):
        self.entry = newest_entry(read("CHANGELOG.md"))
        self.assertTrue(self.entry.startswith("## %s（%s）" % (VERSION, TITLE)), self.entry[:60])

    def test_the_opening_says_where_it_comes_from_and_what_it_does_not_claim(self):
        opening = self.entry.split("\n### ", 1)[0]
        for phrase in ("在 r5.58（`2026-11-16-r5.58`）上做", "仓颉 Skill 2.5.0", "claude-skills 合集", "Scrapling 0.5.1",
                       "BJM 通用迁移包 v1.8", "编排方写了方案", "要定的几条都照编排方的建议办", "方案第三节的改动照做",
                       "不带 Scrapling", "用标准库补上几处漏洞", "工坊自带的读页", "BJM 借三条", "两个 AI 侧栏删掉",
                       "七样，作者这次没有提，没有做", "同一个模型（Claude）的新实例", "不是独立评审",
                       "那一条不放进发布版", "不说明写得更好", "r5.58 的包原样留着",
                       # r5.59, after the paired scenario tests (see the module docstring): the first batch ran and the
                       # author chose to narrow the exception
                       "第一批跑完了", "作者选了收窄",
                       # r5.59, after the second batch (see the module docstring): the retest ran; the opening gives
                       # its figures, what they do not show, where the rest is, and what the author decided about
                       # the other weak spots of the first batch ("结果待补" and "这几处还没定，交作者定" before)
                       "三轮措辞补正", "另出一批没见过的题重测", "7 个场景、每版两次", "r5.58 对 8、部分对 5、错 1",
                       "这一版 14 份都对", "第一批测出的毛病没有再出现", "评分要点照这一版的条文写",
                       "出题、答题、评分都是同一个模型的新实例", "只说明这一版照新条文办到了",
                       "VERIFICATION.md 本版“成对场景测试”", "作者定了照实记下，这一版不改规则",
                       "下一版专门出几道加戏的新题再看", "那条例外收窄以后留着，其余几处照实记下、没有撤条文"):
            self.assertIn(phrase, opening, phrase)
        for phrase in ("结果待补", "这几处还没定"):
            self.assertNotIn(phrase, opening, phrase)

    def test_the_parts_say_what_changed(self):
        expected = {
            "一、": ("`assets/technique-card-template.md`", "`references/deconstruction-library.md`",
                    "`assets/reference-source-template.md`", "`assets/third-party/SOURCE-NOTES.md`",
                    "`THIRD-PARTY-NOTICES.md`", "模板是编排方起草、作者照建议采用的，措辞作者可以随时改",
                    "没在真实拆文上用过", "三样都试过才判“可用”", "只缩条件", "只写参考", "不只是改措辞"),
            "二、": ("宪法正文没有改", "`references/quality-loop.md`", "复盘：先归因，再谈经验", "整理一次：交作者定",
                    "判断卡请认单（第 7 阶段）", "自我纠错的三层", "`references/chapter-confirmation.md`",
                    "`references/learning-loop.md`", "`references/demonstration-learning.md`",
                    "`references/editorial-judgment.md`", "`references/author-preferences.md`",
                    "`references/scene-dramaturgy.md`", "`scene_beat_revision`", "`scripts/learning_loop.py`",
                    "`author_reviewed`", "`scripts/demonstration_memory.py`", "`after_by`", "逐字节相同",
                    "没有退回 A", "`chapter_policy`", "只在合成材料上走过"),
            "三、": ("`protected_sections`", "`version` 仍是 NWC-1.8", "r5.59 的行号和哈希",
                    "`skills/darwin-novel-workshop/scripts/darwin_eval.py`",
                    "`governance.sections_changed`", "`BLOCKED_CONSTITUTION_CHANGE`", "`--constitution-approval`",
                    "`group`", "`author-feedback-log/2`",
                    "`skills/darwin-novel-workshop/assets/dialogue-scene-anchors.json`", "工坊新编，措辞作者还没看过",
                    "`no_new_dialogue`", "`references/skill-evaluation.md`", "各跑两次", "`scripts/detail_check.py`",
                    "`new_dialogue`", "`tests/regression-cases.json`"),
            "四、": ("第 4 条", "没有做", "`references/execution.md`", "`workflow_guard.py` 没有改", "`packets`", "退出码 2",
                    "能骗过这项核对", "不换人、不重跑", "`references/adversarial-review.md`"),
            "五、": ("不带 Scrapling", "绕过网站防护", "Python 3.9", "`scripts/visual_materials/common.py`",
                    "`private_address`", "`too_many_redirects`", "`robots_unreachable`", "`host_paused`", "`refused`",
                    "`rate_limited`", "`skipped_max_requests`", "`scripts/visual_materials/static_reader.py`",
                    "不执行网页里的脚本", "`page_reader`", "`auto`", "`thumbnail_not_fetched`", "整个连不上",
                    "`on_page.page_says`", "`checked: false`", "`scripts/export_portable.py`", "PSF"),
            "六、": ("其他本地功能都留着", "gemini-4-argon", "`gemini-assist.mjs`", "`acp-store.mjs`", "`check-acp.command`",
                    "`/api/assist/*`", "`/api/acp/*`", "`{ root, allowEdit }`", "`configDirectory`",
                    "r5.59 起没有 AI 侧栏", "r5.47"),
            # r5.59, after the paired scenario tests (see the module docstring)
            "对照测试以后改的": ("r5.58 四次都判对，这一版四次都判部分对", "“第 5 阶段还没确认的时候”", "作者选了收窄",
                          "`references/chapter-confirmation.md`", "这条例外只管这两种时候", "不登记成教师回传",
                          "`references/learning-loop.md`", "这一轮不起", "`assets/constitution-rules.json`",
                          "行号没变", "`tests/test_r554_dialogue.py`", "`sections_changed` 只有这一节",
                          "第一批题不再算检验", "写作对照例不重跑",
                          # r5.59, after the second batch (see the module docstring): the author read the whole
                          # sentence and approved it ("发布以前还要请作者看过" before); the three rounds of wording
                          # fixes; the retest as it was run (7 scenarios, not the 6 first planned: "共 6 题" before)
                          # and its result ("结果待补" before), with what the result does not show
                          "在第二批结果出来以后给作者看过", "作者 2026-11-20 批准", "公开包里不写作者的原话",
                          "三轮措辞补正", "第一轮（四处）", "第二轮（三处）", "第三轮（三处）", "11 种情形",
                          "没有在真实章节上走过", "7 个场景", "共 28 份", "任何答案评分以前定死",
                          "r5.58 对 8、部分对 5、错 1，这一版 14 份都对", "没有一份照例外办", "没有触发",
                          "这几个场景的差距不说明 r5.58 更差", "不是独立评审",
                          "[VERIFICATION.md](VERIFICATION.md) 本版“成对场景测试”",
                          # r5.59, review of the step above (see the module docstring): how the third round was
                          # really done; the fallback in the same words as the verification notes; the masking
                          "前两轮各是实现人改、两位核对人核、修复人复现问题并提改法",
                          # r5.59, the last word-by-word reading before packaging (see the module docstring): "这一版
                          # 条文没有再请两位核对人核一遍" and "照最后的条文逐字读各只有一种做法" before
                          "当时这一版条文没有再请核对人逐字读", "第二批测试和作者的批准都在补这一道以前",
                          "打包以前补了这一道", "按 21 种情形逐字读了一遍", "其中一位在合成材料上重跑了章节门",
                          "都是同一个模型的新实例，不是独立评审", "19 种两位都判只有一种做法",
                          "一种有两条进路、落点相同", "一种两位判得不一样，记成这一版已知的一处",
                          "这 11 种两位都判只有一种做法",
                          "收窄时定下的“重测里第 4 阶段还会被套进例外的，整条撤掉、照 r5.58 办”没有触发",
                          "评分人可能认得出是哪一版"),
        }
        for heading, phrases in expected.items():
            text = part(self.entry, heading)
            self.assertTrue(text, heading)
            for phrase in phrases:
                self.assertIn(phrase, text, (heading, phrase))
        after_the_tests = part(self.entry, "对照测试以后改的")
        for phrase in ("结果待补", "发布以前还要请作者看过", "发布以前要请作者认", "共 6 题", "每一轮都是实现人改",
                       # r5.59, the last word-by-word reading (see the module docstring)
                       "没有再请两位核对人核一遍", "逐字读各只有一种做法", "没有歧义"):
            self.assertNotIn(phrase, after_the_tests, phrase)

    def test_the_decisions_made_on_the_way_are_listed_and_can_be_changed(self):
        decided = part(self.entry, "编排方定下的几处做法")
        self.assertIn("要改，说一声就改", decided)
        numbers = [int(n) for n in re.findall(r"(?m)^(\d+)\. ", decided)]
        # DECISIONS section 6 (12), visual section 3 items 1-4 (4) and section 4 (3). Visual section 3 items 5 and 6 only
        # say what the notes must record (the incompatible changes; the one test that went out to the network), and
        # refusing unknown keys at once was the author's own decision: they are written under 不兼容的变化 and 七、.
        self.assertEqual(numbers, list(range(1, 20)))
        # r5.59, after the paired scenario tests (see the module docstring): item 3 keeps its place and says that its
        # "先留着、不登记" is withdrawn (it pinned "先问作者这一章还交不交教师" as kept; that sentence went with it)
        for phrase in ("登记表版本不升", "开始时版本 NWC-1.8，现在 NWC-1.8", "r5.59 定稿以后的文本", "还要交教师",
                       "对照测试以后作者选了收窄，这一条的“先留着、不登记”已经撤掉", "问的那一句也跟着删了",
                       "从严", "`learning_loop.py draft`", "“你”改成“作者”", "四个链接",
                       "`demonstration_memory.py` 认 `after_by`", "D02", "够候选的门槛", "请作者看", "第 6 阶段",
                       "“工坊本身”那一格", "停用以后", "最严的", "RFC 9309", "`urllib.robotparser`",
                       "`blocked_hosts`", "封面设计页", "整个连不上",
                       "`private_address`", "`too_many_redirects`", "`skipped_max_requests`", "来源段"):
            self.assertIn(phrase, decided, phrase)

    def test_where_the_work_differs_from_the_plan(self):
        differs = part(self.entry, "实施时和方案原文不一致的地方")
        for group in ("技法库：", "自我纠错：", "维护：", "BJM 的三条：", "视觉链路：", "写作台："):
            self.assertIn("\n" + group + "\n", differs, group)
        for phrase in ("“依据”", "判断卡请认单", "第 5 阶段还没确认的时候", "“上文”改成了“下文”", "“边界”上锁",
                       "D03、S02", "认得出拆句", "CRLF", "451", "Content-Length", "`og:image`", "`opacity:0`",
                       "noimageindex", "`redirected_url`", "429", "`.tool-button.primary`"):
            self.assertIn(phrase, differs, phrase)

    def test_the_incompatible_changes_and_the_fixes(self):
        incompatible = part(self.entry, "不兼容的变化")
        for phrase in ("拒收不认识的键", "`crawl4ai.check_robots_txt: false` 拒收", "`novel-workshop-visual-materials/`",
                       "括号里只收联系方式", "不能少于 1 秒", "记 `error`", "`stdlib_before_3_13`", "`stdlib_3_13`",
                       "`answered_by`", "data: 地址", "不再退缩略图", "四个检查启动器", "`/api/assist/*`", "`/api/acp/*`",
                       "`createDashboardServer` 不再收 `assist`、`acp`", "进备份", "`gemini.json`", "`acp.*`",
                       "`references/local-workbench.md`", "`protected_sections`", "开始时版本 NWC-1.8，现在 NWC-1.8",
                       "宪法没变、登记表变了", "`packets`", "`author-feedback-log/2`", "作者定的是直接拒收，不先警告一版",
                       "`retries`", "`timeout_seconds`", "`blocked_hosts`", "别的爬虫的名字",
                       "`completion` 记 `author_reviewed`（r5.58 记 `self_checked`）"):
            self.assertIn(phrase, incompatible, phrase)
        fixes = part(self.entry, "修正")
        for phrase in ("不再抛错", "`IncompleteRead`", "不是 r5.58 的问题"):
            self.assertIn(phrase, fixes, phrase)
        unchanged = part(self.entry, "没有改的")
        for phrase in BOUND_SCRIPTS + ("逐字节相同", "`assets/delivery-gate-card.md`", "`CONSTITUTION.md`", "83 张风格卡"):
            self.assertIn(phrase, unchanged, phrase)
        upgrade = part(self.entry, "怎样升级")
        for phrase in ("从 r5.58 升上来", "python install.py --upgrade --dry-run", "交付记录照旧", "`governance_warnings`",
                       "只是提示", "`.novel-workshop-backups/<时间>/`", "`--constitution-approval`", "`packets`",
                       "退回 r5.58", "没有验证",
                       # r5.59, review of the step above: both were walked through in the rehearsals; with records
                       # installed, the folders after rolling back are r5.58's files and those records
                       "升级和退回演练里实际走过", "多出来的只有这些记录"):
            self.assertIn(phrase, upgrade, phrase)
        self.assertNotIn("在副本上试过", upgrade)
        self.assertEqual(upgrade.count("升级和退回演练里实际走过"), 2)  # the workbench files; rolling back

    def test_the_test_counts_in_the_notes_are_the_test_files(self):
        tests = part(self.entry, "七、")
        named = re.findall(r"`tests/(test_r559_[a-z_]+\.py)`（(\d+) 项", tests)
        self.assertEqual(sorted(name for name, _ in named),
                         sorted(path.name for path in (ROOT / "tests").glob("test_r559_*.py")))
        for name, count in named:
            source = (ROOT / "tests" / name).read_text(encoding="utf-8")
            self.assertEqual(len(re.findall(r"(?m)^    def test_", source)), int(count), name)
        for phrase in ("`tests/test_r547_gemini.py`", "`tests/test_r549_acp.py`", "`tests/test_r550_acp.py`",
                       "`tests/test_r558_package.py`", "`tests/test_r554_dialogue.py`", "`PACKAGE-MANIFEST.json`",
                       "`portable-novel-workshop.md`", "保留域名"):
            self.assertIn(phrase, tests, phrase)

    def test_the_entry_and_the_verification_notes_say_what_was_not_verified(self):
        verification = newest_entry(read("VERIFICATION.md"))
        # r5.59, after the paired scenario tests (see the module docstring): the first batch was reported, the retest
        # was not ("成对场景测试和写作对照例：结果待补" before). After the second batch both are reported, and what is
        # listed here is what the two batches cannot show ("第二批（收窄以后的重测）结果待补" before)
        for text in (part(self.entry, "没有验证的"), part(verification, "没有验证的")):
            for phrase in ("成对场景测试和写作对照例：两批的结果见", "第二批只有 7 个合成场景、每版两次",
                           "评分要点照这一版的条文写", "同一个模型的新实例，不是独立评审", "说明不了在真实写作里会怎样",
                           "写作对照例第二批没有重跑", "收窄和三轮措辞补正的条文只在合成材料上走过，没有在真实章节上走过",
                           "作者定了照实记下，这一版没有改规则", "真实拆文", "合成材料",
                           "真实章节", "Crawl4AI", "替身",
                           "`user_agent`", "真实网站", "无头 Chromium", "Windows", "macOS", "不说明写得更好",
                           # r5.59, the last word-by-word reading (see the module docstring): the known issue, in
                           # both pages
                           "已知的一处", "这一版没改条文",
                           "作者把晚到的一批教师意见和自己改过的修订稿一起带回并说通过", "条文里两句说法不一",
                           "两位核对人判得不一样", "章节门两条路都放行",
                           "这一版照“完整初稿以后”里“方案交出以后又来了一批”办", "条文留到下一版补",
                           "这种情形没有出题测过", "只交回一场", "章节门分不出登记的回传是不是教师的东西"):
                self.assertIn(phrase, text, phrase)
            self.assertNotIn("结果待补", text)
            self.assertNotIn("没有歧义", text)

    def test_the_verification_notes_name_what_was_run(self):
        verification = newest_entry(read("VERIFICATION.md"))
        for phrase in ("python3 -I -B tests/run_tests.py", "Python 3.9.25", "`__pycache__`", "同一个模型", "不是独立评审",
                       "`tests/test_r559_package.py`", "`tests/test_r558_package.py`", "3.11.17", "3.12.3",
                       "零不一致", "Chromium", "`governance_warnings`", "开始时版本 NWC-1.8，现在 NWC-1.8",
                       "`page.example.org`", "`api.openverse.org`", "没有核实"):
            self.assertIn(phrase, verification, phrase)
        # r5.59, after the paired scenario tests (see the module docstring): the section on them gave the first batch and
        # left only the retest open, and the upgrade and packaging sections were pinned to "结果待补". After the second
        # batch all of it has results, so the checks are turned round: the phrase is gone and the figures are there.
        opening = verification.split("\n### ", 1)[0]
        for phrase in ("成对场景测试做了两批", "三轮措辞补正", "重新冻结的那一版", "同一个模型的新实例，不是独立评审",
                       "三轮补正的条文只在合成材料上走过", "不说明写得更好",
                       # r5.59, the last word-by-word reading (see the module docstring)
                       "打包以前另请两位核对人逐字读了一遍", "21 种情形里 19 种两位都判只有一种做法",
                       "一种两位判得不一样、章节门两条路都放行", "这一版没改条文，记成已知的一处"):
            self.assertIn(phrase, opening, phrase)
        self.assertNotIn("结果待补", opening)
        upgrade = part(verification, "升级和退回")
        for phrase in ("用 r5.58 的发布包和这一版发布用的 ZIP", "11 步全过", "9 步全过", "`carried`", "`conflicts` 为空",
                       "`unchanged`", "两个技能目录都和 r5.58 逐字节相同", "写作台删掉的 11 个文件",
                       # r5.59, the last word-by-word reading: the release ZIP was built again after it
                       "发布用的 ZIP 是补记最后一版条文的逐字核对以后重打的，上面两样是用它走的", "走过三遍"):
            self.assertIn(phrase, upgrade, phrase)
        self.assertNotIn("发布用的 ZIP 是按复核改完说明以后打的", upgrade)
        packaging = part(verification, "打包")
        for phrase in ("`--version 2026-11-19-r5.59 --date 2026-11-19`", "发布用的 ZIP 解开以后，和包目录逐字节相同",
                       "ZIP 的哈希不在包里", "冻结的那一份", "不同的只有这 8 个文件", "私料核对",
                       # r5.59, review of the step above (see the module docstring): the check was run again
                       "对包目录又跑了一次", "私人词、作者原话、书稿，新命中都是 0 处", "都是工坊自己的说法",
                       # r5.59, the last word-by-word reading: what that step touched, and the check run once more
                       "最后一次是打包以前补记最后一版条文的逐字核对", "补记最后一版条文的逐字核对以后，对包目录再跑了一次"):
            self.assertIn(phrase, packaging, phrase)
        self.assertNotIn("发布以前要在维护环境里对 ZIP 再跑一次", packaging)
        # the ZIP holds what the manifest lists and the manifest itself
        listed = len(json.loads(read("PACKAGE-MANIFEST.json"))["files"])
        self.assertEqual([int(n) for n in re.findall(r"ZIP 里 (\d+) 个文件", packaging)], [listed + 1])
        for heading in ("升级和退回", "打包"):
            self.assertNotIn("结果待补", part(verification, heading), heading)
        paired = part(verification, "成对场景测试")
        self.assertNotIn("结果待补", paired)
        # what the author decided about the other weak spots of the first batch ("这几处还没定，交作者定" before)
        self.assertIn("照实记下，这一版不改规则，下一版专门出几道加戏的新题再看", paired)
        # r5.59, review of the step above: it was the coordinator's proposal, and the author decided to follow it
        self.assertIn("作者定的是照编排方的建议办：照实记下", paired)
        self.assertNotIn("这几处还没定", verification)
        # the three rounds of wording fixes, the second batch and the approval of the locked sentence, in that order
        marks = [paired.index(mark) for mark in ("**作者定的收窄**", "**收窄以后的三轮措辞补正**", "**第二批：怎么做的**",
                                                 "**第二批：结果**", "**第二批的结果说明不了什么**",
                                                 "**上锁那一条的批准**")]
        self.assertEqual(marks, sorted(marks))
        rounds, how, result, limits, approval = (paired[a:b] for a, b in zip(marks[1:], marks[2:] + [len(paired)]))
        for phrase in ("行号没变", "第一轮（四处）", "第二轮（三处）", "第三轮（三处）", "两位核对人核", "11 种情形",
                       "每一种都有测试不过", "只在合成材料上走过，没有在真实章节上走过",
                       # r5.59, review of the step above (see the module docstring): the third round as it was done
                       "前两轮各走了一趟", "只提改法、交编排方定", "第三轮的改法是第二轮的一位核对人和修复人各自给出的同一版",
                       # r5.59, the last word-by-word reading before packaging (see the module docstring): "这一版条文
                       # 没有再请两位核对人核一遍" and "照最后的条文逐字读，各只有一种做法" before
                       "第三轮改完当时，最后这一版条文没有再请核对人逐字读", "第二批测试和作者的批准都在补这一道以前",
                       "打包以前补了这一道",
                       "这 11 种，补的那一道核对里两位核对人照最后的条文逐字读，都判只有一种做法",
                       "**最后一版条文的逐字核对（打包以前补的）**", "作者批准以后、打包以前",
                       "另一位还在合成材料上重跑了章节门", "只用页面写明的命令",
                       "两位都是同一个模型的新实例，不是独立评审", "包目录没有动",
                       "19 种两位都判只有一种做法，另外两种见下面两条", "要靠条文拦",
                       "**只问行不行的那一种（这一版没改）**", "一位核对人判两条进路落点相同、算一种，另一位判两种读法",
                       "两种都停在第 6 阶段", "第二批的评分要点在评分以前已经写明两种做法都合条文",
                       "**已知的一处（这一版没改条文）**",
                       "作者把晚到的一批教师意见和自己改过的修订稿一起带回并说通过", "“前面的阶段不重开”", "“再照例外办”",
                       "先带作者原话重开审稿阶段、再登记", "两位核对人判得不一样", "但要转两层",
                       "照字面能读出两种后果不同的做法", "章节门两条路都放行", "这一批教师意见一直没有登记",
                       "这一版遇到这种情形，照“完整初稿以后”里“方案交出以后又来了一批”办", "条文留到下一版补",
                       "这一句是作者看过原句和改后整句以后批准的上锁条文，批准在查出这一处以前，所以发布前没有再改",
                       "没有出题测过", "学习循环的起一轮、评审、改稿、收尾没有跟着跑"):
            self.assertIn(phrase, rounds, phrase)
        self.assertNotIn("修复人修。", rounds)
        for phrase in ("这一版条文没有再请两位核对人核一遍", "照最后的条文逐字读，各只有一种做法", "没有歧义"):
            self.assertNotIn(phrase, verification, phrase)
        # the counts of the last reading add up: 21 situations are the 11 and 10 more; 19 and the other two
        counted = [re.findall(pattern, rounds) for pattern in (r"各自按 (\d+) 种情形", r"(\d+) 种是上面那 (\d+) 种，加上 (\d+) 种",
                                                               r"结果：(\d+) 种两位都判只有一种做法，另外两种",
                                                               r"已知的那一处以外的 (\d+) 种")]
        self.assertEqual([len(found) for found in counted], [1, 1, 1, 1], counted)
        total, (again, walked, added), agreed, others = (int(counted[0][0]), [int(n) for n in counted[1][0]],
                                                         int(counted[2][0]), int(counted[3][0]))
        self.assertEqual((total, again, walked + added, agreed + 2, others + 1), (21, 21, 21, 21, 21))
        self.assertEqual(walked, 11)  # the 11 situations the paragraph before lists
        for phrase in ("重新冻结的那一版", "7 个场景", "写在三轮措辞补正做完以前", "任何答案评分以前定死",
                       "采纳 10 处，不采纳 5 处", "要点照这一版的条文写", "共 28 份", "有 3 个各运行了一次命令",
                       "三人里取多数",
                       # r5.59, review of the step above: every instance read its own question file
                       "题面放在文件里交给它", "除了自己的题面文件，都没读自己那一份包以外的文件"):
            self.assertIn(phrase, how, phrase)
        self.assertNotIn("28 个实例都没读包以外的文件", how)
        for phrase in ("每版 14 份：r5.58 对 8、部分对 5、错 1；这一版对 14、部分对 0、错 0。",
                       "这一版 6 份都对，没有一份照例外办", "没有触发", "请第三位看的 4 份", "r5.58 没全对的几份",
                       # r5.59, review of the step above: the fallback in full, in the words the changelog uses; what
                       # the one answer to scenario 6 did
                       "收窄时定下的“重测里第 4 阶段还会被套进例外的，整条撤掉、照 r5.58 办”没有触发",
                       "场景 6 一份没先问这一版算不算作者改定的修订稿", "这一轮没有做，也告诉了作者可以不走"):
            self.assertIn(phrase, result, phrase)
        # the table, counted against the totals: seven scenarios, two answers each for r5.58 and for this version
        rows = re.findall(r"(?m)^\| (\d) \| [^|\n]+ \| ([^|\n]+) \| ([^|\n]+) \|$", result)
        self.assertEqual([number for number, _, _ in rows], list("1234567"))
        for column, totals in ((1, (8, 5, 1)), (2, (14, 0, 0))):
            marks_given = [mark for row in rows for mark in row[column].strip().split("、")]
            self.assertEqual(len(marks_given), 14)
            self.assertEqual(tuple(marks_given.count(mark) for mark in ("对", "部分对", "错")), totals)
        for phrase in ("评分要点照这一版的条文写", "r5.58 本来没有这条例外", "这几个场景的差距不说明 r5.58 更差",
                       "同一个模型的新实例，不是独立评审", "说明不了在真实写作里会怎样", "写作对照例没有重跑",
                       "不说明写得更好",
                       # r5.59, review of the step above: the masking was not complete in the second batch either
                       "遮挡不完全", "评分人可能认得出是哪一版，这一处没有遮"):
            self.assertIn(phrase, limits, phrase)
        for phrase in ("`protected_sections`", "连同 r5.58 的原句和影响", "在第二批结果出来以后给作者看过",
                       "作者 2026-11-20 批准", "公开包里不写作者的原话",
                       # r5.59, the last word-by-word reading: where the record of the approval is, and that the
                       # approval came before that reading
                       "批准记录备在维护记录里，不在包里", "作者批准这一句在最后一版条文的逐字核对以前"):
            self.assertIn(phrase, approval, phrase)
        # the registry note says the same: the sentence that it was still to be put to the author is gone
        note = json.loads(read("skills/novel-workshop/assets/constitution-rules.json"))["note"]
        self.assertTrue(note.endswith("was put to the author together with the r5.58 sentence after the second batch "
                                      "of paired scenario tests, and the author approved it on 2026-11-20."),
                        note[-120:])
        self.assertNotIn("before release", note)
        for phrase in ("18 个写小说的场景", "一共 108 份", "在答题评分以前定死",
                       "两位核对人各自独立核", "第三位一共用了 10 次", "“[版本]”“[包]”", "容器重启了两次",
                       "统计只用每个调用第一次跑完的结果", "补答的 61 份从题面文件读题", "逐字核过，相同",
                       "23 个实例用了只读命令", "| 合计（第 1—17 个，各 34 份） | 18、15、1 | 19、15、0 | 0、25、9 |",
                       "第 18 个场景（打开写作台的 Gemini 侧栏）单列", "20、15、1", "21、15、0",
                       "r5.58 四次都判对", "字面上管到了第 4 阶段", "r5.58 两次都是通过 8 例", "15／22", "13／22",
                       "就不能报“候选更好”", "原因没有查清", "作者选了收窄", "第一批题不再算检验", "不是独立评审"):
            self.assertIn(phrase, paired, phrase)
        rows = 0
        for line in part(verification, "全套测试").splitlines():
            match = re.search(r"运行 (\d+) 项，跳过 (\d+) 项，其余 (\d+) 项全部通过", line)
            if match:
                rows += 1
                ran, skipped, passed = (int(n) for n in match.groups())
                self.assertEqual(ran - skipped, passed, line[:60])
        self.assertEqual(rows, 2)  # Python 3.13 and Python 3.9.25


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""State precheck (r5.49): list what a candidate deletes, changes and adds, before project_state.py commit.

python3 state_precheck.py BASE.json DESIRED.json [--format text|json]

BASE is the unaltered snapshot from `project_state.py read` (its "data" is compared; the "state" of a commit result
works too) or a bare data object. DESIRED is the complete candidate data for --proposed (a full snapshot works too:
its "data" is compared, and a note says that --proposed takes only the data). By JSON path it lists:
  - deleted: every field or list item BASE has and DESIRED does not, listed first and each marked 要作者看, because
    commit treats a missing field as a deletion (references/state-storage.md);
  - changed: every value that differs, old -> new; a keyed list whose items only moved is listed as an order change;
  - added: every path DESIRED has and BASE does not.
A deleted or added object is listed once at its own path, not field by field. A list whose items, on both sides, are
all objects with a unique "id" is matched by id; failing that, by a unique "name"; otherwise by position. The report
names the way each differing list was matched. Paths are JSON Pointers below the compared root (~ and / in a key are
written ~0 and ~1); a list item matched by key is written [id=...] or [name=...].

It reads two files and writes nothing. It never decides whether a change is right: a listed path is a place to
re-read, not a verdict. Exit 0 when it ran (with deletions too), 2 when a file cannot be read or is not valid JSON
(duplicate keys and NaN/Infinity count as invalid, as in project_state.py).
"""
import argparse
import json
from pathlib import Path
import sys

FORMAT = "novel-workshop-state-precheck"
CORE_SECTIONS = ("characters", "settings", "chapters")
MATCH_KEYS = ("id", "name")
TEXT_LIMIT = 80
CONTEXT = 12
NEEDS_AUTHOR = "要作者看"
LIMITS = "每一处只是要回头核对的地方，不是结论。"
CLOSING = "只列差别，不判对错：有删除时，先给作者看；作者没说删，就不删。"
COMPARED = {
    "snapshot": "read 的完整基线，比较其中的 data",
    "commit_result": "commit 结果，比较其中 state 的 data",
    "whole": "整份文件",
}
MATCH_WORDS = {"id": "按 id 对照", "name": "按 name 对照", "position": "按位置对照"}
POSITION_REASON = "不是两边每一项都是带不重复 id 或 name 的对象"
POSITION_HINT = "中间插入或删掉一项，后面各项都会显示成改动。"


class InputError(Exception):
    def __init__(self, code, role, path, message):
        super().__init__(message)
        self.code = code
        self.role = role
        self.path = str(path)

    def as_dict(self):
        return {"status": "error", "code": self.code, "file": self.path, "role": self.role, "message": str(self)}


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate:" + key)
        result[key] = value
    return result


def _constant(value):
    raise ValueError("constant:" + value)


def load(path, role):
    try:
        raw = Path(path).read_bytes()
    except FileNotFoundError:
        raise InputError("unreadable", role, path, "找不到这个文件。") from None
    except IsADirectoryError:
        raise InputError("unreadable", role, path, "这是文件夹，不是文件。") from None
    except PermissionError:
        raise InputError("unreadable", role, path, "没有读这个文件的权限。") from None
    except OSError as error:
        raise InputError("unreadable", role, path, "读不了这个文件：" + (error.strerror or str(error)) + "。") from None
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        raise InputError("invalid_json", role, path, "不是 UTF-8 文本。") from None
    if text.startswith("﻿"):
        raise InputError("invalid_json", role, path, "文件开头有 BOM。project_state.py 也读不了，去掉 BOM 再比。")
    try:
        return json.loads(text, object_pairs_hook=_pairs, parse_constant=_constant)
    except json.JSONDecodeError as error:
        raise InputError("invalid_json", role, path, "不是有效的 JSON：第 %d 行第 %d 列，%s。"
                         % (error.lineno, error.colno, error.msg)) from None
    except ValueError as error:
        kind, _, detail = str(error).partition(":")
        if kind == "duplicate":
            message = "同一个对象里有重复的键“%s”。project_state.py 也会拒收。" % detail
        else:
            message = "含有 %s，这不是标准 JSON。project_state.py 也会拒收。" % detail
        raise InputError("invalid_json", role, path, message) from None
    except RecursionError:
        raise InputError("invalid_json", role, path, "嵌套太深，读不了。") from None


def _is_snapshot(value):
    return (isinstance(value, dict) and isinstance(value.get("data"), dict) and "version" in value
            and "revision" in value and not any(key in value for key in CORE_SECTIONS))


def unwrap(value):
    """Return (compared root, how it was found)."""
    if _is_snapshot(value):
        return value["data"], "snapshot"
    if (isinstance(value, dict) and "status" in value and _is_snapshot(value.get("state"))
            and not any(key in value for key in CORE_SECTIONS)):
        return value["state"]["data"], "commit_result"
    return value, "whole"


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _same(left, right):
    return _canonical(left) == _canonical(right)


def _escape(text):
    return text.replace("~", "~0").replace("/", "~1")


def _key_segment(key):
    return "/" + _escape(key)


def _match_segment(field, value):
    shown = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)
    return "/[%s=%s]" % (field, _escape(shown))


def _shown(path):
    return path or "/"


def _match_value(item, field):
    if not isinstance(item, dict) or field not in item:
        return None
    value = item[field]
    if isinstance(value, bool) or not isinstance(value, (str, int)):
        return None
    if isinstance(value, str) and not value.strip():
        return None
    return value


def _usable(items, field):
    seen = set()
    for item in items:
        value = _match_value(item, field)
        if value is None:
            return False
        token = (type(value).__name__, value)
        if token in seen:
            return False
        seen.add(token)
    return True


def match_field(old, new):
    for field in MATCH_KEYS:
        if _usable(old, field) and _usable(new, field):
            return field
    return None


class Report:
    def __init__(self):
        self.deleted = []
        self.changed = []
        self.added = []
        self.lists = []


def walk(old, new, path, report):
    if _same(old, new):
        return
    if isinstance(old, dict) and isinstance(new, dict):
        for key, value in old.items():
            child = path + _key_segment(key)
            if key in new:
                walk(value, new[key], child, report)
            else:
                report.deleted.append({"path": child, "old": value})
        for key, value in new.items():
            if key not in old:
                report.added.append({"path": path + _key_segment(key), "new": value})
        return
    if isinstance(old, list) and isinstance(new, list):
        field = match_field(old, new)
        entry = {"path": _shown(path), "match": field or "position"}
        if field is None:
            entry["reason"] = POSITION_REASON
        report.lists.append(entry)
        if field is None:
            for index in range(min(len(old), len(new))):
                walk(old[index], new[index], path + "/" + str(index), report)
            for index in range(len(new), len(old)):
                report.deleted.append({"path": path + "/" + str(index), "old": old[index]})
            for index in range(len(old), len(new)):
                report.added.append({"path": path + "/" + str(index), "new": new[index]})
            return
        new_by_key = {(type(item[field]).__name__, item[field]): item for item in new}
        old_keys = [(type(item[field]).__name__, item[field]) for item in old]
        for item in old:
            token = (type(item[field]).__name__, item[field])
            child = path + _match_segment(field, item[field])
            if token in new_by_key:
                walk(item, new_by_key[token], child, report)
            else:
                report.deleted.append({"path": child, "old": item})
        old_set = set(old_keys)
        for item in new:
            if (type(item[field]).__name__, item[field]) not in old_set:
                report.added.append({"path": path + _match_segment(field, item[field]), "new": item})
        kept_old = [item[field] for item in old if (type(item[field]).__name__, item[field]) in new_by_key]
        kept_new = [item[field] for item in new if (type(item[field]).__name__, item[field]) in old_set]
        if kept_old != kept_new:
            report.changed.append({"path": _shown(path), "kind": "order", "old": kept_old, "new": kept_new})
        return
    report.changed.append({"path": _shown(path), "kind": "value", "old": old, "new": new})


def notes_for(base_how, desired, desired_how):
    notes = []
    if base_how == "whole":
        notes.append("BASE 不是 read 输出的完整基线，按整份文件比较。commit 的 --base 要用 read 的原样输出。")
    if desired_how != "whole":
        notes.append("DESIRED 是完整基线或 commit 结果。commit 的 --proposed 只要其中的 data。")
    if not isinstance(desired, dict) or any(not isinstance(desired.get(key), dict) for key in CORE_SECTIONS):
        notes.append("DESIRED 缺少 characters、settings、chapters 三个对象中的至少一个。project_state.py commit 会拒收。")
    return notes


def precheck(base_value, desired_value, base_file="BASE", desired_file="DESIRED"):
    base, base_how = unwrap(base_value)
    desired, desired_how = unwrap(desired_value)
    report = Report()
    walk(base, desired, "", report)
    for item in report.deleted:
        item["path"] = _shown(item["path"])
        item["needs_author"] = True
        item["mark"] = NEEDS_AUTHOR
    for item in report.added:
        item["path"] = _shown(item["path"])
    return {
        "format": FORMAT,
        "format_version": 1,
        "status": "ok",
        "base": {"file": str(base_file), "compared": base_how},
        "desired": {"file": str(desired_file), "compared": desired_how},
        "counts": {"deleted": len(report.deleted), "changed": len(report.changed), "added": len(report.added)},
        "deleted": report.deleted,
        "changed": report.changed,
        "added": report.added,
        "lists": report.lists,
        "notes": notes_for(base_how, desired, desired_how),
        "writes_files": False,
        "limits": LIMITS,
        "closing": CLOSING,
    }


def _dump(value):
    return json.dumps(value, ensure_ascii=False)


def _cut(text):
    if len(text) <= TEXT_LIMIT:
        return text
    return text[:TEXT_LIMIT] + "…（共 %d 字）" % len(text)


def _size(value):
    if isinstance(value, dict):
        return "（整个对象，里面有 %d 个字段）" % len(value)
    if isinstance(value, list):
        return "（整个列表，里面有 %d 项）" % len(value)
    return ""


def _pair(old, new):
    """Old and new for one line; long strings are cut around the first difference."""
    if isinstance(old, str) and isinstance(new, str) and max(len(old), len(new)) > TEXT_LIMIT:
        start = 0
        while start < min(len(old), len(new)) and old[start] == new[start]:
            start += 1
        end = 0
        while (end < min(len(old), len(new)) - start
               and old[len(old) - 1 - end] == new[len(new) - 1 - end]):
            end += 1

        def middle(text):
            left = max(0, start - CONTEXT)
            right = min(len(text), len(text) - end + CONTEXT)
            piece = text[left:right]
            return ("…" if left else "") + piece + ("…" if right < len(text) else "")

        return (_dump(middle(old)) + "（共 %d 字）" % len(old), _dump(middle(new)) + "（共 %d 字）" % len(new))
    return _cut(_dump(old)), _cut(_dump(new))


def render_text(result):
    counts = result["counts"]
    lines = ["状态候选预查（只读，不写任何文件）",
             "BASE：%s（%s）" % (result["base"]["file"], COMPARED[result["base"]["compared"]]),
             "DESIRED：%s（%s）" % (result["desired"]["file"], COMPARED[result["desired"]["compared"]]),
             "删除 %d 处，改动 %d 处，新增 %d 处。" % (counts["deleted"], counts["changed"], counts["added"])]
    if not any(counts.values()):
        lines += ["", "两边内容一样，没有差别。"]
    if result["deleted"]:
        lines += ["", "【删除：%s】BASE 有、DESIRED 没有。commit 会把这些删掉。" % NEEDS_AUTHOR]
        for item in result["deleted"]:
            lines.append("- %s  %s%s" % (item["path"], NEEDS_AUTHOR, _size(item["old"])))
            lines.append("  原来：" + _cut(_dump(item["old"])))
    if result["changed"]:
        lines += ["", "【改动】旧值 → 新值"]
        for item in result["changed"]:
            old, new = _pair(item["old"], item["new"])
            label = "（只是顺序变了）" if item["kind"] == "order" else ""
            lines.append("- %s%s：%s → %s" % (item["path"], label, old, new))
    if result["added"]:
        lines += ["", "【新增】BASE 没有、DESIRED 有。"]
        for item in result["added"]:
            lines.append("- %s%s" % (item["path"], _size(item["new"])))
            lines.append("  现在：" + _cut(_dump(item["new"])))
    if result["lists"]:
        lines += ["", "【列表怎么对照】"]
        for item in result["lists"]:
            if item["match"] == "position":
                lines.append("- %s：%s（%s）。%s" % (item["path"], MATCH_WORDS["position"], item["reason"], POSITION_HINT))
            else:
                lines.append("- %s：%s。" % (item["path"], MATCH_WORDS[item["match"]]))
    if result["notes"]:
        lines += ["", "格式提醒："]
        lines += ["- " + note for note in result["notes"]]
    lines += ["", LIMITS, CLOSING]
    return "\n".join(lines) + "\n"


def utf8_stdio():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main(argv=None):
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("base", type=Path, help="the unaltered snapshot from project_state.py read (or bare data)")
    parser.add_argument("desired", type=Path, help="the complete candidate data for commit --proposed")
    parser.add_argument("--format", choices=("text", "json"), default="text")
    args = parser.parse_args(argv)
    try:
        base = load(args.base, "BASE")
        desired = load(args.desired, "DESIRED")
        result = precheck(base, desired, args.base, args.desired)
        output = (json.dumps(result, ensure_ascii=False, indent=1) + "\n" if args.format == "json"
                  else render_text(result))
    except InputError as error:
        if args.format == "json":
            print(json.dumps(error.as_dict(), ensure_ascii=False), file=sys.stderr)
        else:
            print("%s %s：%s没有比较，也没有写任何文件。" % (error.role, error.path, error), file=sys.stderr)
        return 2
    except RecursionError:
        message = "嵌套太深，比不了。没有写任何文件。"
        if args.format == "json":
            print(json.dumps({"status": "error", "code": "too_deep", "message": message}, ensure_ascii=False),
                  file=sys.stderr)
        else:
            print(message, file=sys.stderr)
        return 2
    sys.stdout.write(output)
    return 0


if __name__ == "__main__":
    sys.exit(main())

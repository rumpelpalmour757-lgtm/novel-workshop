#!/usr/bin/env python3
"""The only way to write a book's inspiration library (r5.35, references/inspiration-library.md).

python3 inspiration_write.py migrate LIBRARY [--out NEW.json | --replace] [--root DIR] [--date YYYY-MM-DD]
python3 inspiration_write.py adopt LIBRARY --selection SELECTION.json --if-revision N [--rebase] [--dry-run]
python3 inspiration_write.py restore LIBRARY --if-revision N (--revision M | --from BACKUP.json)
python3 inspiration_write.py history LIBRARY

migrate turns a format-1 library into format 2. By default it writes NEW (LIBRARY's name with .v2.json) and leaves the
original as it is; --replace first copies the original into the library's history folder and then writes format 2 in
its place. A format-1 entry picked without saying which parts becomes legacy_picked: nobody decides for the author that
the whole image was taken. adopt records the author's choice from a selection file (which entries, which parts, stable
or one scene, what not to take, how the book changes it; candidates rejected; adoptions withdrawn; parts that became
the book's fact once they are in the author's accepted text, under establish). It writes only when
the library is still at revision N (--if-revision), so two people working from the same revision cannot overwrite each
other; with --rebase it applies the choice to a newer revision when nobody touched the same entries since N. restore
writes an earlier revision (or the format-1 original) back as a new revision. Every write takes a lock file, writes a
temporary file and swaps it in, keeps a copy of the new revision in LIBRARY's history folder (NAME.history/) and adds a
line to its log.jsonl. One library file is written at a time; character cards and the project file are separate files
and are not part of the same write.

r5.37 (the r5.35 review, point 2). migrate --out checks, under the new library's lock, that nothing is there yet, so
two migrations to the same --out cannot overwrite each other; and it checks the result where it will be read (the new
library's folder, or --root): image files named relative to the old folder that cannot be found from there stop the
migration before anything is written. Every write runs in one order: the history copies and a pending note
(NAME.history/pending.json) first, then the library file, then the log line. A failure before the library file is
replaced is "nothing written" (the library is as it was); a failure after it is COMMITTED_INCOMPLETE: the new revision
is in place, do not repeat the write; the next write finishes the log from the pending note, and history shows it
meanwhile. restore checks the copy's entries before writing (a broken record is refused; image files that are only
missing now are reported). A selection that names base_revision must match --if-revision. history reads a log whose
last line was cut off.

r5.38 (the r5.37 review, points 1 and 2). An entry that is already picked is changed only as the author says, in the
adopt item's mode: add (keep what was taken and add the parts named now; the same part again changes nothing),
replace (take only the parts named now; the old ones stay in the history and the log), or use (only add a chapter or
scene; take stays). Without a mode such an entry is refused before anything is written, so "布局" is never silently
replaced by "灯光". The parts kept from an earlier choice keep that choice's decision; the entry's decision is the
latest. A selection may carry the candidate's entry for an image already in the library (the visual-materials path
always does): it must be the same image version, and the library keeps its own source. withdraw may name parts: only
those leave the take (a part in the author's accepted text, established, is refused). With --rebase, additions (add,
use) apply to an entry someone else changed meanwhile, so both increments are kept; other changes still conflict. A
choice that changes nothing writes nothing (UNCHANGED). Every write has an operation_id, in the pending note and in the
log line, and a pending note is finished by that id: two writes with the same bytes (restoring the same format-1
original twice) are two log lines, and finishing again never adds a line twice. A part taken for one scene (scope
scene) keeps where it was taken for (taken_for, from the choice's use), so a card for another chapter does not bring
it along; mode add with the same part for another scene adds that scene. An image already picked and now turned down
is a withdrawal, not a reject: refused before writing.

r5.40 (the author's r5.39 report, point 1). A part for one scene recorded before r5.38 has no taken_for. Before a
write adds a use to such an entry, the part is settled from the record as it was: with exactly one use before this
write, that use becomes its taken_for; with more uses, or none, it is marked taken_for_unknown and no scene gets it
until the author says which (mode add with that scene, or mode replace). The log line names what was settled and on
what basis (scene_parts_bound, scene_parts_unknown); the author's choices and decisions are not changed. Only a write
settles anything; reading never changes the library. mode add with the same part for a scene adds that scene to a
part with or without taken_for.

Also r5.40, after a second reading of the fix: the uses a later write added with mode add or use are in the library's
log; they do not count as an old part's scene (inspiration_library.added_uses), so a use r5.39 appended is not taken
for the scene the part was taken for, and the basis says so (uses_added_later). mode add naming an old part again
settles it first, as a write that adds a use does, so its waiting mark does not depend on an earlier write. replace
naming a part for one scene again without saying a scene keeps the scenes it was taken for (parts_kept_for_their_scenes).
A taken_for_unknown written wrong is left alone (check reports it), as the card reads it: waiting.
"""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
SELECTION = "inspiration-selection/1"
LOCK_STALE_SECONDS = 600


def _library_module():
    spec = importlib.util.spec_from_file_location("nw_inspiration_library", HERE / "inspiration_library.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


lib = _library_module()
LibraryError = lib.LibraryError


class Conflict(Exception):
    def __init__(self, current, changed, message):
        super().__init__(message)
        self.current, self.changed = current, changed


class NotCommitted(LibraryError):
    """The write stopped before the library file was replaced: the library is as it was."""


class CommittedIncomplete(Exception):
    """The library file holds the new revision, but its history is not finished (the log line is pending)."""

    def __init__(self, revision, digest, message, operation_id=None):
        super().__init__(message)
        self.revision, self.sha256, self.operation_id = revision, digest, operation_id


PENDING = "pending.json"
MODES = ("add", "replace", "use")


def new_operation_id():
    """One write's own id: the time and random bytes, so two writes with the same content are told apart."""
    return "op-%s-%s" % (datetime.datetime.now().strftime("%Y%m%dT%H%M%S%f"), os.urandom(4).hex())


def today():
    return datetime.date.today().isoformat()


def history_dir(path):
    path = Path(path)
    return path.with_name(path.stem + ".history")


def dumps(data):
    return (json.dumps(data, ensure_ascii=False, indent=1) + "\n").encode("utf-8")


def sha(data):
    return hashlib.sha256(data).hexdigest()


class Lock:
    """A lock file next to the library, made with O_EXCL: one writer at a time, on Windows too."""

    def __init__(self, path):
        self.path = Path(str(path) + ".lock")
        self.fd = None

    def __enter__(self):
        try:
            self.fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            age = time.time() - self.path.stat().st_mtime if self.path.exists() else 0
            hint = ("; it is %d minutes old: if no other write is running, delete it and try again" % (age // 60)
                    if age > LOCK_STALE_SECONDS else "")
            raise LibraryError("another write holds the lock %s%s" % (self.path.name, hint))
        os.write(self.fd, ("%d %s\n" % (os.getpid(), datetime.datetime.now().isoformat())).encode("ascii"))
        return self

    def __exit__(self, *exc):
        os.close(self.fd)
        try:
            os.remove(str(self.path))
        except OSError:
            pass
        return False


def write_atomic(path, data):
    """Write a temporary file next to path and swap it in: a write that fails halfway leaves the old file whole."""
    path = Path(path)
    tmp = path.with_name("%s.tmp-%d" % (path.name, os.getpid()))
    try:
        tmp.write_bytes(data)
        os.replace(str(tmp), str(path))
    except BaseException:
        try:
            os.remove(str(tmp))
        except OSError:
            pass
        raise


def log(path, record):
    folder = history_dir(path)
    folder.mkdir(exist_ok=True)
    target = folder / "log.jsonl"
    line = (json.dumps(dict({"time": datetime.datetime.now().isoformat(timespec="seconds")}, **record),
                       ensure_ascii=False) + "\n").encode("utf-8")
    size = target.stat().st_size if target.exists() else 0
    if size:
        with target.open("rb") as handle:
            handle.seek(size - 1)
            if handle.read(1) != b"\n":
                line = b"\n" + line  # the last line was cut off: start this one on its own line
    with target.open("ab") as handle:
        handle.write(line)


def keep(path, data, revision, only_if_missing=False):
    folder = history_dir(path)
    folder.mkdir(exist_ok=True)
    target = folder / ("r%04d.json" % revision)
    if not (only_if_missing and target.exists()):
        write_atomic(target, data)


def log_records(path):
    """The log's records in order; a line that cannot be read (cut off by a crash) is reported, not fatal."""
    target = history_dir(path) / "log.jsonl"
    if not target.is_file():
        return []
    out = []
    for number, line in enumerate(target.read_bytes().decode("utf-8", "replace").splitlines(), 1):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except ValueError:
            out.append({"unreadable_line": number, "text": line[:80]})
            continue
        out.append(record if isinstance(record, dict) else {"unreadable_line": number, "text": line[:80]})
    return out


def read_pending(path):
    marker = history_dir(path) / PENDING
    if not marker.is_file():
        return None
    try:
        note = json.loads(marker.read_bytes().decode("utf-8"))
        if not (isinstance(note, dict) and isinstance(note.get("record"), dict) and isinstance(note.get("sha256"), str)):
            raise ValueError("not a pending note")
    except (OSError, UnicodeError, ValueError) as exc:
        raise LibraryError("the pending note %s cannot be read (%s): look at it, then delete it" % (marker, exc))
    return note


LOGGED_KEYS = ("action", "from_revision", "to_revision", "sha256", "restored", "backup", "source_sha256")


def already_logged(records, record):
    """Whether the log already holds this write's line. By its operation_id (r5.38); a note written before r5.38 has
    none, and then only the last line can be its own: the next write finishes a pending note before anything else is
    logged, and two writes with the same bytes (the same original restored twice) are not the same write."""
    readable = [r for r in records if "unreadable_line" not in r]
    if record.get("operation_id"):
        return any(r.get("operation_id") == record["operation_id"] for r in readable)
    return bool(readable) and all(readable[-1].get(k) == record.get(k) for k in LOGGED_KEYS)


def finish_pending(path):
    """Under the lock, before a new write: a write that replaced the library file but did not finish its log is
    finished now (the log line is added once); a pending note whose write never replaced the file is dropped."""
    note = read_pending(path)
    if note is None:
        return None
    current = sha(Path(path).read_bytes()) if Path(path).is_file() else None
    record = note["record"]
    if current == note["sha256"]:
        if not already_logged(log_records(path), record):
            log(path, dict(record, finished_later=True))
        state = "finished"
    else:
        state = "dropped: that write never replaced the library file"
    os.remove(str(history_dir(path) / PENDING))
    out = {"pending": state, "to_revision": record.get("to_revision"), "sha256": note["sha256"]}
    if record.get("operation_id"):
        out["operation_id"] = record["operation_id"]
    return out


def create_new(path, data):
    """Create path with data; O_EXCL refuses when it exists, so a file that appeared meanwhile is never overwritten."""
    fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY | getattr(os, "O_BINARY", 0))
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
    except BaseException:
        try:
            os.remove(str(path))
        except OSError:
            pass
        raise


def commit(path, raw, encoded, record, revisions=(), copies=(), create=False):
    """Write a new version of the library file in an order that can be told apart afterwards: the history copies
    (revisions: (data, revision, only_if_missing); copies: (file name, data)) and the pending note, then the library
    file (create: a new file that must not exist yet), then the log line. Raises NotCommitted when it stopped before
    the library file was replaced, CommittedIncomplete when it stopped after. Returns the write's operation_id, which
    is in the pending note and in the log line."""
    path = Path(path)
    folder = history_dir(path)
    digest = sha(encoded)
    record = dict(record, operation_id=record.get("operation_id") or new_operation_id())
    made = []
    try:
        folder.mkdir(exist_ok=True)
        for name, data in copies:
            if not (folder / name).exists():
                made.append(folder / name)
            write_atomic(folder / name, data)
        for data, revision, only_if_missing in revisions:
            target = folder / ("r%04d.json" % revision)
            if not target.exists():
                made.append(target)
            keep(path, data, revision, only_if_missing)
        note = {"record": record, "sha256": digest, "previous_sha256": sha(raw) if raw is not None else None,
                "time": datetime.datetime.now().isoformat(timespec="seconds")}
        made.append(folder / PENDING)
        write_atomic(folder / PENDING, dumps(note))
        if create:
            create_new(path, encoded)
        else:
            write_atomic(path, encoded)
    except Exception as exc:
        for target in made:
            try:
                os.remove(str(target))
            except OSError:
                pass
        raise NotCommitted("nothing written (%s: %s); the library is as it was" % (type(exc).__name__, exc)) from exc
    try:
        log(path, record)
        os.remove(str(folder / PENDING))
    except Exception as exc:
        raise CommittedIncomplete(record.get("to_revision"), digest, (
            "the library file now holds revision %s (sha256 %s), but finishing its history failed (%s: %s). Do not "
            "repeat this write: the next write finishes the log from %s/%s, and history shows it meanwhile" % (
                record.get("to_revision"), digest[:12], type(exc).__name__, exc, folder.name, PENDING)),
            record["operation_id"]) from exc
    return record["operation_id"]


def read_current(path):
    raw = Path(path).read_bytes()
    try:
        data = lib.parse(json.loads(raw.decode("utf-8-sig")))
    except (UnicodeError, ValueError) as exc:
        if isinstance(exc, LibraryError):
            raise
        raise LibraryError("cannot read the library: %s" % exc) from exc
    return raw, data


# --- migrate -------------------------------------------------------------------------------------------------------

def migrate_entry(entry):
    out = {k: entry[k] for k in ("id", "kind", "title") if k in entry}
    if lib.nonempty(entry.get("subject")):
        out["subjects"] = [entry["subject"].strip()]
    out["status"] = entry.get("status")
    out["source"] = entry.get("source")
    if lib.nonempty(entry.get("visible")):
        out["observation"] = {"scope": "legacy", "seen": entry["visible"].strip()}
    elif entry.get("status") == "candidate" and (entry.get("source") or {}).get("type") in ("author_file", "link"):
        out["observation"] = {"scope": "none"}
    for key in ("suggest", "skip", "adapt", "use", "conflicts"):
        if key in entry:
            out[key] = entry[key]
    if entry.get("status") == "picked":
        parts = [x.strip() for x in entry.get("take") or [] if isinstance(x, str) and x.strip()]
        if parts:
            out["take"] = [{"part": p, "scope": "unspecified"} for p in parts]
            out["decision"] = {"by": "旧版记录（format 1 里是 picked）", "date": "未记"}
        else:
            out["status"] = "legacy_picked"
    notes = [entry["note"].strip()] if lib.nonempty(entry.get("note")) else []
    if out["status"] == "legacy_picked":
        notes.append("format 1 里是 picked，没写借哪几样：采用范围待作者明确，不按整张用（r5.35 迁移）")
    if notes:
        out["note"] = "；".join(notes)
    return out


def migrate_data(data, raw, date):
    if lib.version(data) != 1:
        raise LibraryError("this library is already format 2")
    out = {"schema": lib.SCHEMA_V2, "book": data.get("book", ""), "revision": 1,
           "migrated_from": {"schema": lib.SCHEMA, "sha256": sha(raw), "date": date}}
    if lib.nonempty(data.get("note")):
        out["note"] = data["note"]
    out["entries"] = [migrate_entry(e) for e in data["entries"]]
    return out


def migrate(path, out=None, replace=False, date=None, root=None):
    """root: the folder image file names are relative to; by default the folder of the library being read (the old
    one for the format-1 check, the new one for the result, so a result that could not find its images from where it
    will be read is refused before anything is written)."""
    path = Path(path)
    raw, data = read_current(path)
    if lib.version(data) != 1:
        raise LibraryError("this library is already format 2")
    source_root = (Path(root) if root else path.parent).resolve()
    old_problems = lib.check_v1(data, source_root)[0]
    if old_problems:
        raise LibraryError("fix the format-1 problems first (inspiration_library.py check): %s" % "; ".join(old_problems))
    new = migrate_data(data, raw, date or today())
    target = path if replace else (Path(out) if out else path.with_name(path.stem + ".v2.json"))
    target_root = (Path(root) if root else target.parent).resolve()
    problems, notices = lib.check_v2(new, target_root)
    if problems:
        moved = target_root != source_root and not lib.check_v2(new, source_root)[0]
        raise LibraryError("the migrated library would not pass check where it will be read (%s), nothing written: %s%s"
                           % (target_root, "; ".join(problems),
                              ". Image file names are relative to the library's folder: migrate into the same folder "
                              "(the default), copy the image files next to the new library first, or give --root with "
                              "the folder they are relative to (and the same --root to check)" if moved else ""))
    encoded = dumps(new)
    legacy = [e["id"] for e in new["entries"] if e.get("status") == "legacy_picked"]
    if replace:
        with Lock(path):
            finished = finish_pending(path)
            again = path.read_bytes()
            if again != raw:
                raise LibraryError("the library changed while migrating; run migrate again")
            backup = history_dir(path) / ("v1-original-%s.json" % sha(raw)[:12])
            operation = commit(path, raw, encoded, {"action": "migrate", "from": lib.SCHEMA, "to_revision": 1,
                                                    "sha256": sha(encoded), "backup": backup.name, "legacy_picked": legacy},
                               revisions=[(encoded, 1, False)], copies=[(backup.name, raw)])
    else:
        with Lock(target):
            finished = finish_pending(target)
            if target.exists():
                raise LibraryError("%s already exists (perhaps written meanwhile); nothing written: pick another --out or "
                                   "delete it first" % target)
            folder = history_dir(target)
            if (folder / "log.jsonl").exists() or (folder.is_dir() and any(folder.glob("r[0-9]*.json"))):
                raise LibraryError("%s holds the history of another library; move it away first, nothing written" % folder)
            operation = commit(target, None, encoded, {"action": "migrate", "from": lib.SCHEMA, "source": path.name,
                                                       "source_sha256": sha(raw), "to_revision": 1, "sha256": sha(encoded),
                                                       "legacy_picked": legacy},
                               revisions=[(encoded, 1, False)], create=True)
        backup = path
    report = {"status": "OK", "library": str(target), "revision": 1, "kept": str(backup), "legacy_picked": legacy,
              "notices": notices, "operation_id": operation,
              "rollback": ("python3 inspiration_write.py restore %s --if-revision 1 --from %s" % (target, backup)
                           if replace else "the original %s is untouched; keep using it, or delete %s" % (path, target))}
    if finished:
        report["finished_pending"] = finished
    return report


# --- adopt ---------------------------------------------------------------------------------------------------------

def read_selection(raw):
    try:
        sel = json.loads(raw.decode("utf-8-sig")) if isinstance(raw, bytes) else raw
    except (UnicodeError, ValueError) as exc:
        raise LibraryError("cannot read the selection: %s" % exc) from exc
    if not isinstance(sel, dict) or sel.get("schema") != SELECTION:
        raise LibraryError("the selection is an object with schema %s" % SELECTION)
    extra = set(sel) - {"schema", "decision", "base_revision", "run", "bundle_id", "adopt", "reject", "withdraw",
                        "establish", "note"}
    if extra:
        raise LibraryError("unknown selection field(s) %s" % ", ".join(sorted(extra)))
    if "base_revision" in sel and (type(sel["base_revision"]) is not int or sel["base_revision"] < 0):
        raise LibraryError("base_revision is the library revision the choice was made on (a whole number)")
    decision = sel.get("decision")
    if not (isinstance(decision, dict) and not set(decision) - {"by", "date", "words"} and lib.nonempty(decision.get("by"))
            and isinstance(decision.get("date"), str) and lib.DATE.match(decision["date"])
            and ("words" not in decision or lib.nonempty(decision["words"]))):
        raise LibraryError("decision is {by, date: YYYY-MM-DD, words}: who chose, when, and their own words")
    for key in ("adopt", "reject", "withdraw", "establish"):
        if key in sel and (not isinstance(sel[key], list) or not all(isinstance(x, dict) and lib.nonempty(x.get("id"))
                                                                    for x in sel[key])):
            raise LibraryError("%s is a list of objects with an id" % key)
    if not any(sel.get(k) for k in ("adopt", "reject", "withdraw", "establish")):
        raise LibraryError("the selection adopts, rejects, withdraws or establishes nothing")
    for item in sel.get("establish", []):
        if set(item) - {"id", "part", "where", "chapter"} or not lib.nonempty(item.get("part")) \
                or not lib.nonempty(item.get("where")) or type(item.get("chapter")) is not int or item["chapter"] < 1:
            raise LibraryError("%s: an establish item is {id, part, where, chapter}: a part taken from this entry that is "
                               "now in the author's accepted text of that chapter, and where the book records it"
                               % item["id"])
    ids = [x["id"] for k in ("adopt", "reject", "withdraw") for x in sel.get(k, [])]
    if len(ids) != len(set(ids)):
        raise LibraryError("an entry appears twice in the selection")
    for item in sel.get("adopt", []):
        if set(item) - {"id", "entry", "mode", "take", "skip", "adapt", "use", "subjects", "note"}:
            raise LibraryError("%s: an adopt item has id, entry, mode, take, skip, adapt, use, subjects, note" % item["id"])
        if "mode" in item and item["mode"] not in MODES:
            raise LibraryError("%s: mode is add (keep what was taken and add these parts), replace (take only these parts "
                               "instead) or use (only another chapter or scene)" % item["id"])
        if "use" in item and not (isinstance(item["use"], list) and all(
                isinstance(u, dict) and not set(u) - {"chapter", "scene"} and type(u.get("chapter")) is int
                and u["chapter"] > 0 and ("scene" not in u or lib.nonempty(u["scene"])) for u in item["use"])):
            raise LibraryError("%s: use is a list of {chapter, scene}" % item["id"])
        if item.get("mode") == "use":
            if "take" in item or not item.get("use"):
                raise LibraryError("%s: mode use only adds where the entry is used (use: [{chapter, scene}]); what is "
                                   "taken stays as it is, so leave take out" % item["id"])
            continue
        take = item.get("take")
        if not (isinstance(take, list) and take and all(
                isinstance(t, dict) and not set(t) - {"part", "scope", "subject"} and lib.nonempty(t.get("part"))
                and t.get("scope") in ("stable", "scene") and ("subject" not in t or lib.nonempty(t["subject"]))
                for t in take)):
            raise LibraryError("%s: take lists the parts the author takes, each {part, scope: stable|scene, subject}; "
                               "nothing is taken that the author did not name" % item["id"])
        parts = [t["part"].strip() for t in take]
        if len(parts) != len(set(parts)):
            raise LibraryError("%s: a part is named twice in take" % item["id"])
    for item in sel.get("reject", []):
        if set(item) - {"id", "entry", "note"}:
            raise LibraryError("%s: a reject item has id, entry, note" % item["id"])
    for item in sel.get("withdraw", []):
        if set(item) - {"id", "parts", "replaced_by", "note"}:
            raise LibraryError("%s: a withdraw item has id, parts, replaced_by, note" % item["id"])
        if "parts" in item and not (isinstance(item["parts"], list) and item["parts"]
                                    and all(lib.nonempty(p) for p in item["parts"])):
            raise LibraryError("%s: parts lists the taken parts the author takes back (leave it out to withdraw the "
                               "whole entry)" % item["id"])
        if "parts" in item and "replaced_by" in item:
            raise LibraryError("%s: replaced_by is for withdrawing the whole entry, not some of its parts" % item["id"])
    return sel


def touched(sel):
    return list(dict.fromkeys(x["id"] for k in ("adopt", "reject", "withdraw", "establish") for x in sel.get(k, [])))


def same_image(entry, new):
    """Whether a candidate's entry (from a run) is the image version an entry of the library is about."""
    a, b = (entry.get("image") or {}).get("sha256"), (new.get("image") or {}).get("sha256")
    if a or b:
        return a == b
    def where(e):
        source = e.get("source") or {}
        return source.get("type"), source.get("url") or source.get("file") or source.get("ref"), source.get("sha256")
    return where(entry) == where(new)


def taken_parts(entry):
    return [t.get("part", "").strip() for t in entry.get("take") or [] if isinstance(t, dict)]


def pin_decisions(entry):
    """Before an entry that already takes parts is changed: each part keeps the choice that took it."""
    for t in entry.get("take") or []:
        if isinstance(t, dict) and "decision" not in t and isinstance(entry.get("decision"), dict):
            t["decision"] = dict(entry["decision"])


def merge_list(entry, key, values):
    if values:
        merged = list(dict.fromkeys(list(entry.get(key) or []) + list(values)))
        if merged != list(entry.get(key) or []):
            entry[key] = merged


def merge_text(entry, key, text):
    if lib.nonempty(text):
        old = entry.get(key)
        if not lib.nonempty(old):
            entry[key] = text.strip()
        elif text.strip() not in old:
            entry[key] = "%s；%s" % (old.strip(), text.strip())


def newer_look(entry, new):
    """A candidate's entry for the same image may carry a later look at it (the run's latest observation of that
    image version): it replaces the library's one when it is of the same version and not older; its conflicts and
    suggestions are added. The library's own copies in the history keep the earlier one."""
    seen = new.get("observation") or {}
    if seen.get("scope") not in ("original", "thumbnail"):
        return
    old = entry.get("observation") or {}
    version = (entry.get("image") or {}).get("sha256")
    if version and seen.get("image_sha256") != version:
        return
    if old.get("scope") in ("original", "thumbnail", "author_text") and (old.get("date") or "") > (seen.get("date") or ""):
        return
    if seen != old:
        entry["observation"] = json.loads(json.dumps(seen))
    merge_list(entry, "conflicts", new.get("conflicts"))
    merge_list(entry, "suggest", new.get("suggest"))


def apply_selection(data, sel, later=None):
    """(the library with the selection applied as a new object, what changed per entry); raises LibraryError on a
    choice that cannot be made. later: {entry id: the uses later writes added}, from the library's log
    (inspiration_library.added_uses), so an old part is never settled on a use added after it was taken."""
    later = later or {}
    out = json.loads(json.dumps(data))
    by_id = {e.get("id"): e for e in out["entries"]}
    decision = dict(sel["decision"])
    changes = {}

    def entry_for(item, allowed):
        entry = by_id.get(item["id"])
        if entry is None:
            new = item.get("entry")
            if not isinstance(new, dict) or new.get("id") != item["id"]:
                raise LibraryError("%s is not in the library; give the candidate's entry (from the run) to add it" % item["id"])
            entry = json.loads(json.dumps(new))
            out["entries"].append(entry)
            by_id[item["id"]] = entry
            changes.setdefault(item["id"], {})["added"] = True
        elif "entry" in item:
            new = item["entry"]
            if not isinstance(new, dict) or new.get("id") != item["id"] or not same_image(entry, new):
                raise LibraryError("%s: the candidate's entry is of another image version than the library's %s (another "
                                   "file under the same id); nothing written" % (item["id"], item["id"]))
        if entry.get("status") not in allowed:
            raise LibraryError("%s is %s; this choice applies to %s" % (item["id"], entry.get("status"), ", ".join(allowed)))
        return entry

    def places(item):
        """Where this choice uses the entry (a run's chapter and scene)."""
        return [dict(p) for p in item.get("use") or (item.get("entry") or {}).get("use") or [] if lib.place_ok(p)]

    def mark(t, item):
        """A part taken for one scene says which (taken_for, r5.38): the card gives it to that scene only, so using the
        image in another chapter does not bring along what was only for this scene."""
        where = places(item)
        return dict(t, taken_for=where) if t.get("scope") == "scene" and where else dict(t)

    def old_parts(entry):
        """The parts for one scene that say neither which scene (taken_for) nor that it is not known."""
        return [t for t in entry.get("take") or [] if isinstance(t, dict) and t.get("scope") == "scene"
                and "taken_for" not in t and "taken_for_unknown" not in t]

    def settle_old_parts(entry, before, change):
        """Before a use is added, or mode add names such a part again (r5.40): a part for one scene recorded before
        r5.38 says no scene. The entry's only use before this write, not counting the uses later writes added (the
        log), is that scene; with more uses or none the record does not say, and the part waits for the author
        (taken_for_unknown). Never settled from the uses this write adds."""
        added = [dict(u) for u in later.get(entry.get("id"), [])]
        earlier = [dict(u) for u in before.get("use") or [] if lib.place_ok(u) and u not in added]
        left_out = [dict(u) for u in before.get("use") or [] if lib.place_ok(u) and u in added]
        bound, unknown = [], []
        for t in old_parts(entry):
            if len(earlier) == 1:
                t["taken_for"] = [dict(earlier[0])]
                bound.append(t["part"].strip())
            else:
                t["taken_for_unknown"] = True
                unknown.append(t["part"].strip())
        if bound:
            change["scene_parts_bound"] = {"parts": bound, "taken_for": earlier,
                                           "basis": "the entry's only use before this write%s (the library's own record, "
                                                    "not a new choice of the author)" % (
                                                        ", not counting the uses later writes added (its log)"
                                                        if left_out else "")}
        if unknown:
            change["scene_parts_unknown"] = {"parts": unknown, "uses_before": earlier,
                                             "basis": "recorded before r5.38 without its scene, and the entry had %s use%s "
                                                      "before this write: waits for the author" % (
                                                          len(earlier) or "no", "" if len(earlier) == 1 else "s")}
        for record in ("scene_parts_bound", "scene_parts_unknown"):
            if record in change and left_out:
                change[record]["uses_added_later"] = left_out  # by mode add or use, after the part (the log)

    for item in sel.get("adopt", []):
        mode = item.get("mode")
        if mode and item["id"] not in by_id:
            raise LibraryError("%s is not in the library yet: leave mode out to add it as a new entry" % item["id"])
        entry = entry_for(item, ("candidate", "legacy_picked", "picked", "rejected", "withdrawn"))
        before = json.loads(json.dumps(entry))
        change = changes.setdefault(item["id"], {})
        picked_before = entry.get("status") == "picked" and not change.get("added")
        if picked_before:
            if not mode:
                raise LibraryError(
                    "%s is already picked (it takes %s). Say what the author wants: mode add keeps these and adds the "
                    "parts named now, mode replace takes only the parts named now instead, mode use only adds a chapter "
                    "or scene; nothing written" % (item["id"], "；".join(taken_parts(entry)) or "nothing"))
            already = list(entry.get("use", []))
            named_again = {t["part"].strip() for t in item.get("take") or []} if mode == "add" else set()
            if mode in ("add", "use") and (
                    [u for u in item.get("use") or (item.get("entry") or {}).get("use") or [] if u not in already]
                    or any(t["part"].strip() in named_again for t in old_parts(entry))):
                # before the new use is there to be mistaken for its scene, and before add extends an old part (replace
                # takes new parts: nothing to settle)
                settle_old_parts(entry, before, change)
            if mode == "add":
                added = []
                for t in item["take"]:
                    old = next((x for x in entry["take"] if x.get("part", "").strip() == t["part"].strip()), None)
                    if old is not None:
                        if (old.get("scope"), old.get("subject")) != (t["scope"], t.get("subject")):
                            raise LibraryError("%s already takes %s (%s%s); to change how it is taken, use mode replace" % (
                                item["id"], t["part"].strip(), old.get("scope"),
                                "，" + old["subject"] if old.get("subject") else ""))
                        listed = old["taken_for"] if isinstance(old.get("taken_for"), list) else []
                        more = [p for p in places(item) if p not in listed] if old.get("scope") == "scene" else []
                        if more:  # a part for one scene, now also for a scene the author named (r5.40: with or
                            # without an earlier taken_for)
                            old["taken_for"] = listed + more
                            change.setdefault("parts_for_more_scenes", []).append(t["part"].strip())
                        continue  # the same part again: nothing to add
                    entry["take"].append(dict(mark(t, item), decision=decision))
                    added.append(t["part"].strip())
                if added:
                    change["parts_added"] = added
                merge_list(entry, "skip", item.get("skip"))
                merge_text(entry, "adapt", item.get("adapt"))
            elif mode == "replace":
                change["take_before"] = [dict(t, decision=t.get("decision") or before.get("decision"))
                                         for t in before.get("take") or [] if isinstance(t, dict)]
                entry["take"] = [dict(mark(t, item), decision=decision) for t in item["take"]]
                if not places(item):
                    # r5.40: no scene named now, so a part for one scene named again keeps the scenes it was taken for
                    old_by_part = {x.get("part", "").strip(): x for x in before.get("take") or [] if isinstance(x, dict)}
                    for t in entry["take"]:
                        old = old_by_part.get(t["part"].strip())
                        if t.get("scope") == "scene" and old is not None and old.get("scope") == "scene" and (
                                "taken_for" in old or "taken_for_unknown" in old):
                            t.update({k: json.loads(json.dumps(old[k])) for k in ("taken_for", "taken_for_unknown")
                                      if k in old})
                            change.setdefault("parts_kept_for_their_scenes", []).append(t["part"].strip())
                established = {e.get("part", "").strip() for e in entry.get("established", []) if isinstance(e, dict)}
                gone = sorted(established - set(taken_parts(entry)))
                if gone:
                    raise LibraryError("%s: %s is in the author's accepted text (established); replace keeps it, or the "
                                       "book's fact changes with the author's text first" % (item["id"], "、".join(gone)))
                for key in ("skip", "adapt"):
                    if key in item:
                        entry[key] = item[key]
            if "entry" in item:
                newer_look(entry, item["entry"])
            merge_text(entry, "note", item.get("note"))
        else:
            if mode in ("add", "use"):
                raise LibraryError("%s is %s, not picked: adopting it takes only the parts named now (leave mode out, or "
                                   "mode replace)" % (item["id"], entry.get("status")))
            if not change.get("added") and "entry" in item:
                newer_look(entry, item["entry"])
            entry["status"] = "picked"
            entry["take"] = [mark(t, item) for t in item["take"]]
            for key in ("skip", "adapt"):
                if key in item:
                    entry[key] = item[key]
            if lib.nonempty(item.get("note")):
                entry["note"] = item["note"]
            entry.pop("replaced_by", None)
            change.setdefault("picked", True)
        merge_list(entry, "subjects", item.get("subjects"))
        uses = list(entry.get("use", []))
        new_uses = [u for u in item.get("use") or ((item.get("entry") or {}).get("use") if mode else None) or []
                    if u not in uses]
        if new_uses:
            entry["use"] = uses + new_uses
            change["use_added"] = new_uses
        if entry == before:
            change["unchanged"] = True
            continue
        if picked_before:
            # The parts kept from an earlier choice keep that choice; the entry's decision is the latest.
            for t in entry.get("take") or []:
                if isinstance(t, dict) and "decision" not in t and isinstance(before.get("decision"), dict):
                    t["decision"] = dict(before["decision"])
            change.setdefault("mode", mode)
        entry["decision"] = decision
    for item in sel.get("reject", []):
        if (by_id.get(item["id"]) or {}).get("status") == "picked":
            raise LibraryError("%s is picked: not wanted now is taking it back, so the history says so: withdraw it (or "
                               "withdraw with parts for some of what it takes); nothing written" % item["id"])
        entry = entry_for(item, ("to_find", "candidate", "legacy_picked", "rejected"))
        entry["status"] = "rejected"
        entry["decision"] = decision
        entry.pop("take", None)
        if lib.nonempty(item.get("note")):
            entry["note"] = item["note"]
    for item in sel.get("withdraw", []):
        entry = entry_for(item, ("picked",))
        parts = [p.strip() for p in item.get("parts") or []]
        if parts:
            names = taken_parts(entry)
            missing = [p for p in parts if p not in names]
            if missing:
                raise LibraryError("%s does not take %s (it takes %s)" % (item["id"], "、".join(missing), "；".join(names)))
            established = {e.get("part", "").strip() for e in entry.get("established", []) if isinstance(e, dict)}
            fixed = [p for p in parts if p in established]
            if fixed:
                raise LibraryError("%s: %s is in the author's accepted text (established); the book's fact changes with "
                                   "the author's text, not here" % (item["id"], "、".join(fixed)))
            if len(parts) < len(names):
                pin_decisions(entry)
                changes.setdefault(item["id"], {}).update(parts_withdrawn=parts,
                                                          take_before=[dict(t) for t in entry["take"]])
                entry["take"] = [t for t in entry["take"] if t.get("part", "").strip() not in parts]
                entry["decision"] = decision
                if lib.nonempty(item.get("note")):
                    merge_text(entry, "note", item["note"])
                continue
        entry["status"] = "withdrawn"
        entry["decision"] = decision
        if lib.nonempty(item.get("replaced_by")):
            entry["replaced_by"] = item["replaced_by"]
        if lib.nonempty(item.get("note")):
            entry["note"] = item["note"]
    for item in sel.get("establish", []):
        entry = by_id.get(item["id"])
        if entry is None or entry.get("status") != "picked":
            raise LibraryError("%s: only a picked entry's parts become the book's fact" % item["id"])
        parts = [t.get("part", "").strip() for t in entry.get("take") or []]
        if item["part"].strip() not in parts:
            raise LibraryError("%s: %s is not one of the parts the author took (%s)" % (item["id"], item["part"],
                                                                                    "；".join(parts)))
        record = {"part": item["part"].strip(), "where": item["where"].strip(), "chapter": item["chapter"]}
        if record not in entry.setdefault("established", []):
            entry["established"].append(record)
    return out, changes


def additive(sel, entry_id):
    """Whether everything this selection does to entry_id only adds to a picked entry (mode add or use)."""
    doing = [(k, x) for k in ("adopt", "reject", "withdraw", "establish") for x in sel.get(k, []) if x["id"] == entry_id]
    return bool(doing) and all(k == "adopt" and x.get("mode") in ("add", "use") for k, x in doing)


def adopt(path, sel, if_revision, rebase=False, dry_run=False, root=None):
    path = Path(path)
    sel = read_selection(sel)
    if "base_revision" in sel and sel["base_revision"] != if_revision:
        raise LibraryError("the selection was made on revision %d, but --if-revision says %d: read the library at the "
                           "revision the choice was made on, or make the choice again" % (sel["base_revision"],
                                                                                          if_revision))
    with Lock(path):
        finished = None if dry_run else finish_pending(path)
        raw, data = read_current(path)
        if lib.version(data) != 2:
            raise LibraryError("this library is format 1: migrate it first (inspiration_write.py migrate)")
        current = data["revision"]
        base = data
        if current != if_revision:
            snapshot = history_dir(path) / ("r%04d.json" % if_revision)
            if not rebase or not snapshot.is_file():
                raise Conflict(current, [], "the library is at revision %d, not %d: someone wrote it since you read it. "
                               "Read it again and make the choice on the new revision, or use --rebase%s" % (
                                   current, if_revision, "" if snapshot.is_file() else " (no copy of revision %d in the "
                                   "history to compare with)" % if_revision))
            old = {e.get("id"): e for e in json.loads(snapshot.read_bytes().decode("utf-8"))["entries"]}
            new = {e.get("id"): e for e in data["entries"]}
            # Additions to an entry that was picked then and is picked now are applied to what it is now, so what
            # someone else added meanwhile stays (r5.38); any other change to a touched entry is a conflict.
            changed = [i for i in touched(sel) if old.get(i) != new.get(i) and not (
                additive(sel, i) and (old.get(i) or {}).get("status") == "picked"
                and (new.get(i) or {}).get("status") == "picked")]
            if changed:
                raise Conflict(current, changed, "the library is at revision %d and %s changed since revision %d: read "
                               "them again before choosing" % (current, ", ".join(changed), if_revision))
        result, changes = apply_selection(base, sel, lib.added_uses(path))
        if result["entries"] == data["entries"]:
            report = {"status": "UNCHANGED", "revision": current, "changes": changes,
                      "note": "the library already holds this choice; nothing written"}
            if finished:
                report["finished_pending"] = finished
            return report
        result["revision"] = current + 1
        problems, notices = lib.check_v2(result, (root or path.parent).resolve())
        before = set(lib.check_v2(data, (root or path.parent).resolve())[0])
        mine = [p for p in problems if p not in before]
        if mine:
            return {"status": "PROBLEMS", "problems": mine, "revision": current}
        report = {"status": "DRY-RUN" if dry_run else "OK", "revision": current if dry_run else current + 1,
                  "adopted": [x["id"] for x in sel.get("adopt", [])], "rejected": [x["id"] for x in sel.get("reject", [])],
                  "withdrawn": [x["id"] for x in sel.get("withdraw", [])],
                  "established": [x["id"] for x in sel.get("establish", [])], "notices": notices,
                  "rebased_from": if_revision if current != if_revision else None, "changes": changes}
        if finished:
            report["finished_pending"] = finished
        if dry_run:
            adopted = set(report["adopted"])
            chapters = sorted({u["chapter"] for e in result["entries"] if e.get("id") in adopted for u in lib.uses(e)
                               if isinstance(u, dict) and isinstance(u.get("chapter"), int)})
            report["cards"] = {str(c): lib.card(result, c, None, lib.added_uses(path)) for c in chapters}
            return report
        encoded = dumps(result)
        record = {"action": "adopt", "from_revision": current, "to_revision": current + 1, "based_on": if_revision,
                  "sha256": sha(encoded), "previous_sha256": sha(raw), "entries": touched(sel),
                  "by": sel["decision"]["by"], "date": sel["decision"]["date"], "words": sel["decision"].get("words", ""),
                  "run": sel.get("run", "")}
        if sel.get("bundle_id"):
            record["bundle_id"] = sel["bundle_id"]
        modes = {i: c for i, c in changes.items() if c.get("mode") or c.get("parts_withdrawn")}
        if modes:
            record["changes"] = modes  # what add, replace, use and part withdrawals did, with the parts replaced
        # The revision this write starts from (for a later --rebase) and the new one go into the history first.
        report["operation_id"] = commit(path, raw, encoded, record,
                                        revisions=[(raw, current, True), (encoded, current + 1, False)])
        report["sha256"] = record["sha256"]
        return report


def restore(path, if_revision, revision=None, backup=None, root=None):
    path = Path(path)
    with Lock(path):
        finished = finish_pending(path)
        raw, data = read_current(path)
        current = data.get("revision") if lib.version(data) == 2 else None
        if current != if_revision:
            raise Conflict(current, [], "the library is at revision %s, not %s" % (current, if_revision))
        try:
            if revision is not None:
                source = history_dir(path) / ("r%04d.json" % revision)
                if not source.is_file():
                    raise LibraryError("no copy of revision %d in %s" % (revision, history_dir(path).name))
                old = lib.parse(json.loads(source.read_bytes().decode("utf-8")))
                old["revision"] = current + 1
                encoded = dumps(old)
                label = "revision %d" % revision
            else:
                source = Path(backup)
                encoded = source.read_bytes()
                old = lib.parse(json.loads(encoded.decode("utf-8-sig")))
                if lib.version(old) == 2:
                    old["revision"] = current + 1
                    encoded = dumps(old)
                label = source.name
        except (UnicodeError, ValueError) as exc:
            if isinstance(exc, LibraryError):
                raise
            raise LibraryError("cannot read the copy to restore: %s" % exc) from exc
        # A copy whose entries are broken (beyond what the current library already has) is refused before anything
        # is written; image files that are only missing or moved now are reported, and the restore goes ahead (the
        # format-1 original bytes stay restorable as they were).
        folder_root = (Path(root) if root else path.parent).resolve()
        structure = lib.check_report(old, folder_root, files=False)[0]
        already = set(lib.check_report(data, folder_root, files=False)[0])
        broken = [p for p in structure if p not in already]
        if broken:
            raise LibraryError("the copy to restore would not pass check, nothing written: %s" % "; ".join(broken))
        environment = [p for p in lib.check_report(old, folder_root)[0] if p not in structure]
        record = {"action": "restore", "from_revision": current, "to_revision": old.get("revision"), "restored": label,
                  "sha256": sha(encoded), "kept_before": "before-restore-r%04d.json" % current}
        revisions = [(raw, current, True)] + ([(encoded, current + 1, False)] if lib.version(old) == 2 else [])
        operation = commit(path, raw, encoded, record, revisions=revisions,
                           copies=[("before-restore-r%04d.json" % current, raw)])
        report = {"status": "OK", "restored": label, "revision": old.get("revision"), "schema": old["schema"],
                  "operation_id": operation}
        if environment:
            report["files_now"] = environment
        if finished:
            report["finished_pending"] = finished
        return report


def history(path):
    """The log's records; a cut-off line is listed as unreadable; a write whose log line is still pending is listed
    last, with whether the library file holds it."""
    out = log_records(path)
    note = read_pending(path)
    if note is not None:
        current = sha(Path(path).read_bytes()) if Path(path).is_file() else None
        out.append({"pending": note["record"], "committed": current == note["sha256"],
                    "note": "the log line of this write is not written yet; the next write adds it"
                    if current == note["sha256"] else "this write did not replace the library file; the next write "
                    "drops the note"})
    return out


def main():
    lib.utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = parser.add_subparsers(dest="command", required=True)
    mig = sub.add_parser("migrate")
    mig.add_argument("library", type=Path)
    where = mig.add_mutually_exclusive_group()
    where.add_argument("--out", type=Path)
    where.add_argument("--replace", action="store_true")
    mig.add_argument("--date", help="the migration date (YYYY-MM-DD; default today)")
    mig.add_argument("--root", type=Path, help="folder the image file names are relative to (default: the library's "
                                               "folder; give the same --root to check)")
    ado = sub.add_parser("adopt")
    ado.add_argument("library", type=Path)
    ado.add_argument("--selection", type=Path, required=True)
    ado.add_argument("--if-revision", type=int, required=True)
    ado.add_argument("--rebase", action="store_true")
    ado.add_argument("--dry-run", action="store_true")
    res = sub.add_parser("restore")
    res.add_argument("library", type=Path)
    res.add_argument("--if-revision", type=int, required=True)
    which = res.add_mutually_exclusive_group(required=True)
    which.add_argument("--revision", type=int)
    which.add_argument("--from", dest="backup", type=Path)
    his = sub.add_parser("history")
    his.add_argument("library", type=Path)
    args = parser.parse_args()
    try:
        if args.command == "migrate":
            if args.date and not lib.DATE.match(args.date):
                raise LibraryError("--date is YYYY-MM-DD")
            report = migrate(args.library, args.out, args.replace, args.date, args.root)
        elif args.command == "adopt":
            report = adopt(args.library, args.selection.read_bytes(), args.if_revision, args.rebase, args.dry_run)
        elif args.command == "restore":
            report = restore(args.library, args.if_revision, args.revision, args.backup)
        else:
            report = {"status": "OK", "log": history(args.library)}
        print(json.dumps(report, ensure_ascii=False, indent=1))
        return 1 if report.get("status") == "PROBLEMS" else 0
    except Conflict as exc:
        print(json.dumps({"status": "CONFLICT", "current_revision": exc.current, "changed": exc.changed,
                          "error": str(exc)}, ensure_ascii=False, indent=1))
        return 3
    except CommittedIncomplete as exc:
        print(json.dumps({"status": "COMMITTED_INCOMPLETE", "revision": exc.revision, "sha256": exc.sha256,
                          "operation_id": exc.operation_id, "error": str(exc)}, ensure_ascii=False, indent=1))
        return 4
    except (LibraryError, OSError) as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    sys.exit(main())

"""Behavioral checks for conditional learning records; fixtures are synthetic."""
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
spec = importlib.util.spec_from_file_location("learning_loop", ROOT / "scripts/learning_loop.py")
loop = importlib.util.module_from_spec(spec)
spec.loader.exec_module(loop)
import project_state


START = "<!-- NOVEL_WORKSHOP_LEARNING_START -->"
END = "<!-- NOVEL_WORKSHOP_LEARNING_END -->"
PREFIX = "# 本书学习记录\r\n\r\n作者的原有说明：人物与正文另有权威。\n\n"
SUFFIX = "\n\n## 手写便笺\n保留空格  和换行。\n"


def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def case(case_id, *, status="teacher_approved", group=None,
         split="development", task="dialogue_revision", tags=None, project="book"):
    item = json.loads((ROOT / "assets/demonstration-case-template.json").read_text(encoding="utf-8"))
    item.update(id=case_id, project_id=project, group_id=group or case_id,
                status=status, split=split, task=task, tags=tags or ["dialogue"],
                before="合成原稿：" + case_id, after="合成改稿：" + case_id,
                why="让回应与对方当下的动作相接。", when=["双方正在对话"],
                **{"except": ["本段有意表现答非所问"]})
    item["source"] = {"ref": "fixture://teacher/" + case_id, "version": "1",
                      "reviewer": "synthetic-teacher", "evidence": "Synthetic test evidence only."}
    item["hashes"] = {key: sha(item[key]) for key in ("before", "after")}
    return item


AUTHOR = {"actor_role": "author", "mode": "human"}
ACCEPT = "采纳当前稿。"


class LoopFixture(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "学习记录.md"
        self.serial = 0
        self.write_record()

    def write_record(self, items=(), extra=None):
        data = {"demonstration_learning": {"enabled": True, "loop_enabled": True,
                                            "max_revisions": 2},
                "demonstrations": {c["id"]: c for c in items},
                "learning_runs": {}, "learning_events": {}}
        data.update(copy.deepcopy(extra or {}))
        payload = {"schema_version": 1, "project_id": "book", "revision": 0, "data": data}
        self.path.write_text(PREFIX + START + "\n```json\n" +
                             json.dumps(payload, ensure_ascii=False) + "\n```\n" + END + SUFFIX,
                             encoding="utf-8")

    def payload(self):
        return loop.read_store(self.path)[0]

    def event(self, op, run_id="run", **fields):
        self.serial += 1
        event = {"event_id": "event-" + str(self.serial), "op": op, **fields}
        if run_id is not None:
            event["run_id"] = run_id
        return event

    def apply(self, op, run_id="run", **fields):
        return self.send(self.event(op, run_id, **fields))

    def send(self, event, *, project_id="book", version=None):
        if version is None:
            version = loop.read_store(self.path)[1]
        return loop.apply_event(self.path, event, project_id, version)

    def rejected(self, event, **kwargs):
        before = self.path.read_bytes()
        with self.assertRaises(loop.LoopError) as caught:
            self.send(event, **kwargs)
        self.assertTrue(caught.exception.code)
        self.assertEqual(self.path.read_bytes(), before, "a rejected event must perform no write")
        return caught.exception

    def begin(self, *, text="她把杯子推回来。‘你先说。’", run_id="run", plan=True):
        self.apply("start", run_id, task="dialogue_revision", tags=["dialogue"],
                   group_id="current-scene", input_text="他把杯子递过去。她说，‘我知道。’",
                   source_ref="fixture://input/chapter-2", constraints=["保留杯子这个动作"])
        if plan:
            self.apply("plan", run_id, applications=[], checks=["回应接住对方动作"])
            self.apply("draft", run_id, text=text, source_ref="fixture://draft/v1",
                       actor={"name": "synthetic-writer", "context_id": "writer-context"})
        return text

    def run_record(self, run_id="run"):
        return self.payload()["data"]["learning_runs"][run_id]

    def review(self, review_id="review-1", *, text=None, verdict="pass", findings=None,
               role="writer", mode="self_check", context_id="writer-context", rechecks=None,
               run_id="run", **extra):
        if text is None:
            # The latest registered draft holds the text; current_draft only keeps its hash.
            text = self.run_record(run_id)["drafts"][-1]["text"]
        fields = dict(review_id=review_id, draft_sha256=sha(text),
                      reviewer={"name": "synthetic-" + role, "role": role,
                                "mode": mode, "context_id": context_id},
                      verdict=verdict, findings=findings or [],
                      source_ref="fixture://reviews/" + review_id, **extra)
        if rechecks is not None:
            fields["rechecks"] = rechecks
        return self.apply("review", run_id, **fields)

    def author_review(self, review_id="author-no", *, verdict="revise", findings=None):
        if findings is None and verdict == "revise":
            findings = [{"id": "f1", "issue": "这句台词不要", "evidence": "‘你先说。’", "scope": "第二句"}]
        return self.review(review_id, verdict=verdict, findings=findings, role="author",
                           mode="human", context_id="author-context")

    def accept_event(self, text, quote=ACCEPT, **fields):
        return self.event("author_accept", draft_sha256=sha(text), quote=quote,
                          source_ref="fixture://author/comment", **{**AUTHOR, **fields})

    def request_revision(self, review_id="needs-fix", *, rechecks=None):
        self.review(review_id, verdict="revise", findings=[{
            "id": "f1", "issue": "回应没有接住动作", "evidence": "她没有碰杯子", "scope": "第二句"}],
            role="teacher", mode="independent_agent", context_id="teacher-context",
            rechecks=rechecks)

    def decide_event(self, review_id="needs-fix", decision="adopt", **finding_fields):
        return self.event("decide", review_id=review_id,
                          decisions=[{"finding_id": "f1", "decision": decision,
                                      "reason": "与当前文本和保留动作的要求核对后取舍。", **finding_fields}])

    def adopt(self, review_id="needs-fix", decision="adopt", **finding_fields):
        return self.send(self.decide_event(review_id, decision, **finding_fields))

    def revise_event(self, text="她按住杯子。‘你先说。’", review_id="needs-fix", parent=None):
        if parent is None:
            parent = self.run_record()["current_draft"]["sha256"]
        return self.event("revise", parent_sha256=parent, text=text,
                          source_ref="fixture://draft/v2", review_id=review_id,
                          actor={"name": "synthetic-writer", "context_id": "writer-context"})

    def revise(self, text="她按住杯子。‘你先说。’", review_id="needs-fix", parent=None):
        return self.send(self.revise_event(text, review_id, parent))

    def finish_event(self, text):
        return self.event("finish", draft_sha256=sha(text))

    def finish(self, text):
        return self.send(self.finish_event(text))

    def learn_event(self, case_id="learned"):
        return self.event("learn", case_id=case_id, why="回应承接了杯子的动作。",
                          when=["需要让对白与动作互相承接"],
                          **{"except": ["刻意表现答非所问"]}, decisions=["保留杯子，改回应。"])

    def learn(self, case_id="learned"):
        return self.send(self.learn_event(case_id))


class LearningLoopTests(LoopFixture):

    def test_markdown_writes_preserve_all_outside_text_and_unrelated_data(self):
        unrelated = {"handwritten": {"keep": ["人物另存", 7], "literal": "普通资料里的```不结束JSON字符串"},
                     "characters": {"L": {"name": "林"}}}
        self.write_record(extra=unrelated)
        result = self.apply("configure", None, loop_enabled=True, max_revisions=3)
        saved = self.path.read_bytes()
        self.assertEqual(result["status"], "saved")
        self.assertEqual(saved.split(START.encode())[0], PREFIX.encode())
        self.assertEqual(saved.split(END.encode())[1], SUFFIX.encode())
        for key, value in unrelated.items():
            self.assertEqual(self.payload()["data"][key], value)

    def test_wrong_project_is_rejected_without_writing(self):
        self.rejected(self.event("configure", None, loop_enabled=False), project_id="another-book")

    def test_stale_version_rejects_even_an_unrelated_change(self):
        old_version = loop.read_store(self.path)[1]
        # A note outside the JSON block is still part of the read version.
        self.path.write_bytes(self.path.read_bytes() + "作者新补的块外便笺。\n".encode())
        self.assertNotEqual(loop.read_store(self.path)[1], old_version)
        self.rejected(self.event("configure", None, loop_enabled=False), version=old_version)

    def test_event_retry_is_idempotent_and_id_reuse_with_new_payload_is_rejected(self):
        event = self.event("configure", None, max_revisions=3, loop_enabled=True)
        original_version = loop.read_store(self.path)[1]
        first = self.send(event, version=original_version)
        saved = self.path.read_bytes()
        # A lost-response retry repeats both its event and original CAS token.
        again = self.send(copy.deepcopy(event), version=original_version)
        self.assertEqual(again["status"], "unchanged")
        self.assertEqual(again["version"], first["version"])
        self.assertEqual(self.path.read_bytes(), saved)
        changed = {**event, "max_revisions": 4}
        self.rejected(changed)

    def test_zero_examples_and_unchanged_draft_can_finish_as_self_checked_candidate(self):
        original = "他把杯子递过去。她说，‘我知道。’"
        text = self.begin(text=original)
        self.review()
        self.finish(text)
        self.learn()
        learned = self.payload()["data"]["demonstrations"]["learned"]
        self.assertEqual((learned["before"], learned["after"]), (original, original))
        self.assertEqual(learned["status"], "candidate")
        self.assertEqual(learned["hashes"], {"before": sha(original), "after": sha(original)})
        self.assertTrue(learned["source"]["ref"])
        self.assertIsNone(learned.get("author_acceptance"))

    def test_selected_example_may_be_declined_when_its_exception_applies(self):
        self.write_record([case("deliberate-nonanswer")])
        self.begin(plan=False)
        self.apply("plan", applications=[{
            "case_id": "deliberate-nonanswer", "decision": "decline",
            "reason": "本轮要表现她有意回避，不套用正常应答。",
            "conditions_checked": {"双方正在对话": True},
            "exceptions_checked": {"本段有意表现答非所问": True}}], checks=["回避是有意的"])
        text = "她没有接杯子。‘今天下雨了。’"
        self.apply("draft", text=text, source_ref="fixture://draft/nonanswer",
                   actor={"name": "synthetic-writer", "context_id": "writer-context"})
        self.review()
        self.assertEqual(self.finish(text)["status"], "saved")

    def test_context_excludes_unrelated_examples_entire_holdout_groups_and_text_duplicates(self):
        held = case("held", split="holdout", group="held-scene")
        duplicate = case("duplicate")
        duplicate["before"] = held["after"]
        duplicate["hashes"]["before"] = held["hashes"]["after"]
        self.write_record([held, case("sibling", group="held-scene"), duplicate,
                           case("other-task", task="combat_revision"),
                           case("other-tags", tags=["combat"]), case("other-book", project="elsewhere"),
                           case("safe")])
        result = loop.context(self.path, "book", "dialogue_revision", tags=["dialogue"])
        self.assertEqual([c["id"] for c in result["cases"]], ["safe"])

    def test_feedback_for_a_different_draft_hash_is_rejected(self):
        self.begin()
        self.rejected(self.event("review", review_id="wrong-draft", draft_sha256=sha("另一个稿件"),
            reviewer={"name": "teacher", "role": "teacher", "mode": "independent_agent",
                      "context_id": "teacher-context"}, verdict="pass", findings=[],
            source_ref="fixture://reviews/wrong-draft"))

    def test_same_writer_context_cannot_claim_an_independent_review(self):
        text = self.begin()
        self.rejected(self.event("review", review_id="same-context", draft_sha256=sha(text),
            reviewer={"name": "another-name", "role": "teacher", "mode": "independent_agent",
                      "context_id": "writer-context"}, verdict="pass", findings=[],
            source_ref="fixture://reviews/same-context"))

    def test_self_check_cannot_be_teacher_or_author_approval(self):
        text = self.begin()
        for role in ("teacher", "author"):
            with self.subTest(role=role):
                self.rejected(self.event("review", review_id="pretend-" + role, draft_sha256=sha(text),
                    reviewer={"name": role, "role": role, "mode": "self_check",
                              "context_id": "writer-context"}, verdict="pass", findings=[],
                    source_ref="fixture://reviews/pretend"))

    def test_revision_invalidates_old_pass_and_requires_explicit_recheck_binding(self):
        self.begin()
        self.review("old-pass")
        self.request_revision()
        self.adopt()
        revised = "她按住杯子。‘你先说。’"
        self.revise(revised)
        self.rejected(self.event("finish", draft_sha256=sha(revised)))
        # An unbound pass may be refused when recorded or when finishing, but
        # it must never complete the run or discharge the earlier feedback.
        unbound = self.event("review", review_id="unbound-pass", draft_sha256=sha(revised),
            reviewer={"name": "teacher", "role": "teacher", "mode": "independent_agent",
                      "context_id": "teacher-context"}, verdict="pass", findings=[],
            source_ref="fixture://reviews/unbound")
        before = self.path.read_bytes()
        try:
            self.send(unbound)
        except loop.LoopError:
            self.assertEqual(self.path.read_bytes(), before)
        else:
            self.rejected(self.event("finish", draft_sha256=sha(revised)))
        self.review("bound-pass", role="teacher", mode="independent_agent",
                    context_id="teacher-context", rechecks=["needs-fix"])
        self.assertEqual(self.finish(revised)["status"], "saved")

    def test_revision_requires_an_adopted_finding(self):
        self.begin()
        self.request_revision()
        for decision in (None, "decline"):
            with self.subTest(decision=decision):
                if decision:
                    self.adopt(decision=decision)
                parent = self.payload()["data"]["learning_runs"]["run"]["current_draft"]["sha256"]
                self.rejected(self.event("revise", parent_sha256=parent, text="未获采纳的改写",
                    source_ref="fixture://draft/unadopted", review_id="needs-fix",
                    actor={"name": "synthetic-writer", "context_id": "writer-context"}))

    def test_revision_must_name_the_current_parent_hash(self):
        self.begin()
        self.request_revision()
        self.adopt()
        self.rejected(self.event("revise", parent_sha256=sha("并非本轮稿件"), text="错误父稿的改写",
            source_ref="fixture://draft/wrong-parent", review_id="needs-fix",
            actor={"name": "synthetic-writer", "context_id": "writer-context"}))

    def test_revision_budget_stops_further_rewriting_without_forcing_a_pass(self):
        self.apply("configure", None, loop_enabled=True, max_revisions=1)
        self.begin()
        self.request_revision()
        self.adopt()
        self.revise()
        self.request_revision("still-needs-fix", rechecks=["needs-fix"])
        self.adopt("still-needs-fix")
        parent = self.payload()["data"]["learning_runs"]["run"]["current_draft"]["sha256"]
        self.rejected(self.event("revise", parent_sha256=parent, text="超出预算的第二次改写",
            source_ref="fixture://draft/over-budget", review_id="still-needs-fix",
            actor={"name": "synthetic-writer", "context_id": "writer-context"}))
        self.assertEqual(self.apply("stop", reason="本轮返工额度已用完，保留未解决问题。")["status"], "saved")

    def test_learn_uses_real_input_final_text_and_actual_teacher_review(self):
        original = "他把杯子递过去。她说，‘我知道。’"
        self.begin()
        self.request_revision()
        self.adopt()
        final = "她按住杯子。‘你先说。’"
        self.revise(final)
        self.review("teacher-final", role="teacher", mode="independent_agent",
                    context_id="teacher-context", rechecks=["needs-fix"])
        self.finish(final)
        self.learn()
        learned = self.payload()["data"]["demonstrations"]["learned"]
        self.assertEqual((learned["before"], learned["after"]), (original, final))
        self.assertEqual(learned["hashes"], {"before": sha(original), "after": sha(final)})
        self.assertEqual(learned["status"], "teacher_approved")
        self.assertIsNone(learned.get("author_acceptance"))
        source = learned["source"]
        self.assertEqual(source["run_id"], "run")
        self.assertEqual(source["input_ref"], "fixture://input/chapter-2")
        self.assertEqual(source["draft_ref"], "fixture://draft/v2")
        self.assertEqual(source["draft_sha256"], sha(final))
        self.assertIn("teacher-final", source["review_ids"])

    def test_author_acceptance_requires_a_quote_and_binds_current_text(self):
        text = self.begin()
        self.review()
        self.finish(text)
        # r5.55: the event now also says who spoke (author, in person) and the words
        # must be an explicit acceptance, so the fixture carries both; the two
        # refusals below still fail only for the reason they name.
        self.rejected(self.accept_event(text, quote=""))
        self.rejected(self.accept_event("旧稿"))
        self.send(self.accept_event(text))
        self.learn()
        learned = self.payload()["data"]["demonstrations"]["learned"]
        self.assertEqual(learned["status"], "author_accepted")
        self.assertEqual(learned["author_acceptance"]["quote"], ACCEPT)
        self.assertIn("fixture://author/comment", json.dumps(learned["author_acceptance"]))

    def test_rejected_or_retired_case_is_immediately_excluded(self):
        self.write_record([case("reject"), case("retire"), case("keep")])
        for case_id, status in (("reject", "rejected"), ("retire", "retired")):
            self.apply("case_status", None, case_id=case_id, status=status,
                       reason="合成测试：不继续作为示范。")
        result = loop.context(self.path, "book", "dialogue_revision", tags=["dialogue"])
        self.assertEqual([c["id"] for c in result["cases"]], ["keep"])

    def test_disabling_loop_preserves_history_and_returns_to_original_workflow(self):
        self.begin()
        history = copy.deepcopy(self.payload()["data"]["learning_runs"])
        self.apply("configure", None, loop_enabled=False)
        state = loop.status(self.path)
        self.assertEqual(state["status"], "disabled")
        self.assertFalse(state["loop_enabled"])
        self.assertEqual(state["next_action"], "resume_original_workflow")
        self.assertEqual(loop.context(self.path, "book", "dialogue_revision")["cases"], [])
        self.assertEqual(self.payload()["data"]["learning_runs"], history)
        self.rejected(self.event("start", "new-run", task="dialogue_revision", tags=[],
            group_id="next-scene", input_text="原写作流程仍可处理的文本", source_ref="fixture://next",
            constraints=[]))

    def test_existing_project_json_keeps_story_and_uses_its_conditional_version(self):
        self.path = Path(self.temp.name) / "story-state.json"
        marker_case = case("literal-markers")
        marker_case["before"] = "正文会谈到字面标记：" + START
        marker_case["after"] = "正文会谈到另一字面标记：" + END
        marker_case["hashes"] = {key: sha(marker_case[key]) for key in ("before", "after")}
        original = {"characters": {"L": {"name": "林", "locked": True}},
                    "settings": {"weather": "雨"}, "chapters": {"2": {"text": "作者定稿"}},
                    "workflow_guard": {"budget": 1}, "author_notes": ["不改正文"],
                    "demonstrations": {"literal-markers": marker_case}}
        project_state.init_state(self.path, "book", original)
        old_version = loop.read_store(self.path)[1]
        self.assertEqual(old_version, project_state.read_state(self.path)["version"])
        self.apply("configure", None, loop_enabled=True, max_revisions=2)
        saved = project_state.read_state(self.path)
        for key, value in original.items():
            self.assertEqual(saved["data"][key], value)
        self.assertLessEqual(set(saved["data"]) - set(original),
                             {"demonstration_learning", "demonstrations", "learning_runs", "learning_events"})
        self.rejected(self.event("configure", None, loop_enabled=False), version=old_version)
        self.assertEqual(loop.read_store(self.path)[1], saved["version"])

    def test_evaluation_requires_exclusion_and_context_queries_are_read_only(self):
        self.write_record([case("current", group="current-scene"), case("safe")])
        before = self.path.read_bytes()
        with self.assertRaises(loop.LoopError):
            loop.context(self.path, "book", "dialogue_revision", evaluation=True)
        selected = loop.context(self.path, "book", "dialogue_revision", tags=["dialogue"],
                                excluded=["current-scene"], evaluation=True)
        self.assertEqual([c["id"] for c in selected["cases"]], ["safe"])
        self.assertEqual(self.path.read_bytes(), before)

    def test_markdown_input_and_review_evidence_can_contain_literal_delimiters(self):
        literal = "原文字面内容：" + START + "，以及" + END + "，还有```。"
        self.apply("start", task="dialogue_revision", tags=["dialogue"],
                   group_id="current-scene", input_text=literal,
                   source_ref="fixture://input/literal-markers", constraints=[])
        self.assertEqual(self.payload()["data"]["learning_runs"]["run"]["input_text"], literal)
        self.apply("plan", applications=[], checks=["保持字面标记原文"])
        self.apply("draft", text=literal, source_ref="fixture://draft/literal-markers",
                   actor={"name": "synthetic-writer", "context_id": "writer-context"})
        self.review("literal-evidence", verdict="revise", findings=[{
            "id": "literal", "issue": "核对字面标记", "evidence": literal, "scope": "整句"}])
        run = self.payload()["data"]["learning_runs"]["run"]
        self.assertEqual(run["input_text"], literal)
        # r5.55: the manuscript is kept once, in drafts; current_draft binds it by hash.
        self.assertEqual(run["drafts"][-1]["text"], literal)
        self.assertEqual(run["current_draft"]["sha256"], sha(literal))
        self.assertEqual(run["reviews"]["literal-evidence"]["findings"][0]["evidence"], literal)

    def test_revision_cannot_drop_a_second_unresolved_or_empty_blocked_review(self):
        for second_verdict in ("revise", "blocked"):
            with self.subTest(second_verdict=second_verdict):
                self.write_record()
                self.begin()
                self.request_revision("A")
                if second_verdict == "revise":
                    self.request_revision("B")
                else:
                    self.review("B", verdict="blocked", findings=[])
                self.adopt("A")
                final = "她按住杯子。‘你先说。’"
                if second_verdict == "revise":
                    parent = self.payload()["data"]["learning_runs"]["run"]["current_draft"]["sha256"]
                    self.rejected(self.event("revise", parent_sha256=parent, text=final,
                        source_ref="fixture://draft/missing-B-decision", review_id="A",
                        actor={"name": "synthetic-writer", "context_id": "writer-context"}))
                    self.adopt("B", decision="defer")
                self.revise(final, review_id="A")
                self.review("partial-recheck", rechecks=["A"])
                self.rejected(self.event("finish", draft_sha256=sha(final)))
                self.review("complete-recheck", rechecks=["A", "B"])
                self.assertEqual(self.finish(final)["status"], "saved")

    def test_teacher_approval_after_a_writer_pass_keeps_the_teacher_source(self):
        text = self.begin()
        self.review("teacher-pass", role="teacher", mode="independent_agent",
                    context_id="teacher-context")
        self.review("writer-pass")
        self.finish(text)
        self.learn()
        learned = self.payload()["data"]["demonstrations"]["learned"]
        self.assertEqual(learned["status"], "teacher_approved")
        self.assertEqual(learned["source"]["supporting_review_id"], "teacher-pass")
        self.assertEqual(learned["source"]["reviewer"], "synthetic-teacher")
        self.assertEqual(learned["source"]["evidence"], "fixture://reviews/teacher-pass")

    def test_later_teacher_revise_cannot_reuse_an_earlier_teacher_pass(self):
        text = self.begin()
        self.review("teacher-old-pass", role="teacher", mode="independent_agent",
                    context_id="teacher-context")
        self.request_revision("teacher-latest-revise")
        self.adopt("teacher-latest-revise", decision="decline")
        self.review("writer-final-pass", rechecks=["teacher-latest-revise"])
        self.finish(text)
        self.learn()
        learned = self.payload()["data"]["demonstrations"]["learned"]
        self.assertEqual(learned["status"], "candidate")
        self.assertEqual(learned["source"]["supporting_review_id"], "writer-final-pass")
        self.assertEqual(learned["source"]["evidence"], "fixture://reviews/writer-final-pass")

    def test_frozen_cases_must_still_be_approved_and_unchanged_at_plan_and_draft(self):
        for phase in ("plan", "draft"):
            for mutation in ("retired", "rejected", "text", "metadata"):
                with self.subTest(phase=phase, mutation=mutation):
                    self.path = Path(self.temp.name) / (phase + "-" + mutation + ".json")
                    item = case("frozen")
                    project_state.init_state(self.path, "book", {
                        "characters": {}, "settings": {}, "chapters": {},
                        "demonstration_learning": {"enabled": True, "loop_enabled": True,
                                                   "max_revisions": 2},
                        "demonstrations": {"frozen": item}})
                    self.begin(plan=False)

                    def application(decision):
                        return {"case_id": "frozen", "decision": decision,
                                "reason": "合成测试：核对已冻结案例的适用性。",
                                "conditions_checked": {item["when"][0]: True},
                                "exceptions_checked": {item["except"][0]: False}}

                    if phase == "draft":
                        self.apply("plan", applications=[application("apply")], checks=["核对案例新鲜性"])
                    if mutation in ("retired", "rejected"):
                        self.apply("case_status", None, case_id="frozen", status=mutation,
                                   reason="合成测试：本案例已停止使用。")
                    else:
                        snapshot = project_state.read_state(self.path)
                        updated = copy.deepcopy(snapshot["data"])
                        changed = updated["demonstrations"]["frozen"]
                        if mutation == "text":
                            changed["after"] += "新版"
                            changed["hashes"]["after"] = sha(changed["after"])
                        else:
                            changed["why"] += "新补的适用依据。"
                        project_state.commit_state(self.path, snapshot["version"], updated)
                    if phase == "plan":
                        for decision in ("apply", "adapt"):
                            self.rejected(self.event("plan", applications=[application(decision)],
                                                     checks=["核对案例新鲜性"]))
                        self.assertEqual(self.apply("plan", applications=[application("decline")],
                                                    checks=["不再使用已变更案例"])["status"], "saved")
                    else:
                        self.rejected(self.event("draft", text="案例已失效时不能继续套用。",
                            source_ref="fixture://draft/stale-case",
                            actor={"name": "synthetic-writer", "context_id": "writer-context"}))
                        self.assertEqual(self.apply("stop", reason="案例已变更，停止并重开本轮。")["status"], "saved")

    def test_holdout_group_sibling_text_cannot_leak_through_another_group(self):
        for copied_field in ("before", "after"):
            with self.subTest(copied_field=copied_field):
                held = case("held", split="holdout", group="held-group")
                sibling = case("sibling", group="held-group")
                duplicate = case("cross-group-copy", group="different-group")
                duplicate["after"] = sibling[copied_field]
                duplicate["hashes"]["after"] = sibling["hashes"][copied_field]
                self.write_record([held, sibling, duplicate, case("safe")])
                selected = loop.context(self.path, "book", "dialogue_revision", tags=["dialogue"])
                self.assertEqual([c["id"] for c in selected["cases"]], ["safe"])

    def test_same_text_revision_requires_a_new_review_instance(self):
        text = self.begin()
        self.request_revision("needs-fix")
        self.adopt("needs-fix")
        self.review("prior-instance-pass", rechecks=["needs-fix"])
        self.revise(text, review_id="needs-fix")
        self.rejected(self.event("finish", draft_sha256=sha(text)))
        self.review("current-instance-pass", rechecks=["needs-fix"])
        self.assertEqual(self.finish(text)["status"], "saved")


class AuthorObjectionTests(LoopFixture):
    """The author's own objection to the current text is not the host's to dismiss."""

    def teacher_pass(self, review_id="teacher-pass", rechecks=None):
        return self.review(review_id, role="teacher", mode="independent_agent",
                           context_id="teacher-context", rechecks=rechecks)

    def withdrawal(self, quote="那句留着吧，不删了。", **fields):
        return {**AUTHOR, "quote": quote, "source_ref": "fixture://author/later", **fields}

    def test_host_cannot_decline_or_defer_the_authors_own_objection(self):
        self.begin()
        self.teacher_pass()
        self.author_review()
        for decision in ("decline", "defer"):
            with self.subTest(decision=decision):
                error = self.rejected(self.decide_event("author-no", decision))
                self.assertEqual(error.code, "author_objection")
        self.assertEqual(self.adopt("author-no")["status"], "saved")

    def test_adopted_author_objection_cannot_finish_on_the_same_text(self):
        text = self.begin()
        self.teacher_pass()
        self.author_review()
        self.adopt("author-no")
        self.review("writer-recheck", rechecks=["author-no"])
        error = self.rejected(self.finish_event(text))
        self.assertEqual(error.code, "author_objection")
        revised = "她按住杯子，没有说话。"
        self.revise(revised, review_id="author-no")
        self.review("writer-new", rechecks=["author-no"])
        self.assertEqual(self.finish(revised)["status"], "saved")
        # r5.55 review: the author has not seen the revised text, so the run is not
        # read as self-checked only either (it was "self_checked" before).
        self.assertEqual(self.run_record()["completion"], "author_objection_open")
        self.learn()
        self.assertEqual(self.payload()["data"]["demonstrations"]["learned"]["status"], "candidate")

    def test_a_revision_that_changes_nothing_is_marked_and_does_not_answer_the_author(self):
        text = self.begin()
        self.teacher_pass()
        self.author_review()
        self.adopt("author-no")
        self.revise(text, review_id="author-no")
        self.assertIs(self.run_record()["drafts"][-1]["unchanged"], True)
        self.teacher_pass("teacher-again", rechecks=["author-no"])
        error = self.rejected(self.finish_event(text))
        self.assertEqual(error.code, "author_objection")
        # The objection still names this text, so a real change may cite it.
        revised = "她按住杯子，没有说话。"
        self.revise(revised, review_id="author-no")
        self.assertNotIn("unchanged", self.run_record()["drafts"][-1])
        self.teacher_pass("teacher-new", rechecks=["author-no"])
        self.assertEqual(self.finish(revised)["status"], "saved")

    def test_only_the_authors_later_words_withdraw_the_objection(self):
        text = self.begin()
        self.teacher_pass()
        self.author_review()
        for fields in ({"actor_role": "teacher"}, {"mode": "independent_agent"}, {"quote": ""}):
            with self.subTest(fields=fields):
                error = self.rejected(self.decide_event(
                    "author-no", "decline", withdrawal=self.withdrawal(**fields)))
                self.assertTrue(error.code)
        self.adopt("author-no", "decline", withdrawal=self.withdrawal())
        kept = self.run_record()["decisions"]["author-no"][0]["withdrawal"]
        self.assertEqual((kept["quote"], kept["ref"]), ("那句留着吧，不删了。", "fixture://author/later"))
        self.review("writer-recheck", rechecks=["author-no"])
        self.assertEqual(self.finish(text)["status"], "saved")
        self.assertEqual(self.run_record()["completion"], "teacher_reviewed")

    def test_withdrawal_words_cannot_be_attached_to_someone_elses_review(self):
        self.begin()
        self.request_revision()
        self.rejected(self.decide_event("needs-fix", "decline", withdrawal=self.withdrawal()))

    def test_author_blocked_without_findings_is_not_passed_over(self):
        text = self.begin()
        self.teacher_pass()
        self.author_review("author-blocked", verdict="blocked", findings=[])
        self.review("writer-pass")
        self.rejected(self.finish_event(text))
        result = self.review("writer-recheck", rechecks=["author-blocked"])
        self.assertEqual(result["next_action"], "ask_author_or_stop")
        self.assertEqual(result["open_author_objections"], ["author-blocked"])
        error = self.rejected(self.finish_event(text))
        self.assertEqual(error.code, "author_objection")
        # Nothing but the author's own later words takes it back.
        self.rejected(self.event("decide", review_id="author-blocked", decisions=[]))
        self.apply("decide", review_id="author-blocked", decisions=[],
                   withdrawal=self.withdrawal("刚才看错了，这版没问题。"))
        self.assertEqual(self.finish(text)["status"], "saved")
        self.assertEqual(self.run_record()["completion"], "teacher_reviewed")

    def test_a_new_author_objection_voids_an_earlier_acceptance_of_the_same_text(self):
        text = self.begin()
        self.review()
        self.send(self.accept_event(text))
        self.assertIn("author_acceptance", self.run_record())
        self.author_review()
        self.assertNotIn("author_acceptance", self.run_record())
        error = self.rejected(self.accept_event(text))
        self.assertEqual(error.code, "author_objection")
        self.adopt("author-no", "decline", withdrawal=self.withdrawal())
        self.assertEqual(self.send(self.accept_event(text))["status"], "saved")

    def test_an_objection_after_the_run_is_finished_takes_its_case_out_of_use(self):
        text = self.begin()
        self.teacher_pass()
        self.finish(text)
        self.learn()
        self.assertEqual(self.payload()["data"]["demonstrations"]["learned"]["status"], "teacher_approved")
        self.assertEqual([c["id"] for c in loop.context(self.path, "book", "dialogue_revision")["cases"]],
                         ["learned"])
        # Only the author's own objection may still be added to a finished run.
        self.rejected(self.event("review", review_id="teacher-late", draft_sha256=sha(text),
            reviewer={"name": "teacher", "role": "teacher", "mode": "independent_agent",
                      "context_id": "teacher-context"}, verdict="revise",
            findings=[{"id": "f1", "issue": "合成", "evidence": "合成", "scope": "合成"}],
            source_ref="fixture://reviews/teacher-late"))
        result = self.author_review()
        self.assertEqual((result["run_status"], result["next_action"]), ("finished", "ask_author_or_stop"))
        self.assertEqual(result["open_author_objections"], ["author-no"])
        selected = loop.context(self.path, "book", "dialogue_revision")
        self.assertEqual(selected["cases"], [])
        self.assertIn("learned", selected["skipped_stale_approvals"])
        self.assertEqual(loop.status(self.path)["stale_approval_case_ids"], ["learned"])
        case_accept = self.event("case_accept", None, case_id="learned", case_sha256=sha(text), quote=ACCEPT,
                                 source_ref="fixture://author/final", **AUTHOR)
        self.assertEqual(self.rejected(case_accept).code, "author_objection")
        # The finished text is not revised in this run: no host decision answers the author here.
        self.assertEqual(self.rejected(self.decide_event("author-no")).code, "invalid_transition")
        self.assertEqual(self.rejected(self.decide_event("author-no", "decline")).code, "author_objection")
        self.adopt("author-no", "decline", withdrawal=self.withdrawal())
        self.assertEqual(self.run_record()["status"], "finished")
        self.assertEqual([c["id"] for c in loop.context(self.path, "book", "dialogue_revision")["cases"]],
                         ["learned"])
        self.assertEqual(self.send(case_accept)["case_status"], "author_accepted")

    def test_an_accepted_case_needs_a_fresh_acceptance_after_the_author_objected(self):
        text = self.begin()
        self.review()
        self.finish(text)
        self.send(self.accept_event(text))
        self.assertEqual(self.learn()["next_action"], "complete")
        self.author_review("author-blocked", verdict="blocked", findings=[])
        result = self.apply("decide", review_id="author-blocked", decisions=[],
                            withdrawal=self.withdrawal("合成：刚才说错了。"))
        # Taking the objection back does not bring back the acceptance it voided.
        self.assertEqual(result["next_action"], "await_author_acceptance")
        self.assertEqual(loop.context(self.path, "book", "dialogue_revision")["cases"], [])
        accept = self.event("case_accept", None, case_id="learned", case_sha256=sha(text), quote=ACCEPT,
                            source_ref="fixture://author/again", **AUTHOR)
        self.assertEqual(self.send(accept)["next_action"], "complete")
        learned = self.payload()["data"]["demonstrations"]["learned"]
        self.assertEqual([item["status"] for item in learned["status_history"]], ["author_accepted"])
        self.assertEqual(learned["status_history"][0]["author_acceptance"]["ref"], "fixture://author/comment")
        self.assertEqual(learned["author_acceptance"]["ref"], "fixture://author/again")
        self.assertEqual([c["id"] for c in loop.context(self.path, "book", "dialogue_revision")["cases"]],
                         ["learned"])
        # A case whose acceptance still stands is not accepted a second time.
        self.rejected(self.event("case_accept", None, case_id="learned", case_sha256=sha(text), quote=ACCEPT,
                                 source_ref="fixture://author/third", **AUTHOR))

    def test_an_acceptance_added_to_a_case_is_also_voided_by_a_later_objection(self):
        text = self.begin()
        self.review()
        self.finish(text)
        self.learn()

        def accept(ref):
            return self.event("case_accept", None, case_id="learned", case_sha256=sha(text), quote=ACCEPT,
                              source_ref=ref, **AUTHOR)

        self.send(accept("fixture://author/first"))
        self.author_review("author-blocked", verdict="blocked", findings=[])
        result = self.apply("decide", review_id="author-blocked", decisions=[],
                            withdrawal=self.withdrawal("合成：留着吧。"))
        self.assertEqual(result["next_action"], "await_author_acceptance")
        learned = self.payload()["data"]["demonstrations"]["learned"]
        self.assertTrue(loop.memory.approval_problems(learned, self.payload()["data"]))
        self.assertEqual(loop.context(self.path, "book", "dialogue_revision")["cases"], [])
        self.assertEqual(self.send(accept("fixture://author/again"))["next_action"], "complete")
        self.assertEqual([c["id"] for c in loop.context(self.path, "book", "dialogue_revision")["cases"]],
                         ["learned"])

    def test_an_objection_before_learning_leaves_only_a_candidate(self):
        text = self.begin()
        self.teacher_pass()
        self.finish(text)
        self.author_review("author-blocked", verdict="blocked", findings=[])
        self.assertEqual(self.rejected(self.accept_event(text)).code, "author_objection")
        self.learn()
        learned = self.payload()["data"]["demonstrations"]["learned"]
        self.assertEqual(learned["status"], "candidate")
        self.assertEqual(learned["source"]["open_author_objections"], ["author-blocked"])

    def host_change_after_author_blocked(self):
        """The author rejects the whole draft; the host routes a small change
        through its own finding and a teacher passes the new text."""
        self.begin()
        self.author_review("author-blocked", verdict="blocked", findings=[])
        self.review("host-note", verdict="revise", findings=[
            {"id": "f1", "issue": "合成：换个标点", "evidence": "‘你先说。’", "scope": "第二句"}])
        self.adopt("host-note")
        revised = "她把杯子推回来。‘你先说！’"
        self.revise(revised, review_id="host-note")
        return revised

    def test_an_unanswered_author_objection_follows_the_text_revised_from_it(self):
        revised = self.host_change_after_author_blocked()
        result = self.teacher_pass("teacher-new", rechecks=["author-blocked", "host-note"])
        self.assertEqual(result["earlier_author_objections"], ["author-blocked"])
        self.assertEqual(self.finish(revised)["status"], "saved")
        self.assertNotEqual(self.run_record()["completion"], "teacher_reviewed")
        self.learn()
        learned = self.payload()["data"]["demonstrations"]["learned"]
        self.assertEqual(learned["status"], "candidate")
        self.assertEqual(learned["source"]["earlier_author_objections"], ["author-blocked"])
        self.assertEqual(loop.context(self.path, "book", "dialogue_revision")["cases"], [])
        # A teacher-approved case of the same text (an older script could make one) is not used either.
        older = {**copy.deepcopy(learned), "status": "teacher_approved"}
        self.assertTrue(any("earlier version" in problem
                            for problem in loop.memory.approval_problems(older, self.payload()["data"])))
        # The author's own acceptance of the new text answers it.
        accept = self.event("case_accept", None, case_id="learned", case_sha256=sha(revised), quote=ACCEPT,
                            source_ref="fixture://author/new-text", **AUTHOR)
        self.assertEqual(self.send(accept)["case_status"], "author_accepted")
        self.assertEqual([c["id"] for c in loop.context(self.path, "book", "dialogue_revision")["cases"]],
                         ["learned"])

    def test_the_authors_pass_on_the_new_text_answers_an_earlier_objection(self):
        revised = self.host_change_after_author_blocked()
        self.review("author-ok", role="author", mode="human", context_id="author-context",
                    rechecks=["author-blocked", "host-note"])
        result = self.teacher_pass("teacher-new", rechecks=["author-blocked", "host-note"])
        self.assertNotIn("earlier_author_objections", result)
        self.finish(revised)
        self.assertEqual(self.run_record()["completion"], "teacher_reviewed")
        self.learn()
        self.assertEqual(self.payload()["data"]["demonstrations"]["learned"]["status"], "teacher_approved")

    def test_a_new_run_from_a_text_the_author_rejected_carries_the_objection(self):
        text = self.begin()
        self.teacher_pass()
        self.finish(text)
        self.author_review("author-blocked", verdict="blocked", findings=[])
        self.apply("start", "again", task="dialogue_revision", tags=["dialogue"], group_id="current-scene",
                   input_text=text, source_ref="fixture://input/rejected", constraints=[])
        self.apply("plan", "again", applications=[], checks=["合成"])
        changed = "她把杯子推回来，没有开口。"
        self.apply("draft", "again", text=changed, source_ref="fixture://draft/again",
                   actor={"name": "synthetic-writer", "context_id": "writer-context"})
        result = self.review("teacher-again", role="teacher", mode="independent_agent",
                             context_id="teacher-context", run_id="again")
        self.assertEqual(result["earlier_author_objections"], ["run/author-blocked"])
        self.send(self.event("finish", "again", draft_sha256=sha(changed)))
        self.assertNotEqual(self.run_record("again")["completion"], "teacher_reviewed")
        self.send(self.event("learn", "again", case_id="again-case", why="合成。", when=["合成条件"],
                             **{"except": []}, decisions=["合成取舍"]))
        self.assertEqual(self.payload()["data"]["demonstrations"]["again-case"]["status"], "candidate")

    def test_blocked_teacher_review_without_findings_needs_a_bound_recheck(self):
        text = self.begin()
        self.review("teacher-blocked", verdict="blocked", findings=[], role="teacher",
                    mode="independent_agent", context_id="teacher-context")
        self.review("writer-pass")
        self.rejected(self.finish_event(text))
        self.review("writer-recheck", rechecks=["teacher-blocked"])
        self.assertEqual(self.finish(text)["status"], "saved")
        self.assertEqual(self.run_record()["completion"], "self_checked")


class AuthorAcceptanceTests(LoopFixture):
    def test_author_accept_must_be_the_author_in_person(self):
        text = self.begin()
        self.review()
        self.finish(text)
        for fields in ({"actor_role": None, "mode": None},
                       {"actor_role": "teacher", "mode": "independent_agent"},
                       {"actor_role": "teacher"}, {"mode": "independent_agent"}):
            with self.subTest(fields=fields):
                event = self.accept_event(text, **fields)
                event = {key: value for key, value in event.items() if value is not None}
                self.assertEqual(self.rejected(event).code, "author_evidence")
        self.assertNotIn("author_acceptance", self.run_record())

    def test_progress_words_are_not_author_acceptance(self):
        text = self.begin()
        self.review()
        self.finish(text)
        error = self.rejected(self.accept_event(text, quote="继续。"))
        self.assertEqual(error.code, "not_an_acceptance")
        self.assertEqual(self.send(self.accept_event(text))["status"], "saved")

    def test_one_case_per_finished_run_and_the_next_step_moves_on(self):
        text = self.begin()
        self.review()
        self.finish(text)
        first = self.learn("first")
        self.assertEqual(first["next_action"], "await_author_acceptance")
        error = self.rejected(self.learn_event("second"))
        self.assertIn("first", str(error))
        # A retired case no longer stands for this run's draft.
        self.apply("case_status", None, case_id="first", status="retired", reason="合成：条件写错了。")
        self.assertEqual(self.learn("second")["status"], "saved")

    def test_case_accept_adds_the_authors_later_acceptance_to_an_existing_case(self):
        text = self.begin()
        self.review()
        self.finish(text)
        self.learn("first")
        self.assertEqual(self.payload()["data"]["demonstrations"]["first"]["status"], "candidate")
        self.assertEqual(loop.context(self.path, "book", "dialogue_revision", tags=["dialogue"])["cases"], [])

        def accept(**fields):
            values = {"case_id": "first", "case_sha256": sha(text), "quote": ACCEPT,
                      "source_ref": "fixture://author/final", **AUTHOR, **fields}
            return self.event("case_accept", None, **values)

        # Once the case exists, the acceptance belongs on the case, not on the run alone.
        self.assertIn("case_accept", str(self.rejected(self.accept_event(text))))
        self.rejected(accept(case_sha256=sha("别的文字")))
        self.assertEqual(self.rejected(accept(quote="继续。")).code, "not_an_acceptance")
        self.assertEqual(self.rejected(accept(actor_role="teacher")).code, "author_evidence")
        event = accept()
        result = self.send(event)
        self.assertEqual(result["next_action"], "complete")
        learned = self.payload()["data"]["demonstrations"]["first"]
        self.assertEqual(learned["status"], "author_accepted")
        self.assertEqual(learned["author_acceptance"],
                         {"quote": ACCEPT, "ref": "fixture://author/final",
                          "draft_sha256": sha(text), "event_id": event["event_id"], "run_review_count": 1})
        self.assertEqual(learned["status_history"][0]["status"], "candidate")
        self.assertEqual(loop.memory.approval_problems(learned, self.payload()["data"]), [])
        selected = loop.context(self.path, "book", "dialogue_revision", tags=["dialogue"])
        self.assertEqual([c["id"] for c in selected["cases"]], ["first"])
        self.rejected(accept())

    def test_learn_records_who_reviewed_how_and_every_review_of_the_run(self):
        self.begin()
        self.request_revision()
        self.adopt()
        final = "她按住杯子。‘你先说。’"
        self.revise(final)
        self.review("teacher-final", role="teacher", mode="independent_agent",
                    context_id="teacher-context", rechecks=["needs-fix"])
        self.finish(final)
        self.learn()
        source = self.payload()["data"]["demonstrations"]["learned"]["source"]
        self.assertEqual((source["reviewer_role"], source["reviewer_mode"]), ("teacher", "independent_agent"))
        self.assertEqual(source["run_review_ids"], ["needs-fix", "teacher-final"])

    def test_author_return_is_a_teacher_result_carried_back_by_the_author(self):
        text = self.begin()
        self.rejected(self.event("review", review_id="not-a-teacher", draft_sha256=sha(text),
            reviewer={"name": "writer", "role": "writer", "mode": "author_return",
                      "context_id": "outside-workshop"}, verdict="pass", findings=[],
            source_ref="fixture://reviews/not-a-teacher"))
        self.review("carried-back", role="teacher", mode="author_return", context_id="outside-workshop")
        self.finish(text)
        self.learn()
        learned = self.payload()["data"]["demonstrations"]["learned"]
        self.assertEqual(learned["status"], "teacher_approved")
        self.assertEqual(learned["source"]["reviewer_mode"], "author_return")


class DecisionRecordTests(LoopFixture):
    def test_decisions_can_be_replaced_before_revision_and_the_old_ones_stay(self):
        self.begin()
        self.request_revision()
        self.adopt()
        replaced = self.adopt(decision="defer")
        self.assertEqual(replaced["deferred"], [{"review_id": "needs-fix", "finding_id": "f1"}])
        run = self.run_record()
        self.assertEqual(run["decisions"]["needs-fix"][0]["decision"], "defer")
        self.assertEqual(run["decision_history"]["needs-fix"][0]["decisions"][0]["decision"], "adopt")
        self.adopt()
        self.assertEqual(len(self.run_record()["decision_history"]["needs-fix"]), 2)
        self.revise()
        # Once the draft has been revised on it, the old review is history.
        self.rejected(self.decide_event())

    def test_enabled_switch_is_named_and_needs_the_authors_words_to_turn_on(self):
        self.path = Path(self.temp.name) / "state.json"
        project_state.init_state(self.path, "book", {"characters": {}, "settings": {}, "chapters": {}})
        result = self.apply("configure", None, loop_enabled=True)
        self.assertIn("demonstration_learning.enabled", result["blocked_by"])
        state = loop.status(self.path)
        self.assertEqual((state["status"], state["missing_switches"]), ("disabled", ["enabled"]))
        start = self.event("start", task="dialogue_revision", tags=[], group_id="scene",
                           input_text="合成输入", source_ref="fixture://input", constraints=[])
        self.assertIn("demonstration_learning.enabled", str(self.rejected(start)))
        self.assertEqual(self.rejected(self.event("configure", None, loop_enabled=True, enabled=True)).code,
                         "author_evidence")
        self.apply("configure", None, loop_enabled=True, enabled=True, quote="这本书开始记示范。",
                   source_ref="fixture://author/enable", **AUTHOR)
        self.assertEqual(loop.status(self.path)["status"], "enabled")
        self.assertEqual(self.send(start)["status"], "saved")


class ContextListingTests(LoopFixture):
    def test_more_than_three_approved_cases_are_listed_and_can_be_named(self):
        self.write_record([case("A" + str(number)) for number in range(1, 6)])
        result = loop.context(self.path, "book", "dialogue_revision", tags=["dialogue"])
        self.assertEqual([c["id"] for c in result["cases"]], ["A1", "A2", "A3"])
        self.assertEqual(result["not_selected"], ["A4", "A5"])
        self.assertEqual(result["eligible_count"], 5)
        self.assertTrue(all(c["when"] and "except" in c for c in result["cases"]))
        self.assertIn("when", result["applicability"])
        named = loop.context(self.path, "book", "dialogue_revision", tags=["dialogue"], case_ids=["A5"])
        self.assertEqual([c["id"] for c in named["cases"]], ["A5"])
        self.assertEqual(named["not_selected"], ["A1", "A2", "A3", "A4"])
        with self.assertRaises(loop.LoopError):
            loop.context(self.path, "book", "dialogue_revision", tags=["dialogue"],
                         case_ids=["A1", "A2", "A3", "A4"])

        def start(run_id, case_ids):
            return self.event("start", run_id, task="dialogue_revision", tags=["dialogue"],
                              group_id="current-scene", input_text="合成输入",
                              source_ref="fixture://input", constraints=[], case_ids=case_ids)

        self.rejected(start("unknown", ["no-such-case"]))
        self.rejected(start("too-many", ["A1", "A2", "A3", "A4"]))
        self.send(start("run", ["A5", "A4"]))
        self.assertEqual([c["id"] for c in self.run_record()["selected_cases"]], ["A4", "A5"])

    def test_a_case_whose_approval_binds_another_text_is_left_out_and_reported(self):
        stale = case("stale", status="author_accepted")
        stale["author_acceptance"] = {"quote": "合成认可", "ref": "fixture://author",
                                      "draft_sha256": sha("认可时的旧文字")}
        self.write_record([stale, case("fresh")])
        result = loop.context(self.path, "book", "dialogue_revision", tags=["dialogue"])
        self.assertEqual([c["id"] for c in result["cases"]], ["fresh"])
        self.assertIn("stale", result["skipped_stale_approvals"])
        self.assertEqual(loop.status(self.path)["stale_approval_case_ids"], ["stale"])


class RecordSizeTests(LoopFixture):
    def test_manuscript_text_is_kept_once_per_draft_and_retries_still_match(self):
        original, first, final = ("合成输入" + "甲" * 300, "合成初稿" + "乙" * 300, "合成改稿" + "丙" * 300)
        self.apply("start", task="dialogue_revision", tags=["dialogue"], group_id="current-scene",
                   input_text=original, source_ref="fixture://input", constraints=[])
        self.apply("plan", applications=[], checks=["合成核查项"])
        self.apply("draft", text=first, source_ref="fixture://draft/v1",
                   actor={"name": "synthetic-writer", "context_id": "writer-context"})
        self.request_revision()
        self.adopt()
        old_version = loop.read_store(self.path)[1]
        revise = self.revise_event(final)
        self.send(revise, version=old_version)
        raw = self.path.read_text(encoding="utf-8")
        self.assertEqual([raw.count(text) for text in (original, first, final)], [1, 1, 1])
        run = self.run_record()
        self.assertNotIn("text", run["current_draft"])
        self.assertEqual(run["current_draft"]["sha256"], sha(final))
        kept = self.payload()["data"]["learning_events"][revise["event_id"]]["event"]
        self.assertEqual(kept["text"], {"sha256": sha(final), "chars": len(final)})
        self.assertEqual(kept["parent_sha256"], sha(first))
        # A lost-response retry still carries the full text and is recognized.
        self.assertEqual(self.send(copy.deepcopy(revise), version=old_version)["status"], "unchanged")
        self.rejected({**revise, "text": final + "换了内容"})
        self.review("teacher-final", role="teacher", mode="independent_agent",
                    context_id="teacher-context", rechecks=["needs-fix"])
        self.finish(final)
        self.learn()
        learned = self.payload()["data"]["demonstrations"]["learned"]
        self.assertEqual((learned["before"], learned["after"]), (original, final))
        raw = self.path.read_text(encoding="utf-8")
        self.assertEqual([raw.count(text) for text in (original, first, final)], [2, 1, 2])

    def test_a_selected_example_is_frozen_by_hash_not_copied_again(self):
        self.begin()
        self.request_revision()
        self.adopt()
        final = "合成改稿：" + "丁" * 300
        self.revise(final)
        self.review("teacher-final", role="teacher", mode="independent_agent",
                    context_id="teacher-context", rechecks=["needs-fix"])
        self.finish(final)
        self.learn()
        before = self.path.read_text(encoding="utf-8").count(final)
        self.apply("start", "next", task="dialogue_revision", tags=["dialogue"], group_id="next-scene",
                   input_text="合成下一轮输入", source_ref="fixture://input/next", constraints=[])
        self.assertEqual(self.path.read_text(encoding="utf-8").count(final), before)
        frozen = self.run_record("next")["selected_cases"][0]
        self.assertEqual(frozen["after"], {"sha256": sha(final), "chars": len(final)})
        self.assertEqual(frozen["when"], ["需要让对白与动作互相承接"])
        # The live case is still bound by the frozen hash, so it can be applied.
        self.apply("plan", "next", applications=[{
            "case_id": "learned", "decision": "apply", "reason": "合成：本场也要动作和回应相接。",
            "conditions_checked": {"需要让对白与动作互相承接": True},
            "exceptions_checked": {"刻意表现答非所问": False}}], checks=["合成核查项"])
        self.assertEqual(self.apply("draft", "next", text="合成下一轮稿", source_ref="fixture://draft/next",
                                    actor={"name": "synthetic-writer", "context_id": "writer-context"})["status"],
                         "saved")

    def test_show_brief_leaves_manuscript_text_out(self):
        text = self.begin()

        def show(*options):
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                self.assertEqual(loop.main(["show", str(self.path), "--run-id", "run", *options]), 0)
            return output.getvalue()

        self.assertIn(text, show())
        brief = show("--brief")
        self.assertNotIn(text, brief)
        self.assertIn(sha(text), brief)
        self.assertEqual(json.loads(brief)["next_action"], "review")


class ChapterFlowFixture(LoopFixture):
    """Drives the real chapter gate in the same record; every word is synthetic."""
    CHAPTER = "chapter-1"
    DRAFT = "合成初稿：她把杯子推回来。‘你先说。’"
    REVISED = "合成修订稿：她按住杯子。‘你先说。’"

    def gate(self, action, stage=None, **fields):
        self.serial += 1
        event = {"event_id": "gate-" + str(self.serial), "op": "chapter_gate", "action": action, **fields}
        if action != "configure":
            event["chapter_id"] = self.CHAPTER
        if stage is not None:
            event["stage"] = stage
        return self.send(event)

    def policy(self, handoff):
        return self.gate("configure", visual_required=False, teacher_handoff=handoff,
                         author_quote="合成：每章都按这个办法走。", source_ref="fixture://author/policy", **AUTHOR)

    def present(self, stage, artifact=None, **fields):
        values = {"content": "合成阶段成果：" + stage + "。" + "述" * 120,
                  "source_ref": "fixture://gate/" + stage, **fields}
        if artifact is not None:
            values["artifact_sha256"] = artifact
        return self.gate("present", stage, **values)

    def confirm(self, shown, stage, quote="确认，这一阶段成立。"):
        extra = {"decision": "accept_final_version"} if stage == "final" else {}
        return self.gate("confirm", stage, presentation_id=shown["presentation_id"],
                         presentation_version=shown["presentation_version"], author_quote=quote,
                         source_ref="fixture://author/" + stage, **AUTHOR, **extra)

    def through_draft(self):
        for stage in ("scope", "outline", "preparation"):
            self.confirm(self.present(stage), stage)
        shown = self.present("draft", sha(self.DRAFT))
        self.confirm(shown, "draft")
        return shown

    def teacher_return(self, draft_shown):
        return self.gate("teacher_return", draft_presentation_id=draft_shown["presentation_id"],
                         draft_presentation_version=draft_shown["presentation_version"],
                         draft_sha256=draft_shown["artifact_sha256"],
                         returned_text="合成教师回传：第二句没有接住动作。" + "评" * 120,
                         source_ref="fixture://teacher/return", teacher_name="合成教师")

    def through_final(self, artifact):
        shown = self.present("revision", artifact)
        self.confirm(shown, "revision")
        shown = self.present("final", artifact)
        return self.confirm(shown, "final", quote=ACCEPT)

    def chapter_run(self, run_id="run", chapter=True):
        fields = {"chapter_id": self.CHAPTER} if chapter else {}
        started = self.apply("start", run_id, task="chapter_revision", tags=[], group_id="group-" + run_id,
                             input_text=self.DRAFT, source_ref="fixture://gate/draft", constraints=[], **fields)
        self.apply("plan", run_id, applications=[], checks=["合成核查项"])
        self.apply("draft", run_id, text=self.DRAFT, source_ref="fixture://gate/draft",
                   actor={"name": "synthetic-writer", "context_id": "writer-context"})
        return started

    def teacher_review(self, review_id="teacher-1", **extra):
        return self.review(review_id, verdict="revise", findings=[{
            "id": "f1", "issue": "回应没有接住动作", "evidence": "她没有碰杯子", "scope": "第二句"}],
            role="teacher", mode="author_return", context_id="outside-workshop", **extra)


class ChapterLinkTests(ChapterFlowFixture):
    def test_decisions_wait_for_the_confirmed_plan_when_the_author_carries_the_draft_to_the_teacher(self):
        self.policy("user_return")
        returned = self.teacher_return(self.through_draft())
        plan = self.present("review", teacher_return_id=returned["teacher_return_id"])
        self.assertEqual(self.chapter_run()["chapter_link"], self.CHAPTER)
        self.rejected(self.event("review", review_id="wrong-return", draft_sha256=sha(self.DRAFT),
            reviewer={"name": "teacher", "role": "teacher", "mode": "author_return",
                      "context_id": "outside-workshop"}, verdict="pass", findings=[],
            source_ref="fixture://reviews/wrong-return", teacher_return_id="no-such-return"))
        reviewed = self.teacher_review(teacher_return_id=returned["teacher_return_id"])
        self.assertEqual(reviewed["next_action"], "await_author_plan_confirmation")
        self.assertEqual(self.run_record()["reviews"]["teacher-1"]["teacher_return_id"],
                         returned["teacher_return_id"])
        error = self.rejected(self.decide_event("teacher-1"))
        self.assertEqual(error.code, "chapter_gate_first")
        self.confirm(plan, "review")
        self.assertEqual(self.adopt("teacher-1")["next_action"], "revise_or_stop")
        bound = self.run_record()["decision_plans"]["teacher-1"]
        self.assertEqual((bound["presentation_id"], bound["presentation_version"]),
                         (plan["presentation_id"], plan["presentation_version"]))
        self.assertEqual(self.revise(self.REVISED, review_id="teacher-1")["status"], "saved")

    def test_reopening_the_plan_stops_revision_on_the_old_decisions(self):
        self.policy("user_return")
        returned = self.teacher_return(self.through_draft())
        self.confirm(self.present("review", teacher_return_id=returned["teacher_return_id"]), "review")
        self.chapter_run()
        self.teacher_review()
        self.adopt("teacher-1")
        self.gate("reopen", "review", reason="合成：作者要重看方案。", author_quote="方案我再看一遍，先别改。",
                  source_ref="fixture://author/reopen", **AUTHOR)
        error = self.rejected(self.revise_event(self.REVISED, review_id="teacher-1"))
        self.assertEqual(error.code, "chapter_gate_first")
        self.assertEqual(self.rejected(self.decide_event("teacher-1", "decline")).code, "chapter_gate_first")

    def test_a_plan_confirmed_for_another_draft_does_not_cover_this_run(self):
        # A run can no longer start from a text other than the confirmed draft (see the
        # next test), so the other draft here is the one confirmed after a reopen.
        self.policy("user_return")
        returned = self.teacher_return(self.through_draft())
        self.confirm(self.present("review", teacher_return_id=returned["teacher_return_id"]), "review")
        self.chapter_run()
        self.teacher_review()
        self.gate("reopen", "draft", reason="合成：作者改了初稿。", author_quote="初稿我自己再改一遍。",
                  source_ref="fixture://author/reopen-draft", **AUTHOR)
        newer = "合成新初稿：她没有接杯子。"
        shown = self.present("draft", sha(newer))
        self.confirm(shown, "draft", quote="新的初稿就这样。")
        returned = self.teacher_return(shown)
        plan = self.present("review", teacher_return_id=returned["teacher_return_id"])
        self.confirm(plan, "review", quote="新方案可以。")
        self.assertEqual(self.rejected(self.decide_event("teacher-1")).code, "chapter_gate_first")

    def test_a_chapter_run_starts_from_the_author_confirmed_draft(self):
        self.policy("host")
        for stage in ("scope", "outline", "preparation"):
            self.confirm(self.present(stage), stage)
        shown = self.present("draft", sha(self.DRAFT))

        def start(run_id, text):
            return self.event("start", run_id, task="chapter_revision", tags=[], group_id="group-" + run_id,
                              input_text=text, source_ref="fixture://gate/draft", constraints=[],
                              chapter_id=self.CHAPTER)

        self.assertEqual(self.rejected(start("early", self.DRAFT)).code, "chapter_gate_first")
        self.confirm(shown, "draft")
        self.assertEqual(self.rejected(start("task", "合成：第一章任务说明。")).code, "chapter_gate_first")
        self.assertEqual(self.send(start("run", self.DRAFT))["chapter_link"], self.CHAPTER)
        self.apply("plan", applications=[], checks=["合成核查项"])
        actor = {"name": "synthetic-writer", "context_id": "writer-context"}
        self.rejected(self.event("draft", text="合成：另写的一稿。", source_ref="fixture://draft", actor=actor))
        self.assertEqual(self.apply("draft", text=self.DRAFT, source_ref="fixture://draft", actor=actor)["status"],
                         "saved")

    def test_a_second_round_starts_from_the_last_final_text_of_the_same_draft(self):
        self.policy("user_return")
        returned = self.teacher_return(self.through_draft())
        self.confirm(self.present("review", teacher_return_id=returned["teacher_return_id"]), "review")
        self.chapter_run()
        self.teacher_review()
        self.adopt("teacher-1")
        self.revise(self.REVISED, review_id="teacher-1")
        self.review("writer-recheck", rechecks=["teacher-1"])
        self.finish(self.REVISED)

        def start(run_id, text):
            return self.event("start", run_id, task="chapter_revision", tags=[], group_id="group-" + run_id,
                              input_text=text, source_ref="fixture://run/final", constraints=[],
                              chapter_id=self.CHAPTER)

        self.assertEqual(self.rejected(start("stray", "合成：哪一轮都没有的文字。")).code, "chapter_gate_first")
        self.assertEqual(self.send(start("second", self.REVISED))["chapter_link"], self.CHAPTER)
        self.apply("plan", "second", applications=[], checks=["合成核查项"])
        self.apply("draft", "second", text=self.REVISED, source_ref="fixture://run/final",
                   actor={"name": "synthetic-writer", "context_id": "writer-context"})
        self.review("author-no", run_id="second", verdict="revise", role="author", mode="human",
                    context_id="author-context",
                    findings=[{"id": "f1", "issue": "合成：这句不要", "evidence": "按住杯子", "scope": "第一句"}])
        # The confirmed plan of the draft this round descends from still covers it.
        self.assertEqual(self.send(self.event("decide", "second", review_id="author-no", decisions=[
            {"finding_id": "f1", "decision": "adopt", "reason": "照作者说的删。"}]))["status"], "saved")
        # Once the author has a new confirmed draft, the old line no longer starts a round.
        self.gate("reopen", "draft", reason="合成：作者重写初稿。", author_quote="初稿我重写了。",
                  source_ref="fixture://author/reopen-draft", **AUTHOR)
        newer = "合成新初稿：她没有接杯子。"
        self.confirm(self.present("draft", sha(newer)), "draft", quote="新初稿就这样。")
        self.assertEqual(self.rejected(start("third", self.REVISED)).code, "chapter_gate_first")

    def test_a_chapter_id_without_any_chapter_gate_is_not_linked(self):
        started = self.chapter_run()
        self.assertEqual(started["chapter_link"], "not_linked")
        self.teacher_review()
        self.assertEqual(self.adopt("teacher-1")["status"], "saved")
        self.write_record()
        self.apply("start", task="chapter_revision", tags=[], group_id="group-run", input_text=self.DRAFT,
                   source_ref="fixture://gate/draft", constraints=[], chapter_id=self.CHAPTER)
        self.apply("plan", applications=[], checks=["合成核查项"])
        # Still a chapter run: its first draft is the text it started from.
        self.rejected(self.event("draft", text="合成：另写的一稿。", source_ref="fixture://draft",
                                 actor={"name": "synthetic-writer", "context_id": "writer-context"}))

    def test_host_teacher_handoff_and_unlinked_runs_are_not_gated(self):
        for handoff, chapter in (("host", True), ("user_return", False)):
            with self.subTest(handoff=handoff, chapter=chapter):
                self.write_record()
                self.policy(handoff)
                self.through_draft()  # the review stage has not even been shown
                started = self.chapter_run(chapter=chapter)
                self.assertEqual(started["chapter_link"], self.CHAPTER if chapter else "not_linked")
                self.teacher_review()
                self.assertEqual(self.adopt("teacher-1")["status"], "saved")
                self.assertEqual(self.revise(self.REVISED, review_id="teacher-1")["status"], "saved")

    def test_author_accept_on_a_chapter_run_waits_for_the_final_acceptance_of_the_same_draft(self):
        self.policy("host")
        self.through_draft()
        plan = self.present("review")
        self.chapter_run()
        self.chapter_run("free", chapter=False)
        self.review()
        self.finish(self.DRAFT)
        error = self.rejected(self.accept_event(self.DRAFT))
        self.assertEqual(error.code, "chapter_gate_first")
        # A run that names no chapter stays outside the chapter gate.
        self.review("free-review", run_id="free")
        self.assertEqual(self.send({**self.accept_event(self.DRAFT), "run_id": "free"})["status"], "saved")
        self.confirm(plan, "review")
        self.through_final(sha(self.DRAFT))
        self.assertEqual(self.send(self.accept_event(self.DRAFT))["status"], "saved")
        self.learn()
        self.assertEqual(self.payload()["data"]["demonstrations"]["learned"]["status"], "author_accepted")

    def test_final_acceptance_of_another_text_does_not_reach_this_run_or_its_case(self):
        self.policy("host")
        self.through_draft()
        self.confirm(self.present("review"), "review")
        self.chapter_run()
        self.review()
        self.finish(self.DRAFT)
        self.learn("chapter-case")
        self.through_final(sha("合成：作者最后采纳的是另一份文字。"))
        self.assertEqual(self.rejected(self.accept_event(self.DRAFT)).code, "chapter_gate_first")
        event = self.event("case_accept", None, case_id="chapter-case", case_sha256=sha(self.DRAFT),
                           quote=ACCEPT, source_ref="fixture://author/final", **AUTHOR)
        self.assertEqual(self.rejected(event).code, "chapter_gate_first")

    def test_case_accept_follows_the_chapter_final_when_learning_came_first(self):
        self.policy("host")
        self.through_draft()
        self.confirm(self.present("review"), "review")
        self.chapter_run()
        self.review()
        self.finish(self.DRAFT)
        self.learn("chapter-case")
        event = self.event("case_accept", None, case_id="chapter-case", case_sha256=sha(self.DRAFT),
                           quote=ACCEPT, source_ref="fixture://author/final", **AUTHOR)
        self.assertEqual(self.rejected(event).code, "chapter_gate_first")
        self.through_final(sha(self.DRAFT))
        self.assertEqual(self.send(event)["case_status"], "author_accepted")
        source = self.payload()["data"]["demonstrations"]["chapter-case"]["source"]
        self.assertEqual(source["chapter_id"], self.CHAPTER)

    def test_chapter_stage_and_teacher_return_bodies_are_kept_once(self):
        self.policy("user_return")
        returned = self.teacher_return(self.through_draft())
        self.present("review", teacher_return_id=returned["teacher_return_id"])
        raw = self.path.read_text(encoding="utf-8")
        data = self.payload()["data"]
        chapter = data["chapter_confirmations"][self.CHAPTER]
        self.assertEqual(raw.count(chapter["teacher_returns"][0]["returned_text"]), 1)
        for item in chapter["history"]:
            self.assertEqual(raw.count(item["content"]), 1, item["stage"])
        kept = data["learning_events"][returned["teacher_return_id"]]["event"]
        self.assertEqual(kept["returned_text"]["sha256"], returned["returned_sha256"])
        self.assertEqual(kept["teacher_name"], "合成教师")


LEGACY_STORE = json.loads(
    '{"chapters":{},"characters":{},"demonstration_learning":{"enabled":true,"loop_enabled":true,"max_revisio'
    'ns":2},"demonstrations":{"old-case":{"after":"合成旧稿：她把伞收起来，说了句好。","author_acceptance":{"draft_sha256":"79'
    '5dc7ff7911d86a37e01c2f08f54d40427df1b93cbe3121559eaa90a4bef876","quote":"保留这版。","ref":"fixture://old/aut'
    'hor"},"before":"合成旧输入：他递过伞。","decisions":["合成取舍。"],"except":[],"group_id":"old-scene-1","hashes":{"after'
    '":"795dc7ff7911d86a37e01c2f08f54d40427df1b93cbe3121559eaa90a4bef876","before":"c56cf49de407ef18efd949915'
    'c62e8b6c63f055bfea215b6dadc47cc0236053b"},"id":"old-case","project_id":"book","source":{"draft_ref":"fix'
    'ture://old/draft-1","draft_sha256":"795dc7ff7911d86a37e01c2f08f54d40427df1b93cbe3121559eaa90a4bef876","e'
    'vidence":"fixture://old/review-1","input_ref":"fixture://old/input-1","ref":"fixture://old/draft-1","rev'
    'iew_ids":["old-teacher"],"reviewer":"synthetic-teacher","run_id":"done","supporting_review_id":"old-teac'
    'her","version":"795dc7ff7911d86a37e01c2f08f54d40427df1b93cbe3121559eaa90a4bef876"},"split":"development"'
    ',"status":"author_accepted","tags":["dialogue"],"task":"dialogue_revision","when":["合成条件"],"why":"合成依据。"'
    '}},"learning_events":{"old-13":{"event":{"actor":{"context_id":"writer-context","name":"synthetic-writer'
    '"},"event_id":"old-13","op":"revise","parent_sha256":"b1044be95bec5822fbd5164b52becf0631ca2c8da854869e9f'
    '3dd7fdeb377b65","review_id":"old-needs-fix","run_id":"open","source_ref":"fixture://old/draft-2b","text"'
    ':"合成旧稿二改：他把门带上，没有回头。"},"op":"revise","payload_sha256":"e47c6ae7e8fa5e38d460e330057973b39022e9ad9cdd34190'
    '08f3e33576f7861","result":{"draft_sha256":"3f40f8b23882e292738e9bb910ea35a17a6d8c078ecf3883b6af458af1c0f'
    'f01","next_action":"review","run_id":"open","run_status":"drafted"},"run_id":"open"},"old-3":{"event":{"'
    'actor":{"context_id":"writer-context","name":"synthetic-writer"},"event_id":"old-3","op":"draft","run_id'
    '":"done","source_ref":"fixture://old/draft-1","text":"合成旧稿：她把伞收起来，说了句好。"},"op":"draft","payload_sha256":'
    '"9f51545af9d89aad05f163d13ab0364eccb8eeb29196211c4c821dee9930b09e","result":{"draft_sha256":"795dc7ff791'
    '1d86a37e01c2f08f54d40427df1b93cbe3121559eaa90a4bef876","next_action":"review","run_id":"done","run_statu'
    's":"drafted"},"run_id":"done"},"old-6":{"event":{"draft_sha256":"795dc7ff7911d86a37e01c2f08f54d40427df1b'
    '93cbe3121559eaa90a4bef876","event_id":"old-6","op":"author_accept","quote":"保留这版。","run_id":"done","sour'
    'ce_ref":"fixture://old/author"},"op":"author_accept","payload_sha256":"14f05a8cd3c29deefba557f7b62a79ed6'
    '27af141d20e229088acde2581ee42d2","result":{"draft_sha256":"795dc7ff7911d86a37e01c2f08f54d40427df1b93cbe3'
    '121559eaa90a4bef876","next_action":"learn","run_id":"done","run_status":"finished"},"run_id":"done"}},"l'
    'earning_runs":{"done":{"applications":[],"author_acceptance":{"draft_sha256":"795dc7ff7911d86a37e01c2f08'
    'f54d40427df1b93cbe3121559eaa90a4bef876","quote":"保留这版。","ref":"fixture://old/author"},"checks":["合成核查项"]'
    ',"completion":"teacher_reviewed","constraints":[],"current_draft":{"actor":{"context_id":"writer-context'
    '","name":"synthetic-writer"},"sha256":"795dc7ff7911d86a37e01c2f08f54d40427df1b93cbe3121559eaa90a4bef876"'
    ',"source_ref":"fixture://old/draft-1","text":"合成旧稿：她把伞收起来，说了句好。"},"decisions":{},"drafts":[{"actor":{"co'
    'ntext_id":"writer-context","name":"synthetic-writer"},"sha256":"795dc7ff7911d86a37e01c2f08f54d40427df1b9'
    '3cbe3121559eaa90a4bef876","source_ref":"fixture://old/draft-1","text":"合成旧稿：她把伞收起来，说了句好。"}],"final_revie'
    'w_id":"old-teacher","final_sha256":"795dc7ff7911d86a37e01c2f08f54d40427df1b93cbe3121559eaa90a4bef876","g'
    'roup_id":"old-scene-1","input_text":"合成旧输入：他递过伞。","learned_case_ids":["old-case"],"max_revisions":2,"pen'
    'ding_rechecks":[],"project_id":"book","review_order":["old-teacher"],"reviews":{"old-teacher":{"draft_in'
    'dex":0,"draft_sha256":"795dc7ff7911d86a37e01c2f08f54d40427df1b93cbe3121559eaa90a4bef876","findings":[],"'
    'rechecks":[],"review_id":"old-teacher","reviewer":{"context_id":"teacher-context","mode":"independent_ag'
    'ent","name":"synthetic-teacher","role":"teacher"},"source_ref":"fixture://old/review-1","verdict":"pass"'
    '}},"revision_count":0,"run_id":"done","selected_cases":[],"source_ref":"fixture://old/input-1","status":'
    '"finished","tags":["dialogue"],"task":"dialogue_revision"},"open":{"applications":[{"case_id":"old-case"'
    ',"conditions_checked":{"合成条件":false},"decision":"decline","exceptions_checked":{},"reason":"合成：本场不适用。"}]'
    ',"checks":["合成核查项"],"constraints":[],"current_draft":{"actor":{"context_id":"writer-context","name":"syn'
    'thetic-writer"},"adopted_findings":["f1"],"parent_sha256":"b1044be95bec5822fbd5164b52becf0631ca2c8da8548'
    '69e9f3dd7fdeb377b65","review_id":"old-needs-fix","sha256":"3f40f8b23882e292738e9bb910ea35a17a6d8c078ecf3'
    '883b6af458af1c0ff01","source_ref":"fixture://old/draft-2b","text":"合成旧稿二改：他把门带上，没有回头。"},"decisions":{"ol'
    'd-needs-fix":[{"decision":"adopt","finding_id":"f1","reason":"合成理由。"}]},"drafts":[{"actor":{"context_id"'
    ':"writer-context","name":"synthetic-writer"},"sha256":"b1044be95bec5822fbd5164b52becf0631ca2c8da854869e9'
    'f3dd7fdeb377b65","source_ref":"fixture://old/draft-2","text":"合成旧稿二：他把门带上。"},{"actor":{"context_id":"wri'
    'ter-context","name":"synthetic-writer"},"adopted_findings":["f1"],"parent_sha256":"b1044be95bec5822fbd51'
    '64b52becf0631ca2c8da854869e9f3dd7fdeb377b65","review_id":"old-needs-fix","sha256":"3f40f8b23882e292738e9'
    'bb910ea35a17a6d8c078ecf3883b6af458af1c0ff01","source_ref":"fixture://old/draft-2b","text":"合成旧稿二改：他把门带上，'
    '没有回头。"}],"group_id":"old-scene-2","input_text":"合成旧输入二：他出门。","learned_case_ids":[],"max_revisions":2,"pe'
    'nding_rechecks":["old-needs-fix"],"project_id":"book","review_order":["old-needs-fix"],"reviews":{"old-n'
    'eeds-fix":{"draft_index":0,"draft_sha256":"b1044be95bec5822fbd5164b52becf0631ca2c8da854869e9f3dd7fdeb377'
    'b65","findings":[{"evidence":"合成证据","id":"f1","issue":"合成问题","scope":"末句"}],"rechecks":[],"review_id":"o'
    'ld-needs-fix","reviewer":{"context_id":"teacher-context","mode":"independent_agent","name":"synthetic-te'
    'acher","role":"teacher"},"source_ref":"fixture://old/review-2","verdict":"revise"}},"revision_count":1,"'
    'run_id":"open","selected_cases":[{"after":"合成旧稿：她把伞收起来，说了句好。","author_acceptance":{"draft_sha256":"795dc'
    '7ff7911d86a37e01c2f08f54d40427df1b93cbe3121559eaa90a4bef876","quote":"保留这版。","ref":"fixture://old/author'
    '"},"before":"合成旧输入：他递过伞。","case_sha256":"4ee3ffa0ea0e2343b99e4a76b7aedf3c1a5fd3fc628ec7da32769b86e8d4131'
    'f","decisions":["合成取舍。"],"except":[],"group_id":"old-scene-1","hashes":{"after":"795dc7ff7911d86a37e01c2'
    'f08f54d40427df1b93cbe3121559eaa90a4bef876","before":"c56cf49de407ef18efd949915c62e8b6c63f055bfea215b6dad'
    'c47cc0236053b"},"id":"old-case","project_id":"book","source":{"draft_ref":"fixture://old/draft-1","draft'
    '_sha256":"795dc7ff7911d86a37e01c2f08f54d40427df1b93cbe3121559eaa90a4bef876","evidence":"fixture://old/re'
    'view-1","input_ref":"fixture://old/input-1","ref":"fixture://old/draft-1","review_ids":["old-teacher"],"'
    'reviewer":"synthetic-teacher","run_id":"done","supporting_review_id":"old-teacher","version":"795dc7ff79'
    '11d86a37e01c2f08f54d40427df1b93cbe3121559eaa90a4bef876"},"split":"development","status":"author_accepted'
    '","tags":["dialogue"],"task":"dialogue_revision","when":["合成条件"],"why":"合成依据。"}],"source_ref":"fixture:/'
    '/old/input-2","status":"drafted","tags":["dialogue"],"task":"dialogue_revision"}},"settings":{}}')


class OldRecordTests(LoopFixture):
    """LEGACY_STORE was written by the unmodified r5.54 merge scripts (synthetic text);
    its ledger keeps only the three entries these tests use."""

    def setUp(self):
        super().setUp()
        self.path = Path(self.temp.name) / "old-state.json"
        project_state.init_state(self.path, "book", copy.deepcopy(LEGACY_STORE))

    def test_old_record_reads_selects_and_shows_as_before(self):
        self.assertEqual(loop.status(self.path)["active_runs"], ["open"])
        selected = loop.context(self.path, "book", "dialogue_revision", tags=["dialogue"])
        self.assertEqual([(c["id"], c["status"]) for c in selected["cases"]], [("old-case", "author_accepted")])
        self.assertNotIn("skipped_stale_approvals", selected)
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            self.assertEqual(loop.main(["show", str(self.path), "--run-id", "open"]), 0)
        self.assertEqual(json.loads(output.getvalue())["next_action"], "review")

    def test_old_run_in_progress_can_be_reviewed_finished_and_learned(self):
        final = "合成旧稿二改：他把门带上，没有回头。"
        self.review("old-recheck", run_id="open", rechecks=["old-needs-fix"])
        self.apply("finish", "open", draft_sha256=sha(final))
        self.send({**self.learn_event("new-case"), "run_id": "open"})
        learned = self.payload()["data"]["demonstrations"]["new-case"]
        self.assertEqual((learned["before"], learned["after"]), ("合成旧输入二：他出门。", final))
        self.assertEqual(learned["status"], "candidate")

    def test_old_event_retry_and_finished_run_keep_their_meaning(self):
        old = LEGACY_STORE["learning_events"]["old-13"]
        retried = self.send(copy.deepcopy(old["event"]))
        self.assertEqual(retried["status"], "unchanged")
        self.assertEqual(retried["draft_sha256"], old["result"]["draft_sha256"])
        # The finished old run already has its case; a second one is refused.
        self.rejected({**self.learn_event("again"), "run_id": "done"})


if __name__ == "__main__":
    unittest.main()

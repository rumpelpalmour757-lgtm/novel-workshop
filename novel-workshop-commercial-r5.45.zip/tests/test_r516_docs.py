#!/usr/bin/env python3
"""r5.16: two documentation points from the 2026-10-19 outside review of r5.14 (P2-G01's wording, P3-D02).

- The execution notes promised "a decision at every place that changed"; the gate checked one decision per block of
  changed lines. The repair (tests/test_r516_change_coverage.py) makes the gate keep the promise; the notes now say
  outright that several changes in one line or in neighbouring lines each need their own record.
- A local task's reading range was stated three ways: one non-blank line on each side (execution notes, the gate),
  one line on each side (review template), one paragraph on each side (expression-check notes). They differ when a
  paragraph is wrapped over several physical lines. Now every place says both: the gate's minimum is one non-blank
  line on each side; the editor reads the whole paragraph on each side for the join.

The same day the author sent a grammar and punctuation handbook to use as the base for revisions (the six textbook
types of faulty sentences; GB/T 15834-2011), and a second edition of the sentence check list with two new items (a
state written into an object that later actions cannot get past; a verb whose direction is the wrong way round).
Most of it the modules already had. What they lacked, and what these tests pin:
- the language-sense section names the six textbook types and the kinds its table does not list (a subject lost
  halfway or swallowed by a preposition, a two-sided "whether" answered on one side, items of different rank listed
  together or a cause that does not lead to the result), with the rule that the standard decides right and wrong and
  the work's own usage decides style;
- the collocation row asks who does a verb, and towards whom, in passive and causative sentences;
- the punctuation module lists four clauses of the standard that the handbook flags and the module did not state
  (approximate numbers and the enumeration comma, the enumeration comma between quoted or titled items, the question
  mark in alternative questions, no colon inside a colon's range); the handbook's other points that could not be
  checked against the standard's text are left to the work's own sheet;
- persistent states include how an object is fixed or broken (sewn shut, welded, locked, cracked).
"""

import json
import os
from pathlib import Path
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"


def read(rel):
    return (SKILL / rel).read_text(encoding="utf-8")


def line_with(text, marker):
    lines = [line for line in text.splitlines() if marker in line]
    assert len(lines) == 1, (marker, len(lines))
    return lines[0]


class LocalRange(unittest.TestCase):
    def test_execution_notes_give_the_gate_minimum_and_the_reading_range(self):
        line = line_with(read("references/execution.md"), "- `scope` 写 `chapter`（整篇）或 `local`")
        self.assertIn("前后各一个非空行", line)
        self.assertIn("前后各一个自然段", line)

    def test_expression_check_notes_say_the_same(self):
        line = line_with(read("references/prose-audit.md"), "只改局部的任务写 `local`")
        self.assertIn("前后各一个非空行", line)
        self.assertIn("前后各一个自然段", line)
        self.assertNotIn("前后各一段衔接", line)

    def test_review_template_says_the_same(self):
        template = json.loads(read("assets/editorial-review-template.json"))
        note = json.dumps(template, ensure_ascii=False)
        self.assertIn("前后各一个非空行", note)
        self.assertIn("前后各一个自然段", note)
        self.assertNotIn("前后各一行", note)


class EachChange(unittest.TestCase):
    def test_execution_notes_say_each_change_needs_its_own_record(self):
        line = line_with(read("references/execution.md"), "记录过一版以后又改了正文")
        self.assertIn("各要一条", line)
        self.assertIn("同一行", line)


def section(text, heading):
    return text.split(heading, 1)[1].split("\n## ", 1)[0]


class HandbookGaps(unittest.TestCase):
    def test_language_sense_names_the_textbook_types_and_what_the_table_lacks(self):
        part = section(read("references/sentence-craft.md"), "## 语感：搭配、照应与叫法")
        self.assertIn("语序不当、搭配不当、成分残缺或赘余、结构混乱、表意不明、不合逻辑", part)
        for phrase in ("成分残缺", "介词结构吞掉", "一面对两面", "种属", "因果接不上", "主干", "作品口径"):
            self.assertIn(phrase, part)
        # it sits after the table, before the working notes, so the table itself is unchanged in shape
        self.assertLess(part.index("| 翻译腔、书面腔 |"), part.index("一面对两面"))
        self.assertLess(part.index("一面对两面"), part.index("几条做法："))

    def test_collocation_row_asks_who_does_the_verb_and_towards_whom(self):
        row = line_with(read("references/sentence-craft.md"), "| 搭配 |")
        self.assertIn("被字句", row)
        self.assertIn("向着谁", row)

    def test_punctuation_module_states_the_four_clauses(self):
        text = read("references/chinese-punctuation.md")
        for clause in ("4.5.3.4", "4.5.3.5", "4.2.3.2", "4.7.3.5"):
            self.assertIn(clause, text)
        for phrase in ("概数", "书名号", "选择问句", "冒号"):
            self.assertIn(phrase, section(text, "## 顿号、问号与冒号"))

    def test_persistent_states_include_how_a_thing_is_fixed_or_broken(self):
        part = section(read("references/continuity.md"), "## 持续状态")
        first = part.strip().split("\n\n", 1)[0]
        for phrase in ("缝死", "焊死", "锁住", "摔裂"):
            self.assertIn(phrase, first)
        self.assertIn("拉开", first)


if __name__ == "__main__":
    unittest.main()

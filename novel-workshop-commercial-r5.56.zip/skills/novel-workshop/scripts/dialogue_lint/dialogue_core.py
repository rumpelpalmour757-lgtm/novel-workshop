"""Conservative, per-quotation attribution. Offsets are Unicode string indices.

Quotations are read in “”, 「」 and 『』, the same marks dialogue_lines.py reads. A
quotation closes with its own mark on the same line; one still open at the end of the
line is read to the line end and marked ``closed=False`` (a quotation continued in the
next paragraph, or a missing closing mark). Straight quotes and marks that pair with
nothing are not read as dialogue; ``quote_coverage`` lists them by line.
"""
from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Mapping, Sequence

QUOTE_PAIRS = (('“', '”'), ('「', '」'), ('『', '』'))
OPEN_MARKS = ''.join(pair[0] for pair in QUOTE_PAIRS)
CLOSE_MARKS = ''.join(pair[1] for pair in QUOTE_PAIRS)
QUOTE_MARKS = OPEN_MARKS + CLOSE_MARKS
# Marks that look like quotation marks but are not read as dialogue here.
UNSUPPORTED_MARKS = '"＂〝〞〟'
QUOTE_RE = re.compile('|'.join(
    f'{re.escape(o)}(?P<t{n}>[^{re.escape(o + c)}]*)(?P<c{n}>{re.escape(c)}|\\Z)'
    for n, (o, c) in enumerate(QUOTE_PAIRS)))
LINE_END_RE = re.compile(r'(?:\r\n|[\n\r\v\f\x1c\x1d\x1e\x85  ])\Z')
SPEECH = r'(?:说道|问道|答道|喊道|低语|嘟囔|回答|提醒|说|问|答|喊|骂|道|哼)'
ACTION_RE = re.compile(r'^(?:把|将|端起|放下|低头|抬头|伸手|指着|走到|看|按|拦|靠|推|拉|握|抓|收|转|蹲|摇|点)')
MANNER = r'(?:低声|大声|轻声|小声|高声|冷冷地|冷冷|笑着|哭着|低头|抬头|皱眉|急忙|轻轻|缓缓|忽然|突然|接着|又|才|便|就|忙)*'
RECIPIENT = r'(?:(?!听|说|问|喊|答|骂|让|叫|要求|转述)[一-鿿]){1,10}'
# Right before the speech verb: speech that did not happen (没有说、不敢说、本想说) or two
# people speaking together (跟某某一起说). Such a tag names nobody as the speaker.
# “想了想说”“没好气地说” are not caught: there the person does speak.
NOT_ONE_SPEAKER = re.compile(
    r'(?:没有|没能|没敢|没来得及|来不及|没|不敢|不肯|不愿|不想|不便|不|未曾|未能|未|本想|原想|正想|刚想|想要|(?<![了一])想'
    r'|一起|一齐|一同|齐声|同时)' + MANNER + SPEECH + r'[：:，,]?\s*$')
_NO_MARKS = re.escape(QUOTE_MARKS)


@dataclass(frozen=True)
class QuoteMatch:
    start: int
    end: int
    text: str
    open_mark: str
    close_mark: str


def find_quotes(paragraph: str):
    """Every quotation in one line, in order; an open one runs to the line end."""
    line_end = LINE_END_RE.search(paragraph)
    body_end = line_end.start() if line_end else len(paragraph)
    found = []
    for match in QUOTE_RE.finditer(paragraph, 0, body_end):
        for n, (open_mark, close_mark) in enumerate(QUOTE_PAIRS):
            if match.group(f'c{n}') is not None:
                closed = match.group(f'c{n}') == close_mark
                text = match.group(f't{n}')
                if closed or text.strip():
                    found.append(QuoteMatch(match.start(f't{n}'), match.end(f't{n}'), text,
                                            open_mark, close_mark if closed else ''))
                break
    return found


def quote_coverage(paragraphs: Sequence[str]):
    """Which lines hold quotation marks that were not read as dialogue, or a line left open."""
    unclosed, stray, unsupported = [], [], []
    for p_index, paragraph in enumerate(paragraphs, 1):
        quotes = find_quotes(paragraph)
        covered = [False] * len(paragraph)
        for q_index, quote in enumerate(quotes, 1):
            for i in range(quote.start - len(quote.open_mark), quote.end + len(quote.close_mark)):
                covered[i] = True
            if not quote.close_mark:
                unclosed.append({'para_index': p_index, 'quote_id': f'p{p_index}:q{q_index}'})
        outside = [ch for ch, inside in zip(paragraph, covered) if not inside]
        marks = ''.join(ch for ch in outside if ch in QUOTE_MARKS)
        if marks:
            stray.append({'para_index': p_index, 'marks': marks})
        odd = ''.join(ch for ch in outside if ch in UNSUPPORTED_MARKS)
        if odd:
            unsupported.append({'para_index': p_index, 'marks': odd})
    return {'supported_marks': [o + c for o, c in QUOTE_PAIRS], 'unclosed_quotes': unclosed,
            'stray_marks': stray, 'unsupported_marks': unsupported,
            'complete': not (unclosed or stray or unsupported)}


@dataclass(frozen=True)
class DialogueSpan:
    para_index: int
    quote_index: int
    start: int
    end: int
    text: str
    speaker: str
    confidence: str
    evidence: str
    raw_para: str
    prev_para: str
    next_para: str
    open_mark: str = '“'
    close_mark: str = '”'

    @property
    def quote(self):
        return f'{self.open_mark}{self.text}{self.close_mark}'

    @property
    def quote_id(self):
        return f'p{self.para_index}:q{self.quote_index}'

    @property
    def closed(self):
        return bool(self.close_mark)


def extract_dialogues(paragraphs: Sequence[str], names=(), *, aliases=None,
                      speaker_overrides: Mapping | None = None):
    """Explicit labels outrank actions; inference is labelled and never inherited.

    Unregistered explicit speakers stay unknown. Quotation pairing across lines and
    generic coreference resolution are outside this lightweight parser's scope.
    """
    if isinstance(paragraphs, str) or isinstance(names, str):
        raise TypeError('paragraphs and names must be sequences, not single strings')
    if aliases is not None and not isinstance(aliases, Mapping):
        raise TypeError('aliases must be a mapping')
    paragraphs = list(paragraphs)
    if any(not isinstance(p, str) for p in paragraphs):
        raise TypeError('paragraphs must contain strings')
    canonical = {name: name for name in names}
    if any(not isinstance(n, str) or not n for n in canonical):
        raise ValueError('names must be nonempty strings')
    for alias, target in (aliases or {}).items():
        if not isinstance(alias, str) or not alias or target not in canonical:
            raise ValueError('aliases must map nonempty names to registered names')
        if alias in canonical and canonical[alias] != target:
            raise ValueError('alias conflicts with an existing name')
        canonical[alias] = target
    alternatives = '|'.join(re.escape(n) for n in sorted(canonical, key=lambda n: (-len(n), n)))
    name_re = re.compile(alternatives) if alternatives else None
    overrides = dict(speaker_overrides or {})
    used_overrides = set()

    def speech_tail(fragment):
        # Arbitrary characters before “说” could describe a hearer rather than
        # the speaker (e.g. “林舟听老人说”). Recognize only explicit forms.
        pattern = MANNER + r'(?:(?:对|向|跟|冲|朝)' + RECIPIENT + r')?' + MANNER + SPEECH
        if NOT_ONE_SPEAKER.search(fragment):
            return False
        return bool(re.fullmatch(pattern + r'[：:，,]?\s*', fragment))

    def explicit_prefix(fragment):
        # Only a speech label immediately introducing this quotation qualifies.
        if not name_re:
            return None
        candidates = []
        for match in name_re.finditer(fragment):
            # A name buried in the preceding clause can be a listener/object,
            # A listener after a looking/pointing action is not a speaker label.
            leading = fragment[:match.start()].rstrip()
            if leading and leading[-1] not in '，,。！？；;':
                continue
            between = fragment[match.end():]
            if speech_tail(between):
                candidates.append(canonical[match.group()])
        if candidates:
            return candidates[-1]
        # A bare speech verb after an action keeps its grammatical subject.
        # A bare speech verb after the last comma keeps the immediately
        # preceding action subject; pronouns such as “他问” remain unresolved.
        parts = re.split(r'[，,]', fragment)
        if len(parts) > 1 and re.fullmatch(SPEECH + r'[：:]?\s*', parts[-1].strip()):
            return action_subject(parts[-2])
        return None

    def explicit_suffix(fragment):
        # A trailing colon introduces the *next* quotation, not the previous one.
        if not name_re or fragment.rstrip().endswith(('：', ':')):
            return None
        head = fragment.lstrip()
        match = name_re.match(head)
        if not match:
            return None
        rest = head[match.end():]
        rest = re.split(r'[。！？；，,]', rest, maxsplit=1)[0]
        if speech_tail(rest):
            return canonical[match.group()]
        return None

    def action_subject(fragment):
        if not name_re:
            return None
        stripped = fragment.strip()
        match = name_re.match(stripped)
        if match and ACTION_RE.match(stripped[match.end():]):
            return canonical[match.group()]
        return None

    result = []
    for p_index, paragraph in enumerate(paragraphs):
        matches = find_quotes(paragraph)
        for q_index, match in enumerate(matches):
            key = (p_index + 1, q_index + 1)
            opening = match.start - len(match.open_mark)
            closing = match.end + len(match.close_mark)
            previous_end = matches[q_index - 1].end + len(matches[q_index - 1].close_mark) if q_index else 0
            next_start = (matches[q_index + 1].start - len(matches[q_index + 1].open_mark)
                          if q_index + 1 < len(matches) else len(paragraph))
            before = paragraph[previous_end:opening]
            after = paragraph[closing:next_start]
            prev = paragraphs[p_index - 1] if p_index else ''
            following = paragraphs[p_index + 1] if p_index + 1 < len(paragraphs) else ''
            speaker, confidence, evidence = '未知', 'unknown', '没有足够的说话人依据'
            if key in overrides:
                override = overrides[key]
                if not isinstance(override, str) or not override.strip():
                    raise ValueError('speaker override must be a nonempty string')
                speaker, confidence, evidence = override, 'manual', '作者明确指定'
                used_overrides.add(key)
            else:
                pre, post = explicit_prefix(before), explicit_suffix(after)
                if pre and post and pre != post:
                    evidence = '引语前后发言提示语冲突，需人工核对'
                elif pre or post:
                    speaker = pre or post
                    confidence, evidence = 'explicit', '紧邻引语的明确发言提示语'
                elif (re.search(SPEECH + r'[：:，,]?\s*$', before)
                      or re.match(r'^\s*[^，。！？；：' + _NO_MARKS + r']{1,12}?' + SPEECH + r'[。！？；，,]', after)):
                    evidence = '发言提示语中的角色未登记或无法确认'
                else:
                    candidates = set()
                    if before.rstrip().endswith(('：', ':')):
                        own = action_subject(before)
                        if own:
                            candidates.add(own)
                    # Adjacent actions are tentative; blank lines and dialogue
                    # paragraphs form boundaries and are never silently skipped.
                    if not candidates:
                        for neighbor in (prev, following):
                            if neighbor.strip() and not any(mark in neighbor for mark in QUOTE_MARKS):
                                actor = action_subject(neighbor)
                                if actor:
                                    candidates.add(actor)
                    if len(candidates) == 1:
                        speaker = candidates.pop()
                        confidence, evidence = 'inferred', '相邻动作主语推测，尚未人工确认'
                    elif len(candidates) > 1:
                        evidence = '相邻动作涉及多个可能说话人，保留未知'
            result.append(DialogueSpan(p_index + 1, q_index + 1,
                match.start, match.end, match.text,
                speaker, confidence, evidence, paragraph, prev, following,
                match.open_mark, match.close_mark))
    if set(overrides) != used_overrides:
        raise ValueError('speaker override refers to a missing quotation')
    return result

#!/usr/bin/env node
// Google AI（官方 ACP 运行时）接通检查：作者在自己的电脑上运行（双击 check-acp，或 node acp-check.mjs）。
// 1) 官方程序：路径、种类（官方 CLI agy acp，或 ACP Registry 的 agy_acp_server）、版本、大小、SHA-256，
//    和你贴的校验值对不对得上；
// 0) 或者只用 --zip：只算下载的压缩包的 SHA-256、和 ACP Registry 登记的对比（登记的是压缩包的校验值），不解压、不启动任何程序；
// 2) 启动它、握手：协议版本、agentInfo、它列出的登录方式和能力；
// 3) 加 --login：用它列出的方式登录（默认 oauth-personal）——官方程序自己打开浏览器，工坊看不到、也不保存账号和密码；
// 4) 加 --try：发一次工坊自带的两句合成示例（不发任何文稿），看是不是真的拿回了回复。
// 直接双击（不带参数）时，握手以后会问要不要登录、要不要发合成示例。
// 报告写在用户配置目录的 acp-check-report.txt：去掉了主目录路径，看上去像邮箱、令牌、密钥、授权码的字样换成了［已隐去］；
// 这只是按样子去掉的，发给别人之前请自己从头看一遍。
//
// 这里通过只说明“连接能用”，不说明可以把订阅用于写小说（见下面打印的说明）。
// 四件事分开报：程序来源（--sha256 给出你核对过的校验值、而且对得上）、ACP 握手、官方程序自己的登录、真实的模型回复。
// 来源没核对的，最多只算协议结果；工坊自己的模拟程序（它在握手里标明自己是模拟的）产出的一切都标成“模拟”。
// 退出码：0 检查跑完了（结论见最后一行；--zip 时是压缩包对得上）；2 没找到可启动的官方程序、压缩包对不上、参数不对、
// 另一个写作台正在用或 Node 太旧；3 启动了但握手没有成功；被 Ctrl+C、关掉终端窗口等打断时是 128 加信号号
// （Ctrl+C 是 130，关掉窗口是 129，SIGTERM 是 143）。被打断时照样结束它启动的官方程序（和它拉起的子进程）、
// 删掉临时目录、放开锁，并把打断以前的结果写进报告。

import { realpathSync } from "node:fs";
import { mkdir, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { createInterface } from "node:readline/promises";
import { fileURLToPath } from "node:url";
import { configDirectory } from "./gemini-assist.mjs";
import { SELFTEST_SAMPLE, createAcpProvider, duration } from "./acp-assist.mjs";
import { ALLOWED_FLAGS, REGISTRY_RELEASE, makeScrubber, normalizeSha256, platformKey, registryMatch, sha256File, stopAllRuntimesSync } from "./acp-runtime.mjs";

const MIN_NODE = 18;
const SHUTDOWN_WAIT_MS = 3000;
// 被打断时的退出码：128 加信号号（Windows 的 Ctrl+Break 是 SIGBREAK，21 号）。
export const SIGNAL_EXIT_CODES = Object.freeze({ SIGHUP: 129, SIGINT: 130, SIGTERM: 143, SIGBREAK: 149 });
export function interruptSignals(platform = process.platform) {
  return ["SIGINT", "SIGTERM", "SIGHUP", ...(platform === "win32" ? ["SIGBREAK"] : [])];
}

export const SCOPE_NOTICE = Object.freeze([
  "注意：这里通过只说明“连接能用”，不等于允许把订阅用于写小说。",
  "  · Google 官方论坛 2026-11-02 的答复只说：ACP 客户端可以启动官方、未经修改的 antigravity-acp，用它自己的 oauth-personal 登录，在“单用户、交互式开发”里使用个人 Google AI 订阅。",
  "  · Antigravity 附加条款第 6 节大范围禁止第三方访问；FAQ 还限制第三方复用登录信息、包装 agy -p。",
  "  · 把订阅用于小说写作、自动互审、无人值守的循环：未确认。",
  "  · 工坊不会自动改用 Gemini API 或别的付费接口；它也看不到、拦不住 Google 账号里的 AI 额度超额消费：不想超额花钱，把 Antigravity 套餐页的“AI Credit Overages”设成 Never。",
  "  来源：https://discuss.ai.google.dev/t/conflicting-guidance-on-using-t3-code-with-personal-google-ai-subscriptions/197131/3 ；https://antigravity.google/terms ；https://antigravity.google/docs/faq ；https://antigravity.google/docs/plans",
]);

export function parseAcpCheckArguments(argv) {
  const options = { runtime: null, sha256: null, zip: null, login: false, method: null, tryPrompt: false, model: null, thinking: null, flags: [], help: false, error: null };
  for (let index = 0; index < argv.length; index += 1) {
    const value = argv[index];
    const next = () => {
      const following = argv[index + 1];
      index += 1;
      if (following === undefined || following.startsWith("--")) {
        options.error = `${value} 后面要跟一个值`;
        return null;
      }
      return following;
    };
    if (value === "--help" || value === "-h") options.help = true;
    else if (value === "--login") options.login = true;
    else if (value === "--try") options.tryPrompt = true;
    else if (value === "--runtime") options.runtime = next();
    else if (value === "--zip") options.zip = next();
    else if (value === "--method") options.method = next();
    else if (value === "--model") options.model = next();
    else if (value === "--thinking") options.thinking = next();
    else if (value === "--sha256") {
      const raw = next();
      if (raw !== null) {
        options.sha256 = normalizeSha256(raw);
        if (!options.sha256) options.error = "--sha256 后面要跟 64 位十六进制的校验值";
      }
    } else if (value === "--flag") {
      const flag = next();
      if (flag !== null) {
        if (ALLOWED_FLAGS.includes(flag)) options.flags.push(flag);
        else options.error = `--flag 只认这几个：${ALLOWED_FLAGS.join("、")}`;
      }
    } else options.error = `不认识的参数：${value}`;
  }
  if (options.zip && !options.error && (options.runtime || options.sha256 || options.login || options.tryPrompt || options.method || options.model || options.thinking || options.flags.length)) {
    options.error = "--zip 只核对压缩包，不启动任何程序，不和别的参数一起用：先单独跑一次 --zip，再另外检查程序。";
  }
  return options;
}

const USAGE = [
  "用法：node acp-check.mjs [--runtime 官方程序的完整路径] [--sha256 校验值] [--zip 下载的zip] [--login [--method 登录方式]] [--try [--model 模型] [--thinking 思考强度]] [--flag 开关]",
  "  --runtime  这一次检查这个文件（不改写作台保存的设置）；不写就用写作台里填的路径，或在 PATH 里找 agy",
  "  --sha256   和这个文件的 SHA-256 对比（你自己核对过的那一份程序的校验值）",
  "  --zip      只算下载的 zip 的 SHA-256，和 ACP Registry 登记的对比（登记的是压缩包的，不是解压后程序的）；不解压、不启动任何程序，不和别的参数一起用",
  "  --login    握手以后用官方程序列出的方式登录，默认 oauth-personal；官方程序自己打开浏览器",
  "  --try      发一次工坊自带的两句合成示例，看是否拿回回复；--model、--thinking 这一次指定（不在清单里就不发，不替你换）",
  `  --flag     连接时多带的官方 CLI 开关，只认：${ALLOWED_FLAGS.join("、")}（效果没有核实）`,
];

function nodeTooOld(version = process.versions.node) {
  return Number(String(version).split(".")[0]) < MIN_NODE;
}

function describeOptions(options) {
  return options.map((option) => {
    const values = option.values.map((value) => `${value.name}${value.value !== value.name ? `（${value.value}）` : ""}`).join("、");
    return `  - ${option.name}（${option.category || "未分类"}）：现在是 ${option.currentValue ?? "未知"}；可选 ${values || "无"}`;
  });
}

export async function runAcpCheck({
  argv = [],
  env = process.env,
  print = console.log,
  now = () => new Date(),
  ask = null,
  timeouts = {},
  platform = process.platform,
  onStart = null,
} = {}) {
  const scrub = makeScrubber({ env, platform });
  const lines = [];
  const say = (text = "") => {
    const clean = scrub(text);
    lines.push(clean);
    print(clean);
  };
  const options = parseAcpCheckArguments(argv);
  if (options.help || options.error) {
    if (options.error) say(options.error);
    for (const line of USAGE) say(line);
    return { code: options.error ? 2 : 0, lines };
  }
  if (nodeTooOld()) {
    say(`Node.js 版本是 ${process.versions.node}，需要 ${MIN_NODE} 或更新。`);
    return { code: 2, lines };
  }
  say("Google AI 官方 ACP 运行时接通检查（小说写作工坊）");
  say(`时间：${now().toISOString()}；Node ${process.versions.node}；${platformKey(platform)}`);
  for (const line of SCOPE_NOTICE) say(line);
  say("");

  let conclusion = null;
  let interrupted = null;
  // 对方在握手里标明自己是模拟程序：最后一行结论（每一种结论）都带上“模拟”。
  let simulated = false;
  const marked = (text) => (simulated && text && !text.startsWith("结论（模拟）") ? text.replace(/^结论：/, "结论（模拟）：") : text);
  const reportPath = join(configDirectory(env), "acp-check-report.txt");
  const writeReport = async (code) => {
    try {
      await mkdir(configDirectory(env), { recursive: true, mode: 0o700 });
      await writeFile(reportPath, `${lines.join("\n")}\n`, { encoding: "utf8", mode: 0o600 });
      print(`报告：${scrub(reportPath)}。里面去掉了主目录路径，看上去像邮箱、令牌、密钥、授权码的字样换成了［已隐去］；这只是按样子去掉的，发给别人之前请自己从头看一遍。`);
      return { code, lines, report: reportPath };
    } catch {
      print("报告没有写成（配置目录写不进去），上面的输出就是全部结果。");
      return { code, lines, report: null };
    }
  };
  const finish = async (code) => {
    // 已经被打断：报告由打断的那边写，这里不再写，免得两边抢着写。
    if (interrupted) return interrupted;
    if (conclusion) say(marked(conclusion));
    return writeReport(code);
  };
  if (options.zip) {
    say("〇、核对下载的压缩包（只算校验值，不解压，不启动任何程序）");
    let matched = false;
    try {
      const digest = await sha256File(options.zip);
      const match = registryMatch(digest.sha256);
      matched = Boolean(match);
      say(`  ${options.zip}：${digest.size} 字节，SHA-256 ${digest.sha256}`);
      say(match
        ? `  和 ACP Registry 里 antigravity-acp ${REGISTRY_RELEASE.version} 的 ${match.key} 压缩包一致（Google LLC 发布）。解压后要启动的是 ${match.cmd}${match.args.length ? `，参数 ${match.args.join(" ")}` : ""}。`
        : `  和 ACP Registry 里 antigravity-acp ${REGISTRY_RELEASE.version} 登记的任何一个压缩包都对不上：不要解压运行，重新从清单里的官方地址下载。`);
    } catch (error) {
      say(`  读不了这个文件（${error?.code || error?.message || "出错"}）`);
    }
    say("");
    conclusion = matched ? "结论：压缩包和 ACP Registry 登记的一致，可以解压。这一步没有启动任何程序。" : "结论：压缩包对不上或读不了，不要解压运行。这一步没有启动任何程序。";
    return finish(matched ? 0 : 2);
  }

  const provider = createAcpProvider({
    env,
    platform,
    timeouts,
    tool: "check-acp",
    overrides: { runtimePath: options.runtime, expectedSha256: options.sha256, flags: options.flags.length ? options.flags : undefined },
  });
  // 被 Ctrl+C、关掉终端窗口（SIGHUP）、SIGTERM 打断：停掉官方程序（整个进程组）、删临时目录、放开锁，写下打断以前的报告。
  // 只做一次；最多等 SHUTDOWN_WAIT_MS，等不到就直接结束进程组。
  const interrupt = (signal) => {
    if (interrupted) return interrupted;
    const code = SIGNAL_EXIT_CODES[signal] ?? 130;
    interrupted = (async () => {
      say("");
      say(`检查被中断（${signal}）：已经结束官方程序（和它拉起的子进程）、删掉临时目录、放开锁；没有自动重发任何请求。`);
      let timer;
      await Promise.race([
        provider.shutdown().catch(() => {}),
        new Promise((accept) => {
          timer = setTimeout(accept, SHUTDOWN_WAIT_MS);
          timer.unref?.();
        }),
      ]);
      clearTimeout(timer);
      stopAllRuntimesSync();
      provider.lock?.releaseSync?.();
      say(conclusion ? `中断以前的${marked(conclusion)}` : marked("结论：检查没有跑完（被中断）。"));
      return writeReport(code);
    })();
    return interrupted;
  };
  onStart?.({ provider, interrupt, reportPath });
  const steps = async () => {
    say("一、官方程序");
    const runtime = await provider.probe();
    if (runtime.path) say(`  路径：${runtime.path}${runtime.source === "path" ? "（在 PATH 里找到的）" : ""}`);
    if (runtime.realPath && runtime.realPath !== runtime.path) say(`  实际文件：${runtime.realPath}`);
    if (runtime.kind) say(`  种类：${runtime.kind === "agy-cli" ? "官方 CLI（agy acp）" : "ACP Registry 发行包（agy_acp_server）"}；启动参数：${(runtime.args || []).join(" ") || "无"}`);
    if (runtime.kind === "agy-cli") say(`  agy --version：${runtime.version || runtime.versionNote || "没查"}`);
    if (runtime.sha256) {
      say(`  大小 ${runtime.size} 字节；程序文件的 SHA-256 ${runtime.sha256}${runtime.hashOf === "windows-shim" ? "（这是 Windows 的 .cmd 启动脚本本身的，不是程序本体的）" : runtime.hashOf === "link-target" ? "（链接指向的那个文件的）" : "（解压以后的程序本身的）"}`);
      say(`  和你贴的校验值：${runtime.checksum?.match === true ? "一致" : runtime.checksum?.match === false ? "不一致" : "没有贴，只记下"}`);
      say(`  程序来源：${runtime.hashOf === "windows-shim"
        ? "未核对：校验值是 .cmd/.bat 启动脚本的，不是它启动的程序的；后面最多只算协议结果。要核对来源，--runtime 填程序本身（比如 agy.exe）"
        : runtime.checksum?.match === true ? "已核对（和你用 --sha256 给的一致）" : runtime.checksum?.match === false ? "校验不符" : "未核对（没有用 --sha256 给出你核对过的校验值）：后面最多只算协议结果，不算真实接通"}`);
    }
    if (runtime.kind === "registry-binary" && runtime.registry?.archiveSha256) {
      say(`  （ACP Registry 登记的 ${runtime.registry.platformKey} 发行包 zip 的 SHA-256 是 ${runtime.registry.archiveSha256}：那是压缩包的，不是上面这个程序文件的；解压前用 --zip 核对）`);
    }
    say(`  状态：${runtime.label}。${runtime.message}`);
    for (const warning of runtime.warnings || []) say(`  提醒：${warning}`);
    say("");
    if (runtime.state !== "launchable") {
      conclusion = "结论：没有找到可启动的官方程序，原因见上面。";
      return 2;
    }

    say("二、启动和握手（只交换协议信息，不发任何文字）");
    let status;
    try {
      status = await provider.connect();
    } catch (error) {
      say(`  失败：${error?.message || error}`);
      const after = await provider.status();
      for (const line of after.diagnostics.stderr || []) say(`  [官方程序的 stderr] ${line}`);
      conclusion = "结论：官方程序启动了，但握手没有成功，原因见上面。";
      return 3;
    }
    const handshake = status.handshake;
    say(`  协议版本：${handshake.protocolVersion}`);
    say(`  agentInfo：${handshake.agentInfo ? `${handshake.agentInfo.title || "（没有 title）"}；name ${handshake.agentInfo.name || "未知"}；version ${handshake.agentInfo.version || "未知"}` : "官方程序没有给出"}${handshake.official ? "" : "（它不自称 Antigravity）"}（这是它自己说的，工坊核实不了）`);
    simulated = Boolean(handshake.simulated);
    if (handshake.simulated) say("  ［模拟］这是工坊自己的模拟程序（它在握手里标明了），不是 Google 的：下面的结果都只是模拟。");
    say(`  登录方式：${handshake.authMethods.map((method) => `${method.id}${method.type ? `（${method.type}）` : ""}`).join("、") || "没有列出"}`);
    const caps = handshake.capabilities;
    say(`  能力：loadSession ${caps.loadSession}；图片 ${caps.promptCapabilities.image}、音频 ${caps.promptCapabilities.audio}、嵌入资料 ${caps.promptCapabilities.embeddedContext}；MCP http ${caps.mcpCapabilities.http}、sse ${caps.mcpCapabilities.sse}；logout ${caps.authLogout}；会话能力 ${caps.sessionCapabilities.join("、") || "无"}`);
    say("  工坊声明的客户端能力：不提供文件读写（fs）、不提供终端（terminal）。");
    say("");
    conclusion = "结论：握手成功。这只是连接检查；没有发请求，不算真实接通。";

    let doLogin = options.login;
    if (!doLogin && ask) doLogin = /^y/i.test(String(await ask("要用 Google 登录试一次吗？官方程序会自己打开浏览器。输入 y 回车登录，直接回车跳过：")).trim());
    if (doLogin) {
      say("三、登录（官方程序自己处理；工坊看不到、也不保存你的账号和密码）");
      const methods = handshake.authMethods;
      const methodId = options.method || (methods.some((method) => method.id === "oauth-personal") ? "oauth-personal" : null);
      if (!methodId) {
        say(`  官方程序没有列出 oauth-personal；它列出的是：${methods.map((method) => method.id).join("、") || "无"}。要用别的，加 --method 名字。`);
      } else {
        say(`  用 ${methodId} 登录，等官方程序完成（最多 ${duration(provider.timeouts.loginMs)}）……`);
        try {
          await provider.login({ methodId });
          say("  登录成功（已认证）。“已认证”只说明登录成功，还不说明能用。");
        } catch (error) {
          say(`  ${error?.message || error}`);
        }
      }
      say("");
    }

    let doTry = options.tryPrompt;
    if (!doTry && ask && provider.connected()) doTry = /^y/i.test(String(await ask("要发一次合成示例吗？只发工坊自带的两句合成文字，不发任何文稿。输入 y 回车发送，直接回车跳过：")).trim());
    if (doTry && provider.connected()) {
      say("四、模型和一次合成示例（不发任何文稿）");
      let ready = true;
      try {
        status = await provider.models();
        const list = status.session?.options || [];
        say(list.length ? "  官方程序给出的会话设置：" : "  官方程序没有给出可选的会话设置（模型、思考强度）。");
        for (const line of describeOptions(list)) say(line);
        for (const [category, wanted, label] of [["model", options.model, "模型"], ["thought_level", options.thinking, "思考强度"]]) {
          if (!wanted) continue;
          const option = list.find((entry) => entry.category === category);
          if (!option || !option.values.some((value) => value.value === wanted || value.name === wanted)) {
            say(`  你指定的${label}“${wanted}”不在官方程序给出的清单里：没有替你换别的，这次不发。`);
            ready = false;
            continue;
          }
          const value = option.values.find((entry) => entry.value === wanted || entry.name === wanted).value;
          await provider.setOption({ configId: option.id, value, persist: false });
          say(`  这一次的${label}：${value}（不改写作台保存的选择）`);
        }
      } catch (error) {
        say(`  ${error?.message || error}`);
        ready = false;
      }
      if (ready) {
        say(`  发送：${SELFTEST_SAMPLE.text}`);
        say(`  要求：${SELFTEST_SAMPLE.instruction}`);
        try {
          const started = await provider.startPrompt({ kind: "selftest" });
          const task = await provider.waitForTask(started.taskId);
          say(`  结果：${task.outcomeLabel}；结束原因 ${task.stopReason ?? "没有"}；收到 ${task.chars} 字（思考片段 ${task.thoughtChunks} 条、工具调用 ${task.toolCalls} 次、权限请求 ${task.permissionRequests} 次，内容不显示）`);
          say(`  请求的模型：${task.requested?.model ? `${task.requested.model.name}${task.requested.model.chosen ? "" : "（官方程序默认）"}` : "未知"}；官方程序回报的会话模型设置：${task.reportedModel?.name || "未知"}`);
          if (task.candidate) say(`  回复：${task.candidate.slice(0, 300)}${task.candidate.length > 300 ? "……" : ""}`);
          else if (task.partial) say(`  不完整的部分输出：${task.partial.slice(0, 200)}`);
          say(`  ${task.message}`);
          const after = await provider.status();
          if (task.outcome === "complete") {
            const reply = after.verification?.reply;
            if (after.realCurrent) {
              conclusion = "结论：真实接通——官方程序对合成示例拿回了完整回复（end_turn），程序来源核对过。这只说明连接能用，不说明可以把订阅用于写小说。";
            } else if (after.handshake?.simulated) {
              conclusion = "结论（模拟）：这是工坊自己的模拟程序，不是 Google 的；它拿回了完整回复，只说明工坊这一侧能用，不算接通 Google 官方运行时。";
            } else if (!after.handshake?.official) {
              conclusion = "结论：收到了回复，但对方不自称 Antigravity，不算接通 Google 官方运行时。";
            } else {
              conclusion = `结论：只算协议结果——握手和一次回复都正常，但不算真实接通：${(reply?.why || ["程序来源没有核对"]).join("；")}。要算真实接通，用 --sha256 给出你核对过的校验值再跑一次。`;
            }
          } else {
            conclusion = "结论：握手成功，但合成示例没有拿回完整回复，原因见上面。";
          }
        } catch (error) {
          say(`  ${error?.message || error}`);
          conclusion = "结论：握手成功，但合成示例没有发出或没有拿回回复，原因见上面。";
        }
      }
      say("");
    }
    return 0;
  };
  let code;
  try {
    code = await steps();
  } catch (error) {
    if (error?.code === "acp_other_instance") {
      say(`  ${error.message}`);
      conclusion = "结论：没有检查：另一个写作台（或 check-acp）正在用 Google AI。";
    } else {
      say(`检查中途出错：${error?.message || error}`);
    }
    code = 2;
  }
  if (interrupted) return interrupted;
  const final = await provider.status().catch(() => null);
  if (final?.verification && code !== 2) {
    // 四件事分开列，不互相代替。
    const v = final.verification;
    say("五、四件事分开看");
    say(`  程序来源：${v.source.label}`);
    say(`  ACP 握手：${v.handshake.label}${v.handshake.simulated ? "（模拟程序）" : ""}`);
    say(`  官方登录：${v.login.label}；${v.login.accountNote}${v.handshake.simulated ? "（模拟程序）" : ""}`);
    say(`  模型回复：${v.reply.label}${v.reply.why?.length ? `（${v.reply.why.join("；")}）` : ""}`);
    say(`  额度：${v.reply.quota.state === "limited" ? v.reply.quota.message : v.reply.quota.label}`);
    say("");
  }
  await provider.shutdown().catch(() => {});
  if (final?.diagnostics?.protocol?.protocolErrors) say(`协议错误 ${final.diagnostics.protocol.protocolErrors} 行（不是协议消息的输出，已丢弃，没有进候选稿）。`);
  return finish(code);
}

function isMain() {
  try {
    return Boolean(process.argv[1]) && realpathSync(process.argv[1]) === realpathSync(fileURLToPath(import.meta.url));
  } catch {
    return false;
  }
}

if (isMain()) {
  const argv = process.argv.slice(2);
  const interactive = argv.length === 0 && process.stdin.isTTY && process.stdout.isTTY;
  const rl = interactive ? createInterface({ input: process.stdin, output: process.stdout }) : null;
  let context = null;
  let stopping = false;
  const onSignal = (signal) => {
    const code = SIGNAL_EXIT_CODES[signal] ?? 130;
    // 第二次再按：不等了，直接结束官方程序的进程组和临时目录（退出钩子也会放开锁）。
    if (stopping || !context) {
      stopAllRuntimesSync();
      process.exit(code);
    }
    stopping = true;
    context.interrupt(signal).finally(() => process.exit(code));
  };
  for (const signal of interruptSignals()) process.on(signal, () => onSignal(signal));
  // 问 y/n 的时候按 Ctrl+C，信号先到 readline：同样处理。
  rl?.on("SIGINT", () => onSignal("SIGINT"));
  try {
    const { code } = await runAcpCheck({ argv, ask: rl ? (question) => rl.question(question) : null, onStart: (value) => (context = value) });
    if (!stopping) process.exitCode = code;
  } finally {
    rl?.close();
  }
}

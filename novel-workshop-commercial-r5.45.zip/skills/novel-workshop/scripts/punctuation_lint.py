#!/usr/bin/env python3
"""Read-only checks for Chinese fiction punctuation and sentence-chopping hints.

ERROR  objective format faults: unpaired quotes or brackets, banned forms such as
       "..." or "。。", ASCII punctuation between Chinese characters, or a declared
       ability/item tag carrying sentence punctuation inside its brackets.
REVIEW needs an editor's decision: short-sentence chains, runs of one-line
       paragraphs, suspicious tags, dialogue punctuation, heavy paragraphs and
       long unbroken speeches (reader load). Never auto-fixed.
INFO   counts with a stated basis. No ratio is a pass mark.

--baseline ORIGINAL compares a revision with its original and reports only what
the revision introduced, plus changed end marks of the same line of dialogue. The
dialogue of the two versions is matched one to one (whole lines first, so moved
paragraphs are found again); repeated words that cannot be matched reliably are
reported as uncertain, never taken as unchanged.

--dialogue-soft-wrap (or "dialogue_soft_wrap": true in the rules file) is an opt-in
house style: line breaks inside one quotation that closes on a later line are the
author's visual soft wraps, not unclosed quotes. A blank line, or a line that opens
a new quotation, still ends the quotation; a quotation that never closes is still
an ERROR. Off by default.

Never rewrites text, never judges style, never says whether AI wrote it.
Exit codes: 0 no ERROR findings (or none introduced), 1 ERROR findings present
(or introduced), 2 unreadable input or rules.
"""

import argparse
import bisect
from collections import Counter
from difflib import SequenceMatcher
import hashlib
import json
from pathlib import Path
import re
import sys

VERSION = "1.10"  # 1.3: tone ids carry the column (TONE-L3-C12); 1.4: repeated dialogue is matched one to one;
                 # 1.5: a speech-only line is matched with its speaker line, coincidental runs are not trusted;
                 # 1.6: a colon line names the speech below it across blank lines, the line below alone names nobody,
                 #      a replaced line is "rewritten in place" only when nothing else explains it;
                 # 1.7: words pair by place only when named the same way in both versions; a tie is no rewrite;
                 # 1.8: words are unique only if said once anywhere (inline too); a changed line is no rewrite when
                 #      text it lost or gained stands in another changed line (people traded places)
                 # 1.9: the last fallback compares the narration of the lines, not the whole lines, and refuses an
                 #      order in which people traded lines; an assumed rewrite pairs no words said more or fewer times
                 # 1.10: each quote of a line gets its own narration; the same narration once on each side pairs
                 #      the same words whatever the lines were split into or merged with
HAN = r"㐀-䶿一-鿿豈-﫿"
HAN_RE = re.compile("[" + HAN + "]")
FULL_PUNCT = "，。、；：！？“”‘’（）【】《》〈〉「」『』〔〕…—·～"
CJK_CONTEXT = re.compile("[" + HAN + re.escape(FULL_PUNCT) + "]")
TERMINALS = "。！？"
PAUSES = "。，、；："
DEFAULT_RULES = {
    "ability_tags": [],
    "panel_prefixes": [],
    "tag_brackets": [["【", "】"]],
    "quote_pairs": [["“", "”"], ["‘", "’"]],
    "short_chain": {"max_chars": 6, "min_run": 3},
    "short_paragraph_run": {"max_chars": 12, "min_run": 4},
    # Reader-load hints (REVIEW only). Narrative Han characters in one paragraph; registered people
    # crowding one paragraph; one stretch of speech with no beat in between. Tune per work.
    "dense_paragraph": {"max_chars": 150, "max_people": 3, "min_clauses": 6},
    "long_speech": {"max_chars": 100, "min_sentences": 4},
    "characters": [],
    # Opt-in house style: line breaks inside ONE quotation that is not closed until a later line are the
    # author's visual soft wraps, not missing closing quotes. Off by default (strict P01).
    "dialogue_soft_wrap": False,
    "ignore": [],
}
RULE_TEXT = {
    "P01": "引号配对", "P02": "括号配对", "P03": "标签内标点", "P04": "连续标点",
    "P05": "省略号与破折号写法", "P06": "中文语境半角标点", "P07": "全角数字字母",
    "P08": "多余空格", "P09": "对白引号标点", "P10": "连续极短句", "P11": "连续单行短段",
    "P12": "段落负担", "P13": "长段对白",
}
SPEECH_TAG = re.compile("^[" + HAN + "]{0,4}?(?:说|问|道|喊|答|笑道|叫|嘟囔|低声|开口)")
HEADING = re.compile(r"^\s*(?:#|第[0-9一二三四五六七八九十百千零〇两]+[章节回卷部集])")


def load_rules(value):
    if value is None:
        value = {}
    if not isinstance(value, dict):
        raise ValueError("rules must be a JSON object")
    unknown = set(value) - set(DEFAULT_RULES) - {"note", "project"}
    if unknown:
        raise ValueError("unknown rule fields: " + ", ".join(sorted(unknown)))
    rules = json.loads(json.dumps(DEFAULT_RULES))
    for key, item in value.items():
        if key in ("note", "project"):
            continue
        if isinstance(rules[key], bool):
            if type(item) is not bool:
                raise ValueError(key + " must be true or false")
            rules[key] = item
        elif isinstance(rules[key], dict):
            if not isinstance(item, dict) or set(item) - set(rules[key]):
                raise ValueError(key + " has invalid fields")
            for sub, number in item.items():
                if type(number) is not int or number < 1:
                    raise ValueError(key + "." + sub + " must be a positive integer")
            rules[key].update(item)
        else:
            if not isinstance(item, list):
                raise ValueError(key + " must be a list")
            rules[key] = item
    for key in ("ability_tags", "panel_prefixes"):
        if not all(isinstance(x, str) and x.strip() for x in rules[key]):
            raise ValueError(key + " must contain nonempty strings")
    for entry in rules["characters"]:
        names = [entry] if isinstance(entry, str) else entry
        if not (isinstance(names, list) and names and all(isinstance(x, str) and x.strip() for x in names)):
            raise ValueError("characters entries must be a name or a list of a person's names")
    for key in ("tag_brackets", "quote_pairs"):
        used = set()
        for pair in rules[key]:
            if not (isinstance(pair, list) and len(pair) == 2 and all(isinstance(c, str) and len(c) == 1 for c in pair)):
                raise ValueError(key + " entries must be two single characters")
            if pair[0] == pair[1] or used.intersection(pair):
                raise ValueError(key + " pairs must have distinct, non-overlapping opening and closing characters")
            used.update(pair)
    for item in rules["ignore"]:
        if not isinstance(item, dict) or set(item) != {"rule", "line", "text", "reason"}:
            raise ValueError("each ignore needs rule, line, text, reason")
        if item["rule"] not in RULE_TEXT or type(item["line"]) is not int or item["line"] < 1:
            raise ValueError("ignore has an unknown rule or invalid line")
        if not (isinstance(item["text"], str) and item["text"] and isinstance(item["reason"], str) and item["reason"].strip()):
            raise ValueError("ignore text and reason must be nonempty")
    return rules


def assign_ids(items, make):
    """Give every item its own id. The position-based id is unique by construction; should two items ever
    share one, the later ones get -2, -3 ... so that one editorial decision can never cover two findings."""
    taken = set()
    for item in items:
        base = make(item)
        value, number = base, 1
        while value in taken:
            number += 1
            value = "%s-%d" % (base, number)
        item["id"] = value
        taken.add(value)
    return items


def han_count(text):
    return len(HAN_RE.findall(text))


def is_han(char):
    return bool(char) and bool(HAN_RE.match(char))


def lint_text(text, rules=None, dialogue_soft_wrap=None):
    """dialogue_soft_wrap=None follows the rules file; True or False overrides it for this run."""
    rules = load_rules(rules)
    dialogue_soft_wrap = rules["dialogue_soft_wrap"] if dialogue_soft_wrap is None else bool(dialogue_soft_wrap)
    starts = [0] + [m.end() for m in re.finditer("\n", text)]
    findings = []

    def locate(offset):
        index = bisect.bisect_right(starts, offset) - 1
        return index + 1, offset - starts[index] + 1

    def add(rule, severity, start, end, message):
        line, column = locate(start)
        line_end = text.find("\n", start)
        line_end = len(text) if line_end < 0 else line_end
        context = text[max(starts[line - 1], start - 12):min(line_end, end + 12)]
        findings.append({"rule": rule, "name": RULE_TEXT[rule], "severity": severity,
                         "line": line, "column": column, "match": text[start:end],
                         "context": context, "message": message})

    paragraphs = []
    for match in re.finditer(r"[^\n]+", text):
        if match.group(0).strip():
            paragraphs.append((match.start(), match.group(0)))

    # Opt-in only: physical line breaks inside ONE quoted speech block may be
    # author's soft visual wraps, not missing closing quotes. Preserve literal
    # offsets, bytes, all other checks, and the default strict behavior.
    if dialogue_soft_wrap:
        left, right = rules["quote_pairs"][0]
        joined = []
        i = 0
        while i < len(paragraphs):
            start, fragment = paragraphs[i]
            body = fragment.lstrip(' \t　')
            if body.startswith(left) and body.count(left) > body.count(right):
                j = i + 1
                while j < len(paragraphs) and j - i <= 12:
                    next_start, next_fragment = paragraphs[j]
                    previous_start, previous_fragment = paragraphs[j - 1]
                    # An empty line or an independently quoted new paragraph
                    # stops soft wrapping. These retain ordinary P01 checks.
                    between = text[previous_start + len(previous_fragment):next_start]
                    if between.count('\n') != 1 or next_fragment.lstrip().startswith(left):
                        break
                    fragment = text[start:next_start + len(next_fragment)]
                    j += 1
                    if fragment.count(left) <= fragment.count(right):
                        break
                if j > i+1:
                    joined.append((start, fragment))
                    i = j
                    continue
            joined.append((start, fragment))
            i += 1
        paragraphs = joined

    # P01 quotes, allowing the convention that a quotation spanning paragraphs
    # reopens each paragraph and closes only once at the end.
    openers = {pair[0]: pair[1] for pair in rules["quote_pairs"]}
    closers = {pair[1]: pair[0] for pair in rules["quote_pairs"]}
    stack = []
    for start, para in paragraphs:
        body_offset = len(para) - len(para.lstrip(" \t　"))
        skip_at = None
        if stack:
            first = para[body_offset:body_offset + 1]
            if len(stack) == 1 and first == stack[0][0]:
                skip_at = body_offset
            else:
                for char, pos in stack:
                    add("P01", "ERROR", pos, pos + 1, "引号在段末仍未闭合，下一段也不是续引的前引号。")
                stack = []
        for i, char in enumerate(para):
            if i == skip_at:
                continue
            pos = start + i
            if char in openers and not (char == closers.get(char)):
                if stack and stack[-1][0] == char:
                    add("P01", "ERROR", stack[-1][1], stack[-1][1] + 1, "同类前引号尚未闭合又出现新的前引号。")
                    stack[-1] = (char, pos)
                else:
                    stack.append((char, pos))
            elif char in closers:
                if char == "’" and 0 < i < len(para) - 1 and para[i - 1].isascii() and para[i - 1].isalpha() and para[i + 1].isascii() and para[i + 1].isalpha():
                    continue  # English apostrophe
                if stack and stack[-1][0] == closers[char]:
                    stack.pop()
                else:
                    add("P01", "ERROR", pos, pos + 1, "后引号没有对应的前引号，或与内层引号交叉。")
    for char, pos in stack:
        add("P01", "ERROR", pos, pos + 1, "全文结束时引号仍未闭合。")

    # P02 brackets inside one paragraph.
    bracket_pairs = {"（": "）", "【": "】", "《": "》", "〈": "〉", "〔": "〕", "「": "」", "『": "』"}
    for pair in rules["quote_pairs"]:
        bracket_pairs.pop(pair[0], None)
    closing = {v: k for k, v in bracket_pairs.items()}
    for start, para in paragraphs:
        local = []
        for i, char in enumerate(para):
            if char in bracket_pairs:
                local.append((char, start + i))
            elif char in closing:
                if local and local[-1][0] == closing[char]:
                    local.pop()
                else:
                    add("P02", "ERROR", start + i, start + i + 1, "后括号没有对应的前括号，或括号交叉。")
        for char, pos in local:
            add("P02", "ERROR", pos, pos + 1, "括号在本段内没有闭合。")

    # P03 tags such as an ability name that must not carry sentence punctuation.
    abilities = set(rules["ability_tags"])
    for left, right in rules["tag_brackets"]:
        pattern = re.compile(re.escape(left) + "([^" + re.escape(left + right) + "\n]{1,40})" + re.escape(right))
        bare = {m.group(1) for m in pattern.finditer(text)}
        for match in pattern.finditer(text):
            content = match.group(1)
            core = content.rstrip("。，、；：！？…")
            if core == content or not core:
                continue
            if any(core.startswith(prefix) for prefix in rules["panel_prefixes"]):
                continue
            if core in abilities:
                add("P03", "ERROR", match.start(), match.end(),
                    "已登记的能力/物品标签内带了句末标点；应写作" + left + core + right + "，句子标点放在括号外。")
            elif core in bare:
                add("P03", "REVIEW", match.start(), match.end(),
                    "本文也有" + left + core + right + "；确认两处是否同类标签。面板整句与标签可能合法并存。")
            elif han_count(core) <= 2:
                add("P03", "REVIEW", match.start(), match.end(),
                    "短标签内带句末标点，疑似能力名误加标点；若是系统面板句子，请在规则中登记前缀或豁免。")

    # P04 consecutive punctuation.
    for match in re.finditer("[" + PAUSES + "]{2,}", text):
        if set(match.group(0)) == {"。"} and len(match.group(0)) >= 3:
            continue  # reported as an ellipsis form below
        add("P04", "ERROR", match.start(), match.end(), "停顿或句末标点连用。")
    for match in re.finditer("[" + TERMINALS + "][”’」』][。，；]", text):
        add("P04", "REVIEW", match.start(), match.end(), "核对引文是独立话语还是句子成分，再决定引号内外标点；不能只凭相邻符号删除。")
    for match in re.finditer("[！？]{3,}", text):
        add("P04", "REVIEW", match.start(), match.end(), "连续三个以上叹号或问号，确认是否为人物声音所需。")
    for match in re.finditer("……[。，]", text):
        add("P04", "REVIEW", match.start(), match.end(), "省略号后通常不再加句号或逗号，按项目约定确认。")

    # P05 ellipsis and dash forms.
    for match in re.finditer(r"\.{3,}|。{3,}", text):
        before, after = text[max(0, match.start() - 1):match.start()], text[match.end():match.end() + 1]
        if CJK_CONTEXT.search(before + after) or match.group(0)[0] == "。":
            add("P05", "ERROR", match.start(), match.end(), "中文省略号应为“……”（两个省略号字符）。")
    for match in re.finditer("(?<!…)…(?!…)", text):
        add("P05", "REVIEW", match.start(), match.end(), "单个“…”；中文省略号通常为“……”。")
    for match in re.finditer(r"(?<![-－])(?:--+|－－+)(?![-－])", text):
        around = text[max(0, match.start() - 1):match.end() + 1]
        if CJK_CONTEXT.search(around):
            add("P05", "REVIEW", match.start(), match.end(), "疑似破折号写法；中文破折号为“——”。")

    # P06 ASCII punctuation in Chinese context; numbers, times and words exempt.
    for match in re.finditer(r"[,.;:!?()\"']", text):
        i, char = match.start(), match.group(0)
        prev = text[i - 1] if i > 0 else ""
        nxt = text[i + 1] if i + 1 < len(text) else ""
        if char == "." and (prev == "." or nxt == "."):
            continue  # handled by P05
        if char in ".,:" and prev.isdigit() and nxt.isdigit():
            continue  # 3.5, 1,000, 10:00
        if prev.isascii() and prev.isalnum() and nxt.isascii() and (nxt.isalnum() or nxt in " \n"):
            continue  # English or code
        if not (is_han(prev) or is_han(nxt) or (prev and prev in FULL_PUNCT) or (nxt and nxt in FULL_PUNCT)):
            continue
        severity = "ERROR" if char in ",.;:!?\"'" and is_han(prev) else "REVIEW"
        add("P06", severity, i, i + 1, "中文语境中出现半角“" + char + "”。")

    # P07 full-width digits and Latin letters.
    for match in re.finditer("[０-９Ａ-Ｚａ-ｚ]+", text):
        add("P07", "REVIEW", match.start(), match.end(), "全角数字或字母，确认是否与全书写法一致。")

    # P08 spaces between Chinese characters, ideographic spaces inside a line.
    for match in re.finditer("(?<=[" + HAN + "]) +(?=[" + HAN + "])", text):
        line_start = starts[locate(match.start())[0] - 1]
        if HEADING.match(text[line_start:match.start()]):
            continue  # "第一章 雾港" and Markdown headings keep their title space
        add("P08", "REVIEW", match.start(), match.end(), "汉字之间出现空格。")
    for start, para in paragraphs:
        indent = len(para) - len(para.lstrip(" \t　"))
        for match in re.finditer("　+", para[indent:]):
            pos = start + indent + match.start()
            add("P08", "REVIEW", pos, pos + len(match.group(0)), "行内出现全角空格。")

    # P09 a quote that ends without punctuation and runs straight into a speech tag.
    for left, right in rules["quote_pairs"][:1]:
        for match in re.finditer("[" + HAN + "]" + re.escape(right), text):
            opened = text.rfind(left, 0, match.start())
            if opened < 0 or "\n" in text[opened:match.start()] or (opened > 0 and is_han(text[opened - 1])):
                continue  # 把“船票”收好: a quoted term inside narration, not a spoken line
            if SPEECH_TAG.match(text[match.end():match.end() + 8]):
                add("P09", "REVIEW", match.start(), match.end(),
                    "引号内末尾没有标点就接说话人；常见写法是“……。”他说。或“……，”他说。按项目约定确认。")

    # P10 chains of very short narrative sentences inside one paragraph.
    limit, run = rules["short_chain"]["max_chars"], rules["short_chain"]["min_run"]
    quote_open = "".join(pair[0] for pair in rules["quote_pairs"])
    quote_close = "".join(pair[1] for pair in rules["quote_pairs"])
    for start, para in paragraphs:
        masked, depth = [], 0
        for char in para:
            if char in quote_open:
                depth += 1
            # Quoted speech and terms are masked with a non-Han placeholder so
            # their inner full stops do not split or shorten narrative sentences.
            masked.append("Q" if depth else char)
            if char in quote_close and depth:
                depth -= 1
        narrative = "".join(masked)
        chain = []
        for sentence in re.finditer("[^" + TERMINALS + "]+[" + TERMINALS + "]+", narrative):
            size = han_count(sentence.group(0))
            if 0 < size <= limit:
                chain.append(sentence)
                continue
            if len(chain) >= run:
                add("P10", "REVIEW", start + chain[0].start(), start + chain[-1].end(),
                    "连续%d个不超过%d字的叙述短句。检查是否把同一动作的条件—动作—结果切碎；有节奏作用可保留并写明理由。" % (len(chain), limit))
            chain = []
        if len(chain) >= run:
            add("P10", "REVIEW", start + chain[0].start(), start + chain[-1].end(),
                "连续%d个不超过%d字的叙述短句。检查是否把同一动作的条件—动作—结果切碎；有节奏作用可保留并写明理由。" % (len(chain), limit))

    # P11 runs of short one-line paragraphs. Dialogue lines, headings and lines that open with a tag
    # bracket or a registered panel prefix (an ability call-out, a system notice) are deliberate beats:
    # they are not counted and they end a run.
    limit, run = rules["short_paragraph_run"]["max_chars"], rules["short_paragraph_run"]["min_run"]
    streak = []

    def flush():
        if len(streak) >= run:
            first, last = streak[0], streak[-1]
            add("P11", "REVIEW", first[0], last[0] + len(last[1]),
                "连续%d个不超过%d字的单行段落。确认每次分段都有停顿、冲击或视线切换的作用。" % (len(streak), limit))

    for start, para in paragraphs:
        body = para.strip()
        dialogue = any(char in quote_open for char in body)  # rapid exchanges are not narrative chopping
        heading = body.startswith("#") or bool(HEADING.match(body))
        tag_line = (any(body.startswith(pair[0]) for pair in rules["tag_brackets"])
                    or any(body.startswith(prefix) for prefix in rules["panel_prefixes"]))
        if not dialogue and not heading and not tag_line and 0 < han_count(body) <= limit:
            streak.append((start, para))
        else:
            flush()
            streak = []
    flush()

    # P12 reader load of one paragraph: a long stretch of narration, or several registered
    # people acting in one paragraph. A hint about where to re-read, never a length limit.
    dense = rules["dense_paragraph"]
    people = [[entry] if isinstance(entry, str) else entry for entry in rules["characters"]]
    for start, para in paragraphs:
        body = para.strip()
        if body.startswith("#") or HEADING.match(body):
            continue
        masked, depth = [], 0
        for char in para:
            if char in quote_open:
                depth += 1
            masked.append("Q" if depth else char)
            if char in quote_close and depth:
                depth -= 1
        narrative = "".join(masked)
        size = han_count(narrative)
        clauses = sum(1 for s in re.split("[" + TERMINALS + "，；]+", narrative) if han_count(s))
        reasons = []
        if size > dense["max_chars"]:
            reasons.append("这一段叙述有%d个汉字（复核线 %d）" % (size, dense["max_chars"]))
        present = [names[0] for names in people if any(name in para for name in names)]
        if len(present) >= dense["max_people"] and clauses >= dense["min_clauses"]:
            reasons.append("一段里有%d个人物（%s）、%d个分句" % (len(present), "、".join(present), clauses))
        if reasons:
            offset = len(para) - len(para.lstrip())
            add("P12", "REVIEW", start + offset, start + offset + min(24, len(body)),
                "；".join(reasons) + "。检查动作主体、观察焦点和信息是否挤在一段里，手机上读起来负担重不重。"
                "需要时在主体或焦点转换处分段；不按字数机械切分，也不要拆成一串单行短段。")

    # P13 one stretch of speech, possibly across paragraphs, with no action or reply in between.
    speech = rules["long_speech"]
    for left, right in rules["quote_pairs"][:1]:
        for match in re.finditer(re.escape(left) + "[^" + re.escape(right) + "]*" + re.escape(right), text):
            spoken = match.group(0)
            later = [line.lstrip(" \t　") for line in spoken.split("\n")[1:]]
            if not dialogue_soft_wrap:
                if any(line.strip() and not line.startswith(left) for line in later):
                    continue  # an unclosed quote (P01), not one speech continued across paragraphs
            else:
                # Soft wraps: a line that does not reopen the quote must follow the previous line directly.
                after_blank, broken = False, False
                for line in later:
                    if not line.strip():
                        after_blank = True
                        continue
                    if after_blank and not line.startswith(left):
                        broken = True
                        break
                    after_blank = False
                if broken:
                    continue
            size = han_count(spoken)
            sentences = sum(1 for s in re.split("[" + TERMINALS + "]+", spoken) if han_count(s))
            if size > speech["max_chars"] and sentences >= speech["min_sentences"]:
                add("P13", "REVIEW", match.start(), match.start() + min(24, len(spoken)),
                    "一段连续发言%d个汉字、%d句，中间没有动作、停顿或对方的反应（复核线 %d 字）。检查信息是否一次给得太多；"
                    "需要时用动作、对方反应或分段把信息分层。同一段发言可以有多个完整句子，"
                    "不要为了换行改标点或句意。" % (size, sentences, speech["max_chars"]))

    # Exemptions are exact: rule, line and matched text must all agree.
    findings.sort(key=lambda f: (f["line"], f["column"], f["rule"]))
    active, suppressed, used = [], [], set()
    for finding in findings:
        hits = [i for i, item in enumerate(rules["ignore"])
                if item["rule"] == finding["rule"] and item["line"] == finding["line"] and item["text"] == finding["match"]]
        if hits:
            used.update(hits)
            suppressed.append(dict(finding, reasons=[rules["ignore"][i]["reason"] for i in hits]))
        else:
            active.append(finding)
    errors = sum(f["severity"] == "ERROR" for f in active)
    reviews = sum(f["severity"] == "REVIEW" for f in active)
    assign_ids(active, lambda f: "%s-L%d-C%d" % (f["rule"], f["line"], f["column"]))
    return {
        "tool": "punctuation_lint", "version": VERSION, "dialogue_soft_wrap": dialogue_soft_wrap,
        "status": "ERRORS" if errors else "REVIEW" if reviews else "NO_FLAGS",
        "counts": {"ERROR": errors, "REVIEW": reviews},
        "findings": active, "suppressed": suppressed,
        "unused_ignores": [item for i, item in enumerate(rules["ignore"]) if i not in used],
        "stats": statistics(text, rules),
        "limits": ("只检查客观格式与可定位的复核线索；REVIEW 必须由编辑逐条裁决，不能自动改句号为逗号。"
                   "统计只作同口径对照，没有通用合格比例；NO_FLAGS 不代表文笔或标点用法全部正确。"),
    }


def statistics(text, rules):
    body = "\n".join(line for line in text.splitlines() if not line.lstrip().startswith("#"))
    marks = {mark: body.count(mark) for mark in "。，、；：！？“”"}
    marks["……"] = body.count("……")
    marks["——"] = body.count("——")
    sentences = [s for s in re.split("[" + TERMINALS + "]+", body) if han_count(s)]
    paragraphs = [p for p in body.splitlines() if p.strip()]
    single = [p for p in paragraphs if len(re.findall("[" + TERMINALS + "]+", p.strip())) <= 1]
    han = han_count(body)
    return {
        "basis": "汉字=CJK统一汉字；标题行(# 开头)不计；句=按。！？切分且含汉字的片段；段=非空物理行",
        "han_characters": han, "marks": marks,
        "period_per_comma": round(marks["。"] / marks["，"], 3) if marks["，"] else None,
        "sentences": len(sentences),
        "mean_han_per_sentence": round(han / len(sentences), 2) if sentences else None,
        "paragraphs": len(paragraphs),
        "single_sentence_paragraph_share": round(len(single) / len(paragraphs), 3) if paragraphs else None,
    }


END_MARKS = re.compile("[。！？…]+")


def utterances(text, rules):
    """Quoted speech in reading order, one piece per physical line: letters-only key, end marks (and where they are),
    content, line and column. A quotation that runs over several lines -- each paragraph reopened with an opening quote,
    or lines soft-wrapped inside one quotation -- gives one piece per line, so a changed mark in its middle is seen too.
    A blank line ends a quotation that was left open."""
    left, right = rules["quote_pairs"][0]
    found, inside, offset = [], False, 0
    for number, line in enumerate(text.split("\n"), 1):
        if not line.strip():
            inside = False
        start = 0 if inside else None
        for k, char in enumerate(line):
            if char == left and start is None:
                start = k
            elif char == right and start is not None:
                found.append(speech_piece(text, offset, line, number, start, k + 1, left, right))
                start = None
        if start is not None and start < len(line):
            found.append(speech_piece(text, offset, line, number, start, len(line), left, right))
        inside = start is not None
        offset += len(line) + 1
    return found


def speech_piece(text, offset, line, number, start, end, left, right):
    piece = line[start:end]
    runs = [(offset + start + m.start(), offset + start + m.end()) for m in END_MARKS.finditer(piece)]
    content = piece[1:] if piece.startswith(left) else piece
    content = content[:-1] if content.endswith(right) else content
    return {"key": re.sub("[^" + HAN + "0-9A-Za-z]", "", piece), "content": content, "runs": runs,
            "marks": "".join(text[a:b] for a, b in runs), "line": number, "column": start + 1, "span": (start, end)}


def line_skeletons(text, found):
    """Physical lines with the end marks inside quoted speech left out, so that two versions of a line that differ
    only in those marks (including a mark added or dropped) compare equal."""
    chars = list(text)
    for item in found:
        for a, b in item["runs"]:
            chars[a:b] = [""] * (b - a)
    return "".join(chars).split("\n")


def ends_with_colon(line):
    return line.rstrip().endswith(("：", ":"))


def line_identities(text, found, skeletons):
    """What identifies each physical line when the two versions are matched (r5.3 and r5.5, review N04).

    A line that holds nothing but quoted speech does not say who speaks; the speaker is usually named on a line above
    it. Such a line is identified as follows, so that the same words said by different people stay apart when
    paragraphs move:
    - A line that ends with a colon ("陈青低声说：") introduces what follows it. It identifies the speech below it,
      directly below or after blank lines, and nothing else is needed. It never identifies the speech above it: there
      it is the next speaker's line.
    - Otherwise the nonblank line directly above identifies it (when that line is more than speech), together with the
      nonblank line directly below when that one is there too (no blank lines around: both must match).
    - The line below alone is not used. It may name this speaker ("陈青低声说。") or begin the next paragraph (the next
      speaker's line), and the program cannot tell which. Nor, alone, is a line above that directly follows another
      line with speech: it may close that speech rather than open this one.
    A speech-only line identified in none of these ways gets a key marked "words": it is told apart by its words and
    by where it stands, never by the key alone (it is no anchor and is never paired as "the same line" just because the
    key occurs once). Any other line is identified by its own text without end marks, as before. Returns the keys,
    per line whether it is such a speech-only line, and per line the row of the line that names it (None when nothing
    names it: other lines, and speech known by its words only)."""
    lines = text.split("\n")
    spans = {}
    for item in found:
        spans.setdefault(item["line"] - 1, []).append(item["span"])
    speech_only = []
    for i in range(len(skeletons)):
        outside = list(lines[i])
        for a, b in spans.get(i, []):
            outside[a:b] = [""] * (b - a)
        speech_only.append(i in spans and not re.search("[" + HAN + "0-9A-Za-z]", "".join(outside)))

    def nonblank(k):
        return 0 <= k < len(lines) and bool(lines[k].strip())

    keys, namers = [], []
    for i, skeleton in enumerate(skeletons):
        if not speech_only[i]:
            keys.append(skeleton)
            namers.append(None)
            continue
        if not nonblank(i - 1):
            nearest = next((k for k in range(i - 1, -1, -1) if lines[k].strip()), None)
            if nearest is not None and not speech_only[nearest] and ends_with_colon(lines[nearest]):
                keys.append(("speech", skeletons[nearest], skeleton, None))
                namers.append(nearest)
            else:
                keys.append(("words", None, skeleton, None))
                namers.append(None)
            continue
        above = i - 1
        if ends_with_colon(lines[above]):
            keys.append(("speech", skeletons[above], skeleton, None))
            namers.append(above)
            continue
        below = i + 1 if nonblank(i + 1) and not ends_with_colon(lines[i + 1]) else None
        # The line above names nobody for sure when it is speech itself, or when, alone, it directly follows a line
        # with speech (it may close that speech).
        unsure = speech_only[above] or (below is None and nonblank(above - 1) and (above - 1) in spans)
        keys.append(("words" if unsure else "speech", skeletons[above], skeleton,
                     skeletons[below] if below is not None else None))
        namers.append(None if unsure else above)
    return keys, speech_only, namers


def blank_key(key):
    return isinstance(key, str) and not key.strip()


SENTENCES = re.compile("[^。！？；…]*[。！？；…]+")
SPEECH_VERB = re.compile("(?:说|问|道|喊|答|叫|嚷|嘟囔|应)(?:了|着)?$")


def letters(text):
    return re.sub("[^" + HAN + "0-9A-Za-z]", "", text)


def attributions(line, spans):
    """The narration that belongs to each quote of one physical line, letters only (r5.10, review of r5.9).

    Taking every letter outside the quotes gave the quotes of one line one narration ("岳宁说：“走吧？”方澈说：“走吧。”":
    "岳宁说方澈说" for both), so when the line was split in two and the two people traded places, nothing told them
    apart and the fallback paired them in order. Now the text in front of the first quote goes with it, the text after
    the last quote with that one, and the text between two quotes is shared out:
    - when the quote before it was introduced by a colon ("岳宁说：“…”"), all of it leads into the next quote;
    - otherwise a first sentence that is a speech tag ("岳宁低声说。") closes the quote before it, and the rest leads into
      the next one ("方澈说：", "方澈点了点头。");
    - a first sentence that is no tag leads into the next quote when the quote before it has narration in front of it
      already ("岳宁点了点头。“…”方澈点了点头。“…”"); with nothing in front of that quote ("“…”岳宁笑了笑。“…”") it may
      close it or open the next one, and both get it; so does a clause ending in a comma with nothing before it
      ("“走吧，”岳宁说，“我们走。”": one speaker).
    A quote left with no letters of its own (two quotes in a row) gets the letters of the whole line, as before."""
    spans = sorted(spans)
    front, back = [line[:spans[0][0]]] + [""] * (len(spans) - 1), [""] * (len(spans) - 1) + [line[spans[-1][1]:]]
    for k in range(len(spans) - 1):
        gap = line[spans[k][1]:spans[k + 1][0]]
        if front[k].rstrip().endswith(("：", ":")):
            front[k + 1] = gap
            continue
        sentences = SENTENCES.findall(gap)
        rest = gap[len("".join(sentences)):]
        if not sentences:
            back[k], front[k + 1] = (rest, rest) if rest.rstrip().endswith(("，", ",")) else ("", rest)
        elif SPEECH_VERB.search(letters(sentences[0])):
            back[k], front[k + 1] = sentences[0], gap[len(sentences[0]):]
        elif letters(front[k]):
            front[k + 1] = gap  # the quote before has narration in front of it already ("甲点了点头。“…”")
        else:
            back[k], front[k + 1] = sentences[0], gap
    outside = list(line)
    for a, b in spans:
        outside[a:b] = [""] * (b - a)
    whole = letters("".join(outside))
    return [letters(front[k] + back[k]) or whole for k in range(len(spans))]


def by_context(olds, news):
    """Pair two equally long lists of same-word utterances by how alike their lines are (ties: nearest in order).

    Lines are compared by their narration -- the letters outside the quotes -- when they have any (r5.9, review of r5.8):
    whole lines are most alike by layout, so "罗峻低声说：“走吧”" looked more like "许平低声说：“走吧”" (0.8) than like
    "“走吧”罗峻低声说。" (0.5), and the fallback agreed with an order that paired two people's words."""
    ranked = []
    for p, old in enumerate(olds):
        for q, new in enumerate(news):
            ratio = SequenceMatcher(None, old.get("narration") or old["context"], new.get("narration") or new["context"],
                                    autojunk=False).ratio()
            ranked.append((-ratio, abs(p - q), p, q))
    ranked.sort()
    chosen, used = {}, set()
    for _, _, p, q in ranked:
        if p not in chosen and q not in used:
            chosen[p] = q
            used.add(q)
    return [chosen[p] for p in range(len(olds))]


def by_narration(olds, news, spare):
    """Pairs of same-word utterances told apart by their own narration (r5.10, review of r5.9): a narration found once
    among the original utterances and once among the revised ones pairs those two -- the same speaker, however the
    lines were split, merged or moved ("岳宁说：“走吧？”方澈说：“走吧。”" against "方澈说：“走吧？”" / "岳宁说：“走吧。”").
    When that leaves one utterance on each side, the last two pair as well (one on each side pairs directly, as
    everywhere) unless spare(x, y) says no -- a line of nothing but these words whose words another such line says too
    (which of them is which is not in the text). Returns all pairs, or None when any utterance is left otherwise; the
    order is then weighed as before."""
    count_a = Counter(x["narration"] for x in olds)
    count_b = Counter(y["narration"] for y in news)
    sure = [(x, y) for x in olds for y in news if x["narration"] and x["narration"] == y["narration"]
            and count_a[x["narration"]] == 1 and count_b[y["narration"]] == 1]
    left_a = [x for x in olds if all(x is not p for p, _ in sure)]
    left_b = [y for y in news if all(y is not q for _, q in sure)]
    if not sure or len(left_a) > 1 or (left_a and not spare(left_a[0], left_b[0])):
        return None
    return sure + list(zip(left_a, left_b))


LETTER_RUNS = re.compile("[" + HAN + "0-9A-Za-z]+")


def moved_text(old, new, others_a, others_b):
    """Text that moved between lines, seen from the change of one line from `old` to `new`: whether some text that left
    `old` stands in a line of `others_b` (the revision), and whether some text that came into `new` stands in a line of
    `others_a` (the original). Text counts as a changed run of letters, or any two letters in a row of a longer run,
    because a name runs together with reworded words ("秦照低声说。" -> "黎渔压低嗓子说。": “黎渔压” is one run). Single
    letters of a longer run do not count -- they would match common words everywhere."""
    gone, came = [], []
    for tag, a1, a2, b1, b2 in SequenceMatcher(None, old, new, autojunk=False).get_opcodes():
        if tag in ("replace", "delete"):
            gone += LETTER_RUNS.findall(old[a1:a2])
        if tag in ("replace", "insert"):
            came += LETTER_RUNS.findall(new[b1:b2])

    def stands(parts, lines):
        lines = list(lines)
        for part in parts:
            pieces = [part] + [part[k:k + 2] for k in range(len(part) - 1)] if len(part) > 2 else [part]
            if any(piece in line for piece in pieces for line in lines):
                return True
        return False

    return stands(gone, others_b), stands(came, others_a)


def exchanged(old, new, others_a, others_b):
    """Whether the change of a line from `old` to `new` is explained by text moving between changed lines (moved_text),
    from either side. r5.8, review of r5.6: "秦照低声说。" -> "黎渔低声说。" while "黎渔低声说：“…”" -> "秦照低声说：“…”"
    is two people trading places, not one line reworded in place. One side is enough: the person who left may be gone
    from the revision, or the one who came may have been named nowhere in the original. A one-letter name run together
    with reworded words still passes as a rewrite when the person who left is nowhere else."""
    gone, came = moved_text(old, new, others_a, others_b)
    return gone or came


def traded(olds, news):
    """Whether pairing the same words in order (olds[k] with news[k]) puts two people's lines together: in some pair,
    text that left the original line's narration stands in the narration of another line of the group in the revision,
    AND text that came into the revised line stood in another line of the group in the original (r5.9, review of r5.8:
    "罗峻低声说：“走吧？”" and "“走吧。”许平低声说。" traded places, each place keeping its layout, and a verb that
    belongs to the place -- "压低嗓子说" -- can still make the wrong lines the most alike). Both halves are needed here,
    unlike in exchanged: the speaker lines of the same words share their verbs ("低声说"), and one shared letter would undo
    every order in which two speaker lines were reworded where they stand; by_context, which compares the narration,
    already refuses the orders that only one half would show."""
    for k, (old, new) in enumerate(zip(olds, news)):
        others_a = [x["narration"] for n, x in enumerate(olds) if n != k]
        others_b = [y["narration"] for n, y in enumerate(news) if n != k]
        gone, came = moved_text(old["narration"], new["narration"], others_a, others_b)
        if gone and came:
            return True
    return False


def rewritten_in_place(opcodes, keys_a, keys_b, lines_a, lines_b, limit=90000):
    """Replaced lines taken as rewritten in place, original row -> revised row (r5.5, review of r5.4: any replaced run
    of the same length was taken as rewritten in place, so a speaker line that had moved seemed to be the rewrite of
    the one now in its slot).

    A line of a replaced run of the same length is the rewrite of the line in its slot only when nothing else explains
    the change: its old text is gone from the revision, its new text was not in the original, and the two are more
    alike than either is to any other line that changed. A tie explains nothing (r5.6, review of r5.5): speaker lines
    that differ only in the name ("乙低声说：", "丁低声说：", "乙低声说。") or repeated words look just as much like
    several lines, and taking the one in the slot paired one person's words with another's. Nor does text that moved
    (r5.8, review of r5.6; exchanged): when what the line lost now stands in another changed line, or what it gained
    came from one, people traded places and each place kept its layout, and the words next to the line are another
    person's now. A moved speaker line fails the first test; a moved and reworded one usually fails the third. Lines
    merged into one fail the last test too (what came in stood on its own line before). With more than `limit` pairs
    of changed lines to weigh, no line is taken as rewritten (the comparison then flags more, it never passes more)."""
    rewritten = {}
    in_a, in_b = set(keys_a), set(keys_b)
    changed_a = [i for tag, i1, i2, _, _ in opcodes if tag != "equal"
                 for i in range(i1, i2) if not blank_key(keys_a[i])]
    changed_b = [j for tag, _, _, j1, j2 in opcodes if tag != "equal"
                 for j in range(j1, j2) if not blank_key(keys_b[j])]
    weigh = len(changed_a) * len(changed_b) <= limit

    def closer(fixed, others, score, fixed_first):
        for other in others:
            matcher = SequenceMatcher(None, fixed, other, autojunk=False) if fixed_first else \
                SequenceMatcher(None, other, fixed, autojunk=False)
            if matcher.real_quick_ratio() >= score and matcher.quick_ratio() >= score and matcher.ratio() >= score:
                return True
        return False

    for tag, i1, i2, j1, j2 in opcodes:
        if tag != "replace" or i2 - i1 != j2 - j1 or not weigh:
            continue
        for i, j in zip(range(i1, i2), range(j1, j2)):
            if blank_key(keys_a[i]) or blank_key(keys_b[j]) or keys_a[i] in in_b or keys_b[j] in in_a:
                continue
            score = SequenceMatcher(None, lines_a[i], lines_b[j], autojunk=False).ratio()
            if closer(lines_a[i], (lines_b[q] for q in changed_b if q != j), score, True) or \
                    closer(lines_b[j], (lines_a[p] for p in changed_a if p != i), score, False):
                continue
            if exchanged(lines_a[i], lines_b[j], (lines_a[p] for p in changed_a if p != i),
                         (lines_b[q] for q in changed_b if q != j)):
                continue
            rewritten[i] = j
    return rewritten


def match_utterances(original, revised, rules):
    """Match the dialogue of two versions one to one (r5.2, review N01: a repeated line could hide a changed mark;
    r5.3, review N04: the same words said by different people were paired across speakers when paragraphs moved;
    r5.5, review of r5.4: the same when a blank line stands between the speaker line and the words; r5.6, review of
    r5.5: the same when the speaker lines moved from above the words to below them; r5.8, review of r5.6: the same
    when speech written inline is mixed with speaker lines and two people trade places, each place keeping its layout;
    r5.9, review of r5.8: the same when both speakers are named on the line of the words, one in front, one after;
    r5.10, review of r5.9: the same when two people speak on one line and the revision splits it, or merges two lines
    into one, and they trade places).

    Every line has an identity (line_identities): its own text without end marks; for a line that holds nothing but
    quoted speech, the line that names its speaker (a colon line above it, across blank lines too) or else the line of
    narration directly above it. A speech-only line named in none of these ways is known by its words only ("words"
    keys): such a key is no anchor and pairs nothing by itself, unless each of its quotes is said exactly once in each
    version, counting every utterance -- inline speech and every quote of a line holding several (r5.8).
    1. Identities are aligned with their neighbours. An equal run is anchored when it contains an identity that occurs
       exactly once in each version. A line of an anchored run pairs in place ("same_line") when an anchor of the run
       (or the start of both texts) is above it and one (or the end of both texts) below it. Repeated lines line up
       with an offset just as well as in place -- N04's “知道了” of two different people did exactly that -- so
       whatever is not fenced in like this is left for the next steps.
    2. Lines left over with the same identity on both sides pair when it occurs once on each side ("moved_line", or
       "same_line" when it still stands between the same lines), and so do copies of one line whose marks are all the
       same (no pairing among them can show a change). Every other line left over pairs only by place: the same words
       between lines that correspond to the lines around it in the original, and named the same way in both versions
       -- by lines that correspond, or by no line at all (r5.6: when speaker lines move to the other side of the words,
       the same place holds another person's words). Lines correspond when one is an anchor and the other its
       namesake, when both are fenced in place in an anchored run, or when one is the other rewritten in place
       (rewritten_in_place); a pair that rests on such an assumed rewrite is marked "in_place". Such a pair is not
       taken for words said a different number of times in the two versions (r5.9): one of those lines is new or gone,
       and it may be the very line taken as rewritten -- a speaker line given another name may be someone else's words
       moved in, the first speaker's line cut -- so a changed mark would vanish without a word.
       Marks that read the same in order prove nothing: r5.4 took them as evidence, and a swap of two people with
       changed marks passed unreported.
    3. The remaining utterances pair by their words: one on each side pairs directly; equally many on each side pair
       in order when pairing by the most alike lines gives the same result ("changed_line"). Not for speech-only
       lines: their own text is the same words, so "most alike" would only be position again. Lines are compared by
       their narration, the letters outside the quotes, so the layout ("罗峻低声说：“…”" or "“…”罗峻低声说。") does not
       outweigh the speaker; and an order in which people traded lines (traded) is not taken (r5.9). Each quote has
       a narration of its own when a line holds several (attributions), and before any order is weighed, a narration
       found once on each side pairs those words, the last ones left pairing by elimination (by_narration; r5.10):
       one narration for the whole line made two people on it indistinguishable once the line was split.
    4. Everything else with the same words but different marks cannot be paired reliably: those revised utterances
       are returned as uncertain, never taken as unchanged, with the reason -- the count changed ("count_changed"),
       the two ways of pairing disagree ("order_unclear"), the order would pair lines whose speakers traded places
       ("crossed"), the lines and their neighbours do not tell the speakers apart ("indistinct"), two quotes of one
       line have one narration ("same_narration": none of their own, so the whole line's, while the narration
       elsewhere differs -- when every narration is the same, one person speaks throughout; r5.10), or there are too
       many repeats to pair ("too_many").
    """
    olds, news = utterances(original, rules), utterances(revised, rules)
    lines_a, lines_b = line_skeletons(original, olds), line_skeletons(revised, news)
    keys_a, alone_a, named_a = line_identities(original, olds, lines_a)
    keys_b, alone_b, named_b = line_identities(revised, news, lines_b)
    by_a, by_b = {}, {}
    for items, keys, alone, by in ((olds, keys_a, alone_a, by_a), (news, keys_b, alone_b, by_b)):
        for item in items:
            row = item["line"] - 1
            key = keys[row]
            item["context"] = "\n".join(part for part in key[1:] if part is not None) if isinstance(key, tuple) else key
            item["alone"] = alone[row]
            by.setdefault(row, []).append(item)
    # The narration of each utterance: the letters outside the quotes that belong to it (r5.9: who speaks is in there,
    # wherever the quote stands; the layout is not). A line holding several quotes shares its narration out among them
    # (r5.10, attributions): one narration for all made two people on one line indistinguishable.
    for items, text in ((olds, original), (news, revised)):
        rows = text.split("\n")
        on_line = {}
        for item in items:
            on_line.setdefault(item["line"], []).append(item)
        for number, here in on_line.items():
            here.sort(key=lambda item: item["span"])
            for item, narration in zip(here, attributions(rows[number - 1], [item["span"] for item in here])):
                item["narration"] = narration
    count_a, count_b = Counter(keys_a), Counter(keys_b)
    # How often each set of words is said, counted over every utterance: inline speech ("黎渔低声说：“知道了？”") and
    # every quote of a line holding several count too (r5.8, review of r5.6: counting speech-only lines alone took
    # “知道了” for unique although 黎渔 said it inline, and paired 秦照's words with 黎渔's).
    said_a = Counter(item["key"] for item in olds)
    said_b = Counter(item["key"] for item in news)
    spoken = {}
    for keys, by in ((keys_a, by_a), (keys_b, by_b)):
        for row, items in by.items():
            if isinstance(keys[row], tuple):
                spoken[keys[row][2]] = tuple(item["key"] for item in items)

    def identifying(key):
        """Whether a key can stand for one line: any line's own text, a speech named by the line above it, and a speech
        known only by its words when each of its quotes is said exactly once in each version, anywhere."""
        if blank_key(key):
            return False
        if not (isinstance(key, tuple) and key[0] == "words"):
            return True
        words = spoken.get(key[2], ())
        return bool(words) and all(w and said_a[w] == 1 and said_b[w] == 1 for w in words)

    def anchor(key):
        return identifying(key) and count_a[key] == 1 and count_b[key] == 1

    def neighbours(keys):
        """Nearest nonblank line above and below each line (None at the edges of the text)."""
        up, down, last = [None] * len(keys), [None] * len(keys), None
        for i, key in enumerate(keys):
            up[i], last = last, (i if not blank_key(key) else last)
        last = None
        for i in range(len(keys) - 1, -1, -1):
            down[i], last = last, (i if not blank_key(keys[i]) else last)
        return up, down

    up, down = neighbours(keys_a)
    up_b, down_b = neighbours(keys_b)
    opcodes = SequenceMatcher(None, keys_a, keys_b, autojunk=False).get_opcodes()
    runs = {}
    for tag, i1, i2, j1, j2 in opcodes:
        pins = [i for i in range(i1, i2) if anchor(keys_a[i])] if tag == "equal" else []
        if pins:
            runs[i1] = (i1, i2, j1, j2, pins)
    first_a = next((i for i, key in enumerate(keys_a) if not blank_key(key)), len(keys_a))
    first_b = next((j for j, key in enumerate(keys_b) if not blank_key(key)), len(keys_b))
    last_a = max((i for i, key in enumerate(keys_a) if not blank_key(key)), default=-1)
    last_b = max((j for j, key in enumerate(keys_b) if not blank_key(key)), default=-1)

    def held(i, run):
        """A line of an anchored equal run stays in place when it is fenced in within the run: an anchor of the run (or
        the start of both texts) above it, and one (or the end of both texts) below it. Otherwise the run may have slid
        over a moved paragraph -- repeated lines line up with an offset just as well -- pairing one person's words
        with another's (r5.3; r5.5: the fence must be an anchor, not just any line of the run)."""
        i1, i2, j1, j2, pins = run
        above = pins[0] <= i or (first_a >= i1 and first_b >= j1)
        below = pins[-1] >= i or (last_a < i2 and last_b < j2)
        return above and below

    # Which revised line each original line reliably stands for: an anchor wherever it now is, a line held in an
    # anchored run, a line rewritten in place. Nothing else counts as "the same place" (r5.5: equal runs of repeated
    # lines and replaced runs of the same length can line up by coincidence).
    rewritten = rewritten_in_place(opcodes, keys_a, keys_b, lines_a, lines_b)
    where = dict(rewritten)
    anchors_b = {key: j for j, key in enumerate(keys_b) if anchor(key)}
    where.update((i, anchors_b[key]) for i, key in enumerate(keys_a) if anchor(key))
    for run in runs.values():
        i1, i2, j1 = run[:3]
        for i in range(i1, i2):
            if not blank_key(keys_a[i]) and held(i, run):
                where.setdefault(i, j1 + i - i1)

    def same_surroundings(i, j):
        return all((p is None and q is None) or (p is not None and where.get(p) == q)
                   for p, q in ((up[i], up_b[j]), (down[i], down_b[j])))

    def placed(i):
        """How a pair that stands between corresponding lines got there: "same_line", or "in_place" when one of those
        lines is an assumed rewrite."""
        return "in_place" if any(p in rewritten for p in (up[i], down[i])) else "same_line"

    pairs, loose_a, loose_b = [], [], []
    for tag, i1, i2, j1, j2 in opcodes:
        anchored = tag == "equal" and i1 in runs
        for offset in range(i2 - i1) if anchored else ():
            i, j = i1 + offset, j1 + offset
            if i not in by_a:
                continue
            if held(i, runs[i1]):
                pairs.extend((x, y, "same_line") for x, y in zip(by_a[i], by_b.get(j, [])))
            else:
                loose_a.append(i)
                loose_b.extend([j] if j in by_b else [])
        if not anchored:
            loose_a.extend(i for i in range(i1, i2) if i in by_a)
            loose_b.extend(j for j in range(j1, j2) if j in by_b)
    moved_a, moved_b = {}, {}
    for i in loose_a:
        moved_a.setdefault(keys_a[i], []).append(i)
    for j in loose_b:
        moved_b.setdefault(keys_b[j], []).append(j)
    used_a, used_b = set(), set()
    for key, rows_a in moved_a.items():
        rows_b = moved_b.get(key, [])
        # The same identity once on each side: the same line, moved or still in its place. Copies of one line (the same
        # identity several times on each side) whose marks are all the same: no pairing among them can show a change.
        marks = {tuple(x["marks"] for x in by[r]) for by, rows in ((by_a, rows_a), (by_b, rows_b)) for r in rows}
        if not identifying(key) or len(rows_a) != len(rows_b) or (len(rows_a) > 1 and len(marks) > 1):
            continue
        for i, j in zip(rows_a, rows_b):
            how = placed(i) if same_surroundings(i, j) else "moved_line"
            pairs.extend((x, y, how) for x, y in zip(by_a[i], by_b[j]))
            used_a.add(i)
            used_b.add(j)
    # Every other line left over pairs only by place: the same words between lines that correspond to the lines around
    # it in the original. Only one nonblank line can stand between two given lines, so this pairs one to one. Marks that
    # read the same in order prove nothing (r5.5: that once let a swap of two people with changed marks pass).
    # The words must also be named the same way in both versions: by lines that correspond, or by no line at all
    # (r5.6, review of r5.5). When the speaker lines move to the other side of the words ("孟迟低声说：" above becomes
    # "孟迟低声说。" below), the slot between two speaker lines holds the next person's words: same place, other speaker.
    def named_alike(i, j):
        p, q = named_a[i], named_b[j]
        return (p is None and q is None) or (p is not None and where.get(p) == q)

    slots = {(up_b[j], down_b[j]): j for j in loose_b if j not in used_b}
    for i in loose_a:
        if i in used_a or any(p is not None and p not in where for p in (up[i], down[i])):
            continue
        j = slots.get((where.get(up[i]), where.get(down[i])))
        if j is None or j in used_b or lines_a[i] != lines_b[j] or not named_alike(i, j):
            continue
        if placed(i) == "in_place" and any(said_a[x["key"]] != said_b[x["key"]] for x in by_a[i]):
            continue  # r5.9: an assumed rewrite next to words that are new or gone somewhere
        pairs.extend((x, y, placed(i)) for x, y in zip(by_a[i], by_b[j]))
        used_a.add(i)
        used_b.add(j)
    # Lines of nothing but quoted words, counted per words: when another such line says the same words, nothing in
    # the text tells which is which, and none of them pairs by elimination (by_narration).
    lone_a = Counter(item["key"] for item in olds if item["alone"])
    lone_b = Counter(item["key"] for item in news if item["alone"])

    def spare(x, y):
        return not ((x["alone"] and lone_a[x["key"]] > 1) or (y["alone"] and lone_b[y["key"]] > 1))

    rest_a, rest_b = {}, {}
    for i in loose_a:
        for item in by_a[i] if i not in used_a else []:
            if item["key"]:
                rest_a.setdefault(item["key"], []).append(item)
    for j in loose_b:
        for item in by_b[j] if j not in used_b else []:
            if item["key"]:
                rest_b.setdefault(item["key"], []).append(item)
    unsure = []
    for key, ys in rest_b.items():
        xs = rest_a.get(key, [])
        if not xs or len({x["marks"] for x in xs + ys}) == 1:
            continue  # new words, or nothing that could have changed
        if len(xs) != len(ys):
            reason = "count_changed"
        elif len(xs) == 1:
            pairs.extend((x, y, "changed_line") for x, y in zip(xs, ys))
            continue
        elif len(xs) * len(ys) > 400:
            reason = "too_many"
        elif (named := by_narration(xs, ys, spare)):
            pairs.extend((x, y, "changed_line") for x, y in named)
            continue
        elif any(item["alone"] for item in xs + ys):
            reason = "indistinct"
        elif any(len({(x["line"], x["narration"]) for x in side}) < len(side) for side in (xs, ys)) and \
                len({x["narration"] for x in xs + ys}) > 1:
            reason = "same_narration"  # two quotes of one line that their narration cannot tell apart (r5.10)
        elif by_context(xs, ys) != list(range(len(xs))):
            reason = "order_unclear"
        elif traded(xs, ys):
            reason = "crossed"
        else:
            pairs.extend((x, y, "changed_line") for x, y in zip(xs, ys))
            continue
        unsure.extend((xs, ys, y, reason) for y in ys if any(x["marks"] != y["marks"] for x in xs))
    return pairs, unsure


def compare_texts(original, revised, rules=None, dialogue_soft_wrap=None):
    """What a revision introduced: new findings, resolved findings, changed end marks in the same line of dialogue.

    Findings are matched by rule and matched text, not by position, so moving a paragraph does not count as new.
    Both versions are linted in the same quotation mode.
    """
    checked = load_rules(rules)
    before = lint_text(original, rules, dialogue_soft_wrap)
    after = lint_text(revised, rules, dialogue_soft_wrap)

    def key(finding):
        return finding["rule"], re.sub(r"\s+", "", finding["match"])

    def surplus(findings, other):
        available, seen, extra = Counter(key(f) for f in other), Counter(), []
        for finding in findings:
            seen[key(finding)] += 1
            if seen[key(finding)] > available[key(finding)]:
                extra.append(finding)
        return extra

    introduced, resolved = surplus(after["findings"], before["findings"]), surplus(before["findings"], after["findings"])
    pairs, unsure = match_utterances(original, revised, checked)
    where = {"same_line": "", "moved_line": "（这一段换了位置）", "changed_line": "（这一段的叙述也改过）",
             "in_place": "（按原位置对应：紧挨着的一行改写过，程序假定那是原地改写，不是别处挪来的）"}
    tone = []
    for old, new, how in pairs:
        if old["marks"] == new["marks"]:
            continue
        before_marks, after_marks = old["marks"] or "（无）", new["marks"] or "（无）"
        tone.append({"line": new["line"], "column": new["column"], "before": before_marks, "after": after_marks,
                     "original": old["content"], "revised": new["content"], "original_line": old["line"], "match": how,
                     "message": "同一句对白的句末标点由“%s”改成“%s”%s，语气或句类可能变了（比如疑问变陈述、叹号变平叙）。"
                                "确认这是有意的改动。" % (before_marks, after_marks, where[how])})
    why = {"count_changed": "原稿里出现 %d 次，修订稿里出现 %d 次",
           "order_unclear": "两版都出现 %d 次，但所在的段落改过叙述，按先后次序对和按上下文对，结果不一样",
           "crossed": "两版都出现 %d 次，所在的几行改过叙述，一行去掉的说法出现在另一行、另一行原来的说法出现在这一行，"
                      "像是说话人换了位置，按先后次序对不可靠",
           "indistinct": "两版都出现 %d 次，这几行只有引号里的话；程序只凭上方以冒号结尾的说话行或紧挨着的上一行认人，"
                         "在这里分不出是谁说的哪一句（比如段落挪了位置）",
           "same_narration": "两版都出现 %d 次，其中几句在同一行，行里的叙述分不出各是谁说的，按先后次序对不可靠",
           "too_many": "两版都出现 %d 次，重复太多，不逐句对应"}
    for olds, news, new, reason in unsure:
        seen = "、".join(dict.fromkeys(x["marks"] or "（无）" for x in olds))
        where_seen = "，".join("第 %d 行句末“%s”" % (x["line"], x["marks"] or "（无）") for x in olds[:6])
        where_seen += "等 %d 处" % len(olds) if len(olds) > 6 else ""
        counts = (len(olds), len(news)) if reason == "count_changed" else (len(olds),)
        tone.append({"line": new["line"], "column": new["column"], "before": seen, "after": new["marks"] or "（无）",
                     "original": olds[0]["content"], "revised": new["content"],
                     "original_lines": [x["line"] for x in olds], "match": "uncertain", "uncertain_reason": reason,
                     "message": "这句对白在原稿里出现过（%s）；%s，程序对不上这一处原来是哪一句。"
                                "请对照原稿确认这里的句末标点和语气有没有改。" % (where_seen, why[reason] % counts)})
    # One line can hold several utterances: the id names the line AND the column of the opening quote, so each change
    # needs its own decision (r5 review F01: line-only ids collided).
    tone.sort(key=lambda t: (t["line"], t["column"]))
    assign_ids(tone, lambda t: "TONE-L%d-C%d" % (t["line"], t["column"]))
    errors = sum(f["severity"] == "ERROR" for f in introduced)
    reviews = sum(f["severity"] == "REVIEW" for f in introduced) + len(tone)
    return {"tool": "punctuation_lint", "mode": "compare", "version": VERSION,
            "dialogue_soft_wrap": after["dialogue_soft_wrap"],
            "status": "INTRODUCED_ERRORS" if errors else "REVIEW" if reviews else "NO_NEW_FLAGS",
            "counts": {"ERROR": errors, "REVIEW": reviews},
            "introduced": introduced, "resolved": resolved, "tone_changes": tone,
            "stats": {"before": before["stats"], "after": after["stats"]},
            "limits": ("只比较两版的格式问题和对白句末标点：修改稿新出现的问题、原稿已有而修改后消失的问题。"
                       "对白一一对应着比：先按整行对齐（挪了位置的段落也找得回来），再按同样的话对应改过叙述的段落；"
                       "一行里有几个人说话、修订时拆成几行或几行并成一行的，各句按各自的说话人叙述对应；"
                       "只有台词的一行，按上方以冒号结尾的说话行认人（隔着空行也算），其次是紧挨着的上一行，"
                       "只写在下一行的说话人不认；"
                       "同一句话重复出现、程序确定不了哪句对哪句的，标为“对不上”（uncertain）请人核对。"
                       "修复目标是否达成、语义和因果有没有变，仍要编辑对照两版判断；统计只作同口径对照。")}


def render_text(report):
    lines = ["%s  %s  ERROR=%d REVIEW=%d" % (report.get("file", "-"), report["status"],
                                            report["counts"]["ERROR"], report["counts"]["REVIEW"])]
    for f in report["findings"]:
        lines.append("  L%d:C%d [%s %s %s] %s —— %s" % (f["line"], f["column"], f["severity"], f["rule"],
                                                     f["name"], f["context"], f["message"]))
    s = report["stats"]
    lines.append("  统计（口径：%s）：汉字%d，句号%d，逗号%d，句数%d，平均句长%s，单句段占比%s" % (
        s["basis"], s["han_characters"], s["marks"]["。"], s["marks"]["，"], s["sentences"],
        s["mean_han_per_sentence"], s["single_sentence_paragraph_share"]))
    return "\n".join(lines)


def utf8_stdio():
    """Reports are UTF-8 on every platform; a Windows pipe would otherwise use the local code page."""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("manuscript", type=Path, nargs="+")
    parser.add_argument("--rules", type=Path, help="project JSON: ability_tags, panel_prefixes, ignore ...")
    parser.add_argument("--format", choices=("json", "text"), default="json")
    parser.add_argument("--baseline", type=Path, help="original text; report only what the revised manuscript introduced")
    parser.add_argument("--dialogue-soft-wrap", action="store_true", default=None,
                        help="opt in for this run: consecutive physical lines inside one unclosed quote are the author's "
                             "soft wraps (a rules file can declare dialogue_soft_wrap: true instead)")
    args = parser.parse_args()
    if args.baseline:
        if len(args.manuscript) != 1:
            print(json.dumps({"status": "INPUT_ERROR", "error": "--baseline compares exactly one revised manuscript"},
                             ensure_ascii=False))
            return 2
        try:
            rules_bytes = args.rules.read_bytes() if args.rules else None
            rules = json.loads(rules_bytes.decode("utf-8")) if rules_bytes is not None else None
            original, revised = args.baseline.read_bytes(), args.manuscript[0].read_bytes()
            report = compare_texts(original.decode("utf-8-sig"), revised.decode("utf-8-sig"), rules,
                                   args.dialogue_soft_wrap)
        except (OSError, UnicodeError, ValueError, TypeError) as exc:
            print(json.dumps({"status": "INPUT_ERROR", "error": str(exc)}, ensure_ascii=False))
            return 2
        report.update(baseline=str(args.baseline), baseline_sha256=hashlib.sha256(original).hexdigest(),
                      file=str(args.manuscript[0]), sha256=hashlib.sha256(revised).hexdigest(),
                      rules_file=str(args.rules) if args.rules else None,
                      rules_sha256=hashlib.sha256(rules_bytes).hexdigest() if rules_bytes is not None else None)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 1 if report["counts"]["ERROR"] else 0
    try:
        rules_bytes = args.rules.read_bytes() if args.rules else None
        rules = json.loads(rules_bytes.decode("utf-8")) if rules_bytes is not None else None
        load_rules(rules)
        reports = []
        for path in args.manuscript:
            data = path.read_bytes()
            report = lint_text(data.decode("utf-8-sig"), rules, args.dialogue_soft_wrap)
            report.update(file=str(path), sha256=hashlib.sha256(data).hexdigest(),
                          rules_file=str(args.rules) if args.rules else None,
                          rules_sha256=hashlib.sha256(rules_bytes).hexdigest() if rules_bytes is not None else None)
            reports.append(report)
    except (OSError, UnicodeError, ValueError, TypeError) as exc:
        print(json.dumps({"status": "INPUT_ERROR", "error": str(exc)}, ensure_ascii=False))
        return 2
    if args.format == "text":
        print("\n".join(render_text(r) for r in reports))
    else:
        print(json.dumps(reports[0] if len(reports) == 1 else reports, ensure_ascii=False, indent=2))
    return 1 if any(r["counts"]["ERROR"] for r in reports) else 0


if __name__ == "__main__":
    sys.exit(main())

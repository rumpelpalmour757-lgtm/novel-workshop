#!/usr/bin/env python3
"""r5.22: each decision accounts for its own change, at the place its old words stood.

The 10-19 review of r5.20 (P2-G520-01, still in r5.21): the same sentence R stood on both sides of a paragraph A that
stays, and both copies were cut. One decision quoting "R + A -> A" (the left cut with the paragraph it sat beside)
covered both cuts, because r5.20 let a cut count for any change whose old words held the cut text and whose new words
stood beside the cut, on either side; and r5.16-r5.21 counted any cut that touched the edge of a decision's words.
r5.19 refused the left-only record; r5.20 and r5.21 recorded PASS.

Now the change decisions are done to the version recorded before, each at its place (a cut's old words must occur
there once; a change with new words stands where its old words occur once, or where its new words came from, traced
back through the edit; places that give the same text, in a run of repeats, count as one) and each with its own edit
only (the words it quotes around its change are not cut by it). What is left between that and the candidate needs words
a decision keeps or gives in the candidate: a cut strictly inside them (wherever over repeated words the diff put it),
or on their edge when the cut is part of the same sentence (no line break; no 。！？ in a cut of words); punctuation
alone may sit beside a decision's edit. A whole sentence or paragraph cut beside a decision's words needs a decision of
its own. Material is invented test data, not literary judgment.
"""

import hashlib
import json
import os
import re
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
GUARD = ROOT / "skills" / "novel-workshop" / "scripts" / "workflow_guard.py"
DIMENSIONS = ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function", "continuity",
              "revision_comparison")
P1 = "雨停以后，阿禾把木箱放在门边，解开麻绳，取出几只旧瓷碗。"
P2 = "老沈拿来报纸，把桌上的碗一只只包好，码进竹筐，又在筐底垫了一层稻草。"
P3 = "天黑以后，两人抬着竹筐回屋，灯芯剪过一次，屋里亮了些。"
R = "他把竹筐放在门口。"
A = "阿禾关好木窗，把灯芯拨亮了些。"
EVIDENCE = ("雨停以后，阿禾把木箱", "把桌上的碗一只只包好", "灯芯剪过一次，屋里亮了些")
NOTE = "测试数据：只验证记录结构"


def body(*paragraphs):
    return "\n\n".join(paragraphs) + "\n"


def change(before, after, **extra):
    return dict({"decision": "change", "before": before, "after": after, "judgment": NOTE, "reason": NOTE}, **extra)


def keep(quote, **extra):
    return dict({"decision": "keep", "quote": quote, "judgment": NOTE, "reason": NOTE}, **extra)


class Steps(unittest.TestCase):
    """Start a strict run, record a PASS on the old text, edit it, record reviews of the edit."""

    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.dir)

    def write(self, name, text):
        (self.dir / name).write_bytes((text).encode("utf-8"))

    def guard(self, *args):
        proc = subprocess.run([sys.executable, "-I", "-B", str(GUARD), *args], cwd=self.dir, capture_output=True,
                              text=True, encoding="utf-8")
        try:
            return proc.returncode, json.loads(proc.stdout)
        except ValueError:
            return proc.returncode, {"raw": proc.stdout[-400:], "stderr": proc.stderr[-400:]}

    def review(self, name, text, decisions):
        value = {"schema": "editorial-review/2", "verdict": "PASS",
                 "candidate_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                 "reviewer": {"mode": "self_check", "label": NOTE}, "checked_against": ["测试数据"], "inputs_read": [],
                 "evidence": [{"quote": q, "in": "candidate"} for q in EVIDENCE], "issues": [], "machine_dispositions": [],
                 "counter_evidence": "测试数据，不是真实文学审稿。",
                 "dimensions": [{"id": key, "status": "met", "note": NOTE} for key in DIMENSIONS],
                 "expression": {"scope": "chapter", "decisions": decisions, "segments": [
                     {"from": text[:8], "to": text.rstrip()[-8:], "note": "测试数据：从头连读到尾，逐句看过改动和前后句"}]}}
        self.write(name, json.dumps(value, ensure_ascii=False))
        return name

    def edit_after_pass(self, old, new):
        self.write("draft.md", old)
        self.write("checks.json", json.dumps({"candidate": "draft.md", "mode": "strict", "checks": [
            {"id": "ending", "type": "contains", "text": "灯芯剪过一次"}]}, ensure_ascii=False))
        self.assertEqual(self.guard("start", "run.json", "--task-id", "t", "--spec", "checks.json")[0], 0)
        code, out = self.guard("record", "run.json", "--event-id", "v1", "--review", self.review("v1.json", old, []))
        self.assertEqual(code, 0, out)
        self.write("draft.md", new)
        self.assertEqual(self.guard("reserve", "run.json", "--event-id", "r1")[0], 0)

    def record(self, event, text, decisions):
        return self.guard("record", "run.json", "--event-id", event, "--review", self.review(event + ".json", text, decisions))

    def refused(self, out, low, high):
        """Refused, and the place it names is the cut no decision covers: a line between low and high."""
        self.assertEqual(out.get("failure"), "REVIEW_INCOMPLETE", out)
        line = int(re.search(r"Candidate line (\d+) changed", out["message"]).group(1))
        self.assertTrue(low <= line <= high, (line, out["message"]))


class DeletionPlaces(Steps):
    def test_the_same_sentence_cut_on_both_sides_of_a_paragraph_needs_both_sides(self):
        # The case of the review: old P1 / R / A / R / P2 / P3, new P1 / A / P2 / P3.
        old, new = body(P1, R, A, R, P2, P3), body(P1, A, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change(R + "\n\n" + A, A)])  # the left cut only
        self.refused(out, 4, 5)  # the right cut: after A (line 3), before P2 (line 5)
        code, out = self.record("v3", new, [change(A + "\n\n" + R, A)])  # the right cut only
        self.refused(out, 2, 3)  # the left cut: after P1, where A now begins
        code, out = self.record("v4", new, [change(R + "\n\n" + A, A), change(A + "\n\n" + R, A)])
        self.assertEqual(code, 0, out)

    def test_one_decision_that_quotes_both_cuts_is_enough(self):
        old, new = body(P1, R, A, R, P2, P3), body(P1, A, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change(R + "\n\n" + A + "\n\n" + R, A)])
        self.assertEqual(code, 0, out)

    def test_the_same_inside_one_line(self):
        line = R + A + R
        old, new = body(P1, line, P2, P3), body(P1, A, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change(R + A, A)])
        self.refused(out, 3, 3)
        code, out = self.record("v3", new, [change(R + A, A), change(A + R, A)])
        self.assertEqual(code, 0, out)

    def test_a_cut_the_diff_shifts_into_the_words_that_stay_is_still_tied_to_its_own_place(self):
        # The words that stay ("门口。") are also the end of the cut sentence, so the diff keeps the first copy's end and
        # reports the second cut as "门口。" + R: part of it stood inside the left decision's old words. Every word of a
        # cut must have stood inside some decision's old words, so the left decision alone does not cover it.
        stay = "门口。"
        line = R + stay + R
        old, new = body(P1, line, P2, P3), body(P1, stay, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change(R + stay, stay)])
        self.refused(out, 3, 3)
        code, out = self.record("v3", new, [change(R + stay, stay), change(stay + R, stay)])
        self.assertEqual(code, 0, out)

    def test_a_kept_paragraph_does_not_cover_the_paragraph_cut_beside_it(self):
        old, new = body(P1, R, A, P2, P3), body(P1, A, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [keep(A)])
        self.refused(out, 2, 3)
        code, out = self.record("v3", new, [keep(A), change(R, "")])
        self.assertEqual(code, 0, out)

    def test_old_words_that_occur_twice_are_placed_by_where_their_new_words_came_from(self):
        # R + A stood twice; both R were cut. The decisions quote the same old words, each pinned (offset) to its A.
        old, new = body(P1, R, A, P2, R, A, P3), body(P1, A, P2, A, P3)
        first, second = new.index(A), new.rindex(A)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change(R + "\n\n" + A, A, offset=first)])
        self.refused(out, 6, 7)  # the second cut: after P2 (line 5), where the second A now begins (line 7)
        code, out = self.record("v3", new, [change(R + "\n\n" + A, A, offset=first),
                                            change(R + "\n\n" + A, A, offset=second)])
        self.assertEqual(code, 0, out)

    def test_a_rewrite_the_diff_splits_into_an_insertion_and_a_cut_at_its_edge_is_still_one_change(self):
        # "补了也白补" -> "这缝就白补了": the diff matches "补了", inserts before it and cuts after it; the cut sits on
        # the edge of the kept words and is part of the same sentence.
        old_line, new_line = "林舟说木楔吃不准，补了也白补。", "林舟说木楔吃不准，这缝就白补了。"
        old, new = body(P1, old_line, P2, P3), body(P1, new_line, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [keep("这缝就白补了")])
        self.assertEqual(code, 0, out)

    def test_a_whole_sentence_cut_beside_kept_words_in_the_same_line_needs_its_own_decision(self):
        old, new = body(P1, A + R, P2, P3), body(P1, A, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [keep(A)])
        self.refused(out, 3, 3)
        code, out = self.record("v3", new, [keep(A), change(R, "")])
        self.assertEqual(code, 0, out)

    def test_a_cut_of_punctuation_only_on_the_edge_of_kept_words_is_part_of_that_sentence(self):
        # Dropping the full stop after a sentence the review keeps: punctuation only, no words of a sentence of its own.
        old, new = body(P1, A + "灯光照到了门槛上", P2, P3), body(P1, A[:-1] + "灯光照到了门槛上", P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [keep(A[:-1])])
        self.assertEqual(code, 0, out)

    SAID = "他说：“好。”她说：“好。”他走了。"
    CUT = "她说：“好。”"

    def test_a_cut_the_diff_puts_elsewhere_in_repeated_words_is_the_same_cut(self):
        # The second speaker's line is cut. The diff may report the cut as "说：“好。”她", which leaves the same words: a
        # cut moves over text that stays and repeats, so it still stands where the decision's old words stood. r5.21
        # accepted this record; the first r5.22 build refused it.
        old, new = body(P1, self.SAID, P2, P3), body(P1, self.SAID.replace(self.CUT, ""), P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change(self.CUT, "")])
        self.assertEqual(code, 0, out)

    def test_the_same_cut_quoted_with_the_words_after_it(self):
        old, new = body(P1, self.SAID, P2, P3), body(P1, self.SAID.replace(self.CUT, ""), P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change(self.CUT + "他走了。", "他走了。")])
        self.assertEqual(code, 0, out)

    def test_two_copies_cut_and_one_decision_is_still_refused(self):
        # Both copies of the repeated line are cut; the one decision quotes the second copy with the words after it.
        said = "他说：“好。”" + self.CUT + self.CUT + "他走了。"
        old, new = body(P1, said, P2, P3), body(P1, "他说：“好。”他走了。", P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change(self.CUT + "他走了。", "他走了。")])
        self.refused(out, 3, 3)
        code, out = self.record("v3", new, [change(self.CUT + self.CUT + "他走了。", "他走了。")])
        self.assertEqual(code, 0, out)

    def test_ordinary_cuts_still_pass(self):
        # A cut quoted with the words that stay (inside a line, and a whole paragraph); a cut of a clause quoted without
        # its comma (as in the r5.20 test); a deleted comma inside a rewritten clause. Unchanged paragraphs stand
        # between the edits, so that each edit is a change of its own.
        x, y = "院里的水还没退，木箱底下垫着两块砖。", "隔壁的狗叫了两声，又趴回门槛上。"
        z = "灶上的水壶响了一阵，又没了声音。这一夜没有再下雨。"
        old = body(P1, x, R, y, P2, z, P3)
        new = body(P1.replace("解开麻绳，", ""), x, y, P2.replace("，又在筐底垫了一层稻草。", "。"), z,
                   P3.replace("天黑以后，", "天黑以后"))
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change("放在门边，解开麻绳，", "放在门边，"), change("两块砖。\n\n" + R, "两块砖。"),
                                            change("又在筐底垫了一层稻草", ""),
                                            change("天黑以后，两人抬着竹筐回屋", "天黑以后两人抬着竹筐回屋")])
        self.assertEqual(code, 0, out)


class EachDecisionIsDoneAtItsPlace(Steps):
    """The change decisions are done to the version recorded before, each at its place, and what is left between
    that and the candidate needs words a decision keeps or gives around it. Found by the maker's own random check of
    r5.22 (repro/r5.22/fuzz_*.py in the personal edition's maintenance folder): r5.21 and the first r5.22 build let a
    decision whose old words keep a sentence cover a copy of that sentence cut next door, and let a cut beside a
    decision's new words count as inside them when the two share a full stop."""

    W = "她说：“好。”"
    D = "他说：“好。”"

    def test_a_decision_that_keeps_a_sentence_does_not_cover_its_copy_cut_next_door(self):
        # Two copies of the line; one is cut, and so is the paragraph after them. The paragraph's decision quotes the
        # copy that stays as its context; it does not account for the other copy.
        old, new = body(P1, self.W + self.W, "风停了。", P2, P3), body(P1, self.W, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change(self.W + "\n\n风停了。", self.W)])
        self.refused(out, 3, 3)
        code, out = self.record("v3", new, [change(self.W + "\n\n风停了。", self.W), change(self.W + self.W, self.W)])
        self.assertEqual(code, 0, out)

    def test_a_cut_beside_new_words_is_not_inside_them_because_they_share_a_full_stop(self):
        # "门口。" is cut after "好。", the new words of the other decision. The diff may report the cut as "。门口",
        # inside "好。"; the same cut ends at the edge of those words, so it is not inside them.
        old, new = body(P1, "风停了。好。门口。好。他走了。", P2, P3), body(P1, "好。好。他走了。", P2, P3)
        first = new.index("好。")
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change("风停了。好。", "好。", offset=first)])
        self.refused(out, 3, 3)
        code, out = self.record("v3", new, [change("风停了。好。", "好。", offset=first),
                                            change("好。门口。好。", "好。好。")])
        self.assertEqual(code, 0, out)

    def test_two_decisions_in_a_run_of_repeats_each_take_their_own_copy(self):
        # Three copies, two cut. The decisions quote overlapping words; done as the diff gives them, both would cut the
        # same copy, so the second takes the same cut moved over the repeated words.
        old, new = body(P1, self.W * 3, P2, P3), body(P1, self.W, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change(self.W + self.W, self.W), change(self.W + self.W + "\n\n", self.W + "\n\n")])
        self.assertEqual(code, 0, out)

    def test_old_words_in_a_run_of_repeats_need_no_more_context(self):
        # The old words stand twice, overlapping; done at either place they give the same text.
        line = "门口。门口。门口。" + self.W
        old, new = body(P1, line, P2, P3), body(P1, line[3:], P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change("门口。门口。", "门口。", offset=new.index("门口。"))])
        self.assertEqual(code, 0, out)

    def test_a_cut_in_a_run_of_repeats_needs_no_more_context(self):
        # Three copies of the line side by side, two cut: the cut words stand twice (overlapping), and whichever two
        # copies the decision means, the text is the same.
        old, new = body(P1, self.W * 3 + "他走了。", P2, P3), body(P1, self.W + "他走了。", P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change(self.W * 2, "")])
        self.assertEqual(code, 0, out)

    def test_old_words_at_two_places_are_done_at_one_and_the_rest_still_needs_a_decision(self):
        # "门口。门口。" stands twice (overlapping) in a run of three; one copy was rewritten and another cut. The
        # rewrite's decision is done at one copy; the cut still needs its own (r5.21 let the rewrite's new words
        # cover both, the diff having joined them into one change).
        old, new = body(P1, "门口。门口。门口。好。", P2, P3), body(P1, "门外。门口。好。", P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change("门口。门口。", "门外。门口。")])
        self.refused(out, 3, 3)  # the cut has no decision of its own
        code, out = self.record("v3", new, [change("门口。门口。", "门外。门口。"), change("门口。门口。好。", "门口。好。")])
        self.assertEqual(code, 0, out)

    def test_old_words_at_overlapping_places_stand_where_the_edit_kept_the_new_words(self):
        # Three copies, the middle one rewritten. The decision quotes it with the copy after it; those old words also
        # stand as the first two copies. The copy whose words the edit kept as the new ones is its place.
        old, new = body(P1, R * 3, P2, P3), body(P1, R + R.replace("门口", "门外") + R, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change(R + R, R.replace("门口", "门外") + R)])
        self.assertEqual(code, 0, out)

    def test_a_decision_tied_between_two_places_is_still_done_at_one(self):
        # The new words keep nothing of the old ones, so they do not tell which of two overlapping copies was
        # rewritten; the decision is done at the first. The third copy was cut as well and needs a decision of its
        # own (left out, the decision's new words would have covered that cut too, the diff having joined them).
        old, new = body(P1, "门口。门口。门口。好。", P2, P3), body(P1, "柴房好。", P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change("门口。门口。", "柴房")])
        self.refused(out, 3, 3)
        code, out = self.record("v3", new, [change("门口。门口。门口。", "柴房")])
        self.assertEqual(code, 0, out)

    def test_a_cut_and_a_rewrite_in_the_next_sentence_stay_two_changes(self):
        # Three copies of a sentence: one cut, the next rewritten. Character by character the diff joins the cut and
        # the rewrite into one change inside the new sentence, which a keep of that sentence would cover; compared
        # sentence by sentence first, they stay two.
        rewritten = A.replace("关好", "关上")
        old, new = body(P1, A * 3 + "门口。", P2, P3), body(P1, A + rewritten + "门口。", P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [keep(rewritten)])
        self.refused(out, 3, 3)
        code, out = self.record("v3", new, [keep(rewritten), change(A + A, A, offset=new.index(A))])
        self.assertEqual(code, 0, out)

    def test_two_cuts_that_both_quote_the_line_break_between_them_are_one_cut(self):
        # The second copy of the line and the paragraph after it are cut; each decision quotes the line break
        # between them, so their edits overlap there and are done as one cut.
        old, new = body(P1, self.W + self.W, A, P2, P3), body(P1, self.W, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change(self.W + self.W + "\n\n", self.W), change(self.W + "\n\n" + A, self.W)])
        self.assertEqual(code, 0, out)

    def test_a_keep_does_not_stretch_over_the_blank_line_it_quotes(self):
        # "门口。" before A is cut and "风停了。" after it rewritten as "门口。". The keep quotes the new words with the
        # blank line after them; the cut the diff puts just before that blank line is on the edge of the words, not
        # inside them.
        old, new = body(P1, self.D + "门口。" + A + "风停了。", P2, P3), body(P1, self.D + A + "门口。", P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [keep(A + "门口。\n\n")])
        self.refused(out, 3, 3)
        code, out = self.record("v3", new, [keep(A + "门口。\n\n"), change("门口。" + A, A)])
        self.assertEqual(code, 0, out)

    def test_the_same_change_quoted_twice_is_done_once(self):
        old, new = body(P1, R, P2, P3), body(P1, R.replace("门口", "门外"), P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change(R, R.replace("门口", "门外")), change("竹筐放在门口。", "竹筐放在门外。")])
        self.assertEqual(code, 0, out)


class TheNotesSaySo(unittest.TestCase):
    def test_execution_notes_say_where_a_cut_counts(self):
        notes = (ROOT / "skills" / "novel-workshop" / "references" / "execution.md").read_text(encoding="utf-8")
        line = next(l for l in notes.splitlines() if "同一行里改了几处、相邻几行一起改了，各要一条" in l)
        for phrase in ("只算它所引的旧文字原来所在的那一处", "一条记录只算它自己改掉的字", "两边各要一条", "整句或整段", "r5.22"):
            self.assertIn(phrase, line)


if __name__ == "__main__":
    unittest.main()

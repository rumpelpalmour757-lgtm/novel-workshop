"""Integration contracts for the installed, project-neutral dialogue tool.

All names and text below are synthetic fixtures, unrelated to any user project.
The tests establish structural behavior, not literary editing effectiveness.
"""
import contextlib
import copy
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

INSTALL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(INSTALL))
import dialogue_antipatterns
import dialogue_core
import voice_lint
from dialogue_antipatterns import scan_dialogue_antipatterns
from patch_guard import apply_dialogue_patch, build_patch_request
from run_lint import config_values, main
from voice_lint import analyze_voice_and_idioms


def project_config():
    return {
        'profiles': {
            '许澄': {'archetype': 'cold', 'min_avg_len': 5,
                   'min_colloquial_rate': 0.1, 'voice_prompt': '只作测试参考。'},
            '乔宁': {'archetype': 'folksy_warm', 'min_avg_len': 8,
                   'min_colloquial_rate': 0.2, 'voice_prompt': '只作测试参考。'},
        },
        'aliases': {'小澄': '许澄'},
        'cold_protagonist_names': ['许澄'],
    }


class InstalledDefaultsTests(unittest.TestCase):
    def test_tests_import_the_actual_installation(self):
        for module in (dialogue_core, dialogue_antipatterns, voice_lint):
            self.assertEqual(Path(module.__file__).resolve().parent, INSTALL)

    def test_generic_defaults_are_empty_and_do_not_attribute_named_text(self):
        self.assertEqual(voice_lint.VOICEPRINT_REGISTRY, {})
        self.assertEqual(dialogue_antipatterns.DEFAULT_NAMES, ())
        config, profiles, overrides = config_values(None)
        self.assertEqual((config, profiles, overrides), ({}, {}, {}))
        text = ['许澄说：“在门后头。”']
        result = dialogue_core.extract_dialogues(text)
        self.assertEqual((result[0].speaker, result[0].confidence), ('未知', 'unknown'))
        report, issues = analyze_voice_and_idioms(text)
        self.assertEqual(report['未知']['台词数'], 0)
        self.assertEqual(issues, [])
        self.assertEqual(scan_dialogue_antipatterns(text), [])
        style = scan_dialogue_antipatterns(text, include_style_hints=True)
        self.assertTrue(any(i.rule_id == 'COMP_04_COORDINATE_REPLY' for i in style))
        self.assertEqual(build_patch_request(text, style)['items'], [])

    def test_cold_exemption_requires_confirmed_speaker_and_does_not_hide_other_rules(self):
        text = ['许澄说：“在门后头。”', '许澄站在门边，乔宁说：“在门后头。”',
                '“在门后头。”', '许澄说：“挺挡咬。”']
        issues = scan_dialogue_antipatterns(text, ('许澄',), names=('许澄', '乔宁'),
                                          include_style_hints=True)
        coordinate = [i for i in issues if i.rule_id == 'COMP_04_COORDINATE_REPLY']
        self.assertEqual([(i.para_index, i.speaker) for i in coordinate], [(2, '乔宁'), (3, '未知')])
        self.assertTrue(any(i.para_index == 4 and i.rule_id == 'SYN_01_DEGREE_ACT_VERB' for i in issues))

    def test_manual_confirmation_can_enable_cold_exemption(self):
        text = ['“在门后头。”']
        issues = scan_dialogue_antipatterns(text, ('许澄',), names=('许澄',),
                   speaker_overrides={(1, 1): '许澄'}, include_style_hints=True)
        self.assertFalse(any(i.rule_id == 'COMP_04_COORDINATE_REPLY' for i in issues))

    def test_scope_guard_rejects_expanded_range_and_unrequested_quote(self):
        text = ['乔宁说：“挺挡咬。”她放下书。许澄说：“留在这儿。”']
        issues = scan_dialogue_antipatterns(text, names=('许澄', '乔宁'))
        req = build_patch_request(text, issues)
        response = {'source_hash': req['source_hash'], 'replacements': [
            {'quote_id': 'p1:q2', 'original': '留在这儿。', 'replacement': '先走。'}]}
        with self.assertRaises(ValueError):
            apply_dialogue_patch(text, req, response)
        forged = copy.deepcopy(req)
        forged['items'][0]['end'] += len('”她放下书。')
        response['replacements'] = []
        with self.assertRaises(ValueError):
            apply_dialogue_patch(text, forged, response)
        self.assertEqual(text, ['乔宁说：“挺挡咬。”她放下书。许澄说：“留在这儿。”'])


class InstalledCLITests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / 'chapter.txt'
        self.config = self.root / 'project.json'
        self.config.write_text(json.dumps(project_config(), ensure_ascii=False), encoding='utf-8')

    def invoke(self, args):
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            code = main(args)
        return code, out.getvalue(), err.getvalue()

    def test_cli_default_scan_is_read_only_and_yields_no_confirmed_patch(self):
        original = '乔宁说：“挺挡咬。”她放下书。\r\n\r\n'
        self.source.write_bytes(original.encode())
        request = self.root / 'request.json'
        code, output, error = self.invoke(['scan', str(self.source), '--request-output', str(request)])
        self.assertEqual((code, error), (0, ''))
        payload = json.loads(output)
        self.assertEqual(payload['summary']['dialogue_quotes'], 1)
        self.assertFalse(payload['summary']['style_hints_enabled'])
        self.assertEqual(payload['dialogues'][0]['confidence'], 'unknown')
        self.assertEqual(json.loads(request.read_text(encoding='utf-8'))['items'], [])
        self.assertEqual(self.source.read_bytes(), original.encode())

    def test_cli_explicit_project_config_scan_and_apply_preserve_scope_and_crlf(self):
        original = '小澄说：“在门后头。”\r\n\r\n乔宁说：“挺挡咬。”她放下书。\r\n'
        self.source.write_bytes(original.encode())
        report, request, prompt = [self.root / p for p in ('report.json', 'request.json', 'prompt.txt')]
        code, _, error = self.invoke(['scan', str(self.source), '--config', str(self.config),
             '--output', str(report), '--request-output', str(request), '--prompt-output', str(prompt)])
        self.assertEqual((code, error), (0, ''))
        payload = json.loads(report.read_text(encoding='utf-8'))
        req = json.loads(request.read_text(encoding='utf-8'))
        self.assertEqual(payload['dialogues'][0]['speaker'], '许澄')
        self.assertEqual(payload['dialogues'][0]['confidence'], 'explicit')
        self.assertEqual(len(req['items']), 1)
        self.assertEqual(req['items'][0]['quote_id'], 'p3:q1')
        self.assertEqual(len(req['items'][0]['issues']), 2)
        self.assertIn(req['source_hash'], prompt.read_text(encoding='utf-8'))
        response = self.root / 'response.json'
        response.write_text(json.dumps({'source_hash': req['source_hash'], 'replacements': [{
            'quote_id': 'p3:q1', 'original': '挺挡咬。', 'replacement': '还能挡一挡。'}]}, ensure_ascii=False), encoding='utf-8')
        target = self.root / 'revised.txt'
        code, _, error = self.invoke(['apply', str(self.source), str(request), str(response), '--output', str(target)])
        self.assertEqual((code, error), (0, ''))
        self.assertEqual(target.read_bytes(), original.replace('挺挡咬。', '还能挡一挡。').encode())
        self.assertEqual(self.source.read_bytes(), original.encode())

    def test_cli_style_hints_and_project_exemptions_are_explicit(self):
        self.source.write_text('许澄说：“在门后头。”\n乔宁说：“在门后头。”\n', encoding='utf-8')
        code, output, error = self.invoke(['scan', str(self.source), '--config', str(self.config), '--style-hints'])
        self.assertEqual((code, error), (0, ''))
        payload = json.loads(output)
        issues = [i for i in payload['antipattern_issues'] if i['rule_id'] == 'COMP_04_COORDINATE_REPLY']
        self.assertEqual([(i['para_index'], i['speaker']) for i in issues], [(2, '乔宁')])
        self.assertTrue(payload['summary']['style_hints_enabled'])

    def test_cli_output_collision_and_duplicate_json_do_not_modify_existing_files(self):
        self.source.write_text('乔宁说：“先关门。”', encoding='utf-8')
        output = self.root / 'report.json'
        output.write_text('keep me', encoding='utf-8')
        self.assertEqual(self.invoke(['scan', str(self.source), '--output', str(output)])[0], 2)
        self.assertEqual(output.read_text(encoding='utf-8'), 'keep me')
        self.config.write_text('{"aliases": {}, "aliases": {}}', encoding='utf-8')
        self.assertEqual(self.invoke(['scan', str(self.source), '--config', str(self.config)])[0], 2)
        self.assertEqual(self.source.read_text(encoding='utf-8'), '乔宁说：“先关门。”')

    def test_cli_rejects_foreign_or_stale_patch_without_creating_output(self):
        self.source.write_text('乔宁说：“挺挡咬。”她放下书。', encoding='utf-8')
        request = self.root / 'request.json'
        self.assertEqual(self.invoke(['scan', str(self.source), '--config', str(self.config), '--request-output', str(request)])[0], 0)
        req = json.loads(request.read_text(encoding='utf-8'))
        response = self.root / 'response.json'
        response.write_text(json.dumps({'source_hash': 'stale', 'replacements': []}), encoding='utf-8')
        target = self.root / 'revised.txt'
        self.assertEqual(self.invoke(['apply', str(self.source), str(request), str(response), '--output', str(target)])[0], 2)
        self.assertFalse(target.exists())
        self.assertEqual(self.source.read_text(encoding='utf-8'), '乔宁说：“挺挡咬。”她放下书。')

    def test_cli_runs_as_subprocess_from_installed_script(self):
        self.source.write_text('乔宁说：“好。”', encoding='utf-8')
        result = subprocess.run([sys.executable, str(INSTALL / 'run_lint.py'), 'scan', str(self.source)],
                                cwd=INSTALL, capture_output=True, text=True, encoding='utf-8', check=False)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)['summary']['dialogue_quotes'], 1)


if __name__ == '__main__':
    unittest.main()

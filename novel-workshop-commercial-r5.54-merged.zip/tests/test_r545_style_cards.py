#!/usr/bin/env python3
"""r5.45: style cards (card set 4.1.0), identified per scene and loaded as directions only (references/style-cards.md).

The author sent the card set 4.1.0 (83 cards in four layers: base, voice, device, scene), said it is the most complete,
and asked that it be wired in and replace the set r5.43 had taken in. The library keeps the cleaned cards; which cards
a scene gets is the writer's judgment against the index, and the script only lists literal hints, so these tests check
what the code does: the library validates and the checker catches broken libraries and configs; text removed in
cleaning (famous lines, names of one work, the private book's phrases, memes, private-list words; kept here only as
SHA-256 digests) does not come back; match lists literal hits and never invents a card (no hit, no card, unless a book's
config names a default the author decided); an excluded card is not offered or loaded; load takes at most what the card
set allows per layer, refuses cards marked as not going together, follows the set's order, applies a card's overrides
of the global part, and renders examples as illustrations rather than replace orders; copied finds a card's own wording
in a draft; and the files reach the personal and the sale exports. The wording of the reference is not mirrored here.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
SCRIPT = SKILL / "scripts" / "style_cards.py"
LIBRARY = SKILL / "assets" / "style-cards" / "cards.json"
# What cleaning took out of the author's cards (length, sha256): table entries, " / " alternatives, list items, cut
# stretches and dropped lines or examples, and (r5.50) the deck's old words in the composition rule. Filled from the
# cleaning decisions (maintenance records of the personal build).
REMOVED = (
    (3, "0e43bfe278f7b213637e09fb6e7043eeec55e57643545d799cb33bd3a99d81ff"),
    (3, "1d1f24f794f1d3f06d2000a6671492d495860de5964e97fd177483b2208b7570"),
    (3, "2330cfc72e0c278c7a56fc6d958f3a672a1e7365f39e99741c426e55933b41c8"),
    (3, "65c61945f102b3617b131d517f40d275344e71fe7224ae0b2c0c4130763440a7"),
    (3, "680062519b3a1a43a31ea711d0a80e98285e415003cac27063f314c76cf1803e"),
    (3, "80e5aae0ce1a411c580cf0ba37de68728915806e4dff2e9cd3f33daaeb811ffe"),
    (3, "863c345738ddb2c6608ab2e9de3b5e61030d9f1e63df702d392ea1b3db6e44b8"),
    (3, "a44e2b69f065c764873f7f617c3754f45daa9110c6de5fdd9494507405ba5a23"),
    (3, "d0c3b0436f3246a3ebd84c7c1bdb83d31cbe33283aadbe0f390c6390122c0d35"),
    (3, "d43e1490f9aee038398e2fef3b568278fa238c9b5521f936cbcbea5abfc1a5b7"),
    (3, "f3f81f427403bffe3f97128dff8557ea57e9647ee434b77287908952d35d03b6"),
    (3, "f59c697d9900fc14efc6a86af3af740554b542b704cfc47db72b4730370857ee"),
    (3, "f9ee71e4059a3458db2d74b26db1e23440cc3099887a6d76ed0b94427bb39ad8"),
    (4, "0b36d0cace7caa8459d7e881eac755c952aeeee1755637b219cf35ba68cbed0e"),
    (4, "1b1020d85125092b3364f6569fd32d839cd0e7a6702c85bd70a4f963a77a9efd"),
    (4, "287875477627213a0b5d40ec8c63f88fd97cd86351852ecc6b7d8eb3fd1be7bc"),
    (4, "319ec8b3ea3070879f71418455897a158db05c286e645c4f869b8fa934352fec"),
    (4, "3a12f169573e7ceac52e83e9f2c5a2d421226e4b92e8abfe584562e600496f54"),
    (4, "3e538c09d5c15268debfeaba8fe92899b62b23a4753c13b0966749a85b62c187"),
    (4, "3f88eaae5f49cfa3dccc47615a2bb4b15486594d6350d9e9064a72c97f0e588d"),
    (4, "4257b5ae667ef340a44be2e85a2901f41177373afab9cbb370f5108430a8030e"),
    (4, "447a703dd5783daaa5131ea9f0709c57f50febf8b0f1f0235a0670da140ca50b"),
    (4, "451a00230c99461a5cada640ee7a567dfdc9a1d07d94404cdb6b2136da4a22ca"),
    (4, "4545cd52344ebc4804abbfe3e60d8b350d0ac17f0766429a7d909830b1f9785d"),
    (4, "46ff60d2090b6d7b74a561aeaac3cbab7ac309a71efa83e7caefcd8a040fb439"),
    (4, "4b846a4207ba8abba5c3d2d77979bdd06d604ee3091adaa63376b6700c81da05"),
    (4, "6e2dab5480b463241ed7910fd884c5a91261d6aba7df892e70c3e72d25263ae0"),
    (4, "7316137b870789f33a32d5eca7a006ee21888c4c513415feb79fbf84a68879cf"),
    (4, "868eb737378ff7067b1b4cfdf8582467ba1bbc095329bf9238f8e4faaca7ab89"),
    (4, "8daa45af4efde9522063055a3dfe7ecb407e789b842ddf21cf85f53bb278e806"),
    (4, "9651e9b37a411c31907eeb0898952cd78fdca4188c5dddb36d00b6e15bea91a6"),
    (4, "98a4fd45b65efaafecba68d9e203a4fa39597845e044b5eca05c127bbf75b40e"),
    (4, "a0f820b6de0a4da72484ecd61d952f39973ba89b91418774afc23097b4f641be"),
    (4, "aba3bfb4182fc9ef8d571966162162dff5670ac2fc7b3530da5070105b1c916d"),
    (4, "aeae75ef7b727fcf7166b6e9cb788b84e9d7e98dc4cb9d73870e33f4e5fc2d17"),
    (4, "b66f393dcd3040c69b0d73a52194932f99415e605cb8f3a62db2ff4f08f3fa1d"),
    (4, "bf7c96f914b97e92804b04ab09b7599729f3a0a73ddea215153d3667e0a5e099"),
    (4, "c3a8eb2a5841ca50f96c1ddc77ae2471eef1fa5a440e70aedf07173359917ec6"),
    (4, "cff1c39f259fd7a383d999b98148d1a69afa6455b96d7ba18b0be5f57aa1f480"),
    (4, "d6ab102a92639ee7f48c3789b9d10925b5c1e4efcddf855127ca152e005a6b0e"),
    (4, "e2e7d8a5fa8c6bafe9eae9ae54eb73ccbaf740c3bdeeddd8ace38c7f135f88b7"),
    (4, "e34b4cfc085a940034221c13c4169e089c3dcbb37c43992052bba6cf0d74ddc1"),
    (4, "e6730d19ca93b44e15e8bd1ff76720e101789034cfa3442216255ffd90069e1d"),
    (4, "f12fe435b7bd08688a6cdbe411cbd9146d3ad4d41e88465bdcac55d6b73b439c"),
    (4, "fc996257f0db05bb2113b2788f870adbe69cd4d6345ba707d88f41e7d8eab948"),
    (5, "06639b8798de06a8a985d89e6262e09ff7b462e153899ea561b83b932caadf76"),
    (5, "13bc5781f28db874b88fa579448386a6b9217eaba14afbf4c9f3bfe031898642"),
    (5, "1b1f82eec994b16d2ed1a8febea769128457edf1136668d1243a7f9a800e4ccd"),
    (5, "565ae1be9aadff8a5c0e9aff700097069eb18bb78a73e889becdb852062f5961"),
    (5, "607d2080574885eaca4bf7ff50931f01856359a3503e5a1ab457c55ce29224ca"),
    (5, "6c34579d59c26422ebf9324e375c15b95c93597f363c11f3d4308ffe6f53806a"),
    (5, "6e1803fafce88ed6d9739dc5d002abdbe97b1b96e4e0ee956bfc33a5e104903c"),
    (5, "7d666bb41134a6ab258f94308cfea0cff95f0a9c5a621100bd168e5652055b83"),
    (5, "841721a8764d19a1a5e348134829fa838c04ba5875c1bc39563c27811655e36e"),
    (5, "91a1cc3a6ee983a26e6a5ad804bbc03161bd4b4bcaebba15fb0296e942bc9265"),
    (5, "ba7382c88d4597ce07e0b9f1573a48b006f6055efd709a1841eed925583cf9cd"),
    (5, "c24e3e3ee29382f1104c5be9d2eb34d6857a947a61b165d423b17fa0599a2333"),
    (5, "ca2439cc3174eacc1775ae796bd0b4677f9d1a243b08d565c3e2e36cd4223d50"),
    (5, "cb1fd17ea4db3c1a152f9d83d7de5420eb3141999fcd02988c72e5fd978c23ae"),
    (5, "ce578ddcc20d87833b936fa850453e11b633e102c49bf48acde8334ef3b8e1cf"),
    (5, "d3706d65abc49f7ea4f89b3533b9c324c535be1ad6fcd73bff1ba35e2399b9f6"),
    (5, "d551be6b4910394e20370d1cd607c9e21d883663d3e8fd54d2cc336938b3a874"),
    (6, "08bacefae20226b2dea006d979eab5075389802fc1c8fde304268de8ca8e3d35"),
    (6, "0bbbb07b0699447da1e5ca1d89f8a5a8a9abe0631e93eef6b996f04684f8183f"),
    (6, "0ed19547731d49a3784f162932b97e6a1da113a425c29dc94b621ece61b382b9"),
    (6, "29d9a145c6b0451703319cde6d37a3ded85ea3ff9a20db4217695be5de89ab38"),
    (6, "2e89b86d3445ebf1e24aa6bfb8d79572eec3f287254a3585128a5cebc524a7a0"),
    (6, "4348512683f0f019ba5e2437044b11a2b3387570f841627d2a4b4a8b20562f14"),
    (6, "4babe6de7ec1a2d0a3b562cfe6ef5c1ff192d6a8989f65142363e649c6802692"),
    (6, "5915f3f514ee17716483fe32966e06d20021b78fa5b2a0450f963195cb249835"),
    (6, "6c7fed01a7d164520230c84c83ca1467c0428228fe3ae95506e242010466f222"),
    (6, "6f01f2207160f8de3e318303aab01892e9b74024c2003814348dd169ef46846f"),
    (6, "79d901eddb0d0dccd800af30ac81b19138bca21248dd6b7e35b70031f089409e"),
    (6, "a2fcc5931b5c8be85456cc89281c58041619446823f0297bb26bb60e3a2d83a7"),
    (6, "a70cd519ed7f3aab0f724d7873950f5ca4cbaace6ea093a544575b48e86d8f73"),
    (6, "c4dd3155bd6a89a9e938ed9ea12655ac05de08712ef5f9be4fb406185a2ee209"),
    (6, "f0d277a9abda37d4fbec8a9a314140dd42c087ef0fa8fc24103038dd8030c42e"),
    (6, "f6fc6a6dfcdbc3453347fb5cba01a54edd12cd151d3bb84e5db5c054896345a4"),
    (7, "174f3b3663d1dbfdd8227272a6051ed5033709721e277a52b14fb1720f2e0c0e"),
    (7, "500f16b6d5b87c78fa1aca9116ab8f7804290a66a08f2c8eca36596ad92efb71"),
    (7, "508974c56adfae332158a9c7e3196c93b6f60ec77764261eae7d847c59fe2c94"),
    (7, "57e89ee4becac5db99bed1e279775e5ccc63d92185be2d13ecd3c4c1e68cbfbd"),
    (7, "65dc53152fbe250e27b6da5fc5a6ced156369b406aa990bc67d855ce5f6358be"),
    (7, "8f87bd30a856e382acebd423da07d29624938bdb5d2c3c491512b5d32ffea104"),
    (7, "ab6e04929990ac9d875c8f0cca88b6afa0f8a7bd34e48f3b9b6dbad8dd3eb4b0"),
    (7, "af6e094d7bfd466f75721798d3d83ab7a37580405994d97f33808642d3fee01d"),
    (7, "b132921b9bcc3449e5e302721aef7652298589ed4def2e7ba495cb7c00b4df96"),
    (7, "b5376e259c89012018b6b83a13f414d8a6ba5b34a854f804bf03c9b6868692a8"),
    (7, "b6ad1713bdd788f8342426c7b34a16da88d7f8968b46403dea83391f586a8706"),
    (7, "d21164d8c7993f9a33f8cc3e0bb2fcdaa2cba82789064e54731a7ee055ec4361"),
    (7, "d3b4c54d71d63f1bc865592cfa1ec5f4eca279f4e085812b223b14d5376ce72b"),
    (7, "e0415d7f96913ed2749ad0f27bb0c3fd9ca33556a78cfaac6abbd066cc73841f"),
    (8, "2fc14551f725babaab1ba83e99695257d5ed8e423a9ba50feb9ad552166d9fdf"),
    (8, "67ddb1721f1c82e496202f264ebd1f4c497402f7f84c34e6df8b9b820efb6499"),
    (8, "7626c2c019aed15112e52f6aa0d7b6b05f2f5d5b4ba4831b9ab0c95585d172a8"),
    (8, "7d9d14905eebcf30dc1a98dbc7ca06f7392f0a4bbe4834f93e1203d9baf760d0"),
    (8, "9df85619d29ae6ca57a68efbb5d0b5a54ef45caa3b38ef62d21b473d5af979db"),
    (8, "a65e4156d38150409f529cae0c9b1e34614d69620e78ddb67f7597c61c5bc123"),
    (8, "c2acb504e450604cdab3367be5e1ad49a1395fb01b0354d221b34d21fcf83caa"),
    (8, "c464ef51c1589605865a7df34e3177ef27f09c8b60a6a36fcce037894768b3f0"),
    (8, "d35458cfd4ecbd802991756197363a1351bb842c38fa112f1e1f6cd6d77a1351"),
    (8, "e2d3a6233e449fa1e6cd01b6bc086fdfba7af13805ebbdaea31946e0eea43507"),
    (8, "f1ff9323af8f6c65617daf58fadc182db086b53eb2abac1db9e316d82f3eb5db"),
    (9, "11c67cada1c064c5d961dc5adb57cfdab490b21367329ddedce5ca5b39e15f1b"),
    (9, "1bfd3403903e10a387c6fe0e6ded88ecfc6a13944898a8151b4dcaf855322cac"),
    (9, "22ce7ed5ff35ee2126123f0f445f16a962a29597d6f0037a58d87b3b5e8b6fed"),
    (9, "362667bb666b2aeb1ad4070bb044df0e2460a6c4fb2e711d0bf92ab6e524a030"),
    (9, "386ea84ee64cebc2f4e3c249721351173eb76e94f01e54e6b6fd3fe0f99ff968"),
    (9, "4d3ce357b6441ae582a929b820f17720559831b091262f743c9a29ae12a8b036"),
    (9, "515ec79275d46f9141118fbaa3a9918439ce4bb55fffcaa1a087f1939fcce33f"),
    (9, "53140f8308de6d3a15270033e4490b15959d22f6d022ff518d0da8c222cf8882"),
    (9, "75e825628cb6975fa35a8aeec5907ade6273c9daffb4c60b3e8669d635dc6ade"),
    (9, "7e5735e9d9256da1c5a0ad4d3e00cb0c1ab8da5d3ef990e410c41f998be91e3d"),
    (9, "8bc1876a5157cd1042af571957f313cb4f5eeb1a35227d6bb36dc47a3345bfb7"),
    (9, "942aad47df8d77631c6aa7e7a77e0aafaf9f9dcd93aa17c577115b3e5cd4a510"),
    (9, "a37037402345c8ed93747d91e65ee2743889ebc7896dc38515bfc2190e1f0e64"),
    (9, "a3f88d5c25860ea92a361dca624dc585c9445eca724adbc6bd632cc31a7d548b"),
    (9, "b5669c0ef27824185d332972ea1803a9daac591cd6951fdbdc1c5a0e618a2373"),
    (9, "bedffa0b664982ab519d138ab9edcd90ba30ac412781c2ea93b6172136323488"),
    (9, "cf9f2c47566f112b6ced0e56d0abc71f801cc02b89e03a4800fe913faf340bb0"),
    (9, "e3a0450cd66693a6ecbe9660fbf385c3a2fc007aab777d974c039727fc565dd6"),
    (9, "f991510627651fae3933d8d5b29c975dab3e1aba9b53057155fbc0f754be2c78"),
    (10, "1875a9793bc4eac31c08ea962a5c3a4d83db021ed0ff93050c34f3aa2467af73"),
    (10, "2c9802f80d6941d29d5c39916c93f9940570d472d8d24f7df62e160b64ab3183"),
    (10, "42c30ccd724d8a578c9f00e8b1a486cb2e261042b49ca240725c4d7a3581d5eb"),
    (10, "5ecbac9064d44bd56bfaaf4b9e79f10da6bdeb0178841cdc5bdf26c395eb9766"),
    (10, "68df3bcc59b19129b47d468b58725d172ab13e75f38c90fb196e033c2f88971c"),
    (10, "78f62e69baaee9fd65b4e13940c53da02d88c9898128147bb53e286dc0686362"),
    (10, "a65187867f88d05b763d46b313c853f34b336f199d9bc05f56d6109efcf2a0a5"),
    (10, "ace154d1b3cfb3f22f06f908876f6f88113974d39e856449ffdfcbcd35da704c"),
    (10, "c00e1250d9ddcf749641ba95b60e3ced29c6d65cecd0a2a31afe7c219628b580"),
    (10, "ce2e33f125b8671846eec3009d2d62d42fba75b76fe7ff77df442c0e2ae28df1"),
    (10, "db229d08ceba69325e5168c5b8edaf50b3ade81d099f099764851bacc5351fce"),
    (10, "ea9ce08b102d5fcaee91664b4da1f3e2eaa8e0c16d79dd98c56655f715c4d6d5"),
    (10, "ec900486d47c9c047be589744076dd25c9bbf0558d5ad318694b449ddb50cdfa"),
    (11, "02ba1ed5d8ab318d66a92665ffba5eec9946856cf403a42ba2f803988cf9ced1"),
    (11, "0e74f82c9f13ca3c076ca09f16de1338781a1d7d6c84725644af9d5a092e6639"),
    (11, "2b1a48bd42005b89cc6b728a39efb9b3e3b5d4d46c5cb0926f0a98a054cfaa33"),
    (11, "5af7ba23c25b8db704811e401298cc9ac89a54a3a44ef3f6bd3d81c306615ec3"),
    (11, "611c6f606395ca11ceb897e2e3d1cb77d2f6b78822bd8b2c9df1b25b6c0d622c"),
    (11, "a79f4daa8aad50bb08ba9aa9b6748956338c7576bebcb08d4d884fb9a3d43e92"),
    (11, "bbe9bc2a45a87d9a65b59b2bb1f3f3a471227acf1a028751efac873adb703a09"),
    (11, "c28baef6d6331f1e6fdd1be0df1998f4a3e00880b671adcce313152d8751cbce"),
    (11, "ca3ff9ed7a01d0b14fe6eeb7842188b95254cf10f59b434158354a78e40bdc29"),
    (11, "e08ee3a1ebeaa8e6464c1b5960c0686addc20f412c4ef729b65896f18a7d35fd"),
    (11, "ecf982df92c65dd6e8ad781d62008829ce3bc2aea7ce5af7e3bec36f58dc98eb"),
    (11, "fab177e0173a87f84618a727c8b371e66dce897dab5610dfa7c8c54483cced55"),
    (11, "fdf1ccc3711b591206d64417b6126faf742cf0fb5d9c6a8e65a6e1e0b176624e"),
    (12, "269cc332209bc5c9f0b022b53d21522c0a67745bd353804a5222e41990a6cff0"),
    (12, "27ef32cf38cffabb17b22f8831eae03e79feefeaaa89f67872ec1175b31da89b"),
    (12, "7d2dd7979ceedecbe5961f16e3224195d0d9ccb16fbe211d5d1c670ad29601ab"),
    (12, "9352e295be837c91a282ae10f97713fdcf2818a1a43a2ddb316467ee2d64cab9"),
    (12, "9b12436fdd29d67ccebf8c004606ba67858165a26f2324d8e5aa0c129bc03c9f"),
    (12, "be2cd49b60db685719d6ba52892c47c8a4630bf8a3b35e737275e94cfcb86d7b"),
    (12, "cf9303b39e5b1ca9e69847cccfe2d92d3332025aa2428f9e4a8bd2ea16ffba33"),
    (12, "e2b402c9ecf0880a8bfe70ea9e1abc075c9074d7adf79738efe52dbe703c58ae"),
    (12, "e61d281456c83fa0f02b10922360891923e7f9a7442e71124a9d59459a84e2dc"),
    (12, "e7c37ddf193ec4c3b79fd85932f095bd8a6e04ab77bdc0f4bc7f85468a84845a"),
    (13, "13bc1ded4c00b69e6db7180841cf6993cb97d32e2f2c76a16541e750a23d3f2b"),
    (13, "2d1a62b3d3c2f78b2852bc32cac9091e10042968f3c20d20b88558503a12c6df"),
    (13, "34adc5d4263e75a20c6fb0b3981b5bbd8ca2bff9130fc7fb0de02bf2f54e581d"),
    (13, "34f4e0e27e32bd5ed8f9a00aba5aeeaa989c8f9759a41cabc5b888a40848df19"),
    (13, "674892d4f4aed52687a5dd9e42fa955671cfb847a9ee53139263fa0fdb6e1147"),
    (13, "7cbaf2f394fae9b8d0b577bcac0b21c1fef7342ac34bf4df40befd7fbd3198e5"),
    (13, "b664d05a4eb78b3858eaf45d127c72607531d815fd400581489dd0d266911a21"),
    (13, "da8441c6c06db749ac973e5ae3812cfe4ab505b135441b706faf116f5aa271a1"),
    (13, "f1f101c128fec5f91a2fbb1688724b56b2a430b65e9c0c375314a497cc27bd4b"),
    (14, "42e987a168b6d3e93e9f3d530ba2b96b7851225a49b848ce418658289a53b48b"),
    (14, "50248be5811a279e1e6c835f3e7d22491cdbc7776f4c22ee56db3f2cf5995093"),
    (14, "6d94407a09124b1b474c0bab798e0e6ff758369fbc5e00d8261e1a176ad4d6f5"),
    (14, "95d82c45c98300563c7072bc1bafc10ca31762489c4590c173f4246152b78838"),
    (14, "ac574a1b6a3b5622be418c2ca45ba71834bc108e4d36a3f38a026cf6f29722f6"),
    (14, "e836483f1e8ba4fef1d043080b99b3223209cb4dddf69edd56eb04e34791afaa"),
    (14, "f12ccf5ff777fceca63c4329981bd3f1a2098cd848432112442fa7f3b898bb12"),
    (15, "2bdd3503ded005cd086eb4e3753d8bcb9598b243af86abda4c278c66c7f10886"),
    (15, "3bdf82c067474bb1aade6199e93e31ec25bcb4b17fccec5487c0cc799ec1d556"),
    (15, "4066dd340590250937faae8774a08db08d829384cae07a3dd379e0363b77c179"),
    (15, "562ad4f32c32d9c28b759371d3a20610f842abc882e30b001b6718f4680262c3"),
    (15, "82e774615b28297d2cd8e6066662fa06d7533b11999d934597ec57beb5201e1a"),
    (15, "949a8ad82ad2250aa375ec8978e3a73ae3ef4e7be9eff86d1c602907179f258e"),
    (15, "aa4168cd46743cb61e30962eb4d4ee30f7bfbfc02e62a70183fe00ebc74a5732"),
    (15, "c847c5d32571e89387e40393c85c928db5507f7e15841da51524b446801c029f"),
    (15, "f840ce05f913a769ccba605e4318c7f80eeee2dd3bb499b9cfb9a3e25aec7bcf"),
    (16, "d779f3b2d58cf0b1cc2155f2500731a68c0b8b925bd3dd7ef3fe00fe704f96ab"),
    (17, "02394ac89e353fb92488bfaedff281ac1d5b122c79dfce6ad4acaa3785c38738"),
    (17, "183ad1eb95699e7b180d8e88c0b4191c37221307e4d97b9f1a2cd84a98fba9de"),
    (17, "89565c05cd689f3f521fde2858618a34227cc1a1613f9142200a12106e2296b1"),
    (17, "a8c58aef6b93ce2603fe7ea47e2522b29a72e20c000da300f54a23b5d9cc52d7"),
    (17, "dc9fdfe57131c0a13d1f932cc9d843f4b28e5af23b27b229d0724aa6b649d8a6"),
    (17, "f136d291158116be01106df4a796fd6e58fbc7aa0908a1c37015eaefa8e471f6"),
    (17, "f1799aa2d746bb47ac59d595db89d2867056684242f7c0b91c8918b4e20cc968"),
    (18, "040e21df3e5458c47285cd9dc4cafc1ea32fe6b7bb6310228fffb092106d9b6f"),
    (18, "044f736822fa52baadf563ae334587b44419cdc5cf5ad9adb48dccb777ff47d4"),
    (18, "1e9d3d6acabc54276c390928342cd2314944c772c8e6fae90cce6205a4255d8a"),
    (18, "3c4c2d66cc0f55fbf2cdba4e4c3a31da14d58e987d71be56061385ac47781b63"),
    (18, "5b3a5310ade1aa76ff1d091bf6923c9b37f1bb86321d8641999a84ea977ff2c1"),
    (18, "a2d13a4e23a3c61905f7b619afcdf5326c06c10da18ce2fda923382ddeb6bd03"),
    (18, "a622c1844d861a6c5b2f8af336b99b9f1fe7054ec1e90f691b3bf8fddb5c5a7d"),
    (18, "aeb51d1a41ff94c2252f4466f0bf58c41acfb265fc6d12cc4957e279cf651f6a"),
    (18, "b857495413f8c3eee1eea0b172523449772ad585361ec7389d3db58663df926e"),
    (18, "fc27f8b0f97e7845a41d824d3f67f74fa6e68b7c406ddc77e9a303a4cd6ccd97"),
    (19, "5957118436f5e0e42af916d3c2f79a8080fd5e2943622dc406681916a7aa5333"),
    (19, "a698e53fee3fa0f41ba73d5a43ad9cabc679e17a25551e115e6f5c4b5b22e4bf"),
    (19, "eab4e8c7c2f52590cf83cb0076cd16ba2b617ac92f7a048d99fa057f37372d9e"),
    (19, "f0710d51ab6f0557ae5d13e71e7eb591068ccc3a15582c3c87a7a4a0c3497876"),
    (20, "2a0f27410736d11d1f41348517a208194444697bdc7a2baf9f24f98adbb60f0b"),
    (20, "327c00f18ce0e3f81c9177f53ed796f5dd3595afa57bf1de614d3e1318135e5f"),
    (20, "3493c48d4661637d1cb5640cafd53705a400cb2b37bbf4d6187a1d4d9bf36118"),
    (20, "6e98ec2178777b6bb33687fa9f75c8cc2f57e67901ea612b890e88d9b02cf4d6"),
    (20, "9cb9e6110bf2db8517dc1ec914b876695b8d4440ea06466dc76c794a9c1b45e1"),
    (20, "ca510ccf67ebfb3b9754ea1a846e4f22ab3133d48e697b07fe0134c70c056d6f"),
    (20, "d1f088d9d19a56df0ea4797afd0baaefbbd8ae73c230561f1fff9870399c8997"),
    (21, "029e0604c5c7430e8cf4928ad951c0b24e1d6c5a766c315ecff84ee1062a129c"),
    (21, "157a69f688109281126b773381d8f1d151571e2d915e62084a502f0c563af434"),
    (21, "3eeb17081958b74e8979742831f2f73c7063376e65300e79141644b586fd4203"),
    (21, "5f20fcadc5dd96f92766d83739409a6ff3105fd296f4949681cb0f62bf93ef0d"),
    (21, "6007ea62dee51b4df1a424c3300d1299c353dd2aa2effc3c23b93b7c88198782"),
    (21, "65ba6bd8925503a9051691d7ee38ff3bb47cfc258e465aa927c3d2e6794bb518"),
    (21, "c1f70005fdf09e5afb0de8bc761e964537c9d981e047ed1369e3ab43f394cfab"),
    (22, "3951d3bf41c43c972be7966f8884a48d39582aa41f9e7c739782940efd404d2a"),
    (22, "5313926b07c172d200e2833d6677cc0ab393dea30b652b59d2cabedf5c16fd29"),
    (22, "7fad3cd61f3ca2c08a82c7cce95f0269957b3099b2719ad344c52275ee1a8996"),
    (22, "ab34eccd8384a950b24ae22f96a3027020ac54bddad9fe79a22b3f2fa450cb52"),
    (22, "cc206407321f93a6df19e15f2b708835532acda17f18d0ad6d23d554c28a9a71"),
    (22, "d86d4e02cb45be9687d8a3d3daa73444b5521ddfd3b9c3d84db70a639b7d6986"),
    (22, "d96ac3ff697815d702dcee2bcd916443f09d60a53ff66aecf98f4ca0402c5a5e"),
    (22, "ef632a55f8a9c76b3bbebdd47448cfe466c1b8a32655346c268fd9b005fb4f2e"),
    (22, "f99c765bcef82ce1daadb3a810f99dd1df39e769670ce22fde3e0eb14b20ee57"),
    (23, "50635f74050cbfa56907d2af61fc44df120b167e316839b1a63210c22afa0590"),
    (23, "7a49d56c07f68dbaa86022bc5e91113667d4427ec9b15786032ff787ab71f614"),
    (23, "da2b4fb9617aad3874e660d053612291f2372f9a9141c66f37d52921dafc897b"),
    (23, "dd347790a3f22a3eaeb44715addad5453da82d5e5c38da7e625ca82d69de88c5"),
    (23, "e07e154d0d07589918b82402b66f57b6336de2a1d24c8cee74602ae13fbb34d5"),
    (23, "f2d12f8cb7dfa1c7768635e57f92c40bdf3b44cc27253dff3001fa8492e4983f"),
    (24, "0cd4a9f718e238049c121196b6b98312a6572dca34d3c644ebe76d26a0550632"),
    (24, "37543991d6502e3a64a8351f4c81ecc4a01f2667c444cb5005657e3df6dce6ec"),
    (24, "3fad24b16cb5ed909d21582a0c32965c67b52f0f1de666dfd386c9e1a121b8e5"),
    (24, "56cbfb3fe39781678f359c36222108790228554b4297142924236f02d322e161"),
    (24, "b9def67a87ceab973a49d55326b6d98485e09ad6bb818ec0ca97fee72cb8dcbe"),
    (25, "2c277d88204fdcaeb17fbb1af5508f6482ed574d65b36b5fefc2f76e0451d604"),
    (25, "7169dd58573c621471cdfed67367ffa6c9acc55140e88a496a7a5d69ecce37d0"),
    (25, "bc39387e6569971d3e6b779fc2611d94c4448b2d94672320942cf2a503fea902"),
    (26, "0b5b99c0976d0a959b70c6135b20d449d1279a531a1e288668b1df765a7b673b"),
    (26, "214600d2bd19a17cb88759a3464b3973905088d712e9cb8d05ac395df6063f5d"),
    (26, "521ab943d6d86d391d0bf332eb34b8e4dfabae71dcb1f210b554948c052f2bcf"),
    (26, "b7c5ebf872be6a3bb641cd11d893f7b118cb1dd929c36902e419788649eb89cf"),
    (26, "beba3553a1b776bda2b16af9c02b8eccb09c35077a849b516495f172dbb871ca"),
    (26, "d91529f910b22413587a756ea4249a86799a0a480a4ee4af17e44b3c95332439"),
    (27, "255e7ddb02350102713ede1e257719c5232c07f9f50229455f369da6833008e9"),
    (27, "2c86216d25618b973b9161fe94a54e5ff2f747d73597c842152043879b13e0fe"),
    (27, "457dae355f3e68405f879b3a4bad448def769f77374b019fe147ec694ce16f6b"),
    (27, "52797ca9e533bd55eda8b709b5b4303cb703b3b7b0580f043927886d889e138e"),
    (27, "53742cdb0a0af26edaa53fc7cd4a0388d81cb09c8b3fe95398277e157eb332bb"),
    (27, "7929ea59b39d28bf3e746e35ee6414051c0d788e4a49826fe8218b4f580d6e1b"),
    (27, "9487a6d0821714dbdfbea78c8d01a32608fec7d3ef29f33937984b40a884e585"),
    (27, "fac83c3a24a5e33068c6684cf78c42b9c494eed25741a32f881f3cf684ab4843"),
    (28, "807a5dfb9a3941b591ea8bdcf25ed26cbda4b493d1f062360e437515d6c87763"),
    (28, "b469437d06eb70c5c2b29e8517c3eecffb9f48d784226c982859737ed7b53e3b"),
    (28, "f109bfdc08168e6e686803b6b122d9cb0b26f0e5c81bf4a5b7969014e8544fa4"),
    (29, "2d018336639d7269029acd37eb5f06527131a74a21ab043a9d94f93f0e61fc36"),
    (29, "386d7b12660bf7d9e82d3c02b20caa3ac4f3106790d0887460005e8afadecff2"),
    (29, "a5b8e974e678d14bfac8e1357a560cd02c960c07f004e6e5edf052060f847670"),
    (29, "c657bed808d130888aa208020b82d03539655ded0397727db40aab797b2123c2"),
    (30, "02424d568303d7b865041c962f2aef32242ed4d95c5b62279fe5b98157400bbe"),
    (30, "05174b354331ffdb200bdb526ddb30ebd8090e2432b0596773d21ac7ca1c518b"),
    (30, "2e975d41885acb30267f5cf93a6d2c92b3c86c7f89b9d2de4ff0657b8a2b1ffc"),
    (30, "608df428dda55aee68fcc74d40ee1aa74066b9b98a35ce473f3276748a3b4c70"),
    (30, "83b892ca10bab8b72447c0ff0d1f3c8dbfe23c690a9ccc17721a622c8c44f5cb"),
    (30, "935a81b31ecebc63d121e0aea5860304a0a2a42d9ca03dd40fc9aa59c4d04f00"),
    (30, "ac0a699f644bf58f99e53c3ae819fade2011543906585e72e441c848c19fd023"),
    (30, "af5d4d20472b6f071e8600fce06929ef0b9104370e46156d3ba836df8310b24b"),
    (30, "db16466349b1ab4d960d52de839d528c920331c0c79289caee59d3ed43e7a17c"),
    (31, "83cb29da40bc73164940a17116648ac3fa70bf2977a7e215dca83a775bc321b2"),
    (31, "f1b21ff75ba3ddc856b4f90cb978f258d638598809e5d75100b6ab8c250c155b"),
    (32, "ac3b1bedabde9e8bcbfe230374c621895f9fb6c3f0c7b59a7615a6e1879411ab"),
    (32, "b969cabd00b6d24777bf8861375a7f1b572aac97d15aa0e8a5e0db697181618c"),
    (33, "788a5e035570a0bbb1fa6d68b25e6309c9c1cebdd6a1c7f20a720065ba774b8e"),
    (33, "b52dbd1c6c85350898b3283abd329f82a944f022a7b51da05bd2d0a8e50afbe6"),
    (34, "5ed0b1a396eebb2dba90a5ba339cd4a12cb5840f754da6654443c653eb2b14d9"),
    (36, "dd2483f95af029825e97d08e0ac5cf93bf2e055d8460fe9ab8786edc895c1e41"),
    (37, "307a6ffe34970602b03c5bd09f241b1670180acf08189735e0d151652295c6d3"),
    (37, "340b676f84d7b3f7ea0d2e8da0e6394a0f5dd5d58642de4e71318a1aeed8a840"),
    (37, "c8f4c471f05ab14b6c16d75253b65ecf2fa2f2c243d9f22c0ce496385239bff0"),
    (37, "ca8543d9ca3247da4271a3b75c8e626b277057cbe4101fd637469a2904e4cf5f"),
    (37, "e9766fef5e33cb4d749874e20f6f9876fca87f0a00351564dbc65d3995af0676"),
    (38, "072c6635ae50f431f720b4ca25710aef5bc241a0e0b856b863ab602304e25d89"),
    (39, "acef2fc0c0564bba6067cfbb419990b90e5bc5109db144ad1e1778ba1e1cd3d9"),
    (39, "f269ddbf1de6a67d424ede7d11ec9ccfdf2386a808fe82c011cc4fb1f0efb7e3"),
    (40, "409cbfeabf283807ffa5b93262fd2df5baee3cfa14aabe88d7618d1f4ee36de1"),
    (40, "f97a07baf3acb94d91b703456254d62aa23e57d26d4cb6481fd7a8bf7132e36c"),
    (41, "0c638eea947c81d9fc8e1c42c8a3f686357955173fa9f1d40068d69353aeab54"),
    (42, "0c834b6cbd7bfc742ccb692e456b739d3137929eea71b34256f81c63f08bc081"),
    (42, "0cd364f4428d9cfa1bbc4fc79fce894fc9cd14fb16f631e6528017ddde28c380"),
    (43, "8af98f65e5381ec1ca3f1fe88bc25c168c4181f0672e20c704e6a6e164fd4e34"),
    (45, "c984ff7bd21138ae849e128ecbcfcbdf1917bef6013bc94f83c876677f268026"),
    (46, "1a818b54086c40f051e55f6ba9db332ac4d61e15c9d55033c932cedfea09789d"),
    (46, "91c3ec4011a59d1f13d5dd02bdcc27bce04c812b5cabfa8b624b442105033c33"),
    (47, "055cb02641a82fafd801fec2af1ee3ef8c5f84fe91b7ef53c03ee8588f0a5b45"),
    (48, "46fe7ca83992e36fb9cb2f0aa57c6a18aa79b07be81ce212a4b10e12301f6d72"),
    (49, "1b2207256b173594c204974cd1a870e0c1c31728bafee0e507e0bb6af1488bfc"),
    (49, "4b8ff562bf8759851c50693d66b9bf1178339fea8f5bd015b520fed056b73382"),
    (50, "02ae1b81df5f5a1044e433549228b8ea52069fc1d08e0bcba620b57520316d77"),
    (51, "332a11154fd022ee2da84e2b6de1caf4da8ea006d85182086f284056d64574b0"),
    (51, "be94b370c09cdee3ecf13e10acdda7352fbb0776f61905c700c22dfa3a8e70f8"),
    (51, "faf108bbf6be749411950ccaa49bd2a02b72da08fa8934d9995b184dd017d7ed"),
    (54, "275c4f72df2702a562762e0f917b8ab9777a1f5604f847b27bddbe4bc28cff81"),
    (54, "e8276f93105119bb51c5b7f89640824ce1da3cab1991505482ab63a02660660f"),
    (56, "eb049be05ca5d377beb128e9486fbc841cce30d2a500953a1d1a547e94b57bd2"),
    (59, "cb9827049a371ac9fe41147a3a7565572fef3768bc788a297434401b3c4a687d"),
    (62, "1cf39eb0e6cca0446608291075a9751a9b6dda844e76343ff9370ac4db475bdc"),
    (62, "cbf8f0ddbfeb16d21d7fc7e1bba4a7604ad8b864a7beef626a62a9b6a223caa1"),
    (122, "4a187e62c962c7b3c853cc4c03e21da2111571d08db05eeb382199298dbef9b2"),
)
HELD = ()
GONE_MARKERS = {"bullet-screen-livestream": "666", "fourth-calamity-sandbox": "草"}


def digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def run(*args):
    proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT), *map(str, args)], capture_output=True, text=True,
                          encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


def strings(card):
    yield card["name"]
    yield from card["scene_triggers"]
    yield from card["aliases"]
    for field in ("lexical_shifts", "kinetic_verbs"):
        for key, value in card[field].items():
            yield key
            yield value
            yield from (part.strip() for part in value.split(" / "))
    yield from card["blacklist"]
    for key in ("sentence_final_particles", "punctuation", "register_markers"):
        yield from card["syntax_metrics"].get(key, [])
    yield from card["sections"].values()


def module():
    spec = importlib.util.spec_from_file_location("style_cards_under_test", SCRIPT)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def card_of(data, cid):
    return next(c for c in data["cards"] if c["id"] == cid)


class Library(unittest.TestCase):
    def setUp(self):
        self.data = json.loads(LIBRARY.read_text(encoding="utf-8"))

    def test_the_library_checks_and_every_card_renders(self):
        code, out, err = run("check")
        self.assertEqual(code, 0, out + err)
        self.assertEqual(json.loads(out)["status"], "OK")
        self.assertEqual(self.data["format_version"], 2)
        self.assertEqual(self.data["composition"]["max_per_layer"], {"base": 1, "voice": 1, "device": 1, "scene": 2})
        self.assertEqual(self.data["composition"]["precedence"], ["device", "voice", "scene", "base"])
        mod = module()
        for card in self.data["cards"]:
            page = mod.render(self.data, [card])
            self.assertIn(card["sections"]["subtext_logic"].strip(), page)
            self.assertIn(mod.DIRECTIONS, page)
            self.assertIn(self.data["global"]["example_policy"], page)

    def test_the_checker_catches_a_broken_library(self):
        mod = module()
        broken = json.loads(json.dumps(self.data))
        cards = broken["cards"]
        cards[1]["id"] = cards[0]["id"]
        del cards[2]["sections"]["subtext_logic"]
        cards[3]["layer"] = "no-such-layer"
        cards[4]["lexical_shifts"] = ["not", "a", "map"]
        cards[5]["conflicts_with"] = ["no-such-card"]
        cards[6]["aliases"] = [cards[7]["id"]]
        problems = " | ".join(mod.library_problems(broken))
        for expected in ("used twice", "sections must have", "layer must be one of", "lexical_shifts must map",
                         "conflicts_with names a card that is not in the library", cards[7]["id"] + " is used twice"):
            self.assertIn(expected, problems)
        broken2 = json.loads(json.dumps(self.data))
        broken2["composition"]["max_per_layer"].pop("scene")
        self.assertIn("composition", " ".join(mod.library_problems(broken2)))
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "cards.json"
            path.write_bytes(json.dumps(broken, ensure_ascii=False).encode("utf-8"))
            code, out, err = run("check", "--library", path)
            self.assertEqual(code, 1, out + err)
            code, out, err = run("load", self.data["cards"][0]["id"], "--library", path)
            self.assertEqual(code, 2, out + err)

    def test_cleaned_text_does_not_come_back(self):
        self.assertTrue(REMOVED)
        texts = [s for card in self.data["cards"] for s in strings(card)] + [self.data["composition"]["rule"]]  # r5.50
        wanted = {}
        for length, h in REMOVED:
            wanted.setdefault(length, set()).add(h)
        found = []
        for text in texts:
            for length, hashes in wanted.items():
                for i in range(len(text) - length + 1):
                    if digest(text[i:i + length]) in hashes:
                        found.append(text[i:i + length])
        self.assertEqual(found, [])
        ids = {c["id"] for c in self.data["cards"]}
        self.assertEqual(ids & set(HELD), set())
        for cid, word in GONE_MARKERS.items():
            self.assertNotIn(word, card_of(self.data, cid)["syntax_metrics"].get("register_markers", []))


class Identify(unittest.TestCase):
    def setUp(self):
        self.data = json.loads(LIBRARY.read_text(encoding="utf-8"))
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def config(self, **fields):
        body = {"format": "novel-workshop-style-card-config", "format_version": 1}
        body.update(fields)
        path = Path(self.tmp.name) / "style-cards.json"
        path.write_bytes(json.dumps(body, ensure_ascii=False).encode("utf-8"))
        return path

    def test_a_literal_scene_phrase_is_listed_and_nothing_is_invented(self):
        folk = card_of(self.data, "folk-eerie-horror")
        code, out, err = run("match", "--text", "这一场：" + folk["scene_triggers"][0], "--format", "json")
        self.assertEqual(code, 0, out + err)
        result = json.loads(out)
        self.assertEqual(result["hits"][0]["id"], "folk-eerie-horror")
        self.assertEqual(result["hits"][0]["layer"], "scene")
        self.assertIsNone(result["default_card"])
        code, out, err = run("match", "--text", "ABC 123", "--format", "json")
        self.assertEqual(json.loads(out)["hits"], [])
        self.assertIsNone(json.loads(out)["default_card"])
        code, out, err = run("match")
        self.assertEqual(code, 2, out + err)

    def test_book_keywords_come_first_and_a_default_only_when_configured(self):
        path = self.config(keywords={"hemingway-iceberg": ["砂轮机"]})
        text = "他把砂轮机关了。荒村古宅探索"
        code, out, err = run("match", "--text", text, "--project", path, "--format", "json")
        self.assertEqual(code, 0, out + err)
        hits = json.loads(out)["hits"]
        self.assertEqual([h["id"] for h in hits][:2], ["hemingway-iceberg", "folk-eerie-horror"])
        self.assertEqual(hits[0]["book_keywords"], ["砂轮机"])
        path = self.config(default_card="wang-zengqi-literati-daily")
        code, out, err = run("match", "--text", "ABC", "--project", path, "--format", "json")
        self.assertEqual(json.loads(out)["default_card"], "wang-zengqi-literati-daily")
        code, out, err = run("match", "--text", "荒村古宅探索", "--project", path, "--format", "json")
        self.assertIsNone(json.loads(out)["default_card"])  # a hit: the default is not pushed in on top of it

    def test_an_excluded_card_is_not_offered(self):
        path = self.config(exclude=["folk-eerie-horror"])
        code, out, err = run("match", "--text", "荒村古宅探索", "--project", path, "--format", "json")
        self.assertNotIn("folk-eerie-horror", [h["id"] for h in json.loads(out)["hits"]])
        code, out, err = run("index", "--project", path, "--format", "json")
        self.assertNotIn("folk-eerie-horror", [r["id"] for r in json.loads(out)])
        code, out, err = run("load", "folk-eerie-horror", "--project", path)
        self.assertEqual(code, 2, out + err)
        self.assertIn("excludes", out)

    def test_the_config_checker(self):
        good = self.config(keywords={"hemingway-iceberg": ["砂轮机"], "folk-eerie-horror": ["砂轮机"]})
        code, out, err = run("check", "--project", good)
        self.assertEqual(code, 0, out + err)
        self.assertTrue(json.loads(out)["config"]["notices"])  # one word, two cards: a notice, not a problem
        for fields, expected in (({"keywords": {"gritty-street": ["x"]}}, "not in the library"),
                                 ({"keywords": {"zero-degree-camera": ["x"]}}, "alias of hemingway-iceberg"),
                                 ({"exclude": ["hemingway-iceberg"], "default_card": "hemingway-iceberg"}, "excluded"),
                                 ({"default_card": "no-such-card"}, "default_card"),
                                 ({"routes": {}}, "unknown fields")):
            code, out, err = run("check", "--project", self.config(**fields))
            self.assertEqual(code, 1, (fields, out + err))
            self.assertIn(expected, " ".join(json.loads(out)["config"]["problems"]))
            code, out, err = run("index", "--project", self.config(**fields))
            self.assertEqual(code, 2, (fields, out + err))


class Load(unittest.TestCase):
    def setUp(self):
        self.data = json.loads(LIBRARY.read_text(encoding="utf-8"))
        self.mod = module()

    def test_directions_not_replace_orders(self):
        code, out, err = run("load", "classical-wuxia-chivalry")
        self.assertEqual(code, 0, out + err)
        self.assertIn(self.mod.DIRECTIONS, out)
        for promise in ("例句和示范段只示意这种腔调大概什么样，不搬进正文", "作者自己的原文、本书的文风卡和口吻表、已采纳的正文优先"):
            self.assertIn(promise, out)
        self.assertIn("这种腔调大概是", out)
        self.assertIn("不是替换表", out)
        self.assertNotIn(" / ", out)  # alternatives come out as separate ways
        self.assertIn("不是禁词表", out)

    def test_layers_order_conflicts_and_aliases(self):
        code, out, err = run("load", "tense-suspense-probe", "hemingway-iceberg", "rashomon-confessional-pov")
        self.assertEqual(code, 0, out + err)
        names = [card_of(self.data, cid)["name"] for cid in ("rashomon-confessional-pov", "hemingway-iceberg", "tense-suspense-probe")]
        positions = [out.index("## " + name) for name in names]
        self.assertEqual(positions, sorted(positions))  # device, voice, scene
        for ids, expected in ((("hemingway-iceberg", "russian-epic-realism"), "at most 1 voice"),
                              (("folk-eerie-horror", "tense-suspense-probe", "chase-and-infiltration"), "at most 2 scene"),
                              (("bullet-screen-livestream", "meta-anti-cliche-comedy"), "does not go together"),
                              (("hemingway-iceberg", "hemingway-iceberg"), "named twice"),
                              (("no-such-card",), "no card")):
            code, out, err = run("load", *ids)
            self.assertEqual(code, 2, (ids, out + err))
            self.assertIn(expected, json.loads(out)["error"])
        code, out, err = run("load", "zero-degree-camera")
        self.assertEqual(code, 0, out + err)
        self.assertIn("（hemingway-iceberg，voice）", out)

    def test_a_cards_overrides_of_the_global_part(self):
        allowing = [c for c in self.data["cards"] if "然而" in c["overrides"].get("allow_global_terms", [])]
        self.assertTrue(allowing)
        plain = card_of(self.data, "hemingway-iceberg")
        self.assertIn("然而", self.mod.render(self.data, [plain]).split("全卡组相反的写法", 1)[1].split("\n", 1)[0])
        page = self.mod.render(self.data, [allowing[0]])
        self.assertNotIn("然而", page.split("全卡组相反的写法", 1)[1].split("\n", 1)[0])
        self.assertIn("这几张卡放开的：然而", page)
        free = [c for c in self.data["cards"] if c["overrides"].get("forbid_translationese") is False]
        self.assertIn("少用翻译腔", self.mod.render(self.data, [plain]))
        self.assertNotIn("少用翻译腔", self.mod.render(self.data, [free[0]]))

    def test_an_example_against_another_loaded_cards_opposites_is_marked(self):
        data = json.loads(json.dumps(self.data))
        voice = card_of(data, "hemingway-iceberg")
        scene = card_of(data, "tense-suspense-probe")
        plain, example = next(iter(scene["lexical_shifts"].items()))
        word = example.split(" / ")[0][:2]
        voice["blacklist"].append(word)
        page = self.mod.render(data, [voice, scene])
        line = next(l for l in page.splitlines() if l.startswith("- 平常写“%s”" % plain))
        self.assertIn("待复核", line)  # r5.49: marked for a re-read, no longer dropped outright

    def test_copied_wording_is_found_and_plain_text_is_not(self):
        card = card_of(self.data, "classical-wuxia-chivalry")
        table = next(v.split(" / ")[0] for v in card["kinetic_verbs"].values() if len(v.split(" / ")[0]) >= 6)
        quoted = next(e for w, e in self.mod.examples(card) if w in ("lexical_map", "somatosensory") and len(e) >= 6)
        with tempfile.TemporaryDirectory() as tmp:
            draft = Path(tmp) / "draft.txt"
            draft.write_bytes(("他没说话。" + table + "。" + quoted + "。").encode("utf-8"))
            code, out, err = run("copied", "classical-wuxia-chivalry", "--file", draft, "--format", "json")
            self.assertEqual(code, 0, out + err)
            found = {f["text"] for f in json.loads(out)["found"]}
            self.assertIn(table, found)
            self.assertIn(quoted, found)
            draft.write_bytes("灯还亮着，两个人谁也没有先开口。".encode("utf-8"))
            code, out, err = run("copied", "classical-wuxia-chivalry", "--file", draft, "--format", "json")
            self.assertEqual(json.loads(out)["found"], [])
            code, out, err = run("copied", "classical-wuxia-chivalry")
            self.assertEqual(code, 2, out + err)


class Reach(unittest.TestCase):
    def test_both_exports_carry_the_cards(self):
        spec = importlib.util.spec_from_file_location("export_portable_under_test", SKILL / "scripts" / "export_portable.py")
        exporter = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(exporter)
        wanted = {"references/style-cards.md", "assets/style-cards/cards.json", "scripts/style_cards.py"}
        for mode in ("personal", "sale"):
            self.assertLessEqual(wanted, set(exporter.collect_core(SKILL, mode)), mode)


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""r5.61, package four (part one): the entry page, the interface configuration and the package root pages.

The entry page (skills/novel-workshop/SKILL.md) now names reference images in the skill's description, sends a host
to the visual notes card before the library row and before the row of the workshop's own image search (which says
when to take that row: scripts can run, reach the network, and the five projects are installed), says that the
"only through visual_materials_cli.py" sentence is about the workshop's scripts, points the chat-only item to the card,
and gives the revision row a half sentence for revising an existing draft from reference images, pointing to
"手上有参考图时" in editing.md (EDIT-08). The interface configuration names reference images in its two texts (HOST-22).
EXAMPLES.md (items 24 and 25), QUICKSTART.md (first use) and USAGE.md (the table by environment, the size of the
single file, the visual section, the add-image command in the list of local scripts) say what can be recorded where
scripts cannot run (HOST-28 to 33, LIB-51).

These tests pin each new sentence (exactly once on its page, none of the four hard words), where it sits, the links to
the card (the file is there), what had to stay (the L1 line, the delivery gate card and the revision card without the
words of the new paragraph, the anchor "](references/inspiration-library.md) |" an older test finds the library row
by, the third cell of the script row, the keys of the configuration), the size of the single file as USAGE.md gives it
against the single file at the package root (HOST-32), and run the add-image command of the list as it stands, its
placeholders replaced by made-up values, in a temporary folder (LIB-51, B-01). The example values are made up for these
tests. They do not say that a host reads these pages or does what they say, or that the writing is better.
"""
import importlib.util
import json
import os
from pathlib import Path
import re
import shlex
import struct
import subprocess
import sys
import tempfile
import unittest
import zipfile
import zlib

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
SKILL_PAGE = "skills/novel-workshop/SKILL.md"
# the interface configuration: the one .yaml file in agents/ (named by its path, not spelled here)
YAML_PAGE = "skills/novel-workshop/agents/" + next(p.name for p in sorted((SKILL / "agents").glob("*.yaml")))
EXAMPLES_PAGE = "EXAMPLES.md"
QUICK_PAGE = "QUICKSTART.md"
USAGE_PAGE = "USAGE.md"
PORTABLE = "portable-novel-workshop.md"
HARD = ("永远", "绝不", "必须", "严禁")
CARD_FILE = "assets/visual-notes-card.md"
CARD_FROM_SKILL = "[看图与手记卡](assets/visual-notes-card.md)"
CARD_FROM_ROOT = "[看图与手记卡](skills/novel-workshop/assets/visual-notes-card.md)"
LEAD = "**手上有参考图时（r5.61）。**"
# The new sentences of this part, as they are written on the pages (PLAN 2.1 order). The number in HOST-32 is also
# checked against the single file (RootPages.test_the_size_of_the_single_file).
NEW = [
    ("HOST-21", SKILL_PAGE,
     "用于设定、人物、大纲、长短篇正文、续写、照参考图或照片写和改、文笔修改、"),
    ("HOST-20", SKILL_PAGE,
     "风格包不在单文件里要作者另给什么。看图、找图、记图，另照 [看图与手记卡](assets/vis"
     "ual-notes-card.md)：先看宿主有什么，跑不了脚本时记手记。"),
    ("EDIT-08", SKILL_PAGE,
     "| 文笔修改、章节自检、编辑反馈、流失位置排查、删冗或重写；作者交了参考图、要照着改一份已有的稿"
     " | [editing.md](references/editing.md)；作者转来别人改过的"
     "稿子、问改得对不对：[teacher-review.md](references/teacher"
     "-review.md)（r5.54）；照参考图改已有的稿：[editing.md](refere"
     "nces/editing.md)“要求修改时”里的“手上有参考图时”（r5.61） |"),
    ("HOST-17", SKILL_PAGE,
     "| 先读 [看图与手记卡](assets/visual-notes-card.md) 第 1 节"
     "，看宿主有什么；[inspiration-library.md](references/insp"
     "iration-library.md) | 图从哪里来（作者给的、工坊推荐 4—6 张）"),
    ("HOST-18", SKILL_PAGE,
     "| 用工坊的脚本给一章找参考图（先照 [看图与手记卡](assets/visual-notes-"
     "card.md) 第 1 节看宿主有什么，能跑脚本、脚本连得上网、五个项目装好了才走这一行）：两"
     "路搜索、读来源页提图、"),
    ("HOST-19", SKILL_PAGE,
     "用工坊的脚本联网找图时只走 [visual_materials_cli.py](scripts/"
     "visual_materials_cli.py)"),
    ("HOST-22", YAML_PAGE,
     "从设定、大纲到正文、续写与改稿，也照参考图写，保持人物、能力和伏笔连贯"),
    ("HOST-22", YAML_PAGE,
     "处理我提供的小说材料（稿子、设定、参考图），"),
    ("HOST-28", EXAMPLES_PAGE,
     "想把这张图留到以后用，说一声，它会记下借了哪几样：能跑脚本的环境记进本书的灵感库，跑不了的记成一"
     "条手记交给你存，下次带回来接着用。"),
    ("HOST-29", EXAMPLES_PAGE,
     "这一条要能跑脚本、脚本连得上网。跑不了的环境不用说“先用 doctor 看五个项目装好没有”，说"
     "“帮我找图”就行：工坊先看宿主有什么，宿主有自己的搜索的，由它按几个短搜索词找，挑几张给你，每张"
     "写明来源页和页面上写的许可（工坊没核）；它只见到标题和链接、没见到图的，会照实说，请你自己点开看"
     "；宿主没有搜索的，把搜索词交给你自己搜，或者请你发图。记录是一条手记，由你存。断着网时 `doc"
     "tor` 不加 `--probe` 仍会把 Openverse 报成配好了，到搜索那一步才报失败"
     "。"),
    ("HOST-30", QUICK_PAGE,
     "想把这张图留到以后用，记不记得下来要看环境：能跑脚本的记进灵感库，跑不了的记成一条手记，由你存、"
     "下次带回。更多写法见 [使用示例](EXAMPLES.md) 第 24 条。"),
    ("HOST-31", USAGE_PAGE,
     "| 环境 | 做法 | 能用到什么 | 看图、找图、记图 |\n| --- | --- | ---"
     " | --- |\n"),
    ("HOST-31", USAGE_PAGE,
     "宿主看图；能跑脚本的，灵感库用脚本读写，每次写库以后把本书的 `inspiration/` 整个"
     "文件夹交你存、下次带回；脚本连得上网、五个项目也装了才走脚本找图，不然由宿主自己搜，或者你给图 "
     "|"),
    ("HOST-31", USAGE_PAGE,
     "你发图，宿主看；宿主有自己的搜索的可以自己找图；记录是一份手记，由你存、下次带回；常用图的，把 "
     "[看图与手记卡](skills/novel-workshop/assets/visual-not"
     "es-card.md) 也贴进项目指令 |"),
    ("HOST-31", USAGE_PAGE,
     "同上；手记贴在对话里，新对话要你重新带回 |"),
    ("HOST-31", USAGE_PAGE,
     "最后一栏里看不看得到图、有没有搜索、跑不跑得了脚本、文件留不留得住，各个平台不一样，工坊没有逐个"
     "验证，以你那里试到的为准（[看图与手记卡](skills/novel-workshop/asse"
     "ts/visual-notes-card.md) 第 1 节）。"),
    ("HOST-32", USAGE_PAGE,
     "单文件约一百四十万字节（它把风格卡库整份嵌了进去）。"),  # the number: test_the_size_of_the_single_file
    ("HOST-33", USAGE_PAGE,
     "写作、审稿和灵感库的 `check`、`list`、`card` 不需要它。这一节讲的是脚本那条"
     "路，要能跑脚本、脚本连得上网；跑不了的，看图、找图、记图照 [看图与手记卡](skills/no"
     "vel-workshop/assets/visual-notes-card.md)。"),
    ("LIB-51", USAGE_PAGE,
     "# r5.61 起：作者给的图一条命令入库（收图、算哈希、记看到的）；没带 --take 的先记"
     "成“看过了等作者挑”，作者说了借哪几样，带上 --id、--take 和作者的原话 --word"
     "s 再跑一次\npython3 scripts/inspiration_write.py add-"
     "image 作品/inspiration/library.json --if-revision "
     "N --image 图片文件 --title 标题 --seen \"看到的\" --by \"谁看的"
     "\""),
]


def read(relative):
    return (ROOT / relative).read_text(encoding="utf-8")


def section(text, heading):
    """From a heading line to the next heading of the same or a higher level ("" if the heading is missing)."""
    level = len(heading) - len(heading.lstrip("#"))
    start = text.find("\n" + heading + "\n")
    if start < 0:
        return ""
    found = re.search(r"(?m)^#{1,%d} " % level, text[start + 1 + len(heading):])
    end = start + 1 + len(heading) + found.start() if found else len(text)
    return text[start:end]


def row(text, start):
    """The one table row of text that starts with start."""
    rows = [line for line in text.splitlines() if line.startswith(start)]
    assert len(rows) == 1, (start, len(rows))
    return rows[0]


def cells(line):
    return [cell.strip() for cell in line.strip().strip("|").split(" | ")]


def png(width, height, rgb):
    """A small PNG made here (standard library only)."""
    raw = b"".join(b"\x00" + bytes(rgb) * width for _ in range(height))

    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))


class NewSentences(unittest.TestCase):
    def test_each_new_sentence_is_on_its_page_once_without_the_four_words(self):
        for item, page, sentence in NEW:
            with self.subTest(item=item, sentence=sentence[:30]):
                self.assertEqual(read(page).count(sentence), 1)
                self.assertEqual([word for word in HARD if word in sentence], [])

    def test_the_links_to_the_card_lead_to_the_card(self):
        self.assertTrue((SKILL / CARD_FILE).is_file())
        for item, page, sentence in NEW:
            for target in re.findall(r"\[看图与手记卡\]\(([^)]+)\)", sentence):
                with self.subTest(item=item, target=target):
                    self.assertTrue(((ROOT / page).parent / target).resolve() == (SKILL / CARD_FILE).resolve())


class EntryPage(unittest.TestCase):
    def setUp(self):
        self.text = read(SKILL_PAGE)

    def test_the_description_names_reference_images(self):  # HOST-21
        description = row(self.text, "description: ")
        self.assertIn("续写、照参考图或照片写和改、文笔修改、", description)

    def test_the_chat_only_item_points_to_the_card(self):  # HOST-20
        item = row(self.text, "- 只能聊天、或者只能上传单文件的环境")
        self.assertIn("风格包不在单文件里要作者另给什么。看图、找图、记图，另照 " + CARD_FROM_SKILL
                      + "：先看宿主有什么，跑不了脚本时记手记。", item)
        self.assertLess(item.index("[改稿卡](assets/revision-card.md)"), item.index(CARD_FROM_SKILL))

    def test_the_revision_row_points_to_the_paragraph(self):  # EDIT-08
        first, second, third = cells(row(self.text, "| 文笔修改、"))
        self.assertTrue(first.endswith("；作者交了参考图、要照着改一份已有的稿"), first)
        self.assertTrue(second.endswith("；照参考图改已有的稿：[editing.md](references/editing.md)“要求修改时”里的“手上有参考图时”（r5.61）"),
                        second)
        self.assertIn("问改得对不对：[teacher-review.md](references/teacher-review.md)（r5.54）", second)  # test_r554_dialogue
        self.assertEqual(third, "结合正文定位问题，选择修补范围并复核语义变化")
        # the paragraph the row names is there, under the heading the row names
        editing = read("skills/novel-workshop/references/editing.md")
        self.assertEqual(editing.count(LEAD), 1)
        self.assertIn(LEAD, section(editing, "## 要求修改时"))

    def test_what_stays_as_it_was(self):
        level1 = row(self.text, "| L1 ")
        for words in ("手上有参考图", "看图与手记卡", "照参考图"):  # it named 参考图 before r5.61 and still does
            self.assertNotIn(words, level1)  # the L1 line is pinned by hash and mirrored by the gate card
        self.assertNotIn("手上有参考图", read("skills/novel-workshop/assets/delivery-gate-card.md"))
        self.assertNotIn("手上有参考图", read("skills/novel-workshop/assets/revision-card.md"))
        self.assertIn("- **范围**：整章写作、整章重写。", read("skills/novel-workshop/CONSTITUTION.md"))

    def test_the_library_row_sends_to_the_card_first(self):  # HOST-17
        line = row(self.text, "| 找参考图、建本书的灵感库；")
        second = cells(line)[1]
        self.assertTrue(second.startswith("先读 " + CARD_FROM_SKILL + " 第 1 节，看宿主有什么；"), second)
        self.assertLess(second.index(CARD_FROM_SKILL), second.index("[inspiration-library.md](references/inspiration-library.md)"))
        # test_r534_review_followups finds this row by these characters; the card link stays in front of them
        self.assertTrue(line.split(" | ")[1].endswith("](references/inspiration-library.md)"), line[:80])
        self.assertEqual(self.text.count("](references/inspiration-library.md) |"), 1)

    def test_the_script_row_says_when_to_take_it(self):  # HOST-18
        line = row(self.text, "| 用工坊的脚本给一章找参考图")
        first, second, third = cells(line)
        self.assertIn("（先照 " + CARD_FROM_SKILL + " 第 1 节看宿主有什么，能跑脚本、脚本连得上网、五个项目装好了才走这一行）", first)
        self.assertEqual(second, "[visual-materials.md](references/visual-materials.md)")
        self.assertIn("先用 `doctor` 看 SearXNG、Openverse、Crawl4AI、ImageHash、OpenCLIP 五项装好没有", third)
        self.assertIn("没装、没网照常写作", third)
        self.assertEqual([l for l in self.text.splitlines() if l.startswith("| 要给一章自动找参考图：")], [])

    def test_the_network_sentence_is_about_the_scripts(self):  # HOST-19
        self.assertIn("；用工坊的脚本联网找图时只走 [visual_materials_cli.py](scripts/visual_materials_cli.py)（按预算取图", self.text)
        self.assertNotIn("；联网找图只走", self.text)

    def test_the_interface_configuration(self):  # HOST-22
        self.assertEqual(len(list((SKILL / "agents").glob("*.yaml"))), 1)
        text = read(YAML_PAGE)
        keys = re.findall(r"(?m)^( *)([a-z_]+):", text)
        self.assertEqual([(len(indent), key) for indent, key in keys],
                         [(0, "interface"), (2, "display_name"), (2, "short_description"), (2, "default_prompt"),
                          (2, "icon_small"), (2, "icon_large"), (0, "policy"), (2, "products"),
                          (2, "allow_implicit_invocation")])
        self.assertEqual(len(re.findall(r"(?m)^  - \S+$", text)), 4)  # the list of products is as it was
        short = row(text, "  short_description: ")
        prompt = row(text, "  default_prompt: ")
        self.assertIn("参考图", short)
        self.assertIn("参考图", prompt)
        self.assertIn("用 $novel-workshop 处理我提供的小说材料（稿子、设定、参考图），按当前要求完成创作或修改", prompt)


class RootPages(unittest.TestCase):
    def test_examples_24_and_25(self):  # HOST-28, HOST-29
        text = read(EXAMPLES_PAGE)
        item24 = section(text, "## 24. 只有一张图和一句感受")
        self.assertIn("它会记下借了哪几样：能跑脚本的环境记进本书的灵感库，跑不了的记成一条手记交给你存", item24)
        self.assertNotIn("说一声，它记进本书的灵感库，写清借了哪几样。", text)
        item25 = section(text, "## 25. 让工坊自己找图（五个项目）")
        # the request and the note above stay; the new paragraph comes after the note's last sentence
        self.assertIn("先用 doctor 看五个项目装好没有；搜索只发几个短词，不发正文。", item25)
        note_end = item25.index("图里的光、材质可以只给气氛，不必样样变成道具。")
        added = item25.index("这一条要能跑脚本、脚本连得上网。")
        self.assertLess(note_end, added)
        self.assertIn("不必样样变成道具。\n\n这一条要能跑脚本", item25)
        for phrase in ("说“帮我找图”就行：工坊先看宿主有什么", "每张写明来源页和页面上写的许可（工坊没核）",
                       "没见到图的，会照实说", "宿主没有搜索的，把搜索词交给你自己搜，或者请你发图", "记录是一条手记，由你存",
                       "不加 `--probe` 仍会把 Openverse 报成配好了"):
            self.assertIn(phrase, item25[added:], phrase)

    def test_quickstart_first_use(self):  # HOST-30
        first = section(read(QUICK_PAGE), "## 第一次用：一张图加一句话就能开始")
        self.assertIn("想把这张图留到以后用，记不记得下来要看环境：能跑脚本的记进灵感库，跑不了的记成一条手记，由你存、下次带回。"
                      "更多写法见 [使用示例](EXAMPLES.md) 第 24 条。", first)

    def test_the_table_by_environment(self):  # HOST-31
        part = section(read(USAGE_PAGE), "## 一、按环境选择用法")
        lines = part.splitlines()
        head = lines.index("| 环境 | 做法 | 能用到什么 | 看图、找图、记图 |")
        self.assertEqual(lines[head + 1], "| --- | --- | --- | --- |")
        rows = lines[head + 2:head + 5]
        self.assertEqual([len(cells(line)) for line in rows], [4, 4, 4], rows)
        self.assertEqual(lines[head + 5], "")
        last = [cells(line)[3] for line in rows]
        self.assertIn("脚本连得上网、五个项目也装了才走脚本找图", last[0])
        self.assertIn(CARD_FROM_ROOT, last[1])
        self.assertIn("手记贴在对话里，新对话要你重新带回", last[2])
        after = part.index("最后一栏里看不看得到图、")
        self.assertIn("工坊没有逐个验证，以你那里试到的为准（" + CARD_FROM_ROOT + " 第 1 节）。", part[after:])
        self.assertLess(after, part.index("**平台自己管的技能目录（r5.40）。**"))

    def test_the_size_of_the_single_file(self):  # HOST-32
        part = section(read(USAGE_PAGE), "## 一、按环境选择用法")
        found = re.findall(r"单文件(约|有)一百([一二三四五六七八九])十(多)?万字节（它把风格卡库整份嵌了进去）。", part)
        self.assertEqual(len(found), 1, found)
        about, tens, more = found[0]
        stated = 1000000 + "一二三四五六七八九".index(tens) * 100000 + 100000
        self.assertEqual(bool(more), about == "有", found)  # "约一百几十万" or "有一百几十多万"
        path = ROOT / PORTABLE
        if path.is_file():
            actual = path.stat().st_size
        else:  # no single file at the package root: export one the way the package does
            actual = len(export_single_file())
        if about == "约":
            self.assertLess(abs(actual - stated), 50000, (stated, actual))
        else:
            self.assertTrue(stated <= actual < stated + 100000, (stated, actual))

    def test_the_visual_section_names_the_other_road(self):  # HOST-33
        part = section(read(USAGE_PAGE), "### 视觉素材（r5.35 起，可选）")
        first = part.split("\n\n")[1]
        self.assertTrue(first.endswith("这一节讲的是脚本那条路，要能跑脚本、脚本连得上网；跑不了的，看图、找图、记图照 "
                                       + CARD_FROM_ROOT + "。"), first[-80:])


def export_single_file():
    spec = importlib.util.spec_from_file_location("r561_entry_export_portable", SKILL / "scripts" / "export_portable.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    with tempfile.TemporaryDirectory() as tmp:
        target = Path(tmp) / "sale.zip"
        module.export(SKILL, target, mode="sale", format="portable")
        with zipfile.ZipFile(target) as archive:
            return archive.read(PORTABLE)


class TheCommandInTheList(unittest.TestCase):  # LIB-51, B-01: the add-image line of USAGE.md, run as it stands
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.library = self.root / "作品" / "inspiration" / "library.json"
        self.library.parent.mkdir(parents=True)
        self.library.write_bytes(json.dumps({"schema": "inspiration-library/2", "book": "测试", "revision": 0,
                                             "entries": []}, ensure_ascii=False).encode("utf-8"))
        self.picture = self.root / "收到的图" / "粮站磅秤.png"
        self.picture.parent.mkdir()
        self.picture.write_bytes(png(6, 5, (128, 104, 72)))
        text = read(USAGE_PAGE)
        lines = text.splitlines()
        at = lines.index("#           没写的报 ERROR，什么都不写；库里已经有这个选择的报 UNCHANGED，不写新版")
        self.comment, self.command = lines[at + 1], lines[at + 2]
        self.assertEqual([l for l in lines if "inspiration_write.py add-image" in l], [self.command])

    def tearDown(self):
        self.tmp.cleanup()

    def test_as_the_list_says(self):
        self.assertTrue(self.comment.startswith("# r5.61 起："), self.comment)
        for flag in ("--take", "--id", "--words"):
            self.assertIn(flag, self.comment)
        words = shlex.split(self.command)
        self.assertEqual(words[:3], ["python3", "scripts/inspiration_write.py", "add-image"])
        values = {"作品/inspiration/library.json": self.library, "N": 0, "图片文件": self.picture,
                  "标题": "旧粮站的磅秤", "看到的": "磅秤的铁盘生了锈，秤杆上挂着一只铜砣，地上撒着几粒麦子", "谁看的": "工坊"}
        self.assertEqual(set(values) - set(words), set())  # every placeholder is in the line
        args = [str(values.get(w, w)) for w in words[2:]]
        # the list is run from skills/novel-workshop (python3 scripts/...); the script is the package's, -I -B
        proc = subprocess.run([sys.executable, "-I", "-B", str(SKILL / words[1])] + args, cwd=str(self.root),
                              capture_output=True, text=True, encoding="utf-8")
        report = json.loads(proc.stdout)
        self.assertEqual((proc.returncode, report["status"], report["recorded_as"]), (0, "OK", "candidate"), report)
        proc = subprocess.run([sys.executable, "-I", "-B", str(SKILL / "scripts" / "inspiration_library.py"), "check",
                               str(self.library)], capture_output=True, text=True, encoding="utf-8")
        self.assertEqual((proc.returncode, json.loads(proc.stdout)["status"]), (0, "OK"), proc.stdout)


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""r5.13: repairs from the 2026-10-19 self-review of r5.12 (files saved by other editors; short lines at segment edges).

- F1: the delivery gate read the candidate as plain UTF-8 and compared lines with their line breaks attached, while
  the other checkers drop a leading byte-order mark (BOM, U+FEFF) and read CRLF as an ordinary line break. With a BOM
  the title line was not recognised (the title check failed, the length check counted the title), and since r5.11 the
  expression record could never cover line 1: a strict PASS was impossible whatever the record said. A frozen source
  saved with a BOM or with CRLF line breaks made the scope check report lines the task never touched. The gate now
  reads text the way the checkers do; hashes are still taken over the bytes.
- F2: `status --deliverable` called a copy that differed only in its line breaks (CRLF) or a BOM "not the checked
  version", although its text is the same.
- F3: a line shorter than the four-character anchor minimum (a title such as 楔子, a one-word last line) is covered
  by an anchor that runs across the line break; the refusal did not say so.
All material is invented for these tests; reviews are labelled test data and are not literary judgments.
"""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
GUARD = ROOT / "skills" / "novel-workshop" / "scripts" / "workflow_guard.py"
DIMENSIONS = ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function", "continuity",
              "revision_comparison")
BOM = "﻿"
TITLE = "第三章　渡口"
PARAGRAPHS = [
    "风停以后，渡口只剩下水拍木桩的声音。林舟提着马灯下到栈桥，先看缆绳，再看船帮。",
    "小满跟在后面，手里攥着一把木楔子。他昨天才来，连哪根缆是系锚的都分不清。",
    "林舟蹲下，用指节敲了敲裂缝两边。左边是实的，右边发空。他把马灯递给小满：“照着，别晃。”",
    "补缝用了小半个时辰。林舟先把裂口两边削平，再一片一片嵌进木楔，听声音发实了才换下一片。",
    "最后一片嵌进去时，东边的天已经发青。林舟往船舱里舀了两瓢水，蹲着看了一阵，缝里没有渗出水来。",
    "栈桥那头传来脚步声。运货的人到了，问船能不能走。林舟解开缆绳，说能走。",
]
BODY = "\n\n".join(PARAGRAPHS) + "\n"
CHAPTER = TITLE + "\n\n" + BODY
SEGMENTS = [{"from": "风停以后，渡口", "to": "“照着，别晃。”", "note": "测试数据：前三段逐句连读，没有要改的"},
            {"from": "补缝用了小半个", "to": "林舟解开缆绳，说能走。", "note": "测试数据：后三段逐句连读，保留原样"}]
TITLE_CHECKS = [{"id": "title", "type": "title", "min": 2, "max": 30},
                {"id": "length", "type": "length", "min": 100, "basis": "non_whitespace", "exclude_headings": True}]


class Run(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.dir)

    def write(self, name, text):
        (self.dir / name).write_bytes(text.encode("utf-8"))

    def guard(self, *args):
        proc = subprocess.run([sys.executable, "-I", "-B", str(GUARD), *args], cwd=self.dir, capture_output=True,
                              text=True, encoding="utf-8")
        try:
            return proc.returncode, json.loads(proc.stdout)
        except ValueError:
            return proc.returncode, {"raw": proc.stdout[-400:], "stderr": proc.stderr[-400:]}

    def spec(self, text, checks=TITLE_CHECKS):
        self.write("draft.md", text)
        self.write("checks.json", json.dumps({"candidate": "draft.md", "mode": "strict", "checks": checks},
                                             ensure_ascii=False))

    def start(self, text, checks=TITLE_CHECKS):
        self.spec(text, checks)
        code, out = self.guard("start", "run.json", "--task-id", "t", "--spec", "checks.json")
        self.assertEqual(code, 0, out)

    def checks(self):
        code, report = self.guard("check", "checks.json")
        self.assertIn("checks", report, report)
        return {item["id"]: item for item in report["checks"]}

    def review(self, name, segments=SEGMENTS, decisions=(), verdict="PASS", issues=()):
        value = {"schema": "editorial-review/2", "verdict": verdict,
                 "candidate_sha256": hashlib.sha256((self.dir / "draft.md").read_bytes()).hexdigest(),
                 "reviewer": {"mode": "self_check", "label": "测试数据：只验证记录结构"},
                 "checked_against": ["测试数据"], "inputs_read": [],
                 "evidence": [{"quote": q, "in": "candidate"}
                              for q in ("林舟提着马灯下到栈桥", "补缝用了小半个时辰", "运货的人到了，问船能不能走")],
                 "issues": list(issues), "machine_dispositions": [], "counter_evidence": "测试数据，不是真实文学审稿。",
                 "dimensions": [{"id": key, "status": "met", "note": "测试数据：只验证记录结构"} for key in DIMENSIONS],
                 "expression": {"scope": "chapter", "segments": segments, "decisions": list(decisions)}}
        self.write(name, json.dumps(value, ensure_ascii=False))
        return name

    def record(self, event, name):
        return self.guard("record", "run.json", "--event-id", event, "--review", name)

    def gate(self, *extra):
        code, out = self.guard("status", "run.json", *extra)
        return code, out.get("gate", out)


class ByteOrderMarkAndLineBreaks(Run):
    def test_a_bom_hides_neither_the_title_nor_line_one(self):
        self.start(BOM + CHAPTER)
        results = self.checks()
        self.assertEqual((results["title"]["actual"]["title"], results["title"]["passed"]), ("渡口", True))
        code, out = self.record("v1", self.review("pass.json"))
        self.assertEqual(code, 0, out)  # r5.11, r5.12: REVIEW_INCOMPLETE, "not covered: candidate line(s) 1"
        gate = self.gate()[1]
        self.assertEqual((gate["mechanical"], gate["editorial"]), ("GREEN", "PASS[self_check]"))

    def test_the_same_text_counts_the_same_in_every_form(self):
        found = {}
        for label, text in (("LF", CHAPTER), ("BOM", BOM + CHAPTER), ("CRLF", CHAPTER.replace("\n", "\r\n"))):
            self.spec(text)
            found[label] = {key: item["actual"] for key, item in self.checks().items()}
        self.assertEqual(found["BOM"], found["LF"])  # r5.12: the title is missed and counted as text
        self.assertEqual(found["CRLF"], found["LF"])

    def test_resaving_the_text_with_a_bom_is_not_an_edit(self):
        self.start(CHAPTER)
        self.assertEqual(self.record("v1", self.review("v1.json"))[0], 0)
        self.write("draft.md", BOM + CHAPTER)  # an editor saved the file again; nobody changed a word
        self.assertEqual(self.gate()[1]["editorial"], "STALE")  # other bytes: the old record does not carry over
        self.assertEqual(self.guard("reserve", "run.json", "--event-id", "r1")[0], 0)
        code, out = self.record("v2", self.review("v2.json"))
        self.assertEqual(code, 0, out)  # no decision is owed for a change no reader can see
        self.assertEqual(self.gate()[1]["editorial"], "PASS[self_check]")

    def test_a_change_across_a_line_break_is_found_in_an_earlier_crlf_version(self):
        self.start(CHAPTER.replace("\n", "\r\n"))
        self.assertEqual(self.record("v1", self.review("v1.json"))[0], 0)
        deleted = PARAGRAPHS[1] + "\n\n"  # a paragraph and the blank line after it, quoted with \n as in any record
        self.write("draft.md", CHAPTER.replace(deleted, ""))
        self.assertEqual(self.guard("reserve", "run.json", "--event-id", "r1")[0], 0)
        change = {"decision": "change", "before": deleted, "after": "", "judgment": "测试数据：这一段交代的是学徒的来历",
                  "reason": "测试数据：只验证记录结构"}
        code, out = self.record("v2", self.review("v2.json", decisions=[change]))
        self.assertEqual(code, 0, out)  # the CRLF bytes kept for v1 are read with LF line breaks, like the candidate

    def test_a_quote_across_a_line_break_is_found_in_a_crlf_source(self):
        self.write("original.md", CHAPTER.replace("\n", "\r\n"))
        line = CHAPTER.splitlines().index(PARAGRAPHS[-1]) + 1
        self.start(CHAPTER.replace("说能走。", "说走吧。"),
                   [{"id": "scope", "type": "scope", "source": "original.md", "editable_lines": [[line, line]]}])
        issue = {"quote": "缝里没有渗出水来。\n\n栈桥那头", "in": "original.md",
                 "expected": "测试数据：两段之间的衔接", "impact": "测试数据：只验证记录结构"}
        segments = [SEGMENTS[0], dict(SEGMENTS[1], to="林舟解开缆绳，说走吧。")]
        code, out = self.record("v1", self.review("needs.json", segments, verdict="NEEDS_REVISION", issues=[issue]))
        self.assertEqual(code, 0, out)  # the frozen CRLF source is read with LF line breaks, like the candidate

    def test_line_breaks_or_a_bom_in_the_source_are_not_edits_outside_the_scope(self):
        edited = CHAPTER.replace("别晃。", "别乱晃。")  # the one authorised line, in the middle of the text
        line = CHAPTER.splitlines().index(PARAGRAPHS[2]) + 1
        scope = [{"id": "scope", "type": "scope", "source": "original.md", "editable_lines": [[line, line]]}]
        for label, source, candidate in (("BOM source", BOM + CHAPTER, edited),
                                         ("CRLF source", CHAPTER.replace("\n", "\r\n"), edited),
                                         ("CRLF candidate", CHAPTER, edited.replace("\n", "\r\n")),
                                         ("no final newline in the source", CHAPTER.rstrip("\n"), edited)):
            self.write("original.md", source)
            self.spec(candidate, scope)
            result = self.checks()["scope"]
            self.assertTrue(result["passed"], (label, result["actual"]))  # r5.12: line 1, or every line, "changed"
            self.assertEqual([change["source_lines"] for change in result["actual"]], [[line, line]], label)


class DeliveredCopies(Run):
    def test_a_copy_that_differs_only_in_line_breaks_or_a_bom_is_the_checked_text(self):
        self.start(CHAPTER)
        self.assertEqual(self.record("v1", self.review("v1.json"))[0], 0)
        crlf = CHAPTER.replace("\n", "\r\n")
        for name, text in (("crlf.txt", crlf), ("bom.txt", BOM + CHAPTER), ("both.txt", BOM + crlf.rstrip("\r\n"))):
            self.write(name, text)
            code, gate = self.gate("--deliverable", name)
            self.assertEqual((code, gate["deliverable"]["matches"]), (0, "line_endings_or_bom_only"), name)
            self.assertIn("CRLF", gate["deliverable"]["note"])  # said as it is: same text, other bytes
            self.assertNotEqual(gate["permissions"]["claim_reviewed"]["decision"], "BLOCK", name)
            self.assertNotIn("MISMATCH", gate["summary"])
        self.write("edited.txt", crlf.replace("说能走", "说走吧"))  # a changed word behind the new line breaks
        code, gate = self.gate("--deliverable", "edited.txt")
        self.assertEqual((code, gate["deliverable"]["matches"]), (1, "no"))
        self.assertEqual(gate["permissions"]["claim_reviewed"]["decision"], "BLOCK")


class ShortLines(Run):
    def test_a_short_title_is_covered_by_an_anchor_across_the_line_break(self):
        # Only a first line starting with 第N章 or # is a title the record may leave out; 楔子 is text to cover.
        self.start("楔子\n\n" + BODY, [{"id": "length", "type": "length", "min": 100}])
        code, out = self.record("v1", self.review("body-only.json"))
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertIn("line(s) 1", out["message"])
        self.assertIn("across the line break", out["message"])  # r5.12 did not say how to cover a two-character line
        spanning = [dict(SEGMENTS[0], **{"from": "楔子\n\n风停以后"}), SEGMENTS[1]]
        code, out = self.record("v2", self.review("spanning.json", spanning))
        self.assertEqual(code, 0, out)

    def test_a_short_last_line_in_a_crlf_file_is_covered_the_same_way(self):
        text = (CHAPTER + "\n走。\n").replace("\n", "\r\n")
        self.start(text)
        code, out = self.record("v1", self.review("body-only.json"))
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertIn("across the line break", out["message"])
        # Written with \n as in any record; the file's CRLF line breaks are read as line breaks.
        spanning = [SEGMENTS[0], dict(SEGMENTS[1], to="说能走。\n\n走。")]
        code, out = self.record("v2", self.review("spanning.json", spanning))
        self.assertEqual(code, 0, out)

    def test_a_line_long_enough_for_an_anchor_gets_no_hint(self):
        self.start("番外：雨夜渡河\n\n" + BODY, [{"id": "length", "type": "length", "min": 100}])
        code, out = self.record("v1", self.review("body-only.json"))
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertNotIn("across the line break", out["message"])
        spanning = [dict(SEGMENTS[0], **{"from": "番外：雨夜渡河"}), SEGMENTS[1]]
        self.assertEqual(self.record("v2", self.review("titled.json", spanning))[0], 0)


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""r5.8: repairs for the 2026-10-17 review of the r5.6 candidate (speech written inline mixed with speaker lines).

The review's example: 秦照's words stand on a line of their own with his speaker line below them; 黎渔 says the same
words inline ("黎渔低声说：“知道了？”"). The revision trades the two people's places -- each place keeps its layout --
and changes both marks. r5.5 to r5.7 reported nothing and the strict gate passed with nothing to decide; r5.4 flagged
both lines. Two things together hid the change:
- A line holding nothing but speech was taken as unique when no other such line had the same words, although the
  same words were spoken inline elsewhere ("words" keys were counted on speech-only lines only). The line became an
  anchor and was paired in place with the other person's words.
- The speaker lines below the words ("秦照低声说。" -> "黎渔低声说。") were taken as one line rewritten in place,
  although the two names had only traded places with another changed line. Pairing "by place" then did the same.
Uniqueness now counts every utterance, inline and several quotes on a line included; and a changed line whose removed
text went to another changed line, or whose new text came from one, is no rewrite in place (the keep-slots fuzz in
repro/r5.8 showed that one side is enough evidence, and needed: see ExchangesSeenFromOneSide).
Uncertain items are acceptable here; passing a real change unreported, or reporting one that did not happen, is not.
All material is invented for these tests; reviews are labelled test data.
"""

import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SCRIPTS = ROOT / "skills" / "novel-workshop" / "scripts"
DIMENSIONS = ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function", "continuity",
              "revision_comparison")

# The review's own texts (with the two neutral narration lines its gate fixture appends).
TAIL = "\n门外有人经过，脚步声渐渐远去。\n窗边那盏旧灯还亮着。\n"
ORIGINAL = "“知道了！”\n秦照低声说。\n\n黎渔低声说：“知道了？”\n" + TAIL
CHANGED = "“知道了！”\n黎渔低声说。\n\n秦照低声说：“知道了？”\n" + TAIL
PURE_MOVE = "“知道了？”\n黎渔低声说。\n\n秦照低声说：“知道了！”\n" + TAIL

# One person's paragraph in each layout: lines, and the index of the line that holds the words.
LAYOUTS = {
    "inline": (("{n}低声说：“{w}”",), 0),
    "above": (("{n}低声说：", "“{w}”"), 1),
    "separated": (("{n}低声说：", "", "“{w}”"), 2),
    "below": (("“{w}”", "{n}低声说。"), 0),
    "lead": (("{n}点了点头。", "“{w}”"), 1),
}
NAMES = ("秦照", "黎渔", "莫川")


def compare(original, revised):
    spec = importlib.util.spec_from_file_location("r58_punctuation", SCRIPTS / "punctuation_lint.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.compare_texts(original, revised)


def flagged_lines(report):
    return {t["line"] for t in report["tone_changes"]}


def render(people, tail=""):
    """people: (name, layout, mark) in reading order, paragraphs separated by a blank line. Returns the text and, for
    each name, the line that holds the words."""
    blocks, where, line = [], {}, 1
    for name, layout, mark in people:
        lines, at = LAYOUTS[layout]
        block = [part.format(n=name, w="知道了" + mark) for part in lines]
        where[name] = line + at
        blocks.append("\n".join(block))
        line += len(block) + 1
    return "\n\n".join(blocks) + "\n" + tail, where


class Checks:
    def check(self, original_people, revised_people, tail=""):
        original, _ = render(original_people, tail)
        revised, where = render(revised_people, tail)
        report = compare(original, revised)
        old = {name: mark for name, _, mark in original_people}
        truth = {where[name]: (old[name], mark) for name, _, mark in revised_people}
        flagged = flagged_lines(report)
        for line, (before, after) in truth.items():
            if before != after:
                self.assertIn(line, flagged, (original, revised, report["tone_changes"]))
        for item in report["tone_changes"]:
            if item["match"] != "uncertain":
                self.assertEqual((item["before"], item["after"]), truth.get(item["line"]),
                                 (original, revised, report["tone_changes"]))


class TheReportsMixedLayout(unittest.TestCase):
    """The review's example, word for word."""

    def test_both_changes_are_flagged(self):
        report = compare(ORIGINAL, CHANGED)
        # 黎渔 (now line 1) went from ？ to ！; 秦照 (now line 4) went from ！ to ？.
        self.assertTrue({1, 4} <= flagged_lines(report), report["tone_changes"])
        for item in report["tone_changes"]:
            if item["match"] != "uncertain":
                self.assertIn((item["line"], item["before"] + "→" + item["after"]), [(1, "？→！"), (4, "！→？")])

    def test_trading_places_alone_is_never_a_certain_change(self):
        # r5.5 to r5.7 reported line 1 ！→？ (same_line) and line 4 ？→！ (changed_line); neither happened.
        report = compare(ORIGINAL, PURE_MOVE)
        self.assertEqual([t for t in report["tone_changes"] if t["match"] != "uncertain"], [], report["tone_changes"])

    def test_the_gate_needs_decisions(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            (work / "original.md").write_text(ORIGINAL, encoding="utf-8")
            (work / "draft.md").write_text(CHANGED, encoding="utf-8")
            (work / "checks.json").write_text(json.dumps({"candidate": "draft.md", "mode": "strict", "checks": [
                {"id": "rev", "type": "revision", "source": "original.md"}]}), encoding="utf-8")

            def run(*args):
                proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPTS / "workflow_guard.py"), *args], cwd=work,
                                      capture_output=True, text=True, encoding="utf-8")
                return proc.returncode, json.loads(proc.stdout)

            def review(name, dispositions):
                # The review's own fixture: three separate quotes, all six dimensions, labelled test data.
                (work / name).write_text(json.dumps({
                    "schema": "editorial-review/2", "verdict": "PASS",
                    "candidate_sha256": hashlib.sha256((work / "draft.md").read_bytes()).hexdigest(),
                    "reviewer": {"mode": "self_check", "label": "测试数据：只验证结构"},
                    "checked_against": ["测试数据：original.md"], "inputs_read": ["original.md"],
                    "evidence": [{"in": "candidate", "quote": q}
                                 for q in ("“知道了！”", "秦照低声说：“知道了？”", "窗边那盏旧灯还亮着。")],
                    "issues": [], "counter_evidence": "测试数据，不是真实文学审稿。", "machine_dispositions": dispositions,
                    "dimensions": [{"id": key, "status": "met", "note": "测试数据：只验证结构"} for key in DIMENSIONS]},
                    ensure_ascii=False), encoding="utf-8")
                return name

            self.assertEqual(run("start", "state.json", "--task-id", "r58", "--spec", "checks.json")[0], 0)
            items = [x["id"] for x in run("check", "checks.json")[1]["review_items"]]
            self.assertTrue({"rev:TONE-L1-C1", "rev:TONE-L4-C7"} <= set(items), items)
            code, out = run("record", "state.json", "--event-id", "v1", "--review", review("none.json", []))
            self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"))
            code, _ = run("record", "state.json", "--event-id", "v2", "--review", review("all.json", [
                {"id": key, "decision": "keep", "reason": "测试数据：逐句对照过原稿"} for key in items]))
            self.assertEqual(code, 0)
            gate = run("status", "state.json")[1]["gate"]
            self.assertEqual((gate["mechanical"], gate["editorial"], gate["review_items_open"]), ("GREEN", "PASS[self_check]", 0))


class TwoPeopleTradePlaces(Checks, unittest.TestCase):
    """Two people say the same words, each in any of five layouts. The revision trades their places -- each place keeps
    its layout, as in the review -- or keeps them, with marks kept, traded or changed for one person; with and without
    narration after them. A real change must always be in front of a person; a mark that did not change must never be
    a certain change."""

    MARKS = [("！", "？"), ("。", "！"), ("？", "？")]

    def cases(self):
        for first, second in itertools.product(LAYOUTS, repeat=2):
            for marks in self.MARKS:
                for tail in ("", TAIL):
                    yield first, second, marks, tail

    def run_cases(self, revise):
        for first, second, (m1, m2), tail in self.cases():
            original = [(NAMES[0], first, m1), (NAMES[1], second, m2)]
            for revised in revise(first, second, m1, m2):
                with self.subTest(first=first, second=second, marks=m1 + m2, tail=bool(tail), revised=revised):
                    self.check(original, revised, tail)

    def test_places_traded_marks_kept(self):
        self.run_cases(lambda f, s, m1, m2: [[(NAMES[1], f, m2), (NAMES[0], s, m1)]])

    def test_places_traded_marks_traded(self):
        # The review's example is the case first="below", second="inline", marks ！？.
        self.run_cases(lambda f, s, m1, m2: [[(NAMES[1], f, m1), (NAMES[0], s, m2)]])

    def test_places_traded_one_mark_changed(self):
        other = {"！": "。", "。": "？", "？": "！"}
        self.run_cases(lambda f, s, m1, m2: [[(NAMES[1], f, other[m2]), (NAMES[0], s, m1)],
                                              [(NAMES[1], f, m2), (NAMES[0], s, other[m1])]])

    def test_places_kept_layouts_traded(self):
        # Each person keeps the place and takes the other's layout.
        other = {"！": "。", "。": "？", "？": "！"}
        self.run_cases(lambda f, s, m1, m2: [[(NAMES[0], s, m1), (NAMES[1], f, m2)],
                                              [(NAMES[0], s, other[m1]), (NAMES[1], f, m2)]])

    def test_the_reviews_example_is_in_this_matrix(self):
        original, _ = render([(NAMES[0], "below", "！"), (NAMES[1], "inline", "？")], TAIL)
        revised, _ = render([(NAMES[1], "below", "！"), (NAMES[0], "inline", "？")], TAIL)
        self.assertEqual((original, revised), (ORIGINAL, CHANGED))


class ThreePeopleMixed(Checks, unittest.TestCase):
    """Three people in mixed layouts; one paragraph moves or two people trade places, marks change for some."""

    def test_moves_and_trades(self):
        layouts = ("below", "inline", "above")
        orders = [(1, 0, 2), (0, 2, 1), (2, 0, 1), (1, 2, 0)]
        marks = [("！", "？", "！"), ("。", "。", "？")]
        other = {"！": "。", "。": "？", "？": "！"}
        for order, base, keep_slots in itertools.product(orders, marks, (True, False)):
            original = [(NAMES[k], layouts[k], base[k]) for k in range(3)]
            for changed in ((), (0,), (0, 2)):
                revised = []
                for slot, k in enumerate(order):
                    mark = other[base[k]] if k in changed else base[k]
                    revised.append((NAMES[k], layouts[slot] if keep_slots else layouts[k], mark))
                with self.subTest(order=order, marks="".join(base), keep_slots=keep_slots, changed=changed):
                    self.check(original, revised, TAIL)


class UniquenessCountsEveryUtterance(unittest.TestCase):
    """A line holding nothing but speech is known by its words only when those words are said once in each version:
    counted over every utterance, inline ones and several quotes on one line included."""

    def test_words_also_spoken_inline_are_not_unique(self):
        # 甲's “走吧” alone on a line, 乙 says “走吧” inline; they trade places and both marks change.
        original = "“走吧！”\n甲说完转身。\n\n乙低声说：“走吧。”\n"
        revised = "“走吧！”\n乙说完转身。\n\n甲低声说：“走吧？”\n"
        report = compare(original, revised)
        # Read by place, line 1 did not change and line 4 went from 。 to ？. Read by person, 乙 went from 。 to ！ and
        # 甲 from ！ to ？. Either way line 4 changed; line 1 must not be reported as certainly unchanged.
        self.assertIn(4, flagged_lines(report), report["tone_changes"])
        self.assertIn(1, flagged_lines(report), report["tone_changes"])

    def test_one_of_several_quotes_on_a_line_repeated_elsewhere(self):
        # A line with two quotes is unique only if both words are; “等等” is also said inline.
        original = "“走吧！”“等等。”\n甲回头看了一眼。\n\n乙低声说：“等等？”\n"
        revised = "“走吧！”“等等？”\n乙回头看了一眼。\n\n甲低声说：“等等。”\n"
        report = compare(original, revised)
        for item in report["tone_changes"]:
            if item["match"] != "uncertain":
                # Nothing on line 1 can be called certain: whose “等等” it is depends on who moved.
                self.assertNotEqual(item["line"], 1, report["tone_changes"])

    def test_unique_words_still_pair_as_before(self):
        # Words said once in each version, inline or not, still pair with certainty.
        original = "“走吧！”\n甲说完转身。\n\n乙低声说：“等等。”\n"
        revised = "“走吧？”\n甲说完转身。\n\n乙低声说：“等等！”\n"
        report = compare(original, revised)
        certain = sorted((t["line"], t["before"] + "→" + t["after"]) for t in report["tone_changes"]
                         if t["match"] != "uncertain")
        self.assertEqual(certain, [(1, "！→？"), (4, "。→！")], report["tone_changes"])


class RewritesThatAreExchanges(unittest.TestCase):
    """A changed line counts as rewritten in place only when nothing else explains the change. When what it lost went
    to another changed line, or what it gained came from one, lines exchanged parts (names, here), and the words next
    to them belong to other people now."""

    def rewritten(self, original, revised):
        spec = importlib.util.spec_from_file_location("r58_punctuation_rw", SCRIPTS / "punctuation_lint.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        from difflib import SequenceMatcher
        rules = module.load_rules(None)
        olds, news = module.utterances(original, rules), module.utterances(revised, rules)
        lines_a, lines_b = module.line_skeletons(original, olds), module.line_skeletons(revised, news)
        keys_a = module.line_identities(original, olds, lines_a)[0]
        keys_b = module.line_identities(revised, news, lines_b)[0]
        opcodes = SequenceMatcher(None, keys_a, keys_b, autojunk=False).get_opcodes()
        return module.rewritten_in_place(opcodes, keys_a, keys_b, lines_a, lines_b)

    def test_names_that_traded_lines_are_no_rewrite(self):
        # The review's speaker lines: 秦照 moved to the inline line and 黎渔 came from it.
        self.assertNotIn(1, self.rewritten(ORIGINAL, CHANGED))

    def test_a_reworded_speaker_line_is_still_a_rewrite(self):
        # What 陈青's line lost (“低声”) went nowhere else; it stays the same line, reworded.
        original = "陈青低声说：\n“知道了！”\n\n孟迟点了点头。\n"
        revised = "陈青压低嗓子说：\n“知道了！”\n\n孟迟点了点头。\n"
        self.assertEqual(self.rewritten(original, revised).get(0), 0)

    def test_a_renamed_speaker_line_alone_is_still_a_rewrite(self):
        # The author gives the line to 孟迟; no other changed line took 陈青's name. Read in place, as before.
        original = "陈青低声说：\n“知道了！”\n\n孟迟点了点头。\n"
        revised = "孟迟低声说：\n“知道了？”\n\n孟迟点了点头。\n"
        self.assertEqual(self.rewritten(original, revised).get(0), 0)
        report = compare(original, revised)
        certain = [(t["line"], t["before"] + "→" + t["after"], t["match"]) for t in report["tone_changes"]]
        self.assertEqual(certain, [(2, "！→？", "in_place")], report["tone_changes"])


class ExchangesSeenFromOneSide(unittest.TestCase):
    """Found by the keep-slots fuzz (repro/r5.8): one half of an exchange is enough. The person who left a place may be
    gone from the revision, or the one who took it may not have been named anywhere in the original; and a name may run
    together with reworded words ("黎渔压低嗓子说。" against "秦照低声说。": “黎渔压” is one changed run). In each case
    the speaker line was not rewritten in place, and the words next to it are another person's."""

    def certain(self, original, revised):
        report = compare(original, revised)
        return report, [(t["line"], t["before"] + "→" + t["after"]) for t in report["tone_changes"]
                        if t["match"] != "uncertain"]

    def test_the_newcomer_was_named_nowhere_before(self):
        # 黎渔's words had nobody named next to them; they now stand where 秦照's stood (speaker below, kept), with ！
        # changed to ？. 秦照 moved to the end and leads his line there; 孟迟's words moved up. Only line 1 changed.
        original = "“知道了。”\n秦照低声说。\n“知道了！”\n孟迟点了点头。\n“别动。”\n"
        revised = "“知道了？”\n黎渔低声说。\n“别动。”\n秦照点了点头。\n“知道了。”\n"
        report, certain = self.certain(original, revised)
        self.assertTrue(set(certain) <= {(1, "！→？")}, report["tone_changes"])
        self.assertIn(1, flagged_lines(report))

    def test_the_person_who_left_is_gone(self):
        # 秦照's words were cut; 黎渔's words, unchanged, moved up under 秦照's colon line, which now names 黎渔; 孟迟 is
        # new. Nobody's marks changed.
        original = "秦照低声说：\n“走吧！”\n黎渔点了点头。\n“走吧？”\n"
        revised = "黎渔低声说：\n“走吧？”\n孟迟点了点头。\n“走吧。”\n"
        report, certain = self.certain(original, revised)
        self.assertEqual(certain, [], report["tone_changes"])

    def test_a_name_run_together_with_reworded_words(self):
        # As above with the speaker below the words, reworded too: “黎渔压低嗓子说。” replaces “秦照低声说。”.
        original = "“走吧！”\n秦照低声说。\n黎渔点了点头。\n“走吧。”\n"
        revised = "“走吧。”\n黎渔压低嗓子说。\n孟迟点了点头。\n“知道了！”\n"
        report, certain = self.certain(original, revised)
        self.assertEqual(certain, [], report["tone_changes"])

    def test_lines_reworded_where_they_stand_still_pair_in_place(self):
        # Guard against over-correcting: two speaker lines reworded where they stand, nothing moved between them. The
        # repeated words still pair through the rewritten lines, and only the real change is reported.
        original = "陈青低声说：\n“知道了！”\n\n林舟点了点头。\n“知道了。”\n"
        revised = "陈青压低嗓子说：\n“知道了？”\n\n林舟摇了摇头。\n“知道了。”\n"
        report = compare(original, revised)
        items = [(t["line"], t["before"] + "→" + t["after"], t["match"]) for t in report["tone_changes"]]
        self.assertEqual(items, [(2, "！→？", "in_place")], report["tone_changes"])


def doc(name):
    return (ROOT / name).read_text(encoding="utf-8")


class ManualRollbackRestoresOnlyWhatWasBackedUp(unittest.TestCase):
    """Review of r5.6, P3: the manual rollback said to move both skill folders away and put both back from the backup.
    An upgrade backs up only the skills it replaces; from r5.5 to r5.6 only novel-workshop changed, the backup held no
    Darwin, and following the text word for word left the installation without it."""

    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        import shutil
        shutil.rmtree(self.dir)

    def package(self, name, workshop, darwin):
        import shutil
        root = self.dir / name
        files = {"skills/novel-workshop/SKILL.md": "工坊 " + workshop,
                 "skills/darwin-novel-workshop/SKILL.md": "维护 " + darwin}
        for relative, text in files.items():
            (root / relative).parent.mkdir(parents=True, exist_ok=True)
            (root / relative).write_text(text, encoding="utf-8")
        shutil.copy2(ROOT / "install.py", root / "install.py")
        manifest = {"schema_version": 1,
                    "files": {r: hashlib.sha256((root / r).read_bytes()).hexdigest() for r in files},
                    "components": {"novel-workshop": {"path": "skills/novel-workshop"},
                                   "darwin-novel-workshop": {"path": "skills/darwin-novel-workshop"}}}
        (root / "PACKAGE-MANIFEST.json").write_text(json.dumps(manifest), encoding="utf-8")
        return root / "install.py"

    def install(self, script, *args):
        proc = subprocess.run([sys.executable, "-I", "-B", str(script), "--dest", str(self.dir / "skills"), *args],
                              capture_output=True, text=True, encoding="utf-8")
        return proc.returncode, proc.stdout, proc.stderr

    def installed(self):
        dest = self.dir / "skills"
        return tuple((dest / name / "SKILL.md").read_text(encoding="utf-8") if (dest / name).exists() else None
                     for name in ("novel-workshop", "darwin-novel-workshop"))

    def test_the_backup_holds_only_what_the_upgrade_replaced(self):
        import shutil
        old, new = self.package("old", "旧版", "同一版"), self.package("new", "新版", "同一版")
        self.assertEqual(self.install(old)[0], 0)
        code, out, err = self.install(new, "--upgrade")
        self.assertEqual(code, 0, err)
        report = json.loads(out)
        self.assertEqual({s["name"]: s["action"] for s in report["skills"]},
                         {"novel-workshop": "upgrade", "darwin-novel-workshop": "unchanged"})
        backup = Path(report["backup"])
        self.assertEqual(sorted(p.name for p in backup.iterdir()), ["novel-workshop"])
        # The manual rollback as now written: only what the backup holds is moved aside and put back.
        aside = self.dir / "aside"
        aside.mkdir()
        for folder in sorted(backup.iterdir()):
            shutil.move(str(self.dir / "skills" / folder.name), str(aside / folder.name))
            shutil.move(str(folder), str(self.dir / "skills" / folder.name))
        self.assertEqual(self.installed(), ("工坊 旧版", "维护 同一版"))

    def test_the_old_package_rolls_back_with_upgrade(self):
        old, new = self.package("old", "旧版", "同一版"), self.package("new", "新版", "同一版")
        self.assertEqual(self.install(old)[0], 0)
        self.assertEqual(self.install(new, "--upgrade")[0], 0)
        code, out, err = self.install(old, "--upgrade")
        self.assertEqual(code, 0, err)
        self.assertEqual(self.installed(), ("工坊 旧版", "维护 同一版"))
        backup = Path(json.loads(out)["backup"])
        self.assertEqual(sorted(p.name for p in backup.iterdir()), ["novel-workshop"])  # the newer version, kept

    def test_the_instructions_say_so(self):
        quick = next(line for line in doc("QUICKSTART.md").splitlines() if line.startswith("想回到旧版"))
        changelog = next(line for line in doc("CHANGELOG.md").splitlines() if line.startswith("- **用安装器装的：**"))
        for text in (quick, changelog):
            for phrase in ("python install.py --upgrade", "备份里没有的技能升级时没有动过", "留在原处，不要移走",
                           "`unchanged`", "升级前没装、这次才新装上的技能"):
                self.assertIn(phrase, text)
        self.assertIn("手动回退只换备份目录里有的技能", doc("README.md"))
        for name in ("QUICKSTART.md", "CHANGELOG.md", "README.md"):
            self.assertNotIn("里的两个旧目录移回原处", doc(name), name)


class ExclusiveFactsAreStillAContradiction(unittest.TestCase):
    """Review of r5.6, low-risk wording: "只有两边明确互斥、又找不出来源和权限上的差别，才报矛盾" could be read as
    "accounts from different sources are never a contradiction". Now: a gap that differences of source and access can
    explain, with the truth not settled, is listed for checking; confirmed facts about the same thing at the same time
    that exclude each other are still a contradiction, whatever their sources."""

    def test_continuity_says_both_halves(self):
        text = (SCRIPTS.parent / "references" / "continuity.md").read_text(encoding="utf-8")
        line = next(line for line in text.splitlines() if line.startswith("两种说法对不上时"))
        self.assertIn("能用来源和权限的差别解释、哪边是真又还没定，就列待核", line)
        self.assertIn("出处不同不等于不算矛盾", line)
        self.assertIn("同一对象、同一时间的两条事实都已确认", line)
        self.assertIn("仍报矛盾", line)
        self.assertNotIn("找不出来源和权限上的差别", text)
        self.assertEqual(text.count("出处不同不等于不算矛盾"), 1)


if __name__ == "__main__":
    unittest.main()

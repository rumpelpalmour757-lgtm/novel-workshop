#!/usr/bin/env python3
"""r5.22: rule_register.py no longer reports success when it did not check.

The 10-19 review of r5.21:
- P2-R521-01: `collide` skipped a registered chapter that was not there (moved, or --texts-root pointing elsewhere)
  and still exited 0 with no hits, so "not read" looked like "read, and no clash". Now it lists missing_texts, says
  complete: false and exits 1; a register with no texts is incomplete too. Normal runs are unchanged.
- P2-R521-02: `external` was read with bool(), so the string "false" counted as true and switched off the file, hash
  and quote checks of a local source. Now only a JSON true is external; any other value is reported and the source is
  checked as a local file.
- P3: a register of the wrong shape (sides null, a path that is a number, ...) raised a traceback; it is now a FAIL
  with a message. A workshop decision names step 1-4 as an integer (true is not 1); step 5 is the author's.
"""

import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SCRIPT = ROOT / "skills" / "novel-workshop" / "scripts" / "rule_register.py"


def run(*args):
    proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT)] + [str(a) for a in args], capture_output=True,
                          text=True, encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


def register(**changes):
    value = {"schema": "rule-conflicts/1", "project": "测试数据", "updated": "2026-01-01",
             "sources": [{"id": "s", "title": "测试规则", "version": "1", "date": "2026-01-01", "status": "in_force",
                          "file": "rules.md"}],
             "texts": {"ch1": "chapter.md"},
             "items": [{"id": "X", "kind": "exception", "title": "测试项", "status": "open",
                        "sides": [{"source": "s", "where": "第一节", "quote": "包上的叫行囊"}],
                        "ask": "请作者定", "meanwhile": "旧章不动"}]}
    value.update(changes)
    return value


class Fixture(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        (self.dir / "rules.md").write_bytes(("一、包上的叫行囊。\n").encode("utf-8"))
        (self.dir / "chapter.md").write_bytes(("她把行囊卸在门边。\n提灯的油只够半夜。\n").encode("utf-8"))

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, value):
        path = self.dir / "rule-conflicts.json"
        path.write_bytes((json.dumps(value, ensure_ascii=False)).encode("utf-8"))
        return path

    def check(self, value):
        code, out, err = run("check", self.write(value), "--texts-root", self.dir)
        self.assertNotIn("Traceback", err)
        result = json.loads(out)
        self.assertEqual(code, 0 if result["status"] == "OK" else 1)
        return result


class CollideSaysWhatItRead(Fixture):
    def test_found_and_not_found_both_complete(self):
        path = self.write(register())
        code, out, _ = run("collide", "--register", path, "--texts-root", self.dir, "行囊", "雨衣")
        result = json.loads(out)
        self.assertEqual((code, result["complete"], result["missing_texts"], result["checked"]), (0, True, [], ["ch1"]))
        self.assertEqual([h["line"] for h in result["words"]["行囊"]], [1])
        self.assertEqual(result["words"]["雨衣"], [])

    def test_a_missing_chapter_is_not_a_clean_result(self):
        (self.dir / "chapter.md").unlink()
        path = self.write(register())
        code, out, _ = run("collide", "--register", path, "--texts-root", self.dir, "行囊")
        result = json.loads(out)
        self.assertEqual((code, result["complete"]), (1, False))
        self.assertEqual(result["missing_texts"], [{"text": "ch1", "path": "chapter.md"}])
        # the wrong folder is the same thing
        code, out, _ = run("collide", "--register", path, "--texts-root", self.dir / "elsewhere", "行囊")
        self.assertEqual((code, json.loads(out)["complete"]), (1, False))

    def test_a_register_without_texts_checks_nothing(self):
        path = self.write(register(texts={}))
        code, out, _ = run("collide", "--register", path, "--texts-root", self.dir, "行囊")
        self.assertEqual((code, json.loads(out)["complete"]), (1, False))


class ExternalIsTrueOrFalse(Fixture):
    def test_only_json_true_switches_off_the_local_checks(self):
        broken = {"id": "s", "title": "测试规则", "version": "1", "date": "2026-01-01", "status": "in_force",
                  "file": "missing.md", "sha256": "0" * 64}
        for value in ("false", "true", 1, 0, [], {}):
            source = dict(broken, external=value)
            result = self.check(register(sources=[source]))
            self.assertEqual(result["status"], "FAIL", value)
            self.assertTrue(any("external must be true or false" in p for p in result["problems"]), (value, result))
            self.assertTrue(any("file not found" in p for p in result["problems"]), (value, result))
        result = self.check(register(sources=[dict(broken, external=False)]))
        self.assertTrue(any("file not found" in p for p in result["problems"]), result)
        self.assertFalse(any("external must be" in p for p in result["problems"]), result)
        external = {"id": "s", "title": "国家标准", "version": "2011", "date": "2011-12-30", "status": "in_force",
                    "external": True}
        self.assertEqual(self.check(register(sources=[external]))["status"], "OK")


class WrongShapesFailCleanly(Fixture):
    def test_each_shape_is_a_fail_with_a_message(self):
        item = register()["items"][0]
        shapes = {
            "sides null": register(items=[dict(item, sides=None)]),
            "sides a string": register(items=[dict(item, sides="第一节")]),
            "a side that is a list": register(items=[dict(item, sides=[["s"]])]),
            "a source id that is a list": register(items=[dict(item, sides=[{"source": ["s"], "where": "第一节"}])]),
            "a text path that is a number": register(texts={"ch1": 7}),
            "texts a list": register(texts=["chapter.md"]),
            "items an object": register(items={"X": item}),
            "an item that is a string": register(items=["X"]),
            "a file that is a number": register(sources=[dict(register()["sources"][0], file=7)]),
            "superseded_by a list": register(sources=[dict(register()["sources"][0], status="superseded", superseded_by=["s"])]),
            "status a list": register(items=[dict(item, status=["open"])]),
        }
        for name, value in shapes.items():
            result = self.check(value)
            self.assertEqual(result["status"], "FAIL", name)
            self.assertTrue(result["problems"], name)
        # Sides that are not a list are named as such, and the rest of the item is still checked (not one generic
        # "malformed register" that hides everything else).
        for name in ("sides null", "sides a string"):
            problems = self.check(shapes[name])["problems"]
            self.assertTrue(any("needs at least 1 sides (a list)" in p for p in problems), (name, problems))
            self.assertFalse(any(p.startswith("malformed register") for p in problems), (name, problems))

    def test_a_workshop_step_is_an_integer_from_one_to_four(self):
        decided = {"id": "X", "kind": "exception", "title": "测试项", "status": "decided", "resolution": "照旧",
                   "sides": [{"source": "s", "where": "第一节", "quote": "包上的叫行囊"}],
                   "decided_by": {"who": "workshop", "when": "2026-01-01", "rule_applied": 4}}
        self.assertEqual(self.check(register(items=[decided]))["status"], "OK")
        for step in (5, 0, True, "1", 1.0):
            decided["decided_by"]["rule_applied"] = step
            result = self.check(register(items=[decided]))
            self.assertEqual(result["status"], "FAIL", step)
            self.assertTrue(any("step 5 is the author's" in p for p in result["problems"]), (step, result))

    def test_list_and_collide_on_a_broken_register_fail_cleanly(self):
        path = self.write(register(items=[{"id": "X", "status": "open", "sides": None}], texts={"ch1": 7}))
        code, out, err = run("collide", "--register", path, "--texts-root", self.dir, "行囊")
        self.assertEqual(code, 1)
        self.assertNotIn("Traceback", err)
        path.write_bytes(("[1, 2]").encode("utf-8"))
        for args in (("list", path, "--markdown"), ("collide", "--register", path, "--texts-root", self.dir, "行囊")):
            code, out, err = run(*args)
            self.assertEqual(code, 1, args)
            self.assertNotIn("Traceback", err)


if __name__ == "__main__":
    unittest.main()

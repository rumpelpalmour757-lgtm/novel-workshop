"""Which quotation marks the scanner reads, and what it says about the ones it cannot read.

The scanner reads “”, 「」 and 『』, like dialogue_lines.py. A line whose quotation is still
open at the end of the line is read to the line end and listed, and never goes into a
patch request. Straight quotes and stray marks are listed in the report, so a draft
written with them does not come back as a silent zero. All text below is synthetic.
"""
import contextlib
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from dialogue_core import extract_dialogues, quote_coverage
from patch_guard import apply_dialogue_patch, build_patch_request
from run_lint import main

NAMES = ('陈原', '方禾')


def issue_for(span, **extra):
    data = {'quote_id': span.quote_id, 'para_index': span.para_index, 'quote_index': span.quote_index,
            'start': span.start, 'end': span.end, 'source_quote': span.text,
            'speaker': span.speaker, 'confidence': span.confidence, 'name': '测试', 'description': '测试。'}
    data.update(extra)
    return data


def run_cli(args):
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        try:
            code = main(args)
        except SystemExit as stop:
            code = stop.code
    return code, out.getvalue(), err.getvalue()


class QuoteStyleTests(unittest.TestCase):
    def test_corner_quotes_are_read_like_curly_quotes(self):
        text = ['陈原说：「门锁了。」', '方禾问：「钥匙呢？」']
        spans = extract_dialogues(text, NAMES)
        self.assertEqual([(s.text, s.speaker, s.confidence) for s in spans],
                         [('门锁了。', '陈原', 'explicit'), ('钥匙呢？', '方禾', 'explicit')])
        self.assertEqual(spans[0].quote, '「门锁了。」')
        self.assertEqual(text[0][spans[0].start:spans[0].end], '门锁了。')
        self.assertTrue(spans[0].closed)

    def test_white_corner_quotes_and_nesting_keep_one_line_per_quotation(self):
        spans = extract_dialogues(['陈原说：「他写的是『明早再来』。」', '方禾说：『好。』'], NAMES)
        self.assertEqual([(s.para_index, s.text, s.speaker) for s in spans],
                         [(1, '他写的是『明早再来』。', '陈原'), (2, '好。', '方禾')])

    def test_curly_quotes_inside_a_corner_quote_are_not_a_separate_line(self):
        spans = extract_dialogues(['陈原说：「还是“老地方”见。」'], NAMES)
        self.assertEqual([(s.text, s.speaker) for s in spans], [('还是“老地方”见。', '陈原')])

    def test_a_neighbor_paragraph_with_corner_quotes_is_a_dialogue_boundary(self):
        # Without the 「」 check, 陈原's action in the line before would be borrowed as a guess.
        spans = extract_dialogues(['陈原推开门「到了。」', '「谁在里面？」'], NAMES)
        self.assertEqual((spans[1].speaker, spans[1].confidence), ('未知', 'unknown'))

    def test_a_line_left_open_runs_to_the_line_end_and_is_listed(self):
        text = ['陈原说：“第一段还没说完，\r\n', '“第二段接着说。”\r\n']
        spans = extract_dialogues(text, NAMES)
        self.assertEqual([(s.text, s.closed) for s in spans],
                         [('第一段还没说完，', False), ('第二段接着说。', True)])
        self.assertEqual(spans[0].speaker, '陈原')
        self.assertEqual(spans[0].quote, '“第一段还没说完，')
        coverage = quote_coverage(text)
        self.assertEqual(coverage['unclosed_quotes'], [{'para_index': 1, 'quote_id': 'p1:q1'}])
        self.assertFalse(coverage['complete'])

    def test_an_open_line_never_goes_into_a_patch_request(self):
        text = ['陈原说：“先别走，\n']
        span = extract_dialogues(text, NAMES)[0]
        self.assertEqual((span.speaker, span.confidence, span.closed), ('陈原', 'explicit', False))
        self.assertEqual(build_patch_request(text, [issue_for(span)])['items'], [])

    def test_stray_and_unsupported_marks_are_listed_by_line(self):
        coverage = quote_coverage(['“先等等“好。”', '他停下。”', '陈原说："门锁了。"', '没有引号的一行。'])
        self.assertEqual(coverage['stray_marks'], [{'para_index': 1, 'marks': '“'}, {'para_index': 2, 'marks': '”'}])
        self.assertEqual(coverage['unsupported_marks'], [{'para_index': 3, 'marks': '""'}])
        self.assertEqual(coverage['supported_marks'], ['“”', '「」', '『』'])
        self.assertFalse(coverage['complete'])
        self.assertTrue(quote_coverage(['陈原说：“好。”', '“走吧。”'])['complete'])

    def test_patch_on_a_corner_quote_keeps_its_marks(self):
        text = ['陈原说：「门锁了。」他放下包。\n']
        span = extract_dialogues(text, NAMES)[0]
        request = build_patch_request(text, [issue_for(span)])
        self.assertEqual([i['quote_id'] for i in request['items']], ['p1:q1'])
        response = {'source_hash': request['source_hash'], 'replacements': [
            {'quote_id': 'p1:q1', 'original': '门锁了。', 'replacement': '门锁着呢。'}]}
        self.assertEqual(apply_dialogue_patch(text, request, response), ['陈原说：「门锁着呢。」他放下包。\n'])


class QuoteStyleCLITests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.config = self.root / 'book.json'
        self.config.write_text(json.dumps({'profiles': {'陈原': {}, '方禾': {}}}, ensure_ascii=False), encoding='utf-8')

    def scan(self, text):
        source = self.root / 'chapter.txt'
        source.write_text(text, encoding='utf-8')
        code, out, err = run_cli(['scan', str(source), '--config', str(self.config)])
        return code, (json.loads(out) if code in (0, 1) else None), err

    def test_corner_quote_draft_is_scanned(self):
        code, report, _ = self.scan('陈原说：「门锁了。」\n方禾问：「钥匙呢？」\n「在我这儿。」陈原说。\n')
        self.assertEqual(code, 0)
        self.assertEqual(report['summary']['dialogue_quotes'], 3)
        self.assertEqual([d['speaker'] for d in report['dialogues']], ['陈原', '方禾', '陈原'])
        self.assertTrue(report['quote_coverage']['complete'])

    def test_straight_quote_draft_says_no_lines_were_recognized(self):
        code, report, err = self.scan('陈原说："门锁了。"\n方禾问："钥匙呢？"\n')
        self.assertEqual(code, 0)
        self.assertEqual(report['summary']['dialogue_quotes'], 0)
        self.assertEqual([m['para_index'] for m in report['quote_coverage']['unsupported_marks']], [1, 2])
        self.assertIn('没有认出台词', report['quote_coverage']['notice'])
        self.assertIn('引号', report['quote_coverage']['notice'])
        self.assertIn('没有认出台词', err)

    def test_open_line_is_counted_and_named_in_the_notice(self):
        code, report, err = self.scan('陈原说：“第一段还没说完，\n“第二段接着说。”\n')
        self.assertEqual(code, 0)
        self.assertEqual(report['summary']['dialogue_quotes'], 2)
        self.assertEqual(report['summary']['unclosed_quotes'], 1)
        self.assertIn('第1行', report['quote_coverage']['notice'])
        self.assertIn('第1行', err)


if __name__ == '__main__':
    unittest.main()

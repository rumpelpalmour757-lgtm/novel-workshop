"""Regression cases for real r4.2 failure modes, including interrupted workflows."""
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SCRIPTS = ROOT / "skills/novel-workshop/scripts"


def module(name):
    spec = importlib.util.spec_from_file_location("test42_" + name, SCRIPTS / (name + ".py"))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


class Repair42(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.guard = module("workflow_guard")
        self.demo = module("workflow_demo")
        self.delivery = module("delivery_manifest")

    def fixture(self):
        root = self.root / "demo"
        self.assertEqual(self.demo.run(root)["status"], "PASS")
        return root

    def test_full_demo_is_idempotent_and_preserves_original(self):
        root = self.fixture()
        before = (root / "project-state.json").read_bytes()
        self.assertEqual(self.demo.run(root)["status"], "PASS")
        self.assertEqual(before, (root / "project-state.json").read_bytes())
        run = self.guard.load_state(root / "ch1.run.json")
        self.assertEqual([e["machine"]["status"] for e in run["evidence"]], ["RED", "GREEN"])
        self.assertEqual((root / "ch1.original.md").read_text(encoding="utf-8"), self.demo.BODIES[0])

    def test_demo_resume_after_failed_review_keeps_budget(self):
        root = self.root / "demo"
        self.assertEqual(self.demo.run(root, "failed-review")["status"], "PAUSED")
        self.assertEqual(self.demo.run(root)["status"], "PASS")
        run = self.guard.load_state(root / "ch1.run.json")
        self.assertEqual(sum(k == "repair-once" for k in run["events"]), 1)
        self.assertEqual(len(run["evidence"]), 2)

    def test_demo_refuses_existing_user_directory(self):
        (self.root / "original.md").write_text("用户原稿", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "Refusing"):
            self.demo.run(self.root)
        self.assertEqual((self.root / "original.md").read_text(encoding="utf-8"), "用户原稿")

    def test_batch_detects_omitted_chapter(self):
        root = self.fixture()
        path = root / "delivery.json"
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["records"].pop(1)
        self.demo.write(path, payload)
        self.assertEqual(self.delivery.check(path)["issues"], [{"unit": "ch2", "problem": "MISSING_UNIT"}])

    def test_batch_detects_empty_and_stale_candidate(self):
        root = self.fixture()
        (root / "ch3.md").write_text("\n", encoding="utf-8")
        report = self.delivery.check(root / "delivery.json")
        self.assertEqual(report["status"], "INCOMPLETE")
        self.assertIn("EMPTY_CANDIDATE", report["units"][2]["problems"])
        self.assertEqual(report["units"][2]["gate"]["editorial"], "STALE")

    def test_batch_detects_duplicate_and_mismatched_files(self):
        root = self.fixture()
        path = root / "delivery.json"
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["records"][1]["candidate"] = "ch1.md"
        payload["records"].append(payload["records"][0])
        self.demo.write(path, payload)
        report = self.delivery.check(path)
        self.assertIn("CANDIDATE_PATH_MISMATCH", report["units"][1]["problems"])
        self.assertIn("REUSED_CANDIDATE_FILE", report["units"][1]["problems"])
        self.assertIn("DUPLICATE_UNIT", report["units"][3]["problems"])

    def test_batch_independent_review_requirement_is_enforced(self):
        root = self.fixture()
        path = root / "delivery.json"
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["require_independent"] = True
        self.demo.write(path, payload)
        self.assertEqual(self.delivery.check(path)["status"], "INCOMPLETE")

    def test_candidate_delivery_does_not_require_author_acceptance(self):
        root = self.fixture()
        for n in (1, 2, 3):
            path = root / ("ch%d.run.json" % n)
            state = json.loads(path.read_text(encoding="utf-8"))
            state["human_approvals"] = []
            self.demo.write(path, state)
        path = root / "delivery.json"
        payload = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(self.delivery.check(path)["status"], "INCOMPLETE")
        payload["stage"] = "candidate"
        self.demo.write(path, payload)
        self.assertEqual(self.delivery.check(path)["status"], "PASS")

    # Removed in the r5 merge: test_build_preserves_historical_baseline tested the r4.2/r4.3 top-level
    # build_release.py, which is not shipped any more. Releases are built by the maintainer's
    # maintenance/tools/build_release.py (private-term scan, frozen-tree comparison, tests in both builds);
    # it does not rewrite version strings, so there is no substitution that could clobber a historical label.

    def test_prior_chapter_edit_invalidates_later_gates(self):
        root = self.fixture()
        with (root / "ch1.md").open("a", encoding="utf-8") as file:
            file.write("铜匣被拿走了。")
        later = self.guard.compute_gate(self.guard.load_state(root / "ch2.run.json"), root)
        self.assertEqual((later["input_ready"], later["mechanical"]), ("BLOCKED", "STALE"))
        report = self.guard.check_spec(root / "ch2.checks.json")
        self.assertEqual(report["status"], "RED")

    def test_unregistered_tag_and_embedded_quoted_question_are_review_only(self):
        lint = module("punctuation_lint").lint_text('标签是【好】，回答是【好。】\n听见那句“你还来吗？”，她停了一下。')
        self.assertEqual(lint["counts"]["ERROR"], 0)
        self.assertEqual({f["rule"] for f in lint["findings"]}, {"P03", "P04"})

    def test_registered_tag_error_is_not_weakened(self):
        lint = module("punctuation_lint").lint_text('他启动【定。】。', {"ability_tags": ["定"]})
        self.assertEqual(lint["counts"]["ERROR"], 1)

    def test_ambiguous_quote_pair_configuration_is_refused(self):
        for pairs in [[["“", "“"]], [["“", "”"], ["‘", "”"]]]:
            with self.assertRaisesRegex(ValueError, "distinct"):
                module("punctuation_lint").lint_text("“测试。”", {"quote_pairs": pairs})

    def test_impossible_fact_times_are_refused(self):
        facts = module("fact_guard")
        self.assertEqual(facts.parse_time("D2 23:59"), (2, 1439))
        for value in ("25:10", "09:60", "D2 24:00"):
            with self.assertRaisesRegex(ValueError, "00-23"):
                facts.parse_time(value)

    def test_tampered_project_snapshot_cannot_supply_fact_baseline(self):
        root = self.fixture()
        facts = module("fact_guard")
        self.assertEqual(len(facts.load_ledger(root / "project-state.json")["facts"]), 3)
        value = json.loads((root / "project-state.json").read_text(encoding="utf-8"))
        value["data"]["facts"]["facts"][0]["value"] = "别处"
        self.demo.write(root / "tampered.json", value)
        with self.assertRaisesRegex(ValueError, "Invalid project state snapshot"):
            facts.load_ledger(root / "tampered.json")

    def test_prose_findings_cannot_silently_pass_editorial_gate(self):
        root = self.fixture()
        path = root / "ch3.md"
        path.write_text(path.read_text(encoding="utf-8") + "【待补：结尾】", encoding="utf-8")
        claims = json.loads((root / "ch3.claims.json").read_text(encoding="utf-8"))
        claims["candidate_sha256"] = self.demo.sha(path)
        self.demo.write(root / "ch3.claims.json", claims)
        review = json.loads((root / "ch3.review.json").read_text(encoding="utf-8"))
        review["candidate_sha256"] = self.demo.sha(path)
        self.demo.write(root / "review.json", review)
        self.guard.reserve(root / "ch3.run.json", "new-fix")
        with self.assertRaisesRegex(ValueError, "every machine review item"):
            self.guard.record(root / "ch3.run.json", "new-check", root / "review.json")

    def test_duplicate_review_evidence_rejected(self):
        root = self.fixture()
        review = json.loads((root / "ch3.review.json").read_text(encoding="utf-8"))
        review["evidence"] *= 3
        with self.assertRaisesRegex(ValueError, "distinct"):
            self.guard.validate_review_shape(review)

    def test_repeated_quote_does_not_fake_spread(self):
        text = ("独特开头测试文字。" + "中间普通文本" * 60 + "结束尾声测试文字。")
        review = {"verdict": "PASS", "candidate_sha256": self.guard.digest(text.encode()), "issues": [],
                  "evidence": [{"quote": "独特开头测试文字"}, {"quote": "中间普通文本"}, {"quote": "结束尾声测试文字"}]}
        report = {"candidate": {"sha256": review["candidate_sha256"]}, "review_items": [],
                  "review_policy": {"min_evidence": 3, "spread": True, "require_independent": False}}
        with self.assertRaisesRegex(ValueError, "beginning, middle and end"):
            self.guard.verify_review(review, report, text, self.root / "spec.json", [], self.root)
        review["evidence"][1]["offset"] = text.find("中间普通文本", len(text) // 2)
        self.guard.verify_review(review, report, text, self.root / "spec.json", [], self.root)

    def test_verifier_upgrade_invalidates_old_result(self):
        root = self.fixture()
        scripts = self.root / "scripts"
        shutil.copytree(SCRIPTS, scripts)
        with (scripts / "punctuation_lint.py").open("a", encoding="utf-8") as file:
            file.write("\n# changed checker version\n")
        result = subprocess.run([sys.executable, "-B", str(scripts / "workflow_guard.py"), "status", str(root / "ch3.run.json")], capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["gate"]["editorial"], "STALE")

    def test_killed_process_releases_workflow_lock(self):
        loader = "import importlib.util,sys,time;from pathlib import Path;s=importlib.util.spec_from_file_location('g',sys.argv[1]);g=importlib.util.module_from_spec(s);s.loader.exec_module(g)\nwith g.locked(Path(sys.argv[2])):\n print('LOCKED',flush=True)\n time.sleep(30)"
        path = self.root / "run.json"
        # -B: the child imports the packaged script; it must not leave __pycache__ inside the package under test.
        process = subprocess.Popen([sys.executable, "-B", "-c", loader, str(SCRIPTS / "workflow_guard.py"), str(path)], stdout=subprocess.PIPE, text=True, encoding="utf-8")
        try:
            self.assertEqual(process.stdout.readline().strip(), "LOCKED")
            with self.assertRaisesRegex(ValueError, "Another process"):
                with self.guard.locked(path):
                    pass
        finally:
            process.kill()
            process.wait(timeout=5)
            process.stdout.close()
        with self.guard.locked(path):
            pass

    def test_legacy_lock_is_not_silently_removed(self):
        path = self.root / "run.json"
        legacy = path.with_name(path.name + ".lock")
        legacy.write_text("", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "Legacy"):
            with self.guard.locked(path):
                pass
        self.assertTrue(legacy.exists())


if __name__ == "__main__":
    unittest.main()

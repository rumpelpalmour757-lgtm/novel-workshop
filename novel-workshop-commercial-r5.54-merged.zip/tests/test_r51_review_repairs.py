#!/usr/bin/env python3
"""r5.1: repairs for the 2026-10-16 review of the r5 candidate (findings F01-F05).

F01  two dialogue tone changes on one line shared one review id, so one decision passed both.
F02  two fact claims with the same written id shared one review id, with the same result.
F03  the six review dimensions had no fixed structure and were dropped from the state.
F04  the author's right to skip the review and accept had no command.
F05  a finished Darwin evaluation could not be replayed after the folder moved.
All material is invented for these tests.
"""

import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SCRIPTS = ROOT / "skills" / "novel-workshop" / "scripts"
DARWIN = ROOT / "skills" / "darwin-novel-workshop" / "scripts" / "darwin_eval.py"
DIMENSION_IDS = ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function",
                 "continuity", "revision_comparison")

# The review's own reproduction text (F01): two exclamations on one line both become full stops.
TONE_ORIGINAL = "院门仍然紧紧关着。\n\n“快走！”他喊，“别回头！”\n\n桌上的灯一直亮着。\n\n他回头又看了窗子一眼。\n\n门外已经没有声音。\n"
TONE_REVISED = TONE_ORIGINAL.replace("快走！", "快走。").replace("别回头！", "别回头。")
SPREAD_QUOTES = ["院门仍然紧紧关着。", "桌上的灯一直亮着。", "门外已经没有声音。"]


def module(name, path=None):
    spec = importlib.util.spec_from_file_location("r51_" + name, path or SCRIPTS / (name + ".py"))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def dims(note="回归用例：本维度逐段核对过（测试数据）", **status):
    return [{"id": key, "status": status.get(key, "met"), "note": note} for key in DIMENSION_IDS]


def whole_text(text):
    """r5.11: a strict-mode PASS needs the expression record. These short test texts are read as one segment; the
    record is test data that only lets the gate get to what this file tests."""
    body = text.strip()
    begin = next(body[:k] for k in range(4, len(body) + 1) if len("".join(body[:k].split())) >= 4)
    end = next(body[-k:] for k in range(4, len(body) + 1)
               if len("".join(body[-k:].split())) >= 4 and body.count(body[-k:]) == 1)
    return {"scope": "chapter", "decisions": [],
            "segments": [{"from": begin, "to": end, "note": "测试数据：只验证结构，从“%s”连读到“%s”" % (begin, end)}]}


class Project(unittest.TestCase):
    """A throwaway project folder and the workflow_guard command line, run the way a user runs it."""

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def write(self, name, value):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes((value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=1)).encode("utf-8"))
        return path

    def sha(self, name):
        return hashlib.sha256((self.root / name).read_bytes()).hexdigest()

    def run_script(self, script, *args, cwd=None):
        proc = subprocess.run([sys.executable, "-I", "-B", str(script), *map(str, args)], cwd=cwd or self.root,
                              capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(proc.stderr, "", proc.stderr)
        return proc.returncode, json.loads(proc.stdout) if proc.stdout.strip().startswith(("{", "[")) else proc.stdout

    def guard(self, *args, code=None):
        returned, out = self.run_script(SCRIPTS / "workflow_guard.py", *args)
        if code is not None:
            self.assertEqual(returned, code, out)
        return out

    def start(self, spec, state="run.json"):
        self.write("checks.json", spec)
        self.guard("start", state, "--task-id", "fixture", "--spec", "checks.json", code=0)

    def review(self, name="review.json", candidate="draft.md", **override):
        value = {"schema": "editorial-review/2", "verdict": "PASS", "candidate_sha256": self.sha(candidate),
                 "reviewer": {"mode": "self_check", "label": "回归用例自查（测试数据）"},
                 "checked_against": ["测试任务的要求"], "inputs_read": [],
                 "evidence": [{"quote": q, "in": "candidate"} for q in SPREAD_QUOTES], "issues": [],
                 "machine_dispositions": [], "counter_evidence": "测试数据：只验证记录结构，不作文学判断。",
                 "expression": whole_text((self.root / candidate).read_text(encoding="utf-8"))}
        value.update(override)
        self.write(name, value)
        return name

    def record(self, review, event="v0", code=None, state="run.json"):
        return self.guard("record", state, "--event-id", event, "--review", review, code=code)

    def gate(self, state="run.json"):
        return self.guard("status", state, code=0)["gate"]


class ReviewItemIds(Project):
    """F01: every review item has its own id; one decision never covers two findings."""

    def tone_project(self, mode="strict"):
        self.write("original.md", TONE_ORIGINAL)
        self.write("draft.md", TONE_REVISED)
        self.start({"candidate": "draft.md", "mode": mode,
                    "checks": [{"id": "revision", "type": "revision", "source": "original.md"}]})
        return [item["id"] for item in self.guard("check", "checks.json", code=0)["review_items"]]

    def test_two_tone_changes_on_one_line_get_their_own_ids(self):
        report = module("punctuation_lint").compare_texts(TONE_ORIGINAL, TONE_REVISED)
        self.assertEqual([(t["line"], t["column"], t["id"]) for t in report["tone_changes"]],
                         [(3, 1, "TONE-L3-C1"), (3, 9, "TONE-L3-C9")])
        self.assertEqual(report["counts"]["REVIEW"], 2)

    def test_three_tone_changes_on_one_line_get_their_own_ids(self):
        original = "“走！”他喊，“快！”又喊，“别停！”\n"
        revised = "“走。”他喊，“快。”又喊，“别停。”\n"
        ids = [t["id"] for t in module("punctuation_lint").compare_texts(original, revised)["tone_changes"]]
        self.assertEqual(len(ids), 3)
        self.assertEqual(len(set(ids)), 3)

    def test_one_decision_cannot_cover_two_tone_changes(self):
        ids = self.tone_project()
        self.assertEqual(ids, ["revision:TONE-L3-C1", "revision:TONE-L3-C9"])
        keep = {"decision": "keep", "reason": "测试数据：作者要求这里改成平叙"}
        one = self.review("one.json", inputs_read=["original.md"], dimensions=dims(),
                          machine_dispositions=[dict(keep, id=ids[0])])
        out = self.record(one, code=2)
        self.assertEqual(out["failure"], "REVIEW_INCOMPLETE")
        self.assertIn("must decide every machine review item", out["message"])
        self.assertIn(ids[1], out["message"])
        self.assertEqual(self.gate()["editorial"], "UNTESTED")  # nothing was written
        both = self.review("both.json", inputs_read=["original.md"], dimensions=dims(),
                           machine_dispositions=[dict(keep, id=key, reason=keep["reason"] + "（%s）" % key) for key in ids])
        self.record(both, code=0)
        gate = self.gate()
        self.assertEqual((gate["mechanical"], gate["editorial"], gate["review_items_open"]), ("GREEN", "PASS[self_check]", 0))

    def test_the_reviews_line_only_disposition_no_longer_matches_anything(self):
        # The exact input of the review's probe: one decision for "revision:TONE-L3", the old shared id.
        self.tone_project()
        probe = self.review("probe.json", inputs_read=["original.md"], dimensions=dims(), machine_dispositions=[
            {"id": "revision:TONE-L3", "decision": "keep", "reason": "只核对第一处快走的叹号变化，另一处尚未审读。"}])
        self.assertEqual(self.record(probe, code=2)["failure"], "REVIEW_STALE")

    def test_open_items_are_counted_per_item(self):
        ids = self.tone_project(mode="light")
        partial = self.review("partial.json", verdict="NEEDS_REVISION", inputs_read=["original.md"],
                              issues=[{"quote": "“别回头。”", "expected": "保留原来的叹号", "impact": "催促的语气没了"}],
                              machine_dispositions=[{"id": ids[0], "decision": "keep", "reason": "测试数据：第一处是有意改的"},
                                                    {"id": ids[1], "decision": "issue", "reason": "测试数据：第二处改掉了催促"}])
        self.record(partial, code=0)
        gate = self.gate()
        self.assertEqual((gate["editorial"], gate["review_items_open"]), ("NEEDS_REVISION", 1))

    def test_colliding_ids_are_refused_by_the_gate_and_never_merged(self):
        guard = module("workflow_guard")
        with self.assertRaises(guard.GuardError) as caught:
            guard.require_unique_ids([{"id": "revision:TONE-L3"}, {"id": "revision:TONE-L3"}])
        self.assertEqual(caught.exception.code, "DUPLICATE_REVIEW_ITEM")
        # The lint's own fallback: position ids are unique by construction, and a forced collision is numbered.
        items = module("punctuation_lint").assign_ids([{"k": 1}, {"k": 1}, {"k": 1}], lambda item: "X-L1-C1")
        self.assertEqual([item["id"] for item in items], ["X-L1-C1", "X-L1-C1-2", "X-L1-C1-3"])

    def test_a_stored_record_with_colliding_ids_cannot_show_pass(self):
        # A record made by r5 (line-only tone ids) carried into this version: it must not stay PASS.
        ids = self.tone_project(mode="light")
        decided = self.review("decided.json", inputs_read=["original.md"], machine_dispositions=[
            {"id": key, "decision": "keep", "reason": "测试数据：两处都是有意改的（%s）" % key} for key in ids])
        self.record(decided, code=0)
        state = json.loads((self.root / "run.json").read_text(encoding="utf-8"))
        for item in state["evidence"][-1]["machine"]["review_items"]:
            item["id"] = "revision:TONE-L3"
        self.write("run.json", state)
        gate = self.gate()
        self.assertEqual((gate["mechanical"], gate["editorial"], gate["review_items_open"]), ("STALE", "STALE", None))
        self.assertIn("share ids", gate["summary"])
        self.assertEqual(gate["permissions"]["claim_reviewed"]["decision"], "BLOCK")


class FactClaimIds(Project):
    """F02: claim ids are nonempty strings, unique in the claims file, and never collide with automatic ones."""

    LEDGER = {"schema": "fact-ledger/1", "entities": {"key": {"name": "钥匙"}, "box": {"name": "锁盒"}},
              "chapters": {"1": {"status": "accepted"}},
              "facts": [{"id": "old-key", "entity": "key", "attribute": "holder", "value": "唐野", "chapter": 1,
                         "layer": "accepted", "basis": "witnessed_action", "source": "第1章（测试数据）"},
                        {"id": "old-box", "entity": "box", "attribute": "location", "value": "桌上", "chapter": 1,
                         "layer": "accepted", "basis": "witnessed_action", "source": "第1章（测试数据）"}]}
    TEXT = "院门仍然紧紧关着。\n\n唐野将钥匙交给了陈絮。\n\n桌上的灯一直亮着。\n\n锁盒已被挪到门边。\n\n门外已经没有声音。\n"
    KEY = {"entity": "key", "attribute": "holder", "value": "陈絮", "basis": "witnessed_action", "change": True,
           "quote": "唐野将钥匙交给了陈絮。"}
    BOX = {"entity": "box", "attribute": "location", "value": "门边", "basis": "witnessed_action", "change": True,
           "quote": "锁盒已被挪到门边。"}

    def facts_project(self, claims):
        self.write("draft.md", self.TEXT)
        self.write("ledger.json", self.LEDGER)
        self.write("claims.json", {"schema": "fact-claims/1", "chapter": 2, "candidate": "draft.md",
                                   "candidate_sha256": self.sha("draft.md"), "extracted_by": "self_check", "claims": claims})

    def fact_check(self):
        return self.run_script(SCRIPTS / "fact_guard.py", "check", "ledger.json", "claims.json")

    def test_a_repeated_written_id_is_invalid_input(self):
        # The review's probe: two different claims both written as id "same".
        self.facts_project([dict(self.KEY, id="same"), dict(self.BOX, id="same")])
        code, out = self.fact_check()
        self.assertEqual((code, out["status"]), (2, "INPUT_ERROR"))
        self.assertIn('both use the id "same"', out["error"])
        self.start({"candidate": "draft.md", "checks": [{"id": "facts", "type": "facts", "ledger": "ledger.json",
                                                         "claims": "claims.json"}]})
        refused = self.guard("check", "checks.json", code=2)
        self.assertEqual(refused["failure"], "INVALID_INPUT")
        review = self.review(inputs_read=["ledger.json"], machine_dispositions=[
            {"id": "facts:F-same", "decision": "keep", "reason": "只核对钥匙的交接，锁盒的位置变化尚未审读。"}])
        self.assertEqual(self.record(review, code=2)["failure"], "INVALID_INPUT")
        self.assertEqual(self.gate()["editorial"], "UNTESTED")

    def test_written_and_automatic_ids_never_collide(self):
        self.facts_project([dict(self.KEY, id="c2"), dict(self.BOX)])  # the second claim would be "c2" by position
        code, out = self.fact_check()
        self.assertEqual(code, 0, out)
        self.assertEqual([r["claim"] for r in out["results"]], ["c2", "c2-auto"])
        self.assertEqual([i["id"] for i in out["review_items"]], ["F-c2", "F-c2-auto"])

    def test_positions_still_name_claims_without_ids(self):
        self.facts_project([dict(self.KEY), dict(self.BOX)])
        self.assertEqual([r["claim"] for r in self.fact_check()[1]["results"]], ["c1", "c2"])

    def test_empty_blank_and_non_string_ids_are_invalid(self):
        for bad in ("", "   ", 7, None, ["k"], {"id": "k"}):
            with self.subTest(bad=bad):
                self.facts_project([dict(self.KEY, id=bad), dict(self.BOX, id="box")])
                code, out = self.fact_check()
                self.assertEqual((code, out["status"]), (2, "INPUT_ERROR"))
                self.assertIn("id must be a nonempty string", out["error"])

    def test_a_repeated_key_inside_one_claim_is_invalid(self):
        self.write("draft.md", self.TEXT)
        self.write("ledger.json", self.LEDGER)
        claim = json.dumps(dict(self.KEY, id="k1"), ensure_ascii=False)[:-1] + ', "value": "唐野"}'
        self.write("claims.json", '{"schema": "fact-claims/1", "chapter": 2, "candidate": "draft.md", "candidate_sha256": "%s", '
                                  '"extracted_by": "self_check", "claims": [%s]}' % (self.sha("draft.md"), claim))
        code, out = self.fact_check()
        self.assertEqual(code, 2)
        self.assertIn("repeated JSON key", out["error"])

    def test_one_decision_cannot_cover_two_pending_facts(self):
        self.facts_project([dict(self.KEY, id="k1"), dict(self.BOX, id="k2")])
        self.start({"candidate": "draft.md", "checks": [{"id": "facts", "type": "facts", "ledger": "ledger.json",
                                                         "claims": "claims.json"}]})
        ids = [item["id"] for item in self.guard("check", "checks.json", code=0)["review_items"]]
        self.assertEqual(ids, ["facts:F-k1", "facts:F-k2"])
        keep = {"decision": "keep", "reason": "测试数据：交作者确认这项变化"}
        one = self.review("one.json", inputs_read=["ledger.json"], machine_dispositions=[dict(keep, id="facts:F-k1")])
        out = self.record(one, code=2)
        self.assertIn("facts:F-k2", out["message"])
        both = self.review("both.json", inputs_read=["ledger.json"],
                           machine_dispositions=[dict(keep, id=key, reason=keep["reason"] + "（%s）" % key) for key in ids])
        self.record(both, code=0)
        self.assertEqual(self.gate()["review_items_open"], 0)


class ReviewDimensions(Project):
    """F03: one structure for the six dimensions; strict mode needs all six; they stay in the state."""

    def strict_project(self, checks=None, mode="strict", **extra):
        self.write("original.md", TONE_ORIGINAL)
        self.write("draft.md", TONE_ORIGINAL)
        spec = {"candidate": "draft.md", "mode": mode, "checks": checks or [
            {"id": "same", "type": "file_hash", "source": "original.md", "sha256": self.sha("original.md")}]}
        spec.update(extra)
        self.start(spec)

    def refused(self, **override):
        out = self.record(self.review(inputs_read=["original.md"], **override), code=2)
        return out["failure"], out["message"]

    def test_strict_pass_without_dimensions_is_refused(self):
        self.strict_project()
        failure, message = self.refused()
        self.assertEqual(failure, "REVIEW_INCOMPLETE")
        self.assertIn("six-dimension conclusions", message)
        self.record(self.review(inputs_read=["original.md"], dimensions=dims()), code=0)
        self.assertEqual(self.gate()["dimensions"]["by_status"]["met"], list(DIMENSION_IDS))

    def test_a_dimensions_block_names_all_six_once_with_a_legal_status_and_a_note(self):
        self.strict_project()
        cases = {
            "missing: revision_comparison": dims()[:5],
            "Unknown dimension id: style": dims()[:5] + [{"id": "style", "status": "met", "note": "测试数据：文风统一"}],
            "repeated: continuity": dims() + [{"id": "continuity", "status": "met", "note": "测试数据：重复一条"}],
            "status must be": [dict(x, status="达到") if x["id"] == "paragraphing" else x for x in dims()],
            "note must say": dims(note="看过"),
            "unknown field": [dict(x, score=5) if x["id"] == "narrative_function" else x for x in dims()],
        }
        for expected, block in cases.items():
            with self.subTest(expected=expected):
                failure, message = self.refused(dimensions=block)
                self.assertEqual(failure, "REVIEW_INCOMPLETE")
                self.assertIn(expected, message)

    def test_strict_pass_cannot_leave_a_dimension_unreviewed(self):
        self.strict_project()
        failure, message = self.refused(dimensions=dims(continuity="not_reviewed"))
        self.assertEqual(failure, "REVIEW_INCOMPLETE")
        self.assertIn("continuity（跨章连续性）", message)
        self.assertEqual(self.gate()["editorial"], "UNTESTED")

    def test_not_reviewed_stays_not_reviewed_where_pass_allows_it(self):
        # Light mode with the dimensions switched on: PASS may leave a dimension unread, and the gate says so.
        self.strict_project(mode="light", review_policy={"dimensions": True})
        block = dims(continuity="not_reviewed")
        block[4]["note"] = "测试数据：没有拿到前一章原文"
        self.record(self.review(inputs_read=["original.md"], dimensions=block), code=0)
        gate = self.gate()
        self.assertEqual(gate["editorial"], "PASS[self_check]")
        self.assertEqual(gate["dimensions"]["by_status"]["not_reviewed"], ["continuity"])
        self.assertEqual(next(c for c in gate["dimensions"]["conclusions"] if c["id"] == "continuity")["status_text"], "未看")
        self.assertIn("not_reviewed continuity", gate["summary"])
        self.assertIn("跨章连续性", gate["permissions"]["claim_reviewed"]["reason"])
        self.assertIn("未看：跨章连续性", gate["deliverable_label"])
        stored = json.loads((self.root / "run.json").read_text(encoding="utf-8"))["evidence"][-1]["editorial"]["dimensions"]
        self.assertEqual(stored[4]["status"], "not_reviewed")  # never filled in as "met"

    def test_an_issue_needs_a_quote_and_rules_out_pass(self):
        self.strict_project()
        quoted = [{"quote": "“快走！”他喊", "in": "candidate"}]
        self.assertIn("needs at least one quote", self.refused(dimensions=dims(dialogue_punctuation="issue"))[1])
        block = dims(dialogue_punctuation="issue")
        block[1]["evidence"] = quoted
        self.assertIn("PASS cannot keep a dimension marked issue", self.refused(dimensions=block)[1])
        block[1]["evidence"] = [{"quote": "这句话不在稿子里面", "in": "candidate"}]
        revise = self.review("revise.json", verdict="NEEDS_REVISION", inputs_read=["original.md"], dimensions=block,
                             issues=[{"quote": "“快走！”他喊", "expected": "测试数据", "impact": "测试数据"}])
        self.assertEqual(self.record(revise, code=2)["failure"], "EVIDENCE_NOT_FOUND")
        block[1]["evidence"] = quoted
        self.record(self.review("revise.json", verdict="NEEDS_REVISION", inputs_read=["original.md"], dimensions=block,
                                issues=[{"quote": "“快走！”他喊", "expected": "测试数据", "impact": "测试数据"}]), code=0)
        gate = self.gate()
        self.assertEqual((gate["editorial"], gate["dimensions"]["by_status"]["issue"]), ("NEEDS_REVISION", ["dialogue_punctuation"]))

    def test_not_applicable_is_limited_to_two_dimensions_and_to_tasks_without_their_check(self):
        self.strict_project()
        self.assertIn("cannot be not_applicable", self.refused(dimensions=dims(paragraphing="not_applicable"))[1])
        self.record(self.review(inputs_read=["original.md"],
                                dimensions=dims(continuity="not_applicable", revision_comparison="not_applicable")), code=0)
        self.assertEqual(self.gate()["dimensions"]["by_status"]["not_applicable"], ["continuity", "revision_comparison"])

    def test_a_declared_revision_check_makes_revision_comparison_apply(self):
        self.write("original.md", TONE_ORIGINAL)
        self.write("draft.md", TONE_ORIGINAL)
        self.start({"candidate": "draft.md", "mode": "strict",
                    "checks": [{"id": "rev", "type": "revision", "source": "original.md"}]})
        out = self.record(self.review(inputs_read=["original.md"], dimensions=dims(revision_comparison="not_applicable")),
                          code=2)
        self.assertIn("revision_comparison cannot be not_applicable: this task declares a revision check", out["message"])

    def test_dimensions_live_in_the_state_with_the_review_file(self):
        self.strict_project()
        block = dims(continuity="not_applicable")
        block[0].update(evidence=[{"quote": "院门仍然紧紧关着。", "in": "candidate"}], where="第1段")
        name = self.review(inputs_read=["original.md"], dimensions=block, unit="测试第1章")
        self.record(name, code=0)
        raw = (self.root / name).read_bytes()
        editorial = json.loads((self.root / "run.json").read_text(encoding="utf-8"))["evidence"][-1]["editorial"]
        self.assertEqual(editorial["dimensions"], block)
        self.assertEqual(editorial["review_file"]["sha256"], hashlib.sha256(raw).hexdigest())
        self.assertEqual(base64.b64decode(editorial["review_file"]["snapshot"]["data"]), raw)  # "unit" survives here
        # Carry only the project files elsewhere, without the review file: the conclusions are still there.
        moved = Path(self.temp.name + "-moved")
        shutil.copytree(self.root, moved)
        self.addCleanup(shutil.rmtree, moved, True)
        (moved / name).unlink()
        returned, out = self.run_script(SCRIPTS / "workflow_guard.py", "status", "run.json", cwd=moved)
        gate = out["gate"]
        self.assertEqual((returned, gate["editorial"]), (0, "PASS[self_check]"))
        self.assertEqual([c["status"] for c in gate["dimensions"]["conclusions"]],
                         ["met", "met", "met", "met", "not_applicable", "met"])
        self.assertEqual(gate["dimensions"]["conclusions"][0]["where"], "第1段")

    def test_edited_conclusions_in_the_state_are_not_trusted(self):
        self.strict_project()
        self.record(self.review(inputs_read=["original.md"], dimensions=dims(continuity="not_applicable")), code=0)
        state = json.loads((self.root / "run.json").read_text(encoding="utf-8"))
        state["evidence"][-1]["editorial"]["dimensions"][4]["status"] = "met"
        self.write("run.json", state)
        gate = self.gate()
        self.assertEqual((gate["mechanical"], gate["editorial"]), ("STALE", "STALE"))
        self.assertIn("no longer match the stored review file", gate["summary"])

    def test_dimensions_cannot_be_switched_off_in_strict_mode_or_by_replan(self):
        self.write("draft.md", TONE_ORIGINAL)
        self.write("checks.json", {"candidate": "draft.md", "mode": "strict", "review_policy": {"dimensions": False},
                                   "checks": [{"id": "keep", "type": "contains", "text": "院门"}]})
        self.assertIn("cannot be loosened", self.guard("start", "run.json", "--task-id", "t", "--spec", "checks.json",
                                                       code=2)["message"])
        self.start({"candidate": "draft.md", "review_policy": {"dimensions": True},
                    "checks": [{"id": "keep", "type": "contains", "text": "院门"}]}, state="run2.json")
        self.write("lighter.json", {"candidate": "draft.md", "checks": [{"id": "keep", "type": "contains", "text": "院门"}]})
        self.write("decision.json", {"author_decision": "测试数据", "source": "测试数据", "affected_scope": "测试数据"})
        out = self.guard("replan", "run2.json", "--event-id", "p1", "--spec", "lighter.json", "--decision", "decision.json",
                         code=2)
        self.assertIn("dimensions on -> off", out["message"])

    def test_light_review_without_dimensions_still_records(self):
        self.strict_project(mode="light")
        self.record(self.review(inputs_read=["original.md"]), code=0)
        gate = self.gate()
        self.assertEqual((gate["editorial"], gate["dimensions"]), ("PASS[self_check]", {"required": False, "recorded": False}))

    def test_the_review_template_matches_the_tool_and_cannot_be_submitted_unfilled(self):
        template = json.loads((ROOT / "skills" / "novel-workshop" / "assets" / "editorial-review-template.json")
                              .read_text(encoding="utf-8"))
        guard = module("workflow_guard")
        self.assertEqual([x["id"] for x in template["dimensions"]], [key for key, _ in guard.DIMENSIONS])
        self.assertEqual(list(DIMENSION_IDS), [key for key, _ in guard.DIMENSIONS])
        self.strict_project()
        self.write("template-copy.json", template)
        out = self.record("template-copy.json", code=2)
        self.assertIn("Invalid editorial verdict", out["message"])

    def test_a_repeated_key_in_the_review_is_refused(self):
        self.strict_project()
        name = self.review(inputs_read=["original.md"], dimensions=dims())
        text = (self.root / name).read_text(encoding="utf-8")
        self.write(name, text.replace('"verdict": "PASS"', '"verdict": "FAIL", "verdict": "PASS"', 1))
        out = self.record(name, code=2)
        self.assertIn("Repeated JSON key 'verdict'", out["message"])


class SkipReviewAcceptance(Project):
    """F04: the author may skip the review and accept; the record says exactly that."""

    TEXT = "第一章　雨停以后\n\n天亮了，门外的雨已经停了。\n"

    def skip_project(self):
        self.write("draft.md", self.TEXT)
        self.start({"candidate": "draft.md", "checks": [{"id": "keep", "type": "contains", "text": "雨已经停了"}]})

    def decision(self, name="decision.json", **override):
        value = {"candidate_sha256": self.sha("draft.md"), "source": "作者当前消息：跳过这次机器检查和审稿，直接采纳这一版。（测试数据）",
                 "scope": "第一章完整正文"}
        value.update(override)
        self.write(name, value)
        return name

    def accept(self, *extra, event="a1", decision="decision.json", code=None):
        return self.guard("accept", "run.json", "--event-id", event, "--decision", decision, *extra, code=code)

    def test_author_can_skip_the_review_and_accept_the_current_text(self):
        self.skip_project()
        self.decision()
        out = self.accept(code=2)  # the plain command still wants a recorded version, and now says what to do
        self.assertIn("--skip-review", out["message"])
        self.accept("--skip-review", code=0)
        gate = self.gate()
        self.assertEqual((gate["input_ready"], gate["mechanical"], gate["editorial"], gate["author"], gate["stage"]),
                         ("READY", "UNTESTED", "UNTESTED", "ACCEPTED", "AUTHOR_ACCEPTED"))
        self.assertTrue(gate["review_skipped_by_author"])
        self.assertTrue(any("作者决定跳过审稿" in w for w in gate["stage_warnings"]))
        self.assertIn("作者决定跳过审稿", gate["deliverable_label"])
        perms = gate["permissions"]
        self.assertEqual((perms["claim_final"]["decision"], perms["claim_reviewed"]["decision"],
                          perms["claim_mechanical_pass"]["decision"]), ("ALLOW", "BLOCK", "BLOCK"))
        state = json.loads((self.root / "run.json").read_text(encoding="utf-8"))
        frozen = [a for a in state["artifacts"] if a["role"] == "candidate"]
        self.assertEqual([(a["sha256"], a["review"], a["author_status"]) for a in frozen],
                         [(self.sha("draft.md"), "skipped_by_author", "accepted")])
        self.assertTrue(state["human_approvals"][-1]["review_skipped"])
        self.assertEqual(state["evidence"], [])  # no check or review was invented

    def test_skip_review_still_needs_the_current_bytes_and_the_authors_words(self):
        self.skip_project()
        self.assertEqual(self.accept("--skip-review", decision=self.decision(candidate_sha256="0" * 64), code=2)["failure"],
                         "ACCEPT_INVALID")
        self.assertEqual(self.accept("--skip-review", decision=self.decision(source=" "), code=2)["failure"], "ACCEPT_INVALID")
        self.assertEqual(self.gate()["author"], "NOT_ACCEPTED")

    def test_a_reviewed_version_is_accepted_without_the_skip_flag(self):
        self.skip_project()
        self.record(self.review(evidence=[{"quote": "门外的雨已经停了", "in": "candidate"}]), code=0)
        self.decision(source="作者：就用这版（测试数据）")
        out = self.accept("--skip-review", code=2)
        self.assertIn("already has a recorded review", out["message"])
        self.accept(code=0)
        self.assertFalse(self.gate()["review_skipped_by_author"])

    def test_the_event_cannot_be_replayed_with_other_content(self):
        self.skip_project()
        self.decision()
        self.accept("--skip-review", code=0)
        before = (self.root / "run.json").read_bytes()
        self.accept("--skip-review", code=0)  # an identical retry changes nothing
        self.assertEqual((self.root / "run.json").read_bytes(), before)
        self.assertEqual(self.accept(code=2)["failure"], "EVENT_CONFLICT")  # same event id, without the skip
        self.assertEqual((self.root / "run.json").read_bytes(), before)

    def test_editing_after_a_skipped_review_needs_the_author_again(self):
        self.skip_project()
        self.decision()
        self.accept("--skip-review", code=0)
        self.write("draft.md", self.TEXT + "补一句。\n")
        gate = self.gate()
        self.assertTrue(gate["author"].startswith("NOT_ACCEPTED (an earlier version"))
        self.assertEqual(gate["permissions"]["edit_accepted_text"]["decision"], "REVIEW_REQUIRED")
        self.assertFalse(gate["review_skipped_by_author"])

    def test_the_batch_report_names_a_skipped_review(self):
        self.skip_project()
        self.decision()
        self.accept("--skip-review", code=0)
        self.write("delivery.json", {"schema": "delivery-manifest/1", "stage": "accepted", "expected_units": ["ch1"],
                                     "records": [{"unit": "ch1", "candidate": "draft.md", "state": "run.json"}]})
        code, out = self.run_script(SCRIPTS / "delivery_manifest.py", "delivery.json")
        self.assertEqual((code, out["status"]), (1, "INCOMPLETE"))
        self.assertIn("AUTHOR_SKIPPED_REVIEW", out["units"][0]["problems"])
        self.assertNotIn("AUTHOR_NOT_ACCEPTED", out["units"][0]["problems"])


class RelocatedEvaluation(unittest.TestCase):
    """F05: a finished evaluation replays elsewhere; a missing folder is not a changed one."""

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.dir = Path(self.temp.name)
        self.work = self.dir / "evaluation"
        self.write(self.work / "TASKS.json", json.dumps({"tasks": [{"id": "hold1", "split": "holdout"}],
                                                         "dimensions": [{"id": "facts", "hard": True},
                                                                        {"id": "readability", "hard": False}]}))
        self.write(self.dir / "arms" / "baseline" / "SKILL.md", "保留原稿事实。")
        self.write(self.dir / "arms" / "candidate" / "SKILL.md", "保留原稿事实，逐条核对改动。")
        self.write(self.dir / "base.md", "雨停了。沈七把钥匙放回桌上。")
        self.write(self.dir / "cand.md", "窗外雨停了。沈七把钥匙放回桌上。")
        self.cli("freeze", "--baseline", self.dir / "arms" / "baseline", "--candidate", self.dir / "arms" / "candidate")
        self.cli("blind", "--task", "hold1", "--baseline-output", self.dir / "base.md", "--candidate-output",
                 self.dir / "cand.md", "--seed", "7")
        mapping = json.loads((self.work / "sealed" / "hold1.mapping.json").read_text(encoding="utf-8"))["mapping"]
        label = {arm: key for key, arm in mapping.items()}
        self.write(self.dir / "verdict.json", json.dumps({
            "task": "hold1", "judge": {"mode": "independent_agent", "label": "测试数据"},
            "dimensions": {"facts": {"result": "tie", "evidence": "沈七把钥匙放回桌上。"},
                           "readability": {"result": label["candidate"], "evidence": "窗外雨停了。"}}}, ensure_ascii=False))
        self.cli("verdict", "--task", "hold1", "--file", self.dir / "verdict.json")
        self.cli("unblind", "--task", "hold1")
        self.sealed = {name: (self.work / name).read_bytes() for name in ("FROZEN.json", "SEALS.log")}

    @staticmethod
    def write(path, text):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes((text).encode("utf-8"))

    def cli(self, command, *args, code=0, work=None):
        proc = subprocess.run([sys.executable, "-I", "-B", str(DARWIN), command, str(work or self.work), *map(str, args)],
                              capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(proc.returncode, code, proc.stdout + proc.stderr)
        self.assertEqual(proc.stderr, "")
        return json.loads(proc.stdout)

    def move(self):
        target = self.dir / "elsewhere"
        shutil.move(str(self.dir / "arms"), str(target))
        return target / "baseline", target / "candidate"

    def assert_seals_untouched(self):
        for name, data in self.sealed.items():
            self.assertEqual((self.work / name).read_bytes(), data, name)

    def test_moved_arms_are_unavailable_not_compromised(self):
        self.move()
        report = self.cli("verify")
        self.assertEqual((report["baseline"], report["candidate"], report["seals"], report["status"]),
                         ("UNAVAILABLE", "UNAVAILABLE", "INTACT", "ARMS_UNAVAILABLE"))
        blocked = self.cli("summarize", code=2)
        self.assertTrue(blocked["decision"].startswith("BLOCKED_ARMS_UNAVAILABLE"), blocked["decision"])
        self.assert_seals_untouched()

    def test_relocated_roots_must_match_the_frozen_trees(self):
        base, cand = self.move()
        summary = self.cli("summarize", "--baseline-root", base, "--candidate-root", cand)
        self.assertTrue(summary["decision"].startswith("CANDIDATE_BETTER_ON_HELD_OUT_TASKS"), summary["decision"])
        self.assertEqual(summary["integrity"]["arm_sources"]["candidate"]["checked"], "relocated_root")
        self.write(cand / "SKILL.md", "评测之后改过的规则。")
        report = self.cli("verify", "--baseline-root", base, "--candidate-root", cand)
        self.assertEqual((report["candidate"], report["status"]), ("CHANGED", "COMPROMISED"))
        self.assertTrue(self.cli("summarize", "--baseline-root", base, "--candidate-root", cand,
                                 code=2)["decision"].startswith("BLOCKED_INTEGRITY"))
        self.assert_seals_untouched()

    def test_sealed_snapshots_replay_a_finished_evaluation(self):
        shutil.rmtree(self.dir / "arms")
        copy = self.dir / "copied" / "evaluation"
        shutil.copytree(self.work, copy)
        summary = self.cli("summarize", "--from-snapshots", work=copy)
        self.assertEqual(summary["integrity"]["status"], "OK")
        self.assertEqual({arm: v["checked"] for arm, v in summary["integrity"]["arm_sources"].items()},
                         {"baseline": "sealed_snapshot", "candidate": "sealed_snapshot"})
        self.assertTrue(summary["decision"].startswith("CANDIDATE_BETTER_ON_HELD_OUT_TASKS"), summary["decision"])
        with (copy / "snapshots" / "candidate.zip").open("ab") as handle:
            handle.write(b"tamper")
        self.assertEqual(self.cli("verify", "--from-snapshots", work=copy)["status"], "COMPROMISED")

    def test_snapshot_flag_and_roots_are_exclusive(self):
        out = self.cli("verify", "--from-snapshots", "--baseline-root", self.dir, code=2)
        self.assertIn("not both", out["message"])

    def test_a_repeated_dimension_in_a_verdict_is_refused(self):
        work = self.dir / "second"
        self.write(work / "TASKS.json", (self.work / "TASKS.json").read_text(encoding="utf-8"))
        self.cli("freeze", "--baseline", self.dir / "arms" / "baseline", "--candidate", self.dir / "arms" / "candidate",
                 work=work)
        self.cli("blind", "--task", "hold1", "--baseline-output", self.dir / "base.md", "--candidate-output",
                 self.dir / "cand.md", "--seed", "7", work=work)
        self.write(self.dir / "twice.json", '{"task": "hold1", "judge": {"mode": "independent_agent", "label": "x"}, '
                                            '"dimensions": {"facts": {"result": "A", "evidence": "沈七"}, '
                                            '"facts": {"result": "tie", "evidence": "沈七"}}}')
        out = self.cli("verdict", "--task", "hold1", "--file", self.dir / "twice.json", code=2, work=work)
        self.assertIn("repeated JSON key", out["message"])

    def test_the_packaged_r5_evaluation_replays_from_its_snapshots(self):
        work = ROOT / "maintenance" / "eval" / "darwin"
        if not (work / "FROZEN.json").is_file():
            self.skipTest("only the personal build carries the r5 evaluation record")
        before = {name: (work / name).read_bytes() for name in ("FROZEN.json", "SEALS.log")}
        self.assertIn(self.cli("verify", work=work)["status"], {"ARMS_UNAVAILABLE", "OK"})  # OK only on the maker's machine
        summary = self.cli("summarize", "--from-snapshots", work=work)
        self.assertTrue(summary["decision"].startswith("KEEP_BASELINE"), summary["decision"])
        self.assertEqual((summary["holdout"]["improved"], summary["holdout"]["regressed"], summary["holdout"]["same"]),
                         (11, 5, 32))
        self.assertEqual({name: (work / name).read_bytes() for name in before}, before)


if __name__ == "__main__":
    unittest.main()

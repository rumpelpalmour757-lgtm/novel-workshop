#!/usr/bin/env python3
"""Read-only checks for Chinese fiction punctuation and sentence-chopping hints.

ERROR  objective format faults: unpaired quotes or brackets, banned forms such as
       "..." or "。。", ASCII punctuation between Chinese characters, or a declared
       ability/item tag carrying sentence punctuation inside its brackets.
REVIEW needs an editor's decision: short-sentence chains, runs of one-line
       paragraphs, suspicious tags, dialogue punctuation, heavy paragraphs and
       long unbroken speeches (reader load). Never auto-fixed.
INFO   counts with a stated basis. No ratio is a pass mark.

--baseline ORIGINAL compares a revision with its original and reports only what
the revision introduced, plus changed end marks of the same line of dialogue. The
dialogue of the two versions is matched one to one (whole lines first, so moved
paragraphs are found again); repeated words that cannot be matched reliably are
reported as uncertain, never taken as unchanged.

--dialogue-soft-wrap (or "dialogue_soft_wrap": true in the rules file) is an opt-in
house style: line breaks inside one quotation that closes on a later line are the
author's visual soft wraps, not unclosed quotes. A blank line, or a line that opens
a new quotation, still ends the quotation; a quotation that never closes is still
an ERROR. Off by default.

Never rewrites text, never judges style, never says whether AI wrote it.
Exit codes: 0 no ERROR findings (or none introduced), 1 ERROR findings present
(or introduced), 2 unreadable input or rules.
"""

import argparse
import bisect
import difflib
from collections import Counter
from difflib import SequenceMatcher
import hashlib
import json
from pathlib import Path
import re
import sys

VERSION = "1.11"  # 1.3: tone ids carry the column (TONE-L3-C12); 1.4: repeated dialogue is matched one to one;
                 # 1.5: a speech-only line is matched with its speaker line, coincidental runs are not trusted;
                 # 1.6: a colon line names the speech below it across blank lines, the line below alone names nobody,
                 #      a replaced line is "rewritten in place" only when nothing else explains it;
                 # 1.7: words pair by place only when named the same way in both versions; a tie is no rewrite;
                 # 1.8: words are unique only if said once anywhere (inline too); a changed line is no rewrite when
                 #      text it lost or gained stands in another changed line (people traded places)
                 # 1.9: the last fallback compares the narration of the lines, not the whole lines, and refuses an
                 #      order in which people traded lines; an assumed rewrite pairs no words said more or fewer times
                 # 1.10: each quote of a line gets its own narration; the same narration once on each side pairs
                 #      the same words whatever the lines were split into or merged with
                 # 1.11 (r5.52, the author's punctuation rules of 11-07): ellipsis and dash forms (.., mixed
                 #      runs, odd lengths, single or long dashes), ASCII marks after English words in a Chinese
                 #      sentence, mixed-width brackets, a standalone quote with no end mark, tag lines (P14), a quote
                 #      left open into a paragraph that reopens it (P15), stacked-mark limit and profiles; code, URLs
                 #      and registered raw panels are not checked; title spaces and ".NET" are no longer flagged
HAN = r"㐀-䶿一-鿿豈-﫿"
HAN_RE = re.compile("[" + HAN + "]")
FULL_PUNCT = "，。、；：！？“”‘’（）【】《》〈〉「」『』〔〕…—·～"
CJK_CONTEXT = re.compile("[" + HAN + re.escape(FULL_PUNCT) + "]")
TERMINALS = "。！？"
PAUSES = "。，、；："
DEFAULT_RULES = {
    "ability_tags": [],
    "panel_prefixes": [],
    "tag_brackets": [["【", "】"]],
    "quote_pairs": [["“", "”"], ["‘", "’"]],
    "short_chain": {"max_chars": 6, "min_run": 3},
    "short_paragraph_run": {"max_chars": 12, "min_run": 4},
    # Reader-load hints (REVIEW only). Narrative Han characters in one paragraph; registered people
    # crowding one paragraph; one stretch of speech with no beat in between. Tune per work.
    "dense_paragraph": {"max_chars": 150, "max_people": 3, "min_clauses": 6},
    "long_speech": {"max_chars": 100, "min_sentences": 4},
    "characters": [],
    # Opt-in house style: line breaks inside ONE quotation that is not closed until a later line are the
    # author's visual soft wraps, not missing closing quotes. Off by default (strict P01).
    "dialogue_soft_wrap": False,
    # r5.52, the author's profiles of 11-07 as presets of the fields below (explicit fields win):
    # strict = stacked_mark_limit 1; light = stacked_mark_limit 3; raw-panel = raw_brackets 【】 and [], tag_layout allow,
    # stacked_mark_limit 1. No profile: the standard (stacked_mark_limit 2).
    "profile": "",
    # More ！ or ？ in a row than this is a REVIEW (the standard allows stacking up to three; 1 is a house rule).
    "stacked_mark_limit": 2,
    # P14: a tag standing as its own paragraph with a mark after it, and spaces between adjacent tags.
    "tag_layout": "review",
    # P15: a quote left open at a paragraph end, with the next paragraph reopening it.
    "continued_quotes": "review",
    # Brackets whose inside is copied as is (terminal output, raw system panels): no format checks inside.
    "raw_brackets": [],
    "ignore": [],
}
PROFILES = {  # the author's three presets (v2.2-v2.7), as ordinary fields
    "strict": {"stacked_mark_limit": 1},
    "light": {"stacked_mark_limit": 3},
    "raw-panel": {"raw_brackets": [["【", "】"], ["[", "]"]], "tag_layout": "allow", "stacked_mark_limit": 1},
}
CHOICES = {"profile": ("",) + tuple(PROFILES), "tag_layout": ("review", "allow"), "continued_quotes": ("review", "allow")}
RULE_TEXT = {
    "P01": "引号配对", "P02": "括号配对", "P03": "标签内标点", "P04": "连续标点",
    "P05": "省略号与破折号写法", "P06": "中文语境半角标点", "P07": "全角数字字母",
    "P08": "多余空格", "P09": "对白引号标点", "P10": "连续极短句", "P11": "连续单行短段",
    "P12": "段落负担", "P13": "长段对白", "P14": "标签外标点与间隔", "P15": "跨段续引待核",
}
FORMAT_RULES = {"P01", "P02", "P03", "P04", "P05", "P06", "P07", "P08", "P09", "P14", "P15"}
SPEECH_TAG = re.compile("^[" + HAN + "]{0,4}?(?:说|问|道|喊|答|笑道|叫|嘟囔|低声|开口)")
SPEECH_TAG_AFTER_GAP = re.compile("^[" + HAN + "]{0,4}?(?:说|问|道|喊|答|笑道|叫|嘟囔|低声|开口)[了着]?"
                                  "(?=[，。：！？；…—“”「」\\s]|$)")
EXTENSIONS = ("txt md markdown json csv tsv py js ts java c h cpp cc go rs rb php lua kt swift sql sh bat cmd ps1 exe apk ipa dmg iso "
              "html htm css xml yaml yml toml ini cfg conf log db sqlite sav dat bak tmp zip rar 7z tar gz torrent pdf doc docx xls "
              "xlsx ppt pptx key pages numbers wps et dps caj kdh nh ofd xmind vsdx mpp epub mobi azw3 png jpg jpeg gif bmp webp heic "
              "svg psd ai mp3 m4a wav flac aac ogg ape amr mp4 mov avi mkv flv rmvb m4v 3gp srt ass").split()
DOTTED_NAMES = re.compile(r"\.(?:NET|" + "|".join(sorted(EXTENSIONS + [e.upper() for e in EXTENSIONS], key=len, reverse=True))
                          + r")(?![A-Za-z0-9])")  # 资料.rar; upper or mixed case only inside a path (P06 below)
DOTTED_NAMES_ANY_CASE = re.compile(DOTTED_NAMES.pattern, re.I)
HEADING = re.compile(r"^\s*(?:#|第[0-9一二三四五六七八九十百千零〇两]+(?:[章卷]|[节回部集篇话幕](?=[\s　：:]|$))"
                     r"|(?:卷[0-9一二三四五六七八九十百千零〇两]+|番外[0-9一二三四五六七八九十]*篇?|间章|幕间|楔子|序章|序幕"
                     r"|引子|尾声|终章|后记)(?=[\s　：:]|$))")
SPEECH_WORD = re.compile("(?:说|道|问|喊|答|叫|吼|嚷|骂|笑|念|嘀咕|嘟囔|开口|回|应|喝|叹|吩咐|告诉|宣布|喃喃|低语|咆哮|一句|一嗓子|摇头|点头)"
                         "[了着过]?[ \t　]*[：:]?$")
CONTINUES = re.compile("(?:随后|随即|旋即|接着|紧接着|然后|便[转起走往朝向拉推抬摇点挥]|说完|话音未落|话音刚落)")
BOX_DRAWING = re.compile("[\u2500-\u257f]")
ABBREVIATION = re.compile(r"(?:^|(?<=[^A-Za-z]))(?:[A-Za-z]|Dr|Mr|Mrs|Ms|St|Jr|Sr|Prof|vs|etc|Vol|Inc|Ltd|Fig|pp)$")


CODE_LANGUAGES = {"python", "py", "javascript", "js", "typescript", "ts", "java", "c", "cpp", "c++", "cs", "csharp", "go",
                  "rust", "ruby", "php", "sh", "bash", "shell", "zsh", "powershell", "ps1", "bat", "cmd", "sql", "json",
                  "yaml", "yml", "toml", "xml", "html", "css", "lua", "kotlin", "swift", "r", "matlab", "ini", "dockerfile",
                  "makefile", "jsx", "tsx", "scala", "perl", "haskell"}
PROSE_LABELS = {"markdown", "md", "text", "txt", "plain", "plaintext", "prose", "novel", "zh", "chinese", "正文"}


def reads_as_code(body, label="", inline=False):
    """Is a ``` block or a `backtick` stretch code (skipped) rather than prose (checked)? A block labelled with a
    programming language (```python) is code; one labelled markdown or text is prose. Otherwise: no Chinese at all, or
    Chinese only inside string literals and some code syntax around it (if hp < 0: print("死亡")). A chapter wrapped in a
    fence, a chat log, a status panel with Chinese sentences is prose and is checked."""
    label = label.strip().lower().split()[0] if label.strip() else ""
    if label in CODE_LANGUAGES:
        return True
    if not HAN_RE.search(body):
        return True  # nothing Chinese to check
    if label in PROSE_LABELS:
        return False
    outside = re.sub(r'"[^"\n]*"|\'[^\'\n]*\'', "", body)  # not “…”: a Chinese quotation is prose
    if not inline:
        outside = re.sub(r"(?://|#).*$|/\*.*?\*/", "", outside, flags=re.M)  # // 扣血,如果小于0就死亡: a comment in code
    if inline and not HAN_RE.search(outside) and re.search(r"[A-Za-z0-9_=(){}\[\]]", outside):
        return True  # ``a`b, "中文"``、`print("你好")`: Chinese only inside a string, with code around it
    return not HAN_RE.search(outside) and bool(re.search(r"[=(){}\[\];<>]|^[ \t]*(?:#|//|def |if |for |import |return )", outside, re.M))


def apostrophe(para, i):
    """’ that is an English apostrophe: Schindler’s, Livin’ on, rock ’n’ roll, the Smiths’ house, ’90s. Not a ’
    right after Chinese text in front of English (他说’OK’, a mistyped opening quote). P01 also needs no ‘ to be open."""
    before, after = para[i - 1:i] if i > 0 else "", para[i + 1:i + 2]
    letter = lambda c: c.isascii() and c.isalpha()
    if re.match(r"’\d\ds", para[i:]):
        return True  # ’90s
    if is_han(after) or (after and after in FULL_PUNCT):
        return False  # SSR’他、OK’，: a closing quotation without its opening one (as in r5.51)
    return letter(before) or (letter(after) and not is_han(before) and before not in FULL_PUNCT)


def title_line(line):
    """A heading (r5.52): a Markdown heading, or a line that begins like 第一章 / 楔子 / 尾声 and is shaped like a title
    (at most 40 characters, no 。 or ；), so prose such as 第二节课上，他睡着了。 or 尾声：众人散去，灯也灭了。 is not."""
    body = line.strip(" \t　")
    if body.startswith("#"):
        return True
    if re.fullmatch("《[^》\n]{1,30}》[ \t　]+[" + HAN + "·]{1,10}", body):
        return True  # 《静夜思》 李白: a title and its author
    return bool(HEADING.match(body)) and len(body) <= 40 and not re.search("[。；]", body)


def load_rules(value):
    if value is None:
        value = {}
    if not isinstance(value, dict):
        raise ValueError("rules must be a JSON object")
    unknown = set(value) - set(DEFAULT_RULES) - {"note", "project"}
    if unknown:
        raise ValueError("unknown rule fields: " + ", ".join(sorted(unknown)))
    rules = json.loads(json.dumps(DEFAULT_RULES))
    profile = value.get("profile", "")
    if profile not in CHOICES["profile"]:
        raise ValueError("profile must be one of: " + ", ".join(PROFILES))
    items = list(json.loads(json.dumps(PROFILES[profile])).items()) if profile else []
    for key, item in items + list(value.items()):
        if key in ("note", "project"):
            continue
        if key in CHOICES:
            if item not in CHOICES[key]:
                raise ValueError(key + " must be one of: " + ", ".join(c for c in CHOICES[key] if c))
            rules[key] = item
        elif key == "stacked_mark_limit":
            if type(item) is not int or not 1 <= item <= 3:
                raise ValueError("stacked_mark_limit must be 1, 2 or 3")
            rules[key] = item
        elif isinstance(rules[key], bool):
            if type(item) is not bool:
                raise ValueError(key + " must be true or false")
            rules[key] = item
        elif isinstance(rules[key], dict):
            if not isinstance(item, dict) or set(item) - set(rules[key]):
                raise ValueError(key + " has invalid fields")
            for sub, number in item.items():
                if type(number) is not int or number < 1:
                    raise ValueError(key + "." + sub + " must be a positive integer")
            rules[key].update(item)
        else:
            if not isinstance(item, list):
                raise ValueError(key + " must be a list")
            rules[key] = item
    for key in ("ability_tags", "panel_prefixes"):
        if not all(isinstance(x, str) and x.strip() for x in rules[key]):
            raise ValueError(key + " must contain nonempty strings")
    for entry in rules["characters"]:
        names = [entry] if isinstance(entry, str) else entry
        if not (isinstance(names, list) and names and all(isinstance(x, str) and x.strip() for x in names)):
            raise ValueError("characters entries must be a name or a list of a person's names")
    for key in ("tag_brackets", "quote_pairs", "raw_brackets"):
        used = set()
        for pair in rules[key]:
            if not (isinstance(pair, list) and len(pair) == 2 and all(isinstance(c, str) and len(c) == 1 for c in pair)):
                raise ValueError(key + " entries must be two single characters")
            if pair[0] == pair[1] or used.intersection(pair):
                raise ValueError(key + " pairs must have distinct, non-overlapping opening and closing characters")
            used.update(pair)
    for item in rules["ignore"]:
        if not isinstance(item, dict) or set(item) - {"column"} != {"rule", "line", "text", "reason"}:
            raise ValueError("each ignore needs rule, line, text, reason (and may give column)")
        if "column" in item and (type(item["column"]) is not int or item["column"] < 1):
            raise ValueError("ignore column must be a positive whole number")
        if item["rule"] not in RULE_TEXT or type(item["line"]) is not int or item["line"] < 1:
            raise ValueError("ignore has an unknown rule or invalid line")
        if not (isinstance(item["text"], str) and item["text"] and isinstance(item["reason"], str) and item["reason"].strip()):
            raise ValueError("ignore text and reason must be nonempty")
    return rules


def assign_ids(items, make):
    """Give every item its own id. The position-based id is unique by construction; should two items ever
    share one, the later ones get -2, -3 ... so that one editorial decision can never cover two findings."""
    taken = set()
    for item in items:
        base = make(item)
        value, number = base, 1
        while value in taken:
            number += 1
            value = "%s-%d" % (base, number)
        item["id"] = value
        taken.add(value)
    return items


def han_count(text):
    return len(HAN_RE.findall(text))


def is_han(char):
    return bool(char) and bool(HAN_RE.match(char))


def lint_text(text, rules=None, dialogue_soft_wrap=None):
    """dialogue_soft_wrap=None follows the rules file; True or False overrides it for this run."""
    rules = load_rules(rules)
    dialogue_soft_wrap = rules["dialogue_soft_wrap"] if dialogue_soft_wrap is None else bool(dialogue_soft_wrap)
    text = text.replace("\r\n", "\n")  # r5.52: CRLF is a line break like LF, as workflow_guard reads files
    if text.startswith("\ufeff"):
        text = text[1:]  # r5.52: a leading byte-order mark is not text (the command line already drops it)
    starts = [0] + [m.end() for m in re.finditer("\n", text)]
    findings = []

    def locate(offset):
        index = bisect.bisect_right(starts, offset) - 1
        return index + 1, offset - starts[index] + 1

    def add(rule, severity, start, end, message, at=None):
        """at: the offsets that decide whether the finding is inside a skipped stretch (default: the whole match), so a
        bracket pair with a URL inside is still reported by its brackets."""
        if rule in FORMAT_RULES and any(shield[k] for k in (range(start, max(end, start + 1)) if at is None else at)):
            return  # inside code, a URL or a registered raw panel: not checked (listed in skipped_spans)
        if rule not in FORMAT_RULES and all(shield[start:max(end, start + 1)]):
            return  # a reading-load hint about a code block
        line, column = locate(start)
        line_end = text.find("\n", start)
        line_end = len(text) if line_end < 0 else line_end
        context = text[max(starts[line - 1], start - 12):min(line_end, end + 12)]
        findings.append({"rule": rule, "name": RULE_TEXT[rule], "severity": severity,
                         "line": line, "column": column, "match": text[start:end],
                         "context": context, "message": message})

    # r5.52: text copied as is is not checked for format: fenced and inline code, URLs, and the inside of the
    # brackets the work registers in raw_brackets. Each skipped stretch is listed in the report.
    shield, skipped = bytearray(len(text) + 1), []

    code_blocks = bytearray(len(text) + 1)  # skipped code blocks: left out of the statistics too
    url_marks = set()  # a half-width , or ; right after a web address, before Chinese text

    def protect(a, b, kind):
        if b > a and not any(shield[a:b]):
            shield[a:b] = b"\x01" * (b - a)
            if kind == "code_block":
                code_blocks[a:b] = b"\x01" * (b - a)
            line, column = locate(a)
            skipped.append({"line": line, "column": column, "kind": kind, "text": text[a:b][:40].replace("\n", "⏎")})

    # Only ``` fences that are closed again; a line of ~~~ is a scene break, and an unclosed fence protects nothing. A
    # fenced block, and text in backticks, is skipped only when it reads as code (reads_as_code); a chapter wrapped in a
    # fence, whatever the label, is prose and is checked like any other text.
    fence, in_fence = None, bytearray(len(text) + 1)
    for match in re.finditer(r"^[ \t]{0,3}(`{3,})([^`\n]*)$", text, re.M):
        if fence is None:
            fence = match
        elif len(match.group(1)) >= len(fence.group(1)) and not match.group(2).strip():
            in_fence[fence.start():match.end()] = b"\x01" * (match.end() - fence.start())
            if reads_as_code(text[fence.end():match.start()], fence.group(2)):
                protect(fence.start(), match.end(), "code_block")
            fence = None
    for match in re.finditer(r"(?<!`)(`+)(?!`)(.+?)(?<!`)\1(?!`)", text):
        if "\n" not in match.group(2) and reads_as_code(match.group(2), inline=True):
            protect(match.start(), match.end(), "code")  # `print("你好")`、``a`b, "中文"``, not backticks around prose
    for match in re.finditer(r"""(?<![A-Za-z0-9_])[A-Za-z_][A-Za-z0-9_.]*\((?:"[^"\n]*"|'[^'\n]*'|[^()\n"']|\([^()\n]*\))*\)""", text):
        inside = match.group(0)[match.group(0).index("(") + 1:-1]
        code_name = match.group(0)[0].islower() or text[match.start() - 1:match.start()] in ("=", ".") or "_" in match.group(0).split("(")[0]
        if code_name and re.search(r'["\'`]', inside) and reads_as_code(match.group(0), inline=True):
            protect(match.start(), match.end(), "code")  # 调用f("中文!")、f(")"): a call written in the prose
    for match in re.finditer(r'(!?)\[[^\]\n]*\]\(((?:[^()\s]|\([^()\s]*\))+)\s+"[^"\n]*"\)', text):
        target = match.group(2)
        if re.search("[,;!?\"'，。！？；：、]", target) or (HAN_RE.search(target) and not (
                re.match(r"(?:\.{0,2}/|#|https?:)", target) or re.search(r"\.[A-Za-z0-9]{1,5}(?:#\S*)?$", target))):
            continue  # [说明](任务完成,奖励已发放 "x"): not an address
        if match.group(1):
            protect(match.start(), match.start() + 1, "link")  # the ! of a Markdown image
        protect(text.index("](", match.start()) + 1, match.end(), "link")  # ![中 文](https://a.cn/a_(b) "标题 (x)")
    for match in re.finditer(r"^[ \t　]*\[\d{1,3}\][ \t　]*\S[^\n]*\[[A-Z]{1,2}(?:/[A-Z]{2})?\][^\n]*$", text, re.M):
        protect(match.start(), match.end(), "reference")  # a reference list entry (GB/T 7714)
    for match in re.finditer(r"!\[[^\]\n]*\]\(", text):
        protect(match.start(), match.start() + 1, "link")  # ![插图](图1.png): the ! of a Markdown image
    for match in re.finditer(r"\]\(([^()\s]+)\)", text):
        target = match.group(1)
        if not re.search("[,;!?\"'，。！？；：、]", target) and (
                not HAN_RE.search(target) or re.match(r"(?:\.{0,2}/|#|https?:)", target)
                or re.search(r"\.[A-Za-z0-9]{1,5}(?:#\S*)?$", target)):
            protect(match.start() + 1, match.end(), "link")  # [见第一章](第一章.md), not ](任务完成,奖励已发放.)
    for match in re.finditer(r"https?://[A-Za-z0-9\-._~:/?#\[\]@!$&'*+,;=%()]+", text):
        url = match.group(0)
        root = re.match(r"https?://[A-Za-z0-9.-]+(?::\d+)?(?=[,;(])", url)
        if root:
            url = root.group(0)  # https://example.com,VIP用户免费、https://example.com(备用站): the address ends at the host (v3.0.1)
        while url and (url[-1] in ".,;:!?'" or (url[-1] == ")" and url.count("(") < url.count(")"))):
            url = url[:-1]  # 见https://a.cn)。、https://a.cn...、主页是https://a.cn:欢迎来玩: the marks after the address are checked
        protect(match.start(), match.start() + len(url), "url")
        after = text[match.start() + len(url):match.start() + len(url) + 1]
        if after in (",", ";") and HAN_RE.search(text[match.start() + len(url):match.start() + len(url) + 12]):
            url_marks.add(match.start() + len(url))  # P06 gives this mark a hint below
    for left, right in rules["raw_brackets"]:
        for line in re.finditer(r"[^\n]+", text):
            depth, opened = 0, None
            for k in range(line.start(), line.end()):
                if text[k] == left:
                    if depth == 0:
                        opened = k
                    depth += 1
                elif text[k] == right and depth:
                    depth -= 1
                    if depth == 0 and k > opened + 1:
                        inside = text[opened + 1:k]
                        if inside.rstrip("。，、；：！？….,;:!?") in rules["ability_tags"]:
                            continue  # 【定。】: a registered ability tag is never a raw panel (P03 still applies)
                        protect(opened + 1, k, "raw")  # the outermost panel on the line, nested panels inside it

    paragraphs = []
    for match in re.finditer(r"[^\n]+", text):
        if match.group(0).strip():
            paragraphs.append((match.start(), match.group(0)))

    # Opt-in only: physical line breaks inside ONE quoted speech block may be
    # author's soft visual wraps, not missing closing quotes. Preserve literal
    # offsets, bytes, all other checks, and the default strict behavior.
    if dialogue_soft_wrap and rules["quote_pairs"]:
        left, right = rules["quote_pairs"][0]
        joined = []
        i = 0
        while i < len(paragraphs):
            start, fragment = paragraphs[i]
            body = fragment.lstrip(' \t　')
            if body.startswith(left) and body.count(left) > body.count(right):
                j = i + 1
                while j < len(paragraphs) and j - i <= 12:
                    next_start, next_fragment = paragraphs[j]
                    previous_start, previous_fragment = paragraphs[j - 1]
                    # An empty line or an independently quoted new paragraph
                    # stops soft wrapping. These retain ordinary P01 checks.
                    between = text[previous_start + len(previous_fragment):next_start]
                    if between.count('\n') != 1 or next_fragment.lstrip().startswith(left):
                        break
                    fragment = text[start:next_start + len(next_fragment)]
                    j += 1
                    if fragment.count(left) <= fragment.count(right):
                        break
                if j > i+1:
                    joined.append((start, fragment))
                    i = j
                    continue
            joined.append((start, fragment))
            i += 1
        paragraphs = joined

    # P01 quotes, allowing the convention that a quotation spanning paragraphs
    # reopens each paragraph and closes only once at the end.
    openers = {pair[0]: pair[1] for pair in rules["quote_pairs"]}
    closers = {pair[1]: pair[0] for pair in rules["quote_pairs"]}
    stack, previous_end, open_at, apostrophes = [], 0, None, set()
    for start, para in paragraphs:
        body_offset = len(para) - len(para.lstrip(" \t　"))
        skip_at = None
        if stack:
            first = para[body_offset:body_offset + 1]
            if len(stack) == 1 and first == stack[0][0]:
                skip_at = body_offset
                if rules["continued_quotes"] == "review":
                    add("P15", "REVIEW", open_at, min(previous_end, open_at + 12, text.find("\n", open_at) % (len(text) + 1)),
                        "这一段到段末引号没有收，下一段又以前引号开头。同一个人接着说（跨段引语：每段开头用前引号，"
                        "只在最后一段收）不用改；如果下一段换了人说话，这里漏了后引号。", at=(open_at,))
            else:
                for char, pos in stack:
                    add("P01", "ERROR", pos, pos + 1, "引号在段末仍未闭合，下一段也不是续引的前引号。")
                stack = []
        previous_end = start + len(para.rstrip(" \t　"))
        for i, char in enumerate(para):
            if i == skip_at or shield[start + i]:
                continue
            pos = start + i
            if char in openers and not (char == closers.get(char)):
                if stack and stack[-1][0] == char:
                    add("P01", "ERROR", stack[-1][1], stack[-1][1] + 1, "同类前引号尚未闭合又出现新的前引号。")
                    stack[-1] = (char, pos)
                else:
                    stack.append((char, pos))
            elif char in closers:
                if char == "’" and 0 < i < len(para) - 1 and para[i - 1].isascii() and para[i - 1].isalpha() and para[i + 1].isascii() and para[i + 1].isalpha():
                    apostrophes.add(pos)
                    continue  # English apostrophe
                if char == "’" and apostrophe(para, i) and not (stack and stack[-1][0] == "‘"):
                    apostrophes.add(pos)
                    continue  # Livin’ on, Guns N’ Roses, rock ’n’ roll (r5.52): an apostrophe, no single quotation is open
                if stack and stack[-1][0] == closers[char]:
                    stack.pop()
                else:
                    add("P01", "ERROR", pos, pos + 1, "后引号没有对应的前引号，或与内层引号交叉。")
        if stack:  # where the quotation still open at the end of this paragraph opened (or was reopened)
            open_at = stack[0][1] if stack[0][1] >= start else start + (skip_at or 0)
    for char, pos in stack:
        add("P01", "ERROR", pos, pos + 1, "全文结束时引号仍未闭合。")

    partner = {}  # round brackets paired within a line, full or half width (a mixed pair is reported once, by P06)
    for line in re.finditer(r"[^\n]+", text):
        opened = []
        for k in range(line.start(), line.end()):
            if text[k] in "(（":
                opened.append(k)
            elif text[k] in ")）" and opened:
                if text[k] == ")" and text[opened[-1]] == "（" and (
                        text[k - 1:k] in (":", ";") or text[k - 2:k] in (":-", ";-")
                        or re.search(r"(?:^|[\s（：；，、])[0-9A-Za-z]{1,2}$", text[line.start():k])):
                    continue  # （1) 保护现场；2) 通知家属）、（别迟到哦:)）: an ordinal or an emoticon
                o = opened.pop()
                partner[o], partner[k] = k, o
    def wordy(inside):
        """Words in a bracket pair, not a kaomoji: （左臂还在发麻)、（Lv.10)、（？), not (╯°口°）╯、(⊙▽⊙）、(😂）."""
        faces = re.findall("[╯╰╭╮°□′‵ωಥ⊙▽△▼▲´｀ﾟ∀ノヽ＼◕‿◡＾≧≦⌒⊂⊃ε∩Ддσ●◉┻━︵]|[\U0001F300-\U0001FAFF]", inside)
        kaomoji = len(faces) >= 2 or (faces and not re.search("[A-Za-z0-9" + HAN + "]", re.sub("[口皿益]", "", inside)))
        return bool(inside.strip()) and not kaomoji

    mixed_any = {k for k, v in partner.items() if {text[k], text[v]} in ({"（", ")"}, {"(", "）"})}
    mixed_pair = {k for k in mixed_any if wordy(text[min(k, partner[k]) + 1:max(k, partner[k])])}

    # P02 brackets inside one paragraph.
    bracket_pairs = {"（": "）", "【": "】", "《": "》", "〈": "〉", "〔": "〕", "「": "」", "『": "』"}
    for pair in rules["quote_pairs"]:
        bracket_pairs.pop(pair[0], None)
    closing = {v: k for k, v in bracket_pairs.items()}
    for start, para in paragraphs:
        local = []
        for i, char in enumerate(para):
            if shield[start + i] or start + i in mixed_any:
                continue  # a mixed-width pair: P06 (a kaomoji such as (╯°□°）╯ is not reported at all)
            if char in bracket_pairs:
                parent = next((c for c in reversed(local) if c[0] in "《〈"), None)
                rest = para[i + 1:]
                run = len(re.match(re.escape(char) + "*", para[i:]).group(0)) + len(para[:i]) - len(para[:i].rstrip(char))
                if char in "《〈" and parent and parent[0] == char and run < 3 \
                        and rest.count(bracket_pairs[char]) - rest.count(char) >= 2:
                    add("P02", "ERROR", start + i, start + i + 1,
                        "书名号里又套同一种书名号；里层要用另一种：外层《》、里层〈〉（《〈春〉教案》）。")
                local.append((char, start + i))
            elif char in closing:
                if local and local[-1][0] == closing[char]:
                    local.pop()
                    continue
                depth = next((k for k in range(len(local) - 1, -1, -1) if local[k][0] == closing[char]), None)
                if depth is not None and not any(para[i + 1:].count(bracket_pairs[c]) > para[i + 1:].count(c) for c, _ in local[depth + 1:]):
                    for c, pos in local[depth + 1:]:  # r5.52 (from the author's v3.2.1): “他打开了【系统面板。” is one
                        add("P02", "ERROR", pos, pos + 1, "括号在本段内没有闭合。")  # missing 】, not three faults
                    del local[depth:]
                else:
                    add("P02", "ERROR", start + i, start + i + 1, "后括号没有对应的前括号，或括号交叉。")
        for char, pos in local:
            add("P02", "ERROR", pos, pos + 1, "括号在本段内没有闭合。")

    # r5.52: a quote and a bracket that cross inside one paragraph (他说：“走（快”）。). Crossings of two quotes or two
    # brackets are reported above; this finds the ones the two separate stacks cannot see.
    quote_open = {pair[0]: pair[1] for pair in rules["quote_pairs"] if pair[0] != pair[1]}
    quote_close = {v: k for k, v in quote_open.items()}
    for index, (start, para) in enumerate(paragraphs):
        mixed_stack = []
        follows = paragraphs[index + 1][1].lstrip(" \t　")[:1] if index + 1 < len(paragraphs) else ""
        for i, char in enumerate(para):
            pos = start + i
            if shield[pos] or pos in mixed_any or pos in apostrophes:
                continue  # 《Schindler’s List》 inside ‘’ inside “”: an apostrophe, not a crossing
            if char in quote_open or char in bracket_pairs:
                mixed_stack.append((char, pos))
            elif char in quote_close or char in closing:
                want = quote_close.get(char) or closing.get(char)
                if mixed_stack and mixed_stack[-1][0] == want:
                    mixed_stack.pop()
                    continue
                depth = next((k for k in range(len(mixed_stack) - 1, -1, -1) if mixed_stack[k][0] == want), None)
                if depth is None:
                    continue  # no opener in this paragraph: P01 or P02
                rest = para[i + 1:]
                if any((c in quote_open) != (char in quote_close)
                       and (rest.count(quote_open.get(c) or bracket_pairs.get(c)) > rest.count(c) or (c in quote_open and follows == c))
                       for c, _ in mixed_stack[depth + 1:]):  # an inner mark that never closes is P01/P02's missing mark, unless
                    # it is a quotation carried on into the next paragraph (P01 gives only P15 there): （“别回来）。⏎“我知道了。”
                    add("P02", "ERROR", pos, pos + 1, "引号和括号交叉：里层的括号或引号要先收，再收外层的。")
                del mixed_stack[depth]

    # P03 tags such as an ability name that must not carry sentence punctuation.
    abilities = set(rules["ability_tags"])
    for left, right in rules["tag_brackets"]:
        pattern = re.compile(re.escape(left) + "([^" + re.escape(left + right) + "\n]{1,40})" + re.escape(right))
        bare = {m.group(1) for m in pattern.finditer(text)}
        for match in pattern.finditer(text):
            content = match.group(1)
            core = content.rstrip("。，、；：！？…")
            if core == content or not core:
                continue
            if any(core.startswith(prefix) for prefix in rules["panel_prefixes"]):
                continue
            if core in abilities:
                add("P03", "ERROR", match.start(), match.end(),
                    "已登记的能力/物品标签内带了句末标点；应写作" + left + core + right + "，句子标点放在括号外。")
            elif core in bare:
                add("P03", "REVIEW", match.start(), match.end(),
                    "本文也有" + left + core + right + "；确认两处是否同类标签。面板整句与标签可能合法并存。")
            elif han_count(core) <= 2:
                add("P03", "REVIEW", match.start(), match.end(),
                    "短标签内带句末标点，疑似能力名误加标点；若是系统面板句子，请在规则中登记前缀或豁免。")

    # P04 consecutive punctuation.
    for match in re.finditer(r"([。，、；：])[ \t　]+\1", text):
        add("P04", "ERROR", match.start(), match.end(), "同一个标点隔着空格写了两遍（。 。）；只留一个。")
    in_error_run = set()
    for match in re.finditer("[" + PAUSES + "！？]{2,}", text):
        run = set(match.group(0))
        if run & set("！？") and run & set("。，、；"):
            add("P04", "ERROR", match.start(), match.end(), "叹号或问号和句号、逗号等连用；只留一个。")
            in_error_run.update(range(match.start(), match.end()))
            continue
        for part in re.finditer("[" + PAUSES + "]{2,}", match.group(0)):  # 小雪：？ and ？？？：你来了 are not reported
            if set(part.group(0)) == {"。"} and len(part.group(0)) >= 3:
                continue  # reported as an ellipsis form below
            add("P04", "ERROR", match.start() + part.start(), match.start() + part.end(), "停顿或句末标点连用。")
    for match in re.finditer("[" + TERMINALS + "][”’」』][。，；]|([！？])[”’」』]\\1", text):  # “谁？”？ (not “救命！”？)
        add("P04", "REVIEW", match.start(), match.end(), "核对引文是独立话语还是句子成分，再决定引号内外标点；不能只凭相邻符号删除。")
    limit = rules["stacked_mark_limit"]
    for match in re.finditer("[！？]{%d,}" % (limit + 1), text):
        if match.start() in in_error_run:
            continue  # 走！！！。: one ERROR for the run
        if limit == 2:
            add("P04", "REVIEW", match.start(), match.end(), "连续三个以上叹号或问号，确认是否为人物声音所需。")
        elif not (limit == 1 and match.group(0) in ("？！", "！？")):
            add("P04", "REVIEW", match.start(), match.end(),
                "连续%d个叹号或问号；作品约定最多连用%d个。国家标准允许叠用，这里只提示，确认是否为人物声音所需。"
                % (len(match.group(0)), limit))
    for match in re.finditer("……[。，]", text):
        add("P04", "REVIEW", match.start(), match.end(), "省略号后通常不再加句号或逗号，按项目约定确认。")

    # P05 ellipsis and dash forms.
    handled = set()  # offsets already reported as part of an ellipsis or dash run (P06 does not report them again)

    def beside(i, step):
        j = i + step
        while 0 <= j < len(text) and text[j] in " \t":
            j += step
        return text[j] if 0 <= j < len(text) else ""

    def cjk_around(a, b):
        """Next to a Chinese character or mark; or, across spaces, Chinese on both sides (他说 ... 走了, not 加载 ../config)."""
        if CJK_CONTEXT.search(text[max(0, a - 1):a] + text[b:b + 1]):
            return True
        left, right = beside(a, -1), beside(b - 1, 1)
        return bool(left and right and CJK_CONTEXT.match(left) and CJK_CONTEXT.match(right))

    for match in re.finditer(r"[….]+", text):
        if "…" in match.group(0) and "." in match.group(0) and cjk_around(match.start(), match.end()):
            add("P05", "ERROR", match.start(), match.end(), "省略号里混着半角点；中文省略号为“……”（两个“…”）。")
            handled.update(range(match.start(), match.end()))
    chinese_text = bool(HAN_RE.search(text))

    def line_of_text(offset):
        line_start = text.rfind("\n", 0, offset) + 1
        line_end = text.find("\n", offset)
        return text[line_start:len(text) if line_end < 0 else line_end]

    def between_chinese_lines(offset):
        """The nearest non-blank lines above and below (where there are any) have Chinese characters."""
        line_start = text.rfind("\n", 0, offset) + 1
        line_end = text.find("\n", offset)
        wordy_line = lambda l: bool(re.search("[A-Za-z0-9" + HAN + "]", l))  # skip ---, * * *, ◆◆◆
        above = [l for l in text[:max(0, line_start - 1)].split("\n") if wordy_line(l)][-1:]
        below = [l for l in ("" if line_end < 0 else text[line_end + 1:]).split("\n") if wordy_line(l)][:1]
        return bool(above or below) and all(HAN_RE.search(l) for l in above + below)

    def english_quotation(offset):
        """Inside a quotation that has no Chinese character before offset and ends an English word: “Wait...”"""
        line_start = text.rfind("\n", 0, offset) + 1
        opened = max(text.rfind(q, line_start, offset) for q in "“「『‘")
        if not (opened >= 0 and offset > 0 and text[offset - 1].isascii() and text[offset - 1].isalpha()
                and not HAN_RE.search(text[opened + 1:offset])):
            return False
        line_end = text.find("\n", offset)
        rest = text[offset:len(text) if line_end < 0 else line_end]
        closed = min([k for k in (rest.find(q) for q in "”」』’") if k >= 0] or [len(rest)])
        return not HAN_RE.search(rest[:closed]) and " " in text[opened + 1:offset].strip()  # not “emmm...”、“Wait...”
    for match in re.finditer(r"\.{3,}|。{3,}", text):
        if match.start() in handled:
            continue
        alone = chinese_text and re.fullmatch(r"[ \t　]*", text[text.rfind("\n", 0, match.start()) + 1:match.start()]) \
            and re.match(r"[ \t　]*(?:\n|$)", text[match.end():]) and between_chinese_lines(match.start())
        if match.group(0)[0] == "." and english_quotation(match.start()):
            continue  # “Fine, thanks...”, “Loading...”: an English quotation keeps English dots (r5.52)
        if cjk_around(match.start(), match.end()) or match.group(0)[0] == "。" or alone:
            add("P05", "ERROR", match.start(), match.end(), "中文省略号应为“……”（两个省略号字符）。")
    for match in re.finditer(r"(?<!\.)\.\.(?!\.)", text):
        if text[match.end():match.end() + 1] in ("/", "\\") and text[match.end():match.end() + 1] \
                or (text[match.start() - 1:match.start()] == " " and re.search("[A-Za-z0-9]$", text[:match.start()].rstrip(" "))) \
                or english_quotation(match.start()):
            continue  # ../verify, ..\backup, cd .. ; “Wait..”
        if match.start() not in handled and cjk_around(match.start(), match.end()):
            add("P05", "ERROR", match.start(), match.end(), "两个半角点；中文省略号为“……”（两个“…”）。")
            handled.update(range(match.start(), match.end()))
    for match in re.finditer("…+", text):
        size = len(match.group(0))
        if match.start() in handled or size == 2:
            continue
        if size == 1:
            add("P05", "REVIEW", match.start(), match.end(), "单个“…”；中文省略号通常为“……”。")
        elif size == 4:
            line_start = text.rfind("\n", 0, match.start()) + 1
            line_end = text.find("\n", match.end())
            if text[line_start:len(text) if line_end < 0 else line_end].strip(" \t　") == match.group(0):
                continue  # a line of twelve dots: whole paragraphs or lines left out
            add("P05", "REVIEW", match.start(), match.end(),
                "四个“…”（十二个点）只用于省略整段文字或诗行；句子里的省略号为“……”。")
        else:
            add("P05", "REVIEW", match.start(), match.end(), "%d个“…”连写；中文省略号为“……”（两个“…”）。" % size)
    for match in re.finditer(r"[—\-－]+", text):
        end = match.end()
        minus = re.match(r"[0-9][0-9.]*", text[end:end + 12])
        if text[end - 1] in "-－" and ((minus and not is_han(text[end + minus.end():end + minus.end() + 1]))
                                       or re.match(r"[a-z]", text[end:end + 1])):
            end -= 1  # ——-273.15℃: the last hyphen is a minus sign
        run = text[match.start():end]
        if "—" in run and ("-" in run or "－" in run) and cjk_around(match.start(), end):
            add("P05", "ERROR", match.start(), end, "破折号里混着连字符；中文破折号为“——”（两个“—”）。")
            handled.update(range(match.start(), end))
    for match in re.finditer(r"(?<![-－—])(?:--+|－－+)(?![-－—])", text):
        if re.match(r"[a-z]", text[match.end():match.end() + 1]):
            continue  # 中文--force与---long选项: command-line options
        if cjk_around(match.start(), match.end()):  # 他说--走了, 他说 -- 走了 (not 执行 --force)
            add("P05", "REVIEW", match.start(), match.end(), "疑似破折号写法；中文破折号为“——”。")
    for match in re.finditer("—+", text):
        size, before, after = len(match.group(0)), text[match.start() - 1:match.start()], text[match.end():match.end() + 1]
        if match.start() in handled or size == 2 or not cjk_around(match.start(), match.end()):
            continue
        whole = line_of_text(match.start()).strip(" \t　")
        if size >= 3 and re.fullmatch("—{3,}.{0,12}—{3,}", whole):
            continue  # ————分割线————: a divider line
        if size == 1:
            if before.isascii() and before.isalnum() and after.isascii() and after.isalnum():
                continue  # 第1—4章, 2011—2012年: a range
            numeral = "一二三四五六七八九十百千零〇两日天"
            left_run = re.search("[" + numeral + "]+$", text[max(0, match.start() - 6):match.start()])
            right_run = re.match("[" + numeral + "]+", text[match.end():match.end() + 6])
            if (re.search(r"(?:[0-9][年月日号点时]|世纪|？)$", text[max(0, match.start() - 3):match.start()]) and after.isdigit()) \
                    or (left_run and right_run and left_run.group(0) != right_run.group(0)) \
                    or (before and after and before in numeral and before != after
                        and (after in numeral or (text[match.start() - 2:match.start() - 1] == after
                                                  and text[match.end() + 1:match.end() + 2] in numeral))):
                continue  # 1937年—1945年, 9点—11点, （？—757）, 三—五天, 周一—周五: ranges (不是—不是这样的 is not one)
            add("P05", "REVIEW", match.start(), match.end(),
                "单个“—”：表示起止（北京—上海、第1—4章）是一字线，不用改；当破折号用时应为“——”。")
        else:
            add("P05", "REVIEW", match.start(), match.end(),
                "%d个“—”连写；破折号为“——”。表示声音延长时作品可以按约定加长，确认是否有意。" % size)
    for match in re.finditer("[─―]+", text):
        before, after = text[match.start() - 1:match.start()], text[match.end():match.end() + 1]
        if len(match.group(0)) > 2 and not (before and after and CJK_CONTEXT.match(before) and CJK_CONTEXT.match(after)
                                            and before not in "【】" and after not in "【】"):
            continue  # a drawn line (────, 【────状态────】); 他―――走了, 我说───” stand for a dash
        if BOX_DRAWING.match(text[match.start() - 1:match.start()]) or BOX_DRAWING.match(text[match.end():match.end() + 1]):
            continue  # ├─武器, └─任务物品: a drawn tree
        if cjk_around(match.start(), match.end()):
            char = match.group(0)[0]
            add("P05", "REVIEW", match.start(), match.end(),
                ("“─”是制表符，" if char == "─" else "“―”是近形字符，") + "不是破折号；当破折号用时应为“——”。")

    for match in re.finditer("[·・･]{2,}", text):
        if is_han(text[match.start() - 1:match.start()]) and (is_han(text[match.end():match.end() + 1])
                                                              or text[match.end():match.end() + 1] in "”’」』"):
            add("P05", "REVIEW", match.start(), match.end(), "间隔号连写当省略号用；中文省略号为“……”。")

    # P06 ASCII punctuation in Chinese context; numbers, times, words, code and English sentences exempt.
    closing_of = {"”": "“", "’": "‘", "」": "「", "』": "『", "）": "（", "】": "【", "》": "《"}

    def english_stretch(i):
        """The text before i back to the last Chinese character or mark on the line: Level up of [System: Level up!"""
        j = i - 1
        while j >= 0 and text[j] != "\n" and not is_han(text[j]) and text[j] not in FULL_PUNCT and text[j] not in "[(":
            j -= 1
        return text[j + 1:i]

    def chinese_sentence(i):
        """The stretch before i, back to the last Chinese mark or the line start, has a Han character; or it holds no
        English word (只是数字、时间) and the line before it is Chinese: 他看了一眼表——10:30."""
        j = i - 1
        while j >= 0 and text[j] != "\n" and text[j] not in "。！？；：，、“”‘’「」『』（）【】《》…—":
            j -= 1
        stretch = text[j + 1:i]
        if HAN_RE.search(re.sub(r"\([^()\n]*\)", "", stretch)):
            return True  # (Entropy (熵) is a measure of disorder.: a Chinese gloss in an English sentence does not count)
        return not re.search("[A-Za-z]", stretch) and bool(HAN_RE.search(text[text.rfind("\n", 0, i) + 1:i]))

    mixed_reported, emoticons = set(), set()
    for match in re.finditer(r"[,.;:!?()\"']", text):
        i, char = match.start(), match.group(0)
        if i in handled:
            continue  # part of an ellipsis or dash run reported by P05
        prev = text[i - 1] if i > 0 else ""
        nxt = text[i + 1] if i + 1 < len(text) else ""
        if char == "." and (prev == "." or nxt == "."):
            continue  # handled by P05
        if char in ".,:" and prev.isdigit() and nxt.isdigit():
            continue  # 3.5, 1,000, 10:00
        face = re.match(r"[:;]-?(?:([)(])(?![A-Za-z0-9" + HAN + "])|([DPp])(?=[ \t\n]|$))", text[i:i + 4])
        if face and face.group(2) and not (i == 0 or text[i - 1] in " \t\n"):
            face = None  # 他的总评:D: a grade after a colon (好的 :D is a face)
        if i in url_marks:
            add("P06", "REVIEW", i, i + 1, "网址后面紧跟的半角“%s”接着中文；网址和中文之间的标点应为全角。" % char)
            continue  # 请打开https://example.com,VIP用户免费
        if char in ":;" and face and (not face.group(1) or i + face.end(1) - 1 not in partner):
            emoticons.add(i + face.end() - 1)
            continue  # 收到:)、晚安;)、哈哈:D: an emoticon (not 如下:(见附件)、答案:D。)
        if char in "()" and i in emoticons:
            continue
        if char == ":" and re.match(r"[ \t]*\[\^?[^\]\n]{1,12}\]$", text[text.rfind("\n", 0, i) + 1:i]):
            continue  # [^1]: 注释、[1]: https://…: a Markdown footnote or reference definition
        if char in "()" and i in partner:
            o, c = min(i, partner[i]), max(i, partner[i])
            if text[o] != "(" or text[c] != ")":
                if i in mixed_pair and o not in mixed_reported:
                    mixed_reported.add(o)
                    add("P06", "ERROR", i, i + 1, "括号一半全角一半半角；中文括号应为“（……）”。")
                continue  # a kaomoji such as (╯°□°）╯ is not reported
            inside = text[o + 1:c]
            if not HAN_RE.search(inside) and '"' not in inside and not re.search("[" + re.escape(FULL_PUNCT) + "]", inside):
                if i == o and re.search(r"[!?]$", inside) and not re.match(r"[A-Za-z0-9_]", text[o - 1:o]) \
                        and (CJK_CONTEXT.match(text[o - 1:o]) or CJK_CONTEXT.match(text[c + 1:c + 2])):
                    add("P06", "REVIEW", o, c + 1, "中文句子里的半角括号带着半角叹号或问号（(SSR!)）；中文正文用（SSR！）。")
                continue  # init(), f(x), (HP), f(x!=0): ASCII brackets around ASCII text (not ("SSR!"), (？), (……))
        in_path = re.search(r"(?:[A-Za-z]:\\|\\|~/|\./|/)\S*$", text[text.rfind("\n", 0, i) + 1:i])
        named = (DOTTED_NAMES_ANY_CASE if in_path else DOTTED_NAMES).match(text, i)
        if named and not in_path and not named.group(0)[1:].islower() and named.group(0) != ".NET":
            named = None  # 电脑.PDF怎么也打不开、走了.Doc看了: a sentence end (r5.51); D:\雾镇\第一卷.Docx is a path
        if char == "." and (not prev or is_han(prev) or prev in FULL_PUNCT or prev in " \t") and named:
            continue  # 基于.NET, 、.NET, 存成.txt: a known name that begins with a dot (电脑.Windows启动了 is still an ERROR)
        if char in ",!?;" and prev.isascii() and prev.isalnum() and nxt.isascii() and nxt.isalpha() and \
                (char != "," or prev.isdigit()) and is_han(text[i + 1 + len(re.match(r"[A-Za-z0-9]*", text[i + 1:]).group(0)):][:1]):
            add("P06", "REVIEW", i, i + 1, "英文或数字后面的半角“%s”接着英文词和中文；中文句子里应为全角。" % char)
            continue  # 11:30,Boss还在、SSR!Boss看了
        if prev.isascii() and prev.isalnum():
            if nxt.isascii() and nxt.isalnum():
                continue  # inside an English word or a code token
            if char in "\"'" and nxt in ("", " ", "\n"):
                continue  # English quotation marks
            if char == "." and re.search(r"(?:^|[\s　（：；，、])(?:[0-9]{1,3}|[A-Za-z])$", text[text.rfind("\n", 0, i) + 1:i]):
                continue  # "1. 耗时……"、"：1.传递信息；2.确定关系"、"A.坐船": a list ordinal
            word_start = i
            while word_start > 0 and (text[word_start - 1].isascii() and (text[word_start - 1].isalnum() or text[word_start - 1] == ".")):
                word_start -= 1
            word = text[word_start:i]
            last = word.split(".")[-1]
            if char == "." and (re.fullmatch(r"(?:[A-Z]\.)+[A-Z]", word) or (len(word) == 1 and word.isupper()
                                                                          and text[word_start - 1:word_start] in "·・•")):
                continue  # J.K.罗琳、作者署名W.H.O.、蒙奇·D.路飞: initials (代号是K.他走了 is still a hint)
            if char == "." and ABBREVIATION.search(last) and (len(last) == 1 or word == last) and \
                    (len(last) > 1 or (nxt in " \t" and not is_han(text[word_start - 1:word_start]))):
                continue  # P.S. 你、A. 鲁迅、Dr. 陈、e.g. 内卷、vs. 日本队 (not 选C. 你呢): the dot belongs to the abbreviation
            if char == ":" and word in ("Re", "RE", "Fw", "FW", "Fwd"):
                continue  # “Re: 冷启动方案讨论”: a mail subject as written
            line_start = text.rfind("\n", 0, i) + 1
            if char in ",.;:!?" and nxt in ("", " ", "\t", "\n") and text.rfind("[", line_start, i) > text.rfind("]", line_start, i) \
                    and len(re.findall("[A-Za-z]{2,}", english_stretch(i))) >= 2:
                continue  # [System: Level up! 等级+1]: the mark of an English phrase inside an English panel
            if char in ",.;:!?" and nxt in ("", " ", "\t", "\n"):
                after = beside(i, 1)
                if is_han(after):
                    add("P06", "REVIEW", i, i + 1, "英文词后面的半角“%s”接着中文；这是中文句子的标点，应为全角。" % char)
                elif after in ("", "\n") and chinese_sentence(i):
                    add("P06", "REVIEW", i, i + 1, "中文句子以英文词收尾，句末用了半角“%s”；应为全角。" % char)
                continue  # otherwise English text
            if char in ",.;:!?" and nxt in closing_of:
                opened = text.rfind(closing_of[nxt], text.rfind("\n", 0, i) + 1, i)
                if opened >= 0 and not HAN_RE.search(text[opened + 1:i]) and (" " in text[opened + 1:i].strip()
                                                                             or not is_han(text[i + 2:i + 3])):
                    continue  # “Fine, thanks.”, 写了“Help!”。: English quoted inside Chinese text (not “OK,”他说)
        spaced_han = prev in " \t" and is_han(beside(i, -1)) and \
            (is_han(beside(i, 1)) or beside(i, 1) in ("", "\n") or beside(i, 1) in FULL_PUNCT)  # 他说 , 走吧; not 好吧 :(
        if not (is_han(prev) or is_han(nxt) or (prev and prev in FULL_PUNCT) or (nxt and nxt in FULL_PUNCT)):
            if spaced_han:
                add("P06", "ERROR" if char in ",.;!?\"'" else "REVIEW", i, i + 1,
                    "中文语境中出现半角“%s”（前后有空格）。" % char)  # a spaced : is a hint: 糖 : 醋 : 酱油 is a ratio
            elif char in "\"'" and (is_han(beside(i, -1)) or is_han(beside(i, 1))):
                add("P06", "REVIEW", i, i + 1, "中文句子里的直引号（他说 \"OK\" 就走了）；中文正文用“”‘’。")
            elif char in ",.;:!?" and ((prev in " \t" and beside(i, -1) in FULL_PUNCT and beside(i, -1))
                                       or (nxt in " \t" and is_han(beside(i, 1)))):
                add("P06", "REVIEW", i, i + 1, "中文语境中出现半角“%s”（隔着空格）；中文句子里应为全角。" % char)
            continue
        # ERROR only where the mark is certainly Chinese punctuation: right after a Chinese character (as in r5.51), across
        # spaces with Chinese on both sides, or a straight double quote touching a Chinese character or right after a Chinese
        # mark ("走吧。"她说, “快走。"). A mark
        # after a closing quote or bracket, a straight single quote and half-width brackets around Chinese stay REVIEW:
        # English sentences, primes (A'), formulas and file names use them correctly (RC-53).
        line_start, line_end = text.rfind("\n", 0, i) + 1, (text.find("\n", i) + 1 or len(text) + 1) - 1
        prime = char == '"' and (prev.isnumeric() or (prev.isascii() and prev.isalpha() and not re.match('[A-Za-z"“]', text[i - 2:i - 1])))
        chinese_side = is_han(prev) or spaced_han or (char == '"' and not prime and not in_fence[i]
                                                     and (is_han(nxt) or prev in "。！？，、；：…—"))
        # 27"的显示器、所以f"恒大于零: after a digit, or a lone one after a single letter, it is an inch, second or double
        # prime mark (a hint, as in r5.51), not a quotation mark
        severity = "ERROR" if char in ",.;:!?\"'" and chinese_side else "REVIEW"
        add("P06", severity, i, i + 1, "中文语境中出现半角“" + char + "”。")

    # P07 full-width digits and Latin letters.
    for match in re.finditer("[０-９Ａ-Ｚａ-ｚ]+", text):
        add("P07", "REVIEW", match.start(), match.end(), "全角数字或字母，确认是否与全书写法一致。")

    # P08 spaces between Chinese characters, ideographic spaces inside a line.
    def line_of(offset):
        line_start = starts[locate(offset)[0] - 1]
        line_end = text.find("\n", offset)
        return text[line_start:len(text) if line_end < 0 else line_end]

    for match in re.finditer("(?<=[" + HAN + "])[ \t]+(?=[" + HAN + "])", text):
        if title_line(line_of(match.start())):
            continue  # "第一章 雾港" and Markdown headings keep their title space
        add("P08", "REVIEW", match.start(), match.end(), "汉字之间出现空格。")
    tag_pairs = {(pair[1], pair[0]) for pair in rules["tag_brackets"]}
    for match in re.finditer("(?<=[" + HAN + re.escape(FULL_PUNCT) + "])[ \t]+(?=[" + HAN + re.escape(FULL_PUNCT) + "])", text):
        a, b = text[match.start() - 1], text[match.end()]
        if is_han(a) and is_han(b):
            continue  # reported above
        if (a, b) in tag_pairs:
            continue  # 】 【: P14
        if a == b and a in "。，、；：":
            continue  # 。 。: P04
        if title_line(line_of(match.start())):
            continue
        add("P08", "REVIEW", match.start(), match.end(), "中文标点前后出现半角空格。")
    marks = re.escape(FULL_PUNCT.replace("·", ""))
    for match in re.finditer("(?<=[A-Za-z0-9" + marks + "])[ \t]+(?=[A-Za-z0-9" + marks + "])", text):
        a, b = text[match.start() - 1], text[match.end()]
        if (a in FULL_PUNCT) == (b in FULL_PUNCT):
            continue  # two marks: above; two letters: English text
        if a in "”）》】〉」』〕‘’" or b in "“（《【〈「『〔‘’" or (a in "—…" and text[match.start() - 2:match.start() - 1] != a) \
                or (b in "—…" and text[match.end() + 1:match.end() + 2] != b):
            continue  # translated 《三体》, and、labelled “adjusted revenue”、【力量】 12、rock ’n’ roll、Wait — what: a space
            # outside a bracket or quotation pair, or English typography (a space inside one, （ Lv.10 ）、“ Hello ”, is reported)
        if title_line(line_of(match.start())):
            continue  # 第2章  SSR
        add("P08", "REVIEW", match.start(), match.end(),  # r5.52 (from the author's v3.3.1): 抽到SSR ！、倒计时—— 3、（ Lv.10 ）
            "中文标点和英文或数字之间出现半角空格；全角标点自带间距，前后不加空格。")
    for start, para in paragraphs:
        if title_line(para):
            continue  # 第一章　雾港: a title keeps its space (r5.52)
        indent = len(para) - len(para.lstrip(" \t　"))
        for match in re.finditer("　+", para[indent:]):
            if para[indent + match.start() - 1:indent + match.start()] == "\n":
                continue  # the indent of a soft-wrapped line (dialogue_soft_wrap)
            pos = start + indent + match.start()
            add("P08", "REVIEW", pos, pos + len(match.group(0)), "行内出现全角空格。")

    # P09 a quote that ends without punctuation and runs straight into a speech tag. r5.52 (from the author's v2.8.1):
    # or, at the start of a paragraph, straight into a person doing something (“快走”老冯一把拽住他。): a word list of
    # people (pronouns, 老X/小X/阿X, the work's registered characters) and actions, never the length of the quotation.
    names = [re.escape(n) for entry in rules["characters"] for n in ([entry] if isinstance(entry, str) else entry)]
    person_first = re.compile("(?:[他她我你您它]们?" + "".join("|" + n for n in names) + ")")
    actor_action = re.compile(
        "(?:[他她我你您]们?|[老小阿][" + HAN + "]{1,2}?|(?:这|那)(?:个|名|位)?(?:人|男人|女人|少年|少女|老人|老者)"
        "|众人|有人|向导|司机|医生|护士|老板|店主|警卫|守卫|士兵" + "".join("|" + n for n in names) + ")"
        "(?:一把|猛地|连忙|急忙|低声|轻声|大声|厉声|缓缓|立刻|赶紧){0,2}"
        "(?:拽|拉|推|抓|扑|伸手|抬手|转身|点头|摇头|回头|摆手|挥手|挽住|拍了|拍着)")
    p09_ends = set()  # closing quotes the speech-tag check already reported (r5.52: one P09 per quote)
    for left, right in rules["quote_pairs"][:1]:
        for match in re.finditer("[" + HAN + "]" + re.escape(right), text):
            opened = text.rfind(left, 0, match.start())
            if opened < 0 or "\n" in text[opened:match.start()] or (opened > 0 and is_han(text[opened - 1])):
                continue  # 把“船票”收好: a quoted term inside narration, not a spoken line
            gap = re.match(r"[ \t]*，?[ \t]*", text[match.end():match.end() + 6]).end()
            if (SPEECH_TAG.match(text[match.end():match.end() + 8]) if not gap
                    else SPEECH_TAG_AFTER_GAP.match(text[match.end() + gap:match.end() + gap + 12])):
                add("P09", "REVIEW", match.start(), match.end(),
                    "引号内末尾没有标点就接说话人；常见写法是“……。”他说。或“……，”他说。按项目约定确认。")
                p09_ends.add(match.end())
            elif not gap and re.fullmatch(r"[ \t　]*", text[text.rfind("\n", 0, opened) + 1:opened]) \
                    and actor_action.match(text[match.end():match.end() + 16]):
                add("P09", "REVIEW", match.start(), match.end(),
                    "段首的话后面直接接人物的动作，引号内末尾没有标点；常见写法是“……！”老冯一把拽住他。按项目约定确认。")
                p09_ends.add(match.end())
    # r5.52: a quotation standing as its own paragraph, or introduced by a colon and ending the paragraph, with no
    # end mark before the closing quote (looking through an inner quote that closes there). Decided by the layout of
    # the paragraph, never by how long the quotation is: a quoted term inside a sentence is not touched.
    left, right = (rules["quote_pairs"] or [["“", "”"]])[0]  # no quote pairs registered: the loop below finds nothing
    inner = "".join(pair[1] for pair in rules["quote_pairs"][1:]) + "’』」）》】〉〕"
    only_quotes = re.compile("[ \t　]*(?:" + re.escape(left) + "[^" + re.escape(left + right) + "]+" + re.escape(right) + ")+[ \t　]*")
    bare_quote = re.compile("[ \t　]*" + re.escape(left) + "[^" + re.escape(left + right) + "]+" + re.escape(right) + "[ \t　]*")

    def introduced_by_speech(index):
        """A standalone quotation: unless the paragraphs before it (past other bare quotations) end with a colon line
        that has no speech verb (刻着：, 列了三个词：), it is read as speech."""
        k = index - 1
        while k >= 0 and bare_quote.fullmatch(paragraphs[k][1]):
            k -= 1
        if k < 0:
            return True
        line = paragraphs[k][1].strip(" \t　")
        return not line.endswith(("：", ":")) or bool(SPEECH_WORD.search(re.split("[。！？，]", line)[-1]))

    for index, (start, para) in enumerate(paragraphs if rules["quote_pairs"] else []):
        for match in re.finditer(re.escape(left) + "([^" + re.escape(left + right) + "]+)" + re.escape(right), para):
            core = match.group(1).rstrip(inner)
            if not core or not (is_han(core[-1]) or (core[-1].isascii() and core[-1].isalnum())):
                continue
            before, after = para[:match.start()].strip(" \t　"), para[match.end():].strip(" \t　")
            if title_line(para):
                continue
            if not before and after.startswith(left) and only_quotes.fullmatch(para):
                add("P09", "REVIEW", start + match.end() - 2, start + match.end(),
                    "段首的话后面紧接着下一句引号，前一句后引号前没有句末标点；是两个人的对白就补上标点，"
                    "是并列的词语（“雾镇”“白线”）就不用改。")
                continue
            if not after and before.endswith(("，", "。", "！", "？", "…")):
                add("P09", "REVIEW", start + match.end() - 2, start + match.end(),
                    "段末的话（前面是逗号或一句叙述），后引号前没有句末标点；按语气补上“。”“！”“？”“……”等。")
                continue
            if after and CONTINUES.match(after) and (not before or before.endswith(("，", "：", ":"))):
                lead = re.split("[。！？，]", before[:-1] if before else "")[-1].strip(" \t　")
                spoken = core[-1] in "吧吗呢啊呀嘛" or (not before and len(core) > 1 and core[0] in "我你您咱俺"
                                                         and not after[len(CONTINUES.match(after).group(0)):].startswith("是"))
                if (SPEECH_WORD.search(lead) or spoken) and start + match.end() not in p09_ends:
                    add("P09", "REVIEW", start + match.end() - 2, start + match.end(),  # r5.52 (from the author's v3.3.1)
                        "说的话后面接着叙述（随后、接着……），后引号前没有句末标点；按语气在引号里补上“。”“！”“？”。")
                continue  # 他低声说，“我和你”是书名、“雾镇”随后成了禁区: a quoted name inside the sentence
            if after or (before and not before.endswith(("：", ":"))):
                continue
            lead = re.split("[。！？，]", before)[-1].strip(" \t　")
            if before and not SPEECH_WORD.search(lead) and not person_first.match(lead):
                continue  # 称号：“新手村的希望”、口令：“天王盖地虎”: a field or a label (他心里只有一个念头：“活下去” is a sentence)
            if not before and not introduced_by_speech(index):
                continue  # 刻着：⏎“赠文涛兄，远”、列了三个词：⏎“雾镇”⏎“白线”: an inscription or a list
            add("P09", "REVIEW", start + match.end() - 2, start + match.end(),
                "单独成段（或由冒号引出、放在段末）的话，后引号前没有句末标点；说的话按语气补在引号里（“。”“！”“？”“……”），"
                "引的词语、标题、刻字就在引号外补句号（……的题目：“雾港”。）。")

    # P14 (r5.52) a tag standing as its own paragraph with a mark after it, and spaces between adjacent tags.
    if rules["tag_layout"] == "review":
        for left, right in rules["tag_brackets"]:
            tag = re.escape(left) + "[^" + re.escape(left + right) + "\n]{1,40}" + re.escape(right)
            line_form = re.compile(r"[ \t　]*(?:" + tag + r"[ \t]*)+([。，、；！？]+)[ \t　]*")
            for start, para in paragraphs:
                found = line_form.fullmatch(para)
                if found:
                    first = len(para) - len(para.lstrip(" \t　"))
                    add("P14", "REVIEW", start + first, start + found.end(1),
                        "单独成段的标签后面带了“%s”。能力名、系统提示单独成段时一般不加括号外标点（如%s定%s），"
                        "按作品约定全书统一；作品确认要加的，在规则里写 \"tag_layout\": \"allow\"。"
                        % (found.group(1), left, right), at=range(start + found.start(1), start + found.end(1)))
                for match in re.finditer("(?=(" + tag + ")([ \t]+)(" + tag + "))", para):
                    add("P14", "REVIEW", start + match.end(1) - 1, start + match.end(3),
                        "相邻两个标签之间有半角空格；紧挨着写，或分成两段。", at=range(start + match.start(2), start + match.end(2)))

    # P10 chains of very short narrative sentences inside one paragraph.
    limit, run = rules["short_chain"]["max_chars"], rules["short_chain"]["min_run"]
    quote_open = "".join(pair[0] for pair in rules["quote_pairs"])
    quote_close = "".join(pair[1] for pair in rules["quote_pairs"])
    for start, para in paragraphs:
        masked, depth = [], 0
        for char in para:
            if char in quote_open:
                depth += 1
            # Quoted speech and terms are masked with a non-Han placeholder so
            # their inner full stops do not split or shorten narrative sentences.
            masked.append("Q" if depth else char)
            if char in quote_close and depth:
                depth -= 1
        narrative = "".join(masked)
        chain = []
        for sentence in re.finditer("[^" + TERMINALS + "]+[" + TERMINALS + "]+", narrative):
            size = han_count(sentence.group(0))
            if 0 < size <= limit:
                chain.append(sentence)
                continue
            if len(chain) >= run:
                add("P10", "REVIEW", start + chain[0].start(), start + chain[-1].end(),
                    "连续%d个不超过%d字的叙述短句。检查是否把同一动作的条件—动作—结果切碎；有节奏作用可保留并写明理由。" % (len(chain), limit))
            chain = []
        if len(chain) >= run:
            add("P10", "REVIEW", start + chain[0].start(), start + chain[-1].end(),
                "连续%d个不超过%d字的叙述短句。检查是否把同一动作的条件—动作—结果切碎；有节奏作用可保留并写明理由。" % (len(chain), limit))

    # P11 runs of short one-line paragraphs. Dialogue lines, headings and lines that open with a tag
    # bracket or a registered panel prefix (an ability call-out, a system notice) are deliberate beats:
    # they are not counted and they end a run.
    limit, run = rules["short_paragraph_run"]["max_chars"], rules["short_paragraph_run"]["min_run"]
    streak = []

    def flush():
        if len(streak) >= run:
            first, last = streak[0], streak[-1]
            add("P11", "REVIEW", first[0], last[0] + len(last[1]),
                "连续%d个不超过%d字的单行段落。确认每次分段都有停顿、冲击或视线切换的作用。" % (len(streak), limit))

    for start, para in paragraphs:
        body = para.strip()
        dialogue = any(char in quote_open for char in body)  # rapid exchanges are not narrative chopping
        heading = title_line(body)
        tag_line = (any(body.startswith(pair[0]) for pair in rules["tag_brackets"])
                    or any(body.startswith(prefix) for prefix in rules["panel_prefixes"]))
        if not dialogue and not heading and not tag_line and 0 < han_count(body) <= limit:
            streak.append((start, para))
        else:
            flush()
            streak = []
    flush()

    # P12 reader load of one paragraph: a long stretch of narration, or several registered
    # people acting in one paragraph. A hint about where to re-read, never a length limit.
    dense = rules["dense_paragraph"]
    people = [[entry] if isinstance(entry, str) else entry for entry in rules["characters"]]
    for start, para in paragraphs:
        body = para.strip()
        if title_line(body):
            continue
        masked, depth = [], 0
        for char in para:
            if char in quote_open:
                depth += 1
            masked.append("Q" if depth else char)
            if char in quote_close and depth:
                depth -= 1
        narrative = "".join(masked)
        size = han_count(narrative)
        clauses = sum(1 for s in re.split("[" + TERMINALS + "，；]+", narrative) if han_count(s))
        reasons = []
        if size > dense["max_chars"]:
            reasons.append("这一段叙述有%d个汉字（复核线 %d）" % (size, dense["max_chars"]))
        present = [names[0] for names in people if any(name in para for name in names)]
        if len(present) >= dense["max_people"] and clauses >= dense["min_clauses"]:
            reasons.append("一段里有%d个人物（%s）、%d个分句" % (len(present), "、".join(present), clauses))
        if reasons:
            offset = len(para) - len(para.lstrip())
            add("P12", "REVIEW", start + offset, start + offset + min(24, len(body)),
                "；".join(reasons) + "。检查动作主体、观察焦点和信息是否挤在一段里，手机上读起来负担重不重。"
                "需要时在主体或焦点转换处分段；不按字数机械切分，也不要拆成一串单行短段。")

    # P13 one stretch of speech, possibly across paragraphs, with no action or reply in between.
    speech = rules["long_speech"]
    for left, right in rules["quote_pairs"][:1]:
        for match in re.finditer(re.escape(left) + "[^" + re.escape(right) + "]*" + re.escape(right), text):
            spoken = match.group(0)
            later = [line.lstrip(" \t　") for line in spoken.split("\n")[1:]]
            if not dialogue_soft_wrap:
                if any(line.strip() and not line.startswith(left) for line in later):
                    continue  # an unclosed quote (P01), not one speech continued across paragraphs
            else:
                # Soft wraps: a line that does not reopen the quote must follow the previous line directly.
                after_blank, broken = False, False
                for line in later:
                    if not line.strip():
                        after_blank = True
                        continue
                    if after_blank and not line.startswith(left):
                        broken = True
                        break
                    after_blank = False
                if broken:
                    continue
            size = han_count(spoken)
            sentences = sum(1 for s in re.split("[" + TERMINALS + "]+", spoken) if han_count(s))
            if size > speech["max_chars"] and sentences >= speech["min_sentences"]:
                add("P13", "REVIEW", match.start(), match.start() + min(24, len(spoken)),
                    "一段连续发言%d个汉字、%d句，中间没有动作、停顿或对方的反应（复核线 %d 字）。检查信息是否一次给得太多；"
                    "需要时用动作、对方反应或分段把信息分层。同一段发言可以有多个完整句子，"
                    "不要为了换行改标点或句意。" % (size, sentences, speech["max_chars"]))

    prose_only = "".join(" " if shield[k] and text[k] != "\n" and code_blocks[k] else text[k] for k in range(len(text)))

    # Exemptions are exact: rule, line and matched text must all agree.
    findings.sort(key=lambda f: (f["line"], f["column"], f["rule"]))
    active, suppressed, used = [], [], set()
    for finding in findings:
        hits = [i for i, item in enumerate(rules["ignore"])
                if item["rule"] == finding["rule"] and item["line"] == finding["line"] and item["text"] == finding["match"]
                and item.get("column", finding["column"]) == finding["column"]]
        if hits:
            used.update(hits)
            suppressed.append(dict(finding, reasons=[rules["ignore"][i]["reason"] for i in hits]))
        else:
            active.append(finding)
    errors = sum(f["severity"] == "ERROR" for f in active)
    reviews = sum(f["severity"] == "REVIEW" for f in active)
    assign_ids(active, lambda f: "%s-L%d-C%d" % (f["rule"], f["line"], f["column"]))
    return {
        "tool": "punctuation_lint", "version": VERSION, "dialogue_soft_wrap": dialogue_soft_wrap, "settings": settings_of(rules),
        "status": "ERRORS" if errors else "REVIEW" if reviews else "NO_FLAGS",
        "counts": {"ERROR": errors, "REVIEW": reviews},
        "findings": active, "suppressed": suppressed,
        "unused_ignores": [item for i, item in enumerate(rules["ignore"]) if i not in used],
        "skipped_spans": sorted(skipped, key=lambda span: (span["line"], span["column"])),
        "stats": dict(statistics(prose_only, rules), skipped_spans=len(skipped)),
        "limits": ("只检查客观格式与可定位的复核线索；REVIEW 必须由编辑逐条裁决，不能自动改句号为逗号。"
                   "代码、网址和作品登记的原样面板（raw_brackets）里的文字不检查格式，列在 skipped_spans。"
                   "统计只作同口径对照，没有通用合格比例；NO_FLAGS 不代表文笔或标点用法全部正确。"),
    }


def settings_of(rules):
    """What the run used (r5.52): the preset named and the fields it set, after the rules file and --profile."""
    return {"profile": rules["profile"], "stacked_mark_limit": rules["stacked_mark_limit"], "tag_layout": rules["tag_layout"],
            "continued_quotes": rules["continued_quotes"], "raw_brackets": rules["raw_brackets"]}


def statistics(text, rules):
    body = "\n".join(line for line in text.splitlines() if not line.lstrip().startswith("#"))
    marks = {mark: body.count(mark) for mark in "。，、；：！？“”"}
    marks["……"] = body.count("……")
    marks["——"] = body.count("——")
    sentences = [s for s in re.split("[" + TERMINALS + "]+", body) if han_count(s)]
    paragraphs = [p for p in body.splitlines() if p.strip()]
    single = [p for p in paragraphs if len(re.findall("[" + TERMINALS + "]+", p.strip())) <= 1]
    han = han_count(body)
    return {
        "basis": "汉字=CJK统一汉字；标题行(# 开头)不计；句=按。！？切分且含汉字的片段；段=非空物理行",
        "han_characters": han, "marks": marks,
        "period_per_comma": round(marks["。"] / marks["，"], 3) if marks["，"] else None,
        "sentences": len(sentences),
        "mean_han_per_sentence": round(han / len(sentences), 2) if sentences else None,
        "paragraphs": len(paragraphs),
        "single_sentence_paragraph_share": round(len(single) / len(paragraphs), 3) if paragraphs else None,
    }


END_MARKS = re.compile("[。！？…]+")


def utterances(text, rules):
    """Quoted speech in reading order, one piece per physical line: letters-only key, end marks (and where they are),
    content, line and column. A quotation that runs over several lines -- each paragraph reopened with an opening quote,
    or lines soft-wrapped inside one quotation -- gives one piece per line, so a changed mark in its middle is seen too.
    A blank line ends a quotation that was left open."""
    if not rules["quote_pairs"]:
        return []
    left, right = rules["quote_pairs"][0]
    found, inside, offset = [], False, 0
    for number, line in enumerate(text.split("\n"), 1):
        if not line.strip():
            inside = False
        start = 0 if inside else None
        for k, char in enumerate(line):
            if char == left and start is None:
                start = k
            elif char == right and start is not None:
                found.append(speech_piece(text, offset, line, number, start, k + 1, left, right))
                start = None
        if start is not None and start < len(line):
            found.append(speech_piece(text, offset, line, number, start, len(line), left, right))
        inside = start is not None
        offset += len(line) + 1
    return found


def speech_piece(text, offset, line, number, start, end, left, right):
    piece = line[start:end]
    runs = [(offset + start + m.start(), offset + start + m.end()) for m in END_MARKS.finditer(piece)]
    content = piece[1:] if piece.startswith(left) else piece
    content = content[:-1] if content.endswith(right) else content
    return {"key": re.sub("[^" + HAN + "0-9A-Za-z]", "", piece), "content": content, "runs": runs,
            "marks": "".join(text[a:b] for a, b in runs), "line": number, "column": start + 1, "span": (start, end)}


def line_skeletons(text, found):
    """Physical lines with the end marks inside quoted speech left out, so that two versions of a line that differ
    only in those marks (including a mark added or dropped) compare equal."""
    chars = list(text)
    for item in found:
        for a, b in item["runs"]:
            chars[a:b] = [""] * (b - a)
    return "".join(chars).split("\n")


def ends_with_colon(line):
    return line.rstrip().endswith(("：", ":"))


def line_identities(text, found, skeletons):
    """What identifies each physical line when the two versions are matched (r5.3 and r5.5, review N04).

    A line that holds nothing but quoted speech does not say who speaks; the speaker is usually named on a line above
    it. Such a line is identified as follows, so that the same words said by different people stay apart when
    paragraphs move:
    - A line that ends with a colon ("陈青低声说：") introduces what follows it. It identifies the speech below it,
      directly below or after blank lines, and nothing else is needed. It never identifies the speech above it: there
      it is the next speaker's line.
    - Otherwise the nonblank line directly above identifies it (when that line is more than speech), together with the
      nonblank line directly below when that one is there too (no blank lines around: both must match).
    - The line below alone is not used. It may name this speaker ("陈青低声说。") or begin the next paragraph (the next
      speaker's line), and the program cannot tell which. Nor, alone, is a line above that directly follows another
      line with speech: it may close that speech rather than open this one.
    A speech-only line identified in none of these ways gets a key marked "words": it is told apart by its words and
    by where it stands, never by the key alone (it is no anchor and is never paired as "the same line" just because the
    key occurs once). Any other line is identified by its own text without end marks, as before. Returns the keys,
    per line whether it is such a speech-only line, and per line the row of the line that names it (None when nothing
    names it: other lines, and speech known by its words only)."""
    lines = text.split("\n")
    spans = {}
    for item in found:
        spans.setdefault(item["line"] - 1, []).append(item["span"])
    speech_only = []
    for i in range(len(skeletons)):
        outside = list(lines[i])
        for a, b in spans.get(i, []):
            outside[a:b] = [""] * (b - a)
        speech_only.append(i in spans and not re.search("[" + HAN + "0-9A-Za-z]", "".join(outside)))

    def nonblank(k):
        return 0 <= k < len(lines) and bool(lines[k].strip())

    keys, namers = [], []
    for i, skeleton in enumerate(skeletons):
        if not speech_only[i]:
            keys.append(skeleton)
            namers.append(None)
            continue
        if not nonblank(i - 1):
            nearest = next((k for k in range(i - 1, -1, -1) if lines[k].strip()), None)
            if nearest is not None and not speech_only[nearest] and ends_with_colon(lines[nearest]):
                keys.append(("speech", skeletons[nearest], skeleton, None))
                namers.append(nearest)
            else:
                keys.append(("words", None, skeleton, None))
                namers.append(None)
            continue
        above = i - 1
        if ends_with_colon(lines[above]):
            keys.append(("speech", skeletons[above], skeleton, None))
            namers.append(above)
            continue
        below = i + 1 if nonblank(i + 1) and not ends_with_colon(lines[i + 1]) else None
        # The line above names nobody for sure when it is speech itself, or when, alone, it directly follows a line
        # with speech (it may close that speech).
        unsure = speech_only[above] or (below is None and nonblank(above - 1) and (above - 1) in spans)
        keys.append(("words" if unsure else "speech", skeletons[above], skeleton,
                     skeletons[below] if below is not None else None))
        namers.append(None if unsure else above)
    return keys, speech_only, namers


def blank_key(key):
    return isinstance(key, str) and not key.strip()


SENTENCES = re.compile("[^。！？；…]*[。！？；…]+")
SPEECH_VERB = re.compile("(?:说|问|道|喊|答|叫|嚷|嘟囔|应)(?:了|着)?$")


def letters(text):
    return re.sub("[^" + HAN + "0-9A-Za-z]", "", text)


def attributions(line, spans):
    """The narration that belongs to each quote of one physical line, letters only (r5.10, review of r5.9).

    Taking every letter outside the quotes gave the quotes of one line one narration ("岳宁说：“走吧？”方澈说：“走吧。”":
    "岳宁说方澈说" for both), so when the line was split in two and the two people traded places, nothing told them
    apart and the fallback paired them in order. Now the text in front of the first quote goes with it, the text after
    the last quote with that one, and the text between two quotes is shared out:
    - when the quote before it was introduced by a colon ("岳宁说：“…”"), all of it leads into the next quote;
    - otherwise a first sentence that is a speech tag ("岳宁低声说。") closes the quote before it, and the rest leads into
      the next one ("方澈说：", "方澈点了点头。");
    - a first sentence that is no tag leads into the next quote when the quote before it has narration in front of it
      already ("岳宁点了点头。“…”方澈点了点头。“…”"); with nothing in front of that quote ("“…”岳宁笑了笑。“…”") it may
      close it or open the next one, and both get it; so does a clause ending in a comma with nothing before it
      ("“走吧，”岳宁说，“我们走。”": one speaker).
    A quote left with no letters of its own (two quotes in a row) gets the letters of the whole line, as before."""
    spans = sorted(spans)
    front, back = [line[:spans[0][0]]] + [""] * (len(spans) - 1), [""] * (len(spans) - 1) + [line[spans[-1][1]:]]
    for k in range(len(spans) - 1):
        gap = line[spans[k][1]:spans[k + 1][0]]
        if front[k].rstrip().endswith(("：", ":")):
            front[k + 1] = gap
            continue
        sentences = SENTENCES.findall(gap)
        rest = gap[len("".join(sentences)):]
        if not sentences:
            back[k], front[k + 1] = (rest, rest) if rest.rstrip().endswith(("，", ",")) else ("", rest)
        elif SPEECH_VERB.search(letters(sentences[0])):
            back[k], front[k + 1] = sentences[0], gap[len(sentences[0]):]
        elif letters(front[k]):
            front[k + 1] = gap  # the quote before has narration in front of it already ("甲点了点头。“…”")
        else:
            back[k], front[k + 1] = sentences[0], gap
    outside = list(line)
    for a, b in spans:
        outside[a:b] = [""] * (b - a)
    whole = letters("".join(outside))
    return [letters(front[k] + back[k]) or whole for k in range(len(spans))]


def by_context(olds, news):
    """Pair two equally long lists of same-word utterances by how alike their lines are (ties: nearest in order).

    Lines are compared by their narration -- the letters outside the quotes -- when they have any (r5.9, review of r5.8):
    whole lines are most alike by layout, so "罗峻低声说：“走吧”" looked more like "许平低声说：“走吧”" (0.8) than like
    "“走吧”罗峻低声说。" (0.5), and the fallback agreed with an order that paired two people's words."""
    ranked = []
    for p, old in enumerate(olds):
        for q, new in enumerate(news):
            ratio = SequenceMatcher(None, old.get("narration") or old["context"], new.get("narration") or new["context"],
                                    autojunk=False).ratio()
            ranked.append((-ratio, abs(p - q), p, q))
    ranked.sort()
    chosen, used = {}, set()
    for _, _, p, q in ranked:
        if p not in chosen and q not in used:
            chosen[p] = q
            used.add(q)
    return [chosen[p] for p in range(len(olds))]


def by_narration(olds, news, spare):
    """Pairs of same-word utterances told apart by their own narration (r5.10, review of r5.9): a narration found once
    among the original utterances and once among the revised ones pairs those two -- the same speaker, however the
    lines were split, merged or moved ("岳宁说：“走吧？”方澈说：“走吧。”" against "方澈说：“走吧？”" / "岳宁说：“走吧。”").
    When that leaves one utterance on each side, the last two pair as well (one on each side pairs directly, as
    everywhere) unless spare(x, y) says no -- a line of nothing but these words whose words another such line says too
    (which of them is which is not in the text). Returns all pairs, or None when any utterance is left otherwise; the
    order is then weighed as before."""
    count_a = Counter(x["narration"] for x in olds)
    count_b = Counter(y["narration"] for y in news)
    sure = [(x, y) for x in olds for y in news if x["narration"] and x["narration"] == y["narration"]
            and count_a[x["narration"]] == 1 and count_b[y["narration"]] == 1]
    left_a = [x for x in olds if all(x is not p for p, _ in sure)]
    left_b = [y for y in news if all(y is not q for _, q in sure)]
    if not sure or len(left_a) > 1 or (left_a and not spare(left_a[0], left_b[0])):
        return None
    return sure + list(zip(left_a, left_b))


LETTER_RUNS = re.compile("[" + HAN + "0-9A-Za-z]+")


def moved_text(old, new, others_a, others_b):
    """Text that moved between lines, seen from the change of one line from `old` to `new`: whether some text that left
    `old` stands in a line of `others_b` (the revision), and whether some text that came into `new` stands in a line of
    `others_a` (the original). Text counts as a changed run of letters, or any two letters in a row of a longer run,
    because a name runs together with reworded words ("秦照低声说。" -> "黎渔压低嗓子说。": “黎渔压” is one run). Single
    letters of a longer run do not count -- they would match common words everywhere."""
    gone, came = [], []
    for tag, a1, a2, b1, b2 in SequenceMatcher(None, old, new, autojunk=False).get_opcodes():
        if tag in ("replace", "delete"):
            gone += LETTER_RUNS.findall(old[a1:a2])
        if tag in ("replace", "insert"):
            came += LETTER_RUNS.findall(new[b1:b2])

    def stands(parts, lines):
        lines = list(lines)
        for part in parts:
            pieces = [part] + [part[k:k + 2] for k in range(len(part) - 1)] if len(part) > 2 else [part]
            if any(piece in line for piece in pieces for line in lines):
                return True
        return False

    return stands(gone, others_b), stands(came, others_a)


def exchanged(old, new, others_a, others_b):
    """Whether the change of a line from `old` to `new` is explained by text moving between changed lines (moved_text),
    from either side. r5.8, review of r5.6: "秦照低声说。" -> "黎渔低声说。" while "黎渔低声说：“…”" -> "秦照低声说：“…”"
    is two people trading places, not one line reworded in place. One side is enough: the person who left may be gone
    from the revision, or the one who came may have been named nowhere in the original. A one-letter name run together
    with reworded words still passes as a rewrite when the person who left is nowhere else."""
    gone, came = moved_text(old, new, others_a, others_b)
    return gone or came


def traded(olds, news):
    """Whether pairing the same words in order (olds[k] with news[k]) puts two people's lines together: in some pair,
    text that left the original line's narration stands in the narration of another line of the group in the revision,
    AND text that came into the revised line stood in another line of the group in the original (r5.9, review of r5.8:
    "罗峻低声说：“走吧？”" and "“走吧。”许平低声说。" traded places, each place keeping its layout, and a verb that
    belongs to the place -- "压低嗓子说" -- can still make the wrong lines the most alike). Both halves are needed here,
    unlike in exchanged: the speaker lines of the same words share their verbs ("低声说"), and one shared letter would undo
    every order in which two speaker lines were reworded where they stand; by_context, which compares the narration,
    already refuses the orders that only one half would show."""
    for k, (old, new) in enumerate(zip(olds, news)):
        others_a = [x["narration"] for n, x in enumerate(olds) if n != k]
        others_b = [y["narration"] for n, y in enumerate(news) if n != k]
        gone, came = moved_text(old["narration"], new["narration"], others_a, others_b)
        if gone and came:
            return True
    return False


def rewritten_in_place(opcodes, keys_a, keys_b, lines_a, lines_b, limit=90000):
    """Replaced lines taken as rewritten in place, original row -> revised row (r5.5, review of r5.4: any replaced run
    of the same length was taken as rewritten in place, so a speaker line that had moved seemed to be the rewrite of
    the one now in its slot).

    A line of a replaced run of the same length is the rewrite of the line in its slot only when nothing else explains
    the change: its old text is gone from the revision, its new text was not in the original, and the two are more
    alike than either is to any other line that changed. A tie explains nothing (r5.6, review of r5.5): speaker lines
    that differ only in the name ("乙低声说：", "丁低声说：", "乙低声说。") or repeated words look just as much like
    several lines, and taking the one in the slot paired one person's words with another's. Nor does text that moved
    (r5.8, review of r5.6; exchanged): when what the line lost now stands in another changed line, or what it gained
    came from one, people traded places and each place kept its layout, and the words next to the line are another
    person's now. A moved speaker line fails the first test; a moved and reworded one usually fails the third. Lines
    merged into one fail the last test too (what came in stood on its own line before). With more than `limit` pairs
    of changed lines to weigh, no line is taken as rewritten (the comparison then flags more, it never passes more)."""
    rewritten = {}
    in_a, in_b = set(keys_a), set(keys_b)
    changed_a = [i for tag, i1, i2, _, _ in opcodes if tag != "equal"
                 for i in range(i1, i2) if not blank_key(keys_a[i])]
    changed_b = [j for tag, _, _, j1, j2 in opcodes if tag != "equal"
                 for j in range(j1, j2) if not blank_key(keys_b[j])]
    weigh = len(changed_a) * len(changed_b) <= limit

    def closer(fixed, others, score, fixed_first):
        for other in others:
            matcher = SequenceMatcher(None, fixed, other, autojunk=False) if fixed_first else \
                SequenceMatcher(None, other, fixed, autojunk=False)
            if matcher.real_quick_ratio() >= score and matcher.quick_ratio() >= score and matcher.ratio() >= score:
                return True
        return False

    for tag, i1, i2, j1, j2 in opcodes:
        if tag != "replace" or i2 - i1 != j2 - j1 or not weigh:
            continue
        for i, j in zip(range(i1, i2), range(j1, j2)):
            if blank_key(keys_a[i]) or blank_key(keys_b[j]) or keys_a[i] in in_b or keys_b[j] in in_a:
                continue
            score = SequenceMatcher(None, lines_a[i], lines_b[j], autojunk=False).ratio()
            if closer(lines_a[i], (lines_b[q] for q in changed_b if q != j), score, True) or \
                    closer(lines_b[j], (lines_a[p] for p in changed_a if p != i), score, False):
                continue
            if exchanged(lines_a[i], lines_b[j], (lines_a[p] for p in changed_a if p != i),
                         (lines_b[q] for q in changed_b if q != j)):
                continue
            rewritten[i] = j
    return rewritten


def match_utterances(original, revised, rules):
    """Match the dialogue of two versions one to one (r5.2, review N01: a repeated line could hide a changed mark;
    r5.3, review N04: the same words said by different people were paired across speakers when paragraphs moved;
    r5.5, review of r5.4: the same when a blank line stands between the speaker line and the words; r5.6, review of
    r5.5: the same when the speaker lines moved from above the words to below them; r5.8, review of r5.6: the same
    when speech written inline is mixed with speaker lines and two people trade places, each place keeping its layout;
    r5.9, review of r5.8: the same when both speakers are named on the line of the words, one in front, one after;
    r5.10, review of r5.9: the same when two people speak on one line and the revision splits it, or merges two lines
    into one, and they trade places).

    Every line has an identity (line_identities): its own text without end marks; for a line that holds nothing but
    quoted speech, the line that names its speaker (a colon line above it, across blank lines too) or else the line of
    narration directly above it. A speech-only line named in none of these ways is known by its words only ("words"
    keys): such a key is no anchor and pairs nothing by itself, unless each of its quotes is said exactly once in each
    version, counting every utterance -- inline speech and every quote of a line holding several (r5.8).
    1. Identities are aligned with their neighbours. An equal run is anchored when it contains an identity that occurs
       exactly once in each version. A line of an anchored run pairs in place ("same_line") when an anchor of the run
       (or the start of both texts) is above it and one (or the end of both texts) below it. Repeated lines line up
       with an offset just as well as in place -- N04's “知道了” of two different people did exactly that -- so
       whatever is not fenced in like this is left for the next steps.
    2. Lines left over with the same identity on both sides pair when it occurs once on each side ("moved_line", or
       "same_line" when it still stands between the same lines), and so do copies of one line whose marks are all the
       same (no pairing among them can show a change). Every other line left over pairs only by place: the same words
       between lines that correspond to the lines around it in the original, and named the same way in both versions
       -- by lines that correspond, or by no line at all (r5.6: when speaker lines move to the other side of the words,
       the same place holds another person's words). Lines correspond when one is an anchor and the other its
       namesake, when both are fenced in place in an anchored run, or when one is the other rewritten in place
       (rewritten_in_place); a pair that rests on such an assumed rewrite is marked "in_place". Such a pair is not
       taken for words said a different number of times in the two versions (r5.9): one of those lines is new or gone,
       and it may be the very line taken as rewritten -- a speaker line given another name may be someone else's words
       moved in, the first speaker's line cut -- so a changed mark would vanish without a word.
       Marks that read the same in order prove nothing: r5.4 took them as evidence, and a swap of two people with
       changed marks passed unreported.
    3. The remaining utterances pair by their words: one on each side pairs directly; equally many on each side pair
       in order when pairing by the most alike lines gives the same result ("changed_line"). Not for speech-only
       lines: their own text is the same words, so "most alike" would only be position again. Lines are compared by
       their narration, the letters outside the quotes, so the layout ("罗峻低声说：“…”" or "“…”罗峻低声说。") does not
       outweigh the speaker; and an order in which people traded lines (traded) is not taken (r5.9). Each quote has
       a narration of its own when a line holds several (attributions), and before any order is weighed, a narration
       found once on each side pairs those words, the last ones left pairing by elimination (by_narration; r5.10):
       one narration for the whole line made two people on it indistinguishable once the line was split.
    4. Everything else with the same words but different marks cannot be paired reliably: those revised utterances
       are returned as uncertain, never taken as unchanged, with the reason -- the count changed ("count_changed"),
       the two ways of pairing disagree ("order_unclear"), the order would pair lines whose speakers traded places
       ("crossed"), the lines and their neighbours do not tell the speakers apart ("indistinct"), two quotes of one
       line have one narration ("same_narration": none of their own, so the whole line's, while the narration
       elsewhere differs -- when every narration is the same, one person speaks throughout; r5.10), or there are too
       many repeats to pair ("too_many").
    """
    olds, news = utterances(original, rules), utterances(revised, rules)
    lines_a, lines_b = line_skeletons(original, olds), line_skeletons(revised, news)
    keys_a, alone_a, named_a = line_identities(original, olds, lines_a)
    keys_b, alone_b, named_b = line_identities(revised, news, lines_b)
    by_a, by_b = {}, {}
    for items, keys, alone, by in ((olds, keys_a, alone_a, by_a), (news, keys_b, alone_b, by_b)):
        for item in items:
            row = item["line"] - 1
            key = keys[row]
            item["context"] = "\n".join(part for part in key[1:] if part is not None) if isinstance(key, tuple) else key
            item["alone"] = alone[row]
            by.setdefault(row, []).append(item)
    # The narration of each utterance: the letters outside the quotes that belong to it (r5.9: who speaks is in there,
    # wherever the quote stands; the layout is not). A line holding several quotes shares its narration out among them
    # (r5.10, attributions): one narration for all made two people on one line indistinguishable.
    for items, text in ((olds, original), (news, revised)):
        rows = text.split("\n")
        on_line = {}
        for item in items:
            on_line.setdefault(item["line"], []).append(item)
        for number, here in on_line.items():
            here.sort(key=lambda item: item["span"])
            for item, narration in zip(here, attributions(rows[number - 1], [item["span"] for item in here])):
                item["narration"] = narration
    count_a, count_b = Counter(keys_a), Counter(keys_b)
    # How often each set of words is said, counted over every utterance: inline speech ("黎渔低声说：“知道了？”") and
    # every quote of a line holding several count too (r5.8, review of r5.6: counting speech-only lines alone took
    # “知道了” for unique although 黎渔 said it inline, and paired 秦照's words with 黎渔's).
    said_a = Counter(item["key"] for item in olds)
    said_b = Counter(item["key"] for item in news)
    spoken = {}
    for keys, by in ((keys_a, by_a), (keys_b, by_b)):
        for row, items in by.items():
            if isinstance(keys[row], tuple):
                spoken[keys[row][2]] = tuple(item["key"] for item in items)

    def identifying(key):
        """Whether a key can stand for one line: any line's own text, a speech named by the line above it, and a speech
        known only by its words when each of its quotes is said exactly once in each version, anywhere."""
        if blank_key(key):
            return False
        if not (isinstance(key, tuple) and key[0] == "words"):
            return True
        words = spoken.get(key[2], ())
        return bool(words) and all(w and said_a[w] == 1 and said_b[w] == 1 for w in words)

    def anchor(key):
        return identifying(key) and count_a[key] == 1 and count_b[key] == 1

    def neighbours(keys):
        """Nearest nonblank line above and below each line (None at the edges of the text)."""
        up, down, last = [None] * len(keys), [None] * len(keys), None
        for i, key in enumerate(keys):
            up[i], last = last, (i if not blank_key(key) else last)
        last = None
        for i in range(len(keys) - 1, -1, -1):
            down[i], last = last, (i if not blank_key(keys[i]) else last)
        return up, down

    up, down = neighbours(keys_a)
    up_b, down_b = neighbours(keys_b)
    opcodes = SequenceMatcher(None, keys_a, keys_b, autojunk=False).get_opcodes()
    runs = {}
    for tag, i1, i2, j1, j2 in opcodes:
        pins = [i for i in range(i1, i2) if anchor(keys_a[i])] if tag == "equal" else []
        if pins:
            runs[i1] = (i1, i2, j1, j2, pins)
    first_a = next((i for i, key in enumerate(keys_a) if not blank_key(key)), len(keys_a))
    first_b = next((j for j, key in enumerate(keys_b) if not blank_key(key)), len(keys_b))
    last_a = max((i for i, key in enumerate(keys_a) if not blank_key(key)), default=-1)
    last_b = max((j for j, key in enumerate(keys_b) if not blank_key(key)), default=-1)

    def held(i, run):
        """A line of an anchored equal run stays in place when it is fenced in within the run: an anchor of the run (or
        the start of both texts) above it, and one (or the end of both texts) below it. Otherwise the run may have slid
        over a moved paragraph -- repeated lines line up with an offset just as well -- pairing one person's words
        with another's (r5.3; r5.5: the fence must be an anchor, not just any line of the run)."""
        i1, i2, j1, j2, pins = run
        above = pins[0] <= i or (first_a >= i1 and first_b >= j1)
        below = pins[-1] >= i or (last_a < i2 and last_b < j2)
        return above and below

    # Which revised line each original line reliably stands for: an anchor wherever it now is, a line held in an
    # anchored run, a line rewritten in place. Nothing else counts as "the same place" (r5.5: equal runs of repeated
    # lines and replaced runs of the same length can line up by coincidence).
    rewritten = rewritten_in_place(opcodes, keys_a, keys_b, lines_a, lines_b)
    where = dict(rewritten)
    anchors_b = {key: j for j, key in enumerate(keys_b) if anchor(key)}
    where.update((i, anchors_b[key]) for i, key in enumerate(keys_a) if anchor(key))
    for run in runs.values():
        i1, i2, j1 = run[:3]
        for i in range(i1, i2):
            if not blank_key(keys_a[i]) and held(i, run):
                where.setdefault(i, j1 + i - i1)

    def same_surroundings(i, j):
        return all((p is None and q is None) or (p is not None and where.get(p) == q)
                   for p, q in ((up[i], up_b[j]), (down[i], down_b[j])))

    def placed(i):
        """How a pair that stands between corresponding lines got there: "same_line", or "in_place" when one of those
        lines is an assumed rewrite."""
        return "in_place" if any(p in rewritten for p in (up[i], down[i])) else "same_line"

    pairs, loose_a, loose_b = [], [], []
    for tag, i1, i2, j1, j2 in opcodes:
        anchored = tag == "equal" and i1 in runs
        for offset in range(i2 - i1) if anchored else ():
            i, j = i1 + offset, j1 + offset
            if i not in by_a:
                continue
            if held(i, runs[i1]):
                pairs.extend((x, y, "same_line") for x, y in zip(by_a[i], by_b.get(j, [])))
            else:
                loose_a.append(i)
                loose_b.extend([j] if j in by_b else [])
        if not anchored:
            loose_a.extend(i for i in range(i1, i2) if i in by_a)
            loose_b.extend(j for j in range(j1, j2) if j in by_b)
    moved_a, moved_b = {}, {}
    for i in loose_a:
        moved_a.setdefault(keys_a[i], []).append(i)
    for j in loose_b:
        moved_b.setdefault(keys_b[j], []).append(j)
    used_a, used_b = set(), set()
    for key, rows_a in moved_a.items():
        rows_b = moved_b.get(key, [])
        # The same identity once on each side: the same line, moved or still in its place. Copies of one line (the same
        # identity several times on each side) whose marks are all the same: no pairing among them can show a change.
        marks = {tuple(x["marks"] for x in by[r]) for by, rows in ((by_a, rows_a), (by_b, rows_b)) for r in rows}
        if not identifying(key) or len(rows_a) != len(rows_b) or (len(rows_a) > 1 and len(marks) > 1):
            continue
        for i, j in zip(rows_a, rows_b):
            how = placed(i) if same_surroundings(i, j) else "moved_line"
            pairs.extend((x, y, how) for x, y in zip(by_a[i], by_b[j]))
            used_a.add(i)
            used_b.add(j)
    # Every other line left over pairs only by place: the same words between lines that correspond to the lines around
    # it in the original. Only one nonblank line can stand between two given lines, so this pairs one to one. Marks that
    # read the same in order prove nothing (r5.5: that once let a swap of two people with changed marks pass).
    # The words must also be named the same way in both versions: by lines that correspond, or by no line at all
    # (r5.6, review of r5.5). When the speaker lines move to the other side of the words ("孟迟低声说：" above becomes
    # "孟迟低声说。" below), the slot between two speaker lines holds the next person's words: same place, other speaker.
    def named_alike(i, j):
        p, q = named_a[i], named_b[j]
        return (p is None and q is None) or (p is not None and where.get(p) == q)

    slots = {(up_b[j], down_b[j]): j for j in loose_b if j not in used_b}
    for i in loose_a:
        if i in used_a or any(p is not None and p not in where for p in (up[i], down[i])):
            continue
        j = slots.get((where.get(up[i]), where.get(down[i])))
        if j is None or j in used_b or lines_a[i] != lines_b[j] or not named_alike(i, j):
            continue
        if placed(i) == "in_place" and any(said_a[x["key"]] != said_b[x["key"]] for x in by_a[i]):
            continue  # r5.9: an assumed rewrite next to words that are new or gone somewhere
        pairs.extend((x, y, placed(i)) for x, y in zip(by_a[i], by_b[j]))
        used_a.add(i)
        used_b.add(j)
    # Lines of nothing but quoted words, counted per words: when another such line says the same words, nothing in
    # the text tells which is which, and none of them pairs by elimination (by_narration).
    lone_a = Counter(item["key"] for item in olds if item["alone"])
    lone_b = Counter(item["key"] for item in news if item["alone"])

    def spare(x, y):
        return not ((x["alone"] and lone_a[x["key"]] > 1) or (y["alone"] and lone_b[y["key"]] > 1))

    rest_a, rest_b = {}, {}
    for i in loose_a:
        for item in by_a[i] if i not in used_a else []:
            if item["key"]:
                rest_a.setdefault(item["key"], []).append(item)
    for j in loose_b:
        for item in by_b[j] if j not in used_b else []:
            if item["key"]:
                rest_b.setdefault(item["key"], []).append(item)
    unsure = []
    for key, ys in rest_b.items():
        xs = rest_a.get(key, [])
        if not xs or len({x["marks"] for x in xs + ys}) == 1:
            continue  # new words, or nothing that could have changed
        if len(xs) != len(ys):
            reason = "count_changed"
        elif len(xs) == 1:
            pairs.extend((x, y, "changed_line") for x, y in zip(xs, ys))
            continue
        elif len(xs) * len(ys) > 400:
            reason = "too_many"
        elif (named := by_narration(xs, ys, spare)):
            pairs.extend((x, y, "changed_line") for x, y in named)
            continue
        elif any(item["alone"] for item in xs + ys):
            reason = "indistinct"
        elif any(len({(x["line"], x["narration"]) for x in side}) < len(side) for side in (xs, ys)) and \
                len({x["narration"] for x in xs + ys}) > 1:
            reason = "same_narration"  # two quotes of one line that their narration cannot tell apart (r5.10)
        elif by_context(xs, ys) != list(range(len(xs))):
            reason = "order_unclear"
        elif traded(xs, ys):
            reason = "crossed"
        else:
            pairs.extend((x, y, "changed_line") for x, y in zip(xs, ys))
            continue
        unsure.extend((xs, ys, y, reason) for y in ys if any(x["marks"] != y["marks"] for x in xs))
    return pairs, unsure


def compare_texts(original, revised, rules=None, dialogue_soft_wrap=None):
    """What a revision introduced: new findings, resolved findings, changed end marks in the same line of dialogue.

    Findings are matched by rule and matched text, not by position, so moving a paragraph does not count as new.
    Both versions are linted in the same quotation mode.
    """
    checked = load_rules(rules)
    original, revised = (t.replace("\r\n", "\n") for t in (original, revised))
    original, revised = (t[1:] if t.startswith("\ufeff") else t for t in (original, revised))
    before = lint_text(original, rules, dialogue_soft_wrap)
    after = lint_text(revised, rules, dialogue_soft_wrap)

    # r5.52: a finding of the revision is the same as one of the original when they have the same rule, severity and
    # text and (1) sit on lines the line diff pairs (an unchanged line, or a rewritten one in the same place), or (2)
    # have the same words around them (a paragraph that moved). Nothing pairs across the text by text alone, so a new
    # ERROR is never cancelled by a different one fixed elsewhere. P14 and P15 quote the start of a tag or quotation, so
    # on paired lines they pair even when those words were edited.
    old_lines, new_lines = original.split("\n"), revised.split("\n")
    same_place, same_line = {}, {}  # original line -> revised lines in the same place; one to one where the diff says so
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, old_lines, new_lines, autojunk=False).get_opcodes():
        if tag == "equal" or (tag == "replace" and i2 - i1 == j2 - j1):
            for k in range(i2 - i1):
                same_place.setdefault(i1 + k + 1, set()).add(j1 + k + 1)
                same_line[i1 + k + 1] = j1 + k + 1
        elif tag == "replace":
            for k in range(i1, i2):
                same_place.setdefault(k + 1, set()).update(range(j1 + 1, j2 + 1))

    def key(finding):
        return finding["rule"], finding["severity"], re.sub(r"\s+", "", finding["match"])

    def words_around(finding):
        return key(finding) + (re.sub(r"\s+", "", finding["context"]),)

    tests = (  # (bucket key, test within the bucket)
        (words_around, lambda b, a: a["line"] in same_place.get(b["line"], ())),
        (key, lambda b, a: same_line.get(b["line"]) == a["line"]),
        (lambda f: (f["rule"], f["severity"]) if f["rule"] in ("P14", "P15") else None,
         lambda b, a: same_line.get(b["line"]) == a["line"]),
        (words_around, lambda b, a: True),
    )
    old_left, new_left = list(before["findings"]), list(after["findings"])
    for bucket, test in tests:
        waiting = {}
        for a in new_left:
            waiting.setdefault(bucket(a), []).append(a)
        paired = set()
        for b in old_left:
            group = waiting.get(bucket(b)) if bucket(b) is not None else None
            partner = next((a for a in group if test(b, a)), None) if group else None
            if partner is not None:
                group.remove(partner)
                paired.add(id(b))
                paired.add(id(partner))
        old_left = [f for f in old_left if id(f) not in paired]
        new_left = [f for f in new_left if id(f) not in paired]
    introduced, resolved = new_left, old_left
    pairs, unsure = match_utterances(original, revised, checked)
    where = {"same_line": "", "moved_line": "（这一段换了位置）", "changed_line": "（这一段的叙述也改过）",
             "in_place": "（按原位置对应：紧挨着的一行改写过，程序假定那是原地改写，不是别处挪来的）"}
    tone = []
    for old, new, how in pairs:
        if old["marks"] == new["marks"]:
            continue
        before_marks, after_marks = old["marks"] or "（无）", new["marks"] or "（无）"
        tone.append({"line": new["line"], "column": new["column"], "before": before_marks, "after": after_marks,
                     "original": old["content"], "revised": new["content"], "original_line": old["line"], "match": how,
                     "message": "同一句对白的句末标点由“%s”改成“%s”%s，语气或句类可能变了（比如疑问变陈述、叹号变平叙）。"
                                "确认这是有意的改动。" % (before_marks, after_marks, where[how])})
    why = {"count_changed": "原稿里出现 %d 次，修订稿里出现 %d 次",
           "order_unclear": "两版都出现 %d 次，但所在的段落改过叙述，按先后次序对和按上下文对，结果不一样",
           "crossed": "两版都出现 %d 次，所在的几行改过叙述，一行去掉的说法出现在另一行、另一行原来的说法出现在这一行，"
                      "像是说话人换了位置，按先后次序对不可靠",
           "indistinct": "两版都出现 %d 次，这几行只有引号里的话；程序只凭上方以冒号结尾的说话行或紧挨着的上一行认人，"
                         "在这里分不出是谁说的哪一句（比如段落挪了位置）",
           "same_narration": "两版都出现 %d 次，其中几句在同一行，行里的叙述分不出各是谁说的，按先后次序对不可靠",
           "too_many": "两版都出现 %d 次，重复太多，不逐句对应"}
    for olds, news, new, reason in unsure:
        seen = "、".join(dict.fromkeys(x["marks"] or "（无）" for x in olds))
        where_seen = "，".join("第 %d 行句末“%s”" % (x["line"], x["marks"] or "（无）") for x in olds[:6])
        where_seen += "等 %d 处" % len(olds) if len(olds) > 6 else ""
        counts = (len(olds), len(news)) if reason == "count_changed" else (len(olds),)
        tone.append({"line": new["line"], "column": new["column"], "before": seen, "after": new["marks"] or "（无）",
                     "original": olds[0]["content"], "revised": new["content"],
                     "original_lines": [x["line"] for x in olds], "match": "uncertain", "uncertain_reason": reason,
                     "message": "这句对白在原稿里出现过（%s）；%s，程序对不上这一处原来是哪一句。"
                                "请对照原稿确认这里的句末标点和语气有没有改。" % (where_seen, why[reason] % counts)})
    # One line can hold several utterances: the id names the line AND the column of the opening quote, so each change
    # needs its own decision (r5 review F01: line-only ids collided).
    tone.sort(key=lambda t: (t["line"], t["column"]))
    assign_ids(tone, lambda t: "TONE-L%d-C%d" % (t["line"], t["column"]))
    errors = sum(f["severity"] == "ERROR" for f in introduced)
    reviews = sum(f["severity"] == "REVIEW" for f in introduced) + len(tone)
    return {"tool": "punctuation_lint", "mode": "compare", "version": VERSION, "settings": settings_of(checked),
            "dialogue_soft_wrap": after["dialogue_soft_wrap"],
            "status": "INTRODUCED_ERRORS" if errors else "REVIEW" if reviews else "NO_NEW_FLAGS",
            "counts": {"ERROR": errors, "REVIEW": reviews},
            "introduced": introduced, "resolved": resolved, "tone_changes": tone,
            "stats": {"before": before["stats"], "after": after["stats"]},
            "limits": ("只比较两版的格式问题和对白句末标点：修改稿新出现的问题、原稿已有而修改后消失的问题。"
                       "对白一一对应着比：先按整行对齐（挪了位置的段落也找得回来），再按同样的话对应改过叙述的段落；"
                       "一行里有几个人说话、修订时拆成几行或几行并成一行的，各句按各自的说话人叙述对应；"
                       "只有台词的一行，按上方以冒号结尾的说话行认人（隔着空行也算），其次是紧挨着的上一行，"
                       "只写在下一行的说话人不认；"
                       "同一句话重复出现、程序确定不了哪句对哪句的，标为“对不上”（uncertain）请人核对。"
                       "修复目标是否达成、语义和因果有没有变，仍要编辑对照两版判断；统计只作同口径对照。")}


def render_text(report):
    lines = ["%s  %s  ERROR=%d REVIEW=%d" % (report.get("file", "-"), report["status"],
                                            report["counts"]["ERROR"], report["counts"]["REVIEW"])]
    for f in report["findings"]:
        lines.append("  L%d:C%d [%s %s %s] 「%s」 %s —— %s" % (f["line"], f["column"], f["severity"], f["rule"],
                                                          f["name"], f["match"].replace("\n", "⏎"), f["context"], f["message"]))
    s = report["stats"]
    lines.append("  统计（口径：%s）：汉字%d，句号%d，逗号%d，句数%d，平均句长%s，单句段占比%s" % (
        s["basis"], s["han_characters"], s["marks"]["。"], s["marks"]["，"], s["sentences"],
        s["mean_han_per_sentence"], s["single_sentence_paragraph_share"]))
    for span in report.get("skipped_spans", []):
        lines.append("  未检查格式 L%d:C%d [%s] %s" % (span["line"], span["column"], span["kind"], span["text"]))
    return "\n".join(lines)


def render_compare(report):
    lines = ["%s（对照 %s）  %s  新出现 ERROR=%d REVIEW=%d" % (report.get("file", "-"), report.get("baseline", "-"), report["status"],
                                                        report["counts"]["ERROR"], report["counts"]["REVIEW"])]
    for label, items in (("新出现", report["introduced"]), ("已消失", report["resolved"])):
        for f in items:
            lines.append("  %s L%d:C%d [%s %s] 「%s」 %s" % (label, f["line"], f["column"], f["severity"], f["rule"],
                                                         f["match"].replace("\n", "⏎"), f["context"]))
    for t in report["tone_changes"]:
        lines.append("  语气 L%d:C%d %s → %s —— %s" % (t["line"], t["column"], t["before"], t["after"], t["message"]))
    return "\n".join(lines)


def with_profile(rules, profile):
    """The command-line --profile replaces the rules file's profile for this run; the file's other fields still win."""
    if not profile:
        return rules
    if rules is not None and not isinstance(rules, dict):
        raise ValueError("rules must be a JSON object")
    return dict(rules or {}, profile=profile)


def utf8_stdio():
    """Reports are UTF-8 on every platform; a Windows pipe would otherwise use the local code page."""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("manuscript", type=Path, nargs="+")
    parser.add_argument("--rules", type=Path, help="project JSON: ability_tags, panel_prefixes, ignore ...")
    parser.add_argument("--format", choices=("json", "text"), default="json")
    parser.add_argument("--baseline", type=Path, help="original text; report only what the revised manuscript introduced")
    parser.add_argument("--profile", choices=sorted(PROFILES),
                        help="the author's presets for this run (r5.52): strict = stacked_mark_limit 1; light = stacked_mark_limit 3; "
                             "raw-panel = raw_brackets 【】 and [], tag_layout allow, stacked_mark_limit 1. Overrides the rules file's profile")
    parser.add_argument("--dialogue-soft-wrap", action="store_true", default=None,
                        help="opt in for this run: consecutive physical lines inside one unclosed quote are the author's "
                             "soft wraps (a rules file can declare dialogue_soft_wrap: true instead)")
    args = parser.parse_args()
    if args.baseline:
        if len(args.manuscript) != 1:
            print(json.dumps({"status": "INPUT_ERROR", "error": "--baseline compares exactly one revised manuscript"},
                             ensure_ascii=False))
            return 2
        try:
            rules_bytes = args.rules.read_bytes() if args.rules else None
            rules = json.loads(rules_bytes.decode("utf-8")) if rules_bytes is not None else None
            rules = with_profile(rules, args.profile)
            original, revised = args.baseline.read_bytes(), args.manuscript[0].read_bytes()
            texts = []
            for path, data in ((args.baseline, original), (args.manuscript[0], revised)):
                try:
                    texts.append(data.decode("utf-8-sig").replace("\r\n", "\n"))
                except UnicodeError as exc:
                    raise UnicodeError("%s: not UTF-8 (%s)" % (path, exc)) from exc
            report = compare_texts(texts[0], texts[1], rules, args.dialogue_soft_wrap)
        except (OSError, UnicodeError, ValueError, TypeError) as exc:
            print(json.dumps({"status": "INPUT_ERROR", "error": str(exc)}, ensure_ascii=False))
            return 2
        report.update(baseline=str(args.baseline), baseline_sha256=hashlib.sha256(original).hexdigest(),
                      file=str(args.manuscript[0]), sha256=hashlib.sha256(revised).hexdigest(),
                      rules_file=str(args.rules) if args.rules else None,
                      rules_sha256=hashlib.sha256(rules_bytes).hexdigest() if rules_bytes is not None else None)
        if args.format == "text":
            print(render_compare(report))
        else:
            print(json.dumps(report, ensure_ascii=False, indent=2))
        return 1 if report["counts"]["ERROR"] else 0
    try:
        rules_bytes = args.rules.read_bytes() if args.rules else None
        rules = json.loads(rules_bytes.decode("utf-8")) if rules_bytes is not None else None
        rules = with_profile(rules, args.profile)
        load_rules(rules)
        reports = []
        for path in args.manuscript:
            data = path.read_bytes()
            try:
                manuscript = data.decode("utf-8-sig")
            except UnicodeError as exc:
                raise UnicodeError("%s: not UTF-8 (%s)" % (path, exc)) from exc
            report = lint_text(manuscript.replace("\r\n", "\n"), rules, args.dialogue_soft_wrap)
            report.update(file=str(path), sha256=hashlib.sha256(data).hexdigest(),
                          rules_file=str(args.rules) if args.rules else None,
                          rules_sha256=hashlib.sha256(rules_bytes).hexdigest() if rules_bytes is not None else None)
            reports.append(report)
    except (OSError, UnicodeError, ValueError, TypeError) as exc:
        print(json.dumps({"status": "INPUT_ERROR", "error": str(exc)}, ensure_ascii=False))
        return 2
    if args.format == "text":
        print("\n".join(render_text(r) for r in reports))
    else:
        print(json.dumps(reports[0] if len(reports) == 1 else reports, ensure_ascii=False, indent=2))
    return 1 if any(r["counts"]["ERROR"] for r in reports) else 0


if __name__ == "__main__":
    sys.exit(main())

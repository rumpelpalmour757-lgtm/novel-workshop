#!/usr/bin/env python3
"""Record actual writing/feedback events with project-scoped conditional saves.

This local ledger does not call models, write fiction, train parameters, certify
external sources, human identity, reviewer independence or literary quality.
The host executes the writing/review and continues to obey workflow_guard.
"""
import argparse
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile


def _sibling(name):
    spec = importlib.util.spec_from_file_location("_learning_loop_" + name,
                                                 Path(__file__).with_name(name + ".py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


memory = _sibling("demonstration_memory")
state = _sibling("project_state")
chapter_gate = _sibling("chapter_gate")
NAMESPACES = ("demonstration_learning", "demonstrations", "learning_runs", "learning_events", "chapter_confirmations",
              "chapter_workflow_policy")
OPS = {"configure", "start", "plan", "draft", "review", "decide", "revise",
       "finish", "stop", "author_accept", "learn", "case_status", "chapter_gate"}


class LoopError(ValueError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def _need(condition, message, code="invalid_event"):
    if not condition:
        raise LoopError(code, message)


def _text(value, name):
    _need(isinstance(value, str) and bool(value.strip()), name + " must be non-empty text")
    return value


def _strings(value, name, nonempty=False):
    _need(isinstance(value, list) and all(isinstance(x, str) and x.strip() for x in value),
          name + " must be an array of non-empty strings")
    _need(not nonempty or bool(value), name + " must not be empty")
    _need(len(value) == len(set(value)), name + " must not contain duplicates")
    return value


def _encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def _hash(value):
    return hashlib.sha256(value if isinstance(value, bytes) else value.encode("utf-8")).hexdigest()


def _validate(payload):
    _need(isinstance(payload, dict) and isinstance(payload.get("data"), dict),
          "Store must contain a data object", "invalid_store")
    _need(isinstance(payload.get("project_id"), str) and payload["project_id"].strip(),
          "Store must declare its project_id", "invalid_store")
    errors, _, config = memory.validate(payload)
    _need(not errors, "; ".join(errors), "invalid_store")
    for key in NAMESPACES:
        _need(isinstance(payload["data"].get(key, {}), dict), key + " must be an object", "invalid_store")
    if "chapter_workflow_policy" in payload["data"]:
        try:
            chapter_gate.validate_policy(payload["data"]["chapter_workflow_policy"])
        except chapter_gate.GateError as exc:
            raise LoopError(exc.code, str(exc)) from exc
    _need(type(config.get("loop_enabled", False)) is bool,
          "loop_enabled must be boolean", "invalid_store")
    maximum = config.get("max_revisions", 2)
    _need(type(maximum) is int and 1 <= maximum <= 5,
          "max_revisions must be an integer from 1 to 5", "invalid_store")
    return payload


def _decode(raw, path):
    text = raw.decode("utf-8")
    marked = (Path(path).suffix.lower() in {".md", ".markdown"}
              or not text.lstrip().startswith("{"))
    if marked:
        payload, start, end = memory.markdown_payload(text)
        _need(isinstance(payload, dict) and type(payload.get("schema_version")) is int
              and payload["schema_version"] == 1 and type(payload.get("revision")) is int
              and payload["revision"] >= 0, "Invalid Markdown learning schema", "invalid_store")
        return _validate(payload), "sha256:" + _hash(raw), (text, start, end)
    payload = state._validate(memory._loads(text))
    return _validate(payload), payload["version"], None


def read_store(path):
    """Read existing authority; versions are strict JSON CAS or whole-file SHA."""
    try:
        with state._locked(path, exclusive=False) as resolved:
            payload, version, _ = _decode(resolved.read_bytes(), resolved)
            return payload, version
    except state.StateError as exc:
        raise LoopError(exc.code, str(exc)) from exc
    except (OSError, UnicodeError, TypeError, ValueError) as exc:
        if isinstance(exc, LoopError):
            raise
        raise LoopError("invalid_store", str(exc)) from exc


def _enabled(payload):
    config = payload["data"].get("demonstration_learning", {})
    return config.get("enabled", False) and config.get("loop_enabled", False)


def _next(run):
    if run["status"] in {"finished", "stopped"}:
        return "learn" if run["status"] == "finished" else "resume_original_workflow"
    if run["status"] == "started":
        return "plan"
    if not run.get("current_draft"):
        return "draft"
    current = _reviews(run)
    if not current:
        return "review"
    latest = current[-1]
    if latest["findings"] and latest["review_id"] not in run["decisions"]:
        return "decide"
    if _pass(run):
        return "finish"
    decisions = run["decisions"].get(latest["review_id"], [])
    return "revise_or_stop" if any(x["decision"] == "adopt" for x in decisions) else "review_or_stop"


def status(path):
    payload, version = read_store(path)
    data = payload["data"]
    active = [key for key, run in data.get("learning_runs", {}).items()
              if run.get("status") not in {"finished", "stopped"}]
    return {"status": "enabled" if _enabled(payload) else "disabled",
            "enabled": data.get("demonstration_learning", {}).get("enabled", False),
            "loop_enabled": data.get("demonstration_learning", {}).get("loop_enabled", False),
            "project_id": payload["project_id"], "version": version,
            "case_count": len(data.get("demonstrations", {})),
            "run_count": len(data.get("learning_runs", {})), "active_runs": active,
            "next_action": "context" if _enabled(payload) else "resume_original_workflow"}


def _context(payload, project_id, task, tags, excluded, evaluation, limit):
    _need(payload["project_id"] == project_id, "Requested project differs from store", "project_mismatch")
    _text(task, "task")
    _strings(list(tags), "tags")
    _strings(list(excluded), "excluded groups")
    _need(type(limit) is int and 1 <= limit <= 3, "limit must be 1–3")
    _need(type(evaluation) is bool, "evaluation must be boolean")
    _need(not evaluation or bool(excluded), "Evaluation requires the current group to be excluded")
    cases = memory.select(payload["data"].get("demonstrations", {}), project_id,
                          task, tags, excluded, limit) if _enabled(payload) else []
    return {"status": "selected" if _enabled(payload) else "disabled",
            "cases": copy.deepcopy(cases), "count": len(cases),
            "scope": "examples_for_context_not_story_facts"}


def context(path, project_id, task, tags=(), excluded=(), evaluation=False, limit=3):
    payload, version = read_store(path)
    return {**_context(payload, project_id, task, tags, excluded, evaluation, limit), "version": version}


def _actor(value):
    _need(isinstance(value, dict), "actor must be an object")
    return {key: _text(value.get(key), "actor." + key) for key in ("name", "context_id")}


def _reviews(run):
    current = run.get("current_draft", {}).get("sha256")
    index = len(run["drafts"]) - 1
    return [run["reviews"][key] for key in run.get("review_order", [])
            if run["reviews"][key]["draft_sha256"] == current
            and run["reviews"][key].get("draft_index", index) == index]


def _pass(run):
    reviews = _reviews(run)
    if not reviews or reviews[-1]["verdict"] != "pass":
        return None
    latest = reviews[-1]
    if not set(run["pending_rechecks"]).issubset(latest["rechecks"]):
        return None
    # A pass cannot erase another review's findings without an explicit decision.
    for review in reviews[:-1]:
        if review["findings"] and review["review_id"] not in run["decisions"]:
            return None
        if review["review_id"] not in latest["rechecks"] and any(
                x["decision"] in {"adopt", "defer"}
                for x in run["decisions"].get(review["review_id"], [])):
            return None
    return latest


def _teacher_pass(run):
    reviews = [r for r in _reviews(run) if r["reviewer"]["role"] == "teacher"]
    if reviews and reviews[-1]["verdict"] == "pass" and set(run["pending_rechecks"]).issubset(reviews[-1]["rechecks"]):
        return reviews[-1]
    return None


def _case_available(case_id, cases, frozen):
    return (case_id in cases and cases[case_id]["status"] in memory.ELIGIBLE
            and _hash(_encode(cases[case_id])) == frozen["case_sha256"])


def _checked(value, required, name, default):
    """Maps are canonical; string arrays explicitly confirm the named checks."""
    if isinstance(value, list):
        _strings(value, name)
        value = {item: default for item in value}
    _need(isinstance(value, dict) and all(isinstance(k, str) and type(v) is bool for k, v in value.items()),
          name + " must map each condition/exception to a boolean (or list its checked text)")
    _need(set(required).issubset(value), name + " must cover every frozen condition/exception")
    return copy.deepcopy(value)


def _apply(payload, event, project_id):
    if event["op"] == "chapter_gate":
        try:
            return chapter_gate.apply(payload, event, project_id)
        except chapter_gate.GateError as exc:
            raise LoopError(exc.code, str(exc)) from exc
    data = payload["data"]
    config = data.setdefault("demonstration_learning", {"enabled": False})
    cases = data.setdefault("demonstrations", {})
    runs = data.setdefault("learning_runs", {})
    op = event["op"]
    if op == "configure":
        _need(type(event.get("loop_enabled")) is bool, "loop_enabled must be boolean")
        config["loop_enabled"] = event["loop_enabled"]
        if "max_revisions" in event:
            value = event["max_revisions"]
            _need(type(value) is int and 1 <= value <= 5, "max_revisions must be 1–5")
            config["max_revisions"] = value
        return {"next_action": "context" if _enabled(payload) else "resume_original_workflow"}
    if op == "case_status":
        case_id = _text(event.get("case_id"), "case_id")
        _need(case_id in cases, "Unknown case_id")
        _need(cases[case_id]["project_id"] == project_id, "Case belongs to another project", "project_mismatch")
        _need(event.get("status") in {"rejected", "retired"}, "Only rejected/retired case status is permitted")
        cases[case_id]["status"] = event["status"]
        cases[case_id]["status_reason"] = _text(event.get("reason"), "reason")
        return {"case_id": case_id, "next_action": "context" if _enabled(payload) else "resume_original_workflow"}
    _need(_enabled(payload), "Learning loop is disabled; continue the original workflow", "disabled")
    run_id = _text(event.get("run_id"), "run_id")
    if op == "start":
        _need(run_id not in runs, "run_id already exists", "invalid_transition")
        fields = {key: _text(event.get(key), key) for key in
                  ("task", "group_id", "input_text", "source_ref")}
        fields["tags"] = _strings(event.get("tags"), "tags")
        fields["constraints"] = _strings(event.get("constraints"), "constraints")
        excluded = _strings(event.get("excluded_groups", []), "excluded_groups")
        excluded = list(dict.fromkeys(excluded + [fields["group_id"]]))
        selected = _context(payload, project_id, fields["task"], fields["tags"], excluded,
                            event.get("evaluation", False), event.get("limit", 3))["cases"]
        if "case_ids" in event:
            wanted = _strings(event["case_ids"], "case_ids")
            _need(set(wanted).issubset(c["id"] for c in selected), "case_ids must come from filtered context")
            selected = [c for c in selected if c["id"] in wanted]
        frozen = [{**c, "case_sha256": _hash(_encode(c))} for c in selected]
        run = {"run_id": run_id, "project_id": project_id, **fields,
               "selected_cases": frozen, "applications": [], "checks": [], "drafts": [],
               "reviews": {}, "review_order": [], "decisions": {}, "pending_rechecks": [],
               "revision_count": 0, "max_revisions": config.get("max_revisions", 2),
               "status": "started", "learned_case_ids": []}
        if "workflow_guard_ref" in event:
            run["workflow_guard_ref"] = _text(event["workflow_guard_ref"], "workflow_guard_ref")
        runs[run_id] = run
    else:
        _need(run_id in runs, "Unknown run_id", "invalid_transition")
        run = runs[run_id]
        _need(run["project_id"] == project_id, "Run belongs to another project", "project_mismatch")
        _need(run["status"] != "stopped", "Run is stopped", "invalid_transition")
        _need(run["status"] != "finished" or op in {"learn", "author_accept"},
              "Run is already finished", "invalid_transition")
        if op == "plan":
            _need(run["status"] == "started", "plan must follow start", "invalid_transition")
            applications = copy.deepcopy(event.get("applications"))
            _need(isinstance(applications, list) and all(isinstance(x, dict) for x in applications),
                  "applications must be an array of objects")
            by_id = {c["id"]: c for c in run["selected_cases"]}
            ids = [x.get("case_id") for x in applications]
            _need(len(ids) == len(set(ids)) and set(ids) == set(by_id), "plan must cover every frozen case exactly once")
            for item in applications:
                case = by_id[item["case_id"]]
                _need(item.get("decision") in {"apply", "adapt", "decline"}, "Invalid application decision")
                _text(item.get("reason"), "application reason")
                conditions = _checked(item.get("conditions_checked"), case["when"], "conditions_checked", True)
                exceptions = _checked(item.get("exceptions_checked"), case["except"], "exceptions_checked", False)
                applicable = all(conditions[c] for c in case["when"]) and not any(exceptions[e] for e in case["except"])
                _need(applicable or item["decision"] == "decline", "Unmet condition or matching exception requires decline")
                _need(_case_available(item["case_id"], cases, case) or item["decision"] == "decline",
                      "Frozen case changed or is no longer approved; its decision must be decline")
                item["conditions_checked"], item["exceptions_checked"] = conditions, exceptions
            run.update(applications=copy.deepcopy(applications), checks=_strings(event.get("checks"), "checks"), status="planned")
        elif op in {"draft", "revise"}:
            if op == "draft":
                _need(run["status"] == "planned" and not run["drafts"], "draft must follow plan once", "invalid_transition")
                frozen = {c["id"]: c for c in run["selected_cases"]}
                _need(all(item["decision"] == "decline" or _case_available(item["case_id"], cases, frozen[item["case_id"]])
                          for item in run["applications"]),
                      "An applied case changed or was retired/rejected; stop and start again", "invalid_transition")
            else:
                _need(run.get("current_draft"), "No draft to revise", "invalid_transition")
                _need(event.get("parent_sha256") == run["current_draft"]["sha256"], "parent_sha256 is not current draft")
                review_id = _text(event.get("review_id"), "review_id")
                review = run["reviews"].get(review_id)
                _need(review and review_id in {r["review_id"] for r in _reviews(run)}, "Revision requires current-draft review")
                adopted = [x["finding_id"] for x in run["decisions"].get(review_id, []) if x["decision"] == "adopt"]
                _need(adopted, "Revision requires at least one explicitly adopted finding")
                feedback = [r["review_id"] for r in _reviews(run) if r["findings"]]
                _need(all(key in run["decisions"] for key in feedback),
                      "Decide every current-draft review before revision")
                rechecks = [r["review_id"] for r in _reviews(run) if r["verdict"] != "pass"]
                cap = min(run["max_revisions"], config.get("max_revisions", 2))
                _need(run["revision_count"] < cap, "Revision limit reached; stop with a reason", "limit_reached")
                run["revision_count"] += 1
                run["pending_rechecks"] = list(dict.fromkeys(run["pending_rechecks"] + rechecks))
            text = _text(event.get("text"), "text")
            draft = {"text": text, "sha256": _hash(text),
                     "source_ref": _text(event.get("source_ref"), "source_ref"), "actor": _actor(event.get("actor"))}
            if op == "revise":
                draft.update(parent_sha256=event["parent_sha256"], review_id=event["review_id"], adopted_findings=adopted)
                run.pop("author_acceptance", None)
            run["drafts"].append(draft)
            run.update(current_draft=copy.deepcopy(draft), status="drafted")
        elif op == "review":
            _need(run.get("current_draft"), "No draft to review", "invalid_transition")
            review_id = _text(event.get("review_id"), "review_id")
            _need(review_id not in run["reviews"], "review_id already exists")
            _need(event.get("draft_sha256") == run["current_draft"]["sha256"], "Review must bind the current draft")
            reviewer = event.get("reviewer")
            _need(isinstance(reviewer, dict), "reviewer must be an object")
            for key in ("name", "context_id"):
                _text(reviewer.get(key), "reviewer." + key)
            _need(reviewer.get("role") in {"writer", "teacher", "author"}, "Invalid reviewer role")
            _need(reviewer.get("mode") in {"self_check", "independent_agent", "human"}, "Invalid reviewer mode")
            _need(reviewer["mode"] != "self_check" or reviewer["role"] == "writer", "self_check can only have writer role")
            _need(reviewer["mode"] != "independent_agent" or reviewer["context_id"] != run["current_draft"]["actor"]["context_id"],
                  "Independent agent must have a different context_id from writer")
            _need(event.get("verdict") in {"pass", "revise", "blocked"}, "Invalid verdict")
            findings = event.get("findings")
            _need(isinstance(findings, list) and all(isinstance(x, dict) for x in findings), "findings must be an array")
            for finding in findings:
                for key in ("id", "issue", "evidence", "scope"):
                    _text(finding.get(key), "finding." + key)
            ids = [x["id"] for x in findings]
            _need(len(ids) == len(set(ids)), "Duplicate finding id")
            _need(event["verdict"] != "pass" or not findings, "Pass cannot contain unresolved findings")
            _need(event["verdict"] != "revise" or bool(findings), "revise verdict requires findings")
            rechecks = _strings(event.get("rechecks", []), "rechecks")
            _need(set(rechecks).issubset(run["reviews"]), "rechecks contains an unknown review id")
            review = {"review_id": review_id, "draft_sha256": event["draft_sha256"],
                      "draft_index": len(run["drafts"]) - 1,
                      "reviewer": copy.deepcopy(reviewer), "verdict": event["verdict"],
                      "findings": copy.deepcopy(findings), "source_ref": _text(event.get("source_ref"), "source_ref"),
                      "rechecks": rechecks}
            run["reviews"][review_id] = review
            run["review_order"].append(review_id)
            run["status"] = "reviewed"
        elif op == "decide":
            review_id = _text(event.get("review_id"), "review_id")
            review = run["reviews"].get(review_id)
            _need(review and review_id in {r["review_id"] for r in _reviews(run)}, "decide requires current review")
            _need(review_id not in run["decisions"], "Review decisions are already recorded")
            decisions = event.get("decisions")
            _need(isinstance(decisions, list) and all(isinstance(x, dict) for x in decisions), "decisions must be an array")
            ids = [x.get("finding_id") for x in decisions]
            _need(len(ids) == len(set(ids)) and set(ids) == {x["id"] for x in review["findings"]}, "decide must cover every finding exactly once")
            for decision in decisions:
                _need(decision.get("decision") in {"adopt", "decline", "defer"}, "Invalid finding decision")
                _text(decision.get("reason"), "decision reason")
            run["decisions"][review_id] = copy.deepcopy(decisions)
            run["status"] = "decided"
        elif op in {"finish", "author_accept"}:
            _need(run.get("current_draft") and event.get("draft_sha256") == run["current_draft"]["sha256"], "Event must bind the current draft")
            if op == "finish":
                passed = _pass(run)
                _need(passed is not None, "Current draft needs a passing review and all required rechecks", "invalid_transition")
                run.update(status="finished", final_sha256=event["draft_sha256"],
                           completion="teacher_reviewed" if _teacher_pass(run) else "self_checked",
                           final_review_id=passed["review_id"])
            else:
                _need("author_acceptance" not in run, "Current draft acceptance already recorded")
                run["author_acceptance"] = {"quote": _text(event.get("quote"), "quote"),
                                            "ref": _text(event.get("source_ref"), "source_ref"),
                                            "draft_sha256": event["draft_sha256"]}
        elif op == "stop":
            run.update(status="stopped", stop_reason=_text(event.get("reason"), "reason"))
        elif op == "learn":
            _need(run["status"] == "finished", "learn requires a finished run", "invalid_transition")
            case_id = _text(event.get("case_id"), "case_id")
            _need(case_id not in cases, "case_id already exists; old cases are never overwritten")
            passed = _pass(run)
            _need(passed is not None, "No current-draft passing review")
            draft = run["current_draft"]
            acceptance = run.get("author_acceptance")
            accepted = acceptance and acceptance["draft_sha256"] == draft["sha256"]
            teacher = _teacher_pass(run)
            supporting_review = teacher or passed
            case = {"id": case_id, "project_id": project_id, "group_id": run["group_id"],
                    "task": run["task"], "tags": copy.deepcopy(run["tags"]), "before": run["input_text"],
                    "after": draft["text"], "why": _text(event.get("why"), "why"),
                    "when": _strings(event.get("when"), "when", True),
                    "except": _strings(event.get("except"), "except"),
                    "decisions": _strings(event.get("decisions"), "decisions", True),
                    "status": "author_accepted" if accepted else "teacher_approved" if teacher else "candidate",
                    "split": event.get("split", "development"),
                    "hashes": {"before": _hash(run["input_text"]), "after": draft["sha256"]},
                    "source": {"ref": draft["source_ref"], "version": draft["sha256"],
                               "reviewer": supporting_review["reviewer"]["name"], "evidence": supporting_review["source_ref"],
                               "run_id": run_id, "input_ref": run["source_ref"], "draft_ref": draft["source_ref"],
                               "supporting_review_id": supporting_review["review_id"],
                               "draft_sha256": draft["sha256"], "review_ids": [r["review_id"] for r in _reviews(run)]},
                    "author_acceptance": copy.deepcopy(acceptance) if accepted else None}
            _need(case["split"] in memory.SPLITS, "Invalid split")
            cases[case_id] = case
            run["learned_case_ids"].append(case_id)
    result = {"run_id": run_id, "next_action": _next(run), "run_status": run["status"]}
    if run.get("current_draft"):
        result["draft_sha256"] = run["current_draft"]["sha256"]
    return result


def _atomic_bytes(path, raw):
    descriptor, name = tempfile.mkstemp(prefix="." + path.name + ".", suffix=".tmp", dir=path.parent)
    replaced = False
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(name, path)
        replaced = True
        descriptor = os.open(path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
        return []
    except OSError as exc:
        if replaced:
            return ["Replacement completed; directory durability unconfirmed. Re-read before retrying: " + str(exc)]
        raise
    finally:
        if not replaced:
            os.unlink(name)


def _retry_result(payload, event_id, fingerprint, version):
    prior = payload["data"].get("learning_events", {}).get(event_id)
    if prior is None:
        return None
    _need(isinstance(prior, dict) and prior.get("payload_sha256") == fingerprint,
          "event_id was already used with different content", "duplicate_event")
    return {**prior["result"], "status": "unchanged", "version": version}


def apply_event(path, event, project_id, expected_version):
    """Apply one immutable event with strict CAS; identical retries are harmless."""
    try:
        _need(isinstance(event, dict), "Event must be an object")
        event = copy.deepcopy(event)
        fingerprint = _hash(_encode(event))
        event_id = _text(event.get("event_id"), "event_id")
        _need(isinstance(event.get("op"), str) and event["op"] in OPS, "Unknown op")
        _text(project_id, "project_id")
        _text(expected_version, "expected_version")
        # Markdown's stable lock covers read/transform/replace. JSON delegates its
        # final save to commit_state with no base, so no three-way merge is possible.
        with state._locked(path) as resolved:
            payload, version, markdown = _decode(resolved.read_bytes(), resolved)
            _need(payload["project_id"] == project_id, "Requested project differs from store", "project_mismatch")
            retried = _retry_result(payload, event_id, fingerprint, version)
            if retried:
                return retried
            _need(version == expected_version, "Store changed since your read; no write performed", "stale_version")
            updated = copy.deepcopy(payload)
            result = _apply(updated, event, project_id)
            updated["data"].setdefault("learning_events", {})[event_id] = {
                "payload_sha256": fingerprint, "op": event["op"], "run_id": event.get("run_id"),
                "event": copy.deepcopy(event), "result": result}
            _validate(updated)
            if markdown is not None:
                updated["revision"] += 1
                text, start, end = markdown
                # Literal marker text in a manuscript remains round-trip equal,
                # while only the actual Markdown delimiters occur in the file.
                encoded = _encode(updated).decode("utf-8").replace("<", "\\u003c")
                raw = (text[:start] + encoded + text[end:]).encode("utf-8")
                warnings = _atomic_bytes(resolved, raw)
                return {**result, "status": "saved_durability_uncertain" if warnings else "saved",
                        "version": "sha256:" + _hash(raw), "warnings": warnings}
        # commit_state acquires the very same lock independently. A writer that
        # won this interval causes a CAS failure; it can never be overwritten.
        committed = state.commit_state(path, expected_version, updated["data"])
        return {**result, "status": committed["status"], "version": committed["state"]["version"],
                "warnings": committed.get("warnings", [])}
    except state.StateError as exc:
        if exc.code == "stale_version":
            current, version = read_store(path)
            retried = _retry_result(current, event_id, fingerprint, version)
            if retried:
                return retried
        raise LoopError(exc.code, str(exc)) from exc
    except (OSError, UnicodeError, TypeError, ValueError, KeyError) as exc:
        if isinstance(exc, LoopError):
            raise
        raise LoopError("invalid_event", str(exc)) from exc


HELP = """Events always have event_id/op; run operations also have run_id.
configure: loop_enabled:boolean; optional max_revisions:1..5.
start: task,tags:[text],group_id,input_text,source_ref,constraints:[text].
  Optional case_ids selects only filtered cases; excluded_groups/evaluation/limit
  further restrict selection. Current group is always excluded. Optional
  workflow_guard_ref records an existing guard reference without reading it.
plan: applications:[{case_id,decision:apply|adapt|decline,reason,
  conditions_checked:{condition:bool},exceptions_checked:{exception:bool}}],
  checks:[text]. Cover every frozen case/condition/exception. A matching
  exception or false condition requires decline. String arrays may explicitly
  name satisfied conditions / checked non-matching exceptions. Zero cases: [].
draft: text,source_ref,actor:{name,context_id}.
review: review_id,draft_sha256,reviewer:{name,role:writer|teacher|author,
  mode:self_check|independent_agent|human,context_id},verdict:pass|revise|blocked,
  findings:[{id,issue,evidence,scope}],source_ref; optional rechecks:[review_id].
  self_check only uses writer role; independent_agent needs another context_id.
decide: review_id,decisions:[{finding_id,decision:adopt|decline|defer,reason}].
revise: parent_sha256,text,source_ref,actor,review_id; needs adopted finding(s).
finish: draft_sha256; current pass must cover pending rechecks.
stop: reason. author_accept: draft_sha256,quote,source_ref (actual evidence).
learn: case_id,why,when:[text],except:[text],decisions:[text]; optional split.
  Uses actual run input/final draft; self-check creates candidate only.
case_status: case_id,status:rejected|retired,reason; no evidence-free promotion.
chapter_gate: independent of loop. action:configure needs no chapter_id/stage:
  visual_required:boolean,teacher_handoff:user_return|host,actor_role:author,
  mode:human,author_quote,source_ref. Only chapters first presented afterward
  freeze this policy; existing chapters keep their policy or legacy behavior.
  action:present|confirm|reopen: chapter_id,stage.
  present: content,source_ref; draft/revision/final also artifact_sha256.
  Required visual preparation adds visual_evidence:{mode:pipeline_run|author_images|reuse,
  source_refs:[text],observation_ref,selection_ref}; pipeline_run also needs
  run_ref,verification_ref; reuse needs reuse_author_quote,reuse_source_ref.
  user_return waits after draft confirmation. action:teacher_return needs
  chapter_id,draft_presentation_id,draft_presentation_version,draft_sha256,
  returned_text,source_ref,teacher_name (use unknown explicitly if unknown).
  It keeps the original text and hash without confirming any stage. Then review
  present needs teacher_return_id bound to this confirmed draft instance.
  Review binds confirmed draft; final must match confirmed revision. confirm:
  presentation_id,presentation_version,actor_role:author,mode:human,author_quote,
  source_ref; final also decision:accept_final_version. reopen:
  reason,author_quote,source_ref. Store CAS remains the outer version field.
No command executes event contents or calls a model. Visual evidence only checks
record structure; the host must actually inspect images. Recorded sources,
identities, independent contexts and literary quality cannot be authenticated
by this script. The host remains responsible for workflow_guard's smaller
budget, existing reservation protocol and delivery gate.
"""


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, epilog=HELP,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("status", "show", "context", "apply"):
        sub = commands.add_parser(name, epilog=HELP if name == "apply" else None,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
        sub.add_argument("store", type=Path)
        if name == "show":
            sub.add_argument("--run-id", required=True)
        if name in {"context", "apply"}:
            sub.add_argument("--project-id", required=True)
        if name == "context":
            sub.add_argument("--task", required=True)
            sub.add_argument("--tag", action="append", default=[])
            sub.add_argument("--exclude-group", action="append", default=[])
            sub.add_argument("--evaluation", action="store_true")
            sub.add_argument("--limit", type=int, choices=range(1, 4), default=3)
        if name == "apply":
            sub.add_argument("event", type=Path)
            sub.add_argument("--if-version", required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == "status":
            result = status(args.store)
        elif args.command == "context":
            result = context(args.store, args.project_id, args.task, args.tag,
                             args.exclude_group, args.evaluation, args.limit)
        elif args.command == "show":
            payload, version = read_store(args.store)
            run = payload["data"].get("learning_runs", {}).get(args.run_id)
            _need(run is not None, "Unknown run_id", "invalid_transition")
            result = {"status": "found", "version": version, "run": run, "next_action": _next(run)}
        else:
            event = memory._loads(args.event.read_text(encoding="utf-8"))
            result = apply_event(args.store, event, args.project_id, args.if_version)
        print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
        return 4 if result.get("status") == "saved_durability_uncertain" else 0
    except (LoopError, OSError, ValueError, TypeError) as exc:
        print(json.dumps({"status": "error", "code": getattr(exc, "code", "invalid_event"),
                          "message": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 3 if getattr(exc, "code", "") == "stale_version" else 2


if __name__ == "__main__":
    raise SystemExit(main())

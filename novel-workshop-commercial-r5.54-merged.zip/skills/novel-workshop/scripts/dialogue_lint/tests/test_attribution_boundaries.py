import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import unittest
from dialogue_core import extract_dialogues
from dialogue_antipatterns import scan_dialogue_antipatterns
from patch_guard import build_patch_request


class AttributionBoundaryTests(unittest.TestCase):
    def test_listener_in_unpunctuated_clause_is_never_promoted_to_speaker(self):
        for action in ('看着', '指着', '叫住', '告诉'):
            with self.subTest(action=action):
                text = f'顾舟{action}许澄说：“在门后头。”'
                line = extract_dialogues([text], ('许澄', '顾舟'))[0]
                self.assertFalse(line.speaker == '许澄' and line.confidence == 'explicit')
                issues = scan_dialogue_antipatterns([text], include_style_hints=True)
                self.assertTrue(any(i.rule_id == 'COMP_04_COORDINATE_REPLY' for i in issues))
                self.assertEqual(build_patch_request([text], issues)['items'], [])

    def test_unknown_postposed_speaker_blocks_neighbor_inheritance(self):
        line = extract_dialogues(['乔宁看着门。', '“我那包。”老人说。'], ('乔宁',))[0]
        self.assertEqual((line.speaker, line.confidence), ('未知', 'unknown'))

    def test_listeners_are_handled_or_left_unknown_instead_of_reassigned(self):
        examples = {
            '林舟对沈砚说：“先等。”': '林舟',
            '林舟听老人说：“是我。”': '未知',
            '林舟听沈砚说：“是我。”': '未知',
        }
        for text, expected in examples.items():
            with self.subTest(text=text):
                self.assertEqual(extract_dialogues([text], ('林舟', '沈砚'))[0].speaker, expected)


if __name__ == '__main__':
    unittest.main()

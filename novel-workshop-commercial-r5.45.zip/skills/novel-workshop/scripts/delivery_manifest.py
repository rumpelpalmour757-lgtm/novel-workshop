#!/usr/bin/env python3
"""Read-only batch completeness check. It does not send or publish manuscripts."""
import argparse
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
_spec = importlib.util.spec_from_file_location("delivery_workflow", Path(__file__).with_name("workflow_guard.py"))
guard = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(guard)


def check(path):
    path = Path(path).resolve()
    content = guard.read_bytes(path)
    manifest = guard.strict_json(content)
    guard.need(isinstance(manifest, dict) and manifest.get("schema") == "delivery-manifest/1", "Expected delivery-manifest/1")
    guard.need(manifest.get("stage") in {"candidate", "accepted"}, "stage must be candidate or accepted")
    expected, records = manifest.get("expected_units"), manifest.get("records")
    guard.need(isinstance(expected, list) and bool(expected) and all(guard.nonempty(x) for x in expected)
               and len(set(expected)) == len(expected), "expected_units must contain unique, nonempty unit names")
    guard.need(isinstance(records, list), "records must be an array")
    guard.need(type(manifest.get("require_independent", False)) is bool, "require_independent must be boolean")
    issues, results, seen, paths = [], [], set(), set()
    snapshots = {path: content}
    for entry in records:
        guard.need(isinstance(entry, dict) and guard.nonempty(entry.get("unit")), "Each record needs a unit")
        unit, problems = entry["unit"], []
        if unit in seen:
            problems.append("DUPLICATE_UNIT")
        seen.add(unit)
        if unit not in expected:
            problems.append("UNEXPECTED_UNIT")
        result = {"unit": unit, "problems": problems, "notes": []}
        try:
            candidate = guard.local_path(path.parent, entry.get("candidate"))
            state_path = guard.local_path(path.parent, entry.get("state"))
            if candidate in paths:
                problems.append("REUSED_CANDIDATE_FILE")
            paths.add(candidate)
            for target in (candidate, state_path):
                snapshots[target] = guard.read_bytes(target)
            if not snapshots[candidate].decode("utf-8-sig").strip():
                problems.append("EMPTY_CANDIDATE")
            state = guard.load_state(state_path)
            gate = guard.compute_gate(state, state_path.parent)
            _, spec_path, spec = guard.active_spec(state, state_path.parent)
            if guard.local_path(spec_path.parent, spec["candidate"]) != candidate:
                problems.append("CANDIDATE_PATH_MISMATCH")
            machine = guard.check_spec(spec_path)
            if machine["status"] != "GREEN":
                problems.append("CURRENT_CHECKS_" + machine["status"])
            incomplete = (gate["input_ready"] != "READY" or gate["mechanical"] != "GREEN"
                          or not gate["editorial"].startswith("PASS["))
            if incomplete:
                problems.append("GATE_INCOMPLETE")
            if gate.get("review_skipped_by_author"):
                # Two different facts (r5.2, review N03): the author skipped the review when accepting (history, always
                # kept), and whether these bytes have a current review since then. Whether that review passes is the
                # gate's business (GATE_INCOMPLETE above), not a reason to call the review missing.
                if gate.get("reviewed_since_skip"):
                    result["notes"].append("AUTHOR_SKIPPED_REVIEW_AT_ACCEPTANCE: the author accepted these bytes with the "
                                           "review skipped; a review of them was recorded afterwards (its result is in gate)")
                else:
                    problems.append("AUTHOR_SKIPPED_REVIEW")
            if manifest.get("require_independent") and gate["editorial"] == "PASS[self_check]":
                problems.append("INDEPENDENT_REVIEW_REQUIRED")
            if manifest["stage"] == "accepted" and gate["author"] != "ACCEPTED":
                problems.append("AUTHOR_NOT_ACCEPTED")
            # Recheck the bound context after current checks, including inputs
            # whose changing bytes could make an older PASS appear current.
            if guard.compute_gate(state, state_path.parent) != gate:
                problems.append("CONTEXT_CHANGED_DURING_CHECK")
            result.update(candidate=entry["candidate"], gate=gate, current_checks=machine["status"])
        except (OSError, ValueError, KeyError, TypeError) as exc:
            problems.append("UNVERIFIABLE: " + str(exc))
        results.append(result)
    for unit in expected:
        if unit not in seen:
            issues.append({"unit": unit, "problem": "MISSING_UNIT"})
    for target, data in snapshots.items():
        if guard.read_bytes(target) != data:
            issues.append({"problem": "FILE_CHANGED_DURING_CHECK", "path": str(target)})
    return {"schema": "delivery-report/1", "status": "INCOMPLETE" if issues or any(r["problems"] for r in results) else "PASS",
            "stage": manifest["stage"], "expected": len(expected), "listed": len(records),
            "issues": issues, "units": results,
            "limits": "Only verifies the declared units and current files. Does not prove literary quality, real author identity or message delivery."}


def utf8_stdio():
    """Reports are UTF-8 on every platform; a Windows pipe would otherwise use the local code page."""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    args = parser.parse_args()
    try:
        result = check(args.manifest)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["status"] == "PASS" else 1
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({"status": "INVALID_INPUT", "error": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    sys.exit(main())

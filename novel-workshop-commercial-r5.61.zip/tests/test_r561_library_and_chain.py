#!/usr/bin/env python3
"""r5.61, package one: the inspiration library's new records (a look in the conversation, an image the author sent
in the conversation, an image the host drew, drafted), record and add-image, the material block, the three input
samples and the first repairs of the visual chain (a 429 stops that search, a request with source pages only, the
optional steps, the doctor's summary, the receipt, run_check); the single file's opening and where the visual notes
card sits in it.

Offline: the network is the stand-in of test_visual_materials_pipeline.py or a temporary server on 127.0.0.1, the
pictures are drawn here, the examples are made up for these tests. Passing says the scripts do what the plan
describes; it does not say that a real search service answers this way, that a host uses any of it, or that the
images found or the text written are better.
"""
import hashlib
import importlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
HERE = Path(__file__).resolve().parent
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", HERE.parent))
SKILL = ROOT / "skills" / "novel-workshop"
SCRIPTS = SKILL / "scripts"
READ, WRITE, CLI = SCRIPTS / "inspiration_library.py", SCRIPTS / "inspiration_write.py", SCRIPTS / "visual_materials_cli.py"
for folder in (str(SCRIPTS), str(HERE)):
    if folder not in sys.path:
        sys.path.insert(0, folder)
T = importlib.import_module("test_visual_materials_pipeline")  # its stand-in network and made-up pictures


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


lib = load(READ, "nw_lib_r561")
hygiene = load(HERE / "test_r559_collect_hygiene.py", "r561_hygiene")  # its temporary server on 127.0.0.1
vm = T.vm
HARD = ("永远", "绝不", "必须", "严禁")


def run(*argv):
    proc = subprocess.run([sys.executable, "-I", "-B"] + [str(a) for a in argv], capture_output=True, text=True,
                          encoding="utf-8")
    try:
        data = json.loads(proc.stdout)
    except ValueError:
        data = None
    return proc.returncode, data, proc.stdout + proc.stderr


# Made up for these tests: a repair shop's doorway on a rainy night.
REF = "2026-10-23 的对话，作者发的第 2 张图"
SEEN = "檐下一条长凳，凳腿垫着半块砖；墙上钉着一排挂钩"
LOOK = {"scope": "conversation", "ref": REF, "shown_as": "unknown", "seen": SEEN, "by": "工坊", "date": "2026-10-23"}
CHAT = {"id": "N-1", "kind": "place", "title": "修车铺门口", "status": "candidate",
        "source": {"type": "author_chat", "ref": REF}, "observation": LOOK, "use": [], "conflicts": []}
DECISION = {"by": "作者", "date": "2026-10-23", "words": "长凳要，挂钩也要"}
BENCH, HOOKS = "檐下的长凳", "墙上一排挂钩"
LIB2 = {"schema": "inspiration-library/2", "book": "测试", "revision": 1}


class Book(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.library = self.root / "inspiration" / "library.json"
        self.library.parent.mkdir()
        self.save({"schema": "inspiration-library/2", "book": "测试", "revision": 0, "entries": []})

    def tearDown(self):
        self.tmp.cleanup()

    def save(self, data, path=None):
        (path or self.library).write_bytes(json.dumps(data, ensure_ascii=False).encode("utf-8"))

    def data(self):
        return json.loads(self.library.read_text(encoding="utf-8"))

    def problems(self, *entries):
        return lib.check_library(dict(LIB2, entries=list(entries)), self.root)

    def adopt(self, selection, *more):
        path = self.root / "selection.json"
        self.save(dict({"schema": "inspiration-selection/1", "decision": DECISION}, **selection), path)
        return run(WRITE, "adopt", self.library, "--selection", path, "--if-revision", self.data()["revision"], *more)

    def card(self, chapter, *more):
        return run(READ, "card", self.library, "--chapter", chapter, *more)[2]


class Format(Book):
    def test_a_look_in_the_conversation_is_recorded_as_such(self):  # LIB-02
        self.assertEqual(self.problems(CHAT), [])
        said = {
            "image_sha256": ({"image_sha256": "0" * 64}, "N-1: a look in the conversation is not bound to a file: leave "
                             "image_sha256 out (with the file in hand, look at it and write scope original)"),
            "ref": ({"ref": ""}, "N-1: a look in the conversation says which message it was (observation.ref)"),
            "shown_as": ({"shown_as": "big"}, "N-1: observation.shown_as is one of original, reduced, unknown (unknown "
                         "when it cannot be told whether the original or a reduced copy was shown)"),
            "by": ({"by": ""}, "N-1: observation.by says who looked (the workshop with the host's image viewer, a named "
                   "vision model, or the author)"),
            "extra": ({"page": "x"}, "N-1: observation is {scope, image_sha256, seen, unclear, by, date} (a look in the "
                      "conversation: ref and shown_as instead of image_sha256)"),
        }
        for name, (change, message) in said.items():
            with self.subTest(name=name):
                self.assertIn(message, self.problems(dict(CHAT, observation=dict(LOOK, **change))))
        no_date = {k: v for k, v in LOOK.items() if k != "date"}
        self.assertIn("N-1: a look in the conversation says when (observation.date)",
                      self.problems(dict(CHAT, observation=no_date)))
        elsewhere = dict(CHAT, source={"type": "text", "ref": "作者 2026-10-23 说的"},
                         observation={"scope": "author_text", "seen": SEEN, "by": "作者", "ref": REF})
        self.assertIn("N-1: observation.ref and shown_as belong to a look in the conversation (scope conversation)",
                      self.problems(elsewhere))
        # the old way round is still refused: an original that names no image version
        self.assertTrue(self.problems(dict(CHAT, observation={"scope": "original", "seen": SEEN, "by": "工坊"})))
        # check says what it cannot do for such a look (B-10)
        self.save(dict(LIB2, entries=[CHAT]))
        code, report, _ = run(READ, "check", self.library)
        self.assertEqual((code, report["status"]), (0, "OK"))
        self.assertIn("在对话里看过的只核栏全不全，没有绑定哈希", report["limits"])

    def test_two_new_sources(self):  # LIB-03, LIB-04
        self.assertIn("N-1: ref says which message of the conversation the author sent the image in, and when (there is "
                      "no file)", self.problems(dict(CHAT, source={"type": "author_chat"})))
        web = dict(CHAT, id="W-1", source={"type": "link", "url": "https://example.org/shop", "license": "未核，只作写作参考"})
        self.assertEqual(self.problems(web), [])  # a web image the host looked at in the conversation: link + conversation
        drawn = dict(CHAT, id="G-1", source={"type": "host_generated", "asked_by": "作者", "date": "2026-10-23",
                                             "prompt": "雨夜修车铺门口的示意图"})
        self.assertEqual(self.problems(drawn), [])
        who = "G-1: an image the host drew says who asked for it (asked_by) and the words used (prompt)"
        for key, message in (("asked_by", who), ("prompt", who),
                             ("date", "G-1: an image the host drew says when (date: YYYY-MM-DD)")):
            with self.subTest(key=key):
                source = {k: v for k, v in drawn["source"].items() if k != key}
                self.assertIn(message, self.problems(dict(drawn, source=source)))
        self.assertIn("G-1: sha256 is the file's digest; without a file leave it out",
                      self.problems(dict(drawn, source=dict(drawn["source"], sha256="0" * 64))))
        # with a file it is checked like the author's file
        picture = self.root / "images" / "g.png"
        picture.parent.mkdir()
        picture.write_bytes(b"drawn here")
        digest = hashlib.sha256(b"drawn here").hexdigest()
        with_file = dict(drawn, source=dict(drawn["source"], file="images/g.png", sha256=digest),
                         observation={"scope": "original", "image_sha256": digest, "seen": SEEN, "by": "工坊",
                                      "date": "2026-10-23"})
        self.assertEqual(self.problems(with_file), [])
        wrong = dict(with_file, source=dict(with_file["source"], sha256="1" * 64))
        self.assertTrue(any("sha256" in p for p in self.problems(wrong)))
        self.assertIn("宿主画的图", lib.origin(drawn))
        self.assertIn("不当真实场所、年代、器物的依据", lib.origin(drawn))
        self.assertIn("作者在对话里发的图，没有文件", lib.origin(CHAT))

    def test_drafted_is_checked(self):  # LIB-05
        picked = dict(CHAT, status="picked", decision=DECISION, take=[{"part": BENCH, "scope": "stable"}])
        record = {"part": BENCH, "chapter": 7, "scene": "S2", "draft": "第七章修订稿", "state": "used", "date": "2026-10-24"}
        self.assertEqual(self.problems(dict(picked, drafted=[record])), [])
        self.assertIn("N-1: drafted is a list of {part, chapter, scene, draft, state: used|unused, date}: a part written "
                      "into a draft the author has not accepted yet (or taken and not used in it)",
                      self.problems(dict(picked, drafted=[dict(record, state="maybe")])))
        self.assertIn("N-1: only a picked entry has parts written into a draft", self.problems(dict(CHAT, drafted=[record])))

    def test_the_template_and_the_registered_function(self):  # LIB-06, LIB-22
        template = json.loads((SKILL / "assets" / "inspiration-library-template.json").read_text(encoding="utf-8"))
        found = lib.check_library(template, SKILL / "assets")
        self.assertTrue(found and all(p.startswith("IMG-001: ") for p in found), found)  # only the placeholder file
        self.assertEqual(template["schema"], "inspiration-library/2")
        self.assertEqual([e["status"] for e in template["entries"]], ["picked", "candidate", "to_find"])  # as before
        new = ("只在对话里看过、没有文件的图写 conversation，不写哈希，写 ref（哪一天、对话里哪一条）和 shown_as（original 原图、"
               "reduced 缩小过的、unknown 说不清）；宿主画的图出处写 host_generated（这两种的样子见 "
               "assets/inspiration-selection.example.json）；", "交出去、作者还没采纳的一稿里写了哪几样记在 drafted；")
        for sentence in new:
            self.assertEqual(template["note"].count(sentence), 1)
            self.assertFalse([w for w in HARD if w in sentence])
        self.assertIn("def check_library(", READ.read_text(encoding="utf-8"))

    def test_a_library_without_the_new_records_prints_as_before(self):  # LIB-06; the text is r5.60's output
        entry = {"id": "L-1", "kind": "place", "title": "旧铺子", "status": "picked",
                 "source": {"type": "link", "url": "https://example.org/p", "license": "未核，只作写作参考"},
                 "observation": {"scope": "none"}, "take": [{"part": "布局：柜台在下方", "scope": "stable"}],
                 "decision": DECISION, "use": [{"chapter": 7, "scene": "S1"}], "conflicts": ["图里有电灯，本书没有电"]}
        self.save(dict(LIB2, entries=[entry]))
        self.assertEqual(self.card(7), "- **Scene ID**：S1\n- **看得见、摸得到的东西**：（L-1）布局：柜台在下方（稳定）（看图：没看图）\n"
                         "- **出处**：灵感库 L-1（网页 https://example.org/p，授权：未核，只作写作参考）\n"
                         "- **和已定设定不一样的**：L-1：图里有电灯，本书没有电\n")

    def test_an_r560_library_with_unclear_and_established(self):  # LIB-01, B-02: three changes, the rest as before
        digest = "a" * 64
        entry = {"id": "IMG-1", "kind": "place", "title": "修车铺门口", "status": "picked",
                 "source": {"type": "author_file", "file": "images/door.png", "sha256": digest, "creator": "作者",
                            "license": "作者自己的图"},
                 "image": {"sha256": digest},
                 "observation": {"scope": "original", "image_sha256": digest, "seen": "檐下一条长凳", "unclear": "门头的字看不清",
                                 "by": "工坊", "date": "2026-10-23"},
                 "take": [{"part": "布局：门挨着长凳", "scope": "stable"}], "decision": DECISION,
                 "established": [{"part": "布局：门挨着长凳", "where": "项目档案：修车铺", "chapter": 3}],
                 "use": [{"chapter": 3, "scene": "S1"}, {"chapter": 4, "scene": "S2"}], "conflicts": []}
        self.save(dict(LIB2, entries=[entry]))
        r560 = ("- **Scene ID**：S2\n- **看得见、摸得到的东西**：（IMG-1）布局：门挨着长凳（稳定）（看图：看了原图）\n"
                "- **出处**：灵感库 IMG-1（作者的图 images/door.png）\n- **和已定设定不一样的**：无\n")  # r5.60's output
        expected = (r560.replace("（稳定）（看图：看了原图）", "（稳定；第 3 章已成本书事实，照前文写）（照前文写，不说重新看过图）")
                    .replace("灵感库 IMG-1（作者的图 images/door.png）", "前文（第 3 章，项目档案：修车铺；当初照灵感库 IMG-1）")
                    + "- **图里看不清的**：IMG-1：门头的字看不清\n")
        self.assertEqual(self.card(4), expected)

    def test_an_r560_library_established_in_this_chapter_or_a_later_one(self):  # LIB-12, B-02 (pkg1 check, point 1)
        digest = "a" * 64  # no unclear: only the mark changes, in the chapter it became the book's fact and before it
        entry = {"id": "IMG-1", "kind": "place", "title": "修车铺门口", "status": "picked",
                 "source": {"type": "author_file", "file": "images/door.png", "sha256": digest, "creator": "作者",
                            "license": "作者自己的图"},
                 "image": {"sha256": digest},
                 "observation": {"scope": "original", "image_sha256": digest, "seen": "檐下一条长凳", "by": "工坊",
                                 "date": "2026-10-23"},
                 "take": [{"part": "布局：门挨着长凳", "scope": "stable"}], "decision": DECISION,
                 "established": [{"part": "布局：门挨着长凳", "where": "项目档案：修车铺", "chapter": 3}],
                 "use": [{"chapter": 2, "scene": "S1"}, {"chapter": 3, "scene": "S1"}], "conflicts": []}
        self.save(dict(LIB2, entries=[entry]))
        r560 = ("- **Scene ID**：S1\n- **看得见、摸得到的东西**：（IMG-1）布局：门挨着长凳（稳定）（看图：看了原图）\n"
                "- **出处**：灵感库 IMG-1（作者的图 images/door.png）\n- **和已定设定不一样的**：无\n")  # r5.60's output
        for chapter in (2, 3):
            with self.subTest(chapter=chapter):
                self.assertEqual(self.card(chapter), r560.replace("（稳定）", "（稳定；第 3 章已采纳）"))

    def test_a_format_1_library_prints_as_before(self):  # EDIT-10; the text is r5.60's output
        v1 = {"schema": "inspiration-library/1", "book": "测试", "entries": [
            {"id": "V-1", "kind": "place", "title": "铺子", "status": "picked", "visible": "柜台在下方", "subject": "铺子",
             "source": {"type": "link", "url": "https://example.org/p", "license": "未核，只作写作参考"},
             "take": ["布局"], "use": [{"chapter": 7, "scene": "S1"}], "conflicts": ["图里树叶正绿"]},
            {"id": "V-2", "kind": "light", "title": "灯", "status": "picked", "visible": "一盏灯", "subject": "铺子",
             "source": {"type": "link", "url": "https://example.org/q", "license": "未核，只作写作参考"},
             "use": [{"chapter": 7, "scene": "S1"}], "conflicts": ["图里树叶正绿"]},
            {"id": "V-3", "kind": "light", "title": "夜", "status": "to_find", "subject": "铺子",
             "source": {"type": "search", "queries": ["夜 铺子"]}, "use": [{"chapter": 7}], "conflicts": []}]}
        self.save(v1)
        self.assertEqual(self.card(7), "- **Scene ID**：S1\n- **看得见、摸得到的东西**：（V-1）布局\n"
                         "- **出处**：灵感库 V-1（网页 https://example.org/p，授权：未核，只作写作参考）\n"
                         "- **和已定设定不一样的**：V-1：图里树叶正绿\n\n"
                         "挑过但没写借哪几样的（不写进素材，先请作者说借哪几样，不按整张写）：\n- V-2 灯（旧版选过）\n\n"
                         "还没找到图的（搜索词）：\n- V-3 夜：夜 铺子\n")

    def test_a_format_1_library_lists_each_conflict_as_before(self):  # EDIT-10 (pkg1 check, point 2); r5.60's output
        v1 = {"schema": "inspiration-library/1", "book": "测试", "entries": [
            {"id": "V-1", "kind": "place", "title": "铺子", "status": "picked", "visible": "柜台在下方", "subject": "铺子",
             "source": {"type": "link", "url": "https://example.org/p", "license": "未核，只作写作参考"},
             "take": ["布局"], "use": [{"chapter": 7, "scene": "S1"}], "conflicts": ["图里树叶正绿", "图里树叶正绿"]},
            {"id": "V-2", "kind": "light", "title": "灯", "status": "picked", "visible": "一盏灯", "subject": "铺子",
             "source": {"type": "link", "url": "https://example.org/q", "license": "未核，只作写作参考"},
             "take": ["光"], "use": [{"chapter": 7, "scene": "S1"}], "conflicts": ["图里 树叶正绿"]}]}
        self.save(v1)
        self.assertEqual(self.card(7), "- **Scene ID**：S1\n- **看得见、摸得到的东西**：（V-1）布局；（V-2）光\n"
                         "- **出处**：灵感库 V-1（网页 https://example.org/p，授权：未核，只作写作参考）；"
                         "灵感库 V-2（网页 https://example.org/q，授权：未核，只作写作参考）\n"
                         "- **和已定设定不一样的**：V-1：图里树叶正绿；V-1：图里树叶正绿；V-2：图里 树叶正绿\n")


class Writer(Book):
    def test_waiting_and_to_find_entries_can_be_written(self):  # LIB-07, LIB-13
        to_find = {"id": "Q-1", "kind": "light", "title": "雨夜的修车铺门口", "status": "to_find",
                   "source": {"type": "search", "queries": ["修车铺 雨夜 灯"]}, "use": [{"chapter": 7}], "conflicts": []}
        code, report, _ = self.adopt({"record": [{"id": "N-1", "entry": dict(CHAT, use=[{"chapter": 7}])},
                                                 {"id": "Q-1", "entry": to_find}]})
        self.assertEqual((code, report["status"], report["recorded"]), (0, "OK", ["N-1", "Q-1"]), report)
        self.assertEqual(run(READ, "check", self.library)[1]["status"], "OK")
        card = self.card(7)
        self.assertIn("看过了、等作者挑的（不写进素材，先请作者说借哪几样）：\n- N-1 修车铺门口\n", card)
        self.assertIn("还没找到图的", card)
        self.assertNotIn("Scene ID", card)  # nothing is material until the author chooses
        code, report, _ = self.adopt({"record": [{"id": "N-1", "entry": dict(CHAT, status="picked")}]})
        self.assertEqual((code, report["error"]), (2, "N-1: a record item is {id, entry}: the whole entry, with status "
                         "candidate (looked at, waiting for the author to choose) or to_find (search words, no image "
                         "yet); the author's choice goes under adopt"))
        code, report, _ = self.adopt({"adopt": [{"id": "N-1", "take": [{"part": BENCH, "scope": "stable"}]}]})
        self.assertEqual(report["status"], "OK", report)  # chosen later: the id and take are enough
        code, report, _ = self.adopt({"record": [{"id": "N-1", "entry": CHAT}]})
        self.assertEqual((code, report["error"]), (2, "N-1 is picked in the library: record only adds an entry, or "
                         "renews one that still waits (candidate, to_find); the author's choices are changed under "
                         "adopt, reject or withdraw; nothing written"))
        code, report, _ = self.adopt({})
        self.assertEqual((code, report["error"]), (2, "the selection adopts, rejects, withdraws or establishes nothing "
                         "(r5.61: nor records an entry waiting for the author or still to find under record, nor notes "
                         "a draft under drafted)"))

    def chosen(self, take=((BENCH, "stable"),)):
        item = {"id": "N-1", "entry": CHAT, "take": [{"part": p, "scope": s} for p, s in take], "skip": ["门头的字"],
                "use": [{"chapter": 7, "scene": "S2"}]}
        self.assertEqual(self.adopt({"adopt": [item]})[1]["status"], "OK")
        return item

    def test_the_same_selection_twice_changes_nothing(self):  # LIB-09
        item = self.chosen()
        before = self.library.read_bytes()
        code, report, _ = self.adopt({"adopt": [item]})
        self.assertEqual((code, report["status"], report["revision"]), (0, "UNCHANGED", 1), report)
        self.assertEqual(self.library.read_bytes(), before)
        for other in (dict(item, take=[{"part": HOOKS, "scope": "scene"}]), dict(item, use=[{"chapter": 8}]),
                      dict(item, skip=["门头的字", "卷帘门"]), dict(item, take=item["take"] + [{"part": HOOKS, "scope": "stable"}])):
            with self.subTest(other=other):
                code, report, _ = self.adopt({"adopt": [other]})
                self.assertEqual(code, 2)
                self.assertIn("already picked", report["error"])  # as before: the author says add, replace or use
        # written with a note: the same note again is unchanged, another note is a difference (pkg1 check, point 5)
        noted = dict(item, id="N-2", entry=dict(CHAT, id="N-2"), note="长凳先借，挂钩以后再说")
        self.assertEqual(self.adopt({"adopt": [noted]})[1]["status"], "OK")
        code, report, _ = self.adopt({"adopt": [noted]})
        self.assertEqual((code, report["status"]), (0, "UNCHANGED"), report)
        code, report, _ = self.adopt({"adopt": [dict(noted, note="作者又说了一句")]})
        self.assertEqual(code, 2, report)
        self.assertIn("already picked", report["error"])

    def test_what_went_into_a_draft_and_what_became_fact(self):  # LIB-08, LIB-12
        self.chosen(((BENCH, "stable"), (HOOKS, "stable")))
        notes = {"by": "工坊", "date": "2026-10-24"}
        drafts = [{"id": "N-1", "part": BENCH, "chapter": 7, "scene": "S2", "draft": "第七章修订稿"},
                  {"id": "N-1", "part": HOOKS, "chapter": 7, "scene": "S2", "draft": "第七章修订稿", "state": "unused"}]
        self.assertEqual(self.adopt({"decision": notes, "drafted": drafts})[1]["status"], "OK")
        entry = self.data()["entries"][0]
        self.assertEqual(entry["decision"], DECISION)  # the workshop's note does not replace the author's choice
        self.assertEqual([d["state"] for d in entry["drafted"]], ["used", "unused"])
        card = self.card(7)
        self.assertIn("%s（稳定；写进过第 7 章的稿，作者还没采纳，不当前文）" % BENCH, card)
        self.assertIn("这一章交过稿、作者还没采纳的（不算本书事实；定稿以后请作者说哪几样留下，再记 establish）：\n"
                      "- N-1 %s（第七章修订稿，S2）\n" % BENCH, card)
        self.assertIn("借了、这一章的稿里没用上的：\n- N-1 %s（第七章修订稿，S2）\n" % HOOKS, card)
        self.assertNotIn("前文（", card)
        self.assertEqual(self.adopt({"decision": notes, "drafted": [drafts[0]]})[1]["status"], "UNCHANGED")  # no repeat
        code, report, _ = self.adopt({"decision": notes, "drafted": [dict(drafts[0], part="门头的字")]})
        self.assertEqual((code, report["error"]), (2, "N-1: 门头的字 is not one of the parts the author took (%s；%s)"
                                                   % (BENCH, HOOKS)))
        code, report, _ = self.adopt({"decision": notes, "drafted": [dict(drafts[0], id="N-9")]})
        self.assertEqual((code, report["error"]), (2, "N-9: only a picked entry's parts are written into a draft"))
        code, report, _ = self.adopt({"decision": notes, "drafted": [dict(drafts[0], state="maybe")]})
        self.assertEqual((code, report["error"]), (2, "N-1: a drafted item is {id, part, chapter, scene, draft, state: "
                         "used|unused, date}: a part taken from this entry and written into a draft the author has not "
                         "accepted yet (state unused: taken, not used in that draft)"))
        # the author accepts chapter 7 with the bench; chapter 8 uses the same image
        self.adopt({"establish": [{"id": "N-1", "part": BENCH, "where": "项目档案：修车铺", "chapter": 7}]})
        self.adopt({"adopt": [{"id": "N-1", "mode": "use", "use": [{"chapter": 8, "scene": "S1"}]}]})
        self.assertNotIn("这一章交过稿", self.card(7))  # accepted now
        card = self.card(8)
        self.assertIn("%s（稳定；第 7 章已成本书事实，照前文写）" % BENCH, card)
        self.assertIn("；其中已成本书事实的出处写前文：%s（第 7 章，项目档案：修车铺）" % BENCH, card)
        self.assertIn("看图：", card)  # the hooks still come from the image
        self.adopt({"establish": [{"id": "N-1", "part": HOOKS, "where": "项目档案：修车铺", "chapter": 7}]})
        card = self.card(8)
        self.assertIn("- **出处**：前文（第 7 章，项目档案：修车铺；当初照灵感库 N-1）\n", card)
        self.assertIn("照前文写，不说重新看过图", card)
        self.assertNotIn("看图：", card)

    def test_unclear_is_brought_along_and_a_conflict_is_listed_once(self):  # LIB-11, LIB-13 (EDIT-10)
        entries = []
        for n in (1, 2, 3):
            look = dict(LOOK, unclear="挂钩上挂的是什么看不清") if n < 3 else LOOK
            entries.append(dict(CHAT, id="N-%d" % n, status="picked", observation=look, decision=DECISION,
                                take=[{"part": "布局%d" % n, "scope": "scene", "taken_for": [{"chapter": 7 if n != 2 else 9}]}],
                                use=[{"chapter": 7}], conflicts=["图里树叶正绿，这一场在腊月"] + (["另一句"] if n == 3 else [])))
        self.save(dict(LIB2, entries=entries))
        card = self.card(7)
        self.assertEqual(card.count("图里树叶正绿，这一场在腊月"), 1)
        self.assertIn("N-1、N-2、N-3：图里树叶正绿，这一场在腊月；N-3：另一句", card)
        self.assertIn("- **图里看不清的**：N-1：挂钩上挂的是什么看不清\n", card)  # N-2 brings nothing here: its unclear stays out
        self.assertIn("看图：看了对话里的图（是原图还是缩小过的说不清；没有文件，没有绑定哈希）", card)
        for shown, words in (("original", "原图"), ("reduced", "缩小过的")):
            entries[0]["observation"] = dict(LOOK, shown_as=shown)
            self.save(dict(LIB2, entries=entries))
            self.assertIn("看图：看了对话里的图（%s；没有文件，没有绑定哈希）" % words, self.card(7))

    def test_a_conflict_that_differs_only_in_spaces_is_listed_once(self):  # LIB-11 (pkg1 check, point 3)
        said = ("图里树叶正绿，这一场在腊月", "图里 树叶正绿，这一场在腊月", "图里树叶正绿，　这一场在腊月 ")
        self.save(dict(LIB2, entries=[dict(CHAT, id="N-%d" % n, status="picked", decision=DECISION, use=[{"chapter": 7}],
                                           take=[{"part": "布局%d" % n, "scope": "stable"}], conflicts=[words])
                                      for n, words in enumerate(said, 1)]))
        self.assertIn("- **和已定设定不一样的**：N-1、N-2、N-3：图里树叶正绿，这一场在腊月\n", self.card(7))  # the first one's words

    def test_the_block_goes_into_a_filled_card_and_the_gate_reads_it(self):  # LIB-11 (the gate's script is not changed)
        guard = load(SCRIPTS / "workflow_guard.py", "nw_guard_r561")
        self.chosen(((BENCH, "stable"), (HOOKS, "scene")))
        entry = self.data()
        entry["entries"][0]["observation"] = dict(LOOK, unclear="挂钩上挂的是什么看不清")
        entry["entries"][0]["conflicts"] = ["图里树叶正绿，这一场在腊月"]
        self.save(entry)
        self.adopt({"decision": {"by": "工坊", "date": "2026-10-24"},
                    "drafted": [{"id": "N-1", "part": BENCH, "chapter": 7, "scene": "S2", "draft": "第七章初稿"}]})
        block = self.card(7)
        self.assertIn("图里看不清的", block)
        head = ("# 声音样本与现场素材卡\n\n## 声音样本：作者自己的原文\n\n- **样本来源**：第 3 章第 2—6 行\n"
                "- **原文**：卷帘门拉下一半，雨水顺着铁皮檐往下滴。\n\n- **从样本里看出来的**：短句，台词不带“说”。\n\n"
                "## 现场素材：每个核心场一块\n\n")
        found, problems = guard.read_material_card(head + block)
        self.assertEqual((found["scenes"], problems), (["S2"], []))

    def test_one_command_for_an_image_the_author_gave(self):  # LIB-10
        inbox = self.root / "inbox"
        inbox.mkdir()
        picture = T.picture("shop") if T.Image else b"not decoded here"
        (inbox / "铺子.png").write_bytes(picture)
        common = ["add-image", self.library, "--image", inbox / "铺子.png"]
        code, report, _ = run(WRITE, *common, "--if-revision", 0, "--title", "修车铺门口", "--seen", "门边一条长凳",
                              "--by", "工坊", "--chapter", 7)
        self.assertEqual((code, report["status"], report["recorded_as"]), (0, "OK", "candidate"), report)
        digest = hashlib.sha256(picture).hexdigest()
        self.assertEqual((report["id"], report["file"], report["file_copied"]), ("IMG-" + digest[:10], "images/铺子.png", True))
        self.assertEqual((self.library.parent / "images" / "铺子.png").read_bytes(), picture)
        self.assertEqual(run(READ, "check", self.library)[1]["status"], "OK")
        choice = ["--if-revision", 1, "--id", report["id"], "--take", "布局：门边一条长凳=stable", "--words", "要布局",
                  "--chapter", 7]
        code, report, _ = run(WRITE, "add-image", self.library, *choice)
        self.assertEqual((report["status"], report["recorded_as"]), ("OK", "picked"), report)
        choice[1] = 2
        self.assertEqual(run(WRITE, "add-image", self.library, *choice)[1]["status"], "UNCHANGED")
        self.assertIn("布局：门边一条长凳（稳定）（看图：看了原图）", self.card(7))
        # a write that does not happen leaves no copied file behind
        (inbox / "灯.png").write_bytes(b"x" * 10)
        code, report, _ = run(WRITE, "add-image", self.library, "--image", inbox / "灯.png", "--if-revision", 0,
                              "--title", "灯", "--seen", "一盏灯", "--by", "工坊")
        self.assertEqual(code, 3)
        self.assertFalse((self.library.parent / "images" / "灯.png").exists())
        # nor a dry run, nor a write the check refuses: a chapter 0 is written as given, and the check says so (pkg1
        # check, points 4 and 5)
        images = self.library.parent / "images"
        files = sorted(images.iterdir())
        lamp = ["add-image", self.library, "--image", inbox / "灯.png", "--if-revision", 2, "--title", "灯",
                "--seen", "一盏灯", "--by", "工坊"]
        code, report, _ = run(WRITE, *lamp, "--dry-run")
        self.assertEqual((code, report["status"], report["file_copied"]), (0, "DRY-RUN", False), report)
        self.assertEqual(sorted(images.iterdir()), files)
        code, report, _ = run(WRITE, *lamp, "--chapter", 0)
        self.assertEqual((code, report["status"]), (1, "PROBLEMS"), report)
        self.assertIn("each use is {chapter: a positive number, scene: a Scene ID}", "\n".join(report["problems"]))
        self.assertEqual(sorted(images.iterdir()), files)
        self.assertEqual(self.data()["revision"], 2)
        code, report, _ = run(WRITE, "add-image", self.library, "--chat", REF, "--id", "N-9", "--if-revision", 2,
                              "--title", "修车铺门口", "--seen", SEEN, "--by", "工坊")
        self.assertEqual(report["status"], "OK", report)
        entry = next(e for e in self.data()["entries"] if e["id"] == "N-9")
        self.assertEqual((entry["source"]["type"], entry["observation"]["scope"], entry["observation"]["shown_as"],
                          "image" in entry), ("author_chat", "conversation", "unknown", False))
        # what is refused, each with its own words (B-04, B-20)
        new = ["add-image", self.library, "--chat", REF, "--id", "N-10", "--if-revision", 3]
        full = ["--title", "灯", "--seen", "一盏灯", "--by", "工坊"]
        refused = {
            "--mode use only adds where an entry is used: write it in a selection file (adopt with mode use, no take)":
                new + full + ["--take", "灯=scene", "--words", "要灯", "--mode", "use"],
            "--title is needed for a new entry (a few words that name it)": new + full[2:],
            "--seen is needed for a new entry (what the image shows is written only after looking at it)":
                new + full[:2] + full[4:],
            "--by is needed for a new entry (who looked at the image)": new + full[:4],
            "--take records the author's choice: give the author's own words with --words": new + full + ["--take", "灯=scene"],
            "give --image (a file) or --chat (which message of the conversation showed it), not both":
                new + full + ["--image", inbox / "灯.png"],
            "--image %s is not a file" % (inbox / "没有这张.png"):
                ["add-image", self.library, "--image", inbox / "没有这张.png", "--if-revision", 3] + full,
            "--scene is a scene of a chapter: give --chapter with it": new + full + ["--scene", "S1"],  # pkg1 check, point 4
        }
        for message, argv in refused.items():
            with self.subTest(message=message):
                code, report, _ = run(WRITE, *argv)
                self.assertEqual((code, report["error"]), (2, message))
        code, report, _ = run(WRITE, *new, *full, "--take", "灯")
        self.assertEqual(code, 2)
        self.assertTrue(report["error"].startswith('--take is "part=stable" or "part=scene"'), report)
        self.assertEqual(self.data()["revision"], 3)  # none of them wrote anything

    def test_add_image_records_a_web_image_and_an_image_the_host_drew(self):  # LIB-10 (--source web, generated)
        base = ["add-image", self.library, "--chat", REF, "--title", "修车铺门口", "--seen", SEEN, "--by", "工坊",
                "--date", "2026-11-26"]
        code, report, _ = run(WRITE, *base, "--id", "W-1", "--if-revision", 0, "--source", "web",
                              "--url", "https://example.org/shop")
        self.assertEqual((code, report["status"], report["recorded_as"]), (0, "OK", "candidate"), report)
        entry = self.data()["entries"][0]
        self.assertEqual(entry["source"], {"type": "link", "url": "https://example.org/shop", "license": "未核，只作写作参考",
                                           "retrieved": "2026-11-26"})
        self.assertEqual((entry["observation"]["scope"], "image" in entry), ("conversation", False))
        code, report, _ = run(WRITE, *base, "--id", "W-2", "--if-revision", 1, "--source", "web")
        self.assertEqual((code, report["error"]), (2, "--source web needs --url (the page the image is on)"))
        (self.root / "w.png").write_bytes(b"fetched")
        code, report, _ = run(WRITE, "add-image", self.library, "--image", self.root / "w.png", "--if-revision", 1,
                              "--source", "web", "--url", "https://example.org/shop", "--title", "t", "--seen", "s",
                              "--by", "工坊")
        self.assertEqual(code, 2)
        self.assertTrue(report["error"].startswith("a web image that was fetched comes through visual_materials_cli.py"))
        code, report, _ = run(WRITE, *base, "--id", "G-1", "--if-revision", 1, "--source", "generated", "--asked-by", "作者")
        self.assertEqual((code, report["error"]), (2, "an image the host drew says who asked for it (--asked-by) and the "
                                                      "words used (--prompt)"))
        code, report, _ = run(WRITE, *base, "--id", "G-1", "--if-revision", 1, "--source", "generated",
                              "--asked-by", "作者", "--prompt", "雨夜修车铺门口的示意图")
        self.assertEqual(report["status"], "OK", report)
        entry = next(e for e in self.data()["entries"] if e["id"] == "G-1")
        self.assertEqual(entry["source"], {"type": "host_generated", "asked_by": "作者", "date": "2026-11-26",
                                           "prompt": "雨夜修车铺门口的示意图"})
        code, report, _ = run(WRITE, "add-image", self.library, "--id", "G-1", "--if-revision", 2, "--take",
                              "布局：檐下一条长凳=stable", "--words", "照这张图的布局", "--chapter", 7)
        self.assertEqual(report["status"], "OK", report)
        self.assertIn("灵感库 G-1（宿主画的图，2026-11-26，作者让画的；不当真实场所、年代、器物的依据）", self.card(7))
        # a drawn image with a file is bound like the author's file
        (self.root / "g.png").write_bytes(b"drawn here")
        code, report, _ = run(WRITE, "add-image", self.library, "--image", self.root / "g.png", "--if-revision", 3,
                              "--source", "generated", "--asked-by", "作者", "--prompt", "门口的示意图", "--title", "示意图",
                              "--seen", "门口一条长凳", "--by", "工坊")
        self.assertEqual(report["status"], "OK", report)
        entry = next(e for e in self.data()["entries"] if e["id"] == report["id"])
        self.assertEqual((entry["source"]["type"], entry["source"]["file"], entry["observation"]["scope"]),
                         ("host_generated", "images/g.png", "original"))
        self.assertEqual(run(READ, "check", self.library)[1]["status"], "OK")

    def test_add_image_run_again_adds_conflicts_and_leaves_nothing_out(self):  # LIB-10 (the comparison run)
        """Run again for an entry already in the library (the author says which parts, and only now that a part does
        not fit the book's setting): the conflicts, suggestions and subjects given are added; a flag that says
        something else than the record is refused, as is a flag the source does not keep. Nothing given is left out
        without a word."""
        (self.root / "棚.png").write_bytes(b"a made-up picture of a shed")
        first = ["add-image", self.library, "--image", self.root / "棚.png", "--title", "河边的棚子", "--seen",
                 "四根竹竿撑着一块油布，棚下一只铁皮桶", "--by", "工坊"]
        code, report, _ = run(WRITE, *first, "--if-revision", 0)
        self.assertEqual((code, report["recorded_as"]), (0, "candidate"), report)
        shed = report["id"]
        late = "图里树叶正绿，这一场在腊月，以设定为准"
        choice = ["--id", shed, "--take", "布局：竹竿撑着油布=stable", "--words", "要它的棚子", "--chapter", 5]
        # the same command again (the page says so), with the conflict the author's words brought up
        code, report, _ = run(WRITE, *first, "--if-revision", 1, *choice, "--conflict", late)
        self.assertEqual((code, report["status"], report["recorded_as"]), (0, "OK", "picked"), report)
        self.assertEqual(report["added_to_record"], {"conflicts": [late]})
        entry = self.data()["entries"][0]
        self.assertEqual((entry["conflicts"], entry["title"], entry["observation"]["seen"]),
                         ([late], "河边的棚子", "四根竹竿撑着一块油布，棚下一只铁皮桶"))
        self.assertIn("- **和已定设定不一样的**：%s：%s\n" % (shed, late), self.card(5))
        self.assertEqual(run(WRITE, "add-image", self.library, "--if-revision", 2, *choice, "--conflict", late)[1]["status"],
                         "UNCHANGED")
        more = ["add-image", self.library, "--if-revision", 2, *choice, "--conflict", "另一句"]
        code, report, _ = run(WRITE, *more)
        self.assertEqual(code, 2)
        self.assertTrue(report["error"].startswith("%s is already picked" % shed), report)  # a change asks for a mode
        code, report, _ = run(WRITE, *more, "--mode", "add")
        self.assertEqual((code, report["status"]), (0, "OK"), report)
        self.assertEqual(self.data()["entries"][0]["conflicts"], [late, "另一句"])
        refused = {
            "%s is already in the library and its record says otherwise for --title, --seen: add-image does not rewrite "
            "a record (give what it says, or leave these out); nothing written" % shed:
                ["--id", shed, "--title", "棚子", "--seen", "一只桶", "--take", "布局：竹竿撑着油布=stable", "--words", "要"],
            "%s is already in the library and its record says otherwise for --image: add-image does not rewrite a "
            "record (give what it says, or leave these out); nothing written" % shed:
                ["--id", shed, "--image", self.root / "别的.png", "--take", "布局：竹竿撑着油布=stable", "--words", "要"],
            "%s is picked: what is added to its record (--conflict) goes in with the author's choice, --take (with "
            "--mode add for an entry already picked); nothing written" % shed: ["--id", shed, "--conflict", "第三句"],
        }
        (self.root / "别的.png").write_bytes(b"another made-up picture")
        for message, argv in refused.items():
            with self.subTest(message=message[:40]):
                code, report, _ = run(WRITE, "add-image", self.library, "--if-revision", 3, *argv)
                self.assertEqual((code, report["error"]), (2, message))
        self.assertFalse((self.library.parent / "images" / "别的.png").exists())
        # an image seen only in the conversation, still waiting: renewed with what was added (record)
        code, report, _ = run(WRITE, "add-image", self.library, "--chat", REF, "--id", "N-7", "--if-revision", 3,
                              "--title", "修车铺门口", "--seen", SEEN, "--by", "工坊")
        self.assertEqual(report["status"], "OK", report)
        code, report, _ = run(WRITE, "add-image", self.library, "--id", "N-7", "--if-revision", 4, "--conflict", late,
                              "--suggest", "檐下的长凳")
        self.assertEqual((code, report["recorded_as"], report["added_to_record"]),
                         (0, "candidate", {"conflicts": [late], "suggest": ["檐下的长凳"]}), report)
        # and picked later with one more conflict and a subject: added whatever the look's scope (in the conversation)
        code, report, _ = run(WRITE, "add-image", self.library, "--chat", REF, "--id", "N-7", "--if-revision", 5,
                              "--take", "%s=stable" % BENCH, "--words", "长凳要", "--chapter", 5, "--conflict", "另一句",
                              "--subject", "修车铺门口")
        self.assertEqual((code, report["recorded_as"]), (0, "picked"), report)
        entry = next(e for e in self.data()["entries"] if e["id"] == "N-7")
        self.assertEqual((entry["conflicts"], entry["suggest"], entry["subjects"], entry["observation"]),
                         ([late, "另一句"], ["檐下的长凳"], ["修车铺门口"], dict(LOOK, date=entry["observation"]["date"])))
        self.assertEqual(run(READ, "check", self.library)[1]["status"], "OK")
        # flags a new entry's source does not keep are refused, not left out
        new = ["add-image", self.library, "--if-revision", 6, "--title", "灯", "--seen", "一盏灯", "--by", "工坊"]
        chat = new + ["--chat", REF, "--id", "N-8"]
        (self.root / "灯.png").write_bytes(b"a made-up lamp")
        not_kept = {
            "--url is the page a web image is on (--source web); where the author got an image is --origin; nothing "
            "written": chat + ["--url", "https://example.org/lamp"],
            "--asked-by and --prompt are for an image the host drew (--source generated); nothing written":
                chat + ["--prompt", "一盏灯"],
            "an image the host drew keeps who asked for it and the words used (--asked-by, --prompt), not --creator or "
            "--license; nothing written": chat + ["--source", "generated", "--asked-by", "作者", "--prompt", "一盏灯",
                                                  "--license", "随便用"],
            "--shown-as is for an image seen only in the conversation (--chat); a file is the original; nothing "
            "written": new + ["--image", self.root / "灯.png", "--shown-as", "reduced"],
            "--name is the file name under images/ for --image; nothing written": chat + ["--name", "灯.png"],
            "--skip, --adapt, --words and --mode belong to the author's choice: give --take with them":
                chat + ["--mode", "add"],
        }
        for message, argv in not_kept.items():
            with self.subTest(message=message[:40]):
                code, report, _ = run(WRITE, *argv)
                self.assertEqual((code, report["error"]), (2, message))
        self.assertEqual(self.data()["revision"], 6)  # none of them wrote anything
        self.assertFalse((self.library.parent / "images" / "灯.png").exists())

    def test_a_scene_the_workshop_named_itself(self):  # B-19
        self.chosen()
        for scene in ("改1", "S1（工坊编的，原稿第 1—9 段）"):
            with self.subTest(scene=scene):
                code, report, _ = self.adopt({"adopt": [{"id": "N-1", "mode": "use", "use": [{"chapter": 9, "scene": scene}]}]})
                self.assertEqual(report["status"], "OK", report)
                self.assertEqual(run(READ, "check", self.library)[1]["status"], "OK")
                self.assertIn("- **Scene ID**：%s\n" % scene, self.card(9, "--scene", scene))

    def test_the_samples_are_accepted(self):  # LIB-21
        sample = json.loads((SKILL / "assets" / "inspiration-selection.example.json").read_text(encoding="utf-8"))
        path = self.root / "sample.json"
        self.save(sample, path)
        code, report, _ = run(WRITE, "adopt", self.library, "--selection", path, "--if-revision", 0)
        self.assertEqual((code, report["status"]), (0, "OK"), report)
        self.assertEqual(run(READ, "check", self.library)[1]["status"], "OK")
        request = json.loads((SKILL / "assets" / "visual-request.example.json").read_text(encoding="utf-8"))
        vm("common").check_request(request)
        vm("common").check_request({k: v for k, v in dict(request, pages=["https://example.org/a"]).items() if k != "queries"})
        for name in ("visual-request.example.json", "visual-choice.example.json", "inspiration-selection.example.json"):
            text = (SKILL / "assets" / name).read_text(encoding="utf-8")
            parts = re.findall(r'"part": "([^"]*)"', text)
            self.assertFalse([p for p in parts if "左" in p or "右" in p], name)  # B-11: no left and right of a picture
            self.assertIn("修车铺", text, name)  # one made-up scene in all three: a repair shop's doorway at night


class HandNotes(Book):
    """HOST-05: notes kept in the card's own format (assets/visual-notes-card.md section 4), merged one by one."""

    KINDS = {"地方": "place", "光": "light", "物件": "prop", "人物": "person"}

    def labels(self):
        card = (SKILL / "assets" / "visual-notes-card.md").read_text(encoding="utf-8")
        block = card[card.index("```text\n") + len("```text\n"):]
        return [line.split("：", 1)[0] for line in block[:block.index("```")].splitlines()]

    def note(self, **values):
        labels = self.labels()
        self.assertEqual(set(values), set(labels))
        return "\n".join("%s：%s" % (label, values[label]) for label in labels)

    def entry(self, text):
        """The entry a note becomes, field by field as the card's section 4 says."""
        f = dict(line.split("：", 1) for line in text.splitlines())
        number, date = re.match(r"(\S+?)，(\d{4}-\d{2}-\d{2})", f["手记编号和日期"]).groups()
        kind, subject, title = f["哪一类、给谁用、一句标题"].split("；")
        where = f["图从哪来"]
        if where.startswith("作者在对话里发的"):
            source = {"type": "author_chat", "ref": re.search(r"（(.+)）", where).group(1)}
        elif where.startswith("网页上的"):
            source = {"type": "link", "url": re.search(r"https://\S+?(?=[；）])", where).group(0), "license": "未核，只作写作参考"}
        elif where.startswith("宿主画的"):
            asked, prompt = re.search(r"（(.+?)让画的；用的话：(.+)）", where).groups()
            source = {"type": "host_generated", "asked_by": asked, "date": date, "prompt": prompt}
        else:
            source = {"type": "search", "queries": re.search(r"搜索词：(.+)）", where).group(1).split("、")}
        status = {"待找": "to_find", "看过了等作者挑": "candidate", "作者挑中": "picked", "作者不要": "rejected"}[f["状态"]]
        entry = {"id": number, "kind": self.KINDS[kind], "title": title, "subjects": [subject],
                 "status": "candidate" if status != "to_find" else "to_find", "source": source, "use": [], "conflicts": []}
        chapter, scene = re.match(r"第 (\d+) 章 (\S+)", f["用在哪里"]).groups()
        place = {"chapter": int(chapter), "scene": scene}
        if f["看的是什么、谁看的"].startswith("看了对话里的图"):
            by = f["看的是什么、谁看的"].rsplit("；", 1)[1]
            entry["observation"] = {"scope": "conversation", "ref": "%s 的对话（%s）" % (date, number), "shown_as": "unknown",
                                    "seen": f["看到的"], "by": by, "date": date}
            if f["看不清的"] != "无":
                entry["observation"]["unclear"] = f["看不清的"]
        if f["网页上的文字"] != "无":
            entry["page_text"] = f["网页上的文字"]
        if f["适合借的"] != "无":
            entry["suggest"] = [f["适合借的"]]
        if f["和设定不一样的"] != "无":
            entry["conflicts"] = [f["和设定不一样的"]]
        take = [{"part": p.split("（")[0], "scope": "stable" if "稳定" in p else "scene"} for p in f["借哪几样"].split("、")
                if p != "无"]
        words = f["作者的原话和日期"]
        return entry, status, place, take, words

    def merge(self, text):
        entry, status, place, take, words = self.entry(text)
        if status == "picked":
            selection = {"decision": dict(DECISION, words=words), "adopt": [{"id": entry["id"], "entry": entry,
                                                                              "take": take, "use": [place]}]}
        elif status == "rejected":
            selection = {"decision": dict(DECISION, words=words), "reject": [{"id": entry["id"], "entry": entry}]}
        else:
            entry["use"] = [place]
            selection = {"decision": {"by": "工坊", "date": "2026-11-26"}, "record": [{"id": entry["id"], "entry": entry}]}
        code, report, _ = self.adopt(selection)
        self.assertEqual((code, report["status"]), (0, "OK"), report)

    def blank(self, number, kind_subject_title, where, look, status, take="无", words="无"):
        return self.note(**{"手记编号和日期": "%s，2026-11-26（手记，没经脚本核，没有绑定哈希）" % number,
                            "哪一类、给谁用、一句标题": kind_subject_title, "图从哪来": where, "看的是什么、谁看的": look,
                            "看到的": SEEN if look != "没看到" else "", "看不清的": "挂钩上挂的是什么看不清" if look != "没看到" else "无",
                            "网页上的文字": "无", "适合借的": "无", "借哪几样": take, "不借的": "无", "本书怎样改": "无",
                            "和设定不一样的": "无", "作者的原话和日期": words, "用在哪里": "第 7 章 S2",
                            "写进了哪一稿": "无", "成了本书事实的": "无", "状态": status, "并进库没有": "还没并进库"})

    def test_four_notes_and_one_turned_down_go_into_an_empty_library(self):
        looked = "看了对话里的图（是原图还是缩小过的说不清）；工坊"
        notes = [
            self.blank("N-01", "地方；修车铺门口；檐下的长凳", "作者在对话里发的（2026-11-26 的对话第 3 条）", looked, "作者挑中",
                       BENCH + "（稳定的）", "长凳要"),
            self.blank("N-02", "地方；修车铺门口；对面的铺面", "网页上的（来源页 https://example.org/street；作者和许可：未核）",
                       looked, "看过了等作者挑"),
            self.blank("N-03", "地方；修车铺门口；门口的示意图", "宿主画的（作者让画的；用的话：雨夜修车铺门口的示意图）", looked,
                       "作者挑中", HOOKS + "（只用这一场）", "挂钩用这一场"),
            self.blank("N-04", "光；修车铺门口；雨夜檐下的灯", "还没找到（搜索词：修车铺 雨夜 灯、repair shop doorway lamp）",
                       "没看到", "待找"),
            self.blank("N-05", "地方；修车铺门口；另一间铺子", "作者在对话里发的（2026-11-26 的对话第 5 条）", looked, "作者不要",
                       "无", "这张不要"),
        ]
        for text in notes:
            self.merge(text)
        code, report, _ = run(READ, "check", self.library)
        self.assertEqual((code, report["status"]), (0, "OK"), report)
        by = {e["id"]: e for e in self.data()["entries"]}
        self.assertEqual({k: (e["status"], e["title"]) for k, e in by.items()},
                         {"N-01": ("picked", "檐下的长凳"), "N-02": ("candidate", "对面的铺面"), "N-03": ("picked", "门口的示意图"),
                          "N-04": ("to_find", "雨夜檐下的灯"), "N-05": ("rejected", "另一间铺子")})  # the notes' own ids
        card = self.card(7)
        self.assertIn("灵感库 N-01（作者在对话里发的图，没有文件：2026-11-26 的对话第 3 条）", card)
        self.assertIn("灵感库 N-03（宿主画的图，2026-11-26，作者让画的；不当真实场所、年代、器物的依据）", card)
        self.assertIn("看过了、等作者挑的（不写进素材，先请作者说借哪几样）：\n- N-02 对面的铺面\n", card)
        self.assertIn("还没找到图的（搜索词）：\n- N-04 雨夜檐下的灯", card)
        self.assertNotIn("N-05", card)


@unittest.skipIf(T.Image is None, "Pillow is not installed")
class Chain(T.Base):
    def limited(self, headers):
        return vm("common").Response(429, dict({"Content-Type": "application/json"}, **headers), b"{}", "stand-in", 1)

    def test_a_rate_limit_stops_that_search_and_says_how_long(self):  # LIB-14
        request = dict(T.REQUEST, queries={"searxng": ["一", "二", "三"], "openverse": ["a", "b", "c"]})
        report, run_dir, stand, cfg = self.searched(sx=self.limited({"Retry-After": "120"}), ov=self.limited({}),
                                                    request=request)
        self.assertEqual(len(stand.asked), 2)  # one request each; the other words were not sent
        self.assertEqual(report["status"], "failed")
        record = json.loads((run_dir / "search.json").read_text(encoding="utf-8"))
        self.assertEqual(record["stopped"]["searxng"]["retry_after_seconds"], 120)
        self.assertIn("retry_at", record["stopped"]["searxng"])
        self.assertEqual((record["stopped"]["openverse"]["retry_after_seconds"], record["stopped"]["openverse"]["not_sent"]),
                         (None, 2))
        self.assertEqual([r["status"] for r in record["providers"]["openverse"]["requests"]],
                         ["rate_limited", "not_sent", "not_sent"])
        self.assertIn("服务让等 120 秒", report["next"])
        self.assertIn("服务没说要等多久", report["next"])
        # one search limited, the other goes on with all its words
        self.root = self.root / "second"
        self.root.mkdir()
        report, run_dir, stand, cfg = self.searched(ov=self.limited({"Retry-After": "30"}), request=request)
        self.assertEqual((report["status"], sum("sx.example.org" in u for u in stand.asked)), ("partial", 3))

    def test_a_refusal_does_not_stop_the_search(self):  # LIB-14 (only the limit stops; B-03)
        request = dict(T.REQUEST, queries={"searxng": ["一", "二", "三"], "openverse": ["a", "b", "c"]})
        report, run_dir, stand, cfg = self.searched(sx=T.response(403), ov=T.response(401), request=request)
        self.assertEqual((sum("sx.example.org" in u for u in stand.asked), sum("ov.example.org" in u for u in stand.asked)),
                         (3, 3))  # every word was sent, as in r5.60
        record = json.loads((run_dir / "search.json").read_text(encoding="utf-8"))
        self.assertNotIn("stopped", record)
        self.assertEqual([r["status"] for r in record["providers"]["searxng"]["requests"]], ["json_disabled"] * 3)
        self.assertEqual([r["status"] for r in record["providers"]["openverse"]["requests"]], ["forbidden"] * 3)
        self.assertFalse([p for p in record["providers"].values() if "stopped" in p])
        self.assertNotIn("stopped", report)
        source = (SCRIPTS / "visual_materials" / "common.py").read_text(encoding="utf-8")
        self.assertIn("def stop_search(record, queries, headers=None, wall=None):", source)  # no other reason to stop

    def test_a_request_with_source_pages_only(self):  # LIB-17, LIB-18 (HOST-16)
        common = vm("common")
        request = {"schema": "visual-request/1", "chapter": 7, "scene": "S1", "pages": ["https://page.example.org/shop"]}

        def no_search(*a, **k):
            raise AssertionError("no search request is made")

        report = vm("search").run_search(request, T.config(), self.root / "run", fetch=no_search)
        self.assertEqual((report["status"], report["candidates"]), ("pages_only", 0))
        self.assertEqual(report["next"], "没有搜索词，没发搜索请求；接着 collect 读请求里的来源页")
        self.assertEqual(report["providers"], {"searxng": "not_asked", "openverse": "not_asked"})
        for name in ("run.json", "search.json", "candidates.json"):
            self.assertTrue((self.root / "run" / name).is_file(), name)
        report = vm("search").run_search(dict(request, queries={"searxng": [], "openverse": []}), T.config(),
                                         self.root / "run2", fetch=no_search)
        self.assertEqual(report["status"], "pages_only")
        # on the command line: exit 0; with neither queries nor pages, exit 2 and the answer names pages
        path = self.root / "request.json"
        path.write_bytes(json.dumps(request).encode("utf-8"))
        code, out, text = run(CLI, "search", "--request", path, "--out", self.root / "run3")
        self.assertEqual((code, out["status"]), (0, "pages_only"), text)
        path.write_bytes(json.dumps({"schema": "visual-request/1", "chapter": 7}).encode("utf-8"))
        code, out, text = run(CLI, "search", "--request", path, "--out", self.root / "run4")
        self.assertEqual(code, 2, text)
        self.assertEqual(out["error"], "queries is {searxng: [...], openverse: [...]}: a few short search words for each "
                                       "search (a request without search words names the source pages to read in pages)")
        with self.assertRaises(common.VisualError) as caught:
            common.check_request(dict(T.REQUEST, queries=["词"]))
        self.assertEqual(str(caught.exception), "queries is {searxng: [...], openverse: [...]}: a few short search words "
                                                "for each search")  # the wrong shape: the same answer as before
        with self.assertRaises(common.VisualError) as caught:
            common.check_request({"chapter": 7, "queries": {"searxng": ["词"]}})
        self.assertEqual(str(caught.exception), 'the request is an object with schema visual-request/1: this one has no '
                                                'schema; add "schema": "visual-request/1" (a sample: '
                                                'assets/visual-request.example.json)')
        with self.assertRaises(common.VisualError) as caught:
            common.check_request(dict(T.REQUEST, schema="visual-request/2"))
        self.assertEqual(str(caught.exception), "the request is an object with schema visual-request/1: this one says "
                                                "schema 'visual-request/2'")

    def chain(self):
        report, run_dir, stand, cfg = self.searched()
        vm("collect").run_collect(run_dir, cfg, fetch=stand, crawl=lambda p, c: ([], None))
        codes = [run(CLI, step, "--run", run_dir) for step in ("dedupe", "rank")]
        vm("review").run_bundle(run_dir, cfg)
        obs = json.loads((run_dir / "review" / "observations.json").read_text(encoding="utf-8"))
        obs["items"][0].update(scope="original", seen="柜台在下方", by="工坊（测试）")
        (self.root / "obs.json").write_bytes(json.dumps(obs, ensure_ascii=False).encode("utf-8"))
        vm("review").record_observations(run_dir, cfg, self.root / "obs.json")
        choice = json.loads((SKILL / "assets" / "visual-choice.example.json").read_text(encoding="utf-8"))
        choice.update(bundle_id=obs["bundle_id"], choose=choice["choose"][:1], reject=[])
        (self.root / "choice.json").write_bytes(json.dumps(choice, ensure_ascii=False).encode("utf-8"))
        vm("selection").run_select(run_dir, cfg, self.root / "choice.json")  # the sample choice is accepted (LIB-21)
        library = self.root / "library.json"
        library.write_bytes(json.dumps({"schema": "inspiration-library/2", "book": "测试", "revision": 0,
                                        "entries": []}).encode("utf-8"))
        return run_dir, library, codes

    def test_an_optional_step_that_is_not_installed_is_not_a_failure(self):  # LIB-15
        run_dir, library, codes = self.chain()
        if not T.has("imagehash"):
            self.assertEqual((codes[0][0], codes[0][1]["status"], codes[0][1]["optional_step_skipped"]),
                             (0, "not_installed", True))
            self.assertIn("没装 ImageHash，这一步跳过", codes[0][1]["next"])
        if not (T.has("open_clip") and T.has("torch")):
            self.assertEqual((codes[1][0], codes[1][1]["status"], codes[1][1]["clip_used"], codes[1][1]["optional_step_skipped"]),
                             (0, "DEPENDENCY_MISSING", False, True))
        self.assertIn('"MODEL_ERROR"', CLI.read_text(encoding="utf-8"))  # a configured model that fails is still exit 1
        report = vm("verify").run_verify(run_dir)
        self.assertFalse(report["components"]["imagehash"]["live_verified"] and report["components"]["openclip"]["live_verified"])

    def test_the_receipt_stays_and_the_run_check_beside_the_five(self):  # LIB-19, LIB-20
        run_dir, library, codes = self.chain()
        first = vm("adopt").run_adopt(run_dir, library, 0)
        receipt = json.loads((run_dir / "adopt.json").read_text(encoding="utf-8"))
        again = vm("adopt").run_adopt(run_dir, library, 1)
        self.assertEqual((first["status"], again["status"]), ("OK", "UNCHANGED"), again)
        self.assertTrue(again["receipt"].startswith("kept: this selection was written as revision 1"), again)
        kept = json.loads((run_dir / "adopt.json").read_text(encoding="utf-8"))
        self.assertEqual((kept["status"], kept["operation_id"], len(kept["later_tries"])), ("OK", receipt["operation_id"], 1))
        stale = vm("adopt").run_adopt(run_dir, library, 0)
        self.assertEqual(stale["status"], "CONFLICT")
        self.assertEqual(json.loads((run_dir / "adopt.json").read_text(encoding="utf-8"))["status"], "OK")
        self.assertEqual(len(json.loads((run_dir / "run.json").read_text(encoding="utf-8"))["adoptions"]), 3)
        report = vm("verify").run_verify(run_dir)
        self.assertEqual((report["status"], report["all_five_live"], report["chain"]["complete"]), ("NOT_ALL_LIVE", False, True))
        check = report["run_check"]
        self.assertEqual((check["status"], check["stand_in"], check["not_verified"]), ("RUN_STEPS_VERIFIED", True, {}))
        self.assertIn("不等于五项接通", check["summary"])
        self.assertIn("这次运行用的是测试替身，不是真实服务", check["summary"])
        self.assertEqual(run(CLI, "verify-run", "--run", run_dir)[0], 1)  # the exit code still follows the five
        self.assertEqual(run(CLI, "verify-run", "--run", run_dir, "--this-run")[0], 2)  # no such switch (F8)
        image = next((run_dir / "images").iterdir())
        image.write_bytes(T.picture("door"))
        report = vm("verify").run_verify(run_dir)
        self.assertEqual(report["run_check"]["status"], "RUN_STEPS_NOT_VERIFIED")

    def test_a_run_that_only_searched_is_not_verified(self):  # LIB-20 (B-14)
        request = {"schema": "visual-request/1", "chapter": 7, "scene": "S1", "pages": ["https://page.example.org/shop"]}
        vm("search").run_search(request, T.config(), self.root / "pages", fetch=T.Stand({}))
        check = vm("verify").run_verify(self.root / "pages")["run_check"]
        self.assertEqual(check["status"], "RUN_STEPS_NOT_VERIFIED")
        self.assertIn("没发搜索请求", check["did_no_work"]["search"])
        self.assertIn("这一次只跑了搜索，还没有能核的图的文件", check["summary"])
        self.assertEqual(run(CLI, "verify-run", "--run", self.root / "pages")[0], 1)
        report, run_dir, stand, cfg = self.searched()
        self.assertEqual(report["status"], "ok")
        check = vm("verify").run_verify(run_dir)["run_check"]
        self.assertEqual((check["status"], check["verified"]), ("RUN_STEPS_NOT_VERIFIED", ["search"]))
        self.assertIn("这一次只跑了搜索", check["summary"])

    def test_doctor_says_what_it_did_not_check(self):  # LIB-16
        report = vm("doctor").run_doctor(T.config())
        self.assertIn("searxng、openverse 只看了地址填没填，没发请求", report["summary"])
        self.assertEqual(report["components"]["openverse"]["checked"], "address only: no request was made")
        self.assertEqual(report["pillow_installed"], True)
        down = T.Stand({"https://": vm("common").NetworkError("no route")})
        report = vm("doctor").run_doctor(T.config(), probe=True, fetch=down)
        self.assertIn("openverse 的探测没通", report["summary"])
        code = ("import sys; sys.modules['PIL'] = None; sys.path.insert(0, %r); import json; "
                "from visual_materials import doctor, common; "
                "print(json.dumps(doctor.run_doctor(common.load_config(None))['summary'], ensure_ascii=False))" % str(SCRIPTS))
        proc = subprocess.run([sys.executable, "-I", "-B", "-c", code], capture_output=True, text=True, encoding="utf-8")
        self.assertIn("没装 Pillow：collect 取到的图解不了码", proc.stdout, proc.stderr)


class PagesThenCollect(hygiene.LocalServerBase):  # LIB-18 (HOST-16): the host searched, the scripts fetch
    def test_collect_reads_the_pages_of_a_request_without_search_words(self):
        self.a.routes.update({
            "/robots.txt": (200, {"Content-Type": "text/plain"}, b"User-agent: *\nAllow: /\n"),
            "/doorway.html": (200, {"Content-Type": "text/html; charset=utf-8"},
                              '<figure><img src="/bench.png" alt="长凳" width="400"><figcaption>檐下的长凳</figcaption>'
                              '</figure>'.encode("utf-8")),
            "/bench.png": hygiene.PNG_ANSWER})
        request = {"schema": "visual-request/1", "chapter": 7, "scene": "S2", "pages": [self.a.url("/doorway.html")]}
        cfg = hygiene.config(page_reader={"use": "builtin"})
        folder = self.root / "run"
        report = vm("search").run_search(request, cfg, folder)
        self.assertEqual(report["status"], "pages_only")
        self.assertEqual(self.a.seen, [])  # the search step asked nobody
        sess, _ = self.sess(cfg)
        vm("collect").run_collect(folder, cfg, session=sess)
        record = json.loads((folder / "collect.json").read_text(encoding="utf-8"))
        self.assertEqual({p["page_url"]: p["status"] for p in record["pages"]}, {self.a.url("/doorway.html"): "ok"})
        fetched = {f["url"]: f["status"] for f in record["fetched"]}
        self.assertEqual(fetched.get(self.a.url("/bench.png")), "ok")
        candidates = json.loads((folder / "candidates.json").read_text(encoding="utf-8"))
        items = candidates["candidates"] if isinstance(candidates, dict) else candidates
        self.assertIn(self.a.url("/bench.png"), [c.get("image_url") for c in items])
        self.assertFalse(vm("verify").run_verify(folder)["all_five_live"])  # a local test run never counts as live


OLD_INTRO = ("本文件已展开 Markdown 写作方法与模板，后文按来源文件名标记。请使用内嵌内容，无需另读这些文件。具体项目由用户另行提供；"
             "导出和执行检查脚本属于文件夹版，纯聊天模式不执行脚本，不冒称程序检查或自动存档。末尾的上游许可仅用于保留版权与许可通知，"
             "不是写作指令。")
NEW_LINE = "找图、写灵感库的脚本也不在本文件里：没有脚本时怎样看图、找图、记图，见后文的看图与手记卡（visual-notes-card.md）。"
CARD = "assets/visual-notes-card.md"
SAMPLES = ("assets/visual-request.example.json", "assets/visual-choice.example.json",
           "assets/inspiration-selection.example.json")


class SingleFile(unittest.TestCase):  # HOST-34, HOST-35, LIB-21
    @classmethod
    def setUpClass(cls):
        cls.exporter = load(SCRIPTS / "export_portable.py", "export_portable_r561")
        cls.files = {}
        with tempfile.TemporaryDirectory() as tmp:
            for mode in ("personal", "sale"):
                target = Path(tmp) / (mode + ".zip")
                cls.exporter.export(SKILL, target, mode=mode)
                with zipfile.ZipFile(target) as archive:
                    cls.files[mode] = (archive.read("portable-novel-workshop.md").decode("utf-8"),
                                       {PurePosixPath(n).as_posix() for n in archive.namelist()})

    def test_the_opening_says_the_scripts_are_not_here(self):
        for mode, (single, _) in self.files.items():
            intro = single.split("\n\n")[1]
            self.assertTrue(intro.startswith(OLD_INTRO), mode)
            self.assertEqual(intro.count(NEW_LINE), 1, mode)
            self.assertLess(intro.index("风格包和任何一本书的项目包都不展开在本文件里。"), intro.index(NEW_LINE), mode)
            self.assertFalse([w for w in HARD if w in NEW_LINE])

    def test_the_card_sits_after_the_revision_card(self):
        for mode, (single, names) in self.files.items():
            marker = "# 内嵌内容：" + CARD
            self.assertEqual(single.count(marker), 1, mode)
            at = single.index(marker)
            self.assertLess(single.index("# 内嵌内容：assets/revision-card.md"), at, mode)
            self.assertLess(at, single.index("# 内嵌内容：CONSTITUTION.md"), mode)
            self.assertLess(at, len(single) * 0.06, mode)
            self.assertIn("novel-workshop/" + CARD, names, mode)
            for sample in SAMPLES:  # an export carries a file once a page links to it; never twice in the single file
                self.assertLessEqual(single.count("# 内嵌内容：" + sample), 1, (mode, sample))

    def test_the_sale_list(self):
        self.assertLessEqual({CARD, *SAMPLES}, set(self.exporter.SALE_FILES))
        self.assertEqual(self.exporter.VISUAL_NOTES_CARD, CARD)


if __name__ == "__main__":
    unittest.main()

"""Shared pieces: the config, the run folder, budgets, HTTP with limits, and what may leave the machine."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import urllib.error
import urllib.parse
import urllib.request

CONFIG_SCHEMA = "visual-materials-config/1"
REQUEST_SCHEMA = "visual-request/1"
RUN_SCHEMA = "visual-run/1"
KINDS = ("place", "person", "prop", "light", "other")
DEFAULT_BUDGETS = {"max_candidates": 40, "max_pages": 10, "max_images": 20, "max_reviews": 8, "recommend_min": 4,
                   "recommend_max": 6}
DEFAULTS = {
    "searxng": {"url": "", "categories": "images", "language": "", "safesearch": 1, "engines": "", "time_range": "",
                "pages": 1},
    "openverse": {"endpoint": "https://api.openverse.org/v1/images/", "client_id_env": "OPENVERSE_CLIENT_ID",
                  "client_secret_env": "OPENVERSE_CLIENT_SECRET", "license_type": "", "page_size": 20},
    "network": {"timeout_seconds": 20, "retries": 1, "max_image_bytes": 15000000, "max_json_bytes": 5000000,
                "user_agent": "novel-workshop-visual-materials/1", "blocked_hosts": []},
    "crawl4ai": {"headless": True, "page_timeout_ms": 30000, "wait_for_images": True, "scan_full_page": True,
                 "check_robots_txt": True, "images_per_page": 3},
    "imagehash": {"algorithms": ["phash", "dhash"], "hash_size": 8, "max_distance": 8},
    "openclip": {"model": "ViT-B-32", "pretrained": "laion2b_s34b_b79k", "weights_path": "", "weights_sha256": "",
                 "allow_download": False, "cache_dir": "", "device": "cpu", "text_weight": 0.5, "reference_weight": 0.5},
    "review": {"mode": "host"},
    "budgets": DEFAULT_BUDGETS,
}
HASH_ALGORITHMS = ("phash", "dhash", "ahash", "whash")
# What a new result of a step makes stale: the files the later steps made from the old one (the r5.35 review, point 1:
# after a new fetch, new groups, a new order or a rebuilt bundle, the old observations and choices must not carry over
# to other images). They are moved into outdated/<time>-<step>/, never deleted, and run.json marks those steps outdated.
DOWNSTREAM = {
    "collect": ("dedupe.json", "rank.json", "review", "selection.json", "verify.json"),
    "dedupe": ("rank.json", "review", "selection.json", "verify.json"),
    "rank": ("review", "selection.json", "verify.json"),
    "review_bundle": ("review/bundle.json", "review/review.md", "review/observations.json",
                      "review/observations.recorded.json", "selection.json", "verify.json"),
    "review_record": ("selection.json", "verify.json"),
    "select": ("verify.json",),
}
STEPS_MADE_BY = {"dedupe.json": ("dedupe",), "rank.json": ("rank",), "review": ("review_bundle", "review_record"),
                 "review/bundle.json": ("review_bundle",), "review/observations.recorded.json": ("review_record",),
                 "selection.json": ("select",)}
# What a search may carry: a few words about what to look at, never chapters of the book.
MAX_QUERY_CHARS = 80
MAX_TEXT_QUERY_CHARS = 200
MAX_QUERIES = 8


class VisualError(ValueError):
    """A request, config or run that cannot be used; the message says what to fix."""


def now():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def today():
    return datetime.date.today().isoformat()


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    try:
        return json.loads(Path(path).read_bytes().decode("utf-8-sig"))
    except (OSError, UnicodeError, ValueError) as exc:
        raise VisualError("cannot read %s: %s" % (path, exc)) from exc


def write_json(path, data):
    path = Path(path)
    tmp = path.with_name("%s.tmp-%d" % (path.name, os.getpid()))
    tmp.write_bytes((json.dumps(data, ensure_ascii=False, indent=1) + "\n").encode("utf-8"))
    os.replace(str(tmp), str(path))


def merged(defaults, given):
    out = {}
    for key, value in defaults.items():
        if isinstance(value, dict):
            out[key] = merged(value, (given or {}).get(key) or {})
        else:
            out[key] = (given or {}).get(key, value)
    return out


def load_config(path=None):
    """The config file merged over the defaults. Keys and passwords never go into it: only the names of the
    environment variables that hold them."""
    data = {}
    if path:
        data = read_json(path)
        if not isinstance(data, dict) or data.get("schema") != CONFIG_SCHEMA:
            raise VisualError("the config is an object with schema %s" % CONFIG_SCHEMA)
        unknown = set(data) - set(DEFAULTS) - {"schema", "note"}
        if unknown:
            raise VisualError("unknown config section(s) %s" % ", ".join(sorted(unknown)))
        text = json.dumps(data, ensure_ascii=False)
        if re.search(r'"(?:client_secret|api_key|token|password)"\s*:\s*"[^"]+"', text):
            raise VisualError("the config holds a secret; put it in an environment variable and name the variable "
                              "(client_secret_env) instead")
    config = merged(DEFAULTS, data)
    budgets = config["budgets"]
    for key, value in budgets.items():
        if type(value) is not int or value < 1:
            raise VisualError("budgets.%s must be a positive whole number" % key)
    if budgets["recommend_min"] > budgets["recommend_max"]:
        raise VisualError("budgets.recommend_min is more than recommend_max")
    hashing = config["imagehash"]
    algorithms = hashing.get("algorithms")
    if not (isinstance(algorithms, list) and algorithms and all(a in HASH_ALGORITHMS for a in algorithms)):
        raise VisualError("imagehash.algorithms is a nonempty list of %s (an unknown name would leave nothing to compare)"
                          % ", ".join(HASH_ALGORITHMS))
    if type(hashing.get("hash_size")) is not int or hashing["hash_size"] < 4:
        raise VisualError("imagehash.hash_size is a whole number of at least 4")
    if type(hashing.get("max_distance")) is not int or hashing["max_distance"] < 0:
        raise VisualError("imagehash.max_distance is a whole number of bits (0 or more)")
    return config


def sanitized_config(config):
    """The config as recorded in a run: no environment values, only their names."""
    return json.loads(json.dumps(config))


def check_request(request):
    """A chapter's request: what to look for, a few short queries per search, an optional text for similarity and
    optional reference images. Long text is refused so that chapters do not go to search services by accident."""
    if not isinstance(request, dict) or request.get("schema") != REQUEST_SCHEMA:
        raise VisualError("the request is an object with schema %s" % REQUEST_SCHEMA)
    allowed = {"schema", "chapter", "scene", "kind", "subjects", "purpose", "queries", "text_query", "reference_images",
               "pages", "note"}
    unknown = set(request) - allowed
    if unknown:
        raise VisualError("unknown request field(s) %s" % ", ".join(sorted(unknown)))
    chapter = request.get("chapter")
    if chapter is not None and (type(chapter) is not int or chapter < 1):
        raise VisualError("chapter is a positive whole number")
    if request.get("kind", "place") not in KINDS:
        raise VisualError("kind is one of %s" % ", ".join(KINDS))
    queries = request.get("queries")
    if not isinstance(queries, dict) or not set(queries) <= {"searxng", "openverse"} or not any(queries.values()):
        raise VisualError("queries is {searxng: [...], openverse: [...]}: a few short search words for each search")
    for provider, words in queries.items():
        if not isinstance(words, list) or not all(isinstance(w, str) and w.strip() for w in words):
            raise VisualError("queries.%s is a list of search words" % provider)
        if len(words) > MAX_QUERIES:
            raise VisualError("queries.%s has more than %d queries" % (provider, MAX_QUERIES))
        for word in words:
            if len(word) > MAX_QUERY_CHARS or "\n" in word:
                raise VisualError("a query is longer than %d characters or has a line break: send a few words about "
                                  "what to look at, not text from the book" % MAX_QUERY_CHARS)
    text = request.get("text_query")
    if text is not None and (not isinstance(text, str) or len(text) > MAX_TEXT_QUERY_CHARS or "\n" in text):
        raise VisualError("text_query is one line of at most %d characters" % MAX_TEXT_QUERY_CHARS)
    for key in ("subjects", "reference_images", "pages"):
        value = request.get(key, [])
        if not isinstance(value, list) or not all(isinstance(v, str) and v.strip() for v in value):
            raise VisualError("%s is a list of strings" % key)
    for page in request.get("pages", []):
        if not re.match(r"^https?://\S+$", page):
            raise VisualError("pages are http(s) addresses of source pages to read")
    return request


class Response:
    def __init__(self, status, headers, body, url, elapsed_ms):
        self.status, self.headers, self.body, self.url, self.elapsed_ms = status, headers, body, url, elapsed_ms

    def json(self):
        try:
            return json.loads(self.body.decode("utf-8"))
        except (UnicodeError, ValueError) as exc:
            raise VisualError("not JSON: %s" % exc) from exc


class Timeout(Exception):
    pass


class TooLarge(Exception):
    pass


class NetworkError(Exception):
    pass


def blocked(url, config):
    host = urllib.parse.urlsplit(url).hostname or ""
    return any(host == h or host.endswith("." + h) for h in config["network"].get("blocked_hosts", []))


def http(url, config, headers=None, data=None, max_bytes=None, method=None):
    """One HTTP request with the config's timeout and size limit, tried again network.retries times after a timeout,
    a dropped connection or a 5xx answer. Raises Timeout, TooLarge or NetworkError; an HTTP error status comes back
    as a Response."""
    tries = max(0, int(config["network"].get("retries", 1))) + 1
    for attempt in range(tries):
        try:
            response = _http_once(url, config, headers, data, max_bytes, method)
        except (Timeout, NetworkError):
            if attempt + 1 == tries:
                raise
            continue
        if response.status >= 500 and attempt + 1 < tries:
            continue
        return response


def _http_once(url, config, headers=None, data=None, max_bytes=None, method=None):
    if not re.match(r"^https?://", url or ""):
        raise NetworkError("not an http(s) address: %r" % url)
    if blocked(url, config):
        raise NetworkError("the host is blocked in the config")
    limit = max_bytes or config["network"]["max_json_bytes"]
    request = urllib.request.Request(url, data=data, method=method,
                                     headers=dict({"User-Agent": config["network"]["user_agent"]}, **(headers or {})))
    start = datetime.datetime.now()
    try:
        with urllib.request.urlopen(request, timeout=config["network"]["timeout_seconds"]) as response:
            body = response.read(limit + 1)
            status, head = response.status, dict(response.headers.items())
    except urllib.error.HTTPError as exc:
        body = exc.read(limit + 1) if exc.fp else b""
        status, head = exc.code, dict(exc.headers.items()) if exc.headers else {}
    except (socket.timeout, TimeoutError) as exc:
        raise Timeout(str(exc)) from exc
    except urllib.error.URLError as exc:
        if isinstance(exc.reason, (socket.timeout, TimeoutError)):
            raise Timeout(str(exc.reason)) from exc
        raise NetworkError(str(exc.reason)) from exc
    except (OSError, ValueError) as exc:
        raise NetworkError(str(exc)) from exc
    if len(body) > limit:
        raise TooLarge("more than %d bytes" % limit)
    elapsed = int((datetime.datetime.now() - start).total_seconds() * 1000)
    return Response(status, head, body, url, elapsed)


def clean_url(url):
    """An address as recorded: no user, password or key-like query values."""
    parts = urllib.parse.urlsplit(url)
    query = [(k, "***" if re.search(r"key|token|secret|password|sig", k, re.I) else v)
             for k, v in urllib.parse.parse_qsl(parts.query, keep_blank_values=True)]
    netloc = parts.hostname or ""
    if parts.port:
        netloc += ":%d" % parts.port
    return urllib.parse.urlunsplit((parts.scheme, netloc, parts.path, urllib.parse.urlencode(query), ""))


class Run:
    """A run folder: run.json (the request, the config used, the steps), candidates.json and one file per step."""

    def __init__(self, folder):
        self.folder = Path(folder)

    def path(self, name):
        return self.folder / name

    def exists(self, name):
        return self.path(name).is_file()

    def load(self, name):
        if not self.exists(name):
            raise VisualError("%s has no %s yet: run the step that makes it first" % (self.folder, name))
        return read_json(self.path(name))

    def save(self, name, data):
        self.folder.mkdir(parents=True, exist_ok=True)
        write_json(self.path(name), data)

    def manifest(self):
        return self.load("run.json")

    def step(self, name, record):
        data = self.manifest()
        data.setdefault("steps", {})[name] = dict(record, time=now())
        self.save("run.json", data)

    def candidates(self):
        return self.load("candidates.json")["candidates"] if self.exists("candidates.json") else []

    def outdate(self, step):
        """Before step runs again: move what the later steps made from the old results into outdated/<time>-<step>/,
        and mark those steps outdated in run.json. Returns the moved names."""
        moved = []
        stamp = "%s-%s" % (datetime.datetime.now().strftime("%Y%m%dT%H%M%S%f"), step)
        target = self.folder / "outdated" / stamp
        number = 1
        while target.exists():
            number += 1
            target = self.folder / "outdated" / ("%s-%d" % (stamp, number))
        for name in DOWNSTREAM.get(step, ()):
            source = self.path(name)
            if source.exists():
                destination = target / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                os.replace(str(source), str(destination))
                moved.append(name)
        if moved and self.exists("run.json"):
            data = self.manifest()
            where = target.relative_to(self.folder).as_posix()
            for name in moved:
                for made_by in STEPS_MADE_BY.get(name, ()):
                    if made_by in data.get("steps", {}):
                        data["steps"][made_by] = dict(data["steps"][made_by], status="outdated", outdated_by=step,
                                                      moved_to=where)
            data.setdefault("outdated", []).append({"time": now(), "by": step, "files": moved, "to": where})
            self.save("run.json", data)
        return moved

    def save_candidates(self, items):
        self.save("candidates.json", {"schema": "visual-candidates/1", "candidates": items})

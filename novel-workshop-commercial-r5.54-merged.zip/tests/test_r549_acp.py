"""r5.49 P1：Google AI（官方 ACP 运行时）连接原型。

行为检查在同目录的 acp_check.mjs：对着 fixtures/fake_acp_agent.mjs（工坊自己写的模拟 ACP 程序，不是 Google 的），
不联网，不下载、不启动任何 Google 程序。覆盖：分帧（中文、表情、四字节汉字在任意字节处拆开，粘包，半行，超长行，
不是协议的行，stderr 噪声）；找运行时（未安装、路径错误、校验不符、可启动，PATH 查找，Registry 发行包参数，Windows
.cmd 命令行的拼法——只是模拟）；握手、登录的几种结果、凭据失效、模型清单与配置失效、发送范围与快照、每轮新会话、
权限一律拒绝、停止与迟到消息、取消未确认、崩溃与超时的“结果未知”、额度受限暂停、“已真实接通”的判断、连接代次、
本机路由的页面令牌、只读模式不写文稿、检查脚本的退出码和报告。通过只说明工坊这一侧做对了，不算接通官方运行时，
也不算在 Windows 上跑过。没有 Node.js 18+ 时跳过。

第二轮（独立复审的 25 条和对照的 5 条）的行为也都在 acp_check.mjs 里：丢行和超长行、停止后仍交回整段、单实例锁和按字段
合并的记录、登录后重开会话、额度暂停跨重连和重启、出错前的半段、超上限只留连续前段、模型中途被换、SIGHUP 收尾、
页面不能改种类和开关、别的用户能改的程序不启动、去掉邮箱和 JWT、查版本也在空目录、Windows 收尾先后、启动前再核对、
--zip 只算校验值、终端登录照声明的命令、已真实接通只算这一次连接、写作台被杀后的结果未知和作者确认、事件记录换文件、
确认绑定收件方、坏记录报出来。

这里只查 Node 之外能查的：ACP 这条路不碰 Gemini API 和网络、不处理凭据、不带跳过权限的开关；启动器；两种导出
都带上新文件、不带测试用的模拟程序；页面不存令牌、自动互审是一行固定文字；关窗口的信号有人接；说明和 P0 记录一致。
"""
import importlib.util
import re
import shutil
import subprocess
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILL = HERE.parent / "skills" / "novel-workshop"
FOLDER = SKILL / "scripts" / "oh-story"
DASHBOARD = SKILL / "assets" / "dashboard"
ACP_MODULES = ("acp-assist.mjs", "acp-check.mjs", "acp-client.mjs", "acp-runtime.mjs", "acp-store.mjs")
NEW = tuple("scripts/oh-story/" + name for name in ACP_MODULES + ("check-acp.cmd", "check-acp.command"))
NODE = shutil.which("node")


def node_major():
    try:
        out = subprocess.run([NODE, "--version"], capture_output=True, text=True, encoding="utf-8", timeout=30).stdout
        return int(re.match(r"v(\d+)", out).group(1))
    except Exception:  # noqa: BLE001
        return 0


def code_lines(name):
    """The module without its comment lines (the comments name what the code must never do)."""
    text = (FOLDER / name).read_text(encoding="utf-8")
    return "\n".join(line for line in text.splitlines() if not line.lstrip().startswith("//"))


@unittest.skipUnless(NODE and node_major() >= 18, "需要 Node.js 18 或更新版本")
class AcpBehaviour(unittest.TestCase):
    def test_against_the_fake_agent(self):
        proc = subprocess.run([NODE, str(HERE / "acp_check.mjs"), str(SKILL)],
                              capture_output=True, text=True, encoding="utf-8", timeout=600)
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        summary = re.search(r"^(\d+) passed, (\d+) skipped, (\d+) failed \((\d+) total\)$", proc.stdout, re.M)
        self.assertIsNotNone(summary, proc.stdout[-3000:])
        passed, skipped, failed, total = (int(value) for value in summary.groups())
        self.assertEqual(failed, 0, proc.stdout)
        self.assertNotRegex(proc.stdout, r"(?m)^FAIL ")
        self.assertEqual(passed + skipped, total)
        self.assertGreaterEqual(total, 86)
        # 这台机器上查不了的几条（比如看不到 /proc）照实报成“跳过”，计进 unittest 的 skipped，不藏在“通过”里。
        skips = re.findall(r"(?m)^SKIP (.+)\n(原因：.+)$", proc.stdout)
        self.assertEqual(len(skips), skipped, proc.stdout)
        for name, reason in skips:
            with self.subTest(case=name[:60]):
                self.skipTest(f"acp_check.mjs 跳过了一条：{name}；{reason}")


class AcpPathStaysOffTheApi(unittest.TestCase):
    def test_no_gemini_api_and_no_network_of_its_own(self):
        for name in ACP_MODULES:
            code = code_lines(name)
            for imported in re.findall(r'import\s*\{([^}]*)\}\s*from\s*"\./gemini-assist\.mjs"', code):
                self.assertEqual([part.strip() for part in imported.split(",") if part.strip()], ["configDirectory"], name)
            for forbidden in ("reviseWithGemini", "listModels", "selfTest(", "generativelanguage", "GEMINI_API_KEY",
                              "x-goog-api-key", "node:http", "node:https", "node:net", "node:tls", "node:dgram", "fetch("):
                self.assertNotIn(forbidden, code, "%s: %s" % (name, forbidden))

    def test_no_credential_handling_and_no_permission_skipping(self):
        for name in ACP_MODULES:
            code = code_lines(name)
            for forbidden in ("cookie", "oauth_creds", "refresh_token", "credentials.json", ".gemini/", "--dangerously-skip-permissions",
                              "--add-dir", '"-p"', "set-cookie", "authorization"):
                self.assertNotIn(forbidden, code.lower(), "%s: %s" % (name, forbidden))
        runtime = (FOLDER / "acp-runtime.mjs").read_text(encoding="utf-8")
        flags = re.search(r"ALLOWED_FLAGS = Object\.freeze\(\[([^\]]*)\]\)", runtime).group(1)
        self.assertEqual(re.findall(r'"([^"]+)"', flags), ["--sandbox", "--disable-telemetry", "--process-per-session"])
        self.assertIn("shell: false", runtime)
        self.assertNotIn("shell: true", runtime)

    def test_client_declares_no_files_and_no_terminal(self):
        client = (FOLDER / "acp-client.mjs").read_text(encoding="utf-8")
        self.assertIn("fs: Object.freeze({ readTextFile: false, writeTextFile: false })", client)
        self.assertIn("terminal: false", client)
        self.assertNotIn("@agentclientprotocol/sdk\"", client)
        self.assertFalse((SKILL / "package.json").exists() or (FOLDER / "package.json").exists())


class Shutdown(unittest.TestCase):
    def test_server_and_launcher_handle_the_window_closing(self):
        server = (FOLDER / "dashboard-server.mjs").read_text(encoding="utf-8")
        self.assertIn('for (const signal of ["SIGINT", "SIGTERM", "SIGHUP", ...(process.platform === "win32" ? ["SIGBREAK"] : [])])', server)
        self.assertNotIn('process.once("SIGINT"', server)
        launcher = (FOLDER / "workbench.mjs").read_text(encoding="utf-8")
        self.assertEqual(launcher.count("waitForServer(child);"), 2)
        self.assertNotIn('child.on("exit", (code) => process.exit(code ?? 0));\n  }', launcher)
        # Windows 的 Ctrl+Break：启动器也接住，等服务收尾（REG-9）。
        self.assertIn('return ["SIGINT", "SIGTERM", "SIGHUP", ...(platform === "win32" ? ["SIGBREAK"] : [])];', launcher)
        self.assertIn("for (const signal of launcherSignals(platform))", launcher)

    def test_check_acp_cleans_up_when_interrupted(self):
        # check-acp 也启动官方程序：被打断时同样收尾（FIX-ACP-SEC-1、REG-4）。
        text = (FOLDER / "acp-check.mjs").read_text(encoding="utf-8")
        self.assertIn('return ["SIGINT", "SIGTERM", "SIGHUP", ...(platform === "win32" ? ["SIGBREAK"] : [])];', text)
        self.assertIn("for (const signal of interruptSignals()) process.on(signal, () => onSignal(signal));", text)
        self.assertIn('rl?.on("SIGINT", () => onSignal("SIGINT"));', text)
        self.assertIn("stopAllRuntimesSync();", text)


class Docs(unittest.TestCase):
    def test_the_verification_table_matches_the_p0_record(self):
        doc = (SKILL / "references" / "local-workbench.md").read_text(encoding="utf-8")
        self.assertNotIn("也没有下载 Google 的程序", doc)
        row = [line for line in doc.splitlines() if line.startswith("| ACP Registry 的 linux-x86_64 发行包")]
        self.assertEqual(len(row), 1)
        for fact in ("下载过", "SHA-256 和清单一致", "没有运行", "已删除"):
            self.assertIn(fact, row[0])
        self.assertIn("不保证一点不漏", doc)
        self.assertIn("同一台电脑上、以你的身份运行的别的程序", doc)
        # Windows 上还没堵上的地方要写明白（FIX-ACP-SEC-2）；同组可写只提醒（REG-11）；锁怎么清（RT-03）。
        for fact in ("不查文件夹的权限（ACL）", "**只防住一部分**", "同组的其他用户能改这个程序或文件夹", "页面拿令牌的方式这一版没有改", "删掉那个文件再试", "核对和系统真正打开文件之间还有极短的一下"):
            self.assertIn(fact, doc)


class Launchers(unittest.TestCase):
    def test_windows_launcher_is_ascii_crlf_and_waits(self):
        text = (FOLDER / "check-acp.cmd").read_bytes().decode("ascii")
        self.assertEqual(text.count("\r\n"), text.count("\n"))
        self.assertIn('node "%~dp0acp-check.mjs" %*', text)
        self.assertIn("pause", text.splitlines()[-1])

    def test_unix_launcher_runs_the_check(self):
        text = (FOLDER / "check-acp.command").read_text(encoding="utf-8")
        self.assertTrue(text.startswith("#!/bin/sh\n"))
        self.assertIn("exec node ./acp-check.mjs", text)


class Exports(unittest.TestCase):
    def exporter(self):
        spec = importlib.util.spec_from_file_location("export_portable_r549_acp", SKILL / "scripts" / "export_portable.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def test_both_profiles_carry_the_new_files_and_not_the_fake_agent(self):
        exporter = self.exporter()
        self.assertLessEqual(set(NEW), set(exporter.SALE_FILES))
        for mode in ("personal", "sale"):
            core = set(exporter.collect_core(SKILL, mode))
            self.assertLessEqual(set(NEW), core, mode)
            self.assertFalse([name for name in core if "fake_acp" in name or name.startswith("tests/")], mode)


class Page(unittest.TestCase):
    def test_the_page_keeps_the_token_in_memory_and_gets_no_secrets(self):
        app = (DASHBOARD / "app.js").read_text(encoding="utf-8")
        self.assertNotIn("generativelanguage.googleapis.com", app)
        self.assertNotIn("x-goog-api-key", app)
        for line in app.splitlines():
            if "localStorage" in line or "sessionStorage" in line:
                self.assertNotIn("token", line.lower(), line)
        self.assertIn('"X-Novel-Workshop-Token": token', app)

    def test_auto_review_is_one_fixed_line_not_a_switch(self):
        html = (DASHBOARD / "index.html").read_text(encoding="utf-8")
        self.assertEqual(html.count("自动互审"), 1)
        self.assertIn('<p id="acpAutoReview" class="acp-fixed">自动互审：关闭（订阅用途范围未确认）</p>', html)
        server = (FOLDER / "dashboard-server.mjs").read_text(encoding="utf-8")
        self.assertNotIn("auto-review", server)
        assist = (FOLDER / "acp-assist.mjs").read_text(encoding="utf-8")
        self.assertIn('AUTO_REVIEW = Object.freeze({ enabled: false, label: "自动互审：关闭（订阅用途范围未确认）" })', assist)

    def test_every_acp_post_needs_the_page_token(self):
        server = (FOLDER / "dashboard-server.mjs").read_text(encoding="utf-8")
        handler = server.split("async function handleAcpRequest", 1)[1].split("\nexport function createDashboardServer", 1)[0]
        self.assertLess(handler.index("assertPageRequest(request)"), handler.index('route === "token"'))
        self.assertLess(handler.index("assertAcpToken(request, token)"), handler.index("switch (route)"))
        self.assertIn("provider.saveConfig(body, { fromHttp: true })", handler)
        self.assertIn("timingSafeEqual", server)


if __name__ == "__main__":
    unittest.main()

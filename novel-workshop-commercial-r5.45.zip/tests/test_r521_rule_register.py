#!/usr/bin/env python3
"""r5.21: constitution NWC-1.2 (same-tier adjudication, rule intake and retirement) and the rule-conflict register.

On 2026-10-19 the author said the book's rule files had grown so numerous that they clash, and approved two additions
to the constitution: section 1 gains "同一层之内", the order for settling a clash between rules on the same tier
(a description is checked before it counts as a rule; newer beats older; specific beats general; what remains goes
to the author and neither side is applied meanwhile), and a new section 6 asks that rule files be registered on the
way in (checked against existing rules and the accepted text) and on the way out (superseded, not deleted). The
ten principles keep their titles; CON-008 gains a sentence and the new enforcement points.

The executable part is scripts/rule_register.py and the register format (assets/rule-conflicts-template.json):
- `check` refuses a register whose shape does not hold: unknown sources or texts, an open item without an ask or
  with a resolution, an open item that does not say what happens until the author decides, a workshop decision
  claiming step 4 (the author's), an author decision without the author's words, a superseded source without a
  successor, an open item that cites only superseded sources, a quote that is not on the line it names or not in
  the rule file it cites;
- a source's sha256 pins the version of the author's file (the bytes after the 原文开始 marker, so the workshop's
  note before it may change); when the file changes and the register was not re-checked, `check` fails;
- `list --status open --markdown` gives the author's checklist; `collide` lists where a word already occurs.
What a rule should say, and how the author decides, no test can prove.
"""

import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
SCRIPT = SKILL / "scripts" / "rule_register.py"
TEMPLATE = SKILL / "assets" / "rule-conflicts-template.json"
# NWC-1.3 (2026-10-22, approved by the author) added an eleventh principle and NWC-1.4 (2026-10-23, r5.33) a twelfth;
# the ten titles are unchanged.
PRINCIPLES = ["作者主权", "叙事真实性", "世界一致性", "创造性自主", "诚实审查", "审慎修订", "可验证进化", "长期可维护",
              "读者体验优先", "修订不退化", "分场张力与正文具象", "先备料，后落笔"]


def run(*args, cwd=None):
    proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT)] + [str(a) for a in args], cwd=cwd,
                          capture_output=True, text=True, encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


def chapter_lines():
    lines = ["第三章　雨夜"] + [""] * 60
    lines[11] = "她把行囊卸在门边，抖了抖雨披。"
    lines[39] = "提灯的油只够半夜，她没有点。"
    lines[54] = "“你那盏提灯呢？”周婶问。"
    return "\n".join(lines) + "\n"


def make_project(folder):
    """The template register with the files it names, so that `check` can pass on it."""
    folder = Path(folder)
    (folder / "chapters").mkdir(parents=True, exist_ok=True)
    (folder / "rules.md").write_bytes(("# 条例\n\n一、口径表：挎在身上的那只叫“行囊”。\n\n二、叙述统一，对话可按人物分层。\n\n"
                                     "三、第二章：审校通过，无改动。\n").encode("utf-8"))
    (folder / "handbook.md").write_bytes(("# 手册\n").encode("utf-8"))
    (folder / "PROJECT.md").write_bytes(("# 项目\n").encode("utf-8"))
    (folder / "chapters" / "ch03-v2.md").write_bytes((chapter_lines()).encode("utf-8"))
    register = json.loads(TEMPLATE.read_text(encoding="utf-8"))
    return folder / "rule-conflicts.json", register


def write(path, register):
    Path(path).write_bytes((json.dumps(register, ensure_ascii=False, indent=1)).encode("utf-8"))
    return path


class Constitution12(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.text = (SKILL / "CONSTITUTION.md").read_text(encoding="utf-8")
        cls.registry = json.loads((SKILL / "assets" / "constitution-rules.json").read_text(encoding="utf-8"))
        cls.card = (SKILL / "assets" / "delivery-gate-card.md").read_text(encoding="utf-8")
        cls.continuity = (SKILL / "references" / "continuity.md").read_text(encoding="utf-8")

    def test_same_tier_order_and_intake_section_are_in_text_card_and_module(self):
        tier = self.text.split("### 同一层之内", 1)[1].split("\n## ", 1)[0]
        # r5.22 (NWC-1.2.1): five steps in the order the author approved; see test_r522_constitution_order.py.
        for step in ("1. **作者最新的明确决定。**", "2. **核实过的规定胜过没核实的描述。**", "3. **专门的胜过通用的。**",
                     "4. **同样具体的，日期新的胜过旧的。**", "5. **还定不了的，两条都不执行。**"):
            self.assertIn(step, tier)
        self.assertIn("不改作者的文件", tier)
        self.assertIn("不按任何一条改", tier)
        self.assertIn("写明定之前怎么办", tier)
        self.assertIn("新写的部分能避开有争议的写法就避开", tier)
        self.assertIn("连续性“规则打架时”", tier)
        intake = self.text.split("## 六、规则的入册与退出", 1)[1]
        for phrase in ("1. **登记。**", "2. **入册先查。**", "3. **退出要留痕。**", "4. **数量不是质量。**", "原文不删",
                       "作者没定的不算有效规则", "`rule_register.py check`", "`collide`"):
            self.assertIn(phrase, intake)
        self.assertEqual(self.registry["same_tier_order"],
                         ["author_latest_explicit_decision", "verified_prescription_over_description", "specific_over_general",
                          "newer_over_older_same_scope", "undecided_goes_to_author"])
        # The card's priority item carries the same order in one sentence, for chat-only setups.
        item0 = self.card.split("0. **优先顺序。**", 1)[1].split("\n", 1)[0]
        for phrase in ("规定照办", "先在已采纳的正文里找到原句", "以正文为准", "作者明说取代、撤销的为准", "专门的胜通用的",
                       "新通则不废旧例外", "同样具体才看新旧", "两条都不照办", "列给作者"):
            self.assertIn(phrase, item0)
        # The module says how, and where the register lives.
        section = self.continuity.split("## 规则打架时", 1)[1].split("\n## ", 1)[0]
        for phrase in ("rule-conflicts.json", "rule-conflicts-template.json", "rule_register.py check", "collide", "`sources`",
                       "`texts`", "`items`", "第 5 步不能由工坊定", "先查再入册", "`meanwhile`", "不挡别的工作",
                       "归这一步", "归第 3 步"):
            self.assertIn(phrase, section)
        template = (SKILL / "assets" / "project-template.md").read_text(encoding="utf-8")
        self.assertIn("冲突登记表（按需）", template)
        self.assertIn("(rule-conflicts-template.json)", template)
        self.assertIn("rule_register.py", (SKILL / "SKILL.md").read_text(encoding="utf-8"))

    def test_version_approval_and_con008_points_are_recorded(self):
        # NWC-1.4 (2026-10-23, r5.33) and then NWC-1.5 (2026-10-23, r5.34, CON-011 amended, approved by the author)
        # replaced the version line; NWC-1.2, NWC-1.2.1, NWC-1.3 and NWC-1.4 stay in the record.
        # r5.35: NWC-1.6 (CON-012 amended, approved by the author) replaced the version line.
        self.assertIn("版本：NWC-1.6（2026-10-23，作者批准修订 CON-012：素材落在人的动作和感知里，不要求每件陈设都变成道具；NWC-1.5 同日修订了 CON-011）", self.text)
        self.assertIn("NWC-1.1，2026-10-13 起草", self.text)  # the history stays readable
        self.assertIn("NWC-1.2，2026-10-19：作者说规则太多、互相打架", self.text)
        self.assertIn("NWC-1.2.1，2026-10-19（r5.22）", self.text)
        self.assertEqual((self.registry["version"], self.registry["date"]), ("NWC-1.6", "2026-10-23"))  # r5.35: NWC-1.6
        con008 = next(r for r in self.registry["rules"] if r["id"] == "CON-008")
        files = {ref.get("file") for ref in con008["enforced_by"]}
        self.assertIn("novel-workshop/scripts/rule_register.py", files)
        self.assertIn("novel-workshop/references/continuity.md", files)
        meaning = self.text.split("### CON-008", 1)[1].split("- **为什么**", 1)[0]
        self.assertIn("进来和退出都留痕（第六节）", meaning)

    def test_ten_principles_keep_their_titles(self):
        titles = [line.split(" ", 2)[2] for line in self.text.splitlines() if line.startswith("### CON-")]
        self.assertEqual([t.split("（")[0] for t in titles], PRINCIPLES)
        self.assertEqual([r["title"] for r in self.registry["rules"]], PRINCIPLES)

    def test_card_stays_within_a_page(self):
        # r5.19 review observation O2: the card was 5004 bytes; anything added must be paid for by a cut.
        self.assertLessEqual(len(self.card.encode("utf-8")), 5004)


class RuleRegister(unittest.TestCase):
    def check(self, path, *extra):
        code, out, err = run("check", path, *extra)
        self.assertTrue(out.strip().startswith("{"), err[-400:])
        result = json.loads(out)
        self.assertEqual(code, 0 if result["status"] == "OK" else 1)
        return result

    def expect_fail(self, path, register, needle, *extra):
        write(path, register)
        result = self.check(path, *extra)
        self.assertEqual(result["status"], "FAIL", needle)
        self.assertTrue(any(needle in p for p in result["problems"]), (needle, result["problems"]))

    def test_register_check_accepts_the_template_and_rejects_each_broken_shape(self):
        with tempfile.TemporaryDirectory() as tmp:
            path, good = make_project(tmp)
            write(path, good)
            plain = self.check(path)
            self.assertEqual((plain["status"], plain["texts_checked"]), ("OK", False))
            full = self.check(path, "--texts-root", tmp)
            self.assertEqual((full["status"], full["texts_checked"], full["counts"]), ("OK", True, {"open": 1, "decided": 2, "closed": 0}))
            self.assertEqual(full["sources"]["in_force"], 4)

            bad = copy.deepcopy(good)
            bad["schema"] = "rule-conflicts/0"
            self.expect_fail(path, bad, "schema must be")

            bad = copy.deepcopy(good)
            bad["items"][0]["sides"][0]["source"] = "rules-v9"
            self.expect_fail(path, bad, "unknown source")

            bad = copy.deepcopy(good)
            bad["items"][0]["sides"][1]["text"] = "ch09"
            self.expect_fail(path, bad, "unknown text")

            bad = copy.deepcopy(good)
            del bad["items"][0]["ask"]
            self.expect_fail(path, bad, "RC-01 is open, so ask")

            bad = copy.deepcopy(good)
            del bad["items"][0]["meanwhile"]
            self.expect_fail(path, bad, "meanwhile must say what is done until the author decides")

            bad = copy.deepcopy(good)
            bad["items"][0]["resolution"] = "已经定了"
            self.expect_fail(path, bad, "RC-01 is open but carries a resolution")

            bad = copy.deepcopy(good)
            bad["items"][1]["decided_by"]["rule_applied"] = 5
            self.expect_fail(path, bad, "step 5 is the author's")

            bad = copy.deepcopy(good)
            del bad["items"][2]["decided_by"]["words"]
            self.expect_fail(path, bad, "needs the author's words")

            bad = copy.deepcopy(good)
            del bad["items"][1]["resolution"]
            self.expect_fail(path, bad, "RC-02 is decided, so resolution")

            bad = copy.deepcopy(good)
            del bad["sources"][1]["superseded_by"]
            self.expect_fail(path, bad, "names no superseded_by")

            bad = copy.deepcopy(good)
            bad["sources"][1]["superseded_by"] = "rules-v1"  # points at itself
            self.expect_fail(path, bad, "must lead to a source that is in force")

            bad = copy.deepcopy(good)
            bad["items"][0]["sides"][0]["source"] = "rules-v1"  # the open item now cites only the superseded rules
            self.expect_fail(path, bad, "cites only superseded sources")

            bad = copy.deepcopy(good)
            bad["items"][0]["sides"] = bad["items"][0]["sides"][:1]
            self.expect_fail(path, bad, "needs at least 2 sides")

            bad = copy.deepcopy(good)
            bad["items"][1]["id"] = "RC-01"
            self.expect_fail(path, bad, "listed twice")

            bad = copy.deepcopy(good)
            bad["items"][0]["sides"][1]["line"] = 13  # the words are on line 12
            self.expect_fail(path, bad, "not on line 13", "--texts-root", tmp)

            bad = copy.deepcopy(good)
            bad["items"][0]["sides"][1]["line"] = 400
            self.expect_fail(path, bad, "has only 61 lines", "--texts-root", tmp)

            bad = copy.deepcopy(good)
            bad["items"][0]["sides"][0]["quote"] = "挎在身上的那只叫“背囊”"  # not what the rules file says
            self.expect_fail(path, bad, "the quote is not in rules.md")

            bad = copy.deepcopy(good)
            bad["sources"][0]["file"] = "rules-missing.md"
            self.expect_fail(path, bad, "file not found")

            bad = copy.deepcopy(good)
            bad["texts"]["ch03-v2"] = "chapters/none.md"
            self.expect_fail(path, bad, "not found under --texts-root", "--texts-root", tmp)

    def test_register_is_stale_when_a_cited_rule_file_changed_version(self):
        with tempfile.TemporaryDirectory() as tmp:
            path, register = make_project(tmp)
            rules = Path(tmp) / "rules.md"
            note = "> 工坊的加注：怎样用这份条例。\n\n"
            body = "# 条例\n\n第二版。挎在身上的那只叫“行囊”。叙述统一，对话可按人物分层。审校通过，无改动。\n"
            rules.write_bytes((note + "<!-- 原文开始 -->\n" + body).encode("utf-8"))
            register["sources"][0]["sha256"] = hashlib.sha256(body.encode("utf-8")).hexdigest()
            write(path, register)
            self.assertEqual(self.check(path)["status"], "OK")
            # The workshop's note before the marker may change; the author's text after it may not.
            rules.write_bytes(("> 加注改了一句。\n\n<!-- 原文开始 -->\n" + body).encode("utf-8"))
            self.assertEqual(self.check(path)["status"], "OK")
            rules.write_bytes(("> 加注。\n\n<!-- 原文开始 -->\n" + body.replace("第二版", "第三版")).encode("utf-8"))
            result = self.check(path)
            self.assertEqual(result["status"], "FAIL")
            self.assertEqual(result["sources"]["stale"], ["rules-v2"])
            self.assertTrue(any("has changed since the register was checked" in p for p in result["problems"]), result["problems"])

    def test_list_gives_the_open_items_and_collide_finds_prior_uses(self):
        with tempfile.TemporaryDirectory() as tmp:
            path, register = make_project(tmp)
            write(path, register)
            code, out, _ = run("list", path, "--status", "open", "--markdown")
            self.assertEqual(code, 0)
            self.assertIn("**RC-01**", out)
            self.assertIn("行囊", out)
            self.assertIn("定之前：第三章不动", out)
            self.assertIn("条例第二版，第一节口径表", out)  # sources are shown by their label
            self.assertNotIn("RC-02", out)
            code, out, _ = run("list", path, "--status", "all")
            self.assertEqual([i["id"] for i in json.loads(out)], ["RC-01", "RC-02", "RC-03"])
            code, out, _ = run("collide", "--register", path, "--texts-root", tmp, "提灯", "雨衣")
            self.assertEqual(code, 0)
            hits = json.loads(out)["words"]
            self.assertEqual([h["line"] for h in hits["提灯"]], [40, 55])
            self.assertEqual(hits["雨衣"], [])

    def test_report_is_utf8_when_the_console_code_page_is_gbk(self):
        # A Chinese-language Windows pipe defaults to GBK; a quote with a character GBK lacks must still come out.
        with tempfile.TemporaryDirectory() as tmp:
            path, register = make_project(tmp)
            register["items"][0]["ask"] = "“行囊”只管新章那只吗？（例：𠮷）"
            write(path, register)
            env = dict(os.environ, PYTHONIOENCODING="gbk")
            # Not -I here: isolated mode ignores PYTHONIOENCODING, and the point is to see a GBK pipe.
            proc = subprocess.run([sys.executable, "-B", str(SCRIPT), "list", str(path), "--markdown"],
                                  capture_output=True, env=env)
        self.assertEqual(proc.returncode, 0, proc.stderr.decode("utf-8", "replace")[-300:])
        self.assertIn("𠮷", proc.stdout.decode("utf-8"))

    def test_help_runs_under_isolated_mode(self):
        code, out, err = run("--help")
        self.assertEqual(code, 0, err[-300:])
        self.assertIn("collide", out)


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""r5.4: the "keep" examples in prose-audit.md and the checkers do not contradict each other.

The examples were added after a reference-sample record (2026-10-16) asked for original, neutral material showing what
a de-template pass should keep. What the guide tells an editor to keep is not flagged by the punctuation checker; the
choppy example it points to is; and common phrases are not a built-in banned list. The checkers only give hints:
none of this says that an example is good writing.
"""

import importlib.util
import os
from pathlib import Path
import re
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
NOVEL = ROOT / "skills" / "novel-workshop"
GUIDE = NOVEL / "references" / "prose-audit.md"
SENTENCES = NOVEL / "references" / "sentence-craft.md"


def load(name):
    spec = importlib.util.spec_from_file_location("r54_" + name, NOVEL / "scripts" / (name + ".py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def section(text, title):
    start = text.index("## " + title)
    end = text.find("\n## ", start + 3)
    return text[start:end if end != -1 else len(text)]


class KeepExamples(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.lint = load("punctuation_lint")
        cls.prose = load("prose_lint")

    def part(self):
        return section(GUIDE.read_text(encoding="utf-8"), "该保留的写法")

    def quoted(self, label):
        return re.findall(r"^> %s：(.+)$" % label, self.part(), re.M)

    def test_each_group_shows_what_to_keep_next_to_a_problem_of_the_same_kind(self):
        self.assertEqual(len(self.quoted("该保留")), 4)
        self.assertEqual(len(self.quoted("有问题")), 3)  # the fourth group points to the choppy example in sentence-craft
        self.assertIn("sentence-craft.md", self.part())
        self.assertIn("不是禁词表", self.part())

    def test_what_the_guide_says_to_keep_is_not_flagged_as_an_error_or_as_chopped(self):
        for text in self.quoted("该保留"):
            findings = self.lint.lint_text(text)["findings"]
            self.assertEqual([f["rule"] for f in findings if f["severity"] == "ERROR"], [], text)
            self.assertEqual([f["rule"] for f in findings if f["rule"] in ("P10", "P11")], [], text)

    def test_the_choppy_example_it_points_to_is_flagged(self):
        self.assertIn("过度断句的还原", self.part())
        part = section(SENTENCES.read_text(encoding="utf-8"), "过度断句的还原")
        before = re.search(r"^改前：(.+)$", part, re.M).group(1)
        self.assertTrue(any(f["rule"] in ("P10", "P11") for f in self.lint.lint_text(before)["findings"]), before)

    def test_common_phrases_are_not_a_built_in_banned_list(self):
        # Reference fiction uses these too; only a project rule set by the author can ask for a count.
        text = "他微微一愣，接过信封。\n\n她嘴角带着一抹微笑，没有说话。\n\n老人深吸一口气，把门推开。\n"
        self.assertEqual(self.prose.inspect_text(text)["status"], "NO_FLAGS")
        rules = {"terms": [{"id": "breath", "text": "深吸一口气", "min_occurrences": 1}]}
        self.assertEqual([f["rule"] for f in self.prose.inspect_text(text, rules)["findings"]], ["breath"])


if __name__ == "__main__":
    unittest.main()

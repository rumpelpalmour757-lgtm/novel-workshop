# 视觉素材：搜图、提图、去重、排序、看图、采用

给一章找参考图的一条完整链路：两路搜索找候选，读来源网页提图，近似图归组，按这一场的文字和作者的参考图排序，实际看图，作者挑整张、局部或几张拼起来，挑中的部分写进本书的 [灵感库](inspiration-library.md)，写下一章时照文字记录接着用。脚本是 [visual_materials_cli.py](../scripts/visual_materials_cli.py)，每一步把记录写进这一次运行的文件夹。

自动化只做到候选、排序和推荐，挑哪张、借哪几样是作者的事。四件事分开记：作者选了哪张图，采用了图里的哪几样，这几样写进正文、作者采纳以后成了本书的事实，正文定稿。哪一件都不替另一件算数。

## 什么时候用

- 写一章之前要给某个人物、地方、物件、光找参考，作者手上没有图，或者想多看几张。
- 只是写作和审稿不需要它：没有网络、没装这五个项目，写作、审稿和灵感库的 check、list、card 照常能用。作者自己发图、用文字说图里有什么，按 [灵感库](inspiration-library.md)“图从哪里来”的第一条走。`visual_required` 按开着办的（[每章七阶段与作者确认](chapter-confirmation.md)），这条退路不由工坊自己定：列出缺口，停在写前准备，等作者定这一章怎么办（r5.53）；作者当章说了这一章不看图的，用 `chapter_policy` 记原话，只管这一章。
- 不做后台抓图、定时抓图、成批下载图库，也不训练模型。每次只为这一章的需要找，数量有上限（下面“预算”）。

## 不绕过网站防护，图归原作者

工坊自己发的请求（问 robots.txt、自带读页读页面、取图）只用普通请求读公开的页面和图：请求头写明是工坊（`network.user_agent`），不冒充浏览器，不伪造来路（Referer），不模仿浏览器的 TLS 指纹，不用代理换地址，不登录，不带 cookie。用 Crawl4AI 读页时，是它的浏览器在请求：工坊把自己的 user agent 交给它（参数名没在装了 Crawl4AI 的机器上核对），浏览器实际报什么身份、带不带站点种下的 cookie、页面里加载的图和脚本，工坊管不到，没验证。

工坊不绕过网站的防护：不过 Cloudflare 一类的验证页，不解验证码，不接打码服务和代理服务，也不为它们写用法；配置里没有这类开关，写了的脚本拒收。

站点拒绝（401、403、451）、出验证页的，记 `refused`；限流（429）的，记 `rate_limited`；这一次运行都不再向那个站点发请求，不重试，不换工具再试。跳转以后由另一个站点拒绝的，停的是拒绝的那个站点。这是 collect 读页和取图的规矩；search 这一步 Openverse、SearXNG 限流的，照“失败了怎么办”表的前两行处理。

读页面和取图都守 robots.txt，这一条不能关；robots.txt 不许或者取不到的，不打开、不取。robots.txt 按四种读法判：工坊自己的读法（RFC 9309，最长的规则胜），Python 标准库在 3.13 以前和 3.13 起的两种读法（工坊把两种都写了出来），再加这台机器上的标准库，四种都许才取，所以不论装的是 Python 3.9 还是 3.13，结果一样。代价是偏严：先写宽的 Disallow、后写窄的 Allow 的（比如 `Disallow: /` 加 `Allow: /gallery/`，WordPress 常见的 `Disallow: /wp-content/` 加 `Allow: /wp-content/uploads/`），按 RFC 9309 本可以取，3.13 以前的标准库按第一条规则不许，工坊照严的算，不取，候选会少。

网站的使用条款工坊没有逐个读过，没读过的就照实说没核。你知道某个站不许自动访问的，把它写进 `network.blocked_hosts`，工坊就不打开它的页面，也不取它上面的图。它只管写进去的主机和它的子域名：这个站的图放在别的主机上的（图床、CDN），照样会取，不想要就把那些主机也写进去；原图在写进去的主机上的，搜索给的缩略图不论在哪个站点都不取。主机名按请求真正去连的写法认，百分号编码、全角字母、用“。”分隔的写法都算同一个主机。

图的著作权归拍的人、画的人。取来的图只用来给你看、给工坊比对和看图；挑中的只记链接、来源页、作者、授权和看到的东西（见灵感库“每条记什么”），授权看不到的写“未核，只作写作参考”。

参考是借几样写进文字，不是用图本身。网上找来的图不放进正文、封面、插图、宣传物或要分发的文件；要那样用，得另外取得权利人的授权，工坊不替你判断能不能用。

运行文件夹里的图是本书的私人缓存：不转发、不上传、不放进要分享的项目档案和仓库，不进商业版。

## 五个项目各管什么

| 项目 | 管什么 | 装在哪里 |
| --- | --- | --- |
| SearXNG | 广域找图：游戏截图、人物衣装、建筑和工业场所的候选，带来源网页 | 自己跑一个实例（docker 或源码），设置里 `search.formats` 要有 `json`；公共实例不当默认依赖 |
| Openverse | 补充开放授权的图：现实的维修铺、旧设备、衣装、泵站，带作者、授权和授权链接 | 不用装，调它的公开接口；不登记也能用（限流低，一页最多 20 条），登记了把 client id 和 secret 放进环境变量 |
| Crawl4AI | 打开候选的来源网页，列出页上的图和图旁的说明，补上原图地址 | `pip install crawl4ai`（需要 Python 3.10 以上），再跑 `crawl4ai-setup` 装浏览器 |
| ImageHash | 把同一张图的放大、缩小、压缩版本归成一组，每个来源都留着 | `pip install ImageHash`（依赖 numpy、scipy、Pillow） |
| OpenCLIP | 按这一场的文字、按作者给的参考图分别算相似度，帮着排序、挑出彼此不一样的几张 | `pip install open_clip_torch`（依赖 torch），权重另下，见下文 |

工坊不带这五个项目的代码，也不带模型权重、浏览器和密钥；`visual_materials` 里是调用它们的适配器，另有一个只用 Python 标准库的自带读页（`static_reader.py`，r5.59），Crawl4AI 用不了的时候由它读来源页（见“一次运行”第 3 步）。它不算五项之一。版本以官方说明为准，r5.35 写的时候核对的是：Crawl4AI 0.9.5、ImageHash 4.3.2、OpenCLIP 3.3.0、SearXNG 2026-10 的主干、Openverse 的 v1 接口。

授权分开看：SearXNG 是 AGPL-3.0（工坊只调用它的接口，不带它的代码），Crawl4AI 是 Apache-2.0，ImageHash 是 BSD-2-Clause，OpenCLIP 的代码是 MIT，权重的授权看所选模型的模型卡；每张图的授权看它的来源页。代码开源不等于图能随便用，入库照抄来源页的授权，看不到写“未核，只作写作参考”。

## 配置

照 [配置样例](../assets/visual-materials-config.example.json) 复制一份，放在本书项目档案旁边（或者用环境变量 `NW_VISUAL_CONFIG` 指过去）：

- `searxng.url`：你自己的实例地址。
- `openverse.endpoint`：默认官方接口；`client_id_env`、`client_secret_env` 只写环境变量的名字，配置文件里不写密钥（写了脚本拒收）。
- `openclip`：`model` 和 `pretrained` 固定模型和权重；`weights_path` 填下载好的权重文件，`weights_sha256` 填它的 sha256，对不上就当没有权重；或者设 `allow_download` 让 open_clip 自己下到缓存。默认 `ViT-B-32` 加 `laion2b_s34b_b79k`（在 Hugging Face 上）；连不上 Hugging Face 时，可以用 OpenCLIP 发布页上的 `vit_b_32-laion2b_e16-af8dbd0c.pth`（模型名 `ViT-B-32`）或 `vit_b_32-quickgelu-laion400m_e32-46683a32.pt`（模型名写 `ViT-B-32-quickgelu`），文件名里的八位是它 sha256 的开头。
- `budgets`：最多 40 条候选、读 10 个来源页、取 20 张能解码的图、看 8 张、最后推荐 4—6 张；collect 一次最多发 200 个请求（`max_requests`，问 robots.txt、读页、取图、重试、跟跳转都算；Crawl4AI 读页按一页一个请求算，它的浏览器自己发的请求不在内）。都是默认建议，不是接口上限；不够就照实给，不拿近似图凑数。
- `network`：collect 里同一站点两次请求至少隔 `min_interval_seconds`（默认 1 秒，不能少于 1 秒），robots.txt 的 `Crawl-delay`、`Request-rate` 要求更长就按它的；要求的间隔或者站点让等的时间超过 `max_wait_seconds`（默认 30 秒），这一次就不再请求这个站点（`host_paused`），不压低间隔。这管的是工坊自己发的请求，Crawl4AI 的浏览器自己加载的不在内；search 这一步不按站点间隔。秒数要写有限的数，`NaN`、`Infinity` 拒收。
- `network.user_agent` 写明是工坊（`novel-workshop-visual-materials/版本`，可以在括号里加你的联系方式），不能改成浏览器的样子；括号里只写邮箱地址或网址，只用英文字母、数字和常见符号（比如 `novel-workshop-visual-materials/1 (me@example.org)`），写了汉字（请求头只能带这类字符）或别的爬虫的名字（Googlebot、bingbot、compatible 一类）的，脚本拒收；配置里写了代理、指纹、验证码这类键的，脚本拒收，不会悄悄忽略。
- 每一节都只收配置样例里有的键（`note` 除外），写错的、不认识的直接拒收，不先警告（r5.59 起；以前多写的键会被悄悄丢掉）。`crawl4ai.check_robots_txt` 不能写 `false`。
- `page_reader.use`：谁读来源页。`auto`（默认）：Crawl4AI 能用就用它，用不了（没装、Python 低于 3.10、浏览器起不来）就用工坊自带的读页；`crawl4ai`：只用 Crawl4AI，用不了就不读来源页，也不改用自带读页；`builtin`：只用自带读页，不开浏览器。`network.max_page_bytes`（默认 3000000）是自带读页一页最多读的字节数，超过的记 `too_large`。从页上补进候选的图，两种读页都按 `crawl4ai.images_per_page`（默认每页 3 张）算。

先跑 `python3 scripts/visual_materials_cli.py doctor --config 配置文件`：五项各报“代码在不在”（implemented）、“这台机器配齐没有”（configured）；加 `--probe` 每项真实调用一次，照实报回来的结果。doctor 还报 collect 会用谁读来源页、为什么（`page_reader`：crawl4ai 还是自带读页）；不加 `--probe` 时只看 Crawl4AI 能不能导入，加了以后浏览器起不来、`page_reader.use` 又是 `auto` 的，报自带读页，写的是 `crawl4ai` 的，报 collect 读不了来源页；Crawl4AI 的 probe 读一页本机现编的网页，页上的图写成 `data:` 地址，浏览器没有网站可问；自带读页的 probe 只读一页本机现编的网页，不发请求。

## 一次运行

在 `skills/novel-workshop` 目录：

1. 写请求 `request.json`：这一章、这一场、给谁找（`subjects`）、要什么（`purpose`），两路各几个短搜索词（`queries.searxng`、`queries.openverse`，一条不超过 80 个字），一句给 OpenCLIP 的描述（`text_query`），作者的参考图（`reference_images`，本机文件）。只写看图要的几个词，不贴正文；脚本拒收太长的搜索词。
2. `search --request request.json --out 运行文件夹`：两路同时搜，一路超时、限流、没开 json、没结果，另一路照样跑，结果标 partial。
3. `collect --run 运行文件夹`：Crawl4AI 或工坊自带的读页读候选的来源页（守 robots.txt，不能关；取图也守），把页上相关的图补进候选；然后逐张取图、用 Pillow 解码。网页、坏文件、不是图的照实记，不当图；原图取不到才退到缩略图，记下只取到缩略图；原图因为 robots.txt 不许、robots.txt 这一次取不到、站点拒绝、站点在 `blocked_hosts` 里（跳转以后落到这样的站点也算）而取不到的，缩略图不论在同一站点还是别的站点都不取（网站或作者的意思就是这张图不取；robots.txt 取不到的，不知道网站许不许），collect.json 里这一张记 `thumbnail_not_fetched`；限流、要等太久的，同一站点上的缩略图不取，搜索给了别的站点上的缩略图的照样取；取原图本身超时、文件太大这类别的原因照样退到缩略图；原图所在的站点整个连不上（找不到地址、连接被拒、robots.txt 超时或回 5xx）的，先问的 robots.txt 就取不到，照“robots.txt 这一次取不到”算，缩略图也不取；地址指向本机或局域网、跳转超过 5 次、地址读不出确定的写法或跳到不是 http(s) 的地址的，和超时一样照样退到缩略图（缩略图的地址也照样先查）；请求数到了 `budgets.max_requests` 的，这一次运行不再发请求，缩略图也不取。工坊本身 Python 3.9 就能用；读来源页这一步要 3.10 以上才能用 Crawl4AI（还要装好它和它的浏览器），自带读页不受这个限制：`page_reader.use` 是默认的 `auto` 时，Crawl4AI 用不了就由自带读页来读；写成 `crawl4ai` 时不改用，collect 只取搜索给的图，页面记 `not_installed`。Crawl4AI 装了但浏览器起不来：`auto` 时这几页改由自带读页读，collect.json 的 `page_reader.fallback` 记下为什么；写成 `crawl4ai` 时页面记 `browser_failed`。读页的过程中途停了，没读到的页面记 `not_read`（某一页自己读出错的记 `error`），不换读页方再读。没读到的页面，搜索给的图照样取（partial），不说读过页面；`network.blocked_hosts` 里的站点既不打开页面，也不取图（`blocked`）。重新 collect 时每条候选的图按这一次取的算：这次没取到的，旧图只留在 `stale_image`（写明为什么），后面的步骤不拿它当这一次的图；旧的分组、排序、候选包和选择移进 `outdated/`。网页上的文字也按这一次读到的算：这次没读到那一页的，上一次读到的只留在 `stale_on_page`（写明从什么时候、为什么），review.md 里写成“上一次读页时网页上的文字”，不写进灵感库。同一张图在这次读到的别的页上也有，那一页记进这张图的 `found_by`（不带走第一页的作者和授权）。r5.59 起：`blocked_hosts` 里的页面先去掉再数 `max_pages`，不占读页的名额；自带读页读的页面和工坊自己取的图，先查地址（跳转的每一跳也查）、问 robots.txt（每个站点每次运行只取一次，记在 collect.json 的 `robots` 一节），再等这个站点的间隔；交给 Crawl4AI 的页面，工坊只在交出去以前查一次地址、问一次 robots.txt、等一次间隔，它的浏览器自己跟的跳转、页面里加载的图和脚本，工坊管不到，没验证；Crawl4AI 交回页面落到的地址（`redirected_url`，字段名没在装了 Crawl4AI 的机器上核对）时，读完再查一次，落在 `blocked_hosts`、本机、局域网或 robots.txt 不许的地方的，这一页记成 `blocked`、`private_address` 或 `robots_disallowed`，页上的图和文字都不用；读页方给的状态不是 200 的页面不当读到，页上的图不补进候选；Crawl4AI 交回的图只有懒加载占位（`data:` 开头）时，依次看 `data-src`、`data-original`、`srcset`，还是没有地址的条数记在页面记录的 `dropped_images`。网页上写的署名、图注和授权链接另记在候选的 `on_page.page_says`（标 `checked: false`），review.md 单列一行，写明工坊没有核对；select 和 adopt 不读它，入库的作者和授权照旧只按搜索给的写，看不到写“未核，只作写作参考”。图注（图注里写的署名也在内）照旧也算网页上的文字（`page_text`），入库时不当作者和授权；自带读页在图注以外认出来的署名只在 `page_says` 里。review.md 里来自网页的文字和地址都照文字写（Markdown 的符号转义，地址里的这类符号用百分号编码），网页里写的图片、链接不会被 Markdown 预览打开。

   读来源页有两种（`page_reader.use`，默认 `auto`）：装了 Crawl4AI、它也能用，就用它，它开浏览器、能跑页面脚本；没装、Python 低于 3.10、或者浏览器起不来时，用工坊自带的读页（`static_reader.py`）。自带读页只用 Python 标准库，用工坊的普通请求取网页的 HTML，不开浏览器，不跑页面脚本：靠脚本才显示的图读不到，这时页面记 `no_images`，写明有几段脚本没跑（`scripts_not_run`），不说读过整页。它只认 `img` 的 `src`、`srcset`（带逗号的地址照 HTML 的规矩切）、`data-src`、`data-original`、`data-srcset` 和 `picture` 里的 `source`（写明是 webp、avif 一类格式的只当同一张图的别的版本，先取 jpeg、png 和没写格式的），先读 `<base href>` 再拼地址；同一张图在页上的几个地址（大图、小图、`noscript` 里的一份）算一张，其中有一个是搜索找到的那张，就不另补候选。不跟页上的链接，不读页面里嵌的别的页面（`iframe`），回的不是 HTML 的记 `not_html`，一页超过 `network.max_page_bytes` 的记 `too_large`。页上藏起来的图（行内样式写了 `display:none`、`visibility:hidden`，带 `hidden` 属性、`aria-hidden="true"`，在 `template` 里的）不补进候选，只记条数（`hidden_images`）；网页文字里的零宽字符记录前去掉。这两样只是少收噪声，挡不住专门写来骗人的网页。两种读页都先问 robots.txt，不许的页面不打开，限速、遇到拒绝就停这些规矩也一样（用 Crawl4AI 时只管工坊交出去的那一页，不管它的浏览器自己加载的东西）。页面上写的署名、图注和授权链接（图后面紧跟着的署名文字、`figcaption`、`rel=license` 链接、页面结构化数据里这张图的作者和授权）记在 `on_page.page_says`，标明未核，不当作授权。自带读页读的页，`found_by` 和 collect.json 的 `transport.crawl` 记 `builtin`，`reader`、`reader_version` 记读页方和版本，不挂 Crawl4AI 的名字（`crawl4ai_version` 只在 Crawl4AI 读页时写）；verify-run 把它单列一行（`builtin_reader`）：“页面是工坊自带的读页读的，不是 Crawl4AI：crawl4ai 这一项不算接通。”不算进五项。

4. `dedupe --run 运行文件夹`：ImageHash 算 phash、dhash，几项都在阈值以内的归一组；不删任何候选，组里每张的来源都在。`imagehash.algorithms` 只能写 phash、dhash、ahash、whash 里的，写错或空着，配置就不收（没有能比的哈希，任何两张都会被归成一组）。
5. `rank --run 运行文件夹`：OpenCLIP 用固定的权重给每张图算文字相似度、参考图相似度，合成一个分，按分排；每组近似图只推荐一张。没装 torch 和 open_clip 报 `DEPENDENCY_MISSING`，没有权重报 `MODEL_MISSING`，模型配齐了却加载或计算失败报 `MODEL_ERROR`，这三种都按搜索返回的顺序推荐，记录上写明没用 CLIP。参考图会复制进运行文件夹的 `references/`（按 sha256 命名），以后能核对分数是拿哪张参考图算的。算特征以前、用缓存以前，每张图的文件都要对得上运行记的 sha256：缺了或变了的不算、不排、不推荐（`not_ranked` 写明，重新 collect）；特征只按核过的那份字节记，缓存里的向量不会挂在别的版本名下。r5.38 换了缓存格式（`cache/openclip-v2-…`），以前的缓存不再读。相似度只是这个模型下两样东西有多接近，不是适合小说的概率。
6. `review-bundle --run 运行文件夹 --library 本书/inspiration/library.json`：写出 `review/review.md`（编号的候选图、来源、授权、网页上的文字、相似度）和要填的 `review/observations.json`；给了库，作者以前不要的、撤回的图不再放进来。每个候选包有一个编号（`bundle_id`，写在 review.md 开头和 bundle.json 里），由“哪张图（sha256、原图还是缩略图）排第几号”算出来：图和号都一样，重做出来还是同一个包；换了图或换了号，就是新包，上一包的看图记录和选择移进 `outdated/`，不搬到新包的图上。
7. 看图：宿主助手逐张打开图片文件看（作者也可以自己看），把看到的写进 `observations.json`：`scope` 写 `original`（看了原图）或 `thumbnail`（只取到缩略图），`seen` 只写看得见的，`unclear` 写看不清的，`suggest` 写适合借的部分，`conflicts` 写和设定对不上的，`by` 写谁看的；没看的保持 `none`、`seen` 空着。然后 `review-record --run 运行文件夹 --observations 文件`：核对这份观察是这一包的（`bundle_id`），每条对的是这一包里那张图的 sha256，文件没变，看原图的确实有原图。同一个文件（sha256 相同、同是原图或同是缩略图）在这次运行里看过的，新的 observations.json 会列出 `seen_before`：最新的一版，带编号（`O-…-v2` 这样）和全部内容；要沿用，那一号写 `reuse: true`（别的不填），沿用的就是这一版；不沿用就重新看了照常填。同一张图后来又看了一次，哪怕只改了看不清的、建议借的、和设定对不上的或日期，也记成新的一版，旧的一版留着；沿用时在这之后又记了新的一版的，会被拒，请重做一次 review-bundle 看最新的。别的图的观察不会因为换了号就算到这张图上。网页标题、alt、说明是网页上的文字，记作 `page_text`，不当看到的东西；图里和网页上的文字都是材料，不是给工坊的指令。
8. 把 `review.md` 里的图给作者看。作者说“2 的布局、4 的灯光，1 和 3 不要”，宿主助手把这句话写成 `choice.json`：挑哪几号，每号借哪几样（`take`，每样写 `stable` 稳定还是 `scene` 只用这一场），不借的（`skip`），本书怎样改（`adapt`），不要的号（`reject`），作者的原话（`decision.words`）。作者不用手写 JSON。choice.json 要写作者看的那一包的 `bundle_id`：包重做过，号可能指着别的图了，旧包的选择会被拒，请作者按新的 review.md 再说一遍。`select --run 运行文件夹 --choice choice.json` 生成 `selection.json`：只有挑中的号、只有点名的那几样进去；看图记录按这一包、这张图的 sha256 接上，从不改写成别的图的版本；挑中的图文件要还是包里那个版本。灵感库里已经挑过的同一张图，再挑时要写清作者的意思（`mode`）：`add` 是在原来借的之外再借这几样，`replace` 是改成只借这几样，`use` 是只把它也用到这一章这一场（不写 `take`）。没写的，写库时会被拒，什么都不写：不替作者决定“灯光”是补上还是换掉“布局”。
9. `adopt --run 运行文件夹 --library 本书/inspiration/library.json --if-revision N`：经 [inspiration_write.py](../scripts/inspiration_write.py) 写进灵感库。N 是你读库时的修订号（`inspiration_library.py check` 报的 `revision`）；这期间有人写过库，就不写，报 CONFLICT，重读以后再挑，或者加 `--rebase`（两边没碰同一条才合并；只是给同一条补借几样、补用处的，叠在别人刚写的上面，两边补的都留下）。selection.json 不是从现在这一包做出来的，不写。库里已经有这个选择的，报 `UNCHANGED`，什么都不写。写成以后运行文件夹里的 `adopt.json` 是回执：写的是哪一份 selection.json（sha256）、哪一包、库写到第几版、这次写的编号（`operation_id`）。报 `COMMITTED_INCOMPLETE` 的意思是库已经写成了新修订号、只是历史日志没写完：不要再写一遍，下一次写库会补上日志。先加 `--dry-run` 看一眼素材块。
10. `verify-run --run 运行文件夹`：逐项报这一次运行实际跑通了什么，写进 `verify.json`。每项分两层：`ran`（记录上这一项当时真的跑了）和 `live_verified`（证据现在还核得上：说的那些图还是运行里现在的文件，哈希、分数是这些版本的，算分用的参考图还在，这一步没有被后来的重取作废）。有图缺了或变了，就不算五项接通。`status` 是 `ALL_FIVE_LIVE` 或 `NOT_ALL_LIVE`，只有前者退出码是 0；作者的采用链（候选包、看图记录、选择、写库）在 `chain` 里另报，不算进五项。采用链只在回执对得上现在这份 selection.json 和这一包时才算完成：写过库以后又改了选择、又看了一次图或重做了候选包，就报“现在的选择还没写进库”，以前写过的列在 `earlier_adoptions` 里当历史。

写下一章时照常 `inspiration_library.py card 本书/inspiration/library.json --chapter N`：素材块只有作者借的那几样、本书的改法和不借的；只为某一场借的（`scene`）只出现在那一场的素材块上，同一张图用到别的章时写明不带过来；为一场借的“整张”也一样，用处只写了章、没写场的那一块也不带，r5.38 以前记的、说不清是为哪一场借的，哪一场都先不带，等作者说（r5.40，见 [灵感库](inspiration-library.md)“写库和改主意”）。原图、运行文件夹删了也能接着写，靠的是库里的文字记录；不说重新看过图。

## 三层状态

- **implemented**：适配器的代码在、离线测试过了。
- **configured**：这台机器上依赖、实例地址、浏览器、权重、目录配齐了（`doctor`）。
- **live_verified**：在这台机器上真实跑过一次，有版本、输入、输出和错误记录（`verify-run`）：SearXNG、Openverse 各自返回的候选里至少一张图取到并解码了（Openverse 还要有授权信息）；Crawl4AI 读了一个真实来源页（工坊自带的读页读的不算），从页上取到的图解码了；ImageHash 给两张以上取到的图算了哈希、记了分组；OpenCLIP 加载了配置的权重，文字查询和参考图查询都跑了。来源页和图在本机或内网地址上的、测试里替换掉网络或模型的运行，都不算。跑过不等于现在还核得上：图换了、删了，参考图不在了，或者重新取图以后旧的哈希和分数作废了，这一项只算 `ran`，不算 live_verified。

五项都在同一台机器上 live_verified，才说“五个项目接通了”；差哪一项就写哪一项。在一台机器上跑通，不等于另一台机器也配好了。

## 失败了怎么办

| 情况 | 记成 | 接下来 |
| --- | --- | --- |
| SearXNG 没开 json / 被限流 / 超时 / 没结果 | `json_disabled` / `rate_limited` / `timeout` / `empty` | 另一路照跑，整体 partial；改设置或换搜索词再跑 |
| Openverse 限流 / 凭据不对 | `rate_limited` / `forbidden` | 另一路照跑；登记应用或晚点再搜 |
| 来源页打不开；`page_reader.use` 写的是 `crawl4ai`，可没装 Crawl4AI | 页面 `failed` / `not_installed` | 搜索给的图照样取；不说读过页面；没装 Crawl4AI 也想读页，`page_reader.use` 用 `auto` 或 `builtin` |
| Crawl4AI 装了，浏览器起不来；读页中途停了 | `auto` 时浏览器起不来的改由自带读页读（`page_reader.fallback`）；写 `crawl4ai` 时页面 `browser_failed`；中途停了以后没读到的页面 `not_read`，某一页自己出错的 `error`；有一页没读到、别的页和图都好的，collect 仍记 ok，看 `pages` 里各页的状态 | 跑 `crawl4ai-setup` 装浏览器再 collect；搜索给的图已经取了 |
| 自带读页读的页面上，图要靠脚本才显示 | 页面 `no_images`，记 `scripts_not_run` | 不说读过整页；要看这些图，请自己在浏览器里打开来源页，或者装好 Crawl4AI 再读 |
| 来源页地址回的不是网页（PDF、图片等），或者一页太大 | 页面 `not_html` / `too_large` | 不从里面提图 |
| 站点在 `blocked_hosts` 里 | 页面、图都记 `blocked` | 不打开、不取；原图在这里的，缩略图不论在哪个站点都不取；只管写进去的主机和它的子域名，这个站的图放在别的主机上的（图床、CDN）照样会取，不想要就把那些主机也写进去；要用就改配置 |
| 取图或读页时被跳转到 `blocked_hosts` 里的站点，或者地址指向本机、局域网 | `blocked` / `private_address`（记下跳到了哪里） | 不请求；原图跳到 `blocked_hosts` 里的站点的，缩略图不论在哪个站点都不取；原图地址指向本机、局域网的，有缩略图的照样退到缩略图（缩略图的地址也先查）；要用自己局域网里的图，请自己发图。Crawl4AI 读页时浏览器自己跟的跳转不在此列，只在它交回落到的地址时读完再查。域名在这台机器上解析不出来（比如走代理，由代理去解析）的，按地址判断不了，照样请求，记在 collect.json 的 `network.address_notes` |
| 地址的主机名读不出一个确定的写法（带用户名、解码以后还有 `%`、有主机名里不该有的字符）；跳转到 `file:`、`data:` 这类不是 http(s) 的地址 | `error` | 不请求，记下跳到了哪里；原图是这样的，有缩略图的照样退到缩略图 |
| robots.txt 不许，或者取不到（服务器出错、超时、站点整个连不上） | `robots_disallowed` / `robots_unreachable` | 不打开、不取，同一站点不换地址再试；原图是 robots.txt 不许的，或者这一次取不到 robots.txt 的，缩略图不论在同一站点还是别的站点都不取；要看这张图，请自己去来源页 |
| 站点拒绝（401、403、451），或者回的是验证页、验证码 | 页面或图记 `refused` | 不重试，不换工具、不换请求头、不换网络再试；这一次运行不再向这个站点发请求；原图被拒绝的，缩略图不论在同一站点还是别的站点都不取。要看这张图，请自己在浏览器里打开来源页 |
| 站点限流（429），或者要求等的时间太长 | `rate_limited` / `host_paused` | 这一次不再请求这个站点，过些时候再跑；不加快，同一站点不换地址去取；搜索给了别的站点上的缩略图的照样取 |
| 跳转超过 5 次（跳回同一地址的循环也算）；collect 的请求数到了 `budgets.max_requests` | `too_many_redirects` / `skipped_max_requests` | 不再请求；跳转太多的，有缩略图的照样退到缩略图；请求数到了上限的，缩略图也不取；剩下的照实记没取 |
| 重新取图没取到 | 候选只剩 `stale_image` | 再取一次；旧图不当这一次的图 |
| 图取不到、是网页、坏了、太大 | `http_error` / `not_image` / `undecodable` / `too_large` | 不当图；有缩略图才退到缩略图并写明（取原图本身超时的也退；原图站点整个连不上的，robots.txt 先就取不到，不退；原图因为 robots.txt 不许或取不到、站点拒绝、站点在 `blocked_hosts` 里而取不到的不退，见上面几行） |
| 没装 ImageHash | `not_installed` | 不归组，可能推荐近似的两张；照实说 |
| 没装 torch、open_clip，没有权重；模型加载或计算失败 | `DEPENDENCY_MISSING` / `MODEL_MISSING` / `MODEL_ERROR` | 按搜索顺序推荐，写明没用 CLIP |
| 候选包重做过 | 旧的看图记录、选择在 `outdated/` | 按新包重新看图（同一个文件可以 `reuse: true`）、请作者按新号再选 |
| 同一张图库里已经挑过，这次没写 `mode` | 写库报 ERROR，什么都没写 | 问作者：补上（`add`）、换掉（`replace`），还是只用到这一章（`use`） |
| 库里挑过的图，作者这次说不要了（写在 `reject` 里）；或者 choice 里写了撤回 | 写库或 select 报 ERROR，什么都没写 | 这是撤回，在灵感库里做：`inspiration_write.py adopt`，选择文件写 `withdraw`（只撤其中几样写 `parts`），历史里留着撤回 |
| 写过库以后又改了选择 | `chain` 报现在的选择还没写进库 | 再 adopt 一次；库里已有的报 `UNCHANGED` |
| 排序时图的文件缺了或变了 | `not_ranked` | 重新 collect 再 rank |
| 宿主看不到图 | 观察留 `none` | 只报编号、来源和网页文字，请作者自己看；不描述没看过的图 |
| 写库时修订号对不上 | `CONFLICT` | 重读库再挑，或 `--rebase` |
| 库写成了，日志没写完 | `COMMITTED_INCOMPLETE`（退出码 4） | 不要重写；下一次写库或 `inspiration_write.py history` 会显示、补上 |
| 什么都搜不到、工具用不了 | — | 退回作者发图、作者用文字描述，或者照设定和前文原创；`visual_required` 按开着办的，退到哪一步由作者当章决定，作者的话用 `chapter_policy` 记，只管这一章 |

## 数据放在哪里

- **运行文件夹**：这一次搜索的缓存（请求、两路的原始记录、取到的图、哈希、CLIP 特征缓存、参考图的副本、看图记录和按 sha256 存的看图档案 `observations.archive.json`、作者的选择，重跑以后作废的旧记录在 `outdated/`）。它是本书的私人材料，不进商业版；缓存的键带模型、权重和核过的图片 sha256，换了模型或图就重算。删掉它不影响写作。
- **灵感库**：只记作者挑中的（和明说不要的，免得再推荐）：来源、授权、图片版本、看到了什么、借哪几样、本书怎样改。写库只走 `inspiration_write.py`，每次写都核修订号、留历史副本和日志（`library.history/`）。
- **人物卡、项目档案**：借来的东西写进正文、作者采纳以后才记进去（[灵感库](inspiration-library.md)“采用以后：跨章接续”）。这是另一次写，不和写库算一件事。

## 和别的模块怎样分工

图从哪里来、每条记什么、采用以后怎样跨章接续，见 [灵感库](inspiration-library.md)；素材怎样落进一场戏，见 [声音样本与现场素材卡](../assets/voice-material-card.md) 和 [正文与场景](drafting.md)“落笔前备料”。

每条候选记着每一次被找到的地方（`found_by`：哪一路、哪个搜索词、哪个来源页，那一页写的作者和授权）；候选显示的来源页、作者和授权总是同一页上的：有授权的那一页优先，一起换，不把一页的授权配到另一页的地址上。

来源：作者 2026-10-23 交来的《小说视觉素材五项目接入执行规划 V1》和规划图（五个项目全部接入，分阶段施工，三层状态，全部真实跑通才算接通）。r5.37 按对 r5.35 的审查第一、三点改：候选包编号、看图记录随图不随号、重做后旧记录作废、取图的降级、证据现在还核不核得上、来源和授权按页记。r5.38 按对 r5.37 的审查第一、三点改：同一张图再挑要写清补上、换掉还是只换用处；写库回执绑定 selection 的 sha256，采用链按现在的选择报；看图记录按版本记，沿用最新的一版；排序缓存只按核过的字节记；网页上的文字按这一次读到的算，别的页上的同一张图记进来源。r5.59 按作者 2026-11-19 的决定改：跳转逐跳检查，不碰本机和内网地址；读页和取图都守 robots.txt，不能关；同一站点有间隔，遇到拒绝就停；原图被 robots.txt 挡住或被站点拒绝的不退缩略图；身份照实，配置里没有伪装的口子；页上写的署名只记不认。r5.59 看过 Scrapling 0.5.1（BSD-3-Clause，版权 Karim shoair）的源码：没有接入，也不建议为工坊装它；robots.txt 取不到时按全不许、去掉 robots.txt 开头的 BOM、按 Retry-After 等待、跳转逐跳检查这几样参考了它的做法，代码是工坊自己写的，没有复制它的代码。Crawl4AI 浏览器设置收 `user_agent` 这个参数名、读完交回的 `redirected_url`，都没在装了 Crawl4AI 的机器上核对，没验证。r5.59 交付前按审查补了几处：原图因为 robots.txt 这一次取不到、站点在 `blocked_hosts` 里而取不到的，也不退缩略图（网站或作者没有许这张图）；主机名按请求真正去连的写法认（百分号编码、IDNA）；拒绝记在真正拒绝的那个站点上；robots.txt 的四种读法在 Python 3.9、3.11、3.12、3.13 上用同一批新编的 robots.txt（随机组合的一万多份和审查用的十几份）核过，结果一样，没在真实网站上核；括号里的联系方式只收邮箱和网址；review.md 里的网页文字照文字写。r5.59 按作者同日的决定加了工坊自带的读页（`page_reader`，默认 `auto`）：只用 Python 标准库，Crawl4AI 用不了的时候读来源页，守上面同样的规矩；提图的规矩参照 r5.59 评估里的原型，带逗号的 srcset 地址改照 HTML 规范切。自带读页只在本机合成的网页和本机临时服务上测过，没在真实网站上跑过；署名靠 class 名和关键词判断，会漏，也会认错，没验证。接口按官方说明核对：SearXNG 的搜索接口（docs.searxng.org/dev/search_api.html）、Openverse 的图片接口和授权令牌、Crawl4AI 的媒体提取（docs.crawl4ai.com/core/link-media/）、ImageHash 和 OpenCLIP 的源码。例子都是新写的。

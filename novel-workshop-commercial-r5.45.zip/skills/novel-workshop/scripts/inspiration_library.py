#!/usr/bin/env python3
"""The book's inspiration library: reference images and scene material (r5.33, CON-012, references/inspiration-library.md).

python3 inspiration_library.py check LIBRARY [--root DIR]
python3 inspiration_library.py list LIBRARY [--chapter N] [--scene S1] [--status picked] [--kind place] [--subject NAME]
                                            [--format text|json]
python3 inspiration_library.py card LIBRARY --chapter N [--scene S1]

Read-only and offline; it reads both formats. Writing a library (migrating a v1 file, recording what the author took,
going back to an earlier revision) is done by inspiration_write.py only, which checks the library's revision first.

Format 2 (inspiration-library/2, r5.35) keeps four things apart: what was looked at (observation: not looked at, the
thumbnail, the original, or the author's own words, bound to the image's sha256), what the web page says about it
(page_text, never taken for what the image shows), what the author picked and which parts (take, each part stable or
for one scene), and what became the book's fact (established). A picked entry always says which parts are taken;
an entry picked in format 1 without saying so is "legacy_picked": its scope waits for the author.

Format 1 (inspiration-library/1, r5.33 and r5.34) is still read as it was: check uses the r5.33 rules (r5.34's take
fields are checked when present); a picked entry without take is a notice, not a problem, and card never turns it into
the whole image: it is listed as waiting for the author to say which parts. To use format 2, migrate the file with
inspiration_write.py migrate (it keeps the original).

check: the record is complete (ids, kinds, statuses, sources and licences, files and hashes, observations bound to the
image version, which parts a picked entry takes). list: the entries, filtered. card: the picked entries of one
chapter as material blocks for the voice and material card (assets/voice-material-card.md): only the parts taken,
how the book changes them and what is not taken. Whether an image fits the book is the author's call.

r5.38: a taken part may keep the choice that took it (decision) and, when it is for one scene, where it was taken for
(taken_for); check sees a part taken twice. card gives a part for one scene only to that scene: on another chapter's
card it is named as not brought along.

r5.40 (the author's r5.39 report, points 1 and 2): whether a part comes to a scene is decided before anything is
written out, so "整张" taken for one scene no longer brings the whole image to other scenes. A part for one scene
recorded before r5.38 has no taken_for: when the entry has exactly one use, that is its scene; with more uses or none
the record does not say which, so no scene gets it and the card asks the author ("归属待确认"). Reading never changes
the library. A part marked taken_for_unknown (inspiration_write.py marks it when a use is added while the record cannot
say) goes only to the scenes the author has named since. Where every part is held back, the card does not hand out the
entry's "本书改" text as material either.

Also r5.40, after a second reading of the fix: a block for a use that names no scene gets only the parts taken for the
whole chapter, not a part taken for one of its scenes (it compared only the chapter number). The uses a later write
added with mode add or use (r5.38 on) are in the library's own log (NAME.history/log.jsonl); they are not counted when
an old part's scene is read from its entry's uses, so a use r5.39 appended does not become the part's scene, and the
scene it was taken for keeps it (no log: the uses as they stand). Any taken_for_unknown, even one written wrong, holds
the part back. Where some parts are held back, "本书改" is not copied onto the block either (it is one text for the whole
entry and may speak of what is held back): the block points to the entry instead.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

SCHEMA = "inspiration-library/1"
SCHEMA_V2 = "inspiration-library/2"
KINDS = ("place", "person", "prop", "light", "other")
STATUSES = ("to_find", "candidate", "picked", "rejected")
STATUSES_V2 = ("to_find", "candidate", "picked", "legacy_picked", "rejected", "withdrawn")
SOURCE_TYPES = ("author_file", "link", "search", "text")
ENTRY_FIELDS = {"id", "kind", "title", "visible", "source", "status", "use", "conflicts", "note",
                "subject", "suggest", "take", "skip", "adapt"}
ENTRY_FIELDS_V2 = {"id", "kind", "title", "subjects", "status", "source", "image", "observation", "page_text", "suggest",
                   "take", "skip", "adapt", "decision", "established", "use", "conflicts", "replaced_by", "note"}
# r5.34 (the r5.32 review, points 1 and 2): what an image is for (subject), the parts the workshop suggests borrowing
# from a candidate (suggest), the parts the author takes from a picked image (take; "整张" for all of it), the parts the
# author does not want (skip) and how the book changes what it takes (adapt).
LIST_FIELDS = ("suggest", "take", "skip")
WHOLE = "整张"
SOURCE_FIELDS = {"author_file": {"type", "file", "sha256", "creator", "license", "note"},
                 "link": {"type", "url", "site", "creator", "license", "retrieved", "note"},
                 "search": {"type", "queries", "where", "note"},
                 "text": {"type", "ref", "note"}}
SOURCE_FIELDS_V2 = dict(SOURCE_FIELDS, link=SOURCE_FIELDS["link"] | {"image_url", "license_url", "provider"})
# What was looked at, in format 2: nothing yet, the thumbnail, the original image, the author's own words about it, or a
# description carried over from format 1 without saying which image version it came from.
VIEWS = {"none": "没看图", "thumbnail": "只看了缩略图", "original": "看了原图", "author_text": "作者用文字说的",
         "legacy": "旧版记录，没记看的是哪一版"}
PART_SCOPES = {"stable": "稳定", "scene": "这一场", "unspecified": "稳定还是这一场没写"}
HEX64 = re.compile(r"^[0-9a-f]{64}$")
DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
LIMITS = "只核记录全不全：编号、种类、状态、看得见的东西、借哪几样、出处和授权、文件和哈希；不判断图选得好不好，不联网，不改文件。"
LIMITS_V2 = ("只核记录全不全：编号、种类、状态、看过什么（没看、缩略图、原图、作者的话）和对应的图片版本、网页说明和看图分开、"
             "挑中的借哪几样（稳定还是这一场）、出处和授权、文件和哈希；不判断图选得好不好，不联网，不改文件。")


class LibraryError(ValueError):
    pass


def nonempty(value):
    return isinstance(value, str) and bool(value.strip())


def load(path):
    try:
        data = json.loads(Path(path).read_bytes().decode("utf-8-sig"))
    except (OSError, UnicodeError, ValueError) as exc:
        raise LibraryError("cannot read the library: %s" % exc) from exc
    return parse(data)


def parse(data):
    """A library object of format 1 or 2; the shape of the top level only (check does the entries)."""
    if not isinstance(data, dict):
        raise LibraryError("the library is an object with schema, book, note and entries")
    if data.get("schema") == SCHEMA_V2:
        extra = set(data) - {"schema", "book", "note", "revision", "migrated_from", "entries"}
        if extra:
            raise LibraryError("unknown top-level field(s) %s" % ", ".join(sorted(extra)))
        revision = data.get("revision")
        if type(revision) is not int or revision < 0:
            raise LibraryError("revision must be a whole number (0 for a new library); inspiration_write.py raises it on "
                               "every write")
    elif data.get("schema") == SCHEMA:
        if set(data) - {"schema", "book", "note", "entries"}:
            raise LibraryError("the library is an object with schema, book, note and entries")
    else:
        raise LibraryError("schema must be %s or %s" % (SCHEMA_V2, SCHEMA))
    if not isinstance(data.get("entries"), list) or not all(isinstance(e, dict) for e in data["entries"]):
        raise LibraryError("entries must be a list of objects")
    return data


def version(data):
    return 2 if data.get("schema") == SCHEMA_V2 else 1


def uses(entry):
    value = entry.get("use", [])
    return value if isinstance(value, list) else []


def place_ok(item):
    """A use, or a place a part was taken for: {chapter: a positive number, scene: a Scene ID (optional)}."""
    chapter = item.get("chapter") if isinstance(item, dict) else None
    return isinstance(item, dict) and not set(item) - {"chapter", "scene"} and type(chapter) is int and chapter >= 1 \
        and ("scene" not in item or nonempty(item["scene"]))


def place_matches(place, chapter, scene=None):
    return place.get("chapter") == chapter and (scene is None or not place.get("scene") or place.get("scene") == scene)


def place_name(place):
    return "第 %s 章%s" % (place.get("chapter"), (" " + place["scene"]) if place.get("scene") else "")


def subjects(entry):
    if isinstance(entry.get("subjects"), list):
        return [s for s in entry["subjects"] if nonempty(s)]
    return [entry["subject"]] if nonempty(entry.get("subject")) else []


def pending(entry, v):
    """A picked entry whose parts were never said: format 1 picked without take, or format 2 legacy_picked."""
    if v == 2:
        return entry.get("status") == "legacy_picked"
    return entry.get("status") == "picked" and not (isinstance(entry.get("take"), list) and entry["take"])


def check_library(data, root):
    """Problems of every entry, one sentence each; an empty list when the record is complete."""
    return check_report(data, root)[0]


def check_report(data, root, files=True):
    """(problems, notices). Notices are not problems: an old picked entry waiting for its parts, a part that does not
    say stable or one scene. files=False leaves out whether the image files are there and unchanged (r5.37: restore
    tells a broken record from images that are only offline now)."""
    if version(data) == 2:
        return check_v2(data, root, files)
    return check_v1(data, root, files)


def _common(entry, name, problems, fields, statuses):
    extra = set(entry) - fields
    if extra:
        problems.append("%s: unknown field(s) %s" % (name, ", ".join(sorted(extra))))
    if entry.get("kind") not in KINDS:
        problems.append("%s: kind must be one of %s" % (name, ", ".join(KINDS)))
    if entry.get("status") not in statuses:
        problems.append("%s: status must be one of %s" % (name, ", ".join(statuses)))
    if not nonempty(entry.get("title")):
        problems.append("%s: title is empty" % name)
    for item in uses(entry):
        if not place_ok(item):
            problems.append("%s: each use is {chapter: a positive number, scene: a Scene ID}" % name)
    if "use" in entry and not isinstance(entry["use"], list):
        problems.append("%s: use must be a list" % name)
    conflicts = entry.get("conflicts", [])
    if not isinstance(conflicts, list) or not all(nonempty(x) for x in conflicts):
        problems.append("%s: conflicts must be a list of sentences" % name)
    for field in ("suggest", "skip"):
        if field in entry and (not isinstance(entry[field], list) or not all(nonempty(x) for x in entry[field])):
            problems.append("%s: %s must be a list of short phrases, one part each" % (name, field))
    if "adapt" in entry and not nonempty(entry["adapt"]):
        problems.append("%s: adapt must be a nonempty sentence (leave the field out when there is none)" % name)


def _source(entry, name, status, root, problems, fields, v, files=True):
    source = entry.get("source")
    kind = source.get("type") if isinstance(source, dict) else None
    if kind not in SOURCE_TYPES:
        problems.append("%s: source.type must be one of %s" % (name, ", ".join(SOURCE_TYPES)))
        return None
    extra = set(source) - fields[kind]
    if extra:
        problems.append("%s: unknown source field(s) %s" % (name, ", ".join(sorted(extra))))
    if status == "to_find" and kind != "search":
        problems.append("%s: an entry still to find has a search source (queries)" % name)
    if kind == "search":
        queries = source.get("queries")
        if not isinstance(queries, list) or not queries or not all(nonempty(q) for q in queries):
            problems.append("%s: queries must be a nonempty list of search words" % name)
        if status in ("candidate", "picked", "legacy_picked"):
            problems.append("%s: a candidate or picked entry needs the image itself (author_file or link), not "
                            "search words" % name)
    elif kind == "link":
        if not (nonempty(source.get("url")) and re.match(r"^https?://\S+$", source["url"].strip())):
            problems.append("%s: url must be the http(s) address of the page the image is on" % name)
        if not nonempty(source.get("license")):
            problems.append("%s: license is empty: copy what the page says, or write 未核，只作写作参考" % name)
        for field in ("image_url", "license_url"):
            if field in source and not (nonempty(source[field]) and re.match(r"^https?://\S+$", source[field].strip())):
                problems.append("%s: %s must be an http(s) address" % (name, field))
        if "provider" in source and not nonempty(source["provider"]):
            problems.append("%s: provider names the search that found it (searxng, openverse, crawl4ai, …)" % name)
    elif kind == "author_file":
        file_name = source.get("file")
        if not nonempty(file_name):
            problems.append("%s: file is empty" % name)
            return source
        path = (root / file_name).resolve()
        if files and not path.is_file():
            problems.append("%s: file not found: %s" % (name, file_name))
        elif "sha256" in source:
            digest = source["sha256"]
            if not (isinstance(digest, str) and HEX64.match(digest)):
                problems.append("%s: sha256 must be the file's 64-character lowercase hex digest" % name)
            elif files and hashlib.sha256(path.read_bytes()).hexdigest() != digest:
                problems.append("%s: the file changed: its sha256 is not the one recorded" % name)
        elif status in ("picked", "legacy_picked") or (v == 2 and status == "candidate"):
            problems.append("%s: a %s image file needs its sha256" % (name, "picked" if status != "candidate" else
                                                                      "candidate"))
    elif kind == "text":
        if not nonempty(source.get("ref")):
            problems.append("%s: ref must say where in the setting, outline or earlier text this comes from" % name)
    return source


def check_v1(data, root, files=True):
    problems, notices, seen = [], [], set()
    for number, entry in enumerate(data["entries"], 1):
        key = entry.get("id")
        name = key if nonempty(key) else "entry %d" % number
        if not nonempty(key):
            problems.append("%s: id is empty" % name)
        elif key in seen:
            problems.append("%s: the id is used twice" % name)
        seen.add(key)
        _common(entry, name, problems, ENTRY_FIELDS, STATUSES)
        status = entry.get("status")
        if status in ("candidate", "picked") and not nonempty(entry.get("visible")):
            problems.append("%s: visible is empty: write what the image shows, only what can be seen" % name)
        if "take" in entry and (not isinstance(entry["take"], list) or not all(nonempty(x) for x in entry["take"])):
            problems.append("%s: take must be a list of short phrases, one part each" % name)
        if "subject" in entry and not nonempty(entry["subject"]):
            problems.append("%s: subject must be a nonempty sentence (leave the field out when there is none)" % name)
        if "take" in entry and status != "picked":
            problems.append("%s: take is the author's choice and only a picked entry has it; put the parts you suggest "
                            "into suggest" % name)
        if pending(entry, 1):
            # r5.35 (the r5.34 review, point 2): a format-1 record picked before take existed is valid as it was; it
            # is not read as the whole image (card lists it as waiting), and the author says the parts after migration.
            notices.append("%s: picked without take: which parts the author takes is not recorded; card will not use "
                           "it as the whole image. Migrate (inspiration_write.py migrate) and ask the author which "
                           "parts" % name)
        _source(entry, name, status, root, problems, SOURCE_FIELDS, 1, files)
    return problems, notices


def decision_ok(decision):
    return isinstance(decision, dict) and not set(decision) - {"by", "date", "words"} and nonempty(decision.get("by")) \
        and nonempty(decision.get("date")) and ("words" not in decision or nonempty(decision["words"]))


def check_v2(data, root, files=True):
    problems, notices, seen = [], [], set()
    for number, entry in enumerate(data["entries"], 1):
        key = entry.get("id")
        name = key if nonempty(key) else "entry %d" % number
        if not nonempty(key):
            problems.append("%s: id is empty" % name)
        elif key in seen:
            problems.append("%s: the id is used twice" % name)
        seen.add(key)
        _common(entry, name, problems, ENTRY_FIELDS_V2, STATUSES_V2)
        status = entry.get("status")
        if "subjects" in entry and (not isinstance(entry["subjects"], list) or not all(nonempty(x) for x in entry["subjects"])):
            problems.append("%s: subjects must be a list of the book's names for the people, places or things this is "
                            "for" % name)
        if "page_text" in entry and not nonempty(entry["page_text"]):
            problems.append("%s: page_text is what the web page says (title, alt text, caption); leave it out when "
                            "there is none" % name)
        source = _source(entry, name, status, root, problems, SOURCE_FIELDS_V2, 2, files)
        image = entry.get("image")
        if image is not None:
            if not isinstance(image, dict) or set(image) - {"sha256", "width", "height", "format", "bytes"} \
                    or not (isinstance(image.get("sha256"), str) and HEX64.match(image["sha256"])) \
                    or any(k in image and (type(image[k]) is not int or image[k] < 1) for k in ("width", "height", "bytes")):
                problems.append("%s: image is {sha256, width, height, format, bytes} of the image version that was "
                                "fetched" % name)
                image = None
        version_seen = (image or {}).get("sha256") or ((source or {}).get("sha256") if (source or {}).get("type") ==
                                                       "author_file" else None)
        observation = entry.get("observation")
        view = None
        if observation is not None:
            if not isinstance(observation, dict) or set(observation) - {"scope", "image_sha256", "seen", "unclear", "by",
                                                                         "date"}:
                problems.append("%s: observation is {scope, image_sha256, seen, unclear, by, date}" % name)
            else:
                view = observation.get("scope")
                if view not in VIEWS:
                    problems.append("%s: observation.scope must be one of %s" % (name, ", ".join(VIEWS)))
                elif view == "none":
                    if any(k in observation for k in ("seen", "unclear")):
                        problems.append("%s: nobody looked at the image (scope none): seen and unclear stay empty; what "
                                        "the page says goes into page_text" % name)
                else:
                    if not nonempty(observation.get("seen")):
                        problems.append("%s: observation.seen is empty: write what the image shows, only what can be "
                                        "seen" % name)
                    if view in ("thumbnail", "original"):
                        digest = observation.get("image_sha256")
                        if not (isinstance(digest, str) and HEX64.match(digest)):
                            problems.append("%s: an observation of the %s names the image version it looked at "
                                            "(image_sha256)" % (name, view))
                        elif version_seen and digest != version_seen:
                            problems.append("%s: the observation was of another image version (image_sha256 is not the "
                                            "image's sha256): look again" % name)
                        elif not version_seen:
                            problems.append("%s: an observation of the %s needs the image it looked at: image.sha256 or "
                                            "the author file's sha256" % (name, view))
                    if view in ("thumbnail", "original", "author_text") and not nonempty(observation.get("by")):
                        problems.append("%s: observation.by says who looked (the workshop with the host's image viewer, "
                                        "a named vision model, or the author)" % name)
                for field in ("unclear", "by"):
                    if field in observation and not nonempty(observation[field]):
                        problems.append("%s: observation.%s must be a nonempty sentence (leave it out when there is "
                                        "none)" % (name, field))
                if "date" in observation and not (isinstance(observation["date"], str) and DATE.match(observation["date"])):
                    problems.append("%s: observation.date is YYYY-MM-DD" % name)
        take = entry.get("take")
        if take is not None:
            if not isinstance(take, list) or not all(
                    isinstance(t, dict)
                    and not set(t) - {"part", "scope", "subject", "decision", "taken_for", "taken_for_unknown"}
                    and nonempty(t.get("part")) and t.get("scope") in PART_SCOPES
                    and ("subject" not in t or nonempty(t["subject"]))
                    and ("decision" not in t or decision_ok(t["decision"]))
                    and ("taken_for" not in t or (t.get("scope") == "scene" and isinstance(t["taken_for"], list)
                                                  and t["taken_for"] and all(place_ok(p) for p in t["taken_for"])))
                    and ("taken_for_unknown" not in t or (t.get("scope") == "scene" and t["taken_for_unknown"] is True))
                    for t in take):
                problems.append("%s: take is a list of {part, scope: stable|scene, subject}: one part the author takes "
                                "each (a part kept from an earlier choice may also carry that choice as decision: "
                                "{by, date, words}; a part for one scene may say which, taken_for: [{chapter, scene}], "
                                "or that the record does not say which, taken_for_unknown: true)" % name)
                take = None
            elif len({t["part"].strip() for t in take}) != len(take):
                problems.append("%s: a part is taken twice" % name)
        if status == "picked":
            if not take:
                problems.append("%s: a picked entry says which parts the author takes (take: [{part: \"布局：……\", "
                                "scope: \"stable\"}], or part \"%s\" for the whole image)" % (name, WHOLE))
            elif any(t["part"].strip() == WHOLE for t in take) and not (
                    view in ("thumbnail", "original", "author_text", "legacy") and nonempty((observation or {}).get("seen"))):
                problems.append("%s: \"%s\" takes everything the image shows, so it needs an observation of the image "
                                "(seen): list the parts instead, or look at it first" % (name, WHOLE))
            for t in take or []:
                if t["scope"] == "unspecified":
                    notices.append("%s: %s: stable or only this scene is not recorded" % (name, t["part"]))
        if take and status not in ("picked", "withdrawn"):
            problems.append("%s: take is the author's choice and only a picked entry has it; put the parts you suggest "
                            "into suggest" % name)
        decision = entry.get("decision")
        if decision is not None and not decision_ok(decision):
            problems.append("%s: decision is {by, date, words}: who chose, when, and their words" % name)
        if status in ("picked", "withdrawn") and decision is None:
            problems.append("%s: a %s entry says who decided and when (decision)" % (name, status))
        if status == "legacy_picked":
            notices.append("%s: picked in format 1 without saying which parts: waiting for the author; card lists it as "
                           "waiting and does not use it" % name)
        if status == "withdrawn" and "replaced_by" in entry and not nonempty(entry["replaced_by"]):
            problems.append("%s: replaced_by names the entry that replaced this one" % name)
        established = entry.get("established", [])
        if not isinstance(established, list) or not all(
                isinstance(e, dict) and not set(e) - {"part", "where", "chapter"} and nonempty(e.get("part"))
                and nonempty(e.get("where")) and (type(e.get("chapter")) is int and e["chapter"] > 0)
                for e in established):
            problems.append("%s: established is a list of {part, where, chapter}: a part that became the book's fact, "
                            "where it is recorded and in which chapter's accepted text" % name)
        elif established and status not in ("picked", "withdrawn"):
            problems.append("%s: only a picked entry has parts that became the book's fact" % name)
        if status in ("candidate", "picked") and view is None and source and source.get("type") in ("author_file", "link"):
            problems.append("%s: observation says what was looked at, even when nothing was (scope none)" % name)
    return problems, notices


def select(data, chapter=None, scene=None, status=None, kind=None, subject=None):
    out = []
    for entry in data["entries"]:
        if status and entry.get("status") != status:
            continue
        if kind and entry.get("kind") != kind:
            continue
        if subject is not None and subject not in subjects(entry):
            continue
        if chapter is not None or scene is not None:
            places = [u for u in uses(entry) if isinstance(u, dict)
                      and (chapter is None or u.get("chapter") == chapter) and (scene is None or u.get("scene") == scene)]
            if not places:
                continue
        out.append(entry)
    return out


def origin(entry):
    source = entry.get("source") or {}
    kind = source.get("type")
    if kind == "author_file":
        where = "作者的图 %s" % source.get("file", "")
    elif kind == "link":
        where = "%s %s，授权：%s" % (source.get("site") or "网页", source.get("url", ""), source.get("license", ""))
    elif kind == "text":
        where = source.get("ref", "")
    else:
        where = "搜索词：" + "；".join(source.get("queries") or [])
    return "灵感库 %s（%s）" % (entry.get("id"), where)


def added_uses(path):
    """The uses later writes added to each entry, from the library's own log (r5.40): {entry id: [place, ...]}.

    A write with mode add or use (r5.38 on) adds uses to an entry that was already picked, so the parts it had then were
    taken before those uses existed. The log is NAME.history/log.jsonl next to the library; a line that cannot be read
    is skipped. No log: {}."""
    path = Path(path)
    target = path.with_name(path.stem + ".history") / "log.jsonl"
    out = {}
    if not target.is_file():
        return out
    for line in target.read_bytes().decode("utf-8", "replace").splitlines():
        try:
            record = json.loads(line)
        except ValueError:
            continue
        if not isinstance(record, dict) or record.get("action") != "adopt" or not isinstance(record.get("changes"), dict):
            continue
        for key, change in record["changes"].items():
            if isinstance(change, dict) and change.get("mode") in ("add", "use") and isinstance(change.get("use_added"), list):
                out.setdefault(key, []).extend(dict(p) for p in change["use_added"] if place_ok(p))
    return out


def part_places(entry, t, later=()):
    """Where a taken part may go (r5.40): (None, True) for a part that is not for one scene; otherwise (places, settled).

    A part taken for one scene since r5.38 lists its scenes (taken_for). One recorded before r5.38 lists none: when the
    entry has exactly one use, not counting the uses later writes added (later, from the log), that use is the scene it
    was taken for; with more uses, or none, the record does not say which (settled False) and no scene gets it until
    the author says. A part with taken_for_unknown (any value: one written wrong holds the part back too) goes only to
    the scenes the author has named since (taken_for), and stays unsettled for the rest. inspiration_write.py settles
    an old part before it adds a use."""
    if t.get("scope") != "scene":
        return None, True
    named = t.get("taken_for")
    listed = [p for p in named if isinstance(p, dict)] if isinstance(named, list) else []
    if "taken_for_unknown" in t:
        return listed, False
    if isinstance(named, list):
        return listed, True
    only = [u for u in uses(entry) if place_ok(u) and u not in later]
    return (only, True) if len(only) == 1 else ([], False)


def taken(entry, v=1, chapter=None, scene=None, later=()):
    """What a picked entry gives the scene: only the parts the author takes, how the book changes them and what is not
    taken. "整张" brings the whole description of what was seen. A part taken for one scene (scope scene, taken_for)
    is given only to that scene; elsewhere it is named as not brought along (r5.38). Whether a part comes here is
    decided before it is written out, "整张" included; a part whose scene the record does not say goes nowhere and is
    named as waiting for the author (r5.40). scene "" is the block of a use that names no scene: it gets only the
    parts taken for the whole chapter. later: the uses later writes added to this entry (added_uses)."""

    def fits(place):
        if scene == "":
            return place.get("chapter") == chapter and not place.get("scene")
        return place_matches(place, chapter, scene)

    notes = []
    parts, elsewhere, unsettled = [], [], []
    if v == 2:
        observation = entry.get("observation") or {}
        for t in entry.get("take") or []:
            name = t.get("part", "").strip()
            places, settled = part_places(entry, t, later)
            if chapter is not None and places is not None and not any(fits(p) for p in places):
                if settled:
                    elsewhere.append("“%s”只用在%s（为那一场借的）" % (name, "、".join(place_name(p) for p in places)))
                else:
                    unsettled.append("“%s”%s" % (name, "（作者已说明用在%s）" % "、".join(place_name(p) for p in places)
                                                 if places else ""))
                continue
            if name == WHOLE:
                parts.append("%s：%s" % (WHOLE, (observation.get("seen") or "").strip()))
            else:
                parts.append(name + ("（%s）" % PART_SCOPES[t["scope"]] if t.get("scope") in ("stable", "scene") else ""))
        text = "；".join(parts) or "（这里没有要借的）"
        if elsewhere:
            notes.append("不带到这里：%s；这里也要用，请作者说（mode add）" % "；".join(elsewhere))
        if unsettled:
            used = "、".join(place_name(u) for u in uses(entry) if place_ok(u)) or "还没记用处"
            notes.append("归属待确认：%s只为一场借，库里没记是哪一场（这张图用在：%s），哪一场都先不带；"
                         "哪一场要用，请作者说（mode add 带上那一场）" % ("、".join(unsettled), used))
        view = observation.get("scope")
        if view in VIEWS:
            notes.append("看图：" + VIEWS[view])
    else:
        parts = [x.strip() for x in entry.get("take") or [] if isinstance(x, str) and x.strip()]
        text = "；".join(parts) if parts != [WHOLE] else "%s：%s" % (WHOLE, entry.get("visible", "").strip())
    if nonempty(entry.get("adapt")):
        if (elsewhere or unsettled) and not parts:
            notes.append("本书改：（对别处借的那几样说的，这里不用）")
        elif elsewhere or unsettled:
            notes.append("本书改：（写在一起，可能说到不带到这里的那几样，这里不照抄；原话见灵感库 %s，只对这里借的几样用）"
                         % entry.get("id"))
        else:
            notes.append("本书改：" + entry["adapt"].strip())
    skipped = [x.strip() for x in entry.get("skip") or [] if isinstance(x, str) and x.strip()]
    if skipped:
        notes.append("不借：" + "、".join(skipped))
    return "（%s）%s%s" % (entry["id"], text, "（%s）" % "；".join(notes) if notes else "")


def card(data, chapter, scene=None, later=None):
    """Material blocks of one chapter, one per scene, from the picked entries (the card's own field names). A picked
    entry whose parts were never said is listed as waiting and gives nothing to the scene. later: {entry id: the uses
    later writes added}, from added_uses(library path); the command line reads it from the library's log."""
    later = later or {}
    v = version(data)
    chosen = [e for e in select(data, chapter, scene) if e.get("status") in ("picked", "legacy_picked")]
    ready = [e for e in chosen if not pending(e, v)]
    waiting_scope = [e for e in chosen if pending(e, v)]
    scenes = {}
    for entry in ready:
        for use in uses(entry):
            if isinstance(use, dict) and use.get("chapter") == chapter and (scene is None or use.get("scene") == scene):
                scenes.setdefault(use.get("scene") or "", []).append(entry)
    lines = []
    for key in sorted(scenes, key=lambda k: (k == "", k)):
        items = list(dict.fromkeys(id(e) for e in scenes[key]))
        entries = [e for e in ready if id(e) in items]
        lines += ["- **Scene ID**：%s" % (key or "（灵感库里没写是哪一场）"),
                  "- **看得见、摸得到的东西**：" + "；".join(taken(e, v, chapter, key, later.get(e.get("id"), ()))
                                                     for e in entries),
                  "- **出处**：" + "；".join(origin(e) for e in entries),
                  "- **和已定设定不一样的**：" + ("；".join("%s：%s" % (e["id"], c) for e in entries for c in e.get("conflicts", []))
                                          or "无"),
                  ""]
    if waiting_scope:
        lines.append("挑过但没写借哪几样的（不写进素材，先请作者说借哪几样，不按整张写）：")
        lines += ["- %s %s（%s）" % (e["id"], e.get("title", ""), "旧版选过" if v == 1 or e.get("status") == "legacy_picked"
                                    else "待补") for e in waiting_scope]
        lines.append("")
    waiting = [e for e in select(data, chapter, scene, "to_find")]
    if waiting:
        lines.append("还没找到图的（搜索词）：")
        lines += ["- %s %s：%s" % (e["id"], e.get("title", ""), "；".join((e.get("source") or {}).get("queries") or []))
                  for e in waiting]
    if not lines:
        lines.append("第 %d 章在灵感库里没有挑中的条目，也没有待找的。" % chapter)
    return "\n".join(lines).rstrip() + "\n"


def text_list(entries):
    if not entries:
        return "没有符合条件的条目。\n"
    rows = []
    for e in entries:
        where = "、".join("第%s章%s" % (u.get("chapter"), (" " + u["scene"]) if u.get("scene") else "")
                         for u in uses(e) if isinstance(u, dict)) or "—"
        who = ("  给：%s" % "、".join(subjects(e))) if subjects(e) else ""
        rows.append("%s  [%s/%s]  %s  用在：%s%s" % (e.get("id"), e.get("kind"), e.get("status"), e.get("title", ""), where,
                                                 who))
    return "\n".join(rows) + "\n"


def utf8_stdio():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = parser.add_subparsers(dest="command", required=True)
    check = sub.add_parser("check")
    check.add_argument("library", type=Path)
    check.add_argument("--root", type=Path, help="folder the image file names are relative to (default: the library's folder)")
    listing = sub.add_parser("list")
    listing.add_argument("library", type=Path)
    listing.add_argument("--chapter", type=int)
    listing.add_argument("--scene")
    listing.add_argument("--status", choices=STATUSES_V2)
    listing.add_argument("--kind", choices=KINDS)
    listing.add_argument("--subject", help="only the entries for this person, place or thing (the book's own name for it)")
    listing.add_argument("--format", choices=("text", "json"), default="text")
    material = sub.add_parser("card")
    material.add_argument("library", type=Path)
    material.add_argument("--chapter", type=int, required=True)
    material.add_argument("--scene")
    args = parser.parse_args()
    try:
        data = load(args.library)
        if args.command == "check":
            root = (args.root or args.library.parent).resolve()
            problems, notices = check_report(data, root)
            statuses = STATUSES_V2 if version(data) == 2 else STATUSES
            counts = {s: sum(1 for e in data["entries"] if e.get("status") == s) for s in statuses}
            report = {"status": "PROBLEMS" if problems else "OK", "schema": data["schema"], "entries": len(data["entries"]),
                      "by_status": counts, "problems": problems, "notices": notices,
                      "limits": LIMITS_V2 if version(data) == 2 else LIMITS}
            if version(data) == 2:
                report["revision"] = data["revision"]
            print(json.dumps(report, ensure_ascii=False, indent=1))
            return 1 if problems else 0
        if args.command == "list":
            entries = select(data, args.chapter, args.scene, args.status, args.kind, args.subject)
            print(json.dumps(entries, ensure_ascii=False, indent=1) if args.format == "json" else text_list(entries), end="")
            return 0
        if args.chapter < 1:
            raise LibraryError("chapter must be a positive number")
        print(card(data, args.chapter, args.scene, added_uses(args.library)), end="")
        return 0
    except LibraryError as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    sys.exit(main())

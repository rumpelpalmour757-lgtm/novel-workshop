#!/usr/bin/env python3
"""Read-only Chinese prose hints; not an AI detector or editorial verdict."""

import argparse
import bisect
import hashlib
import json
from pathlib import Path
import re
import sys


PLACEHOLDER = re.compile(
    r"\[\[[^\]\n]{1,60}\]\]|"
    r"[【\[]待(?:补|写)[^】\]\n]{0,60}[】\]]|"
    r"(?:正文|后文|后续)(?:内容)?省略|此处(?:补充|续写)(?:正文|情节)"
)

# Scene rules (r5.32, CON-011, references/scene-dramaturgy.md). Three of them run by default: a run of bare dialogue,
# words that tell the reader the tension or the feeling, and a summing-up ending. A book turns one off only by the
# author's decision, written in its rules file under "off" with the reason. "stock-reaction" stays optional ("hints").
# They give places, literally (NWC-1.5, r5.34): a hit in the narration is rewritten or kept with a reason of its own,
# one in a character's line is marked in_quote (the character's own voice). A bare run broken by one line of weather is
# no longer reported although the scene is still not grounded; no hit does not mean the scene is on the page.
HINTS = ("floating-dialogue", "tension-telling", "stock-reaction", "weak-scene-ending",
         "frequent-words", "negation-ending", "parallel-run", "list-of-three")
SCENE_RULES = ("floating-dialogue", "tension-telling", "weak-scene-ending")
# The first of the five revision passes (r5.33, references/revision-passes.md): tics a count can find. On by default,
# like the scene rules, and like them every hit is an ordinary review item (change it, or keep it with a reason).
# A book turns one off the same way, by the author's decision with the reason.
LANGUAGE_RULES = ("frequent-words", "negation-ending", "parallel-run", "list-of-three")
DEFAULT_RULES = SCENE_RULES + LANGUAGE_RULES
# Word families of the forwarded five-pass plan (maintenance voice-passes-2026-10-22): one word used FREQUENT_MIN
# times or more in a chapter is listed at every place.
FREQUENT_WORDS = (("时间连接", ("随即", "旋即", "紧接着", "与此同时")), ("落点动词", ("落在", "停驻", "扫过")),
                  ("持续态", ("仍", "依旧", "依然")), ("次序标注", ("依次", "先后", "逐一", "挨个")),
                  ("突发", ("忽然", "骤然", "猛然", "陡然")), ("手部报备", ("左手", "右手", "另一只手")))
FREQUENT_MIN = 3
# A narration paragraph whose last clause is a "没有……／没再……" brake; NEGATION_MIN of them in a chapter are listed.
NEGATION_MIN = 3
NEGATION_CLAUSE = re.compile(r"没(?:有|再)")
CLAUSE_BREAK = re.compile(r"[，,。！？!?；;：:、]")
# Three or more short one-clause sentences of about the same length in a row: a list of actions, one per sentence.
RUN_SENTENCES = 3
SHORT_MIN, SHORT_MAX, SHORT_SPREAD = 3, 16, 3
# "一个……，一个……，一个……": three or more clauses in a row that each open with 一 and a measure word.
MEASURE = "个只块张把条句声件道片枚根本扇间座位名双副盏层口"
LIST_CLAUSE = r"一[%s][^，、；。！？“”「」]{0,12}" % MEASURE
LIST_OF_THREE = re.compile(LIST_CLAUSE + r"(?:[，、；]" + LIST_CLAUSE + r"){2,}")
BUILT_IN = ("placeholder", "repeated-paragraph")
# A quoted line; an opening mark with no closing one runs to the paragraph end (a quote continued in the next paragraph).
QUOTE = re.compile(r"“[^”]*(?:”|$)|「[^」]*(?:」|$)|『[^』]*(?:』|$)")
# What may stand outside the quotes of a bare line of dialogue: who speaks and a speech verb, at most TAG_MAX characters.
SPEECH_TAG = re.compile(r"说|道|问|答|应|喊|叫|笑|哼|嚷|吼|骂|嘀咕|嘟囔|开口|接话|回答|回道|反问|追问")
TAG_MAX = 8
RUN_MIN = 5
# Words that sum up the atmosphere, the feeling or the time for the reader (the spec's list, and a few of the same kind).
TENSION_LABELS = re.compile(
    r"气氛(?:顿时|一下子|瞬间|骤然|陡然|霎时|一时间|一时)?(?:变得)?(?:更加|越发|愈发)?(?:紧张|凝固|凝重|压抑|剑拔弩张|尴尬)"
    r"|空气(?:仿佛|好像|似乎|像是)?(?:在这一刻|一下子|瞬间|顿时)?(?:都)?(?:凝固|凝结|静止|停滞)"
    r"|死一般的?(?:寂静|沉默)|剑拔弩张|火药味十足|压抑的气氛|各怀鬼胎"
    r"|(?:心中|心里|心头)?五味杂陈|百感交集|感到一阵(?:莫名的?)?(?:恐慌|心慌|不安)"
    r"|(?:内心|心中|心里|心头)(?:掀起|翻起|涌起)(?:了)?(?:一阵)?(?:惊涛骇浪|轩然大波|滔天巨浪)"
    r"|(?:眼中|眼里|眸中|眼底)(?:闪过|划过|掠过)一(?:丝|抹)|一丝不易察觉的"
    r"|意味深长的(?:笑|笑容|弧度|眼神)"
    r"|(?:聊|谈|说|吵|争|打)了(?:很久|好久|许久|很长时间|好一阵子?)|经过一番(?:苦战|激战|鏖战|争吵|交涉|周旋|商量)"
)
# A few ready-made bodily reactions (optional): the same tic in every book. NWC-1.5 (r5.34) moved the ready-made smile
# ("嘴角扬起一抹笑") here from tension-telling: it is an action, if a worn one, not a word that sums up for the reader.
STOCK_REACTIONS = re.compile(
    r"嘴角(?:勾起|扬起|微微上扬|上扬|噙着)(?:一抹|一丝)"
    r"|指节(?:都)?(?:泛白|发白)|瞳孔(?:猛地|骤然|猛然|微微)?(?:一缩|骤缩|猛缩|收缩)|倒吸(?:了)?一口(?:凉气|冷气)"
    r"|呼吸(?:猛地|骤然)?一滞|心(?:中|里|头)(?:猛地|骤然)?一(?:紧|沉|凛|颤)|青筋(?:暴起|暴突|突起)"
    r"|手心(?:里)?(?:全是|满是|沁出了?|渗出了?)(?:冷)?汗"
)
# Summing-up or deflating lines in the last two paragraphs of the text or of a scene.
WEAK_ENDINGS = re.compile(
    r"(?:一切|这)(?:才|只是|不过是)(?:刚刚)?(?:开始|序幕|开端)(?=[。！？!?…—”」』，,\s]|$|而已|呢|了)"
    r"|(?:前方|未来|以后|今后)的路还(?:很)?(?:长|远)"
    r"|明白了一个道理|(?:一切|什么)都(?:将)?不一样了|再也回不去了"
    r"|新的(?:征程|篇章|旅程|故事)(?:即将|就要|正式)?(?:开始|开启|展开|拉开)|(?:风暴|暴风雨)(?:即将|就要)(?:来临|到来)"
    r"|命运的齿轮|各自回(?:去|房|家)(?:休息|睡下|睡了)?|不欢而散"
)
# A line of its own made only of break marks (***, ※※※, ———) ends a scene.
SCENE_BREAK = re.compile(r"(?:[*＊※◆◇○●☆★#＃=～~·•\-－—_]\s*){3,}")
HINT_MESSAGES = {
    "floating-dialogue": "连着 %d 段只有台词和说话标签：对话缺少动作和道具锚点，场景脱离了物理空间。按分场戏剧张力与正文具象化"
                         "（scene-dramaturgy.md）植入微动作或道具操作；有意连着走的，写明这一处的理由保留（CON-011）。",
    "tension-telling": "情绪、氛围或时间的直述词，替读者下了结论：改写成具体的生理反应、视线变化或操作道具的细节"
                       "（分场戏剧张力与正文具象化 2.1）；在这里不是下结论的，写明这一处的理由保留（CON-011）。",
    "stock-reaction": "现成的身体反应：同一种反应反复出现、换到哪本书里都一样时，换成这一场独有的动作或道具细节。",
    "weak-scene-ending": "泄气式收尾：停在翻转的最高点或新悬念出现的那一下，删掉总结和“各自回家”式的尾巴"
                         "（分场戏剧张力与正文具象化第 3 节第 4 拍）；在这里不是泄气的，写明这一处的理由保留（CON-011）。",
    "frequent-words": "“%s”全章出现 %d 次（%s）：逐处看能不能删、换词或并进邻句；是作者的口吻或有意的反复就留，写明理由"
                      "（修改的五道工序第一遍）。",
    "negation-ending": "段尾用“没有……”“没再……”收住，全章 %d 段：看哪几处能删，或者换成一个正面的动作收住"
                       "（修改的五道工序第一遍）。",
    "parallel-run": "连着 %d 句长短相近、各自一个动作的短句，像分镜：过渡动作降成状语或删掉，关键动作放慢，造一处长短落差"
                    "（修改的五道工序第一、四遍）。",
    "list-of-three": "“一个……，一个……，一个……”的排比：看是不是在列清单，能不能只挑一样写实（修改的五道工序第一遍）。",
}
RULE_LABELS = {
    "placeholder": "占位或交稿备注", "repeated-paragraph": "整段重复", "floating-dialogue": "光台词",
    "tension-telling": "情绪、氛围、时间的直述词", "stock-reaction": "现成的身体反应", "weak-scene-ending": "泄气式收尾",
    "frequent-words": "常见套话词用得太多", "negation-ending": "段尾否定", "parallel-run": "等长短句连排",
    "list-of-three": "“一个……一个……一个……”",
}
IN_QUOTE_NOTE = "在台词里：是人物自己的口吻就保留。"


def nonempty_string(value):
    return isinstance(value, str) and bool(value.strip())


def validate_rules(value):
    if not isinstance(value, dict) or set(value) - {"terms", "ignore", "hints", "off"}:
        raise ValueError("Rules must be an object with only terms, ignore, hints and off")
    terms, ignores = value.get("terms", []), value.get("ignore", [])
    hints, off = value.get("hints", []), value.get("off", [])
    if not isinstance(terms, list) or not isinstance(ignores, list):
        raise ValueError("terms and ignore must be arrays")
    if not isinstance(hints, list) or any(not isinstance(h, str) or h not in HINTS for h in hints) \
            or len(set(hints)) != len(hints):
        raise ValueError("hints must be an array of distinct names from: " + ", ".join(HINTS))
    # Turning a default rule off is the author's decision for this book (CON-011, exceptions, for the scene rules; the
    # same for the language scans of r5.33): rule and reason.
    if not isinstance(off, list) or any(not isinstance(x, dict) or set(x) != {"rule", "reason"}
                                        or x.get("rule") not in DEFAULT_RULES or not nonempty_string(x.get("reason"))
                                        for x in off):
        raise ValueError("off must be an array of {rule, reason}: a default rule (%s) the author turned off for this "
                         "book, and the author's reason" % ", ".join(DEFAULT_RULES))
    off_rules = [x["rule"] for x in off]
    if len(set(off_rules)) != len(off_rules) or set(off_rules) & set(hints):
        raise ValueError("A default rule is turned off once, and not also listed under hints")
    ids = set()
    for term in terms:
        if not isinstance(term, dict) or set(term) != {"id", "text", "min_occurrences"}:
            raise ValueError("Each term needs id, text, min_occurrences")
        if not nonempty_string(term["id"]) or not nonempty_string(term["text"]):
            raise ValueError("Term id and text must be nonempty strings")
        if term["id"] in ids or term["id"] in BUILT_IN or term["id"] in HINTS:
            raise ValueError("Rule IDs must be unique and not reserved")
        ids.add(term["id"])
        count = term["min_occurrences"]
        if type(count) is not int or count < 1:
            raise ValueError("min_occurrences must be a positive integer")
    for item in ignores:
        if not isinstance(item, dict) or set(item) != {"rule", "line", "text", "reason"}:
            raise ValueError("Each ignore needs rule, line, text, reason")
        if item["rule"] not in ids | set(BUILT_IN) | set(HINTS):
            raise ValueError("Ignore refers to an unknown rule")
        if type(item["line"]) is not int or item["line"] < 1:
            raise ValueError("Ignore line must be a positive integer")
        if not all(nonempty_string(item[k]) for k in ("text", "reason")):
            raise ValueError("Ignore text and reason must be nonempty strings")
    # Two values, as before r5.32; the hints are read from the validated object by the caller.
    return terms, ignores


def paragraphs_of(text, paragraph_mode):
    """(start offset, text) of every paragraph, surrounding whitespace removed; empty ones included."""
    separator = r"\n" if paragraph_mode == "line" else r"\n[ \t\r]*\n"
    out, offset = [], 0
    # Split on source spans, without normalizing newlines or moving offsets.
    for match in list(re.finditer(separator, text)) + [None]:
        end = match.start() if match else len(text)
        raw = text[offset:end]
        out.append((offset + len(raw) - len(raw.lstrip()), raw.strip()))
        offset = match.end() if match else len(text)
    return out


def is_bare_dialogue(paragraph):
    """A paragraph of quoted speech with nothing outside the quotes but who speaks and a speech verb."""
    if not QUOTE.search(paragraph):
        return False
    outside = "".join(ch for ch in QUOTE.sub("", paragraph) if ch.isalnum())
    return not outside or (len(outside) <= TAG_MAX and SPEECH_TAG.search(outside) is not None)


def han_count(text):
    return sum(1 for ch in text if "一" <= ch <= "鿿")


SENTENCE = re.compile(r"[^。！？!?]+[。！？!?]+")


def is_short_sentence(sentence):
    """One clause (no comma, colon or semicolon inside) of SHORT_MIN to SHORT_MAX Han characters; a system panel or a
    【label】 line is not narration."""
    body = sentence.rstrip("。！？!?")
    return not CLAUSE_BREAK.search(body) and "【" not in body and SHORT_MIN <= han_count(body) <= SHORT_MAX


def negation_tail(paragraph):
    """Offset of the last clause of a narration paragraph when it is a 没有／没再 brake; None otherwise."""
    tail = paragraph.rstrip().rstrip("。！？!?…—")
    if not tail or tail[-1] in "”」』":
        return None
    breaks = list(CLAUSE_BREAK.finditer(tail))
    start = breaks[-1].end() if breaks else 0
    clause = tail[start:]
    if NEGATION_CLAUSE.search(clause) and han_count(clause) <= 16 and not QUOTE.search(clause):
        return start + len(clause) - len(clause.lstrip())
    return None


def inspect_text(text, rules=None, paragraph_mode="blank", hints=(), scene_rules=True, language_rules=True):
    """scene_rules=False reads the text as r5.31 did, with no default rule; language_rules=False as r5.32 did (scene rules
    only). Both are only for comparing versions; the gate never sets them."""
    if paragraph_mode not in {"blank", "line"}:
        raise ValueError("paragraph_mode must be blank or line")
    rules = {} if rules is None else rules
    terms, ignores = validate_rules(rules)
    rule_hints = rules.get("hints", [])
    off = {x["rule"] for x in rules.get("off", [])}
    unknown = [h for h in hints if h not in HINTS]
    if unknown:
        raise ValueError("Unknown hint: " + ", ".join(unknown))
    on = (SCENE_RULES + (LANGUAGE_RULES if language_rules else ())) if scene_rules else ()
    defaults = {h for h in on if h not in off}
    enabled = [h for h in HINTS if h in defaults | set(rule_hints) | set(hints)]
    starts = [0] + [m.end() for m in re.finditer("\n", text)]

    def locate(offset):
        index = bisect.bisect_right(starts, offset) - 1
        return index + 1, offset - starts[index] + 1

    findings = []

    def add(rule, start, end, message, **extra):
        line, column = locate(start)
        # Complete matched text stays internal for exact, scoped exemptions.
        findings.append({"rule": rule, "line": line, "column": column,
                         "quote": text[start:end][:160], "message": message,
                         "_matched": text[start:end], **extra})

    for match in PLACEHOLDER.finditer(text):
        add("placeholder", match.start(), match.end(),
            "复核是否为遗留写作备注；若为故事内真实文本可以保留。")

    paragraphs = paragraphs_of(text, paragraph_mode)
    seen = {}
    for start, paragraph in paragraphs:
        if len(paragraph) >= 12:
            if paragraph in seen:
                add("repeated-paragraph", start, start + len(paragraph),
                    "整段字面重复；检查是否为有意回声、引文或误粘贴。",
                    first_line=seen[paragraph])
            else:
                seen[paragraph] = locate(start)[0]

    for term in terms:
        matches = list(re.finditer(re.escape(term["text"]), text))
        if len(matches) >= term["min_occurrences"]:
            for match in matches:
                add(term["id"], match.start(), match.end(),
                    "达到项目设定的字面复核阈值；不是自动禁用。",
                    count=len(matches), threshold=term["min_occurrences"])

    if enabled:
        written = [(start, paragraph) for start, paragraph in paragraphs if paragraph]
        quoted = [(start + m.start(), start + m.end()) for start, paragraph in written
                  for m in QUOTE.finditer(paragraph)]

        def in_quote(offset):
            return any(a <= offset < b for a, b in quoted)

        def add_phrases(rule, pattern, spans):
            for start, paragraph in spans:
                for match in pattern.finditer(paragraph):
                    at = start + match.start()
                    inside = in_quote(at)
                    add(rule, at, start + match.end(), HINT_MESSAGES[rule] + (IN_QUOTE_NOTE if inside else ""),
                        in_quote=inside)

        if "floating-dialogue" in enabled:
            run = []
            for item in written + [None]:
                if item is not None and is_bare_dialogue(item[1]):
                    run.append(item)
                    continue
                if len(run) >= RUN_MIN:
                    first_start, first = run[0]
                    add("floating-dialogue", first_start, first_start + len(first),
                        HINT_MESSAGES["floating-dialogue"] % len(run),
                        paragraphs=len(run), last_line=locate(run[-1][0])[0])
                run = []
        if "tension-telling" in enabled:
            add_phrases("tension-telling", TENSION_LABELS, written)
        if "stock-reaction" in enabled:
            add_phrases("stock-reaction", STOCK_REACTIONS, written)
        if "weak-scene-ending" in enabled:
            endings, scene = [], []
            for item in written + [None]:
                if item is None or SCENE_BREAK.fullmatch(item[1]):
                    endings.extend(scene[-2:])
                    scene = []
                else:
                    scene.append(item)
            add_phrases("weak-scene-ending", WEAK_ENDINGS, endings)
        if "frequent-words" in enabled:
            for family, words in FREQUENT_WORDS:
                for word in words:
                    places = [m.start() for m in re.finditer(re.escape(word), text)]
                    if len(places) >= FREQUENT_MIN:
                        for at in places:
                            inside = in_quote(at)
                            add("frequent-words", at, at + len(word),
                                HINT_MESSAGES["frequent-words"] % (word, len(places), family)
                                + (IN_QUOTE_NOTE if inside else ""),
                                word=word, count=len(places), in_quote=inside)
        if "negation-ending" in enabled:
            brakes = []
            for start, paragraph in written:
                at = negation_tail(paragraph)
                if at is not None and not in_quote(start + at):
                    brakes.append((start + at, paragraph[at:].rstrip()))
            if len(brakes) >= NEGATION_MIN:
                for at, clause in brakes:
                    add("negation-ending", at, at + len(clause), HINT_MESSAGES["negation-ending"] % len(brakes),
                        count=len(brakes))
        if "parallel-run" in enabled:
            runs, run = [], []

            def close():
                if len(run) >= RUN_SENTENCES:
                    runs.append(list(run))
                run.clear()

            for start, paragraph in written:
                if QUOTE.search(paragraph) or SCENE_BREAK.fullmatch(paragraph):
                    close()
                    continue
                for m in SENTENCE.finditer(paragraph):
                    sentence = m.group().strip()
                    if not is_short_sentence(sentence):
                        close()
                        continue
                    lengths = [han_count(s) for _, s in run] + [han_count(sentence)]
                    if run and max(lengths) - min(lengths) > SHORT_SPREAD:
                        close()
                    run.append((start + m.start() + len(m.group()) - len(m.group().lstrip()), sentence))
            close()
            for item in runs:
                first_at, first = item[0]
                add("parallel-run", first_at, first_at + len(first), HINT_MESSAGES["parallel-run"] % len(item),
                    sentences=len(item), last_line=locate(item[-1][0])[0])
        if "list-of-three" in enabled:
            for start, paragraph in written:
                for m in LIST_OF_THREE.finditer(paragraph):
                    at = start + m.start()
                    inside = in_quote(at)
                    add("list-of-three", at, start + m.end(),
                        HINT_MESSAGES["list-of-three"] + (IN_QUOTE_NOTE if inside else ""), in_quote=inside)

    findings.sort(key=lambda f: (f["line"], f["column"], f["rule"]))
    active, suppressed, used = [], [], set()
    for finding in findings:
        matched = finding.pop("_matched")
        exemptions = [(i, item) for i, item in enumerate(ignores)
                      if item["rule"] == finding["rule"]
                      and item["line"] == finding["line"]
                      and item["text"] == matched]
        if exemptions:
            used.update(i for i, _ in exemptions)
            suppressed.append({**finding, "reasons": [x["reason"] for _, x in exemptions]})
        else:
            active.append(finding)
    return {
        "status": "REVIEW" if active else "NO_FLAGS",
        "non_whitespace_characters": sum(not ch.isspace() for ch in text),
        "counting_basis": "Unicode non-whitespace characters including punctuation",
        "paragraph_mode": paragraph_mode,
        "checks_run": list(BUILT_IN) + [t["id"] for t in terms] + enabled,
        "turned_off": [dict(x) for x in rules.get("off", [])],
        "findings": active, "suppressed": suppressed,
        "unused_ignores": [item for i, item in enumerate(ignores) if i not in used],
        "limits": "仅为字面复核线索，不判断文笔、完整性、原创性或AI来源；不修改文件。",
    }


def utf8_stdio():
    """Reports are UTF-8 on every platform; a Windows pipe would otherwise use the local code page."""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manuscript", type=Path)
    parser.add_argument("--rules", type=Path)
    parser.add_argument(
        "--paragraph-mode", choices=("blank", "line"), default="blank",
        help="paragraph boundaries for repeated paragraphs and the paragraph hints: blank lines (default), or each "
             "nonempty line",
    )
    parser.add_argument(
        "--hint", action="append", choices=HINTS + ("all",), default=[],
        help="also run an optional hint (repeatable; 'all' for every one); the three scene rules and the four language "
             "scans run anyway unless the rules file turns one off by the author's decision, see prose-audit.md",
    )
    parser.add_argument(
        "--format", choices=("json", "text"), default="json",
        help="json (default; what the delivery gate reads) or text: a short report in Chinese to read after writing a "
             "chapter, the first of the five revision passes",
    )
    args = parser.parse_args()
    hints = HINTS if "all" in args.hint else tuple(args.hint)
    try:
        data = args.manuscript.read_bytes()
        rules = json.loads(args.rules.read_text(encoding="utf-8")) if args.rules else {}
        report = inspect_text(data.decode("utf-8-sig"), rules, args.paragraph_mode, hints)
        report.update({"file": str(args.manuscript),
                       "sha256": hashlib.sha256(data).hexdigest()})
        print(text_report(report) if args.format == "text" else json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    except (OSError, UnicodeError, ValueError, TypeError) as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False))
        return 2


def text_report(report):
    """The report for a person: what was found where, grouped by rule; the same facts as the JSON, nothing more."""
    findings = report["findings"]
    out = ["文字检查：%s（sha256 %s…，非空白字符 %d，分段：%s）" % (
               report.get("file", ""), report.get("sha256", "")[:12], report["non_whitespace_characters"],
               "空行" if report["paragraph_mode"] == "blank" else "每行一段"),
           "结果：%s" % ("要看的 %d 处" % len(findings) if findings else "没有命中（只说明这几条字面规则没命中，不说明文字没问题）")]
    if report["turned_off"]:
        out.append("本书关掉的：" + "；".join("%s（%s）" % (x["rule"], x["reason"]) for x in report["turned_off"]))
    groups = {}
    for finding in findings:
        groups.setdefault(finding["rule"], []).append(finding)
    for rule in [r for r in report["checks_run"] if r in groups] + [r for r in groups if r not in report["checks_run"]]:
        items = groups[rule]
        out.append("")
        out.append("【%s】%s，%d 处" % (rule, RULE_LABELS.get(rule, "项目用词"), len(items)))
        if rule == "frequent-words":
            words = {}
            for f in items:
                words.setdefault(f["word"], []).append(f)
            for word, places in words.items():
                out.append("  “%s” %d 次：第 %s 行" % (word, places[0]["count"],
                                                     "、".join(str(f["line"]) for f in places)))
            out.append("  " + items[0]["message"].split("：", 1)[1])
            continue
        for f in items:
            where = "第 %d 行" % f["line"] + ("—第 %d 行" % f["last_line"] if f.get("last_line", f["line"]) != f["line"] else "")
            quote = f["quote"].replace("\n", " ")
            out.append("  %s：%s%s" % (where, quote[:40] + ("…" if len(quote) > 40 else ""), "（台词里）" if f.get("in_quote") else ""))
        out.append("  " + items[0]["message"])
    if report["suppressed"]:
        out.append("")
        out.append("按规则文件放过的 %d 处（有作者的理由）。" % len(report["suppressed"]))
    out.append("")
    out.append(report["limits"])
    return "\n".join(out)


if __name__ == "__main__":
    sys.exit(main())

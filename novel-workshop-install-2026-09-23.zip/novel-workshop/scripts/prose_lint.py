#!/usr/bin/env python3
"""Read-only Chinese prose hints; not an AI detector or editorial verdict."""

import argparse
import bisect
import hashlib
import json
from pathlib import Path
import re
import sys


PLACEHOLDER = re.compile(
    r"\[\[[^\]\n]{1,60}\]\]|"
    r"[【\[]待(?:补|写)[^】\]\n]{0,60}[】\]]|"
    r"(?:正文|后文|后续)(?:内容)?省略|此处(?:补充|续写)(?:正文|情节)"
)


def nonempty_string(value):
    return isinstance(value, str) and bool(value.strip())


def validate_rules(value):
    if not isinstance(value, dict) or set(value) - {"terms", "ignore"}:
        raise ValueError("Rules must be an object with only terms and ignore")
    terms, ignores = value.get("terms", []), value.get("ignore", [])
    if not isinstance(terms, list) or not isinstance(ignores, list):
        raise ValueError("terms and ignore must be arrays")
    ids = set()
    for term in terms:
        if not isinstance(term, dict) or set(term) != {"id", "text", "min_occurrences"}:
            raise ValueError("Each term needs id, text, min_occurrences")
        if not nonempty_string(term["id"]) or not nonempty_string(term["text"]):
            raise ValueError("Term id and text must be nonempty strings")
        if term["id"] in ids or term["id"] in {"placeholder", "repeated-paragraph"}:
            raise ValueError("Rule IDs must be unique and not reserved")
        ids.add(term["id"])
        count = term["min_occurrences"]
        if type(count) is not int or count < 1:
            raise ValueError("min_occurrences must be a positive integer")
    for item in ignores:
        if not isinstance(item, dict) or set(item) != {"rule", "line", "text", "reason"}:
            raise ValueError("Each ignore needs rule, line, text, reason")
        if item["rule"] not in ids | {"placeholder", "repeated-paragraph"}:
            raise ValueError("Ignore refers to an unknown rule")
        if type(item["line"]) is not int or item["line"] < 1:
            raise ValueError("Ignore line must be a positive integer")
        if not all(nonempty_string(item[k]) for k in ("text", "reason")):
            raise ValueError("Ignore text and reason must be nonempty strings")
    return terms, ignores


def inspect_text(text, rules=None):
    terms, ignores = validate_rules({} if rules is None else rules)
    starts = [0] + [m.end() for m in re.finditer("\n", text)]

    def locate(offset):
        index = bisect.bisect_right(starts, offset) - 1
        return index + 1, offset - starts[index] + 1

    findings = []

    def add(rule, start, end, message, **extra):
        line, column = locate(start)
        # Complete matched text stays internal for exact, scoped exemptions.
        findings.append({"rule": rule, "line": line, "column": column,
                         "quote": text[start:end][:160], "message": message,
                         "_matched": text[start:end], **extra})

    for match in PLACEHOLDER.finditer(text):
        add("placeholder", match.start(), match.end(),
            "复核是否为遗留写作备注；若为故事内真实文本可以保留。")

    seen = {}
    offset = 0
    for match in list(re.finditer(r"\n[ \t\r]*\n", text)) + [None]:
        end = match.start() if match else len(text)
        raw = text[offset:end]
        paragraph = raw.strip()
        start = offset + len(raw) - len(raw.lstrip())
        if len(paragraph) >= 12:
            if paragraph in seen:
                add("repeated-paragraph", start, start + len(paragraph),
                    "整段字面重复；检查是否为有意回声、引文或误粘贴。",
                    first_line=seen[paragraph])
            else:
                seen[paragraph] = locate(start)[0]
        offset = match.end() if match else len(text)

    for term in terms:
        matches = list(re.finditer(re.escape(term["text"]), text))
        if len(matches) >= term["min_occurrences"]:
            for match in matches:
                add(term["id"], match.start(), match.end(),
                    "达到项目设定的字面复核阈值；不是自动禁用。",
                    count=len(matches), threshold=term["min_occurrences"])

    findings.sort(key=lambda f: (f["line"], f["column"], f["rule"]))
    active, suppressed, used = [], [], set()
    for finding in findings:
        matched = finding.pop("_matched")
        exemptions = [(i, item) for i, item in enumerate(ignores)
                      if item["rule"] == finding["rule"]
                      and item["line"] == finding["line"]
                      and item["text"] == matched]
        if exemptions:
            used.update(i for i, _ in exemptions)
            suppressed.append({**finding, "reasons": [x["reason"] for _, x in exemptions]})
        else:
            active.append(finding)
    return {
        "status": "REVIEW" if active else "NO_FLAGS",
        "non_whitespace_characters": sum(not ch.isspace() for ch in text),
        "counting_basis": "Unicode non-whitespace characters including punctuation",
        "checks_run": ["placeholder", "repeated-paragraph"] + [t["id"] for t in terms],
        "findings": active, "suppressed": suppressed,
        "unused_ignores": [item for i, item in enumerate(ignores) if i not in used],
        "limits": "仅为字面复核线索，不判断文笔、完整性、原创性或AI来源；不修改文件。",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manuscript", type=Path)
    parser.add_argument("--rules", type=Path)
    args = parser.parse_args()
    try:
        data = args.manuscript.read_bytes()
        rules = json.loads(args.rules.read_text(encoding="utf-8")) if args.rules else {}
        report = inspect_text(data.decode("utf-8-sig"), rules)
        report.update({"file": str(args.manuscript),
                       "sha256": hashlib.sha256(data).hexdigest()})
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    except (OSError, UnicodeError, ValueError, TypeError) as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    sys.exit(main())

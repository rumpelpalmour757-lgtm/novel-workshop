"""r5.47 Gemini 接通检查：写作台的“查可用模型”“用合成示例试一次”，和不开写作台也能双击的 check-gemini。

行为（只发合成示例、不发文稿，“已真实接通”只认官方地址上的成功调用，按 Google 错误表说明几种失败，检查脚本的退出码和报告）
在 workbench_check.mjs 里测，由 test_r546_workbench.py 运行（不联网，Gemini 用本机模拟服务或替身 fetch，不算真实接通）。
这里只查 Node 之外能查的：启动器在、Windows 启动器是 ASCII 加 CRLF、两种导出都带上这几个文件。
"""
import importlib.util
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILL = HERE.parent / "skills" / "novel-workshop"
FOLDER = SKILL / "scripts" / "oh-story"
NEW = ("scripts/oh-story/gemini-check.mjs", "scripts/oh-story/check-gemini.cmd", "scripts/oh-story/check-gemini.command")


class Launchers(unittest.TestCase):
    def test_windows_launcher_is_ascii_crlf_and_waits(self):
        data = (FOLDER / "check-gemini.cmd").read_bytes()
        text = data.decode("ascii")
        self.assertEqual(text.count("\r\n"), text.count("\n"))
        self.assertIn('node "%~dp0gemini-check.mjs" %*', text)
        self.assertIn("pause", text.splitlines()[-1])

    def test_unix_launcher_runs_the_check(self):
        text = (FOLDER / "check-gemini.command").read_text(encoding="utf-8")
        self.assertTrue(text.startswith("#!/bin/sh\n"))
        self.assertIn("exec node ./gemini-check.mjs", text)


class Exports(unittest.TestCase):
    def test_both_profiles_carry_the_check(self):
        spec = importlib.util.spec_from_file_location("export_portable_r547_gemini", SKILL / "scripts" / "export_portable.py")
        exporter = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(exporter)
        for mode in ("personal", "sale"):
            self.assertLessEqual(set(NEW), set(exporter.collect_core(SKILL, mode)), mode)


if __name__ == "__main__":
    unittest.main()

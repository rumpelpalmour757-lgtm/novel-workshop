// ACP v1 客户端的协议层：stdio 上按行分隔的 JSON-RPC 2.0（UTF-8，一行一条消息，消息里不能有换行；
// 不是 LSP 的 Content-Length 分帧）。照 agentclientprotocol.com 的 v1 页面手写，只实现工坊用到的那一小部分。
// 没有用官方的 @agentclientprotocol/sdk：写作台没有任何 npm 依赖，作者在自己的 Windows 电脑上双击就能打开，
// 不需要安装步骤；加一个依赖就得多一步 npm install，还要锁版本、随包分发。
//
// 这里只管“消息怎么收发”：分帧、请求和响应按 id 配对、超时、连接代次（generation）。
// - stdout 只当协议流：不是 JSON-RPC 的行、超长的行都算协议错误，记数，永远进不了候选稿；
// - 一个中文字或表情被拆在两次读取之间也能拼回来（StringDecoder），一次读到几条、最后半行留到下一次都照常处理；
// - stderr 单独收，去掉主目录路径和像密钥的字样，只给作者看诊断；
// - 连接关掉以后再来的消息一律丢弃；每个请求记着发出它的连接代次，旧进程的迟到消息落不到新连接上；
// - 对方发来的请求交给上层回答；上层不认识的一律回 Method not found（工坊没声明文件和终端能力，就不提供）。

import { StringDecoder } from "node:string_decoder";

export const PROTOCOL_VERSION = 1;
export const RPC = Object.freeze({
  PARSE_ERROR: -32700,
  INVALID_REQUEST: -32600,
  METHOD_NOT_FOUND: -32601,
  INVALID_PARAMS: -32602,
  INTERNAL_ERROR: -32603,
  AUTH_REQUIRED: -32000,
});
// 只声明真正实现了的：工坊不替官方程序读写文件，也不给它开终端。
export const CLIENT_CAPABILITIES = Object.freeze({
  fs: Object.freeze({ readTextFile: false, writeTextFile: false }),
  terminal: false,
});
export const DEFAULT_MAX_LINE_CHARS = 4 * 1024 * 1024;
const STDERR_KEEP_LINES = 80;
const STDERR_LINE_CHARS = 400;
const STDERR_PENDING_CHARS = 8192;
const PROTOCOL_SAMPLES = 5;
const ANSI = /\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b\][^\x07]*\x07/g;

export class AcpRpcError extends Error {
  constructor(method, error) {
    const text = typeof error?.message === "string" ? error.message : "";
    super(`${method} 返回错误 ${error?.code ?? "?"}：${text.slice(0, 300)}`);
    this.name = "AcpRpcError";
    this.method = method;
    this.code = Number.isInteger(error?.code) ? error.code : null;
    this.rpcMessage = text.slice(0, 500);
    this.data = error?.data;
  }
}

export class AcpTimeoutError extends Error {
  constructor(method, timeoutMs) {
    super(`${method} 等了 ${Math.max(1, Math.round(timeoutMs / 1000))} 秒没有回应`);
    this.name = "AcpTimeoutError";
    this.method = method;
    this.timeoutMs = timeoutMs;
  }
}

export class AcpClosedError extends Error {
  constructor(method, reason) {
    super(`${method}：连接已经关闭（${reason || "原因不明"}）`);
    this.name = "AcpClosedError";
    this.method = method;
    this.reason = reason || null;
  }
}

// 上层回答对方请求时抛这个，连接就回一个 JSON-RPC 错误。
export class RpcReply extends Error {
  constructor(code, message) {
    super(message);
    this.name = "RpcReply";
    this.rpcCode = code;
    this.rpcMessage = message;
  }
}

export function methodNotFound(method) {
  return new RpcReply(RPC.METHOD_NOT_FOUND, `Method not found: ${String(method).slice(0, 80)}`);
}

// 一条消息编成一行。JSON.stringify 不会产生裸换行；U+2028/2029 也转义，免得别的读法把它当换行。
export function encodeMessage(message) {
  const text = JSON.stringify(message).replace(/[\u2028\u2029]/g, (c) => (c === "\u2028" ? "\\u2028" : "\\u2029"));
  if (text.includes("\n") || text.includes("\r")) throw new Error("ACP 消息里不能有换行");
  return `${text}\n`;
}

export class NdjsonDecoder {
  constructor({ maxLineChars = DEFAULT_MAX_LINE_CHARS, onMessage = () => {}, onProtocolError = () => {} } = {}) {
    this.maxLineChars = maxLineChars;
    this.onMessage = onMessage;
    this.onProtocolError = onProtocolError;
    this.decoder = new StringDecoder("utf8");
    this.buffer = "";
    this.discarding = false;
    this.ended = false;
  }

  push(chunk) {
    if (this.ended) return;
    this.consume(typeof chunk === "string" ? chunk : this.decoder.write(chunk));
  }

  consume(text) {
    let start = 0;
    let index;
    while ((index = text.indexOf("\n", start)) !== -1) {
      const piece = text.slice(start, index);
      start = index + 1;
      if (this.discarding) {
        // 超长的那一行到这里才结束：整行丢掉，从下一行重新开始。
        this.discarding = false;
        this.buffer = "";
        continue;
      }
      const line = this.buffer + piece;
      this.buffer = "";
      if (line.length > this.maxLineChars) {
        this.onProtocolError({ kind: "line_too_long", chars: line.length, maybeChunk: true });
        continue;
      }
      this.handleLine(line);
    }
    if (this.discarding) return;
    this.buffer += text.slice(start);
    if (this.buffer.length > this.maxLineChars) {
      // 超长的行整行丢掉；它可能是一段回复，所以记成“可能丢了回复”。
      this.onProtocolError({ kind: "line_too_long", chars: this.buffer.length, maybeChunk: true });
      this.buffer = "";
      this.discarding = true;
    }
  }

  handleLine(raw) {
    const line = raw.endsWith("\r") ? raw.slice(0, -1) : raw;
    if (!line.trim()) return;
    let message;
    try {
      message = JSON.parse(line);
    } catch {
      // 坏掉的一行如果像是一段回复（agent_message_chunk），这一轮的正文可能缺了一块。
      this.onProtocolError({ kind: "not_json", chars: line.length, excerpt: line.slice(0, 120), maybeChunk: line.includes("agent_message_chunk") });
      return;
    }
    if (!message || typeof message !== "object" || Array.isArray(message) || message.jsonrpc !== "2.0") {
      this.onProtocolError({ kind: "not_jsonrpc", chars: line.length, excerpt: line.slice(0, 120) });
      return;
    }
    this.onMessage(message);
  }

  // 流结束：解码器里剩下的半个字、没有换行收尾的半行都不算消息。
  end() {
    if (this.ended) return;
    const tail = this.decoder.end();
    if (tail) this.consume(tail);
    this.ended = true;
    if (this.buffer.trim() && !this.discarding) {
      this.onProtocolError({ kind: "truncated_line", chars: this.buffer.length, maybeChunk: this.buffer.includes("agent_message_chunk") });
    }
    this.buffer = "";
  }
}

function hasUsableId(message) {
  return Object.hasOwn(message, "id") && (typeof message.id === "number" || typeof message.id === "string");
}

export class AcpConnection {
  constructor({
    generation,
    stdin,
    stdout,
    stderr = null,
    scrub = (text) => text,
    maxLineChars = DEFAULT_MAX_LINE_CHARS,
    onNotification = null,
    onRequest = null,
    onClose = null,
    onProtocolError = null,
  }) {
    this.generation = generation;
    this.stdin = stdin;
    this.scrub = scrub;
    this.onNotification = onNotification;
    this.onRequest = onRequest;
    this.onClose = onClose;
    this.onProtocolError = onProtocolError;
    this.nextId = 0;
    this.pending = new Map();
    this.closed = false;
    this.closeReason = null;
    this.queue = [];
    this.writable = true;
    this.stderrLines = [];
    this.stats = {
      received: 0,
      sent: 0,
      protocolErrors: 0,
      protocolSamples: [],
      strayResponses: 0,
      droppedAfterClose: 0,
      stderrBytes: 0,
    };
    this.decoder = new NdjsonDecoder({
      maxLineChars,
      onMessage: (message) => this.dispatch(message),
      onProtocolError: (problem) => this.protocolError(problem),
    });
    stdout.on("data", (chunk) => {
      if (this.closed) {
        this.stats.droppedAfterClose += 1;
        return;
      }
      this.decoder.push(chunk);
    });
    stdout.on("end", () => {
      if (this.closed) return;
      this.decoder.end();
      this.close("官方程序的输出流结束了");
    });
    stdout.on("error", (error) => this.close(`读不到官方程序的输出：${error?.code || error?.message || "出错"}`));
    stdin.on("error", (error) => this.close(`写不进官方程序：${error?.code || error?.message || "出错"}`));
    stdin.on("drain", () => this.flush());
    if (stderr) {
      const decoder = new StringDecoder("utf8");
      let pending = "";
      stderr.on("data", (chunk) => {
        this.stats.stderrBytes += chunk.length;
        pending += decoder.write(chunk);
        let index;
        while ((index = pending.indexOf("\n")) !== -1) {
          this.pushStderr(pending.slice(0, index));
          pending = pending.slice(index + 1);
        }
        if (pending.length > STDERR_PENDING_CHARS) {
          this.pushStderr(pending);
          pending = "";
        }
      });
      stderr.on("end", () => {
        pending += decoder.end();
        if (pending) this.pushStderr(pending);
        pending = "";
      });
      stderr.on("error", () => {});
    }
  }

  pushStderr(line) {
    const clean = this.scrub(String(line).replace(ANSI, "").replace(/\r$/, "")).slice(0, STDERR_LINE_CHARS);
    if (!clean.trim()) return;
    this.stderrLines.push(clean);
    if (this.stderrLines.length > STDERR_KEEP_LINES) this.stderrLines.shift();
  }

  stderrTail(count = 20) {
    return this.stderrLines.slice(-count);
  }

  protocolError(problem) {
    this.stats.protocolErrors += 1;
    this.onProtocolError?.(problem, this);
    if (this.stats.protocolSamples.length < PROTOCOL_SAMPLES) {
      this.stats.protocolSamples.push({
        kind: problem.kind,
        chars: problem.chars ?? null,
        excerpt: problem.excerpt ? this.scrub(String(problem.excerpt).replace(ANSI, "")).slice(0, 120) : null,
      });
    }
  }

  send(message) {
    if (this.closed) throw new AcpClosedError(message.method || "response", this.closeReason);
    const line = encodeMessage(message);
    this.stats.sent += 1;
    // 背压：管道写满了就排队，等 drain 再接着写，顺序不变。
    if (!this.writable || this.queue.length) {
      this.queue.push(line);
      return;
    }
    this.writable = this.stdin.write(line);
  }

  flush() {
    this.writable = true;
    while (this.queue.length && this.writable && !this.closed) {
      this.writable = this.stdin.write(this.queue.shift());
    }
  }

  request(method, params, { timeoutMs = 30_000 } = {}) {
    if (this.closed) return Promise.reject(new AcpClosedError(method, this.closeReason));
    const id = this.nextId;
    this.nextId += 1;
    return new Promise((resolve, reject) => {
      const timer = timeoutMs > 0
        ? setTimeout(() => {
          // 超时以后这个 id 作废：之后再到的回应只记一笔“迟到”，不交给任何人。
          this.pending.delete(id);
          reject(new AcpTimeoutError(method, timeoutMs));
        }, timeoutMs)
        : null;
      this.pending.set(id, { method, resolve, reject, timer, generation: this.generation });
      try {
        this.send({ jsonrpc: "2.0", id, method, params });
      } catch (error) {
        if (timer) clearTimeout(timer);
        this.pending.delete(id);
        reject(error);
      }
    });
  }

  notify(method, params) {
    this.send({ jsonrpc: "2.0", method, params });
  }

  dispatch(message) {
    if (this.closed) {
      this.stats.droppedAfterClose += 1;
      return;
    }
    this.stats.received += 1;
    if (typeof message.method === "string") {
      if (hasUsableId(message)) this.answer(message);
      else if (!Object.hasOwn(message, "id")) this.onNotification?.(message.method, message.params ?? {}, this);
      else this.protocolError({ kind: "bad_request_id" });
      return;
    }
    if (hasUsableId(message) && (Object.hasOwn(message, "result") || Object.hasOwn(message, "error"))) {
      const entry = this.pending.get(message.id);
      if (!entry) {
        this.stats.strayResponses += 1;
        return;
      }
      this.pending.delete(message.id);
      if (entry.timer) clearTimeout(entry.timer);
      if (message.error) entry.reject(new AcpRpcError(entry.method, message.error));
      else entry.resolve(message.result ?? null);
      return;
    }
    if (message.error) {
      // 对方说它读不懂我们发的某条消息（id 为 null）：记成协议错误，不当成哪个请求的结果。
      this.protocolError({ kind: "agent_error_without_id", excerpt: typeof message.error.message === "string" ? message.error.message : null });
      return;
    }
    this.protocolError({ kind: "unknown_message" });
  }

  async answer(message) {
    let result;
    try {
      if (!this.onRequest) throw methodNotFound(message.method);
      result = await this.onRequest(message.method, message.params ?? {}, this);
      if (result === undefined) throw methodNotFound(message.method);
    } catch (error) {
      if (this.closed) return;
      const code = Number.isInteger(error?.rpcCode) ? error.rpcCode : RPC.INTERNAL_ERROR;
      const text = typeof error?.rpcMessage === "string" ? error.rpcMessage : "Internal error";
      this.trySend({ jsonrpc: "2.0", id: message.id, error: { code, message: text } });
      return;
    }
    if (this.closed) return;
    this.trySend({ jsonrpc: "2.0", id: message.id, result });
  }

  trySend(message) {
    try {
      this.send(message);
    } catch {
      // 连接已经断了：回应发不出去也没有人等它。
    }
  }

  pendingMethods() {
    return [...this.pending.values()].map((entry) => entry.method);
  }

  close(reason) {
    if (this.closed) return;
    this.closed = true;
    this.closeReason = reason || null;
    this.queue = [];
    for (const entry of this.pending.values()) {
      if (entry.timer) clearTimeout(entry.timer);
      entry.reject(new AcpClosedError(entry.method, this.closeReason));
    }
    this.pending.clear();
    try {
      this.stdin.end();
    } catch {}
    this.onClose?.(this.closeReason, this);
  }
}

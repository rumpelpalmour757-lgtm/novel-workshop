"""r5.52: the author's punctuation rules of 11-07 (their punctuation_lint v2.0-v3.3.1 and its config; v2.5 was never received,
v2.1 and v2.7 do not compile) taken into the workshop checker, which stays read-only.

The author's tool is not merged as code: on the same inputs it rewrote correct text (v2.3, v2.4 and v2.6 turn “——”
into “————”, v2.4 and v2.6 change English sentences, paths and panels, all versions collapse stacked ！ that the standard allows and
overwrite the input file unless -o is given). What it detects that the workshop checker missed is added here, each
form with the severity the workshop uses: objective format faults ERROR, everything a writer may mean REVIEW.
No format rule here judges by how long a sentence or a quotation is (P09 decides by where a quotation stands; a tag
longer than 40 characters is not taken for a tag at all; P10-P13 are reading-load hints with the work's own lines).
"""
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "skills" / "novel-workshop" / "scripts" / "punctuation_lint.py"


def load():
    import importlib.util
    spec = importlib.util.spec_from_file_location("punctuation_lint_r552", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    sys.modules["punctuation_lint_r552"] = module
    spec.loader.exec_module(module)
    return module


LINT = load()


def found(text, rules=None):
    return [(f["rule"], f["severity"], f["match"]) for f in LINT.lint_text(text, rules)["findings"]]


class AuthorsExamples(unittest.TestCase):
    """The examples in the author's own self-tests, as the workshop checker now reports them."""

    def check(self, text, expected, rules=None):
        self.assertEqual(found(text, rules), expected, text)

    def test_half_width_marks_between_chinese_and_kept_numbers(self):
        self.check("他一刀劈下.鲜血飞溅,连r5.50与3.14都没变.",
                   [("P06", "ERROR", "."), ("P06", "ERROR", ","), ("P06", "ERROR", ".")])

    def test_a_straight_closing_quote(self):
        self.check("“老冯，快走\"", [("P01", "ERROR", "“"), ("P06", "ERROR", "\"")])

    def test_dots_ellipsis_mixtures_and_a_mixed_dash(self):
        self.check("“这..”他顿了顿…...又道—-“算了。。。。”",
                   [("P05", "ERROR", ".."), ("P05", "ERROR", "…..."), ("P05", "ERROR", "—-"), ("P05", "ERROR", "。。。。")])

    def test_brackets_of_mixed_width(self):
        self.check("他擦了擦血（左臂还在发麻)，低声道：(先撤退）.",
                   [("P06", "ERROR", ")"), ("P06", "ERROR", "("), ("P06", "REVIEW", ".")])  # after （）: RC-53

    def test_runs_of_full_stops_and_commas(self):
        self.check("完了。，。彻底完了，。，真的！！", [("P04", "ERROR", "。，。"), ("P04", "ERROR", "，。，")])

    def test_a_tag_line_with_a_full_stop_and_spaces_between_tags(self):
        self.check("【定】。", [("P14", "REVIEW", "【定】。")])
        self.check("【风铃护符：验证完成】 【积分奖励已到账】", [("P14", "REVIEW", "】 【积分奖励已到账】")])

    def test_ascii_marks_after_english_words_in_a_chinese_sentence(self):
        self.check("这居然是SSR! 战力突破9999? 他升到了Lv10.然后买了RTX 5090, 性能拉满!",
                   [("P06", "REVIEW", "!"), ("P06", "REVIEW", "?"), ("P06", "REVIEW", "."), ("P06", "REVIEW", ","),
                    ("P06", "ERROR", "!")])

    def test_examples_of_the_authors_v2_6(self):
        self.check("“他的代号是K.”“他是VIP..”", [("P06", "REVIEW", "."), ("P05", "ERROR", "..")])
        self.check("他升到了（Lv.10)，获得了[系统奖励】，学会了《基础刀法>，抽到了(\"SSR!\")。",
                   [("P06", "ERROR", ")"), ("P02", "ERROR", "】"), ("P02", "ERROR", "《"),
                    ("P06", "REVIEW", "("), ("P06", "REVIEW", ")")])
        self.check("他收起刀、，转身喊道：“快走，！”这居然是真的？！？太离谱了、。",
                   [("P04", "ERROR", "、，"), ("P04", "ERROR", "，！"), ("P04", "REVIEW", "？！？"), ("P04", "ERROR", "、。")])
        self.check("他愣了一下.`ls -la`命令已经执行.", [("P06", "ERROR", "."), ("P06", "ERROR", ".")])
        for text in ("第3章\u3000所谓的“旧仓库管理员”", "“风铃护符”是老冯花了大价钱淘来的旧货。",
                     "他看向坐标(12, 34)，调用max(a, b)计算公式f(x)是线性的，提升属性(HP)。"):
            self.check(text, [])

    def test_examples_of_the_authors_v2_8_1(self):
        # code spans with several backticks; nested raw panels; command-line options; a person acting right after a quotation
        self.check("中文``a`b, \"中文\"``。", [])
        self.check("【系统: 【内层: 告警!】 保留?】: 结束!", [("P06", "REVIEW", ":"), ("P06", "ERROR", "!")], {"profile": "raw-panel"})
        self.check("中文--force与---long选项。", [])
        for text in ("“快走”老冯一把拽住他。", "“快走”他拽住老冯。", "“快走”那人推开门。", "“快走”向导推开门。"):
            self.check(text, [("P09", "REVIEW", "走”")])
        self.check("“快走”孙越一把拽住他。", [("P09", "REVIEW", "走”")], {"characters": ["孙越"]})
        for text in ("“风铃护符”是老冯淘来的旧货。", "“生死自负”四个大字挂在墙头。", "“风铃护符”骤然亮起。",
                     "“安全区”这个词印在地图上。", "“破风”技能已经解锁。", "“风铃护符”的光芒忽然增强。", "他喊了一声“快走”老冯转身。"):
            self.check(text, [])

    def test_examples_of_the_authors_v2_9_1(self):
        # a call written in the prose, a Markdown image with a title, a mark doubled across a space, (SSR!)
        for text in ("中文调用f(\"中文!\")。", "中文调用f(\")\")。", "中文调用f(x!=0)和a['x']。", "如图![插图](图1.png)所示。",
                     "苏晴在单元格里敲下=IF(B2>=60,\"及格\",\"不及格\")，回车，整列成绩都标好了。"):
            self.check(text, [])
        self.check("请看![中 文](https://example.com/a_(b) \"标题 (x)\")。", [("P08", "REVIEW", " ")])
        self.check("他退后一步。 。", [("P04", "ERROR", "。 。")])
        self.check("他抽到了(SSR!)。", [("P06", "REVIEW", "(SSR!)")])
        self.check("她说(\"走吧。\")。", [("P06", "REVIEW", "("), ("P06", "ERROR", "\""), ("P06", "ERROR", "\""), ("P06", "REVIEW", ")")])

    def test_examples_of_the_authors_v3_0_1(self):
        # a bare domain ends where a comma or a bracket follows; a path keeps its own , ; ! ( ) '
        self.check("请打开https://example.com,VIP用户免费。", [("P06", "REVIEW", ",")])
        self.check("请打开https://example.com(备用站)。", [("P06", "REVIEW", "("), ("P06", "REVIEW", ")")])
        self.check("访问https://example.com/a,b;name!part_(x)?q=O'Brien，继续。", [])
        self.check("他列了三样：“雾镇”与“白线”。", [])

    def test_examples_of_the_authors_v3_2_1_and_v3_3_1(self):
        # one missing closer is one fault: the correct ” after it is not reported (r5.51 did not report it either)
        self.check("“他打开了【系统面板。”", [("P02", "ERROR", "【")])
        self.check("“你好（朋友。”", [("P02", "ERROR", "（")])
        self.check("他翻开《〈黑石法典残卷》。", [("P02", "ERROR", "〈")])
        self.check("（甲【乙）丙", [("P02", "ERROR", "【")])
        # a real crossing is still reported where it crosses
        self.check("他说：“走（快”）。", [("P02", "ERROR", "”")])
        self.check("（甲【乙）丙】", [("P02", "ERROR", "（"), ("P02", "ERROR", "）")])
        # a title mark inside the same title mark (GB/T 15834-2011 4.15; the author's handbook: 《〈春〉教案》)
        self.check("他翻开《外层《内层》外层》。", [("P02", "ERROR", "《")])
        self.check("他翻开〈外〈内〉层〉。", [("P02", "ERROR", "〈")])
        self.check("他翻开《〈黑石法典〉残卷》。", [])
        self.check("《《《重要通知》》》", [])
        # a space between a Chinese mark and English or a digit, inside a pair or beside a sentence mark
        self.check("这居然是SSR ！", [("P08", "REVIEW", " ")])
        self.check("倒计时—— 3、2、1。", [("P08", "REVIEW", " ")])
        self.check("他等着…… Lv10到了。", [("P08", "REVIEW", " ")])
        self.check("他升到了（ Lv.10 ）。", [("P08", "REVIEW", " "), ("P08", "REVIEW", " ")])
        self.check("第2章  SSR ！", [])
        # a spoken line running into narration that goes on
        self.check("他低声问，“去哪”随后看向我。", [("P09", "REVIEW", "哪”")])
        self.check("老冯拍了拍他，“跟我走吧”随后转身钻进雨幕。", [("P09", "REVIEW", "吧”")])
        self.check("“我先走”随后转身离开。", [("P09", "REVIEW", "走”")])
        # initials
        self.check("J.K.罗琳是作者。", [])
        self.check("作者署名J.K.", [])
        self.check("他看向蒙奇·D.路飞。", [])
        self.check("“他的代号是K.他已经走了。”", [("P06", "REVIEW", ".")])

    def test_a_quote_opened_twice(self):
        self.check("“你过来，“老冯招了招手，”我有话跟你说。”", [("P01", "ERROR", "“"), ("P01", "ERROR", "”")])

    def test_a_standalone_quote_with_no_end_mark_inside_a_nested_quote(self):
        self.check("“他刚才喊了一声‘快跑’”", [("P09", "REVIEW", "’”")])

    def test_what_the_author_marks_as_correct_is_not_flagged(self):
        for text in ("他心里抱着“死马当活马医，能撑一时是一时”的念头。", "第2章\u3000那一夜，雨未停",
                     "1. 耗时18:30，宽高比16:9，赏金1,000,000元，基于.NET重构。",
                     "先调用函数init()，再计算公式f(x)是线性的，最后提升属性(HP)。"):
            self.check(text, [])


class NewForms(unittest.TestCase):
    def test_ellipsis_lengths(self):
        self.assertEqual(found("他想了很久………终于开口。"), [("P05", "REVIEW", "………")])
        self.assertEqual(found("“那天晚上…………”她没有说下去。"), [("P05", "REVIEW", "…………")])
        # A line of twelve dots leaves out whole paragraphs: allowed.
        self.assertEqual(found("那一夜的事，他只写了开头。\n…………\n天亮的时候，雨停了。"), [])
        self.assertEqual(found("“你还回来吗？”\n...\n“会的。”"), [("P05", "ERROR", "...")])

    def test_dash_forms(self):
        self.assertEqual(found("他说—算了。"), [("P05", "REVIEW", "—")])
        self.assertEqual(found("“等我说完———”门被推开了。"), [("P05", "REVIEW", "———")])
        self.assertEqual(found("他说──算了。"), [("P05", "REVIEW", "──")])
        self.assertEqual(found("他说――算了。"), [("P05", "REVIEW", "――")])

    def test_space_around_a_half_width_mark_between_chinese(self):
        self.assertEqual(found("他说 , 走吧。"), [("P06", "ERROR", ",")])

    def test_spaces_next_to_chinese_punctuation(self):
        self.assertEqual(found("他走了 。"), [("P08", "REVIEW", " ")])
        self.assertEqual(found("他走了，  她来了。"), [("P08", "REVIEW", "  ")])

    def test_two_end_marks(self):
        self.assertEqual(found("他喊了一声！。"), [("P04", "ERROR", "！。")])

    def test_speech_tag_after_a_space_or_a_comma(self):
        self.assertEqual(found("“走吧” 他说。"), [("P09", "REVIEW", "吧”"), ("P08", "REVIEW", " ")])
        self.assertEqual(found("“走吧”，他说。"), [("P09", "REVIEW", "吧”")])

    def test_a_quote_left_open_into_a_paragraph_that_reopens_it_is_review(self):
        # Either one speech across paragraphs (correct) or a missing closing quote before another speaker: the
        # editor decides. P01 stays silent, as before.
        report = LINT.lint_text("“老冯，快退！\n“我不退！”孙越说。")
        self.assertEqual([(f["rule"], f["severity"], f["line"]) for f in report["findings"]], [("P15", "REVIEW", 1)])
        self.assertEqual(found("“老冯，快退！\n“我不退！”孙越说。", {"continued_quotes": "allow"}), [])

    def test_stacked_marks_follow_the_standard_unless_the_work_says_otherwise(self):
        self.assertEqual(found("“快走！！”"), [])
        self.assertEqual(found("“你真的要走？！”"), [])
        self.assertEqual(found("“快走！！！”"), [("P04", "REVIEW", "！！！")])
        self.assertEqual(found("“快走！！”", {"stacked_mark_limit": 1}), [("P04", "REVIEW", "！！")])
        self.assertEqual(found("“你真的要走？！”", {"stacked_mark_limit": 1}), [])


class LeftAlone(unittest.TestCase):
    """What the author's v2.x scripts changed or flagged although it is correct."""

    def test_correct_dashes_and_ranges(self):
        for text in ("他说——算了。", "“我——”他张了张嘴。", "他说——算了——还是走吧。", "第1—4章，2011—2012年。",
                     "“等我说完——”门被推开了。", "──── 第二天 ────", "【────状态────】"):
            self.assertEqual(found(text), [], text)

    def test_english_inside_chinese_text(self):
        for text in ("他回了一句：“Fine, thanks.”", "门上刻着一行字：Abandon all hope, ye who enter here.",
                     "她念出那行字——Memento mori.", "他对Mr. Smith点了点头。", "稿子存在D:\\雾镇\\第一卷.docx里。",
                     "他说 He said wait... ok"):
            self.assertEqual([f for f in found(text) if f[1] == "ERROR"], [], text)
        self.assertEqual(found("他回了一句：“Fine, thanks.”"), [])
        self.assertEqual(found("她念出那行字——Memento mori."), [])
        self.assertEqual(found("他对Mr. Smith点了点头。"), [])

    def test_the_profile_can_be_given_on_the_command_line(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "c.md"
            path.write_bytes("“快走！！”\n".encode("utf-8"))
            out = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT), str(path), "--profile", "strict"],
                                 capture_output=True, text=True, encoding="utf-8").stdout
            self.assertEqual([f["rule"] for f in json.loads(out)["findings"]], ["P04"])

    def test_code_urls_and_links_are_not_checked_and_are_listed(self):
        report = LINT.lint_text("他敲下`print(\"你好\")`，又打开https://zh.wikipedia.org/wiki/Main_Page看了看。\n[见第一章](第一章.md)")
        self.assertEqual(report["findings"], [])
        self.assertEqual([s["kind"] for s in report["skipped_spans"]], ["code", "url", "link"])  # reading order
        block = LINT.lint_text("```python\nprint(\"你好\")...\n```\n他走了。")
        self.assertEqual(block["findings"], [])
        self.assertEqual(block["skipped_spans"][0]["kind"], "code_block")

    def test_title_spaces(self):
        for text in ("第一章\u3000雾港", "卷一\u3000雾镇", "楔子\u3000雨夜", "第一章 雾港"):
            self.assertEqual(found(text), [], text)


class ReviewBoundaries(unittest.TestCase):
    """Boundaries the r5.52 review found: what is skipped must not hide the text around it, an exemption must stay
    narrow, and the same fault gives the same finding however it is spaced or saved."""

    def check(self, text, expected, rules=None):
        self.assertEqual([f for f in found(text, rules) if f[0] not in ("P10", "P11", "P12", "P13")], expected, text)

    def test_a_line_of_tildes_is_a_scene_break_and_an_unclosed_fence_protects_nothing(self):
        self.check("他走了。\n~~~~~~\n她说,好。。\n", [("P06", "ERROR", ","), ("P04", "ERROR", "。。")])
        self.check("他走了。\n```\n她说,好。\n", [("P06", "ERROR", ",")])
        report = LINT.lint_text("他走了。\n```python\nprint(\"你好\")\n```\n她说,好。")
        self.assertEqual([(f["rule"], f["match"]) for f in report["findings"]], [("P06", ",")])
        self.assertEqual([s["kind"] for s in report["skipped_spans"]], ["code_block"])
        self.assertEqual(report["stats"]["skipped_spans"], 1)

    def test_only_the_address_of_a_url_is_skipped(self):
        self.check("他打开https://example.com看了半天,又关掉了.然后走了。", [("P06", "ERROR", ","), ("P06", "ERROR", ".")])
        self.check("他打开https://a.cn...没反应。", [("P05", "ERROR", "...")])
        self.check("（见https://a.cn)他说,好。", [("P06", "ERROR", ")"), ("P06", "ERROR", ",")])
        self.check("地址是https://a.cn/x?id=1。", [])

    def test_only_known_names_begin_with_a_dot(self):
        for text in ("他打开了电脑.Windows启动了。", "任务完成了.Boss很满意。", "他点了点头.OK，那就这么定了。"):
            self.check(text, [("P06", "ERROR", ".")])
        self.check("基于.NET重构，存成.txt文件。", [])

    def test_crlf_gives_the_same_findings_as_lf(self):
        for text in ("上文。\n…………\n下文。", "上文。\n...\n下文。", "“走吧”\n“好。”", "【定】。\n他走了。",
                     "他升到了Lv10.\n第二行。", "“老冯，快退！\n“我不退！”孙越说。"):
            self.assertEqual(LINT.lint_text(text.replace("\n", "\r\n")), LINT.lint_text(text), text)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "crlf.md"
            path.write_bytes("上文。\r\n...\r\n下文。\r\n".encode("utf-8"))
            run = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT), str(path)], capture_output=True)
            self.assertEqual(run.returncode, 1)
            self.assertEqual(json.loads(run.stdout.decode("utf-8"))["findings"][0]["match"], "...")

    def test_spaces_around_an_ellipsis_or_a_dash(self):
        self.check("他说 ... 走了。", [("P05", "ERROR", "...")])
        self.check("他说 .. 走了。", [("P05", "ERROR", "..")])
        self.check("他说 ―― 走了。", [("P05", "REVIEW", "――")])
        self.check("他说 …... 走了。", [("P08", "REVIEW", " "), ("P05", "ERROR", "…...")])
        self.check("加载 ../config/init.sh 配置。", [])

    def test_a_standalone_quote_ending_in_a_bracket_or_a_title_mark(self):
        self.check("“我昨天看了《雾港》”", [("P09", "REVIEW", "》”")])
        self.check("“他走了（真的）”", [("P09", "REVIEW", "）”")])

    def test_one_mixed_bracket_pair_is_one_finding(self):
        self.check("他擦了擦血（左臂还在发麻)，继续走。", [("P06", "ERROR", ")")])

    def test_spaced_quotes_and_the_same_severity_on_either_side(self):
        self.check("他说 \" 走吧 \" 。", [("P06", "ERROR", "\""), ("P06", "ERROR", "\"")])
        self.check("他说 ,走吧。", [("P06", "ERROR", ",")])
        self.check("他说 , 走吧。", [("P06", "ERROR", ",")])

    def test_one_english_word_before_a_speech_tag_is_chinese_dialogue(self):
        self.check("“OK,”他说，“我们走。”", [("P06", "REVIEW", ",")])
        self.check("她只回了一句“Fine, thanks.”就挂了。", [])

    def test_quoted_terms_followed_by_words_that_begin_with_a_speech_verb(self):
        for text in ("“船票”，说白了就是一张纸。", "“为什么”，答案很简单。", "“船票”，问题就出在这儿。", "“雾镇”，叫起来顺口。"):
            self.check(text, [])
        self.check("“快走”，他说。", [("P09", "REVIEW", "走”")])

    def test_prose_that_begins_like_a_heading_is_prose(self):
        self.check("第二节课上，他\u3000睡着了。", [("P08", "REVIEW", "\u3000")])
        self.check("尾声：众人散去， 灯也灭了。", [("P08", "REVIEW", " ")])
        self.check("第2章\u3000那一夜，雨未停", [])

    def test_long_bars_between_two_characters(self):
        self.check("他―――走了。", [("P05", "REVIEW", "―――")])
        self.check("他说───走了。", [("P05", "REVIEW", "───")])
        self.check("【────状态────】", [])

    def test_one_error_for_one_run_of_marks(self):
        self.check("走！。。", [("P04", "ERROR", "！。。")])


class ReviewFalsePositives(unittest.TestCase):
    """Correct text the r5.52 review wrote in many genres: the new rules must not report it, above all not as ERROR."""

    def check(self, text, expected=()):
        self.assertEqual([f for f in found(text) if f[0] not in ("P10", "P11", "P12", "P13")], list(expected), text)

    def test_chat_lines_and_emoticons(self):
        self.check("阿白：在吗？\n小雪：？")
        self.check("小雪：！")
        self.check("？？？：你终于来了。", [("P04", "REVIEW", "？？？")])  # stacked marks, as in r5.51
        self.check("阿白：好吧 :(\n老贺：稿子不错 :)")
        self.check("他回了个 ;) 就下线了。")

    def test_paths_minus_signs_and_terminal_output(self):
        self.check("她把校验文件拷到../verify目录里，又敲下cd ..，回到了根目录。")
        self.check("配置文件在../conf/雾镇.toml里。")
        self.check("准确地说，是绝对零度——-273.15℃。")
        self.check("那颗卫星表面的温度很低——－180℃左右。")
        self.check("屏幕上跳出一行提示：\nMounting /dev/sdb1 ...\n...\nMount OK.")
        self.check("“你还回来吗？”\n...\n“会的。”", [("P05", "ERROR", "...")])

    def test_english_quotations_keep_english_dots(self):
        self.check("他回了一句：“Fine, thanks...”")  # an English sentence (it has a space) keeps English dots
        for text in ("“Wait...”她用英语喊了一声，可那人已经走远了。", "“emmm...”他挠了挠头。"):
            self.check(text, [("P05", "ERROR", "...")])  # one word: as in r5.51 (“emmm...” is Chinese slang)
        self.check("“我...我不知道。”", [("P05", "ERROR", "...")])

    def test_kaomoji_and_drawn_trees(self):
        self.check("小雪：我也这么觉得(╯°□°）╯︵ ┻━┻")  # a kaomoji: nothing (r5.51 gave a P02 ERROR)
        self.check("背包（7/20）\n├─武器：精钢长刀\n└─任务物品：矿洞钥匙×1")

    def test_ranges(self):
        for text in ("②哥舒翰（？—757），突骑施人。", "抗日战争（1937年—1945年）期间。", "营业时间：周一—周五，上午9点—11点。"):
            self.check(text)

    def test_quoted_topics_fields_titles_lists_and_inscriptions(self):
        for text in ("“狼来了”，大家都知道这个故事。", "“好”，道理他都懂。", "“明天见”，说起来容易，做起来难。",
                     "称号：“新手村的希望”", "口令：“天王盖地虎”", "第十七章：“别回头”", "## 番外：“如果那天没有下雨”",
                     "他在本子上列了三个词：\n“雾镇”\n“白线”\n“红门”", "剑身上刻着四个字：\n“天下第一”"):
            self.check(text)
        self.check("老冯吼道：“快走”", [("P09", "REVIEW", "走”")])
        self.check("“快走”\n他转身就跑。", [("P09", "REVIEW", "走”")])

    def test_abbreviations_options_and_mail_subjects(self):
        for text in ("P.S. 你上次说想吃家里的腊肉。", "A. 鲁迅\nB. 老舍", "这位是Dr. 陈。", "中国队 vs. 日本队",
                     "（e.g. 内卷、躺平）", "早上7 a.m. 起飞。", "标题是“Re: 冷启动方案讨论”", "[System: Level up! 等级+1]"):
            self.check(text)
        self.check("这居然是SSR! 战力突破了。", [("P06", "REVIEW", "!")])

    def test_tag_lines_with_a_colon_or_an_ellipsis(self):
        self.check("【属性面板】：\n力量：15")
        self.check("【正在连接服务器】……")
        self.check("【定】。", [("P14", "REVIEW", "【定】。")])

    def test_more_titles(self):
        for text in ("番外一 寄往远方的信", "第4话 群聊里的勇者大人", "番外篇 雨夜", "第一幕 雨夜", "间章 白线", "《静夜思》 李白"):
            self.check(text)

    def test_a_quoted_cry_inside_a_question_and_a_repeated_mark(self):
        self.check("难道你没听见他喊“救命！”？")
        self.check("“谁？”？他又问了一遍。", [("P04", "REVIEW", "？”？")])


class ReviewFidelity(unittest.TestCase):
    """The author's rules as the r5.52 review read them: what is an objective fault is ERROR, as the author has it."""

    def check(self, text, expected=(), rules=None):
        self.assertEqual([f for f in found(text, rules) if f[0] not in ("P10", "P11", "P12", "P13")], list(expected), text)

    def test_straight_quotes_around_chinese_dialogue_are_errors(self):
        self.check("\"走吧。\"她说。", [("P06", "ERROR", "\""), ("P06", "ERROR", "\"")])
        self.check("他说：\"天快亮了。\"", [("P06", "ERROR", "\""), ("P06", "ERROR", "\"")])
        self.check("他回了一句：“Fine, thanks.”")
        self.check("他把显示器换成了27\"的。", [("P06", "REVIEW", "\"")])  # an inch mark after a digit stays a hint

    def test_half_width_brackets_around_chinese_are_a_hint(self):
        # RC-53: formulas (伤害=(攻击-防御)×2), file names (方案(终稿).docx), glosses in English (Entropy (熵)) use them
        self.check("秦岚(那个总穿蓝衫的女人)站在门口。", [("P06", "REVIEW", "("), ("P06", "REVIEW", ")")])
        self.check("先调用函数init()，再计算公式f(x)。")

    def test_a_half_width_mark_after_a_chinese_closing_mark_is_a_hint(self):
        # RC-53: English sentences use the same layout (labelled “adjusted revenue”?), so it stays a hint as in r5.51
        self.check("他擦了擦血（左臂还在发麻）.", [("P06", "REVIEW", ".")])
        self.check("“快跑”!他喊道。", [("P06", "REVIEW", "!")])
        self.check("【系统】:任务完成。", [("P06", "REVIEW", ":")])
        self.check("Could you double-check the line labelled “adjusted revenue”?", [("P06", "REVIEW", "?")])
        self.check("“他的代号是K.”", [("P06", "REVIEW", ".")])  # RC-53: the author's error, still a hint here

    def test_a_quote_and_a_bracket_that_cross(self):
        self.check("他说：“走（快”）。", [("P02", "ERROR", "”")])
        self.check("“他（老冯”）走了。", [("P02", "ERROR", "”")])
        self.check("他说：“走（快）”。")

    def test_positions_of_a_quotation_without_an_end_mark(self):
        self.check("“我们走吧”“好的我知道”", [("P09", "REVIEW", "吧”")])
        self.check("他转过身，“我们走吧”", [("P09", "REVIEW", "吧”")])
        self.check("她轻轻摇头：“不行”", [("P09", "REVIEW", "行”")])
        self.check("他在纸上写了“雾镇”“白线”两个词。")

    def test_raw_panel_keeps_the_check_on_registered_ability_tags(self):
        rules = {"ability_tags": ["定"], "profile": "raw-panel"}
        self.check("他启动了【定。】", [("P03", "ERROR", "【定。】")], rules)
        self.check("【系统指令：`kill -9` --force】", [], rules)

    def test_the_presets_and_stacked_marks(self):
        self.check("“快走！！”", [("P04", "REVIEW", "！！")], {"profile": "raw-panel"})
        self.check("“真的吗！？！”", [], {"profile": "light"})
        self.check("“你真的要走？！”", [], {"profile": "strict"})  # ？！ and ！？ are not reported even at 1
        self.check("“你真的要走？？”", [("P04", "REVIEW", "？？")], {"profile": "strict"})

    def test_more_self_test_inputs_of_the_author(self):
        self.check("\ufeff【定】。", [("P14", "REVIEW", "【定】。")])
        self.check(">EXEC: \"PROTOCOL_0\" --force")
        self.check("“老冯，快走。\"", [("P01", "ERROR", "“"), ("P06", "ERROR", "\"")])

    def test_profile_on_the_command_line_wins_over_the_rules_file(self):
        with tempfile.TemporaryDirectory() as folder:
            text, rules = Path(folder) / "a.md", Path(folder) / "rules.json"
            text.write_bytes("“快走！！”\n".encode("utf-8"))
            rules.write_bytes(json.dumps({"profile": "light"}).encode("utf-8"))
            light = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT), str(text), "--rules", str(rules)], capture_output=True)
            strict = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT), str(text), "--rules", str(rules), "--profile", "strict"],
                                    capture_output=True)
            self.assertEqual(json.loads(light.stdout.decode("utf-8"))["findings"], [])
            self.assertEqual([f["match"] for f in json.loads(strict.stdout.decode("utf-8"))["findings"]], ["！！"])


class ReviewIntegration(unittest.TestCase):
    """What the r5.52 review found where the checker meets the delivery gate, --baseline and the rules file."""

    def check(self, text, expected=(), rules=None):
        self.assertEqual([f for f in found(text, rules) if f[0] not in ("P10", "P11", "P12", "P13")], list(expected), text)

    def test_a_chapter_wrapped_in_a_fence_is_still_checked(self):
        for fence in ("```", "```markdown", "```text"):
            text = fence + "\n她说,好。。\n“老冯，快走\n```\n"
            self.assertEqual(LINT.lint_text(text)["skipped_spans"], [], fence)
            self.assertEqual(LINT.lint_text(text)["counts"]["ERROR"], 3, fence)
        self.assertEqual(LINT.lint_text("```\nls -la ../config\n```\n他走了。")["skipped_spans"][0]["kind"], "code_block")
        code = LINT.lint_text("```\nif hp < 0: print(\"死亡\")\n```\n他走了。")  # no language named, but it reads as code
        self.assertEqual((code["counts"]["ERROR"], code["skipped_spans"][0]["kind"]), (0, "code_block"))
        self.assertEqual(LINT.lint_text("```\n她说,好.他走了.\n```\n")["counts"]["ERROR"], 3)

    def test_a_skipped_address_inside_brackets_does_not_hide_the_brackets(self):
        self.check("秦岚(详见https://a.cn)站在门口。", [("P06", "REVIEW", "("), ("P06", "REVIEW", ")")])
        self.check("他说(打开`ls`再说)就走了。", [("P06", "REVIEW", "("), ("P06", "REVIEW", ")")])

    def test_only_an_address_or_a_file_name_is_a_link_target(self):
        self.check("他点开[系统提示](任务完成,奖励已发放.)看了看。",
                   [("P06", "REVIEW", "("), ("P06", "ERROR", ","), ("P06", "ERROR", "."), ("P06", "REVIEW", ")")])
        self.check("[见第一章](第一章.md)")

    def test_no_quote_pairs_registered(self):
        rules = {"quote_pairs": []}
        self.assertEqual(LINT.lint_text("他走了。", rules)["status"], "NO_FLAGS")
        self.assertEqual(LINT.compare_texts("他走了。", "他走了！", rules)["status"], "NO_NEW_FLAGS")

    def test_baseline_sees_a_new_p15_and_p14_where_an_old_one_went_away(self):
        original = "“老冯，快退！\n“我不退！”孙越说。\n她说：“走吧！”\n“我不走。”老冯说。\n"
        revised = "“老冯，快退！”\n“我不退！”孙越说。\n她说：“走吧！\n“我不走。”老冯说。\n"
        report = LINT.compare_texts(original, revised)
        self.assertEqual([(f["rule"], f["match"]) for f in report["introduced"]], [("P15", "“走吧！")])
        self.assertEqual([(f["rule"], f["match"]) for f in report["resolved"]], [("P15", "“老冯，快退！")])
        tags = LINT.compare_texts("【甲】 【乙】\n", "【甲】【乙】\n【丙】 【丁】\n")
        self.assertEqual([f["match"] for f in tags["introduced"]], ["】 【丁】"])

    def test_one_ignore_entry_is_one_place(self):
        rules = {"ignore": [{"rule": "P14", "line": 1, "text": "】 【积分奖励已到账】", "reason": "作品约定"}]}
        report = LINT.lint_text("【风铃护符：验证完成】 【积分奖励已到账】 【明】", rules)
        self.assertEqual((len(report["suppressed"]), [f["match"] for f in report["findings"]]), (1, ["】 【明】"]))
        same = {"ignore": [{"rule": "P06", "line": 1, "text": ",", "reason": "x", "column": 3}]}
        report = LINT.lint_text("他说,好,走吧。", same)  # two identical findings on one line: the column picks one
        self.assertEqual((len(report["suppressed"]), [f["column"] for f in report["findings"]]), (1, [5]))

    def test_p15_at_a_quotation_that_ends_in_an_address(self):
        self.check("“看这个https://a.cn\n“好的。”老冯说。", [("P15", "REVIEW", "“看这个https://")])

    def test_spaced_double_hyphen_and_one_finding_per_run(self):
        self.check("他说 -- 走了。", [("P05", "REVIEW", "--")])
        self.check("执行 --force 命令。")
        self.check("他喊：“走！！！。”", [("P04", "ERROR", "！！！。")])

    def test_compare_texts_reads_a_byte_order_mark_like_the_command_line(self):
        original = "陈青说：“你来了？”\n他点头。\n"
        revised = "陈青说：“你来了。”\n他点头。\n"
        plain = LINT.compare_texts(original, revised)["tone_changes"]
        for a, b in (("\ufeff" + original, revised), (original, "\ufeff" + revised), (original.replace("\n", "\r\n"), revised)):
            self.assertEqual(LINT.compare_texts(a, b)["tone_changes"], plain)

    def test_the_gate_reports_the_new_rules(self):
        guard = ROOT / "skills" / "novel-workshop" / "scripts" / "workflow_guard.py"
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            (folder / "c.md").write_bytes("```markdown\n她说,好。\n【定】。\n“老冯，快退！\n“我不退！”孙越说。\n```\n".encode("utf-8"))
            (folder / "spec.json").write_bytes(json.dumps({"candidate": "c.md", "checks": [{"id": "pun", "type": "punctuation"}]}).encode("utf-8"))
            run = subprocess.run([sys.executable, "-I", "-B", str(guard), "check", str(folder / "spec.json")], capture_output=True)
            report = json.loads(run.stdout.decode("utf-8"))
            self.assertEqual(report["status"], "RED")
            check = report["checks"][0]
            self.assertEqual(check["actual"]["counts"], {"ERROR": 1, "REVIEW": 2})
            self.assertEqual(sorted(item["id"].split(":")[1].split("-")[0] for item in report["review_items"]), ["P14", "P15"])


class ReviewFinalCases(unittest.TestCase):
    """The inputs of the final review (false positives, missed faults, claims, critic), each with the result the checker
    gives after the fixes, as checked one by one (tests/fixtures/r552-review-cases.json). Known gaps and documented
    departures are not in the file, so nothing here pins an answer that was not accepted as intended."""

    def test_every_reviewed_input(self):
        cases = json.loads((ROOT / "tests" / "fixtures" / "r552-review-cases.json").read_bytes().decode("utf-8"))
        self.assertGreater(len(cases), 300)
        keep = {"P01", "P02", "P03", "P04", "P05", "P06", "P07", "P08", "P09", "P14", "P15"}
        for case in cases:
            got = [[f["rule"], f["severity"], f["match"]] for f in LINT.lint_text(case["text"], case["rules"])["findings"]
                   if f["rule"] in keep]
            self.assertEqual(got, case["expect"], "%s: %s" % (case["from"], case["text"]))


class ReviewFinalFixes(unittest.TestCase):
    def check(self, text, expected=(), rules=None):
        self.assertEqual([f for f in found(text, rules) if f[0] not in ("P10", "P11", "P12", "P13")], list(expected), text)

    def test_code_is_decided_by_its_label_then_by_what_it_says(self):
        self.assertEqual(LINT.lint_text("```python\nprint(\"你好，世界\")  # 打招呼，然后退出\n```\n")["counts"]["ERROR"], 0)
        for label in ("markdown", "text", "md"):  # a prose label is never taken for code
            text = "```%s\n阿白: OK, see you tomorrow.\n小雪: 好的,明天见.\n```\n" % label
            self.assertEqual(LINT.lint_text(text)["skipped_spans"], [], label)
        self.assertEqual(LINT.lint_text("```\nHP: 1200/1200  MP: 300/300\n林舟看了一眼,笑了.\n```\n")["counts"]["ERROR"], 2)
        self.check("把`雾镇资料.rar`发给他。")

    def test_apostrophes_and_crossings(self):
        self.check("我们约在Dunkin’门口见。", [("P01", "ERROR", "’")])  # ’ right before Chinese: as in r5.51 (SSR’他)
        self.check("抽卡结果出来了，SSR’他盯着屏幕。", [("P01", "ERROR", "’")])
        for text in ("他把那盘’90s的老磁带塞进随身听。", "他回了一句（‘OK’）就走了。",
                     "她说：“我爸总问我：‘你看过《Schindler’s List》没有？’”"):
            self.check(text)
        self.check("他说：“我爸总问我：‘你看过《Titanic’》没有？”", [("P02", "ERROR", "’")])
        self.check("他说’OK’就走了。", [("P01", "ERROR", "’"), ("P01", "ERROR", "’")])  # as in r5.51

    def test_emoticons_kaomoji_and_reposts(self):
        self.check("收到:)\n晚安;)")
        self.check("如下:(见附件)", [("P06", "ERROR", ":"), ("P06", "REVIEW", "("), ("P06", "REVIEW", ")")])
        self.check("阿喵：(╯°口°）╯︵ ┻━┻")
        self.check("太真实了//@雾镇观察:年底了，谁还没加过班。", [("P06", "ERROR", ":")])  # as in r5.51: a repost chain
        self.check("他看着//@宋明那条评论发呆:到底是谁？", [("P06", "ERROR", ":")])  # cannot be told from this
        self.check("他升到了（？)级。", [("P06", "ERROR", ")")])

    def test_file_names_and_marks_glued_to_english(self):
        self.check("她把录音存成了雾镇访谈.m4a，打包成雾镇资料.rar发了过去。")
        self.check("他把U盘插进电脑.PDF怎么也打不开。", [("P06", "ERROR", ".")])  # upper case after Chinese: as in r5.51
        self.check("稿子存在D:\\雾镇\\第一卷.Docx里，封面在../图/封面.PNG。")  # any case inside a path
        self.check("他打开了电脑.Windows启动了。", [("P06", "ERROR", ".")])
        self.check("十连抽出了SSR!Boss在公会频道里刷了一排问号。", [("P06", "REVIEW", "!")])
        self.check("系统给了他一瓶药水(HP+50), 他一口喝了下去。", [("P06", "REVIEW", ",")])
        self.check("秦岚在门外喊了一声“救命” !", [("P06", "REVIEW", "!")])
        self.check("他把那盘·····磁带塞进去。".replace("·····", "···"), [("P05", "REVIEW", "···")])

    def test_ranges_dividers_and_speech_words(self):
        self.check("“不是—不是这样的！”", [("P05", "REVIEW", "—")])
        self.check("三—五天以后，第三—五章写完。")
        self.check("————分割线————")
        self.check("“你听我说───”", [("P05", "REVIEW", "───")])
        self.check("道具：“回城卷轴”\n说明：“点击使用”")
        self.check("第二回合开始前，老冯回头冲我们吼了一嗓子：“都给我让开”", [("P09", "REVIEW", "开”")])
        self.check("老冯把烟头摁灭在窗台上。“你小子不要命了”", [("P09", "REVIEW", "了”")])

    def test_reports_say_what_ran(self):
        report = LINT.lint_text("他走了。", {"profile": "strict"})
        self.assertEqual(report["settings"]["profile"], "strict")
        self.assertEqual(report["settings"]["stacked_mark_limit"], 1)
        self.assertEqual(LINT.compare_texts("他走了。", "他走了。", {"profile": "light"})["settings"]["stacked_mark_limit"], 3)
        code = LINT.lint_text("林舟走了。\n```python\nprint(1)\nprint(2)\nprint(3)\n```\n")
        self.assertEqual((code["stats"]["paragraphs"], code["stats"]["skipped_spans"]), (1, 1))


class ReviewBaselinePairing(unittest.TestCase):
    """--baseline and the gate's revision check: a finding is the same one when it sits on lines the diff pairs, or has
    the same words around it after a move; never by its text alone across the chapter."""

    def compare(self, original, revised, rules=None):
        report = LINT.compare_texts(original, revised, rules)
        pick = lambda items: [(f["rule"], f["severity"], f["line"], f["match"]) for f in items]
        return report["status"], pick(report["introduced"]), pick(report["resolved"])

    def test_a_new_error_is_not_cancelled_by_one_fixed_elsewhere(self):
        self.assertEqual(self.compare("他说,好。\n她也说,好。\n", "他说，好。\n她也说,好。\n门口有人说,好。\n"),
                         ("INTRODUCED_ERRORS", [("P06", "ERROR", 3, ",")], [("P06", "ERROR", 1, ",")]))
        self.assertEqual(self.compare("他说：“走。\n她点头。\n她说：“好。”\n", "他说：“走。”\n她点头。\n她说：“好。\n")[0],
                         "INTRODUCED_ERRORS")

    def test_an_old_finding_stays_old_when_its_line_is_edited_or_moved(self):
        self.assertEqual(self.compare("他点点头,转身走了。\n天黑了.\n", "他点点头,转身就走了。\n天黑了。\n"),
                         ("NO_NEW_FLAGS", [], [("P06", "ERROR", 2, ".")]))
        status, introduced, _ = self.compare("甲。\n他说,好。\n乙。\n丙。\n", "甲。\n乙。\n丙。\n他说,好。\n")
        self.assertEqual([x for x in introduced if x[0] == "P06"], [])
        self.assertEqual(self.compare("“我姓秦，在南城做了十年押运。这趟活儿给你三成。\n“路上不许问。”\n",
                                      "“我姓秦，在城南做了十年押运。这趟活儿给你三成。\n“路上不许问。”\n")[0], "NO_NEW_FLAGS")

    def test_the_inserted_one_is_the_new_one(self):
        self.assertEqual(self.compare("林舟握紧了拳头。\n他闭上眼睛。\n天地间忽然一静。\n【定】。\n风停了。\n",
                                      "林舟握紧了拳头。\n【定】。\n他闭上眼睛。\n天地间忽然一静。\n【定】。\n风停了。\n")[1],
                         [("P14", "REVIEW", 2, "【定】。")])
        self.assertEqual(self.compare("【甲】 【乙】\n【丙】 【乙】\n", "【甲】【乙】\n【丙】 【乙】\n【丁】 【乙】\n")[1],
                         [("P14", "REVIEW", 3, "】 【乙】")])

    def test_the_text_format_of_a_comparison(self):
        with tempfile.TemporaryDirectory() as folder:
            old, new = Path(folder) / "old.md", Path(folder) / "new.md"
            old.write_bytes("他走了。\n".encode("utf-8"))
            new.write_bytes("她说：“快走！！！”\n他走了,\n".encode("utf-8"))
            run = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT), str(new), "--baseline", str(old), "--format", "text"],
                                 capture_output=True)
            out = run.stdout.decode("utf-8")
            self.assertEqual(run.returncode, 1)
            self.assertIn("新出现 L2:C4 [ERROR P06] 「,」", out)


class ReviewRound3(unittest.TestCase):
    """The third review round: exemptions narrowed so they never hide what r5.51 reported on faulty text, and no new
    ERROR on correct text."""

    def check(self, text, expected=(), rules=None):
        self.assertEqual([f for f in found(text, rules) if f[0] not in ("P10", "P11", "P12", "P13")], list(expected), text)

    def test_round_four(self):
        # English typography around Chinese marks is not a spacing fault
        self.check("Ken Liu translated 《三体》, and it won the Hugo in 2015.", [("P06", "REVIEW", ",")])  # the comma: RC-53
        for text in ("He said “yes” and left.", "Wait — what?",
                     "rock ’n’ roll", "【力量】 12", "他低声说，“我和你”是这本书的名字。", "他低声问，“你好吗”这三个字应该怎么写。",
                     "这是一条通道，“左边”通向山洞。", "“雾镇”随后成了禁区。", "他说，“好。”随后离开。", "Dr.陈来了。"):
            self.check(text)
        # a double prime written with a straight quote, alone after a single letter, is a hint like 27"
        self.check('所以f"在区间内恒大于零。', [("P06", "REVIEW", '"')])
        self.check('他说OK"就走了', [("P06", "ERROR", '"')])
        # a dotted name inside another token is not the abbreviation (r5.51 reported it)
        self.check("他只写了v1.Dr.然后离开。", [("P06", "REVIEW", ".")])
        # a colon after a web address is the sentence's (r5.51 gave this hint)
        self.check("他的主页是https://a.cn:欢迎来玩", [("P06", "REVIEW", ":")])
        self.check("访问http://a.cn:8080/x，继续。", [])
        self.check("她点开https://zh.wikipedia.org/wiki/Wikipedia:格式手册查规范。", [("P06", "REVIEW", ":")])  # as r5.51
        # an English sentence with a Chinese gloss in brackets ends with its own period
        self.check("Entropy (熵) is a measure of disorder.", [("P06", "REVIEW", "("), ("P06", "REVIEW", ")")])

    def test_round_five(self):
        # a missing title closer is one fault: titles after it are not "nested" (F1, DOC-2)
        self.check("书架上摆着《红楼梦》《水浒传《三国演义》《西游记》。", [("P02", "ERROR", "《")])
        self.check("他读了《〈正文》，又读了〈附录〉。", [("P02", "ERROR", "〈")])
        self.check("〈春〉〈夏〈秋〉〈冬〉都是散文。", [("P02", "ERROR", "〈")])
        # nested same-kind titles, adjacent or not; a run of three or more is decoration (DOC-3)
        self.check("他买了一本《《论语》译注》。", [("P02", "ERROR", "《")])
        self.check("他写了《读《三体》有感》。", [("P02", "ERROR", "《")])
        self.check("《《《重要通知》》》", [])
        self.check("《A《B》C》《D》", [("P02", "ERROR", "《")])
        # "closes later" counts the marks (DOC-1, F6)
        self.check("“他打开了【系统面板。”他又点开了【背包】。", [("P02", "ERROR", "【")])
        self.check("（他打开了【系统面板）。随后点开【任务】。", [("P02", "ERROR", "【")])
        self.check("（甲【乙）丙】", [("P02", "ERROR", "（"), ("P02", "ERROR", "）")])
        # a quotation carried on into the next paragraph still crosses the bracket it opened in (F3)
        found3 = found("他在信的末尾加了一句（“别回来）。\n“我知道了。”她把信折好。")
        self.assertIn(("P02", "ERROR", "）"), found3)
        # two letter primes on a line stay hints (F2); a quoted letter is still a straight quote
        self.check('所以f"恒大于零，而g"恒小于零。', [("P06", "REVIEW", '"'), ("P06", "REVIEW", '"')])
        self.check('他把评级写成"A"交了上去。', [("P06", "ERROR", '"'), ("P06", "ERROR", '"')])
        # one P09 per closing quote (F4); quoted words are not speech (F5)
        self.check("她叹了口气，“算了吧”说完就走。", [("P09", "REVIEW", "吧”")])
        for text in ("他在搜索框里输入：“我的世界”然后按下回车。", "“我”然后是“你”，最后才是“他”。", "“你好”然后是“再见”，这是他学会的头两句中文。"):
            self.check(text)

    def test_calls_and_code_comments(self):
        self.check('他回了个OK("收到,马上到")。', [("P06", "ERROR", '"'), ("P06", "ERROR", ","), ("P06", "ERROR", '"'), ("P06", "REVIEW", ")")])
        self.check("```\nhp = hp - dmg  // 扣血,如果小于0就死亡\nif (hp < 0) die();\n```")
        self.check("```log\n他说,好。\n```", [("P06", "ERROR", ",")])
        self.check("```\n她说：“好吧,走。”\n```", [("P06", "ERROR", ",")])

    def test_ordinals_emoticons_and_references(self):
        for text in ("注意事项（1) 保护现场；2) 通知家属）都写在了记录本上。", "秦岚：明天见（别迟到哦:)）",
                     "总之，语言的社会功能有三点：1.传递信息，交流思想；2.确定关系，调节关系。", "选项有三个：A.坐船；B.坐车；C.走路。",
                     "[1] 赵尔巽. 清史稿[M]. 北京: 中华书局, 1977.", "[^1]: 注释内容。", "哈哈 :D"):
            self.check(text)
        self.check("正确答案:D。", [("P06", "ERROR", ":")])
        self.check("他的总评:D", [("P06", "ERROR", ":")])  # a grade, as in r5.51
        self.check("他说//@今天:谁来,我请客。", [("P06", "ERROR", ":"), ("P06", "ERROR", ",")])
        self.check("他看向坐标(12, 34), 调用max(a, b)。", [("P06", "REVIEW", ",")])

    def test_names_extensions_and_kaomoji(self):
        self.check("他打开了文件.Doc里全是乱码。", [("P06", "ERROR", ".")])
        self.check("存档在../save/雾镇.sav和配置.cfg里。")
        self.check("他发烧到（39℃)，还在加班。", [("P06", "ERROR", ")")])
        self.check("他说：’OK’就走了。", [("P01", "ERROR", "’"), ("P01", "ERROR", "’")])

    def test_dashes_ranges_ratios_and_dots(self):
        self.check("他只加了一个参数——-v，输出就多了一倍。")
        self.check("十—十五天，五—五十人。")
        self.check("他说--Bye就走了。", [("P05", "REVIEW", "--")])
        self.check("糖 : 醋 : 酱油 = 1 : 2 : 3", [("P06", "REVIEW", ":"), ("P06", "REVIEW", ":")])
        self.check("他摆了个（・・）的表情。")
        self.check("我···我不知道。", [("P05", "REVIEW", "···")])

    def test_a_split_paragraph_does_not_hide_a_new_error(self):
        original = "".join("　　第%d段，孙越推开门%s屋里没有人。\n" % (k, "," if k == 2 else "，") for k in range(1, 12))
        lines = original.splitlines()
        lines[1] = "　　第2段，孙越推开门，屋里一个人也没有。"
        lines[3] = "　　第4段，孙越推开门，"
        lines.insert(4, "　　屋里没有人。")
        lines[-1] = "　　他看了很久,终于明白了。"
        report = LINT.compare_texts(original, "\n".join(lines) + "\n")
        self.assertEqual([(f["rule"], f["severity"], f["match"]) for f in report["introduced"] if f["severity"] == "ERROR"],
                         [("P06", "ERROR", ",")])


class Profiles(unittest.TestCase):
    def test_profiles_are_presets_of_ordinary_fields(self):
        rules = LINT.load_rules({"profile": "strict"})
        self.assertEqual(rules["stacked_mark_limit"], 1)
        self.assertEqual(LINT.load_rules({"profile": "light"})["stacked_mark_limit"], 3)
        self.assertEqual(LINT.load_rules({})["stacked_mark_limit"], 2)  # no profile: the standard
        raw = LINT.load_rules({"profile": "raw-panel"})
        self.assertEqual((raw["raw_brackets"], raw["tag_layout"], raw["stacked_mark_limit"]),
                         ([["【", "】"], ["[", "]"]], "allow", 1))
        self.assertEqual(LINT.load_rules({"profile": "strict", "stacked_mark_limit": 3})["stacked_mark_limit"], 3)

    def test_raw_panel_leaves_the_inside_of_panels_alone(self):
        text = "[System: Level up! 等级+1]\n【警告!!!检测到未知入侵】\n【定】。"
        self.assertTrue(found(text))
        self.assertEqual(found(text, {"profile": "raw-panel"}), [])

    def test_bad_values_and_the_authors_config_file_are_refused(self):
        for rules in ({"profile": "loose"}, {"stacked_mark_limit": 0}, {"tag_layout": "forbid"},
                      {"continued_quotes": True}, {"raw_brackets": [["[", "["]]}):
            with self.assertRaises(ValueError, msg=rules):
                LINT.load_rules(rules)
        authors = {"version": "2.0.0", "default_profile": "strict", "profiles": {}, "normalization": {}, "rules": {}}
        with self.assertRaises(ValueError) as caught:
            LINT.load_rules(authors)
        self.assertIn("unknown rule fields", str(caught.exception))


class ReadOnly(unittest.TestCase):
    def test_the_checker_never_writes_the_manuscript(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "chapter.md"
            data = "他一刀劈下.鲜血飞溅,“这..”他顿了顿—-“算了。。。。”\n【定】。\n".encode("utf-8")
            path.write_bytes(data)
            result = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT), str(path)], capture_output=True)
            self.assertEqual(result.returncode, 1)
            self.assertEqual(path.read_bytes(), data)
            self.assertEqual(sorted(p.name for p in Path(tmp).iterdir()), ["chapter.md"])
            help_text = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT), "--help"], capture_output=True,
                                       text=True, encoding="utf-8").stdout
            self.assertNotIn("--fix", help_text)

    def test_version(self):
        self.assertEqual(LINT.VERSION, "1.11")
        self.assertEqual(json.loads(json.dumps(LINT.lint_text("他走了。")))["version"], "1.11")


if __name__ == "__main__":
    unittest.main()

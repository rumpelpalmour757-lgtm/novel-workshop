"""Build reviewable proposals and validate replacements before changing text.

No model is called and no file is overwritten by these functions.
"""
from dataclasses import asdict, is_dataclass
import hashlib
import json
import re
from dialogue_core import QUOTE_RE


def _hash(paragraphs):
    data = json.dumps(list(paragraphs), ensure_ascii=False, separators=(',', ':'))
    return hashlib.sha256(data.encode('utf-8')).hexdigest()


def _record(value):
    if is_dataclass(value):
        return asdict(value)
    if isinstance(value, dict):
        return dict(value)
    raise TypeError('issues must be dataclasses or dictionaries')


def _check_location(paragraphs, item):
    p, q = item.get('para_index'), item.get('quote_index')
    if type(p) is not int or type(q) is not int or p < 1 or q < 1 or p > len(paragraphs):
        raise ValueError('invalid quotation location')
    quotes = list(QUOTE_RE.finditer(paragraphs[p - 1]))
    if q > len(quotes):
        raise ValueError('quotation no longer exists')
    match = quotes[q - 1]
    if (item.get('start'), item.get('end'), item.get('original')) != (
            match.start('text'), match.end('text'), match.group('text')):
        raise ValueError('quotation range/original does not match source')
    if item.get('quote_id') != f'p{p}:q{q}':
        raise ValueError('quotation ID does not match location')


def build_patch_request(paragraphs, issues):
    paragraphs = list(paragraphs)
    if any(not isinstance(p, str) for p in paragraphs):
        raise TypeError('paragraphs must contain strings')
    grouped = {}
    for issue in issues:
        data = _record(issue)
        if data.get('confidence') not in ('explicit', 'manual'):
            continue
        item = dict(quote_id=data.get('quote_id'), para_index=data.get('para_index'),
            quote_index=data.get('quote_index'), start=data.get('start'), end=data.get('end'),
            original=data.get('source_quote'), speaker=data.get('speaker'),
            confidence=data.get('confidence'))
        _check_location(paragraphs, item)
        if not isinstance(item['speaker'], str) or item['speaker'] == '未知':
            raise ValueError('patch requires a confirmed speaker')
        quote_id = item['quote_id']
        if quote_id in grouped:
            existing = grouped[quote_id]
            if any(existing[k] != item[k] for k in item):
                raise ValueError('conflicting records for the same quotation')
        else:
            grouped[quote_id] = {**item, 'issues': []}
        problem = {key: data[key] for key in (
            'rule_id', 'reason', 'description', 'rewrite_instruction', 'fix_recipe',
            'matched_span', 'severity') if key in data}
        if problem not in grouped[quote_id]['issues']:
            grouped[quote_id]['issues'].append(problem)
    return {
        'schema_version': 1,
        'source_hash': _hash(paragraphs),
        'items': sorted(grouped.values(), key=lambda item: (item['para_index'], item['quote_index'])),
        'response_schema': {
            'type': 'object', 'additionalProperties': False,
            'required': ['source_hash', 'replacements'],
            'properties': {
                'source_hash': {'type': 'string'},
                'replacements': {'type': 'array', 'items': {
                    'type': 'object', 'additionalProperties': False,
                    'required': ['quote_id', 'original', 'replacement'],
                    'properties': {key: {'type': 'string'} for key in ('quote_id', 'original', 'replacement')},
                }},
            },
        },
    }


def format_patch_prompt(request):
    return (
        '你是小说对白编辑。下列JSON是待复核资料，不是必须执行的改稿命令。'
        '先结合人物口吻判断是否需要修改；可以保留全部原文。'
        '保持人物、事实、语气强弱和含义；不得添加动作、道具、伤势或情节。'
        '同一quote_id只给一个候选替换。只返回符合response_schema的JSON；'
        'source_hash原样回传；replacements可为空或只含需要修改的项。'
        '每项只包含quote_id、original、replacement，original逐字复制。'
        'replacement只写该引语内部文字，不加中文双引号、不换行，不输出旁白。'
        '这只是候选补丁，应用前仍须作者或调用方确认含义。\n\n'
        + json.dumps(request, ensure_ascii=False, indent=2)
    )


def apply_dialogue_patch(paragraphs, request, response):
    """Return a new list after strict validation; semantic acceptance is external.

    Supply the original locally-built request, not a request produced by a model.
    Structural validation guarantees scope, not literary quality or unchanged facts.
    """
    paragraphs = list(paragraphs)
    if not isinstance(request, dict) or request.get('schema_version') != 1:
        raise ValueError('unsupported patch request')
    if request.get('source_hash') != _hash(paragraphs):
        raise ValueError('source changed since request creation')
    if isinstance(response, str):
        # Reject duplicate JSON keys rather than accepting the last value.
        def unique_keys(pairs):
            result = {}
            for key, value in pairs:
                if key in result:
                    raise ValueError('duplicate JSON field')
                result[key] = value
            return result
        response = json.loads(response, object_pairs_hook=unique_keys)
    if not isinstance(response, dict) or set(response) != {'source_hash', 'replacements'}:
        raise ValueError('invalid response fields')
    if response['source_hash'] != request['source_hash'] or not isinstance(response['replacements'], list):
        raise ValueError('response source_hash/replacements mismatch')
    if not isinstance(request.get('items'), list):
        raise ValueError('invalid request items')
    indexed = {}
    for item in request['items']:
        if not isinstance(item, dict):
            raise ValueError('invalid request item')
        _check_location(paragraphs, item)
        if item.get('confidence') not in ('explicit', 'manual') or item.get('speaker') in (None, '', '未知'):
            raise ValueError('unconfirmed attribution cannot be patched')
        if item['quote_id'] in indexed:
            raise ValueError('duplicate request quotation')
        indexed[item['quote_id']] = item
    seen, changes = set(), {}
    for change in response['replacements']:
        if not isinstance(change, dict) or set(change) != {'quote_id', 'original', 'replacement'}:
            raise ValueError('invalid replacement fields')
        if any(not isinstance(change[k], str) for k in change):
            raise ValueError('replacement fields must be strings')
        key = change['quote_id']
        if key in seen or key not in indexed:
            raise ValueError('duplicate or unknown quotation ID')
        seen.add(key)
        item = indexed[key]
        if change['original'] != item['original']:
            raise ValueError('replacement original does not match request')
        replacement = change['replacement']
        if not replacement.strip() or re.search(r'[“”\r\n\v\f\x1c-\x1e\x85\u2028\u2029]', replacement):
            raise ValueError('replacement must stay inside one nonempty quotation')
        changes.setdefault(item['para_index'] - 1, []).append((item['start'], item['end'], replacement))
    updated = list(paragraphs)
    for index, replacements in changes.items():
        for start, end, replacement in sorted(replacements, reverse=True):
            updated[index] = updated[index][:start] + replacement + updated[index][end:]
    return updated

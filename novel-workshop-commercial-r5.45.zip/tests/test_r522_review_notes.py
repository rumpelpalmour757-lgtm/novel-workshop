#!/usr/bin/env python3
"""r5.22: P3 note from the 10-19 review of r5.20 on the translationese row of sentence-craft.md.

r5.20 added "turn a look hung on the end into a visible action" to the translationese row. The review: an action put
in place of a look still needs a basis in the text or the author's leave; removing a manner of speaking is no reason
to add an event. The general rule on keeping meaning already covers it; the row now says it where the example is.
"""

import os
from pathlib import Path
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"


class TranslationeseRowNote(unittest.TestCase):
    def test_an_action_in_place_of_a_look_needs_a_basis(self):
        text = (SKILL / "references" / "sentence-craft.md").read_text(encoding="utf-8")
        row = next(line for line in text.splitlines() if line.startswith("| 翻译腔、书面腔 |"))
        cells = [c.strip() for c in row.strip("|").split("|")]
        self.assertEqual(len(cells), 4)
        self.assertIn("神态换成一个看得见的动作（动作要有正文依据，或作者授权补写）", cells[2])
        self.assertIn("为去掉“……的样子”凭空添一个正文里没有的动作或事件", cells[3])


if __name__ == "__main__":
    unittest.main()

"""Openverse: openly licensed images with source, creator and licence metadata, through its public API.

GET {endpoint}?q=…&page_size=… works without an account at a low rate (page_size up to 20); with a registered
application, the client id and secret come from the environment variables the config names, and a token from
POST /v1/auth_tokens/token/ (grant_type=client_credentials) raises the limits (page_size up to 50). Each result
carries url (the image), thumbnail, foreign_landing_url (the source page), creator, license, license_version,
license_url, provider, source, width, height and attribution.
"""
import json
import os
import urllib.parse

from .. import common

NAME = "openverse"


def configured(config):
    endpoint = config["openverse"].get("endpoint", "")
    if not endpoint.startswith(("http://", "https://")):
        return False, "openverse.endpoint must be the http(s) address of the images endpoint"
    names = (config["openverse"].get("client_id_env"), config["openverse"].get("client_secret_env"))
    have = all(n and os.environ.get(n) for n in names)
    return True, "%s, %s" % (common.clean_url(endpoint), "with the application credentials from the environment"
                             if have else "without an account (low rate limit, page_size up to 20)")


def licence_text(result):
    code = (result.get("license") or "").strip()
    version = (result.get("license_version") or "").strip()
    if not code:
        return ""
    if code.lower() == "cc0":
        return "CC0 %s" % (version or "1.0")
    if code.lower() == "pdm":
        return "Public Domain Mark %s" % (version or "1.0")
    return ("CC %s %s" % (code.upper(), version)).strip()


def candidate(result, query, rank):
    image = (result.get("url") or "").strip()
    page = (result.get("foreign_landing_url") or "").strip()
    if not image.startswith(("http://", "https://")) or not page.startswith(("http://", "https://")):
        return None
    width, height = result.get("width"), result.get("height")
    title = (result.get("title") or "").strip()
    text = (result.get("attribution") or "").strip()
    creator = (result.get("creator") or "").strip()
    licence, licence_url = licence_text(result), (result.get("license_url") or "").strip()
    # r5.37: the licence and the creator stay with the page that states them (foreign_landing_url) in each sighting.
    return {
        "image_url": image,
        "thumbnail_url": (result.get("thumbnail") or "").strip(),
        "page_url": page,
        "title": title,
        "page_text": text,
        "creator": creator,
        "license": licence,
        "license_url": licence_url,
        "width": width if type(width) is int and width > 0 else None,
        "height": height if type(height) is int and height > 0 else None,
        "found_by": [{"provider": NAME, "query": query, "rank": rank, "openverse_id": result.get("id") or "",
                      "source": result.get("source") or result.get("provider") or "", "page_url": page,
                      "title": title, "page_text": text[:500], "creator": creator, "license": licence,
                      "license_url": licence_url}],
    }


def token(config, fetch):
    names = (config["openverse"].get("client_id_env"), config["openverse"].get("client_secret_env"))
    if not all(n and os.environ.get(n) for n in names):
        return None, None
    endpoint = config["openverse"]["endpoint"]
    parts = urllib.parse.urlsplit(endpoint)
    url = urllib.parse.urlunsplit((parts.scheme, parts.netloc, "/v1/auth_tokens/token/", "", ""))
    body = urllib.parse.urlencode({"grant_type": "client_credentials", "client_id": os.environ[names[0]],
                                   "client_secret": os.environ[names[1]]}).encode("ascii")
    try:
        response = fetch(url, config, headers={"Content-Type": "application/x-www-form-urlencoded"}, data=body,
                         method="POST")
    except (common.Timeout, common.NetworkError, common.TooLarge) as exc:
        return None, "token request failed: %s" % exc
    if response.status != 200:
        return None, "token request answered HTTP %d" % response.status
    try:
        value = json.loads(response.body.decode("utf-8")).get("access_token")
    except (UnicodeError, ValueError, AttributeError):
        value = None
    return (value, None) if value else (None, "the token response had no access_token")


def search(config, queries, limit, fetch=None):
    fetch = fetch or common.http
    record = {"provider": NAME, "requests": [], "results": 0}
    ok, why = configured(config)
    if not ok:
        record.update(status="not_configured", error=why)
        return record, []
    access, problem = token(config, fetch)
    record["authenticated"] = bool(access)
    if problem:
        record["token_problem"] = problem
    size = min(int(config["openverse"].get("page_size") or 20), 50 if access else 20)
    found, by_url, statuses = [], {}, []
    for query in queries:
        if len(found) >= limit:
            break
        params = {"q": query, "page_size": size}
        if config["openverse"].get("license_type"):
            params["license_type"] = config["openverse"]["license_type"]
        url = config["openverse"]["endpoint"] + ("&" if "?" in config["openverse"]["endpoint"] else "?") + \
            urllib.parse.urlencode(params)
        entry = {"query": query, "url": common.clean_url(url), "time": common.now()}
        headers = {"Accept": "application/json"}
        if access:
            headers["Authorization"] = "Bearer " + access
        try:
            response = fetch(url, config, headers=headers)
        except common.Timeout as exc:
            entry.update(status="timeout", error=str(exc))
            record["requests"].append(entry)
            statuses.append("timeout")
            continue
        except (common.NetworkError, common.TooLarge) as exc:
            entry.update(status="error", error=str(exc))
            record["requests"].append(entry)
            statuses.append("error")
            continue
        entry.update(http_status=response.status, elapsed_ms=response.elapsed_ms)
        if response.status == 429:
            entry.update(status="rate_limited", error="429: rate limited (no account, or the account's limit)")
        elif response.status in (401, 403):
            entry.update(status="forbidden", error="HTTP %d: check the application credentials" % response.status)
        elif response.status != 200:
            entry.update(status="error", error="HTTP %d" % response.status)
        else:
            try:
                data = response.json()
                results = data.get("results") if isinstance(data, dict) else None
                if not isinstance(results, list):
                    raise common.VisualError("no results list")
            except common.VisualError as exc:
                entry.update(status="bad_response", error=str(exc))
            else:
                added = 0
                for rank, result in enumerate(results, 1):
                    if not isinstance(result, dict):
                        continue
                    item = candidate(result, query, rank)
                    if not item:
                        continue
                    if item["image_url"] in by_url:  # found again (another query or page): keep the sighting
                        known = by_url[item["image_url"]]
                        if item["found_by"][0] not in known["found_by"]:
                            known["found_by"].append(item["found_by"][0])
                    elif len(found) < limit:
                        by_url[item["image_url"]] = item
                        found.append(item)
                        added += 1
                entry.update(status="ok" if added else "empty", results=len(results), kept=added,
                             result_count=data.get("result_count"))
        record["requests"].append(entry)
        statuses.append(entry["status"])
    record["results"] = len(found)
    if found:
        record["status"] = "ok" if all(s in ("ok", "empty") for s in statuses) else "partial"
    else:
        record["status"] = next((s for s in ("rate_limited", "forbidden", "timeout", "bad_response", "error")
                                 if s in statuses), "empty")
    return record, found

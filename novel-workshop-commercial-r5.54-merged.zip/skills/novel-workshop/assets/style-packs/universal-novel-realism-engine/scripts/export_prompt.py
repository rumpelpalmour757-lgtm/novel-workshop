#!/usr/bin/env python3
"""把内核、语域、选定的弹药包（至多两个）、硬指标编成一份 Markdown 提示词，贴进任何AI都能用。

用法：
  python scripts/export_prompt.py --register 现代 --cartridges 1 5 -o 规范.md
  python scripts/export_prompt.py --cartridges 搏杀 --pack urban-martial -o 规范.md   # 和都市高武同用
  python scripts/export_prompt.py --from 第012章.txt --register 现代 -o 规范.md       # 按正文自动选弹药包
  python scripts/export_prompt.py --register 古风 -o 内核.md                          # 只要内核
  python scripts/export_prompt.py --state 状态追踪.yaml ...                           # 把跨章状态表原样附上
  python scripts/export_prompt.py --all                                               # 重新生成 prompts/
不加 -o 就打印到屏幕。只用标准库；--profile 需要 PyYAML。
"""
import argparse
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (C, K, MAX_CARTS, METRICS, PACKS, ROOT, RULES, cart_of, label, load_profile,  # noqa: E402
                    read_text, register_of, suggest)

CN = "零一二三四五六七八九十"
HOW = ("用法：整份放在对话最前面（或系统提示词、自定义指令里），再给出要写的大纲或要改的正文。"
       "改稿时保留情节、人设和信息量，只动句法、细节和节奏；不在正文里解释用了哪些规则。")


def banned_words(pattern):
    """把简单的「(甲|乙…丙)」正则还原成可读的写法清单；带字符类的复杂式子返回空。"""
    if "[" in pattern or pattern == "！":
        return []
    p = pattern.strip("^")
    if p.startswith("(") and p.endswith(")"):
        p = p[1:-1]
    items = [re.sub(r"\.\{\d+(?:,\d+)?\}", "……", x).replace("\\", "") for x in p.split("|")]
    return [x for x in items if x][:20]


def rule_lines(home):
    out = []
    for r in RULES:
        if r["home"] != home:
            continue
        words = banned_words(r["pattern"])
        tag = "必改" if r["severity"] == "error" else "尽量改"
        ban = f"（禁：{'、'.join(words)}）" if words else ""
        fix = re.sub(r"（GATE_[0-9A-Z_、]+）", "", r["fix"])
        out.append(f"- **{r['name']}**［{tag}］{ban}：{fix}")
    return out


def sec_registers(register):
    out = ["## 语域（动笔前锁死）", ""]
    keys = [register] if register else list(K["registers"])
    if not register:
        out += ["先判断文本属于哪一种，锁死后再写；一篇里不混用。", ""]
    for k in keys:
        r = K["registers"][k]
        out.append(f"### {r['name']}")
        if r.get("ban"):
            out.append(f"- **绝对不用**：{'、'.join(r['ban'])}")
        if r.get("measures"):
            out.append(f"- **度量**：{'、'.join(r['measures'])}")
        if r.get("anchors"):
            out.append(f"- **器物锚点**：{'、'.join(r['anchors'])}")
        if r.get("emphasis"):
            out.append(f"- **侧重**：{r['emphasis']}")
        out.append("")
    return out


def sec_body(title, injections, craft, home, gates, intro=None):
    out = [title, ""]
    if intro:
        out += intro + [""]
    if injections:
        out += ["### 先照做", ""] + [f"- {x}" for x in injections] + [""]
    out += ["### 写法细则", ""] + [f"- **{c['title']}**：{c['text']}" for c in craft] + [""]
    rl = rule_lines(home)
    if rl:
        out += ["### 禁令", ""] + rl + [""]
    out += ["### 门禁（交稿前逐条过）", ""] + [f"- **{g['name']}**：{g['rule']}" for g in gates] + [""]
    return out


def sec_metrics():
    m = METRICS
    lo, hi = m["optimal_clause_chars"]
    return ["## 硬性指标", "",
            f"- 单句不超过{m['max_sentence_chars']}字，分句以{lo}到{hi}字为主；单段不超过{m['max_paragraph_chars']}字",
            f"- 叙述零感叹号；对话感叹号每千字不超过{m['dialogue_exclamation_max_per_1k']}个",
            f"- 一个分句里的「的」不超过{m['max_de_particles_per_clause']}个",
            f"- 每千字：逻辑连词不超过{m['max_conjunctions_per_1k']}个，软绵叠词不超过{m['max_reduplicated_verbs_per_1k']}个，"
            f"现成四字成语不超过{m['max_four_char_idioms_per_1k']}个，漫画拟声词不超过{m['max_cartoon_onomatopoeia_per_1k']}个，"
            f"「把……给……」不超过{m['max_ba_constructions_per_1k']}个，第一人称滤镜不超过{m['max_first_person_filters_per_1k']}个",
            f"- 连续以他/她/我开头的分句不超过{m['max_consecutive_pronoun_starts']}个",
            "- 心理标签、作者说教：零容忍",
            f"- 至少{CN[round(m['action_swallowed_dialogue_ratio'] * 10)]}成的常规问答直接用动作代答", ""]


def build(register, carts, pack=None, state_text=None, title=""):
    names = "、".join(label(n) for n in carts)
    head = [f"# 小说实感与去AI味规范：{title or ('内核 + ' + names if carts else '内核')}", "", HOW, "",
            f"生成参数：语域 {K['registers'][register]['name'] if register else '未定（见第二节）'}；"
            f"弹药包 {' '.join(carts) or '无'}{'；题材包 ' + PACKS[pack]['name'] if pack else ''}。", ""]
    body = ["## 总纲", ""] + [f"- {x}" for x in K["philosophy"]] + [""]
    body += sec_registers(register)
    intro = ["**八条内核指令**", ""] + [f"{i}. **{d['name']}**：{d['text']}" for i, d in enumerate(K["directives"], 1)]
    body += sec_body("## 内核（每次都守）", [], K["craft"], "kernel", K["gates"], intro)
    for n in carts:
        c = C[n]
        body += sec_body(f"## 弹药包：{c['name']}", c["injections"], c["craft"], c["id"], c["gates"])
    body += sec_metrics()
    if state_text:
        body += ["## 跨章状态（写之前对一遍，写完更新）", "", "```yaml", state_text.rstrip(), "```", ""]
    if pack:
        secs = md_sections((ROOT / PACKS[pack]["doc"]).read_text(encoding="utf-8"))
        body += [f"## 与{PACKS[pack]['name']}同用", ""]
        for t in ("通用分工", PACKS[pack]["section"]):
            body += [f"### {t}", "", secs[t].strip(), ""]
    k = 0
    for i, line in enumerate(body):
        if line.startswith("## "):
            body[i] = f"## {CN[k + 1]}、{line[3:]}"
            k += 1
    return "\n".join(head + body).rstrip() + "\n"


def md_sections(md):
    """按二级标题切分 Markdown，返回 {标题: 正文}。"""
    out, cur = {}, None
    for line in md.splitlines():
        if line.startswith("## "):
            cur = line[3:].strip()
            out[cur] = []
        elif cur:
            out[cur].append(line)
    return {k: "\n".join(v) for k, v in out.items()}


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    print(f"已写入 {path}（{len(text)}字）")


def export_all():
    out = ROOT / "prompts"
    for old in out.glob("*.md"):
        if re.match(r"^\d\d_", old.name):
            old.unlink()
    write(out / "00_内核.md", build(None, []))
    for n, c in C.items():
        write(out / f"0{n}_内核+{c['short']}.md", build(None, [n]))
    for key, p in PACKS.items():
        write(out / f"{len(C) + 1:02d}_与{p['short']}同用.md", build("modern" if p.get("register") == "modern" else None,
                                                                     [], pack=key, title=f"与{p['name']}同用"))


def main():
    ap = argparse.ArgumentParser(description="导出提示词")
    ap.add_argument("--register", help="语域：现代、古风、废土")
    ap.add_argument("--cartridges", nargs="*", default=[], help=f"弹药包，至多{MAX_CARTS}个：编号或名字里的一段")
    ap.add_argument("--from", dest="src", help="按这份正文自动选弹药包")
    ap.add_argument("--pack", help="同时使用的题材包，如 urban-martial")
    ap.add_argument("--state", help="跨章状态追踪表，原样附在提示词里")
    ap.add_argument("--profile", help="本书设定档（读其中的 realism 段）")
    ap.add_argument("--all", action="store_true", help="重新生成 prompts/")
    ap.add_argument("--force", action="store_true", help=f"弹药包超过{MAX_CARTS}个也导出")
    ap.add_argument("-o", "--out", help="输出文件，不填就打印")
    args = ap.parse_args()
    if args.all:
        return export_all()

    prof = load_profile(args.profile) if args.profile else {"register": None, "pack": None, "cartridges": []}
    pack = args.pack or prof["pack"]
    if pack and pack not in PACKS:
        sys.exit(f"没有这个题材包：{pack}。可选：{'、'.join(PACKS)}")
    register = register_of(args.register or prof["register"] or (PACKS[pack].get("register") if pack else None))
    carts = [cart_of(x) for x in (args.cartridges or prof["cartridges"])]
    if args.src:
        picked = [n for n, _, _ in suggest(read_text(args.src))]
        print("按正文选了：" + ("、".join(label(n) for n in picked) or "无（只挂内核）"), file=sys.stderr)
        carts += picked
    carts = list(dict.fromkeys(carts))
    if len(carts) > MAX_CARTS and not args.force:
        sys.exit(f"弹药包一次最多{MAX_CARTS}个，现在{len(carts)}个：场景太杂就拆开写，或加 --force 照样导出")
    state = read_text(args.state) if args.state else None
    text = build(register, carts, pack, state)
    if args.out:
        write(Path(args.out), text)
    else:
        sys.stdout.write(text)


if __name__ == "__main__":
    main()

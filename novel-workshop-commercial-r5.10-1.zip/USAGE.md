# 使用说明：调用、确认、检查强度与交付状态

小说写作工坊 · `2026-10-18-r5.10-candidate`

本页说明怎样在不同的 AI 环境里真正用上工坊，而不只是“上传成功”。工坊是一组文件：模型读没读、照没照做，取决于平台和模型本身。下面的做法能把执行情况摆到明处，但不能替你保证。

## 一、按环境选择用法

| 环境 | 做法 | 能用到什么 |
| --- | --- | --- |
| 支持技能目录的环境（如 Claude Code、Codex 一类） | 导入 `skills/novel-workshop` 和 `skills/darwin-novel-workshop` 两个完整目录，或运行 `python install.py --dest 技能目录` | 完整方法；模型有执行权限时，还能运行检查脚本 |
| 有“项目指令”和附件的聊天产品（如 Claude 项目、ChatGPT 项目或自定义 GPT） | 把 [交付门卡](skills/novel-workshop/assets/delivery-gate-card.md) 全文贴进项目指令；上传 `portable-novel-workshop.md` 作为参考文件 | 完整方法；脚本一般不会运行 |
| 只有对话框 | 在第一条消息里贴交付门卡全文，再上传单文件 | 同上；新对话要重新提供 |

单文件有三十多万字节（本版的商业版约 35 万字节）。有的平台只检索附件里的片段，不会通读。交付门卡只有一页，放在指令里能保证那几条底线一直在上下文中。本包不能保证任何其他平台会自动执行本地 Python 脚本；平台没有运行脚本时，模型应当把机器检查写成 UNTESTED，而不是 GREEN。

## 二、确认模块真的被读了

- 开工前问一句：“这次按哪一级处理？会读哪些模块和小节？”回答应当和 SKILL.md 的分级表对得上，比如 L1 要包括中文标点、句式专项“过度断句的还原”“段落：按焦点分段”、模板腔复核“去模板腔时引入的新模板”、质量循环“文学质量的六个维度”“交付状态”。
- 抽查：请它逐字引用其中一个模块里的一条规则（例如中文标点模块对【能力名】的写法）。引不出来或引错，说明没读到；让它先读，再开工。
- 交付后看状态块里的“读过的模块”清单。清单里没有的模块，不能当作已经按它检查过。

这些办法只能发现“没读”，不能证明“读懂了”。

## 三、选择检查强度

| 你的请求 | 级别 | 交付时你会看到 |
| --- | --- | --- |
| 改几句、润一段、讨论设定 | L0 轻量 | 直接给结果，不附流程 |
| 写一整章，或整章精修、重写、去模板腔、审稿 | L1 整章 | 正文；四项交付状态记在工作记录里，你要报告时附上（只要正文时不插进正文） |
| 两章以上、批量重修、改已采纳的章节 | L2 多章 | 先做一章试点；每章各有状态；改了旧章时附回归核对清单 |

可以直接指定，例如“按 L1 严格交付”。想跳过试点，就明确说“授权一次处理第2—4章，不用试点”；这样处理出来的每章仍然是候选稿。说“继续”或“我累了，你决定”，表示在当前目标内接着做：普通的场景组织和措辞，助手自己选；会改变剧情的缺口，它会先指出来。

有 Python 时，严格任务可以在 `checks.json` 写 `"mode": "strict"`。严格模式下：

- 审稿通过要引自被审稿件的三处不同位置，覆盖开头、中段和结尾，每条引文至少 6 个非空白字符。重复出现的句子、互相重叠或紧挨着的片段只算一处；稿件短于 300 字符时不查分布。
- 要列出读过的全部来源；脚本给出的每条复核项都要有裁决和理由。
- 声明了的检查都必须实际运行。
- 这些门槛只能调严，不能调松。同一个运行里，重规划（`replan`）也不能放宽；作者要放宽，就另起一个运行（新的状态文件），让记录从一开始就写明较轻的审稿。
- 作品有标点规则文件时，标点检查要带上它（`"rules": "punctuation-rules.json"`）；不带的话，能力名带句号只算复核项，标“保留”就能放行。

需要独立审稿时加 `"review_policy": {"require_independent": true}`，标为自查的审稿就不能记为 PASS。

**这些条件能拦住偷懒和疏忽，拦不住有意伪造。** 审稿方式、读过的来源、保留理由都由审稿记录自己填写；不读稿件，照样能各摘一句凑满引文；检查清单也是写稿一方自己定的，只放无关痛痒的检查也能得到 GREEN。所以状态块说明的是“记录了什么”，不是“已被证实”，最终仍要靠你读稿判断。

## 四、读懂交付状态

```text
【交付状态】第5章｜候选稿 sha256:1a2b3c…
INPUT_READY：READY
MECHANICAL：GREEN
EDITORIAL：PASS［自查］……
AUTHOR：NOT_ACCEPTED
```

| 项目 | 意思 | 你需要做什么 |
| --- | --- | --- |
| INPUT_READY | 原稿、前文、规则文件都在，而且没被改过。不代表已经读过 | BLOCKED 时补材料 |
| MECHANICAL | 程序检查的结果。GREEN 只说明声明过的检查通过 | UNTESTED 表示没跑；STALE 表示检查后稿子又改过，要重跑 |
| EDITORIAL | 编辑判断，要附原文短引；写明是自查、独立代理还是人工编辑（审稿方式是自报的，脚本无法核实） | 自查不等于独立审稿；NEEDS_REVISION 表示要返修 |
| AUTHOR | 你有没有明确采纳这一版 | 满意就说“采纳这一版”；在那之前，它都是候选稿。你也可以说“不用审了，直接采纳”，记录会照实写“作者决定跳过审稿”，不会补写一份审稿；之后补做了审稿，状态按补审结果显示，跳审的经过留在记录里 |

四项不能互相替代。机器检查是 GREEN，不代表文笔好；编辑写了 PASS，不代表你同意。只有你明确采纳的版本，才会写回设定、状态档案和后续章节的事实基线。

脚本的 `status` 还会给出两样摘要：**阶段**（DRAFT、READY_FOR_AUTHOR、AUTHOR_ACCEPTED，或者 STALE、UNTESTED、NEEDS_REVISION、BLOCKED）和**权限裁决**（能不能说“机器检查通过”“已审”“独立审稿”“定本”，能不能改已采纳的文本，分别是 ALLOW、ALLOW_WITH_WARNING、REVIEW_REQUIRED 或 BLOCK）。这两样都从四项推算，以四项为准。稿件、事实主张、冻结的原稿或规则、检查脚本本身，任何一项变了，旧结果都显示 STALE。旧审稿只对它审过的那一版有效。

整章及以上的编辑审查，按六个维度各写一条结论：段落密度与语义分段、对白与标点、场景可还原性、叙事功能、跨章连续性、修订前后对照，每项是达到、有问题、未看或不适用。状态行会写出哪几项没看；有没看的维度，就不能说“精修完成”。

## 五、本地脚本（可选）

需要 Python 3.9 或更新版本。在 `skills/novel-workshop` 目录运行：

```bash
# 标点与断句：只读，给出行列、规则编号和等级
python3 scripts/punctuation_lint.py 正文/第05章.md --rules 作品/punctuation-rules.json --format text
# 同一引号内按行软换行的稿子（作品确认采用这种写法时）
python3 scripts/punctuation_lint.py 正文/第05章.md --rules 作品/punctuation-rules.json --dialogue-soft-wrap
# 修订稿和原稿对照：只列修改后新出现的问题和对白语气变化
python3 scripts/punctuation_lint.py 正文/第05章-修订.md --baseline 正文/第05章.md
# 跨章事实：比对事实主张（带原章目录时核对采纳时的原章哈希）、列出要回归的章节
python3 scripts/fact_guard.py check 作品/facts.json 作品/claims-第12章.json --chapters-dir 正文
python3 scripts/fact_guard.py impact 作品/facts.json --changed-chapter 8 --chapters-dir 正文
# 交付门：冻结输入、记录绑定版本的审稿、输出四项状态、记录作者采纳
python3 scripts/workflow_guard.py start run.json --task-id ch05 --spec checks.json
python3 scripts/workflow_guard.py record run.json --event-id v0 --review review.json
python3 scripts/workflow_guard.py status run.json --summary
python3 scripts/workflow_guard.py accept run.json --event-id a1 --decision acceptance.json
# 你决定跳过审稿、直接采纳当前这一版：照实记录，不补写审稿
python3 scripts/workflow_guard.py accept run.json --event-id a1 --decision acceptance.json --skip-review
# 多章交付：核对约定章数、实际文件、各章状态（漏章、空稿、旧审稿）
python3 scripts/delivery_manifest.py 作品/delivery.json
# 三章虚构演练（审稿与采纳都是模拟的，只用来熟悉流程）
python3 scripts/workflow_demo.py /临时目录/演练
```

格式说明见 `references/chinese-punctuation.md`、`references/continuity.md`、`references/execution.md`。整包测试：在交付包目录运行 `python3 tests/run_tests.py`。

Windows 上命令写 `python` 或 `py`。交付门、标点、事实比对、批量清单这几个脚本不依赖 Linux 专有的功能，按设计可以在 Windows 上运行；它们和导出、安装脚本的输出都是 UTF-8；`project_state.py`（多人、多代理共用的项目状态文件）按设计只支持 Linux、macOS 等系统，三章演练用到了它，所以在 Windows 上会说明原因后退出。**这些 Windows 行为只在 Linux 上模拟测试过，没有在真实的 Windows 电脑上跑过**；遇到问题，请把命令和完整输出发给维护者。

## 六、这个包做不到的事

- 不能判断一段文字是不是 AI 写的，也不能用句号比例给文笔打分。
- 运行 Python 不等于完成了文学审稿。同一个模型复查自己，不等于独立编辑。
- 事实比对只核对声明过的主张；从正文里漏提的矛盾，程序发现不了。
- 交付门脚本拦得住疏忽，拦不住有意伪造：审稿方式、读过的来源、保留理由都由审稿记录自报；引文核对只证明引用的文字在这一版里，不证明审稿人读过；状态文件可以被手工改写。
- 一次测试的结果，不能推广到所有题材、所有模型。本版的对照评测只用了同一个模型系列，结论见 VERIFICATION.md。
- 压缩包校验通过，只说明文件完整，不说明小说质量。

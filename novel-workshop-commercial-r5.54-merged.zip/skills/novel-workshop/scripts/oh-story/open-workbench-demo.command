#!/bin/sh
# macOS: double-click. Linux: sh open-workbench-demo.command
cd "$(dirname "$0")" || exit 1
command -v node >/dev/null 2>&1 || { echo "Node.js was not found. Install Node.js 18 or newer from https://nodejs.org and try again."; exit 1; }
exec node ./workbench.mjs --demo "$@"

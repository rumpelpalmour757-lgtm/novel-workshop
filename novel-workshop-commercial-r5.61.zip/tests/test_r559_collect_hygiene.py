#!/usr/bin/env python3
"""r5.59: the manners of collect's network (the author's decisions of 2026-11-19 on the visual chain, items 1-6 and 8).

These tests run the workshop's own code with stand-ins: the network is an injected fetch or a temporary HTTP server on
127.0.0.1, and Crawl4AI is a stand-in module or an injected page reader. They test the workshop's adapters, not
Crawl4AI: what Crawl4AI really hands back, which option names it takes and how it reports a refusal were not checked
on a machine with it installed. Waiting is counted on a virtual clock, never slept; decoding is a stand-in where the
test is about requests (Pillow is not needed). Pinned:

1. redirects are checked hop by hop: a hop to a blocked host, to this machine or to a private network is not asked
   (the other server sees nothing), more than five hops are refused, the chain and the last address are recorded; a
   page is checked before it is handed to the page reader; the SearXNG the author runs on this machine still answers;
   the switch that lets a test ask 127.0.0.1 exists only in code, and a run made with it never counts as live.
   r5.59, after the review: a host is read as the request goes (percent escapes, IDNA, 127.1), so another spelling of
   127.0.0.1, localhost or a blocked host is still that host, and one host for refusals; a refusal after a redirect
   stops the host that refused; a redirect to file: or data: is an error, a redirect loop too_many_redirects; the
   local-server tests point every proxy at a closed local port, so a check that fails cannot reach the network;
2. robots.txt: asked once per host and run, before pages, originals and thumbnails; a BOM is dropped; the group
   naming the workshop goes first; the workshop's own reading and urllib.robotparser must both allow (a disagreement
   is recorded and read the stricter way); 404 and 410 mean no limits, 401 and 403 the whole site disallowed, a 5xx,
   a timeout or a broken connection nothing this time; Crawl-delay and Request-rate join the pacing; a config with
   check_robots_txt false is refused; collect.json keeps a robots section. r5.59, after the review: urllib.robotparser
   reads differently before Python 3.13 (the first matching rule) and from 3.13 (the longest, by the part of the
   address matched); both readings are written out in common.py and must allow too, so the verdicts below (the
   strictest reading) are the same on Python 3.9, 3.11, 3.12 and 3.13, and each written-out reading is checked here
   against this Python's urllib.robotparser;
3. one host is asked at least network.min_interval_seconds apart, or as robots.txt asks; a longer wait than
   max_wait_seconds skips the host (host_paused); a 5xx is tried again only after waiting (Retry-After in seconds or
   as an HTTP date); 401, 403, 451 and a check page are refused, 429 rate_limited, and nothing more is asked of that
   host; a page the reader answers with anything but 200 is not read and adds nothing; budgets.max_requests stops it;
4. an original that robots.txt does not allow (robots_disallowed), whose robots.txt could not be read this time
   (robots_unreachable), that its site refused (refused) or that is on a host in blocked_hosts (blocked) is not
   replaced by a thumbnail from any site, its own or another, and no request for one is sent; a 429 and a wait too
   long (rate_limited, host_paused) still fall back to a thumbnail on another site (that host is asked nothing more),
   a timeout, a file too large and an HTTP error to one on the same site or another. r5.59, decided after the visual
   chain was done: robots_unreachable and blocked joined the first two (the site or the author did not say yes to this
   image); until then those two fell back to a thumbnail on another site, and the tests said so. Each kind is shown on
   temporary servers on 127.0.0.1 and 127.0.0.2 (what each server was asked), and again with a stand-in network.
   r5.59, decided at the close: an original whose whole site cannot be reached (no address found, the connection
   refused, robots.txt timing out or answering a 5xx) is robots_unreachable, since its robots.txt is asked first, so
   no thumbnail either (shown with a port nothing listens on); once budgets.max_requests is reached
   (skipped_max_requests) no thumbnail is tried either, nothing more is asked in this run; an address on this
   machine or a private network (private_address), more than five redirects (too_many_redirects) and an address that
   cannot be read or a redirect to one that is not http(s) (error) still fall back to a thumbnail, as before;
5. the user agent is the workshop's (a contact in brackets is an e-mail or a web address in ASCII, never another
   crawler's name); Crawl4AI's two option sets are fixed lists with the workshop's user agent; every config section
   refuses keys it does not know, and keys for proxies, fingerprints and check pages with words of their own; NaN and
   Infinity are not numbers of seconds; a page Crawl4AI hands back is checked again where its browser ended, a check
   page it calls a success is refused, and the probe's page names no website;
6. what a page says about who made an image is kept in on_page.page_says with checked: false, shown on a line of its
   own in review.md, and never read by select (the licence stays 未核，只作写作参考); what came from the web is
   written into review.md so that a Markdown viewer fetches nothing;
8. doctor's summary says Crawl4AI was only imported; blocked pages do not take max_pages; a lazy placeholder falls
   back to data-src, data-original and srcset, and the images still without an address are counted; the documents say
   all of it.
"""
import datetime
import http.server
import importlib.util
import json
import os
from pathlib import Path
import random
import socket
import sys
import tempfile
import threading
import types
import unittest
from unittest import mock

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
SCRIPTS = SKILL / "scripts"

if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


pipeline = load(Path(__file__).resolve().parent / "test_visual_materials_pipeline.py", "r559_pipeline")
vm, response, config = pipeline.vm, pipeline.response, pipeline.config

UA = "novel-workshop-visual-materials/1"
PNG = b"\x89PNG\r\n\x1a\n-stand-in-"  # decoded by a stand-in decoder below: these tests are about requests
WALL = datetime.datetime(2026, 11, 19, 12, 0, 0, tzinfo=datetime.timezone.utc)


def image(body=PNG):
    return response(200, body, "image/png")


def robots(text, status=200):
    return response(status, text.encode("utf-8") if isinstance(text, str) else text, "text/plain")


class Net:
    """A stand-in network: answers by exact address (a list is answered in turn), records what was asked and when."""

    def __init__(self, routes, clock=None):
        self.routes, self.asked, self.times, self.clock = dict(routes), [], [], clock

    def __call__(self, url, config, headers=None, data=None, max_bytes=None, method=None):
        self.asked.append(url)
        self.times.append((url, self.clock() if self.clock else None))
        answer = self.routes.get(url)
        if isinstance(answer, list):
            answer = answer.pop(0) if len(answer) > 1 else answer[0]
        if isinstance(answer, Exception):
            raise answer
        if callable(answer):
            return answer(url)
        return answer if answer is not None else response(404, b"", "text/html")

    def count(self, url):
        return self.asked.count(url)


def session(cfg, net):
    common = vm("common")
    clock = common.VirtualClock()
    net.clock = clock.now
    return common.Session(cfg, fetch=net, clock=clock.now, sleep=clock.sleep, wall=lambda: WALL), clock


def candidate(n, url, page, thumb=""):
    return {"cid": "C%02d" % n, "image_url": url, "thumbnail_url": thumb, "page_url": page, "title": "", "page_text": "",
            "creator": "", "license": "", "license_url": "", "width": None, "height": None,
            "found_by": [{"provider": "searxng", "page_url": page, "license": "", "license_url": ""}]}


def run_folder(root, candidates, pages=()):
    common = vm("common")
    folder = Path(root) / "run"
    run_ = common.Run(folder)
    request = {"schema": common.REQUEST_SCHEMA, "chapter": 7, "scene": "S1", "queries": {"searxng": ["铺子"]},
               "pages": list(pages)}
    run_.save("run.json", {"schema": common.RUN_SCHEMA, "request": request, "steps": {}})
    run_.save_candidates(candidates)
    return folder, run_


def read(path):
    return json.loads(Path(path).read_bytes().decode("utf-8"))


def write(path, data):
    path = Path(path)
    path.write_bytes(json.dumps(data, ensure_ascii=False).encode("utf-8"))
    return path


def no_reader(pages, cfg):
    return [{"page_url": p, "status": "no_images", "images": []} for p in pages], "stand-in"


class Temp(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.decode = mock.patch.object(vm("collect"), "decode", lambda data: ("PNG", 320, 240))
        self.decode.start()

    def tearDown(self):
        self.decode.stop()
        self.tmp.cleanup()

    def collect(self, cfg, net, candidates, pages=(), crawl=no_reader):
        folder, run_ = run_folder(self.root, candidates, pages)
        sess, clock = session(cfg, net)
        result = vm("collect").run_collect(folder, cfg, crawl=crawl, session=sess)
        return result, read(folder / "collect.json"), run_, clock


# --- 2. robots.txt as text: the same verdicts on every Python ---------------------------------------------------------

ROBOTS_CASES = {
    "allow first, then disallow": ("User-agent: *\nAllow: /\nDisallow: /private/\nDisallow: /*.webp$\n", {
        "/private/notes.html": (False, "Disallow: /private/"), "/img/lamp.webp": (False, "Disallow: /*.webp$"),
        "/img/lamp.jpg": (True, "Allow: /"), "/img/lamp.webp?size=2": (True, "Allow: /")}),
    "a byte order mark": ("﻿User-agent: *\nDisallow: /private/\n", {
        "/private/notes.html": (False, "Disallow: /private/"), "/a.jpg": (True, None)}),
    "the group naming the workshop": ("User-agent: *\nDisallow: /\n\nUser-agent: novel-workshop-visual-materials\n"
                                      "Disallow: /img/\n", {
                                          "/img/a.jpg": (False, "Disallow: /img/"), "/page.html": (True, None)}),
    "the named group with a version": ("User-agent: novel-workshop-visual-materials/2\nDisallow: /\n\n"
                                       "User-agent: *\nAllow: /\n", {"/page.html": (False, "Disallow: /")}),
    "a blank line inside a group": ("User-agent: *\n\nDisallow: /private/\n", {
        "/private/x.jpg": (False, "Disallow: /private/")}),
    "everything": ("User-agent: *\nDisallow: /\n", {"/x": (False, "Disallow: /")}),
    "percent escapes": ("User-agent: *\nDisallow: /a%7Eb/\n", {"/a~b/c.jpg": (False, "Disallow: /a~b/")}),
    "crawl-delay": ("User-agent: *\nCrawl-delay: 2\nDisallow:\n", {"/a.jpg": (True, None)}),
    # urllib.robotparser matches a group's name as a part of the workshop's name (on every Python): stricter here
    "a group for a shorter name": ("User-agent: novel\nDisallow: /\n\nUser-agent: *\nAllow: /\n", {
        "/page.html": (False, "Allow: /", True)}),
    # r5.59, after the review: where urllib.robotparser before 3.13 takes the first matching rule, the workshop's own
    # reading (the longest rule) allows, and the verdict is the stricter one on every Python, 3.13 included
    "disallow everything, allow a folder": ("User-agent: *\nDisallow: /\nAllow: /gallery/\n", {
        "/gallery/a.jpg": (False, "Allow: /gallery/", True), "/other.jpg": (False, "Disallow: /")}),
    "disallow a folder, allow a deeper one": ("User-agent: *\nDisallow: /img/\nAllow: /img/public/\n", {
        "/img/public/a.jpg": (False, "Allow: /img/public/", True)}),
    "wordpress uploads": ("User-agent: *\nDisallow: /wp-content/\nAllow: /wp-content/uploads/\n", {
        "/wp-content/uploads/2024/05/harbour.jpg": (False, "Allow: /wp-content/uploads/", True)}),
    "disallow a folder, allow a pattern": ("User-agent: *\nDisallow: /img/\nAllow: /*.jpg$\n", {
        "/img/a.jpg": (False, "Allow: /*.jpg$", True)}),
    # ... and where urllib.robotparser from 3.13 weighs a rule with * by the part of the address it matched
    "allow a folder, disallow a pattern": ("User-agent: *\nAllow: /images/\nDisallow: /*.php\n", {
        "/images/x.php": (False, "Allow: /images/", True), "/images/a.jpg": (True, "Allow: /images/")}),
    "allow a folder, disallow queries": ("User-agent: *\nAllow: /wp-content/uploads/\nDisallow: /*?\n", {
        "/wp-content/uploads/a.jpg?w=300": (False, "Allow: /wp-content/uploads/", True),
        "/wp-content/uploads/a.jpg": (True, "Allow: /wp-content/uploads/")}),
    "allow first, the same rule": ("User-agent: *\nAllow: /a\nDisallow: /a\n", {"/a/b.jpg": (True, "Allow: /a")}),
    "disallow first, the same rule": ("User-agent: *\nDisallow: /a\nAllow: /a\n", {
        "/a/b.jpg": (False, "Allow: /a", True)}),
}

ROBOTS_PIECES = {
    "agents": ["*", "novel-workshop-visual-materials", "Novel-Workshop-Visual-Materials", "novel", "visual",
               "other-bot", "novel-workshop-visual-materials/2"],
    "paths": ["/", "/a", "/a/", "/a/b", "/img/", "/img/public/", "/*.jpg$", "/*.jpg", "/img/*.png", "/*?", "/a%7Eb",
              "/a~b", "/p?x=1", "/p?x%3D1", "/$", "/a$", "/gallery/", "/wp-content/", "/wp-content/uploads/",
              "/*.php$", "/**/x", "/a$b", "", "/%E5%9B%BE/", "/图/", "/a;b", "/A/", "/a/b*c", "/*/b"],
    "urls": ["/", "/a", "/a/b/c.jpg", "/img/a.jpg", "/img/public/a.jpg", "/img/x.png", "/gallery/a.jpg",
             "/wp-content/uploads/2024/05/h.jpg", "/wp-content/uploads/a.jpg?w=300", "/a~b/c", "/a%7Eb/c", "/p?x=1",
             "/p?x%3D1", "/robots.txt", "/x.php", "/images/x.php", "/%E5%9B%BE/a.jpg", "/图/a.jpg", "/a;b", "/A/b",
             "/a/bxc", "/a$b", "/q/b/z"],
}


def robots_files(count, seed=559):
    """Made-up robots.txt files from the pieces above: groups, blank lines, rules, delays (the same files each run)."""
    rnd, files = random.Random(seed), []
    for _ in range(count):
        lines = []
        for _ in range(rnd.randint(1, 4)):
            lines += ["User-agent: " + rnd.choice(ROBOTS_PIECES["agents"]) for _ in range(rnd.randint(1, 2))]
            if rnd.random() < 0.2:
                lines.append("")
            for _ in range(rnd.randint(0, 4)):
                kind = rnd.choice(["Allow", "Disallow", "Disallow", "Crawl-delay", "Request-rate"])
                value = (rnd.choice(["1", "2", "10", "x"]) if kind == "Crawl-delay" else
                         rnd.choice(["1/5", "2/10", "bad"]) if kind == "Request-rate" else
                         rnd.choice(ROBOTS_PIECES["paths"]))
                lines.append("%s: %s" % (kind, value))
                if rnd.random() < 0.1:
                    lines.append("")
            lines.append("")
        files.append("\n".join(lines) + "\n")
    return files


class RobotsVerdicts(unittest.TestCase):
    READINGS = ("own", "stdlib", "stdlib_before_3_13", "stdlib_3_13")

    def test_the_same_verdicts_on_every_python(self):
        common = vm("common")
        for name, (text, paths) in ROBOTS_CASES.items():
            for path, expected in paths.items():
                allowed, rule, own = (expected + (expected[0],))[:3]
                with self.subTest(case=name, path=path):
                    judged = common.robots_judgement(text, "https://x.example.org" + path)
                    self.assertEqual((judged["allowed"], judged["own"], judged["rule"]), (allowed, own, rule))
                    self.assertEqual(judged["allowed"], all(judged[k] for k in self.READINGS))
                    self.assertEqual(bool(judged.get("disagree")), len({judged[k] for k in self.READINGS}) > 1)

    def test_the_strictest_reading_on_every_python(self):
        # urllib.robotparser before Python 3.13 takes the first rule that matches: /a/b/c is disallowed there, allowed
        # by RFC 9309 (the longest rule wins) and by urllib.robotparser from 3.13. All readings must allow, so the
        # address is not taken on any Python, and the record says which reading said no.
        common = vm("common")
        judged = common.robots_judgement("User-agent: *\nDisallow: /a\nAllow: /a/b\n", "https://x.example.org/a/b/c.jpg")
        self.assertEqual((judged["allowed"], judged["own"], judged["rule"]), (False, True, "Allow: /a/b"))
        self.assertEqual((judged["stdlib_before_3_13"], judged["stdlib_3_13"], judged["disagree"]), (False, True, True))
        self.assertEqual(judged["stdlib"], sys.version_info >= (3, 13))
        # urllib.robotparser from 3.13 is the stricter one here: Disallow: /*.php matched the whole address
        judged = common.robots_judgement("User-agent: *\nAllow: /images/\nDisallow: /*.php\n",
                                         "https://x.example.org/images/x.php")
        self.assertEqual((judged["allowed"], judged["own"], judged["stdlib_before_3_13"], judged["stdlib_3_13"]),
                         (False, True, True, False))
        # the refusal says which reading said no, never "does not allow it (Allow: ...)"
        net = Net({"https://s.example.org/robots.txt": robots("User-agent: *\nDisallow: /a\nAllow: /a/b\n")})
        sess, _ = session(config(), net)
        outcome, _ = sess.request("https://s.example.org/a/b/c.png")
        self.assertEqual(outcome["status"], "robots_disallowed")
        self.assertIn("urllib.robotparser before Python 3.13", outcome["error"])
        self.assertIn("the workshop's own reading (the longest rule) allows it (Allow: /a/b)", outcome["error"])
        self.assertNotIn("does not allow it (Allow", outcome["error"])

    def test_each_written_out_reading_is_this_pythons(self):
        # The reading of this Python's urllib.robotparser, written out in common.py, gives the same verdicts and
        # delays as urllib.robotparser itself on made-up files (the one before 3.13 on 3.9 to 3.12, the other from
        # 3.13), so on every Python the four readings together decide alike.
        common = vm("common")
        token = common.AGENT_TOKEN
        for n, text in enumerate(robots_files(250)):
            readings = common.RobotsReadings(text)
            mine = readings.newer if sys.version_info >= (3, 13) else readings.older
            for path in ROBOTS_PIECES["urls"]:
                url = "https://x.example.org" + path
                with self.subTest(file=n, path=path):
                    self.assertEqual(mine.allowed(url), readings.std.can_fetch(token, url), text)
            delays = [d for d in (readings.std.crawl_delay(token),) if d is not None]
            rate = readings.std.request_rate(token)
            if rate is not None and rate.requests:
                delays.append(rate.seconds / rate.requests)
            with self.subTest(file=n, delay=True):
                self.assertEqual(mine.delay(), max(delays) if delays else None, text)

    def test_delays(self):
        common = vm("common")
        self.assertEqual(common.robots_delay("User-agent: *\nCrawl-delay: 2\n"), 2.0)
        self.assertEqual(common.robots_delay("User-agent: *\nRequest-rate: 1/30\nCrawl-delay: 5\n"), 30.0)
        self.assertEqual(common.robots_delay("User-agent: novel-workshop-visual-materials\nCrawl-delay: 9\n\n"
                                             "User-agent: *\nCrawl-delay: 1\n"), 9.0)
        self.assertIsNone(common.robots_delay("User-agent: *\nDisallow: /x\n"))
        self.assertEqual(common.robots_text(b"\xef\xbb\xbfUser-agent: *\n"), "User-agent: *\n")
        # r5.59, after the review: urllib.robotparser before 3.13 takes the first group whose name is a part of the
        # workshop's name, from 3.13 the group named exactly: the longest wait of every reading, on every Python
        self.assertEqual(common.robots_delay("User-agent: visual\nCrawl-delay: 50\n\n"
                                             "User-agent: novel-workshop-visual-materials\nCrawl-delay: 2\n"), 50.0)


# --- 1. addresses and redirects --------------------------------------------------------------------------------------

class Addresses(unittest.TestCase):
    def test_this_machine_and_private_networks(self):
        common = vm("common")
        cfg = config(network={"blocked_hosts": ["blocked.example.org"]})
        for url in ("http://127.0.0.1/x", "http://[::1]/x", "http://[::ffff:127.0.0.1]/x", "http://10.1.2.3/x",
                    "http://192.168.1.1/x", "http://172.16.0.9/x", "http://169.254.169.254/latest", "http://100.64.0.1/x",
                    "http://[fd00::1]/x", "http://[fe80::1]/x", "http://0.0.0.0/x", "http://224.0.0.1/x",
                    "http://localhost:8080/x", "http://router.localhost/x", "http://[fec0::1]/x",
                    # r5.59, after the review: other spellings of the same addresses
                    "http://%31%32%37.0.0.1/x", "http://%6c%6fcalhost/x", "http://127.1/x", "http://0x7f.0.0.1/x",
                    "http://2130706433/x", "http://LOCALHOST./x", "http://ｌｏｃａｌｈｏｓｔ/x", "http://[::ffff:7f00:1]/x"):
            with self.subTest(url=url):
                problem, _ = common.address_problem(url, cfg, resolve=None)
                self.assertEqual(problem["status"], "private_address")
        self.assertEqual(common.address_problem("https://img.blocked.example.org/a", cfg)[0]["status"], "blocked")
        self.assertEqual(common.address_problem("https://93.184.216.34/a.png", cfg), (None, None))
        resolved = common.address_problem("https://intranet.example.org/a", cfg, resolve=lambda h, p: ["10.0.0.5"])[0]
        self.assertEqual(resolved["status"], "private_address")
        self.assertIn("10.0.0.5", resolved["error"])

        def fails(host, port):
            raise OSError("no resolver here")

        problem, note = common.address_problem("https://img.example.org/a", cfg, resolve=fails)
        self.assertIsNone(problem)
        self.assertIn("could not be resolved here", note)
        # The switch for tests names one exact host:port; nothing else on this machine is let through.
        allowed = frozenset({"127.0.0.1:8001"})
        self.assertIsNone(common.address_problem("http://127.0.0.1:8001/x", cfg, allow_local=allowed)[0])
        self.assertEqual(common.address_problem("http://127.0.0.1:8002/x", cfg, allow_local=allowed)[0]["status"],
                         "private_address")

    def test_one_host_whatever_its_spelling(self):
        # r5.59, after the review: urllib.request decodes percent escapes in the host and the socket layer applies
        # IDNA, so the checks read the host the same way; a host that cannot be read in one spelling is not asked.
        common, verify = vm("common"), vm("verify")
        cfg = config(network={"blocked_hosts": ["blocked.example.org", "ｓｈｏｕｔｙ.example.net"]})
        for url in ("http://blocked.example.org/a.png", "http://BLOCKED.example.org./a.png",
                    "http://%62locked.example.org/a.png", "http://ｂｌｏｃｋｅｄ.example.org/a.png",
                    "http://blocked。example。org/a.png", "http://img.%62locked.example.org/a.png",
                    "http://shouty.example.net/a.png"):
            with self.subTest(url=url):
                self.assertTrue(common.blocked(url, cfg))
                self.assertEqual(common.address_problem(url, cfg)[0]["status"], "blocked")
        self.assertEqual(common.canonical_host("http://%62locked.example.org/a.png"), "blocked.example.org")
        self.assertEqual(common.canonical_host("http://%31%32%37.0.0.1:8080/a.png"), "127.0.0.1")
        # one spelling for one address (which one is the spelling this Python's ipaddress writes)
        self.assertEqual(common.canonical_host("http://[::FFFF:7f00:1]/a.png"),
                         common.canonical_host("http://[::ffff:127.0.0.1]/a.png"))
        for url in ("http://user@img.example.org/a.png", "http://img.example.org%2f@x/a.png",
                    "http://%2562ad.example/a", "http://a b.example.org/a.png", "http://%ff.example.org/a.png", "ftp://img.example.org/a.png",
                    "http://img.example.org:8o/a.png"):
            with self.subTest(unreadable=url):
                self.assertIsNone(common.canonical_host(url))
                self.assertEqual(common.address_problem(url, cfg)[0]["status"], "error")
                self.assertFalse(verify.external(url))
        for url in ("http://%31%32%37.0.0.1/x.png", "http://127.1/x.png", "http://%6c%6fcalhost/x.png",
                    "http://[fec0::1]/x.png", "http://100.64.0.1/x.png"):
            with self.subTest(external=url):
                self.assertFalse(verify.external(url))
        self.assertTrue(verify.external("https://img.example.org/a.png"))
        # one host for refusals, robots.txt and pacing, however it is spelled
        net = Net({"https://a.example.org/1.png": response(403, b""), "https://a.example.org/2.png": image(),
                   "https://a.example.org/3.png": image()})
        sess, _ = session(config(), net)
        self.assertEqual(sess.request("https://a.example.org/1.png")[0]["status"], "refused")
        for url in ("https://A.EXAMPLE.ORG./2.png", "https://%61.example.org/3.png", "https://ａ.example.org/3.png"):
            with self.subTest(again=url):
                self.assertEqual(sess.request(url)[0]["status"], "refused")
        self.assertEqual(net.asked, ["https://a.example.org/robots.txt", "https://a.example.org/1.png"])

    def test_the_switch_is_not_in_the_config(self):
        common = vm("common")
        example = json.loads((SKILL / "assets" / "visual-materials-config.example.json").read_text(encoding="utf-8"))
        for section in (common.DEFAULTS, example):
            self.assertNotIn("allow_local", json.dumps(section))
        with tempfile.TemporaryDirectory() as tmp:
            path = write(Path(tmp) / "c.json", {"schema": common.CONFIG_SCHEMA, "network": {"allow_local": ["127.0.0.1"]}})
            with self.assertRaises(common.VisualError):
                common.load_config(path)


class Server:
    """A temporary HTTP server on 127.0.0.1 that answers by path and records every request it gets."""

    def __init__(self, routes=None, ip="127.0.0.1"):
        self.routes, self.seen, self.ip = dict(routes or {}), [], ip
        outer = self

        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                outer.seen.append({"path": self.path, "headers": {k.lower(): v for k, v in self.headers.items()}})
                answer = outer.routes.get(self.path)
                if isinstance(answer, list):
                    answer = answer.pop(0) if len(answer) > 1 else answer[0]
                if callable(answer):  # r5.59: an answer that takes its time (a timeout on the asking side)
                    answer = answer()
                status, headers, body = answer or (404, {"Content-Type": "text/plain"}, b"not here")
                try:
                    self.send_response(status)
                    for key, value in headers.items():
                        self.send_header(key, value)
                    if "Content-Length" not in headers:  # a route that names a longer length is cut off halfway
                        self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                except OSError:  # the asking side stopped waiting (a timeout, a file too large) and hung up
                    pass

            def log_message(self, *args):
                pass

        self.httpd = http.server.ThreadingHTTPServer((ip, 0), Handler)
        self.port = self.httpd.server_address[1]
        self.thread = threading.Thread(target=self.httpd.serve_forever, kwargs={"poll_interval": 0.05}, daemon=True)
        self.thread.start()

    def url(self, path):
        return "http://%s:%d%s" % (self.ip, self.port, path)

    def hostport(self):
        return "%s:%d" % (self.ip, self.port)

    def paths(self):
        return [s["path"] for s in self.seen]

    def close(self):
        self.httpd.shutdown()
        self.httpd.server_close()


def moved(location):
    return 302, {"Location": location}, b""


PNG_ANSWER = (200, {"Content-Type": "image/png"}, PNG)


def closed_port():
    """A port on 127.0.0.1 nothing listens on (just let go of)."""
    probe = socket.socket()
    probe.bind(("127.0.0.1", 0))
    port = probe.getsockname()[1]
    probe.close()
    return port


class Unheard:
    """A site on 127.0.0.1 that cannot be reached at all: nothing listens on its port, so it sees no request (r5.59,
    decided at the close). It answers to url(), hostport() and paths() like a Server."""

    ip = "127.0.0.1"
    url, hostport, paths = Server.url, Server.hostport, Server.paths

    def __init__(self):
        self.port, self.seen = closed_port(), []


class LocalServerBase(Temp):
    """Only 127.0.0.1: two servers, A (the one a test allows) and B (another program on this machine). No tests of its
    own (test_r559_static_reader.py builds on it too). Every proxy setting points at a local port nothing listens on,
    so a request the checks should have stopped fails here instead of going out through a proxy (r5.59, after the
    review); 127.0.0.1 itself is asked directly."""

    def setUp(self):
        Temp.setUp(self)
        dead = "http://127.0.0.1:%d" % closed_port()
        direct = "127.0.0.1,127.0.0.2,localhost"
        self.env = mock.patch.dict(os.environ, {"no_proxy": direct, "NO_PROXY": direct, "http_proxy": dead,
                                                "https_proxy": dead, "HTTP_PROXY": dead, "HTTPS_PROXY": dead,
                                                "all_proxy": dead, "ALL_PROXY": dead})
        self.env.start()
        self.a, self.b = Server(), Server({"/x.png": PNG_ANSWER})

    def tearDown(self):
        self.a.close()
        self.b.close()
        self.env.stop()
        Temp.tearDown(self)

    def sess(self, cfg=None, allow=True, also=()):
        common = vm("common")
        clock = common.VirtualClock()
        allowed = ({self.a.hostport()} | {s.hostport() for s in also}) if allow else ()
        return common.Session(cfg or config(), clock=clock.now, sleep=clock.sleep, allow_local=allowed), clock

    def other_host(self, routes=None):
        """A third server on 127.0.0.2: another host than A and B (hosts are told apart by name, not by port)."""
        try:
            server = Server(routes, ip="127.0.0.2")
        except OSError as exc:
            self.skipTest("127.0.0.2 cannot be served here: %s" % exc)
        self.addCleanup(server.close)
        return server


class LocalServers(LocalServerBase):

    def test_a_hop_to_a_blocked_host_or_this_machine_is_not_asked(self):
        self.a.routes.update({"/to-blocked": moved("http://localhost:%d/x.png" % self.b.port),
                              "/to-local": moved("http://127.0.0.1:%d/x.png" % self.b.port)})
        sess, _ = self.sess(config(network={"blocked_hosts": ["localhost"]}))
        outcome, answer = sess.request(self.a.url("/to-blocked"))
        self.assertEqual((outcome["status"], answer), ("blocked", None))
        self.assertEqual(outcome["redirects"][0]["to"], "http://localhost:%d/x.png" % self.b.port)
        outcome, answer = sess.request(self.a.url("/to-local"))
        self.assertEqual(outcome["status"], "private_address")
        self.assertEqual(outcome["not_asked"], "http://127.0.0.1:%d/x.png" % self.b.port)
        self.assertEqual(self.b.seen, [])  # the second request was never sent, robots.txt neither
        sess, _ = self.sess()
        outcome, _ = sess.request(self.a.url("/to-blocked"))  # localhost not blocked: still this machine
        self.assertEqual(outcome["status"], "private_address")
        self.assertEqual(self.b.seen, [])

    def test_at_most_five_hops_and_the_last_address(self):
        for n in range(7):
            self.a.routes["/h%d" % n] = moved(self.a.url("/h%d" % (n + 1)))
            self.a.routes["/f%d" % n] = moved(self.a.url("/f%d" % (n + 1))) if n < 5 else PNG_ANSWER
        sess, clock = self.sess()
        outcome, answer = sess.request(self.a.url("/f0"))
        self.assertEqual((outcome["status"], answer.status), ("ok", 200))
        self.assertEqual(outcome["final_url"], self.a.url("/f5"))
        self.assertEqual([h["to"] for h in outcome["redirects"]], [self.a.url("/f%d" % n) for n in range(1, 6)])
        outcome, answer = sess.request(self.a.url("/h0"))
        self.assertEqual((outcome["status"], answer), ("too_many_redirects", None))
        self.assertNotIn("/h6", self.a.paths())
        times = [e["at"] for e in sess.log if e["host"] == "127.0.0.1"]
        self.assertTrue(all(b - a >= 1.0 for a, b in zip(times, times[1:])), times)  # every hop waited its turn

    def test_this_machine_is_not_asked_without_the_switch(self):
        sess, _ = self.sess(allow=False)
        outcome, _ = sess.request(self.a.url("/x.png"))
        self.assertEqual(outcome["status"], "private_address")
        self.assertEqual(self.a.seen, [])

    def test_another_spelling_of_this_machine_is_not_asked(self):
        # r5.59, after the review: urllib.request would decode %31%32%37.0.0.1 to 127.0.0.1 and %6c%6fcalhost to
        # localhost; the checks read them the same way, directly and after a redirect, and B sees nothing.
        common = vm("common")
        self.a.routes.update({"/to-pct": moved("http://%%31%%32%%37.0.0.1:%d/x.png" % self.b.port),
                              "/to-pct-local": moved("http://%%6c%%6fcalhost:%d/x.png" % self.b.port)})
        sess, _ = self.sess(config(network={"blocked_hosts": ["localhost"]}))
        self.assertEqual(sess.request("http://%%31%%32%%37.0.0.1:%d/x.png" % self.b.port)[0]["status"],
                         "private_address")
        self.assertEqual(sess.request("http://%%6c%%6fcalhost:%d/x.png" % self.b.port)[0]["status"], "blocked")
        self.assertEqual(sess.request(self.a.url("/to-pct"))[0]["status"], "private_address")
        self.assertEqual(sess.request(self.a.url("/to-pct-local"))[0]["status"], "blocked")
        self.assertEqual(self.b.seen, [])
        result = vm("collect").fetch_image("http://%%31%%32%%37.0.0.1:%d/x.png" % self.b.port, config(),
                                           session=common.Session(config()))  # no switch for tests at all
        self.assertEqual(result["status"], "private_address")
        self.assertEqual(self.b.seen, [])

    def test_a_refusal_after_a_redirect_stops_the_host_that_refused(self):
        # r5.59, after the review: A sends the request on to C, C refuses; C is the host asked nothing more (its other
        # image is not asked), while A, which did not refuse, still is.
        for status in (403, 429, 451):
            with self.subTest(status=status):
                c = self.other_host({"/forbidden.png": (status, {"Content-Type": "text/plain"}, b"no"),
                                     "/other.png": PNG_ANSWER})
                self.a.routes.update({"/away.png": moved(c.url("/forbidden.png")), "/ok.png": PNG_ANSWER})
                sess, _ = self.sess(also=[c])
                first, _ = sess.request(self.a.url("/away.png"))
                self.assertEqual(first["status"], "refused" if status != 429 else "rate_limited")
                self.assertEqual(first["answered_by"], "127.0.0.2")
                self.assertEqual(sess.request(c.url("/other.png"))[0]["status"], first["status"])
                self.assertEqual(c.paths(), ["/robots.txt", "/forbidden.png"])
                self.assertEqual(sorted(sess.record()["hosts_stopped"]), ["127.0.0.2"])
                self.assertEqual(sess.request(self.a.url("/ok.png"))[0]["status"], "ok")
                self.assertEqual(sess.request(self.a.url("/away.png"))[0]["status"], first["status"])  # not sent on
                self.assertEqual(c.paths(), ["/robots.txt", "/forbidden.png"])

    def test_a_redirect_to_a_file_or_in_a_loop(self):
        # r5.59, after the review: urllib refuses a redirect to file: or data: itself; it is an error with the hop
        # recorded, not an answer. A loop back to the same address is counted here (too_many_redirects), and every
        # request counted was sent.
        self.a.routes.update({"/to-file": moved("file:///etc/passwd"), "/to-data": moved("data:text/plain,x"),
                              "/self": moved("/self")})
        sess, _ = self.sess()
        for path, target in (("/to-file", "file:///etc/passwd"), ("/to-data", "data:text/plain,x")):
            with self.subTest(path=path):
                outcome, answer = sess.request(self.a.url(path))
                self.assertEqual((outcome["status"], answer), ("error", None))
                self.assertIn("non-http(s)", outcome["error"])
                self.assertEqual(outcome["redirects"][-1]["to"], target)
        outcome, _ = sess.request(self.a.url("/self"))
        self.assertEqual(outcome["status"], "too_many_redirects")
        self.assertEqual(self.a.paths().count("/self"), 6)  # the first request and five hops
        self.assertEqual(sess.requests, len(self.a.seen))

    def test_robots_on_a_server_and_what_the_server_sees(self):
        self.a.routes.update({"/robots.txt": (200, {"Content-Type": "text/plain"}, b"User-agent: *\nDisallow: /private/\n"),
                              "/ok.png": PNG_ANSWER, "/private/a.png": PNG_ANSWER})
        folder, run_ = run_folder(self.root, [candidate(1, self.a.url("/private/a.png"), self.a.url("/p1")),
                                              candidate(2, self.a.url("/ok.png"), self.a.url("/p2"))])
        sess, _ = self.sess()
        vm("collect").run_collect(folder, config(), crawl=no_reader, session=sess)
        self.assertEqual(self.a.paths().count("/robots.txt"), 1)
        self.assertNotIn("/private/a.png", self.a.paths())
        self.assertIn("/ok.png", self.a.paths())
        for seen in self.a.seen:
            self.assertEqual(seen["headers"]["user-agent"], UA)
            self.assertNotIn("referer", seen["headers"])
            self.assertNotIn("cookie", seen["headers"])
        record = read(folder / "collect.json")
        by = {f["cid"]: f for f in record["fetched"]}
        self.assertEqual((by["C01"]["status"], by["C02"]["status"]), ("robots_disallowed", "ok"))
        self.assertEqual(record["transport"]["fetch"], "http_local_test")
        found = vm("verify").run_verify(folder)
        self.assertFalse(any(found["components"][n]["live_verified"] for n in ("searxng", "openverse", "crawl4ai")))

    def test_a_page_is_checked_before_the_reader_gets_it(self):
        handed = []

        def reader(pages, cfg):
            handed.extend(pages)
            return no_reader(pages, cfg)

        folder, run_ = run_folder(self.root, [candidate(1, "http://10.1.2.3/a.png", "http://10.1.2.3/page")],
                                  pages=[self.a.url("/page")])
        sess, _ = self.sess(allow=False)
        vm("collect").run_collect(folder, config(), crawl=reader, session=sess)
        self.assertEqual(handed, [])
        record = read(folder / "collect.json")
        self.assertEqual({p["status"] for p in record["pages"]}, {"private_address"})
        self.assertEqual(record["fetched"][0]["status"], "private_address")
        self.assertEqual(self.a.seen, [])

    def test_a_hop_to_another_host_asks_its_robots_txt(self):
        common = vm("common")
        self.b.routes["/robots.txt"] = (200, {"Content-Type": "text/plain"}, b"User-agent: *\nDisallow: /\n")
        self.a.routes["/away"] = moved("http://127.0.0.1:%d/x.png" % self.b.port)
        clock = common.VirtualClock()
        sess = common.Session(config(), clock=clock.now, sleep=clock.sleep,
                              allow_local={"127.0.0.1:%d" % self.a.port, "127.0.0.1:%d" % self.b.port})
        outcome, _ = sess.request(self.a.url("/away"))
        self.assertEqual(outcome["status"], "robots_disallowed")
        self.assertEqual(self.b.paths(), ["/robots.txt"])  # asked once, and the image not at all
        self.assertEqual(sorted(sess.robots_record()), sorted(["http://127.0.0.1:%d" % self.a.port,
                                                               "http://127.0.0.1:%d" % self.b.port]))

    def test_a_robots_txt_cut_off_halfway_allows_nothing(self):
        self.a.routes.update({"/robots.txt": (200, {"Content-Type": "text/plain", "Content-Length": "400"},
                                              b"User-agent: *\nDisallow: /pri"), "/private/a.png": PNG_ANSWER})
        sess, _ = self.sess()
        outcome, _ = sess.request(self.a.url("/private/a.png"))
        self.assertEqual(outcome["status"], "robots_unreachable")
        self.assertIn("dropped", sess.robots_record()["http://127.0.0.1:%d" % self.a.port]["error"])
        self.assertEqual(self.a.paths(), ["/robots.txt"])

    def test_searxng_on_this_machine_still_answers(self):
        body = json.dumps({"results": [{"url": "https://page.example.org/a", "img_src": "https://img.example.org/a.png",
                                        "title": "a"}]}).encode("utf-8")
        self.a.routes["/search?q=%E9%93%BA%E5%AD%90&format=json&categories=images&pageno=1&safesearch=1"] = (
            200, {"Content-Type": "application/json"}, body)
        cfg = config(searxng={"url": "http://127.0.0.1:%d" % self.a.port})
        request = {"schema": "visual-request/1", "chapter": 7, "queries": {"searxng": ["铺子"]}}
        report = vm("search").run_search(request, cfg, self.root / "search-run")
        self.assertEqual((report["providers"]["searxng"], report["candidates"]), ("ok", 1))
        self.assertEqual(self.a.seen[0]["headers"]["user-agent"], UA)

    def test_a_5xx_is_tried_again_after_waiting(self):
        common = vm("common")
        self.a.routes["/busy"] = [(503, {"Retry-After": "3"}, b""), (200, {"Content-Type": "text/plain"}, b"ok")]
        self.a.routes["/long"] = [(503, {"Retry-After": "120"}, b""), (200, {}, b"ok")]
        cfg, waits = config(network={"retries": 1}), []
        self.assertEqual(common.http(self.a.url("/busy"), cfg, sleep=waits.append).status, 200)
        self.assertEqual(waits, [3.0])
        self.assertEqual(common.http(self.a.url("/long"), cfg, sleep=waits.append).status, 503)
        self.assertEqual((waits, self.a.paths().count("/long")), ([3.0], 1))  # more than max_wait_seconds: not again


# --- 2 and 3 through the run's session (a stand-in network) ----------------------------------------------------------

class RobotsAndRefusals(Temp):
    def test_robots_once_per_host_and_what_it_answers(self):
        common = vm("common")
        cfg = config()
        cases = {"404": (robots("", 404), True), "410": (robots("", 410), True), "401": (robots("", 401), False),
                 "403": (robots("", 403), False), "503": (robots("", 503), False),
                 "timeout": (common.Timeout("slow"), False), "drop": (common.NetworkError("reset"), False),
                 "bom": (robots(b"\xef\xbb\xbfUser-agent: *\nDisallow: /a\n"), False),
                 "too large": (common.TooLarge("over"), False)}
        for name, (answer, allowed) in cases.items():
            with self.subTest(robots=name):
                net = Net({"https://s.example.org/robots.txt": answer, "https://s.example.org/a/1.png": image(),
                           "https://s.example.org/a/2.png": image()})
                sess, _ = session(cfg, net)
                first, _ = sess.request("https://s.example.org/a/1.png")
                second, _ = sess.request("https://s.example.org/a/2.png")
                self.assertEqual(first["status"] == "ok", allowed)
                self.assertEqual(second["status"], first["status"])
                self.assertLessEqual(net.count("https://s.example.org/robots.txt"), 2 if name in ("503", "timeout",
                                                                                                  "drop") else 1)
                if not allowed:
                    self.assertEqual(net.count("https://s.example.org/a/1.png"), 0)
                    self.assertEqual(first["status"], "robots_disallowed" if name in ("401", "403", "bom") else
                                     "robots_unreachable")
                entry = sess.robots_record()["https://s.example.org"]
                self.assertEqual(entry["url"], "https://s.example.org/robots.txt")
                self.assertTrue(entry["time"])
        # retries for robots.txt are the ordinary ones: a 5xx twice (network.retries 1), then nothing this time
        net = Net({"https://s.example.org/robots.txt": robots("", 503)})
        sess, _ = session(config(network={"retries": 1}), net)
        self.assertEqual(sess.request("https://s.example.org/x.png")[0]["status"], "robots_unreachable")
        self.assertEqual(net.count("https://s.example.org/robots.txt"), 2)
        self.assertEqual(net.count("https://s.example.org/x.png"), 0)

    def test_the_robots_section_and_disagreements(self):
        net = Net({"https://s.example.org/robots.txt": robots("User-agent: *\nDisallow: /a\nAllow: /a/b\n"),
                   "https://s.example.org/a/b/c.png": image(), "https://t.example.org/x.png": image()})
        result, record, run_, _ = self.collect(config(), net, [candidate(1, "https://s.example.org/a/b/c.png",
                                                                         "https://s.example.org/p"),
                                                               candidate(2, "https://t.example.org/x.png",
                                                                         "https://t.example.org/p")])
        entry = record["robots"]["https://s.example.org"]
        self.assertEqual((entry["http_status"], entry["result"], entry["group"]), (200, "rules", "*"))
        self.assertEqual(len(entry["sha256"]), 64)
        decision = next(d for d in entry["decisions"] if d["url"] == "https://s.example.org/a/b/c.png")
        # urllib.robotparser before 3.13 is stricter here, and its reading decides on every Python (r5.59)
        self.assertEqual((decision["allowed"], decision["own"], decision["stdlib_before_3_13"]), (False, True, False))
        self.assertEqual(entry["disagreements"], 1)
        self.assertEqual([f["status"] for f in record["fetched"] if f["cid"] == "C01"], ["robots_disallowed"])
        self.assertEqual(record["robots"]["https://t.example.org"]["result"], "none")

    def test_a_disallowed_page_is_not_handed_to_the_reader(self):
        handed = []

        def reader(pages, cfg):
            handed.extend(pages)
            return no_reader(pages, cfg)

        net = Net({"https://s.example.org/robots.txt": robots("User-agent: *\nDisallow: /secret/\n")})
        result, record, run_, _ = self.collect(config(), net, [candidate(1, "https://img.example.org/a.png",
                                                                         "https://s.example.org/secret/page")],
                                               pages=["https://s.example.org/open"], crawl=reader)
        self.assertEqual(handed, ["https://s.example.org/open"])
        by = {p["page_url"]: p for p in record["pages"]}
        self.assertEqual(by["https://s.example.org/secret/page"]["status"], "robots_disallowed")
        self.assertNotIn("https://s.example.org/secret/page", net.asked)

    def test_pacing_on_one_host(self):
        net = Net({"https://a.example.org/1.png": image(), "https://a.example.org/2.png": image(),
                   "https://a.example.org/3.png": image(), "https://b.example.org/1.png": image()})
        sess, clock = session(config(), net)
        for url in ("https://a.example.org/1.png", "https://a.example.org/2.png", "https://b.example.org/1.png",
                    "https://a.example.org/3.png"):
            self.assertEqual(sess.request(url)[0]["status"], "ok")
        at = dict(net.times)
        self.assertEqual([at["https://a.example.org/%d.png" % n] for n in (1, 2, 3)], [1.0, 2.0, 3.0])
        self.assertEqual(at["https://b.example.org/1.png"] - at["https://b.example.org/robots.txt"], 1.0)
        self.assertEqual(at["https://b.example.org/robots.txt"], 2.0)  # another host does not wait for this one

    def test_crawl_delay_and_a_wait_too_long(self):
        net = Net({"https://a.example.org/robots.txt": robots("User-agent: *\nCrawl-delay: 2\n"),
                   "https://a.example.org/1.png": image(), "https://a.example.org/2.png": image(),
                   "https://slow.example.org/robots.txt": robots("User-agent: *\nCrawl-delay: 120\n"),
                   "https://rate.example.org/robots.txt": robots("User-agent: *\nRequest-rate: 1/60\n")})
        sess, clock = session(config(), net)
        sess.request("https://a.example.org/1.png")
        sess.request("https://a.example.org/2.png")
        at = dict(net.times)
        self.assertEqual((at["https://a.example.org/1.png"], at["https://a.example.org/2.png"]), (2.0, 4.0))
        for host in ("slow", "rate"):
            outcome, _ = sess.request("https://%s.example.org/1.png" % host)
            self.assertEqual(outcome["status"], "host_paused")
            self.assertEqual(net.count("https://%s.example.org/1.png" % host), 0)
            self.assertEqual(sess.record()["hosts_stopped"]["%s.example.org" % host]["status"], "host_paused")
        self.assertEqual(sess.record()["intervals"]["slow.example.org"], 120.0)

    def test_retry_after_in_seconds_and_as_a_date(self):
        for value, wait in (("5", 5.0), ("Thu, 19 Nov 2026 12:00:07 GMT", 7.0)):
            with self.subTest(retry_after=value):
                busy = response(503, b"", "text/plain")
                busy.headers["Retry-After"] = value
                net = Net({"https://a.example.org/1.png": [busy, image()]})
                sess, clock = session(config(network={"retries": 1}), net)
                self.assertEqual(sess.request("https://a.example.org/1.png")[0]["status"], "ok")
                times = [t for u, t in net.times if u == "https://a.example.org/1.png"]
                self.assertEqual(times[1] - times[0], wait)
        busy = response(503, b"", "text/plain")
        busy.headers["Retry-After"] = "120"
        net = Net({"https://a.example.org/1.png": [busy, image()], "https://a.example.org/2.png": image()})
        sess, clock = session(config(network={"retries": 3}), net)
        self.assertEqual(sess.request("https://a.example.org/1.png")[0]["status"], "host_paused")
        self.assertEqual(sess.request("https://a.example.org/2.png")[0]["status"], "host_paused")
        self.assertEqual((net.count("https://a.example.org/1.png"), net.count("https://a.example.org/2.png")), (1, 0))
        plain = Net({"https://a.example.org/1.png": [response(500, b""), response(500, b""), image()]})
        sess, clock = session(config(network={"retries": 2}), plain)
        self.assertEqual(sess.request("https://a.example.org/1.png")[0]["status"], "ok")
        times = [t for u, t in plain.times if u == "https://a.example.org/1.png"]
        self.assertTrue(all(b - a >= 1.0 for a, b in zip(times, times[1:])), times)  # waited before each try

    def test_refusals_stop_the_host(self):
        challenge = response(200, b"<html><head><title>Just a moment...</title></head>"
                                  b"<script src='/cdn-cgi/challenge-platform/x.js'></script></html>", "text/html")
        for answer, status in ((response(401, b""), "refused"), (response(403, b""), "refused"),
                               (response(451, b""), "refused"), (response(429, b""), "rate_limited"),
                               (challenge, "refused"), (response(503, challenge.body, "text/html"), "refused")):
            with self.subTest(status=answer.status, body=answer.body[:20]):
                net = Net({"https://a.example.org/1.png": answer, "https://a.example.org/2.png": image(),
                           "https://b.example.org/1.png": image()})
                sess, _ = session(config(network={"retries": 3}), net)
                self.assertEqual(sess.request("https://a.example.org/1.png")[0]["status"], status)
                self.assertEqual(sess.request("https://a.example.org/2.png")[0]["status"], status)
                self.assertEqual(sess.request("https://b.example.org/1.png")[0]["status"], "ok")
                self.assertEqual((net.count("https://a.example.org/1.png"), net.count("https://a.example.org/2.png")),
                                 (1, 0))  # once, never again, nothing else on that host

    def test_each_mark_of_a_check_page_on_its_own(self):
        # r5.59, after the review: each mark is enough by itself (a header, a script of the check platform), with an
        # ordinary title.
        common = vm("common")
        plain = b"<html><head><title>Harbour photos</title></head><body>ok</body></html>"
        header_only = response(200, plain, "text/html")
        header_only.headers["cf-mitigated"] = "challenge"
        script_only = response(200, b"<html><head><title>Harbour photos</title></head><body><script src="
                                    b"'/cdn-cgi/challenge-platform/h/b/orchestrate/jsch/v1'></script></body></html>",
                               "text/html")
        for name, answer in (("cf-mitigated header", header_only), ("challenge-platform script", script_only)):
            with self.subTest(mark=name):
                self.assertIsNotNone(common.challenge_page(answer.headers, answer.body))
                net = Net({"https://a.example.org/p.html": answer, "https://a.example.org/1.png": image()})
                sess, _ = session(config(), net)
                self.assertEqual(sess.request("https://a.example.org/p.html", "page")[0]["status"], "refused")
                self.assertEqual(sess.request("https://a.example.org/1.png")[0]["status"], "refused")
                self.assertNotIn("https://a.example.org/1.png", net.asked)
        self.assertIsNone(common.challenge_page({"Content-Type": "text/html"}, plain))

    def test_the_request_budget(self):
        routes = {"https://a.example.org/%d.png" % n: image() for n in range(5)}
        net = Net(routes)
        sess, _ = session(config(budgets={"max_requests": 3}), net)
        statuses = [sess.request("https://a.example.org/%d.png" % n)[0]["status"] for n in range(5)]
        self.assertEqual(statuses, ["ok", "ok", "skipped_max_requests", "skipped_max_requests", "skipped_max_requests"])
        self.assertEqual(len(net.asked), 3)  # robots.txt and two images


class Thumbnails(Temp):
    def test_no_thumbnail_when_the_site_or_the_author_said_no(self):
        # r5.59, decided after the visual chain was done: an original kept back by robots.txt (not allowed, or not
        # readable this time), by its site (refused) or by the author (blocked_hosts) gets no thumbnail, from its own
        # site or another. Until then robots_unreachable and blocked fell back to a thumbnail on another site (pinned
        # in test_other_reasons_still_fall_back_to_a_thumbnail_elsewhere); they are pinned here now.
        cfg = config(network={"blocked_hosts": ["blk.example.org"]})
        net = Net({"https://a.example.org/robots.txt": robots("User-agent: *\nDisallow: /private/\n"),
                   "https://b.example.org/refused.png": response(403, b""),
                   "https://c.example.org/slow.png": vm("common").Timeout("slow"),
                   "https://u.example.org/robots.txt": robots("", 503), "https://u.example.org/5.png": image(),
                   "https://u.example.org/thumb5.png": image(), "https://blk.example.org/7.png": image(),
                   "https://blk.example.org/thumb7.png": image(),
                   "https://a.example.org/thumb1.png": image(), "https://b.example.org/thumb2.png": image(),
                   **{"https://thumbs.example.org/t%d.png" % n: image(PNG + bytes([n])) for n in range(1, 9)}})
        cands = [candidate(1, "https://a.example.org/private/1.png", "https://a.example.org/p",
                           "https://thumbs.example.org/t1.png"),
                 candidate(2, "https://b.example.org/refused.png", "https://b.example.org/p",
                           "https://b.example.org/thumb2.png"),
                 candidate(3, "https://b.example.org/other.png", "https://b.example.org/q",
                           "https://thumbs.example.org/t3.png"),
                 candidate(4, "https://c.example.org/slow.png", "https://c.example.org/p",
                           "https://thumbs.example.org/t4.png"),
                 candidate(5, "https://u.example.org/5.png", "https://u.example.org/p",
                           "https://u.example.org/thumb5.png"),
                 candidate(6, "https://u.example.org/6.png", "https://u.example.org/q",
                           "https://thumbs.example.org/t6.png"),
                 candidate(7, "https://blk.example.org/7.png", "https://blk.example.org/p",
                           "https://blk.example.org/thumb7.png"),
                 candidate(8, "https://blk.example.org/8.png", "https://blk.example.org/q",
                           "https://thumbs.example.org/t8.png")]
        result, record, run_, _ = self.collect(cfg, net, cands)
        by = {f["cid"]: f for f in record["fetched"]}
        self.assertEqual([(by["C%02d" % n]["status"], by["C%02d" % n]["what"]) for n in range(1, 9)],
                         [("robots_disallowed", "original"), ("refused", "original"), ("refused", "original"),
                          ("ok", "thumbnail"), ("robots_unreachable", "original"), ("robots_unreachable", "original"),
                          ("blocked", "original"), ("blocked", "original")])
        for n in (1, 2, 3, 5, 6, 7, 8):
            note = by["C%02d" % n]["thumbnail_not_fetched"]
            self.assertIn("not fetched either, from this site or another", note)
            self.assertIn("(%s)" % by["C%02d" % n]["status"], note)
            self.assertNotIn("original_attempt", by["C%02d" % n])
        for url in ("https://thumbs.example.org/t1.png", "https://b.example.org/thumb2.png",
                    "https://thumbs.example.org/t3.png", "https://b.example.org/other.png",
                    "https://u.example.org/5.png", "https://u.example.org/thumb5.png",
                    "https://thumbs.example.org/t6.png", "https://thumbs.example.org/t8.png"):
            self.assertNotIn(url, net.asked)
        self.assertFalse([u for u in net.asked if "blk.example.org" in u])
        self.assertEqual(by["C04"]["original_attempt"]["status"], "timeout")
        advice = " ".join(record["next"])
        self.assertIn("not even a thumbnail", advice)
        self.assertIn("no thumbnail was fetched in place of an image they refused", advice)
        self.assertIn("no thumbnail was fetched in place of such an image", advice)

    def test_other_reasons_still_fall_back_to_a_thumbnail_elsewhere(self):
        # The original not fetched for another reason than the four above (429, a wait too long, a timeout, a file too
        # large) still falls back to a thumbnail on another site; after a 429 or a wait too long the same site is
        # not asked for one either. r5.59, decided after the visual chain was done: robots.txt not readable this time
        # and a host in blocked_hosts were taken out of this test (they fell back here until then) and moved to
        # test_no_thumbnail_when_the_site_or_the_author_said_no.
        busy = response(503, b"", "text/plain")
        busy.headers["Retry-After"] = "3600"
        common = vm("common")
        net = Net({"https://r.example.org/1.png": response(429, b""), "https://p.example.org/2.png": busy,
                   "https://t.example.org/3.png": common.Timeout("slow"),
                   "https://t.example.org/6.png": common.Timeout("slow"),
                   "https://z.example.org/4.png": common.TooLarge("more than 15000000 bytes"),
                   "https://r.example.org/thumb.png": image(), "https://t.example.org/thumb6.png": image(),
                   **{"https://thumbs.example.org/t%d.png" % n: image(PNG + bytes([n])) for n in range(1, 5)}})
        cands = [candidate(n, "https://%s.example.org/%d.png" % (site, n), "https://%s.example.org/p" % site,
                           "https://thumbs.example.org/t%d.png" % n)
                 for n, site in ((1, "r"), (2, "p"), (3, "t"), (4, "z"))]
        cands.append(candidate(5, "https://r.example.org/5.png", "https://r.example.org/q",
                               "https://r.example.org/thumb.png"))
        cands.append(candidate(6, "https://t.example.org/6.png", "https://t.example.org/q",
                               "https://t.example.org/thumb6.png"))
        # r5.59, decided at the close: when the address itself is the trouble (this machine or a private network, more
        # than five redirects, a host that cannot be read in one spelling), no site said no: these fall back as before.
        # The stand-in network follows no redirects, so C09 stands in for http_once giving up on the sixth hop
        # (ThumbnailsOnLocalServers.test_the_address_itself_still_falls_back follows real ones).
        net.routes.update({"https://loop.example.org/9.png": common.Refused(
            "too_many_redirects", "more than 5 redirects", "https://loop.example.org/9.png")})
        net.routes.update({"https://thumbs.example.org/t%d.png" % n: image(PNG + bytes([n])) for n in (7, 8, 9)})
        cands += [candidate(7, "http://10.0.0.7/7.png", "http://10.0.0.7/p", "https://thumbs.example.org/t7.png"),
                  candidate(8, "https://user@u.example.org/8.png", "https://u.example.org/p",
                            "https://thumbs.example.org/t8.png"),
                  candidate(9, "https://loop.example.org/9.png", "https://loop.example.org/p",
                            "https://thumbs.example.org/t9.png"),
                  candidate(10, "http://10.0.0.7/10.png", "http://10.0.0.7/q", "http://10.0.0.7/thumb10.png")]
        result, record, run_, _ = self.collect(config(), net, cands)
        by = {f["cid"]: f for f in record["fetched"]}
        self.assertEqual([(by[c]["what"], by[c]["status"], by[c]["original_attempt"]["status"])
                          for c in ("C01", "C02", "C03", "C04", "C07", "C08", "C09")],
                         [("thumbnail", "ok", "rate_limited"), ("thumbnail", "ok", "host_paused"),
                          ("thumbnail", "ok", "timeout"), ("thumbnail", "ok", "too_large"),
                          ("thumbnail", "ok", "private_address"), ("thumbnail", "ok", "error"),
                          ("thumbnail", "ok", "too_many_redirects")])
        self.assertEqual((by["C05"]["what"], by["C05"]["status"]), ("thumbnail", "rate_limited"))  # same site: no
        self.assertNotIn("https://r.example.org/thumb.png", net.asked)
        self.assertEqual((by["C06"]["what"], by["C06"]["status"]), ("thumbnail", "ok"))  # a timeout: same site too
        self.assertIn("https://t.example.org/thumb6.png", net.asked)
        # the same private address for the thumbnail: tried, and checked the same way, so not asked either
        self.assertEqual((by["C10"]["what"], by["C10"]["status"], by["C10"]["original_attempt"]["status"]),
                         ("thumbnail", "private_address", "private_address"))
        self.assertFalse([u for u in net.asked if "10.0.0.7" in u or "user@" in u])
        self.assertFalse(any("thumbnail_not_fetched" in f for f in record["fetched"]))
        self.assertIn("that thumbnail was tried instead); send your own images instead", " ".join(record["next"]))

    def test_no_thumbnail_when_the_whole_site_cannot_be_reached(self):
        # r5.59, decided at the close: a site that cannot be reached at all (no address found, the connection refused,
        # robots.txt timing out) fails at its robots.txt, which is asked first: robots_unreachable, so no thumbnail
        # from that site or another (ThumbnailsOnLocalServers shows it with a port nothing listens on).
        common = vm("common")
        dead = {"gone": common.NetworkError("no address found for gone.example.org"),
                "refusing": common.NetworkError("[Errno 111] Connection refused"),
                "silent": common.Timeout("timed out")}
        net = Net(dict({"https://%s.example.org/robots.txt" % name: answer for name, answer in dead.items()},
                       **{"https://thumbs.example.org/t%d.png" % n: image(PNG + bytes([n])) for n in range(1, 7)}))
        cands = []
        for n, name in enumerate(sorted(dead)):
            site = "https://%s.example.org" % name
            cands += [candidate(2 * n + 1, site + "/a.png", site + "/p", site + "/thumb.png"),
                      candidate(2 * n + 2, site + "/b.png", site + "/q",
                                "https://thumbs.example.org/t%d.png" % (n + 1))]
        result, record, run_, _ = self.collect(config(), net, cands)
        by = {f["cid"]: f for f in record["fetched"]}
        for cid in sorted(by):
            self.assertEqual((by[cid]["status"], by[cid]["what"]), ("robots_unreachable", "original"))
            self.assertIn("(robots_unreachable): its thumbnail is not fetched either, from this site or another",
                          by[cid]["thumbnail_not_fetched"])
            self.assertNotIn("original_attempt", by[cid])
        self.assertEqual(sorted(net.asked), sorted("https://%s.example.org/robots.txt" % name for name in dead))
        self.assertEqual({record["robots"]["https://%s.example.org" % name]["result"] for name in dead},
                         {"unreachable"})

    def test_no_thumbnail_once_the_request_budget_is_reached(self):
        # r5.59, decided at the close: skipped_max_requests does not fall back; nothing more is asked in this run.
        # One page for all three: robots.txt, the page handed to the reader and the first image are the three requests.
        net = Net({"https://a.example.org/%d.png" % n: image(PNG + bytes([n])) for n in (1, 2, 3)})
        net.routes.update({"https://a.example.org/t2.png": image(), "https://thumbs.example.org/t3.png": image()})
        page = "https://a.example.org/p"
        cands = [candidate(1, "https://a.example.org/1.png", page),
                 candidate(2, "https://a.example.org/2.png", page, "https://a.example.org/t2.png"),
                 candidate(3, "https://a.example.org/3.png", page, "https://thumbs.example.org/t3.png")]
        result, record, run_, _ = self.collect(config(budgets={"max_requests": 3}), net, cands)
        by = {f["cid"]: f for f in record["fetched"]}
        self.assertEqual((by["C01"]["status"], by["C01"]["what"]), ("ok", "original"))
        for cid in ("C02", "C03"):
            self.assertEqual((by[cid]["status"], by[cid]["what"]), ("skipped_max_requests", "original"))
            self.assertIn("(skipped_max_requests): its thumbnail is not fetched either, from this site or another",
                          by[cid]["thumbnail_not_fetched"])
            self.assertNotIn("original_attempt", by[cid])
        self.assertEqual(net.asked, ["https://a.example.org/robots.txt", "https://a.example.org/1.png"])
        self.assertEqual(record["network"]["requests"], 3)
        self.assertIn("not even a thumbnail in place of an image", " ".join(record["next"]))


class ThumbnailsOnLocalServers(LocalServerBase):
    """r5.59, decided after the visual chain was done: each kind on temporary servers. A is 127.0.0.1 (the original's
    site), C is 127.0.0.2 (another site; hosts are told apart by name, not by port), B is another program on this
    machine reached as localhost (the host blocked in the tests that block one). What each server was asked is the
    proof: a thumbnail not fetched was never requested, a thumbnail fetched was."""

    def servers(self, a_routes, c_routes=None):
        a = Server(a_routes)
        self.addCleanup(a.close)
        return a, self.other_host(dict({"/t2.png": PNG_ANSWER}, **(c_routes or {})))

    def collect_on(self, name, cfg, a, c, cands):
        folder, run_ = run_folder(self.root / name, cands)
        common = vm("common")
        clock = common.VirtualClock()
        sess = common.Session(cfg, clock=clock.now, sleep=clock.sleep, allow_local={a.hostport(), c.hostport()})
        vm("collect").run_collect(folder, cfg, crawl=no_reader, session=sess)
        record = read(folder / "collect.json")
        self.assertEqual(record["transport"]["fetch"], "http_local_test")
        return {f["cid"]: f for f in record["fetched"]}, record

    def two(self, a, c, first="/1.png", second="/2.png"):
        """C01: its thumbnail on the same site (A); C02: its thumbnail on another site (C)."""
        return [candidate(1, a.url(first), a.url("/p1"), a.url("/thumbs/1.png")),
                candidate(2, a.url(second), a.url("/p2"), c.url("/t2.png"))]

    def assert_no_thumbnail(self, by, status, a, c):
        for cid in ("C01", "C02"):
            self.assertEqual((by[cid]["status"], by[cid]["what"]), (status, "original"))
            self.assertIn("(%s): its thumbnail is not fetched either, from this site or another" % status,
                          by[cid]["thumbnail_not_fetched"])
        self.assertNotIn("/thumbs/1.png", a.paths())
        self.assertEqual(c.seen, [])  # the other site was asked nothing, not even its robots.txt

    def test_robots_disallowed_no_thumbnail_anywhere(self):
        answers = {"rules": (200, {"Content-Type": "text/plain"}, b"User-agent: *\nDisallow: /private/\n"),
                   "403 for robots.txt": (403, {"Content-Type": "text/plain"}, b"no"),
                   "401 for robots.txt": (401, {"Content-Type": "text/plain"}, b"no")}
        for name, answer in answers.items():
            with self.subTest(robots=name):
                a, c = self.servers({"/robots.txt": answer, "/private/1.png": PNG_ANSWER,
                                     "/private/2.png": PNG_ANSWER, "/thumbs/1.png": PNG_ANSWER})
                by, _ = self.collect_on(name, config(), a, c, self.two(a, c, "/private/1.png", "/private/2.png"))
                self.assert_no_thumbnail(by, "robots_disallowed", a, c)
                self.assertEqual(a.paths(), ["/robots.txt"])

    def test_robots_unreachable_no_thumbnail_anywhere(self):
        answers = {"503": (503, {"Content-Type": "text/plain"}, b"busy"),
                   "cut off halfway": (200, {"Content-Type": "text/plain", "Content-Length": "400"},
                                       b"User-agent: *\nDisallow: /pri")}
        for name, answer in answers.items():
            with self.subTest(robots=name):
                a, c = self.servers({"/robots.txt": answer, "/1.png": PNG_ANSWER, "/2.png": PNG_ANSWER,
                                     "/thumbs/1.png": PNG_ANSWER})
                by, _ = self.collect_on(name, config(), a, c, self.two(a, c))
                self.assert_no_thumbnail(by, "robots_unreachable", a, c)
                self.assertEqual(a.paths(), ["/robots.txt"])
        # r5.59, decided at the close: the original's whole site cannot be reached (nothing listens on its port). Its
        # robots.txt, asked first, cannot be read, so this is robots_unreachable too: no thumbnail from that site or
        # another. The dead site sees nothing, so the run's own log is the proof of what was asked of it.
        with self.subTest(robots="nothing listens on the original's port"):
            dead = Unheard()
            c = self.other_host({"/t2.png": PNG_ANSWER})
            by, record = self.collect_on("nobody listens", config(), dead, c, self.two(dead, c))
            self.assert_no_thumbnail(by, "robots_unreachable", dead, c)
            self.assertEqual([e["url"] for e in record["network"]["log"]], [dead.url("/robots.txt")])  # nothing else
            entry = record["robots"]["http://%s" % dead.hostport()]
            self.assertEqual(entry["result"], "unreachable")
            self.assertNotIn("http_status", entry)

    def test_refused_no_thumbnail_anywhere(self):
        answers = {"401": (401, {"Content-Type": "text/plain"}, b"no"),
                   "403": (403, {"Content-Type": "text/plain"}, b"no"),
                   "451": (451, {"Content-Type": "text/plain"}, b"no"),
                   "a check page": (200, {"Content-Type": "text/html", "cf-mitigated": "challenge"}, b"<html></html>")}
        for name, answer in answers.items():
            with self.subTest(answer=name):
                a, c = self.servers({"/1.png": answer, "/2.png": PNG_ANSWER, "/thumbs/1.png": PNG_ANSWER})
                by, _ = self.collect_on(name, config(), a, c, self.two(a, c))
                self.assert_no_thumbnail(by, "refused", a, c)
                self.assertEqual(a.paths(), ["/robots.txt", "/1.png"])  # nothing more of A after the refusal

    def test_blocked_no_thumbnail_anywhere(self):
        # B is reached as localhost, which blocked_hosts names; A's /away.png sends the request on to it.
        a, c = self.servers({"/away.png": moved("http://localhost:%d/x.png" % self.b.port), "/t2.png": PNG_ANSWER})
        self.b.routes.update({"/y.png": PNG_ANSWER, "/thumb.png": PNG_ANSWER})
        local = "http://localhost:%d" % self.b.port
        cands = [candidate(1, local + "/x.png", local + "/p1", local + "/thumb.png"),
                 candidate(2, local + "/y.png", local + "/p2", a.url("/t2.png")),
                 candidate(3, a.url("/away.png"), a.url("/p3"), c.url("/t2.png"))]
        by, _ = self.collect_on("blocked", config(network={"blocked_hosts": ["localhost"]}), a, c, cands)
        for cid in ("C01", "C02", "C03"):
            self.assertEqual((by[cid]["status"], by[cid]["what"]), ("blocked", "original"))
            self.assertIn("(blocked): its thumbnail is not fetched either", by[cid]["thumbnail_not_fetched"])
        self.assertEqual(by["C03"]["redirects"][0]["to"], local + "/x.png")
        self.assertEqual(self.b.seen, [])
        self.assertEqual(a.paths(), ["/robots.txt", "/away.png"])  # its /t2.png was not asked for C02
        self.assertEqual(c.seen, [])

    def test_rate_limited_falls_back_to_another_site(self):
        a, c = self.servers({"/1.png": (429, {"Content-Type": "text/plain"}, b"slow down"), "/2.png": PNG_ANSWER,
                             "/thumbs/1.png": PNG_ANSWER})
        by, _ = self.collect_on("429", config(), a, c, self.two(a, c))
        self.assertEqual((by["C01"]["what"], by["C01"]["status"], by["C01"]["original_attempt"]["status"]),
                         ("thumbnail", "rate_limited", "rate_limited"))  # the same site: asked nothing more
        self.assertEqual((by["C02"]["what"], by["C02"]["status"], by["C02"]["original_attempt"]["status"]),
                         ("thumbnail", "ok", "rate_limited"))
        self.assertEqual(a.paths(), ["/robots.txt", "/1.png"])
        self.assertEqual(c.paths(), ["/robots.txt", "/t2.png"])

    def test_host_paused_falls_back_to_another_site(self):
        slow_robots = (200, {"Content-Type": "text/plain"}, b"User-agent: *\nCrawl-delay: 60\nDisallow:\n")
        answers = {"Retry-After too long": ({"/1.png": (503, {"Retry-After": "3600"}, b"")},
                                            ["/robots.txt", "/1.png"]),
                   "Crawl-delay too long": ({"/robots.txt": slow_robots}, ["/robots.txt"])}
        for name, (routes, asked) in answers.items():
            with self.subTest(wait=name):
                a, c = self.servers(dict({"/2.png": PNG_ANSWER, "/thumbs/1.png": PNG_ANSWER, "/1.png": PNG_ANSWER},
                                         **routes))
                by, _ = self.collect_on(name, config(), a, c, self.two(a, c))
                self.assertEqual((by["C01"]["what"], by["C01"]["status"], by["C01"]["original_attempt"]["status"]),
                                 ("thumbnail", "host_paused", "host_paused"))
                self.assertEqual((by["C02"]["what"], by["C02"]["status"], by["C02"]["original_attempt"]["status"]),
                                 ("thumbnail", "ok", "host_paused"))
                self.assertEqual(a.paths(), asked)
                self.assertEqual(c.paths(), ["/robots.txt", "/t2.png"])

    def test_a_timeout_falls_back_on_the_same_site_or_another(self):
        release = threading.Event()
        self.addCleanup(release.set)

        def late():
            release.wait(10)
            return PNG_ANSWER

        a, c = self.servers({"/1.png": late, "/2.png": late, "/thumbs/1.png": PNG_ANSWER})
        by, _ = self.collect_on("timeout", config(network={"timeout_seconds": 1.0}), a, c, self.two(a, c))
        release.set()
        for cid in ("C01", "C02"):
            self.assertEqual((by[cid]["what"], by[cid]["status"], by[cid]["original_attempt"]["status"]),
                             ("thumbnail", "ok", "timeout"))
        self.assertEqual(a.paths(), ["/robots.txt", "/1.png", "/thumbs/1.png", "/2.png"])
        self.assertEqual(c.paths(), ["/robots.txt", "/t2.png"])

    def test_a_file_too_large_or_an_http_error_falls_back(self):
        big = (200, {"Content-Type": "image/png"}, PNG + b"x" * 1000)
        a, c = self.servers({"/1.png": big, "/2.png": big, "/thumbs/1.png": PNG_ANSWER},
                            {"/t3.png": PNG_ANSWER})
        cands = self.two(a, c) + [candidate(3, a.url("/missing.png"), a.url("/p3"), c.url("/t3.png"))]
        by, _ = self.collect_on("too large", config(network={"max_image_bytes": 64}), a, c, cands)
        for cid, first in (("C01", "too_large"), ("C02", "too_large"), ("C03", "http_error")):
            self.assertEqual((by[cid]["what"], by[cid]["status"], by[cid]["original_attempt"]["status"]),
                             ("thumbnail", "ok", first))
        self.assertEqual(a.paths(), ["/robots.txt", "/1.png", "/thumbs/1.png", "/2.png", "/missing.png"])
        self.assertEqual(c.paths(), ["/robots.txt", "/t2.png", "/t3.png"])

    def test_the_address_itself_still_falls_back(self):
        # r5.59, decided at the close: private_address, too_many_redirects and error (a host that cannot be read in
        # one spelling, a redirect to file:) are other reasons: no site said no, the address itself is the trouble, so
        # a thumbnail is tried as before, and its address is checked the same way. B (127.0.0.1 on a port this test
        # does not allow) stands for this machine.
        a, c = self.servers({"/self": moved("/self"), "/self2": moved("/self2"),
                             "/to-file": moved("file:///etc/passwd"), "/thumbs/1.png": PNG_ANSWER,
                             "/thumbs/3.png": PNG_ANSWER},
                            {"/t4.png": PNG_ANSWER, "/t5.png": PNG_ANSWER, "/t6.png": PNG_ANSWER})
        self.b.routes.update({"/y.png": PNG_ANSWER, "/thumb.png": PNG_ANSWER})
        local = "http://127.0.0.1:%d" % self.b.port
        cands = [candidate(1, a.url("/self"), a.url("/p1"), a.url("/thumbs/1.png")),
                 candidate(2, local + "/x.png", local + "/p2", local + "/thumb.png"),
                 candidate(3, a.url("/to-file"), a.url("/p3"), a.url("/thumbs/3.png")),
                 candidate(4, a.url("/self2"), a.url("/p4"), c.url("/t4.png")),
                 candidate(5, local + "/y.png", local + "/p5", c.url("/t5.png")),
                 candidate(6, "http://user@%s/6.png" % a.hostport(), a.url("/p6"), c.url("/t6.png"))]
        by, record = self.collect_on("the address", config(), a, c, cands)
        self.assertEqual([(by[cid]["what"], by[cid]["status"], by[cid]["original_attempt"]["status"])
                          for cid in ("C01", "C02", "C03", "C04", "C05", "C06")],
                         [("thumbnail", "ok", "too_many_redirects"),
                          ("thumbnail", "private_address", "private_address"),
                          ("thumbnail", "ok", "error"), ("thumbnail", "ok", "too_many_redirects"),
                          ("thumbnail", "ok", "private_address"), ("thumbnail", "ok", "error")])
        self.assertFalse(any("thumbnail_not_fetched" in f for f in record["fetched"]))
        self.assertEqual(a.paths(), ["/robots.txt"] + ["/self"] * 6 + ["/thumbs/1.png", "/to-file", "/thumbs/3.png"]
                         + ["/self2"] * 6)
        self.assertEqual(c.paths(), ["/robots.txt", "/t4.png", "/t5.png", "/t6.png"])
        self.assertEqual(self.b.seen, [])  # this machine was asked nothing, for the original or its thumbnail

    def test_no_thumbnail_once_the_request_budget_is_reached(self):
        # r5.59, decided at the close: skipped_max_requests does not fall back; nothing more is asked in this run.
        # One page for all three: A's robots.txt, the page handed to the reader and /1.png are the three requests.
        a, c = self.servers({"/1.png": PNG_ANSWER, "/2.png": PNG_ANSWER, "/3.png": PNG_ANSWER,
                             "/thumbs/2.png": PNG_ANSWER})
        cands = [candidate(1, a.url("/1.png"), a.url("/p")),
                 candidate(2, a.url("/2.png"), a.url("/p"), a.url("/thumbs/2.png")),
                 candidate(3, a.url("/3.png"), a.url("/p"), c.url("/t2.png"))]
        by, record = self.collect_on("budget", config(budgets={"max_requests": 3}), a, c, cands)
        self.assertEqual((by["C01"]["status"], by["C01"]["what"]), ("ok", "original"))
        for cid in ("C02", "C03"):
            self.assertEqual((by[cid]["status"], by[cid]["what"]), ("skipped_max_requests", "original"))
            self.assertIn("(skipped_max_requests): its thumbnail is not fetched either, from this site or another",
                          by[cid]["thumbnail_not_fetched"])
            self.assertNotIn("original_attempt", by[cid])
        self.assertEqual(a.paths(), ["/robots.txt", "/1.png"])
        self.assertEqual(c.seen, [])
        self.assertEqual(record["network"]["requests"], 3)


class PagesTheReaderAnswers(Temp):
    def page(self, status, http_status):
        return lambda pages, cfg: ([{"page_url": p, "status": status, "http_status": http_status, "images": [
            {"src": "https://s.example.org/new.png", "alt": "门", "desc": "", "score": 4, "width": 320}]}
            for p in pages], "stand-in")

    def test_only_a_200_page_is_read(self):
        for code, status in ((403, "refused"), (451, "refused"), (429, "rate_limited"), (404, "failed"),
                             (None, "ok"), (200, "ok")):
            with self.subTest(http_status=code):
                self.tearDown()
                self.setUp()
                net = Net({"https://s.example.org/new.png": image(), "https://s.example.org/a.png": image()})
                result, record, run_, _ = self.collect(config(), net, [candidate(1, "https://s.example.org/a.png",
                                                                                 "https://s.example.org/p")],
                                                       crawl=self.page("ok", code))
                self.assertEqual(record["pages"][0]["status"], status)
                added = [c for c in run_.candidates() if c["image_url"] == "https://s.example.org/new.png"]
                self.assertEqual(bool(added), status == "ok")
                if status in ("refused", "rate_limited"):
                    self.assertNotIn("https://s.example.org/a.png", net.asked)  # the host was asked nothing more
                    self.assertEqual(record["fetched"][0]["status"], status)

    def test_blocked_pages_do_not_take_the_budget(self):
        handed = []

        def reader(pages, cfg):
            handed.extend(pages)
            return no_reader(pages, cfg)

        cfg = config(network={"blocked_hosts": ["blocked.example.org"]}, budgets={"max_pages": 1})
        cands = [candidate(1, "https://img.example.org/1.png", "https://blocked.example.org/a"),
                 candidate(2, "https://img.example.org/2.png", "https://blocked.example.org/b"),
                 candidate(3, "https://img.example.org/3.png", "https://open.example.org/c")]
        result, record, run_, _ = self.collect(cfg, Net({}), cands, crawl=reader)
        self.assertEqual(handed, ["https://open.example.org/c"])
        self.assertEqual([p["status"] for p in record["pages"]], ["blocked", "blocked", "no_images"])


class LazyImages(unittest.TestCase):
    def test_placeholders_fall_back_and_the_rest_are_counted(self):
        collect = vm("collect")
        items = [{"src": "data:image/gif;base64,R0lGOD", "data-src": "/real/1.jpg", "alt": "一"},
                 {"src": "", "data-original": "https://cdn.example.org/2.jpg"},
                 {"src": "data:image/png;base64,xx", "srcset": "/s/3-480.jpg 480w, /s/3-960.jpg 960w"},
                 {"src": "data:image/png;base64,xx"}, {"src": "javascript:void(0)"},
                 {"src": "https://img.example.org/5.jpg", "desc": "图注"}]
        images, dropped = collect.media_images("https://page.example.org/a/b.html", items)
        self.assertEqual([i["src"] for i in images], ["https://page.example.org/real/1.jpg",
                                                      "https://cdn.example.org/2.jpg",
                                                      "https://page.example.org/s/3-960.jpg",
                                                      "https://img.example.org/5.jpg"])
        self.assertEqual([i.get("src_from") for i in images], ["data-src", "data-original", "srcset", None])
        self.assertEqual(dropped, 2)

    def test_srcset_the_way_the_standard_splits_it(self):
        common = vm("common")
        self.assertEqual(common.parse_srcset("https://x.org/a,b.jpg 480w, https://x.org/c.jpg 960w"),
                         [("https://x.org/a,b.jpg", 480, None), ("https://x.org/c.jpg", 960, None)])
        self.assertEqual(common.parse_srcset("a.jpg, b.jpg 2x,c.jpg 1.5x"),
                         [("a.jpg", None, None), ("b.jpg", None, 2.0), ("c.jpg", None, 1.5)])
        self.assertEqual(common.parse_srcset("a.jpg 10q, b.jpg 100w 2x, c.jpg 200w"), [("c.jpg", 200, None)])
        self.assertEqual(common.parse_srcset(",,, a.jpg,,, "), [("a.jpg", None, None)])
        self.assertEqual(common.best_in_srcset("s.jpg 1x, l.jpg 3x, m.jpg 2x"), "l.jpg")
        self.assertEqual(common.best_in_srcset(""), "")


# --- 5. identity and the config --------------------------------------------------------------------------------------

def fake_crawl4ai(received, answer):
    """A stand-in crawl4ai: records what BrowserConfig and CrawlerRunConfig get; every page answers `answer`."""
    module = types.ModuleType("crawl4ai")
    module.__version__ = "stand-in"

    def options(kind):
        class Options:
            def __init__(self, **kwargs):
                received[kind] = kwargs
        return Options

    class Crawler:
        def __init__(self, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return False

        async def arun(self, url, config):
            return answer

    module.AsyncWebCrawler, module.BrowserConfig, module.CrawlerRunConfig = Crawler, options("browser"), options("run")
    module.CacheMode = types.SimpleNamespace(BYPASS="bypass")
    return module


class Identity(Temp):
    def test_the_options_crawl4ai_gets(self):
        collect = vm("collect")
        cfg = config(network={"user_agent": "novel-workshop-visual-materials/1 (me@example.org)"})
        self.assertEqual(collect.browser_options(cfg), {"headless": True, "verbose": False,
                                                        "user_agent": "novel-workshop-visual-materials/1 (me@example.org)"})
        run = collect.run_options(cfg, "bypass")
        self.assertEqual(sorted(run), ["cache_mode", "check_robots_txt", "exclude_external_images", "page_timeout",
                                       "scan_full_page", "verbose", "wait_for_images"])
        self.assertIs(run["check_robots_txt"], True)

    @unittest.skipIf(sys.version_info < (3, 10), "the workshop only runs Crawl4AI on Python 3.10 or newer")
    def test_the_stand_in_browser_gets_the_workshops_name(self):
        received = {}
        answer = types.SimpleNamespace(status_code=403, success=True, html="<html>forbidden</html>", media={"images": [
            {"src": "https://s.example.org/new.png", "alt": "", "desc": "", "score": 1, "width": 400}]})
        net = Net({"https://s.example.org/a.png": image()})
        folder, run_ = run_folder(self.root, [candidate(1, "https://s.example.org/a.png", "https://s.example.org/p")])
        sess, _ = session(config(), net)
        with mock.patch.dict(sys.modules, {"crawl4ai": fake_crawl4ai(received, answer)}):
            vm("collect").run_collect(folder, config(), session=sess)
        self.assertEqual(received["browser"], {"headless": True, "verbose": False, "user_agent": UA})
        self.assertIs(received["run"]["check_robots_txt"], True)
        record = read(folder / "collect.json")
        self.assertEqual((record["pages"][0]["status"], record["pages"][0]["http_status"]), ("refused", 403))
        self.assertEqual(record["fetched"][0]["status"], "refused")
        self.assertNotIn("https://s.example.org/a.png", net.asked)
        self.assertEqual(len(run_.candidates()), 1)  # nothing added from a page that refused

    def run_with_crawl4ai(self, answer, candidates, cfg=None, received=None, net=None):
        received = {} if received is None else received
        net = net or Net({})
        folder, run_ = run_folder(self.root, candidates)
        sess, _ = session(cfg or config(), net)
        with mock.patch.dict(sys.modules, {"crawl4ai": fake_crawl4ai(received, answer)}):
            vm("collect").run_collect(folder, cfg or config(), session=sess)
        return read(folder / "collect.json"), run_, net, sess

    @unittest.skipIf(sys.version_info < (3, 10), "the workshop only runs Crawl4AI on Python 3.10 or newer")
    def test_a_check_page_crawl4ai_calls_a_success(self):
        # r5.59, after the review: status 200 and success, but the HTML is a check page: refused, the host stopped
        answer = types.SimpleNamespace(status_code=200, success=True, media={"images": [
            {"src": "https://s.example.org/new.png", "alt": "", "desc": "", "score": 1, "width": 400}]},
            html="<html><head><title>Just a moment...</title></head><body></body></html>")
        record, run_, net, _ = self.run_with_crawl4ai(answer, [candidate(1, "https://s.example.org/a.png",
                                                                         "https://s.example.org/p")],
                                                      net=Net({"https://s.example.org/a.png": image()}))
        self.assertEqual(record["pages"][0]["status"], "refused")
        self.assertEqual(record["fetched"][0]["status"], "refused")
        self.assertNotIn("https://s.example.org/a.png", net.asked)
        self.assertEqual(len(run_.candidates()), 1)

    @unittest.skipIf(sys.version_info < (3, 10), "the workshop only runs Crawl4AI on Python 3.10 or newer")
    def test_the_placeholders_dropped_are_counted_in_the_page_record(self):
        answer = types.SimpleNamespace(status_code=200, success=True, html="<html></html>", media={"images": [
            {"src": "data:image/gif;base64,R0lGOD", "alt": "占位"},
            {"src": "https://s.example.org/new.png", "alt": "", "desc": "", "score": 1, "width": 400}]})
        record, run_, net, _ = self.run_with_crawl4ai(answer, [candidate(1, "https://s.example.org/a.png",
                                                                         "https://s.example.org/p")])
        self.assertEqual((record["pages"][0]["status"], record["pages"][0]["dropped_images"]), ("ok", 1))

    @unittest.skipIf(sys.version_info < (3, 10), "the workshop only runs Crawl4AI on Python 3.10 or newer")
    def test_where_crawl4ais_browser_ended(self):
        # r5.59, after the review: the redirects Crawl4AI's browser follows itself are not seen before; when the
        # result says where it ended (redirected_url, a field name not checked against an installed Crawl4AI), that
        # address is checked afterwards and nothing from a page that ended where the workshop does not go is used.
        cfg = config(network={"blocked_hosts": ["blk.example.org"]})
        for landed, status in (("http://10.0.0.5/admin", "private_address"), ("https://blk.example.org/p", "blocked"),
                               ("https://s.example.org/private/p", "robots_disallowed")):
            with self.subTest(landed=landed):
                self.tearDown()
                self.setUp()
                answer = types.SimpleNamespace(status_code=200, success=True, html="<p>x</p>", redirected_url=landed,
                                               media={"images": [{"src": "https://s.example.org/new.png", "alt": "门",
                                                                  "desc": "摄影：某人", "score": 4, "width": 400}]})
                net = Net({"https://s.example.org/robots.txt": robots("User-agent: *\nDisallow: /private/\n"),
                           "https://s.example.org/a.png": image()})
                cands = [candidate(1, "https://s.example.org/a.png", "https://s.example.org/p")]
                record, run_, net, _ = self.run_with_crawl4ai(answer, cands, cfg, net=net)
                page = record["pages"][0]
                self.assertEqual((page["status"], page["images"], page["final_url"]), (status, [], landed))
                self.assertEqual([c["image_url"] for c in run_.candidates()], ["https://s.example.org/a.png"])
                self.assertNotIn("on_page", run_.candidates()[0])
        # a page that ended on another host which refused: that host is stopped, the first one is not
        answer = types.SimpleNamespace(status_code=403, success=True, html="<p>no</p>",
                                       redirected_url="https://t.example.org/p", media={"images": []})
        net = Net({"https://s.example.org/a.png": image(), "https://t.example.org/b.png": image()})
        record, run_, net, sess = self.run_with_crawl4ai(answer, [
            candidate(1, "https://s.example.org/a.png", "https://s.example.org/p"),
            candidate(2, "https://t.example.org/b.png", "https://s.example.org/p")], net=net)
        self.assertEqual(record["pages"][0]["status"], "refused")
        self.assertEqual(sorted(sess.record()["hosts_stopped"]), ["t.example.org"])
        by = {f["cid"]: f["status"] for f in record["fetched"]}
        self.assertEqual(by, {"C01": "ok", "C02": "refused"})
        self.assertNotIn("https://t.example.org/b.png", net.asked)

    @unittest.skipIf(sys.version_info < (3, 10), "the workshop only runs Crawl4AI on Python 3.10 or newer")
    def test_the_probes_page_names_no_website(self):
        # r5.59, after the review: doctor --probe's page holds its image as a data: address, so the browser has no
        # website to load it from outside the workshop's checks.
        asked = []
        answer = types.SimpleNamespace(status_code=200, success=True, html="<html></html>", media={"images": [
            {"src": vm("doctor").PROBE_IMAGE, "alt": "probe"}]})
        module = fake_crawl4ai({}, answer)
        real = module.AsyncWebCrawler.arun

        async def arun(crawler, url, config):
            asked.append(url)
            return await real(crawler, url, config)

        module.AsyncWebCrawler.arun = arun
        with mock.patch.dict(sys.modules, {"crawl4ai": module}):
            probe = vm("doctor").probe_crawl4ai(config())
        self.assertEqual(len(asked), 1)
        self.assertTrue(asked[0].startswith("raw:"))
        self.assertNotIn("http", asked[0])
        self.assertIn("data:image/gif;base64,", asked[0])
        self.assertEqual((probe["browser_started"], probe["dropped_images"]), (True, 1))

    def test_what_the_config_refuses(self):
        common = vm("common")
        refused = {
            "工坊不做这件事": [{"network": {"proxy": "http://p:1"}}, {"network": {"impersonate": "chrome"}},
                        {"crawl4ai": {"magic": True}}, {"crawl4ai": {"enable_stealth": True}},
                        {"network": {"cookies": {}}}, {"network": {"Referer": "https://www.google.com/"}},
                        {"crawl4ai": {"solve_cloudflare": True}}, {"proxies": {}}, {"network": {"captcha_key_env": "X"}}],
            "unknown key(s) in config section network": [{"network": {"timeout": 5}}],
            "unknown key(s) in config section budgets": [{"budgets": {"max_request": 5}}],
            "工坊守 robots.txt，这一项不能关": [{"crawl4ai": {"check_robots_txt": False}},
                                    {"crawl4ai": {"check_robots_txt": 0}}],
            "network.user_agent says it is the workshop": [
                {"network": {"user_agent": "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 Chrome/120 Safari/537.36"}},
                {"network": {"user_agent": "novel-workshop-visual-materials/1 (Mozilla/5.0)"}},
                {"network": {"user_agent": "my-bot/1"}}, {"network": {"user_agent": "novel-workshop-visual-materials/"}}],
            "network.min_interval_seconds": [{"network": {"min_interval_seconds": 0.5}},
                                             {"network": {"min_interval_seconds": True}},
                                             # r5.59, after the review: JSON readers take NaN and Infinity, and a NaN
                                             # interval would switch the pacing off
                                             {"network": {"min_interval_seconds": float("nan")}},
                                             {"network": {"min_interval_seconds": float("inf")}},
                                             {"network": {"min_interval_seconds": float("nan"),
                                                          "max_wait_seconds": float("nan")}}],
            "network.max_wait_seconds": [{"network": {"min_interval_seconds": 5, "max_wait_seconds": 2}},
                                         {"network": {"max_wait_seconds": float("nan")}},
                                         {"network": {"max_wait_seconds": float("inf")}}],
            "config section network is an object": [{"network": []}],
            "network.timeout_seconds": [{"network": {"timeout_seconds": float("nan")}},
                                        {"network": {"timeout_seconds": float("-inf")}}],
            # only a contact in brackets: not another crawler's name, not a browser, nothing outside ASCII
            "括号里只能写联系方式": [
                {"network": {"user_agent": "novel-workshop-visual-materials/1 (compatible; Googlebot/2.1; "
                                           "+http://www.google.com/bot.html)"}},
                {"network": {"user_agent": "novel-workshop-visual-materials/1 (+http://www.google.com/bot.html)"}},
                {"network": {"user_agent": "novel-workshop-visual-materials/1 (bingbot@example.org)"}},
                {"network": {"user_agent": "novel-workshop-visual-materials/1 (作者：小林 me@example.org)"}},
                {"network": {"user_agent": "novel-workshop-visual-materials/1 (José)"}},
                {"network": {"user_agent": "novel-workshop-visual-materials/1 (my notes)"}},
                {"network": {"user_agent": "novel-workshop-visual-materials/1 (me@example.org) extra"}}],
            "unknown config section(s) scrapling": [{"scrapling": {}}],
        }
        for words, configs in refused.items():
            for data in configs:
                with self.subTest(config=data):
                    path = write(self.root / "c.json", dict({"schema": common.CONFIG_SCHEMA}, **data))
                    with self.assertRaises(common.VisualError) as caught:
                        common.load_config(path)
                    self.assertIn(words, str(caught.exception))
        for agent in ("novel-workshop-visual-materials/1 (mailto:me@example.org)",
                      "novel-workshop-visual-materials/1 (+https://me.example.org/about; me@example.org)",
                      "novel-workshop-visual-materials/2.0 (https://me.example.org/visual-bot.html)"):
            with self.subTest(accepted=agent):
                loaded = common.load_config(write(self.root / "c.json", {"schema": common.CONFIG_SCHEMA,
                                                                         "network": {"user_agent": agent}}))
                self.assertEqual(loaded["network"]["user_agent"], agent)
                agent.encode("latin-1")  # a request header carries it
        path = write(self.root / "c.json", {"schema": common.CONFIG_SCHEMA, "network": {
            "note": "联系方式写在括号里", "user_agent": "novel-workshop-visual-materials/1.2 (me@example.org)",
            "min_interval_seconds": 2.5, "max_wait_seconds": 60}})
        loaded = common.load_config(path)
        self.assertEqual((loaded["network"]["min_interval_seconds"], loaded["budgets"]["max_requests"]), (2.5, 200))
        example = json.loads((SKILL / "assets" / "visual-materials-config.example.json").read_text(encoding="utf-8"))
        self.assertEqual((example["network"]["min_interval_seconds"], example["network"]["max_wait_seconds"],
                          example["budgets"]["max_requests"]), (1, 30, 200))
        self.assertEqual(common.load_config(write(self.root / "e.json", example))["network"]["user_agent"], UA)

    def test_doctors_probe_is_the_one_place_robots_is_off(self):
        text = (SCRIPTS / "visual_materials" / "doctor.py").read_text(encoding="utf-8")
        self.assertIn("check_robots_txt=False", text)
        self.assertIn("local_probe=True", text)
        for name in ("collect.py", "common.py", "search.py"):
            self.assertNotIn("check_robots_txt=False", (SCRIPTS / "visual_materials" / name).read_text(encoding="utf-8"))


# --- 6. what the page says is kept apart ------------------------------------------------------------------------------

class PageSays(Temp):
    def test_kept_shown_and_never_taken_as_the_licence(self):
        net = Net({"https://s.example.org/a.png": image(PNG + b"a"), "https://s.example.org/b.png": image(PNG + b"b")})

        def reader(pages, cfg):
            return [{"page_url": p, "status": "ok", "http_status": 200,
                     "page_says": {"license_links": ["https://creativecommons.org/licenses/by-sa/4.0/"]},
                     "images": [{"src": "https://s.example.org/a.png", "alt": "柜台", "score": 3, "width": 320,
                                 "desc": "摄影：某某 / CC BY 4.0 https://creativecommons.org/licenses/by/4.0/"},
                                {"src": "https://s.example.org/b.png", "alt": "门", "desc": "", "score": 2, "width": 320,
                                 "page_says": {"caption": "旧铺子的门", "structured": {"creator": "某某"}}}]}
                    for p in pages], "stand-in"

        result, record, run_, _ = self.collect(config(), net, [candidate(1, "https://s.example.org/a.png",
                                                                         "https://s.example.org/p")], crawl=reader)
        first, added = run_.candidates()
        self.assertEqual(first["on_page"]["page_says"], {
            "credit": "摄影：某某 / CC BY 4.0 https://creativecommons.org/licenses/by/4.0/",
            "license_links": ["https://creativecommons.org/licenses/by-sa/4.0/",
                              "https://creativecommons.org/licenses/by/4.0/"], "checked": False})
        self.assertEqual(added["on_page"]["page_says"], {
            "license_links": ["https://creativecommons.org/licenses/by-sa/4.0/"], "caption": "旧铺子的门",
            "structured": {"creator": "某某"}, "checked": False})
        for c in (first, added):
            self.assertEqual((c["creator"], c["license"], c["license_url"]), ("", "", ""))
        cfg = config()
        vm("review").run_bundle(run_.folder, cfg)
        text = (run_.folder / "review" / "review.md").read_text(encoding="utf-8")
        line = next(l for l in text.splitlines() if l.startswith("- 网页上写的署名和授权"))
        self.assertIn("（工坊没有核对，只供你去来源页核）：摄影：某某 / CC BY 4.0", line)
        self.assertIn("- 作者和授权：没写；未核，只作写作参考", text)
        bundle = read(run_.folder / "review" / "bundle.json")
        choice = {"schema": "visual-choice/1", "bundle_id": bundle["bundle_id"],
                  "decision": {"by": "作者", "date": "2026-11-19", "words": "1 和 2 的布局"},
                  "choose": [{"n": n, "take": [{"part": "布局", "scope": "stable"}]} for n in (1, 2)]}
        vm("selection").run_select(run_.folder, cfg, write(self.root / "choice.json", choice))
        selection = read(run_.folder / "selection.json")
        for piece in selection["adopt"]:
            source = piece["entry"]["source"]
            self.assertEqual(source["license"], "未核，只作写作参考")
            self.assertNotIn("creator", source)
            self.assertNotIn("license_url", source)
        self.assertNotIn("page_says", json.dumps(selection, ensure_ascii=False))

    def test_page_words_in_review_md_stay_words(self):
        # r5.59, after the review: what came from the web is written so that a Markdown viewer shows it as text (an
        # image or a link written into a caption is never fetched or followed); a caption that is the credit is shown
        # once; an image added from a page without any words has no empty "网页上的文字" line.
        net = Net({"https://s.example.org/a.png": image(PNG + b"a"), "https://s.example.org/b.png": image(PNG + b"b")})
        pixel = "![t](http://192.168.1.1/pixel.png)"

        def reader(pages, cfg):
            return [{"page_url": p, "status": "ok", "http_status": 200, "images": [
                {"src": "https://s.example.org/a.png", "alt": "柜台 <img src=x>", "score": 3, "width": 320,
                 "desc": "Photo by %s and [x](http://10.0.0.1/)" % pixel,
                 "page_says": {"credit": "摄影：某某 %s" % pixel, "caption": "摄影：某某 %s" % pixel}},
                {"src": "https://s.example.org/b.png", "alt": "", "desc": "", "score": 2, "width": 320,
                 "page_says": {"license_links": ["https://creativecommons.org/licenses/by/4.0/"]}}]}
                for p in pages], "stand-in"

        cands = [candidate(1, "https://s.example.org/a.png", "https://s.example.org/p(1)![x](http://10.0.0.2/y.png)")]
        cands[0]["creator"] = "![c](http://10.0.0.3/c.png)"
        result, record, run_, _ = self.collect(config(), net, cands, crawl=reader)
        vm("review").run_bundle(run_.folder, config())
        text = (run_.folder / "review" / "review.md").read_text(encoding="utf-8")
        images = [l for l in text.splitlines() if "](" in l and not l.startswith("![")]
        self.assertEqual(images, [])  # only the bundle's own image lines remain Markdown images
        self.assertIn("\\!\\[t\\]\\(http://192.168.1.1/pixel.png\\)", text)
        self.assertIn("柜台 \\<img src=x\\>", text)
        self.assertIn("p%281%29%21%5Bx%5D%28http://10.0.0.2/y.png%29", text)
        says = [l for l in text.splitlines() if l.startswith("- 网页上写的署名和授权")]
        self.assertEqual(says[0].count("摄影：某某"), 1)  # the caption is the credit: once
        sections = text.split("\n## ")
        second = next(s for s in sections if "s.example.org/b.png" in s)
        self.assertNotIn("网页上的文字（不是看图所得）", second)
        self.assertIn("授权链接：https://creativecommons.org/licenses/by/4.0/", second)


# --- 8. small fixes and what the documents say ------------------------------------------------------------------------

class Doctor(unittest.TestCase):
    def test_the_summary_says_the_browser_was_not_started(self):
        doctor = vm("doctor")
        with mock.patch.object(doctor, "crawl4ai_status", lambda: (True, "crawl4ai stand-in", "stand-in")):
            report = doctor.run_doctor(config())
        self.assertIn("crawl4ai 只查了能不能导入，浏览器没查（要查加 --probe）", report["summary"])
        self.assertIs(report["components"]["crawl4ai"]["configured"], True)
        with mock.patch.object(doctor, "crawl4ai_status", lambda: (False, "not here", None)):
            report = doctor.run_doctor(config())
        self.assertNotIn("浏览器没查", report["summary"])


class Documents(unittest.TestCase):
    def read(self, name):
        return (SKILL / "references" / name).read_text(encoding="utf-8")

    def test_visual_materials(self):
        text = self.read("visual-materials.md")
        section = text.split("## 不绕过网站防护，图归原作者", 1)[1].split("\n## ", 1)[0]
        for phrase in ("不冒充浏览器，不伪造来路（Referer），不模仿浏览器的 TLS 指纹，不用代理换地址，不登录，不带 cookie",
                       "工坊不绕过网站的防护", "这一条不能关", "不放进正文、封面、插图、宣传物或要分发的文件",
                       "不转发、不上传、不放进要分享的项目档案和仓库，不进商业版"):
            self.assertIn(phrase, section)
        self.assertLess(text.index("## 什么时候用"), text.index("## 不绕过网站防护，图归原作者"))
        self.assertLess(text.index("## 不绕过网站防护，图归原作者"), text.index("## 五个项目各管什么"))
        for phrase in ("（守 robots.txt，不能关；取图也守）", "工坊本身 Python 3.9 就能用；读来源页这一步要 3.10 以上",
                       "| 取图或读页时被跳转到 `blocked_hosts` 里的站点，或者地址指向本机、局域网 | `blocked` / `private_address`",
                       "| robots.txt 不许，或者取不到（服务器出错、超时、站点整个连不上） | `robots_disallowed` / `robots_unreachable`",
                       "| 站点拒绝（401、403、451），或者回的是验证页、验证码 | 页面或图记 `refused`",
                       "| 站点限流（429），或者要求等的时间太长 | `rate_limited` / `host_paused`",
                       "`network.user_agent` 写明是工坊（`novel-workshop-visual-materials/版本`，可以在括号里加你的联系方式）",
                       "`on_page.page_says`", "Scrapling 0.5.1（BSD-3-Clause，版权 Karim shoair）", "没有复制它的代码"):
            self.assertIn(phrase, text)
        self.assertNotIn("默认守 robots.txt", text)

    def test_visual_materials_on_thumbnails(self):
        # r5.59, decided after the visual chain was done: robots.txt not readable this time and a host in
        # blocked_hosts joined robots.txt not allowing and the site refusing; the sentence pinned until then
        # (原图被 robots.txt 挡住或被站点拒绝的，缩略图不论在哪个站点都不取) and the ones that let those two fall back to a
        # thumbnail on another site are gone.
        text = self.read("visual-materials.md")
        for phrase in ("原图因为 robots.txt 不许、robots.txt 这一次取不到、站点拒绝、站点在 `blocked_hosts` 里（跳转以后落到这样的站点"
                       "也算）而取不到的，缩略图不论在同一站点还是别的站点都不取", "`thumbnail_not_fetched`",
                       "限流、要等太久的，同一站点上的缩略图不取，搜索给了别的站点上的缩略图的照样取；取原图本身超时、文件太大这类别的原因照样退到缩略图",
                       # r5.59, decided at the close: a site that cannot be reached at all is robots.txt not readable;
                       # an address that is itself the trouble falls back; the request budget reached does not
                       "原图所在的站点整个连不上（找不到地址、连接被拒、robots.txt 超时或回 5xx）的，先问的 robots.txt 就取不到，"
                       "照“robots.txt 这一次取不到”算，缩略图也不取",
                       "地址指向本机或局域网、跳转超过 5 次、地址读不出确定的写法或跳到不是 http(s) 的地址的，和超时一样照样退到缩略图",
                       "请求数到了 `budgets.max_requests` 的，这一次运行不再发请求，缩略图也不取",
                       "原图地址指向本机、局域网的，有缩略图的照样退到缩略图（缩略图的地址也先查）",
                       "| `error` | 不请求，记下跳到了哪里；原图是这样的，有缩略图的照样退到缩略图 |",
                       "跳转太多的，有缩略图的照样退到缩略图；请求数到了上限的，缩略图也不取；剩下的照实记没取",
                       "（取原图本身超时的也退；原图站点整个连不上的，robots.txt 先就取不到，不退；",
                       "r5.59 交付前按审查补了几处：原图因为 robots.txt 这一次取不到、站点在 `blocked_hosts` 里而取不到的，也不退缩略图"
                       "（网站或作者没有许这张图）；",
                       "原图被 robots.txt 挡住或被站点拒绝的不退缩略图；身份照实",
                       "原图在写进去的主机上的，搜索给的缩略图不论在哪个站点都不取",
                       "不打开、不取；原图在这里的，缩略图不论在哪个站点都不取",
                       "原图跳到 `blocked_hosts` 里的站点的，缩略图不论在哪个站点都不取",
                       "原图是 robots.txt 不许的，或者这一次取不到 robots.txt 的，缩略图不论在同一站点还是别的站点都不取",
                       "原图被拒绝的，缩略图不论在同一站点还是别的站点都不取",
                       "原图因为 robots.txt 不许或取不到、站点拒绝、站点在 `blocked_hosts` 里而取不到的不退"):
            self.assertIn(phrase, text)
        for gone in ("原图被 robots.txt 挡住或被站点拒绝的，缩略图不论在哪个站点都不取",
                     "限流、要等太久、robots.txt 这一次取不到、站点在 `blocked_hosts` 里的",
                     "robots.txt 只是这一次取不到的，搜索给了别的站点上的缩略图的照样取",
                     "图床、CDN、搜索服务给的缩略图", "图床、搜索服务的缩略图", "原图被 robots.txt 挡住或被站点拒绝的不退）",
                     # r5.59, decided at the close: the history no longer files the two the coordinator added under
                     # the author's decision; a timeout falls back only when it is the original's own
                     "交付前照同一个意思补上", "（超时的也退；", "；超时、文件太大这类别的原因照样退到缩略图"):
            self.assertNotIn(gone, text)

    def test_visual_materials_says_only_what_the_code_does(self):
        # r5.59, after the review: the sentences say how far each rule reaches (the workshop's own requests, not what
        # Crawl4AI's browser does by itself; collect, not search; the host written in blocked_hosts, not its images on
        # other hosts) and what the records really say.
        text = self.read("visual-materials.md")
        for phrase in ("工坊自己发的请求（问 robots.txt、自带读页读页面、取图）只用普通请求读公开的页面和图",
                       "用 Crawl4AI 读页时，是它的浏览器在请求", "这是 collect 读页和取图的规矩", "停的是拒绝的那个站点",
                       "四种都许才取，所以不论装的是 Python 3.9 还是 3.13，结果一样", "`Disallow: /` 加 `Allow: /gallery/`",
                       "它只管写进去的主机和它的子域名", "百分号编码、全角字母、用“。”分隔的写法都算同一个主机",
                       "它的浏览器自己发的请求不在内", "search 这一步不按站点间隔", "`NaN`、`Infinity` 拒收",
                       "括号里只写邮箱地址或网址，只用英文字母、数字和常见符号",
                       "交给 Crawl4AI 的页面，工坊只在交出去以前查一次地址、问一次 robots.txt、等一次间隔，它的浏览器自己跟的跳转、"
                       "页面里加载的图和脚本，工坊管不到，没验证",
                       "没读到的页面记 `not_read`（某一页自己读出错的记 `error`）",
                       "collect 仍记 ok，看 `pages` 里各页的状态",
                       "同一站点上的缩略图不取，搜索给了别的站点上的缩略图的照样取",
                       "网页上写的署名、图注和授权链接另记在候选的 `on_page.page_says`",
                       "图注（图注里写的署名也在内）照旧也算网页上的文字（`page_text`），入库时不当作者和授权",
                       "Crawl4AI 读页时浏览器自己跟的跳转不在此列", "`network.address_notes`",
                       "跳转超过 5 次（跳回同一地址的循环也算）", "跳转到 `file:`、`data:` 这类不是 http(s) 的地址 | `error`"):
            self.assertIn(phrase, text)
        for gone in ("交给读页方（Crawl4AI 或自带读页）的页面和要取的图，先查地址（跳转的每一跳也查）",
                     "网页上写的署名、图注和授权链接只记在", "中途停了的页面 `error`，collect 记 partial",
                     "不换地址再试；要看这张图", "不加快，也不换别的地址去取", "工坊就不打开它的页面，也不取它的图。"):
            self.assertNotIn(gone, text)

    def test_the_library_and_the_cover(self):
        self.assertIn("（读来源页和取图都守 robots.txt）", self.read("inspiration-library.md"))
        self.assertNotIn("读来源页时默认守 robots.txt", self.read("inspiration-library.md"))
        cover = self.read("cover-design.md")
        # r5.59, after the review: the same as visual-materials.md (要那样用，得另外取得权利人的授权): a licence the
        # source page shows is not checked by the workshop, so it is not enough on its own
        sentence = ("从视觉素材链路找来的网上图片，只能当构图参考或色彩参考，不能当编辑对象；要当编辑对象，得另外取得权利人的授权"
                    "（来源页上写的授权工坊没有核对，见 [视觉素材](visual-materials.md)“不绕过网站防护，图归原作者”）。")
        self.assertIn(sentence, cover)
        self.assertNotIn("除非来源页的授权允许改作", cover)
        self.assertIn("要那样用，得另外取得权利人的授权", self.read("visual-materials.md"))
        self.assertLess(cover.index("参考图用途：编辑对象／构图参考／色彩参考，按实际填写"), cover.index(sentence))


if __name__ == "__main__":
    unittest.main()

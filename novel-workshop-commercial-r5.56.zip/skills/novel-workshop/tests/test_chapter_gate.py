"""Chapter confirmation behavior; all chapters and author evidence are synthetic."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import chapter_gate as gate
import learning_loop as loop
import project_state


def sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


# Words that are not a whole-sentence acceptance of the current version. Each
# one is sent together with decision:accept_final_version and must stay pending.
PENDING_FINAL_WORDS = (
    # only moving on
    "继续", "继续吧。", " 继续写！ ", "继续下一章。", "请接着写。", "进入下一步。", "我先看看。",
    # postponed
    "还没到定稿的时候。", "没定稿呢，再等等。", "定稿先放一放。", "等我明天看完再定稿。",
    "离定稿还早，先放着。", "定稿前再给我看一遍。", "定稿前我还要改第三场。", "等教师看过再采纳。",
    "我明天再决定要不要定稿。", "暂不定稿，继续改。", "先别封稿，等我再看一遍。",
    # conditional
    "如果第三场改完就定稿。", "如果老师也同意就采用。", "没问题就定稿。",
    # questioning, with or without a question mark
    "什么时候能定稿？", "这版可以定稿吗？", "这一版能定稿吗", "定稿？再等等。", "定稿吧？", "可以定稿了吧",
    # negated
    "这一版我采纳不了。", "这稿没法采用。", "采纳是不可能的。", "采纳个鬼。", "不采纳。", "先别定稿。",
    "不可以定稿。", "我不是不采纳，再想想。",
    # another version, or only part of this one
    "采用上一版的开头。", "采纳教师第三条，其余再改一轮。", "就用老师改的那版。", "上一版定稿。",
    "第二场那句对白，保留这一版。", "这版采用的词太书面了，再改。",
    # a reservation after the acceptance, reported speech, hedged, or no acceptance at all
    "定稿，但第三场结尾再看一下。", "老师说可以定稿，我再想想。", "应该可以定稿了。", "好。", "可以。",
    "不用改了。",
)

# Plain acceptances, including ones that open with "no more changes".
ACCEPTING_FINAL_WORDS = (
    "定稿。", "采纳当前稿。", "明确采纳当前候选稿。", "这一章，封稿，开始下一章", "不用改了，定稿",
    "别改了，就用这版", "不必再改，采纳", "不错，定稿。", "好，定稿吧。", "可以定稿了。",
    "我确认采纳这一版。", "这版定稿", "就用这一版吧", "没问题，采用当前修订稿。", "OK，定稿！", "定稿，谢谢。",
)


class ChapterGateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "state.json"
        self.serial = 0
        project_state.init_state(self.path, "book", {
            "characters": {}, "settings": {}, "chapters": {},
            "demonstration_learning": {"enabled": False, "loop_enabled": False}})

    def payload(self):
        return loop.read_store(self.path)[0]

    def event(self, action, stage, chapter="c1", **fields):
        self.serial += 1
        return {"event_id": "gate-" + str(self.serial), "op": "chapter_gate",
                "chapter_id": chapter, "action": action, "stage": stage, **fields}

    def send(self, event, version=None):
        return loop.apply_event(self.path, event, "book",
                                version or loop.read_store(self.path)[1])

    def rejected(self, event, version=None):
        before = self.path.read_bytes()
        with self.assertRaises(loop.LoopError) as caught:
            self.send(event, version)
        self.assertEqual(self.path.read_bytes(), before)
        return caught.exception

    def present(self, stage, chapter="c1", **fields):
        """Present a stage the way a host does: with what the chapter's policy asks for.

        Tests about a missing image record or a missing teacher return build
        their events with self.event() instead.
        """
        values = {"content": "合成成果：" + stage, "source_ref": "fixture://" + stage}
        if stage in {"draft", "revision", "final"}:
            values["artifact_sha256"] = sha("合成候选稿")
        if stage == "preparation":
            values["visual_evidence"] = self.visual_evidence()
        if stage == "review" and "teacher_return_id" not in fields:
            state = gate.status(self.payload(), chapter)
            if state["next_action"] == "teacher_return":
                draft = {"chapter_id": chapter, **state["last_valid_confirmation"]}
                values["teacher_return_id"] = self.send(self.teacher_return_event(draft))["teacher_return_id"]
            elif state.get("valid_teacher_returns"):
                values["teacher_return_id"] = state["valid_teacher_returns"][-1]["teacher_return_id"]
        return self.send(self.event("present", stage, chapter, **{**values, **fields}))

    def bare(self, stage, chapter="c1", **fields):
        """A presentation with no image record and no teacher return."""
        return self.event("present", stage, chapter, **{"content": "合成成果（无附件）：" + stage,
                                                        "source_ref": "fixture://bare-" + stage, **fields})

    def confirmation(self, presented, **fields):
        # One author message confirms one presentation, so each synthetic reply
        # names its own source (r5.55: the same words from the same source are
        # refused for a second stage of the chapter).
        values = {"presentation_id": presented["presentation_id"],
                  "presentation_version": presented["presentation_version"],
                  "actor_role": "author", "mode": "human", "author_quote": "本阶段成立，继续。",
                  "source_ref": "fixture://synthetic-author/" + presented["presentation_id"]}
        if presented["current_stage"] == "final":
            values.update(decision="accept_final_version", author_quote="明确采纳当前候选稿。")
        return self.event("confirm", presented["current_stage"], presented["chapter_id"],
                          **{**values, **fields})

    def advance_until(self, target, chapter="c1"):
        for stage in gate.STAGES:
            if stage == target:
                return
            self.send(self.confirmation(self.present(stage, chapter)))

    def finish_chapter(self, chapter="c1"):
        for stage in gate.STAGES:
            result = self.send(self.confirmation(self.present(stage, chapter)))
        return result

    def configure_policy(self, **fields):
        event = self.event("configure", None, visual_required=True, teacher_handoff="user_return",
                           actor_role="author", mode="human", author_quote="每章看图后由我交教师。",
                           source_ref="fixture://workflow-choice")
        event.pop("chapter_id")
        event.pop("stage")
        return self.send({**event, **fields})

    def policy_off(self, **fields):
        """The author's recorded choice against both, for the whole project."""
        return self.configure_policy(**{"visual_required": False, "teacher_handoff": "host",
                                        "author_quote": "这本书不看图，也不交教师。", **fields})

    def chapter_policy(self, chapter="c1", **fields):
        event = self.event("chapter_policy", None, chapter, **{
            "actor_role": "author", "mode": "human", "author_quote": "这一章不看图。",
            "source_ref": "fixture://chapter-choice", **fields})
        event.pop("stage")
        return event

    def visual_evidence(self, mode="author_images"):
        evidence = {"mode": mode, "source_refs": ["fixture://chapter-images"],
                    "observation_ref": "fixture://image-observation",
                    "selection_ref": "fixture://author-selection"}
        if mode == "pipeline_run":
            evidence.update(run_ref="fixture://visual-run", verification_ref="fixture://run-verification")
        if mode == "reuse":
            evidence.update(reuse_author_quote="本章复用这组图。", reuse_source_ref="fixture://reuse-choice")
        return evidence

    def prepare_policy_draft(self, chapter="c1"):
        self.advance_until("preparation", chapter)
        self.send(self.confirmation(self.present("preparation", chapter,
                                                visual_evidence=self.visual_evidence())))
        draft = self.present("draft", chapter)
        self.send(self.confirmation(draft))
        return draft

    def teacher_return_event(self, draft, **fields):
        event = self.event("teacher_return", None, draft["chapter_id"],
                           draft_presentation_id=draft["presentation_id"],
                           draft_presentation_version=draft["presentation_version"],
                           draft_sha256=draft["artifact_sha256"],
                           returned_text="教师原文：保留开场。\n第二场需补动机。",
                           source_ref="fixture://author-return", teacher_name="unknown")
        event.pop("stage")
        return {**event, **fields}

    def policy_now(self, chapter="c1"):
        policy = gate.status(self.payload(), chapter)["workflow_policy"]
        return policy["visual_required"], policy["teacher_handoff"], policy["basis"]

    def status_cli(self, *flags, path=None, chapter="c1"):
        return subprocess.run([sys.executable, *flags, str(ROOT / "scripts/chapter_gate.py"), "status",
                               str(path or self.path), "--chapter-id", chapter],
                              capture_output=True, text=True, encoding="utf-8")

    def markdown_store(self, prefix="# 合成记录\n保留说明。\n", suffix="\n末尾手写说明。\n"):
        self.path = Path(self.temp.name) / "learning.md"
        payload = {"schema_version": 1, "project_id": "book", "revision": 0, "data": {}}
        self.path.write_text(prefix + "<!-- NOVEL_WORKSHOP_LEARNING_START -->\n```json\n" +
                             json.dumps(payload) + "\n```\n<!-- NOVEL_WORKSHOP_LEARNING_END -->" + suffix,
                             encoding="utf-8")

    def test_workflow_policy_requires_author_evidence_and_creates_no_chapter(self):
        for fields in ({"actor_role": "teacher"}, {"mode": "independent_agent"},
                       {"author_quote": " "}, {"source_ref": ""},
                       {"visual_required": "true"}, {"teacher_handoff": "automatic"}):
            with self.subTest(fields=fields):
                with self.assertRaises(loop.LoopError):
                    self.configure_policy(**fields)
        result = self.configure_policy()
        data = self.payload()["data"]
        self.assertEqual(data["chapter_workflow_policy"]["author_quote"], "每章看图后由我交教师。")
        self.assertTrue(data["chapter_workflow_policy"]["visual_required"])
        self.assertNotIn("chapter_confirmations", data)
        self.assertEqual(result["next_action"], "present")
        malformed = self.payload()
        malformed["data"]["chapter_workflow_policy"] = []
        with self.assertRaises(loop.LoopError):
            loop._validate(malformed)

    def test_without_a_recorded_policy_images_and_author_teacher_handoff_are_on(self):
        waiting = gate.status(self.payload(), "c1")["workflow_policy"]
        self.assertEqual((waiting["visual_required"], waiting["teacher_handoff"], waiting["basis"], waiting["frozen"]),
                         (True, "user_return", "default", False))
        self.advance_until("preparation")
        no_images = self.rejected(self.bare("preparation"))
        self.send(self.confirmation(self.present("preparation")))
        confirmed = self.send(self.confirmation(self.present("draft")))
        self.assertEqual((confirmed["chapter_status"], confirmed["next_action"], confirmed["current_stage"]),
                         ("await_teacher_return", "teacher_return", "review"))
        no_teacher = self.rejected(self.bare("review"))
        # Each refusal names the policy behind it and where the author's "not this chapter" is recorded.
        for refusal, field in ((no_images, "visual_required"), (no_teacher, "teacher_handoff")):
            self.assertIn(field, str(refusal))
            self.assertIn("chapter_policy", str(refusal))
        policy = gate.status(self.payload(), "c1")["workflow_policy"]
        self.assertEqual((policy["visual_required"], policy["teacher_handoff"], policy["basis"], policy["frozen"]),
                         (True, "user_return", "default", True))
        self.assertNotIn("author_quote", policy)  # nobody said it: this is the default, and status says so
        self.assertEqual(confirmed["workflow_policy"], policy)  # every result names the policy in force
        self.assertNotIn("chapter_workflow_policy", self.payload()["data"])

    def test_a_recorded_author_choice_against_both_is_followed_and_shown(self):
        self.policy_off()
        waiting = gate.status(self.payload(), "c1")["workflow_policy"]
        self.assertEqual((waiting["visual_required"], waiting["teacher_handoff"], waiting["basis"], waiting["frozen"]),
                         (False, "host", "project", False))
        self.advance_until("preparation")
        self.send(self.confirmation(self.send(self.bare("preparation"))))
        confirmed = self.send(self.confirmation(self.present("draft")))
        self.assertEqual((confirmed["chapter_status"], confirmed["next_action"]), ("awaiting_presentation", "present"))
        self.send(self.bare("review"))
        policy = gate.status(self.payload(), "c1")["workflow_policy"]
        self.assertEqual((policy["visual_required"], policy["teacher_handoff"], policy["basis"], policy["frozen"]),
                         (False, "host", "project", True))
        self.assertEqual(policy["author_quote"], "这本书不看图，也不交教师。")
        self.assertEqual(policy["source_ref"], "fixture://workflow-choice")

    def test_visual_required_rejects_missing_or_incomplete_evidence(self):
        self.configure_policy()
        self.advance_until("preparation")
        self.rejected(self.event("present", "preparation", content="无需视觉", source_ref="fixture://skip"))
        for field in ("mode", "source_refs", "observation_ref", "selection_ref"):
            evidence = self.visual_evidence()
            evidence.pop(field)
            with self.subTest(field=field):
                self.rejected(self.event("present", "preparation", content="合成准备", source_ref="fixture://prep",
                                         visual_evidence=evidence))
        for sources in ([], "fixture://one", [" "]):
            evidence = {**self.visual_evidence(), "source_refs": sources}
            self.rejected(self.event("present", "preparation", content="合成准备", source_ref="fixture://prep",
                                     visual_evidence=evidence))
        self.assertEqual(gate.status(self.payload(), "c1")["current_stage"], "preparation")

    def test_visual_modes_require_their_own_evidence_and_bind_versions(self):
        self.configure_policy()
        self.advance_until("preparation")
        for mode, extra_fields in (("pipeline_run", ("run_ref", "verification_ref")),
                                   ("author_images", ()),
                                   ("reuse", ("reuse_author_quote", "reuse_source_ref"))):
            evidence = self.visual_evidence(mode)
            for field in extra_fields:
                incomplete = {key: value for key, value in evidence.items() if key != field}
                with self.subTest(mode=mode, missing=field):
                    self.rejected(self.event("present", "preparation", content="合成准备", source_ref="fixture://prep",
                                             visual_evidence=incomplete))
            presented = self.present("preparation", visual_evidence=evidence)
            record = self.payload()["data"]["chapter_confirmations"]["c1"]["history"][-1]
            self.assertEqual(record["visual_evidence"], evidence)
            changed = {**evidence, "selection_ref": "fixture://new-selection"}
            next_presented = self.present("preparation", visual_evidence=changed)
            self.assertNotEqual(presented["presentation_version"], next_presented["presentation_version"])

    def test_confirmed_draft_waits_for_teacher_and_blocks_review(self):
        self.configure_policy()
        draft = self.prepare_policy_draft()
        state = gate.status(self.payload(), "c1")
        self.assertEqual((state["chapter_status"], state["next_action"], state["current_stage"]),
                         ("await_teacher_return", "teacher_return", "review"))
        self.assertEqual(state["last_valid_confirmation"]["presentation_id"], draft["presentation_id"])
        self.rejected(self.event("present", "review", content="尚无教师返回", source_ref="fixture://review"))

    def test_teacher_return_keeps_original_text_and_does_not_confirm_any_stage(self):
        self.configure_policy()
        draft = self.prepare_policy_draft()
        original = "教师逐字意见：\n  保留这个空格。\n\n第二段待议。\n"
        before = copy.deepcopy(self.payload()["data"]["chapter_confirmations"]["c1"]["history"])
        event = self.teacher_return_event(draft, returned_text=original)
        result = self.send(event)
        chapter = self.payload()["data"]["chapter_confirmations"]["c1"]
        returned = chapter["teacher_returns"][0]
        self.assertEqual(returned["returned_text"], original)
        self.assertEqual(returned["returned_sha256"], sha(original))
        self.assertEqual(returned["event_id"], event["event_id"])
        self.assertEqual(returned["source_ref"], event["source_ref"])
        self.assertEqual(returned["teacher_name"], "unknown")
        self.assertEqual(chapter["history"], before)
        self.assertEqual((result["current_stage"], result["next_action"]), ("review", "present"))
        self.assertEqual(result["teacher_return_id"], event["event_id"])
        self.assertEqual(result["returned_sha256"], sha(original))
        resumed = gate.status(self.payload(), "c1")
        self.assertEqual(resumed["valid_teacher_returns"][0]["teacher_return_id"], event["event_id"])
        self.assertEqual(resumed["valid_teacher_returns"][0]["returned_sha256"], sha(original))
        self.assertNotIn("AUTHOR", self.payload()["data"])

    def test_teacher_return_requires_waiting_review_and_complete_current_draft_binding(self):
        self.configure_policy()
        scope = self.present("scope")
        early = self.rejected(self.teacher_return_event(scope, draft_sha256=sha("合成候选稿")))
        self.assertIn("review", str(early))
        self.assertNotIn("host", str(early))  # the policy allows it; only the moment is wrong
        draft = self.prepare_policy_draft()
        for fields in ({"draft_presentation_id": "old-instance"},
                       {"draft_presentation_version": sha("old-version")},
                       {"draft_sha256": sha("old-draft")}, {"draft_sha256": 12345}, {"chapter_id": "c2"},
                       {"returned_text": " "}, {"source_ref": ""}, {"teacher_name": ""}):
            with self.subTest(fields=fields):
                self.rejected(self.teacher_return_event(draft, **fields))
        returned = self.send(self.teacher_return_event(draft))
        review = self.present("review", teacher_return_id=returned["teacher_return_id"])
        self.rejected(self.teacher_return_event(draft))
        self.send(self.confirmation(review))
        self.rejected(self.teacher_return_event(draft))

    def test_teacher_return_accepts_the_draft_hash_in_upper_case(self):
        # The draft presentation already accepts either case and stores lower case.
        draft = self.prepare_policy_draft()
        self.send(self.teacher_return_event(draft, draft_sha256=draft["artifact_sha256"].upper()))
        stored = self.payload()["data"]["chapter_confirmations"]["c1"]["teacher_returns"][0]
        self.assertEqual(stored["draft_sha256"], draft["artifact_sha256"])
        self.assertEqual(draft["artifact_sha256"], draft["artifact_sha256"].lower())

    def test_teacher_return_refused_by_policy_says_so_and_names_the_way_out(self):
        self.policy_off()
        self.advance_until("draft")
        draft = self.present("draft")
        self.send(self.confirmation(draft))
        refused = self.rejected(self.teacher_return_event(draft))
        self.assertEqual(refused.code, "invalid_transition")
        for part in ("teacher_handoff", "host", "chapter_policy"):
            self.assertIn(part, str(refused))
        self.send(self.chapter_policy(teacher_handoff="user_return", author_quote="这一章的初稿我交给教师了。"))
        returned = self.send(self.teacher_return_event(draft))
        self.present("review", teacher_return_id=returned["teacher_return_id"])

    def test_review_binds_specific_teacher_return_and_its_text_hash(self):
        self.configure_policy()
        draft = self.prepare_policy_draft()
        first = self.send(self.teacher_return_event(draft, returned_text="第一份教师意见"))
        second = self.send(self.teacher_return_event(draft, returned_text="第二份教师意见"))
        self.rejected(self.event("present", "review", content="未指回传", source_ref="fixture://review"))
        self.rejected(self.event("present", "review", content="错指回传", source_ref="fixture://review",
                                 teacher_return_id="missing"))
        review = self.present("review", teacher_return_id=first["teacher_return_id"])
        record = self.payload()["data"]["chapter_confirmations"]["c1"]["history"][-1]
        self.assertEqual(record["teacher_return_id"], first["teacher_return_id"])
        self.assertEqual(record["returned_sha256"], sha("第一份教师意见"))
        resumed = gate.status(self.payload(), "c1")
        self.assertEqual(resumed["teacher_return_id"], first["teacher_return_id"])
        self.assertEqual(resumed["returned_sha256"], sha("第一份教师意见"))
        self.assertEqual(len(resumed["valid_teacher_returns"]), 2)
        changed = self.present("review", teacher_return_id=second["teacher_return_id"])
        self.assertNotEqual(review["presentation_version"], changed["presentation_version"])
        self.send(self.confirmation(changed))
        self.assertEqual(gate.status(self.payload(), "c1")["current_stage"], "revision")

    def test_reopened_same_text_draft_cannot_reuse_old_teacher_return(self):
        self.configure_policy()
        draft = self.prepare_policy_draft()
        event = self.teacher_return_event(draft)
        returned = self.send(event)
        self.send(self.event("reopen", "draft", reason="重新交初稿", author_quote="重开初稿。",
                             source_ref="fixture://reopen-draft"))
        replacement = self.present("draft")
        self.assertEqual(replacement["presentation_version"], draft["presentation_version"])
        self.assertNotEqual(replacement["presentation_id"], draft["presentation_id"])
        self.send(self.confirmation(replacement))
        self.assertEqual(gate.status(self.payload(), "c1")["next_action"], "teacher_return")
        self.assertNotIn("valid_teacher_returns", gate.status(self.payload(), "c1"))
        self.rejected(self.teacher_return_event(draft))
        self.rejected(self.event("present", "review", content="旧教师意见", source_ref="fixture://review",
                                 teacher_return_id=returned["teacher_return_id"]))
        self.assertEqual(self.payload()["data"]["chapter_confirmations"]["c1"]["teacher_returns"][0]["event_id"],
                         event["event_id"])
        fresh = self.send(self.teacher_return_event(replacement))
        self.assertNotIn("same_text_as_return_for_other_draft", fresh)  # the draft text did not change
        self.present("review", teacher_return_id=fresh["teacher_return_id"])

    def test_same_teacher_text_recorded_again_for_a_changed_draft_is_marked_not_blocked(self):
        self.advance_until("draft")
        first = self.present("draft", artifact_sha256=sha("初稿一"))
        self.send(self.confirmation(first))
        old = self.send(self.teacher_return_event(first))
        self.assertNotIn("same_text_as_return_for_other_draft", old)
        self.send(self.event("reopen", "draft", reason="换了初稿", author_quote="初稿重交。",
                             source_ref="fixture://reopen-draft"))
        second = self.present("draft", artifact_sha256=sha("初稿二"))
        self.send(self.confirmation(second))
        again = self.send(self.teacher_return_event(second))
        self.assertEqual(again["same_text_as_return_for_other_draft"], [old["teacher_return_id"]])
        state = gate.status(self.payload(), "c1")
        self.assertEqual(state["valid_teacher_returns"][0]["same_text_as_return_for_other_draft"],
                         [old["teacher_return_id"]])
        self.present("review", teacher_return_id=again["teacher_return_id"])

    def test_policy_changes_only_apply_to_chapters_first_presented_after_configuration(self):
        # r5.55 rule change: a chapter first presented with no recorded policy
        # freezes both as on (it used to freeze both as off). "early" therefore
        # now needs its image record; "off" keeps the case of a chapter frozen
        # as off that a later project-wide configure does not move.
        self.send(self.confirmation(self.present("scope", "early")))
        self.policy_off()
        self.send(self.confirmation(self.present("scope", "off")))
        self.configure_policy()
        self.send(self.confirmation(self.present("scope", "frozen")))
        self.send(self.confirmation(self.present("outline", "early")))
        self.rejected(self.bare("preparation", "early"))
        self.send(self.confirmation(self.present("outline", "off")))
        self.send(self.bare("preparation", "off"))
        self.configure_policy(visual_required=False, teacher_handoff="host", author_quote="以后由宿主审核。")
        self.send(self.confirmation(self.present("outline", "frozen")))
        self.rejected(self.event("present", "preparation", "frozen", content="缺视觉", source_ref="fixture://prep"))
        self.prepare_policy_draft("new-host")
        self.send(self.bare("review", "new-host"))
        chapters = self.payload()["data"]["chapter_confirmations"]
        self.assertTrue(chapters["early"]["workflow_policy"]["visual_required"])
        self.assertFalse(chapters["off"]["workflow_policy"]["visual_required"])
        self.assertTrue(chapters["frozen"]["workflow_policy"]["visual_required"])
        self.assertEqual(chapters["new-host"]["workflow_policy"]["teacher_handoff"], "host")

    def test_author_can_drop_images_or_the_teacher_for_one_started_chapter(self):
        self.advance_until("preparation")
        self.advance_until("preparation", "c2")
        changed = self.send(self.chapter_policy(visual_required=False, author_quote="这一章不看图。"))
        self.assertEqual((changed["current_stage"], changed["next_action"]), ("preparation", "present"))
        policy = changed["workflow_policy"]
        self.assertEqual((policy["visual_required"], policy["teacher_handoff"], policy["basis"]),
                         (False, "user_return", "chapter"))
        self.assertNotIn("author_quote", policy)  # results name the policy; status also quotes the author
        shown = gate.status(self.payload(), "c1")["workflow_policy"]
        self.assertEqual((shown["author_quote"], shown["source_ref"], shown["event_id"]),
                         ("这一章不看图。", "fixture://chapter-choice", policy["event_id"]))
        self.send(self.confirmation(self.send(self.bare("preparation"))))
        self.assertEqual(self.send(self.confirmation(self.present("draft")))["next_action"], "teacher_return")
        waived = self.send(self.chapter_policy(teacher_handoff="host", author_quote="这一章不交教师。",
                                               source_ref="fixture://chapter-choice-2"))
        self.assertEqual((waived["chapter_status"], waived["next_action"]), ("awaiting_presentation", "present"))
        self.send(self.confirmation(self.send(self.bare("review"))))
        self.assertEqual(self.policy_now(), (False, "host", "chapter"))
        # Only this chapter: the next one and the project keep what they had.
        self.assertEqual(self.policy_now("c2"), (True, "user_return", "default"))
        self.rejected(self.bare("preparation", "c2"))
        self.assertNotIn("chapter_workflow_policy", self.payload()["data"])
        chapter = self.payload()["data"]["chapter_confirmations"]["c1"]
        self.assertEqual([item["author_quote"] for item in chapter["policy_changes"]],
                         ["这一章不看图。", "这一章不交教师。"])
        self.assertEqual(chapter["workflow_policy"], {"visual_required": True, "teacher_handoff": "user_return"})

    def test_author_can_turn_both_on_for_a_chapter_that_started_without_them(self):
        self.policy_off()
        self.advance_until("preparation")
        self.configure_policy()  # project-wide: only for chapters that start later
        self.send(self.event("reopen", "scope", reason="从头重走", author_quote="从范围重新来。",
                             source_ref="fixture://reopen-scope"))
        self.advance_until("preparation")
        self.assertEqual(self.policy_now(), (False, "host", "project"))  # reopening does not move it either
        self.send(self.chapter_policy(visual_required=True, teacher_handoff="user_return",
                                      author_quote="这一章也看图，初稿我交教师。"))
        self.assertEqual(self.policy_now(), (True, "user_return", "chapter"))
        self.rejected(self.bare("preparation"))
        self.send(self.confirmation(self.present("preparation")))
        self.assertEqual(self.send(self.confirmation(self.present("draft")))["next_action"], "teacher_return")
        self.assertEqual(list(self.payload()["data"]["chapter_confirmations"]), ["c1"])  # same chapter id

    def test_tightening_withdraws_a_pending_presentation_but_never_undoes_a_confirmed_stage(self):
        self.policy_off()
        self.advance_until("preparation")
        pending = self.send(self.bare("preparation"))
        changed = self.send(self.chapter_policy(visual_required=True, author_quote="这一章还是看图。"))
        self.assertEqual((changed["current_stage"], changed["next_action"]), ("preparation", "present"))
        self.assertEqual(changed["withdrawn_presentation_ids"], [pending["presentation_id"]])
        self.rejected(self.confirmation(pending))
        self.rejected(self.bare("preparation"))
        self.send(self.confirmation(self.present("preparation")))
        # A stage the author already confirmed: reopen it first, with the author's words.
        self.advance_until("preparation", "c2")
        self.send(self.confirmation(self.send(self.bare("preparation", "c2"))))
        again = {"visual_required": True, "author_quote": "第二章也还是看图。", "source_ref": "fixture://chapter-choice-c2"}
        refused = self.rejected(self.chapter_policy("c2", **again))
        self.assertIn("reopen preparation", str(refused))
        self.assertEqual(self.policy_now("c2"), (False, "host", "project"))
        self.send(self.event("reopen", "preparation", "c2", reason="作者要看图", author_quote="准备阶段重来。",
                             source_ref="fixture://reopen-prep"))
        self.send(self.chapter_policy("c2", **again))
        self.rejected(self.bare("preparation", "c2"))
        self.send(self.confirmation(self.present("preparation", "c2")))

    def test_teacher_handoff_turned_on_late_needs_review_reopened_or_withdraws_a_pending_one(self):
        self.policy_off()
        self.advance_until("revision")  # review confirmed with no teacher return
        words = {"teacher_handoff": "user_return", "author_quote": "这一章还是交教师。"}
        refused = self.rejected(self.chapter_policy(**words))
        self.assertIn("reopen review", str(refused))
        self.send(self.event("reopen", "review", reason="作者要交教师", author_quote="审稿这一步重来。",
                             source_ref="fixture://reopen-review"))
        changed = self.send(self.chapter_policy(**words))
        self.assertEqual((changed["chapter_status"], changed["next_action"]), ("await_teacher_return", "teacher_return"))
        self.advance_until("review", "c2")
        pending = self.send(self.bare("review", "c2"))
        withdrawn = self.send(self.chapter_policy("c2", **words, source_ref="fixture://chapter-choice-c2"))
        self.assertEqual(withdrawn["withdrawn_presentation_ids"], [pending["presentation_id"]])
        self.assertEqual((withdrawn["chapter_status"], withdrawn["next_action"]), ("await_teacher_return", "teacher_return"))
        self.rejected(self.confirmation(pending))
        self.send(self.confirmation(self.present("review", "c2")))  # the helper records a teacher return first

    def test_chapter_policy_needs_author_words_and_a_stated_choice(self):
        self.present("scope")
        for fields in ({"actor_role": "teacher"}, {"mode": "independent_agent"}, {"author_quote": " "},
                       {"source_ref": ""}, {"visual_required": "false"}, {"teacher_handoff": "automatic"}):
            with self.subTest(fields=fields):
                self.rejected(self.chapter_policy(**{"visual_required": False, **fields}))
        self.rejected(self.chapter_policy())  # states neither choice
        self.assertEqual(self.policy_now(), (True, "user_return", "default"))
        # configure is project-wide. Sent with a chapter_id it would silently change
        # every later chapter, so it is refused and points at chapter_policy.
        mistaken = self.event("configure", None, visual_required=False, teacher_handoff="user_return",
                              actor_role="author", mode="human", author_quote="这一章不看图。",
                              source_ref="fixture://chapter-choice")
        self.assertIn("chapter_policy", str(self.rejected(mistaken)))
        self.assertNotIn("chapter_workflow_policy", self.payload()["data"])
        # The author may say it before the chapter's first presentation.
        early = self.send(self.chapter_policy("c9", visual_required=False))
        self.assertEqual((early["chapter_status"], early["current_stage"], early["next_action"]),
                         ("not_started", "scope", "present"))
        self.assertEqual(self.policy_now("c9"), (False, "user_return", "chapter"))
        self.advance_until("preparation", "c9")
        self.send(self.bare("preparation", "c9"))

    def test_records_made_before_policies_existed_keep_reading_as_both_off(self):
        chapter = {"chapter_id": "old", "project_id": "book", "history": []}
        record = {"action": "present", "stage": "scope", "presentation_id": "old-scope", "content": "合成范围",
                  "source_ref": "fixture://old-scope", "artifact_sha256": None, "dependencies": [],
                  "status": "confirmed",
                  "confirmation": {"event_id": "old-confirm", "author_quote": "范围可以。",
                                   "source_ref": "fixture://old-author", "actor_role": "author", "mode": "human"}}
        record["version"] = gate._version(chapter, record)
        chapter["history"].append(record)
        snapshot = project_state.read_state(self.path)
        data = copy.deepcopy(snapshot["data"])
        data["chapter_confirmations"] = {"old": chapter}
        project_state.commit_state(self.path, snapshot["version"], data)
        state = gate.status(self.payload(), "old")
        self.assertEqual(state["current_stage"], "outline")
        self.assertEqual(self.policy_now("old"), (False, "host", "earlier_version"))
        self.send(self.confirmation(self.present("outline", "old")))
        self.send(self.confirmation(self.send(self.bare("preparation", "old"))))
        self.assertEqual(self.send(self.confirmation(self.present("draft", "old")))["next_action"], "present")
        self.send(self.bare("review", "old"))
        self.assertNotIn("workflow_policy", self.payload()["data"]["chapter_confirmations"]["old"])

    def test_policy_and_teacher_return_retries_share_outer_cas_and_idempotency(self):
        config = self.event("configure", None, visual_required=True, teacher_handoff="user_return",
                            actor_role="author", mode="human", author_quote="由我回传。", source_ref="fixture://choice")
        config.pop("chapter_id")
        config.pop("stage")
        stale = loop.read_store(self.path)[1]
        self.send(config, stale)
        self.assertEqual(self.send(config, stale)["status"], "unchanged")
        self.assertEqual(self.rejected({**config, "event_id": "new-config"}, stale).code, "stale_version")
        draft = self.prepare_policy_draft()
        event = self.teacher_return_event(draft)
        stale = loop.read_store(self.path)[1]
        first = self.send(event, stale)
        self.assertEqual(self.send(event, stale)["teacher_return_id"], first["teacher_return_id"])
        self.rejected({**event, "returned_text": "改过的原始回传"})
        self.assertEqual(len(self.payload()["data"]["chapter_confirmations"]["c1"]["teacher_returns"]), 1)

    def test_all_seven_stages_require_their_current_confirmation(self):
        self.assertEqual(gate.STAGES, ("scope", "outline", "preparation", "draft", "review", "revision", "final"))
        for index, stage in enumerate(gate.STAGES):
            if index + 1 < len(gate.STAGES):
                self.rejected(self.event("present", gate.STAGES[index + 1], content="跳关",
                                         source_ref="fixture://skip"))
            presented = self.present(stage)
            self.assertEqual(presented["next_action"], "confirm")
            self.assertEqual(gate.status(self.payload(), "c1")["current_stage"], stage)
            result = self.send(self.confirmation(presented))
        self.assertEqual(result["next_action"], "record_existing_author_gate")
        self.assertEqual(result["chapter_status"], "final_confirmation_recorded")

    def test_confirmation_requires_author_evidence_and_exact_stage_version(self):
        presented = self.present("scope")
        for fields in ({"author_quote": " "}, {"source_ref": ""}, {"actor_role": "teacher"},
                       {"mode": "independent_agent"}, {"presentation_version": sha("旧版")}):
            with self.subTest(fields=fields):
                self.rejected(self.confirmation(presented, **fields))
        wrong_stage = self.confirmation(presented)
        wrong_stage["stage"] = "outline"
        self.rejected(wrong_stage)
        self.send(self.confirmation(presented))
        self.rejected(self.confirmation(presented))

    def test_the_same_words_and_source_on_a_second_stage_are_marked_not_refused(self):
        # r5.55 review: a hard refusal also stops an author who really did answer
        # "继续" at each stage while the host wrote only a coarse source, so the
        # repeat is saved and marked (the earlier assertion that it is refused
        # with reused_confirmation went with that rule).
        words = {"author_quote": "继续", "source_ref": "本次对话"}
        first = self.send(self.confirmation(self.present("scope"), **words))
        self.assertNotIn("same_words_as_confirmation_of", first)
        outline = self.present("outline")
        marked = self.send(self.confirmation(outline, **words))
        self.assertEqual(marked["status"], "saved")
        self.assertEqual(marked["chapter_status"], "awaiting_presentation")
        self.assertEqual(marked["current_stage"], "preparation")
        self.assertEqual([item["stage"] for item in marked["same_words_as_confirmation_of"]], ["scope"])
        state = gate.status(self.payload(), "c1")
        self.assertEqual(state["repeated_confirmations"],
                         [{"stage": "outline", "presentation_id": outline["presentation_id"],
                           "same_as": marked["same_words_as_confirmation_of"]}])
        # A later message named down to its number is not marked.
        self.send(self.event("reopen", "outline", reason="方案变了", author_quote="方案重来。", source_ref="对话 第6条"))
        again = self.present("outline")
        plain = self.send(self.confirmation(again, author_quote="继续", source_ref="对话 第8条"))
        self.assertNotIn("same_words_as_confirmation_of", plain)
        self.assertNotIn("repeated_confirmations", gate.status(self.payload(), "c1"))
        # The mark stays inside one chapter.
        other = self.send(self.confirmation(self.present("scope", "c2"), **words))
        self.assertNotIn("same_words_as_confirmation_of", other)

    def test_confirmations_without_identity_fields_keep_their_progress_and_are_noted(self):
        # Records from an earlier version may carry no actor_role and mode. They are
        # read as before (r5.55 review: only the author's words, the source and,
        # for final, the decision decide whether a stage counts) and noted.
        self.finish_chapter("c1")
        self.advance_until("review", "c2")
        review = self.present("review", "c2")
        snapshot = project_state.read_state(self.path)
        data = copy.deepcopy(snapshot["data"])
        for chapter in data["chapter_confirmations"].values():
            for item in chapter["history"]:
                if isinstance(item.get("confirmation"), dict):
                    item["confirmation"].pop("actor_role", None)
                    item["confirmation"].pop("mode", None)
        project_state.commit_state(self.path, snapshot["version"], data)
        done = gate.status(self.payload(), "c1")
        self.assertEqual((done["chapter_status"], done["current_stage"], done["next_action"]),
                         ("final_confirmation_recorded", None, "record_existing_author_gate"))
        self.assertEqual(done["last_valid_confirmation"]["stage"], "final")
        self.assertEqual(len(done["record_problems"]), 1)
        for part in ("actor_role", "mode", "scope", "final", "as before"):
            self.assertIn(part, done["record_problems"][0])
        midway = gate.status(self.payload(), "c2")
        self.assertEqual((midway["current_stage"], midway["next_action"]), ("review", "confirm"))
        result = self.send(self.confirmation(review))
        self.assertEqual((result["status"], result["current_stage"]), ("saved", "revision"))
        # A stage that also lacks the author's words is still read as not confirmed.
        payload = self.payload()
        del next(item for item in payload["data"]["chapter_confirmations"]["c1"]["history"]
                 if item["stage"] == "draft")["confirmation"]["author_quote"]
        state = gate.status(payload, "c1")
        self.assertEqual((state["current_stage"], state["next_action"]), ("draft", "reopen"))

    def test_reducer_failures_and_status_are_read_only_and_malformed_namespace_rejected(self):
        payload = self.payload()
        before = copy.deepcopy(payload)
        self.assertEqual(gate.status(payload, "new")["current_stage"], "scope")
        with self.assertRaises(ValueError):
            gate.apply(payload, self.event("present", "draft", content="跳关", source_ref="fixture://skip"), "book")
        self.assertEqual(payload, before)
        malformed = copy.deepcopy(payload)
        malformed["data"]["chapter_confirmations"] = []
        with self.assertRaises(loop.LoopError):
            loop._validate(malformed)
        with self.assertRaises(ValueError):
            gate.status(malformed, "c1")

    def test_final_needs_hash_explicit_decision_and_more_than_continue(self):
        self.advance_until("final")
        for artifact in (None, "", "bad", "x" * 64):
            self.rejected(self.event("present", "final", content="合成定稿候选", source_ref="fixture://final",
                                     artifact_sha256=artifact))
        presented = self.present("final")
        for quote in ("继续", "继续吧。", " 继续写！ ", "继续下一章。", "请接着写。", "进入下一步。",
                      "我先看看。", "暂不定稿，继续改。", "先别封稿，等我再看一遍。"):
            self.rejected(self.confirmation(presented, author_quote=quote))
        self.rejected(self.confirmation(presented, decision="continue"))
        absent_decision = self.confirmation(presented)
        absent_decision.pop("decision")
        self.rejected(absent_decision)
        sealed = self.send(self.confirmation(presented, author_quote="这一章，封稿，开始下一章"))
        self.assertEqual(sealed["next_action"], "record_existing_author_gate")
        self.assertEqual(sealed["last_valid_confirmation"]["artifact_sha256"], presented["artifact_sha256"])

    def test_final_keeps_anything_short_of_a_whole_sentence_acceptance_pending(self):
        self.advance_until("final")
        presented = self.present("final")
        payload = self.payload()
        for quote in PENDING_FINAL_WORDS:
            with self.subTest(quote=quote):
                with self.assertRaises(gate.GateError):
                    gate.apply(copy.deepcopy(payload), self.confirmation(presented, author_quote=quote), "book")
        # Through the ledger: nothing is written, and the refusal carries two replies the author can send as is.
        refused = self.rejected(self.confirmation(presented, author_quote="还没到定稿的时候。"))
        for reply in ("定稿。", "采纳当前稿。"):
            self.assertIn(reply, str(refused))
        state = gate.status(self.payload(), "c1")
        self.assertEqual((state["chapter_status"], state["next_action"]), ("awaiting_confirmation", "confirm"))

    def test_final_accepts_plain_acceptance_including_no_more_changes(self):
        self.advance_until("final")
        presented = self.present("final")
        payload = self.payload()
        for quote in ACCEPTING_FINAL_WORDS:
            with self.subTest(quote=quote):
                result = gate.apply(copy.deepcopy(payload), self.confirmation(presented, author_quote=quote), "book")
                self.assertEqual(result["chapter_status"], "final_confirmation_recorded")
        # The words alone are not enough: the host must also send the decision field.
        for quote in ACCEPTING_FINAL_WORDS[:3]:
            event = self.confirmation(presented, author_quote=quote)
            event.pop("decision")
            with self.assertRaises(gate.GateError):
                gate.apply(copy.deepcopy(payload), event, "book")
        sealed = self.send(self.confirmation(presented, author_quote="不用改了，定稿。"))
        self.assertEqual(sealed["next_action"], "record_existing_author_gate")

    def test_draft_review_revision_and_final_bind_the_actual_artifact(self):
        # Runs under the author's recorded "no teacher" choice so that the only
        # reason a review presentation can be refused here is the artifact.
        self.policy_off()
        self.advance_until("draft")
        self.rejected(self.event("present", "draft", content="合成初稿", source_ref="fixture://draft"))
        draft_hash, revision_hash = sha("初稿A"), sha("修订稿B")
        self.send(self.confirmation(self.present("draft", artifact_sha256=draft_hash)))
        self.rejected(self.event("present", "review", content="错稿审查", source_ref="fixture://review",
                                 artifact_sha256=revision_hash))
        review = self.present("review")
        self.assertEqual(review["artifact_sha256"], draft_hash)
        self.send(self.confirmation(review))
        self.rejected(self.event("present", "revision", content="合成修订稿", source_ref="fixture://revision"))
        self.send(self.confirmation(self.present("revision", artifact_sha256=revision_hash)))
        self.rejected(self.event("present", "final", content="偷换旧初稿", source_ref="fixture://final",
                                 artifact_sha256=draft_hash))
        self.assertEqual(self.send(self.confirmation(self.present("final", artifact_sha256=revision_hash)))["next_action"],
                         "record_existing_author_gate")

    def test_same_text_represent_creates_new_instance_and_rejects_old_confirmation(self):
        first = self.present("scope")
        second = self.present("scope")
        self.assertEqual(first["presentation_version"], second["presentation_version"])
        self.assertNotEqual(first["presentation_id"], second["presentation_id"])
        self.rejected(self.confirmation(first))
        self.send(self.confirmation(second))
        history = self.payload()["data"]["chapter_confirmations"]["c1"]["history"]
        self.assertEqual([item["status"] for item in history], ["superseded", "confirmed"])
        self.assertEqual(history[0]["content"], "合成成果：scope")

    def test_reopen_invalidates_target_and_every_later_instance_but_keeps_evidence(self):
        self.finish_chapter()
        old = self.payload()["data"]["chapter_confirmations"]["c1"]["history"]
        old_preparation = old[2]["version"]
        self.rejected(self.event("reopen", "outline", reason="方案变化", author_quote="", source_ref="fixture://change"))
        self.send(self.event("reopen", "outline", reason="作者修改方案", author_quote="重新做本章方案。",
                             source_ref="fixture://synthetic-change"))
        state = gate.status(self.payload(), "c1")
        self.assertEqual((state["current_stage"], state["next_action"]), ("outline", "present"))
        history = self.payload()["data"]["chapter_confirmations"]["c1"]["history"]
        self.assertEqual(history[0]["status"], "confirmed")
        self.assertTrue(all(x["status"] == "invalidated" for x in history[1:7]))
        self.assertEqual(history[6]["confirmation"]["author_quote"], "明确采纳当前候选稿。")
        stale = {"chapter_id": "c1", "current_stage": "outline", "presentation_id": old[1]["presentation_id"],
                 "presentation_version": old[1]["version"]}
        self.rejected(self.confirmation(stale))
        self.send(self.confirmation(self.present("outline")))
        new_preparation = self.present("preparation")
        self.assertNotEqual(new_preparation["presentation_version"], old_preparation)

    def test_reopen_leaves_superseded_and_earlier_invalidated_records_as_they_were(self):
        first = self.present("scope")
        second = self.present("scope")  # first is now superseded
        self.send(self.confirmation(second))
        reopen_1 = self.event("reopen", "scope", reason="范围变了", author_quote="范围重来。",
                              source_ref="fixture://reopen-1")
        self.send(reopen_1)
        third = self.present("scope")
        self.send(self.confirmation(third))
        reopen_2 = self.event("reopen", "scope", reason="范围又变了", author_quote="范围再重来。",
                              source_ref="fixture://reopen-2")
        self.send(reopen_2)
        history = self.payload()["data"]["chapter_confirmations"]["c1"]["history"]
        shown = {item["presentation_id"]: item for item in history if item["action"] == "present"}
        superseded = shown[first["presentation_id"]]
        self.assertEqual((superseded["status"], superseded["superseded_by"]), ("superseded", second["presentation_id"]))
        self.assertNotIn("invalidated_by", superseded)
        self.assertEqual(shown[second["presentation_id"]]["invalidated_by"], reopen_1["event_id"])
        self.assertEqual(shown[third["presentation_id"]]["invalidated_by"], reopen_2["event_id"])
        self.assertEqual([item["invalidated_presentation_ids"] for item in history if item["action"] == "reopen"],
                         [[second["presentation_id"]], [third["presentation_id"]]])

    def test_chapters_cannot_borrow_confirmations_or_reopen_future_stages(self):
        first = self.present("scope", "c1")
        second = self.present("scope", "c2")
        self.assertNotEqual(first["presentation_version"], second["presentation_version"])
        borrowed = self.confirmation(first)
        borrowed["chapter_id"] = "c2"
        self.rejected(borrowed)
        self.rejected(self.event("reopen", "final", "c2", reason="试图跳关", author_quote="继续。",
                                 source_ref="fixture://skip"))
        self.send(self.confirmation(first))
        self.assertEqual(gate.status(self.payload(), "c2")["current_stage"], "scope")

    def test_confirmed_stage_without_author_evidence_reads_as_unconfirmed_and_is_reported(self):
        self.advance_until("final")
        presented = self.present("final")
        clean = self.payload()
        self.assertNotIn("record_problems", gate.status(clean, "c1"))

        def edited(stage, change):
            payload = copy.deepcopy(clean)
            live = next(item for item in payload["data"]["chapter_confirmations"]["c1"]["history"]
                        if item["stage"] == stage and item["status"] in {"pending", "confirmed"})
            change(live)
            return payload

        # The last stage flipped to confirmed by hand, with only an event id.
        flipped = edited("final", lambda item: item.update(status="confirmed", confirmation={"event_id": "手改"}))
        state = gate.status(flipped, "c1")
        self.assertEqual((state["chapter_status"], state["current_stage"], state["next_action"]),
                         ("awaiting_confirmation", "final", "confirm"))
        self.assertEqual(state["last_valid_confirmation"]["stage"], "revision")
        self.assertEqual(len(state["record_problems"]), 1)
        for part in ("final", "author_quote", "source_ref", "actor_role", "mode", "decision"):
            self.assertIn(part, state["record_problems"][0])
        # A real confirmation of that same presentation puts it right.
        fixed = gate.apply(flipped, self.confirmation(presented), "book")
        self.assertEqual(fixed["chapter_status"], "final_confirmation_recorded")
        self.assertNotIn("record_problems", fixed)
        # A final with words and source but no decision is not a final acceptance either.
        accepted = copy.deepcopy(clean)
        gate.apply(accepted, self.confirmation(presented), "book")
        self.assertEqual(gate.status(accepted, "c1")["chapter_status"], "final_confirmation_recorded")
        live_final = next(item for item in accepted["data"]["chapter_confirmations"]["c1"]["history"]
                          if item["stage"] == "final" and item["status"] == "confirmed")
        del live_final["confirmation"]["decision"]
        state = gate.status(accepted, "c1")
        self.assertEqual((state["chapter_status"], state["next_action"]), ("awaiting_confirmation", "confirm"))
        self.assertIn("decision", state["record_problems"][0])
        # Each piece of author evidence is needed on an earlier stage too.
        # r5.55 review: actor_role and mode are noted but no longer hold a stage
        # back, since records from earlier versions may lack them; those two
        # cases moved from "read as not confirmed" to "read as before, noted".
        for field, value, stage in (("author_quote", None, "revision"), ("source_ref", " ", "revision"),
                                    ("actor_role", "teacher", "final"), ("mode", None, "final"),
                                    ("event_id", None, "revision")):
            def drop(item, field=field, value=value):
                if value is None:
                    del item["confirmation"][field]
                else:
                    item["confirmation"][field] = value
            with self.subTest(field=field):
                state = gate.status(edited("revision", drop), "c1")
                self.assertEqual(state["current_stage"], stage)
                self.assertIn(field, " ".join(state["record_problems"]))
                self.assertIn("revision", " ".join(state["record_problems"]))

    def test_confirmed_presentation_gives_other_scripts_the_gates_own_reading(self):
        self.policy_off()
        self.advance_until("review")
        review = self.present("review")
        self.assertIsNone(gate.confirmed_presentation(self.payload(), "c1", "review"))  # only presented
        self.send(self.confirmation(review))
        payload = self.payload()
        found = gate.confirmed_presentation(payload, "c1", "review")
        self.assertEqual((found["presentation_id"], found["version"]),
                         (review["presentation_id"], review["presentation_version"]))
        self.assertIsNone(gate.confirmed_presentation(payload, "c1", "revision"))
        self.assertIsNone(gate.confirmed_presentation(payload, "missing", "review"))
        # Marked confirmed in the record, but without the author's words: not confirmed.
        live = next(item for item in payload["data"]["chapter_confirmations"]["c1"]["history"]
                    if item["stage"] == "review" and item["status"] == "confirmed")
        del live["confirmation"]["author_quote"]
        self.assertIsNone(gate.confirmed_presentation(payload, "c1", "review"))
        self.assertEqual(gate.confirmed_presentation(payload, "c1", "draft")["stage"], "draft")

    def test_unconfirmed_stage_under_later_stages_can_only_be_reopened(self):
        self.advance_until("draft")
        payload = self.payload()
        history = payload["data"]["chapter_confirmations"]["c1"]["history"]
        del history[1]["confirmation"]["author_quote"]  # outline, with preparation confirmed on top of it
        state = gate.status(payload, "c1")
        self.assertEqual((state["chapter_status"], state["current_stage"], state["next_action"]),
                         ("awaiting_confirmation", "outline", "reopen"))
        self.assertEqual(state["last_valid_confirmation"]["stage"], "scope")
        self.assertIn("preparation", state["record_problems"][0])
        outline = {"chapter_id": "c1", "current_stage": "outline", "presentation_id": history[1]["presentation_id"],
                   "presentation_version": history[1]["version"]}
        for event in (self.confirmation(outline), self.bare("outline"),
                      self.event("present", "draft", content="合成初稿", source_ref="fixture://draft",
                                 artifact_sha256=sha("合成候选稿"))):
            with self.assertRaises(gate.GateError) as caught:
                gate.apply(copy.deepcopy(payload), event, "book")
            if event["stage"] == "outline":
                self.assertIn("reopen", str(caught.exception))
        reopened = gate.apply(payload, self.event("reopen", "outline", reason="记录缺作者原话",
                                                  author_quote="方案这一步重新确认。",
                                                  source_ref="fixture://reopen-outline"), "book")
        self.assertEqual((reopened["current_stage"], reopened["next_action"]), ("outline", "present"))
        self.assertNotIn("record_problems", reopened)

    def test_hand_edited_markdown_record_does_not_read_as_final_acceptance(self):
        self.markdown_store()
        self.advance_until("final")
        presented = self.present("final")
        text = self.path.read_text(encoding="utf-8")
        start = text.index("```json\n") + len("```json\n")
        end = text.index("\n```", start)
        payload = json.loads(text[start:end])
        final = payload["data"]["chapter_confirmations"]["c1"]["history"][-1]
        self.assertEqual((final["stage"], final["status"]), ("final", "pending"))
        final.update(status="confirmed", confirmation={"event_id": "手改"})
        self.path.write_text(text[:start] + json.dumps(payload, ensure_ascii=False) + text[end:], encoding="utf-8")
        result = self.status_cli("-I", "-B")
        self.assertEqual(result.returncode, 0, result.stderr)
        state = json.loads(result.stdout)
        self.assertEqual((state["chapter_status"], state["next_action"]), ("awaiting_confirmation", "confirm"))
        self.assertIn("author_quote", state["record_problems"][0])
        sealed = self.send(self.confirmation(presented))
        self.assertEqual(sealed["chapter_status"], "final_confirmation_recorded")

    def test_retries_are_idempotent_and_new_events_require_current_cas(self):
        event = self.event("present", "scope", content="合成范围", source_ref="fixture://scope")
        old_version = loop.read_store(self.path)[1]
        first = self.send(event, old_version)
        saved = self.path.read_bytes()
        repeated = self.send(copy.deepcopy(event), old_version)
        self.assertEqual(repeated["status"], "unchanged")
        self.assertEqual(repeated["presentation_id"], first["presentation_id"])
        self.assertEqual(self.path.read_bytes(), saved)
        self.rejected({**event, "content": "改过的范围"})
        self.assertEqual(self.rejected(self.confirmation(first), old_version).code, "stale_version")
        confirmation = self.confirmation(first)
        confirmed = self.send(confirmation)
        self.assertEqual(self.send(confirmation, old_version)["status"], "unchanged")
        self.assertEqual(confirmed["current_stage"], "outline")

    def test_existing_story_author_status_and_unrelated_data_survive(self):
        original = {"characters": {"L": {"name": "合成角色"}}, "settings": {"weather": "雨"},
                    "chapters": {"c1": {"text": "原有正文", "AUTHOR": "awaiting_author"}},
                    "delivery": {"FACT": "pass", "COPY": "pass", "TEACHER": "pass", "AUTHOR": "waiting"},
                    "notes": ["原有说明"]}
        self.path = Path(self.temp.name) / "original.json"
        project_state.init_state(self.path, "book", original)
        self.finish_chapter()
        for key, value in original.items():
            self.assertEqual(self.payload()["data"][key], value)
        self.assertEqual(set(self.payload()["data"]) - set(original), {"chapter_confirmations", "learning_events"})

    def test_chapter_confirmation_works_with_learning_disabled(self):
        presented = self.present("scope")
        self.assertEqual(self.send(self.confirmation(presented))["current_stage"], "outline")
        self.assertFalse(loop.status(self.path)["loop_enabled"])
        self.assertNotIn("learning_runs", self.payload()["data"])

    def test_learning_finish_does_not_confirm_any_chapter(self):
        self.present("scope")
        before = copy.deepcopy(self.payload()["data"]["chapter_confirmations"])
        def learning(op, **fields):
            self.serial += 1
            return self.send({"event_id": "learning-" + str(self.serial), "op": op,
                              "run_id": "synthetic-run", **fields})
        # Case selection and the learning loop retain their own switches.
        snapshot = project_state.read_state(self.path)
        data = copy.deepcopy(snapshot["data"])
        data["demonstration_learning"]["enabled"] = True
        project_state.commit_state(self.path, snapshot["version"], data)
        learning("configure", loop_enabled=True)
        learning("start", task="dialogue_revision", tags=[], group_id="fixture-group", input_text="合成原稿",
                 source_ref="fixture://input", constraints=[])
        learning("plan", applications=[], checks=[])
        learning("draft", text="合成初稿", source_ref="fixture://draft",
                 actor={"name": "fixture-writer", "context_id": "fixture-writer"})
        learning("review", review_id="teacher", draft_sha256=sha("合成初稿"),
                 reviewer={"name": "fixture-teacher", "context_id": "fixture-teacher", "role": "teacher",
                           "mode": "independent_agent"}, verdict="pass", findings=[], source_ref="fixture://review")
        learning("finish", draft_sha256=sha("合成初稿"))
        self.assertEqual(self.payload()["data"]["chapter_confirmations"], before)

    def test_markdown_storage_and_status_cli_resume_pending_without_writing(self):
        prefix, suffix = "# 合成记录\n保留说明。\n", "\n末尾手写说明。\n"
        self.markdown_store(prefix, suffix)
        self.send(self.confirmation(self.present("scope")))
        presented = self.present("outline")
        before = self.path.read_bytes()
        # Isolated mode keeps the script directory off sys.path, as the package's
        # own runner and many hosts do; -B keeps __pycache__ out of the package.
        result = self.status_cli("-I", "-B")
        self.assertEqual(result.returncode, 0, result.stderr)
        resumed = json.loads(result.stdout)
        self.assertEqual(resumed["presentation_id"], presented["presentation_id"])
        self.assertEqual(resumed["last_valid_confirmation"]["stage"], "scope")
        self.assertEqual(self.path.read_bytes(), before)
        self.assertTrue(before.startswith(prefix.encode()) and before.endswith(suffix.encode()))

    def test_plain_commands_leave_no_bytecode_next_to_the_scripts(self):
        # The pages print these commands without -B; loading the sibling modules
        # by path must still not write scripts/__pycache__ into the skill folder.
        scripts = Path(self.temp.name) / "skill" / "scripts"
        scripts.mkdir(parents=True)
        for name in ("chapter_gate.py", "learning_loop.py", "demonstration_memory.py", "project_state.py"):
            (scripts / name).write_bytes((ROOT / "scripts" / name).read_bytes())
        self.present("scope")
        for command in (["chapter_gate.py", "status", str(self.path), "--chapter-id", "c1"],
                        ["learning_loop.py", "status", str(self.path)]):
            with self.subTest(command=command[0]):
                result = subprocess.run([sys.executable, "-I", str(scripts / command[0]), *command[1:]],
                                        capture_output=True, text=True, encoding="utf-8")
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(sorted(path.name for path in scripts.rglob("*") if path.is_dir()
                                        or path.suffix == ".pyc"), [])

    def test_status_cli_runs_without_the_script_directory_and_reports_errors_as_json(self):
        self.policy_off()
        self.present("scope")
        modes = [("-I", "-B")] + ([("-P", "-B")] if sys.version_info >= (3, 11) else [])
        for flags in modes:
            with self.subTest(flags=flags):
                result = self.status_cli(*flags)
                self.assertEqual(result.returncode, 0, result.stderr)
                state = json.loads(result.stdout)
                self.assertEqual((state["current_stage"], state["next_action"]), ("scope", "confirm"))
                self.assertEqual(state["workflow_policy"]["author_quote"], "这本书不看图，也不交教师。")
                self.assertTrue(state["store_version"])
        described = subprocess.run([sys.executable, "-I", "-B", str(ROOT / "scripts/chapter_gate.py"), "--help"],
                                   capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(described.returncode, 0, described.stderr)
        for word in ("chapter_policy", "workflow_policy", "record_problems"):
            self.assertIn(word, described.stdout)
        missing = self.status_cli("-I", "-B", path=Path(self.temp.name) / "missing.json")
        self.assertEqual(missing.returncode, 2)
        self.assertNotIn("Traceback", missing.stderr)
        self.assertEqual(json.loads(missing.stderr)["status"], "error")


if __name__ == "__main__":
    unittest.main()

# 来源记录

此目录为用户要求的风格卡分享提取版，未自动安装，未修改原商业包或本机已安装技能。

来源：novel-workshop-commercial-r5.45(1).zip，2026-10-26-r5.45-candidate。

SKILL.md为从随包style-cards.md整理的独立入口；references/cards.json逐字节取自原商业包，完整保留83卡、source、layers、global与composition字段。来源卡组版本4.1.0。原始许可说明另存LICENSE-NOTICES.original.md，它针对完整商业交付包；当前目录未包含该说明提到的所有其他组件。本次导出不新增或变更原包许可。

原商业ZIP SHA-256：`d208ed8a3027de3d2637b14edb3a4db2b4d1c7b0f5d8df5c5b5039b31bbcfe96`。

原卡库SHA-256：`6356c822049fea287a72ef924f2ac2463b8a4bd4e6e209eb2a3823e305f27107`。

原风格使用规则SHA-256：`897a619c8c0735435b3c67b6dd1e3979a838870e8b45a6e03c29767b5032d7c4`。

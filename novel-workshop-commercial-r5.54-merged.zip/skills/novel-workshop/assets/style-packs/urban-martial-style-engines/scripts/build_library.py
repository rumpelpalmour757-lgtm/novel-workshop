#!/usr/bin/env python3
"""改过引擎文件、router.yaml 或 L0_core.yaml 之后运行一次，重新生成全部派生文件：

  references/library.json   整库单文件（底座、总控、全部引擎全文）；另外三个脚本只读它
  references/catalog.md     引擎目录、配方、禁配
  docs/改动明细.md           各引擎 changes 字段汇总
  prompts/                   现成提示词（调用 export_prompt.py --all）

先做校验：必填字段、编号格式、文件名前缀、重复编号、悬空引用。本脚本需要 PyYAML。
用法：python scripts/build_library.py
"""
import json
import subprocess
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
REF = ROOT / "references"
REQUIRED = ("id", "num", "name", "layer", "group", "version", "load_when", "conflicts", "pairs_with", "tone", "rules", "bans")
LAYER_DESC = {
    "L1": ("主角模板", "开书锁定1主+1副，身份锁（lock）全书生效；也可进槽1，当本场视角人物的模板。"),
    "L2": ("剧情舞台", "按卷换，进槽3。"),
    "L3": ("场面模块", "按场换，进槽2。"),
    "L4": ("叙事滤镜", "按章换，进槽1或槽3。"),
}
SLOT_KEYS = ("slot_1", "slot_2", "slot_3")


def cell(s):
    return str(s).replace("|", "｜").replace("\n", " ")


def load_engines():
    engines = {}
    for f in (REF / "engines").glob("*.yaml"):
        d = yaml.safe_load(f.read_text(encoding="utf-8"))
        num = d.get("num")
        if not isinstance(num, str):
            sys.exit(f"{f.name}：num 必须是带引号的字符串，例如 num: '02'")
        if not f.name.startswith(num + "_"):
            sys.exit(f"{f.name}：文件名要以编号开头（{num}_…）")
        if num in engines:
            sys.exit(f"编号重复：{num}")
        missing = [k for k in REQUIRED if k not in d]
        if missing:
            sys.exit(f"{f.name}：缺少字段 {'、'.join(missing)}")
        if d["layer"] not in LAYER_DESC:
            sys.exit(f"{f.name}：layer 只能是 L1–L4")
        d["file"] = f"references/engines/{f.name}"
        engines[num] = d
    return dict(sorted(engines.items(), key=lambda kv: int(kv[0])))


def check_refs(engines, rt):
    refs = {r for e in engines.values() for r in e["conflicts"] + e["pairs_with"]}
    for p in rt["forbidden_pairs"]:
        refs |= set(p["a"]) | set(p["b"])
    for g in rt.get("exclusive_groups", []):
        refs |= set(g["members"])
    for m in rt.get("mode_pairs", []):
        refs.add(m["num"])
    for rec in rt["recipes"].values():
        for k, v in rec.items():
            if k.startswith(("L", "slot")):
                refs |= set(v)
    dangling = sorted(refs - set(engines), key=int)
    if dangling:
        sys.exit(f"引用了不存在的编号：{'、'.join(dangling)}")


def catalog(engines, rt, counts):
    name = lambda n: f"{n}{engines[n]['name']}"  # noqa: E731
    out = ["# 引擎目录", "",
           f"由 scripts/build_library.py 生成，改了引擎重新运行即可，别手改。共{len(engines)}个："
           + "、".join(f"{k} {v}" for k, v in counts.items()) + "。",
           "选定后读 references/engines/ 下对应文件；check_combo.py 会列出文件名。", ""]
    for lay, (title, desc) in LAYER_DESC.items():
        rows = [n for n, e in engines.items() if e["layer"] == lay]
        groups = list(dict.fromkeys(engines[n]["group"] for n in rows))
        rows.sort(key=lambda n: (groups.index(engines[n]["group"]), int(n)))
        out += [f"## {lay} {title}（{len(rows)}）", "", desc, "",
                "| 编号 | 引擎 | 组 | 标签 | 何时用 |", "| --- | --- | --- | --- | --- |"]
        for n in rows:
            e = engines[n]
            out.append(f"| {n} | {cell(e['name'])} | {cell(e['group'])} | {'、'.join(e.get('tags', []))} | {cell(e['load_when'])} |")
        out.append("")
    out += ["## 配方", "", "每槽给候选，每次各取一个；`check_combo.py --recipe 名字` 默认取第一个。", "",
            "| 配方 | 本书L1 | 槽1 人物底色 | 槽2 战斗物理 | 槽3 副本规则 | 说明 |", "| --- | --- | --- | --- | --- | --- |"]
    for rname, rec in rt["recipes"].items():
        cols = []
        for k in ("L1",) + SLOT_KEYS:
            v = "、".join(map(name, rec.get(k, [])))
            cols.append(v or ("按主角定" if k == "L1" else "空"))
        out.append(f"| {rname} | " + " | ".join(cols) + f" | {cell(rec.get('note', ''))} |")
    out += ["", "## 禁配与互斥", "", "| 组合 | 层面 | 原因 |", "| --- | --- | --- |"]
    for p in rt["forbidden_pairs"]:
        out.append(f"| {'、'.join(p['a'])} × {'、'.join(p['b'])} | {p['level']} | {cell(p['why'])} |")
    for g in rt.get("exclusive_groups", []):
        out.append(f"| 互斥组「{g['name']}」：{'、'.join(g['members'])}，只选一个 | {g['level']} | {cell(g['why'])} |")
    for t in rt.get("tag_clash", []):
        a = "、".join(n for n, e in engines.items() if t["a"] in e.get("tags", []))
        b = "、".join(n for n, e in engines.items() if t["b"] in e.get("tags", []))
        out.append(f"| 「{t['a']}」（{a}）×「{t['b']}」（{b}） | {t['level']} | {cell(t['why'])} |")
    for m in rt.get("mode_pairs", []):
        out.append(f"| {m['num']}的「{m['mode']}」模式 ×「{m.get('b_tag', '')}」 | {m['level']} | 同上 |")
    out += ["", "## 已合并的旧编号", ""] + [f"- {n}：{v}" for n, v in rt["merged"].items()]
    return "\n".join(out) + "\n"


def changelog(engines):
    out = ["# 改动明细", "",
           "由 scripts/build_library.py 从各引擎的 changes 字段汇总。v1.1 的60个引擎记的是相对最初原稿的改动；"
           "v2.0 新增的引擎记的是相对你这次发来的原稿的改动。没列出的引擎只做了格式整理。", ""]
    for n, e in engines.items():
        if e.get("changes"):
            out += [f"## {n} {e['name']}", ""] + [f"- {c}" for c in e["changes"]] + [""]
    return "\n".join(out)


def main():
    engines = load_engines()
    router = yaml.safe_load((REF / "router.yaml").read_text(encoding="utf-8"))
    core = yaml.safe_load((REF / "L0_core.yaml").read_text(encoding="utf-8"))
    rt = router["router"]
    check_refs(engines, rt)

    counts = {}
    for e in engines.values():
        counts[e["layer"]] = counts.get(e["layer"], 0) + 1
    counts = dict(sorted(counts.items()))
    lib = {"version": rt["version"], "router": rt, "global_rules": router["global_rules"],
           "checklist": router.get("checklist", []), "core": core, "engines": engines}
    (REF / "library.json").write_text(json.dumps(lib, ensure_ascii=False, indent=1), encoding="utf-8")
    (REF / "catalog.md").write_text(catalog(engines, rt, counts), encoding="utf-8")
    (ROOT / "docs").mkdir(exist_ok=True)
    (ROOT / "docs" / "改动明细.md").write_text(changelog(engines), encoding="utf-8")
    print(f"已生成 library.json、catalog.md、改动明细.md：{len(engines)} 个引擎（"
          + "，".join(f"{k} {v}" for k, v in counts.items()) + "）", flush=True)
    subprocess.run([sys.executable, str(ROOT / "scripts" / "export_prompt.py"), "--all"], check=True)


if __name__ == "__main__":
    main()

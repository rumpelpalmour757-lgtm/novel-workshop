#!/usr/bin/env python3
"""Compare declared story-fact claims with an accepted fact ledger.

The tool never reads prose for meaning. A person or model extracts claims from a
candidate chapter (with quotes); this script checks them against facts from
accepted chapters, keeps records, beliefs and plans apart from what actually
happened, and lists later chapters to re-check after an earlier one changes.

Facts marked "persist": true (an injury, a narrow passage, rising water, who holds
an object, who knows what) are listed by `check` whenever a later chapter mentions
the entity and no claim answers that state: the reviewer must say how the chapter
deals with it. The tool still does not judge whether it does.

Every claim has its own id: written ids must be nonempty strings, unique in the
claims file (a repeated id is invalid input); a claim without one gets c<position>,
moved aside when another claim already uses that name.

Who knows what (attributes known_by.<person>) is compared by story time, not by
chapter number (r5.51): a flashback in chapter 3 set at 09:00 is not supported by a
chapter-2 fact saying the person only learned it at 10:00. Evidence still has to
come from accepted chapters before the current one; evidence that takes effect
after the scene cannot support "consistent"; when only the chapter order is known
the result is KNOWLEDGE_PENDING (pending review). A guess or false belief
(belief.<person>.), what only the reader knows (known_by.读者), and facts from
drafts or unaccepted candidates never count as the person having learned it.

Commands: status, check, scan, impact.  Exit codes: 0 no blocking result,
1 conflicts/unsupported/stale binding/ledger problems, 2 invalid input.
"""

import argparse
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import re
import sys

LEDGER_SCHEMA = "fact-ledger/1"
CLAIMS_SCHEMA = "fact-claims/1"
BASELINE_LAYERS = {"accepted", "author_confirmed"}
LAYERS = BASELINE_LAYERS | {"candidate", "abandoned", "summary", "plan"}
DIRECT = {"witnessed_action", "text_statement", "author_confirmed"}
INDIRECT = {"record", "record_absence", "testimony", "inference", "plan", "summary"}
UNKNOWN = {"unknown", "未知", "待定", "不明"}
# Attributes in these namespaces describe what a record says or what someone
# believes. They may rest on indirect evidence; plain attributes may not.
REPORTED = ("record.", "belief.", "claim.")
TIME = re.compile(r"^(?:D(\d+)\s+)?(\d{1,2}):(\d{2})$")
DAY = re.compile(r"^D(\d+)$")
# r5.51: who knows what. known_by.<person> is checked by story time; the reader's knowledge (known_by.读者) follows the
# reading order, so it keeps the chapter-order comparison and never stands for a person in the story.
KNOWN = "known_by."
READER = {"known_by.读者", "known_by.reader"}


class FactError(ValueError):
    pass


def need(condition, message):
    if not condition:
        raise FactError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def unique_keys(items):
    """A repeated key in one JSON object would silently keep only its last value; refuse it."""
    value = {}
    for key, item in items:
        need(key not in value, "repeated JSON key %r in one object; write each key once" % key)
        value[key] = item
    return value


def load_json(path):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"), object_pairs_hook=unique_keys)
    except FileNotFoundError as exc:
        raise FactError("file not found: " + str(path)) from exc


def claim_ids(claims):
    """One id per claim. Written ids must be nonempty strings and unique in the file; a claim without an id gets
    c<position>, moved aside (c2-auto, c2-auto2 ...) when that name is already written on another claim, so a review
    item never stands for two claims (r5 review F02)."""
    written = {}
    for index, claim in enumerate(claims, 1):
        if isinstance(claim, dict) and "id" in claim:
            cid = claim["id"]
            need(isinstance(cid, str) and bool(cid.strip()),
                 "claim %d: id must be a nonempty string (got %s)" % (index, json.dumps(cid, ensure_ascii=False)))
            need(cid not in written, "claims %d and %d both use the id %s; every claim needs its own id, otherwise one "
                 "review decision would cover both" % (written.get(cid, 0), index, json.dumps(cid, ensure_ascii=False)))
            written[cid] = index
    ids, taken = [], set(written)
    for index, claim in enumerate(claims, 1):
        if isinstance(claim, dict) and "id" in claim:
            ids.append(claim["id"])
            continue
        base = value = "c%d" % index
        number = 1
        while value in taken:
            value = base + "-auto" + ("" if number == 1 else str(number))
            number += 1
        taken.add(value)
        ids.append(value)
    return ids


def text_of(value):
    return isinstance(value, str) and bool(value.strip())


def parse_time(value):
    if value is None:
        return None
    match = TIME.match(str(value).strip())
    need(match, "time must look like 08:30 or D2 08:30: " + str(value))
    need(int(match.group(2)) < 24 and int(match.group(3)) < 60,
         "time hour must be 00-23 and minute 00-59: " + str(value))
    return (int(match.group(1) or 0), int(match.group(2)) * 60 + int(match.group(3)))


def parse_point(value, end=False):
    """One end of a story-time span (r5.51): "08:30", "D2 08:30", or a whole day "D2" (its first or last minute).
    Returns ((day, minute), day_written)."""
    text = str(value).strip()
    day = DAY.match(text)
    if day:
        return (int(day.group(1)), 23 * 60 + 59 if end else 0), True
    match = TIME.match(text)
    need(match, "story time must look like 08:30, D2 08:30 or D2: " + str(value))
    need(int(match.group(2)) < 24 and int(match.group(3)) < 60, "time hour must be 00-23 and minute 00-59: " + str(value))
    return (int(match.group(1) or 0), int(match.group(2)) * 60 + int(match.group(3))), match.group(1) is not None


def parse_span(value):
    """A point or a stretch of story time (r5.51): a claim's or fact's "time", or a chapter's "story_time" written as
    one value or as {"from": ..., "to": ...}. Both ends must say the day, or neither: "D2 09:00" against "10:00" cannot
    be put in order."""
    if value is None:
        return None
    if isinstance(value, dict):
        need(set(value) == {"from", "to"}, "story_time as an object needs exactly from and to: " + json.dumps(value, ensure_ascii=False))
        start, start_day = parse_point(value["from"])
        stop, stop_day = parse_point(value["to"], end=True)
        need(start_day == stop_day, "story_time from and to must both say the day (D2 ...) or neither: " + json.dumps(value, ensure_ascii=False))
        need(start <= stop, "story_time from must not be after to: " + json.dumps(value, ensure_ascii=False))
        return {"start": start, "end": stop, "day": start_day, "text": "%s—%s" % (value["from"], value["to"])}
    need(isinstance(value, str), "time must be a string such as 09:20, D2 09:20 or D2: " + json.dumps(value, ensure_ascii=False))
    start, day = parse_point(value)
    stop, _ = parse_point(value, end=True)
    return {"start": start, "end": stop, "day": day, "text": value.strip()}


def story_order(earlier, later):
    """'before' when the whole of `earlier` is at or before the start of `later`, 'after' when it all comes later,
    None when the two overlap, one of them is missing, only one of them says the day, or the day is unknown."""
    if (earlier is None or later is None or earlier["day"] is None or later["day"] is None
            or earlier["day"] != later["day"]):
        return None
    if earlier["end"] <= later["start"]:
        return "before"
    if earlier["start"] > later["end"]:
        return "after"
    return None


def strictly_before(earlier, later):
    """True only when `earlier` ends before `later` starts: the same moment told twice is not earlier (r5.51)."""
    return (earlier is not None and later is not None and earlier["day"] is not None
            and earlier["day"] == later["day"] and earlier["end"] < later["start"])


def with_day(span, frame):
    """A clock time without a day ("08:00") in a chapter whose story_time does say the day ("D3"): the day is not
    filled in from the chapter, because a scene inside the chapter can go back to another day; the time's day is
    unknown, so it cannot be put in order (r5.51, review). Write the day on the time itself ("D3 08:00")."""
    if span is None or span["day"] or frame is None or not frame["day"]:
        return span
    return dict(span, day=None, text=span["text"] + "（第几天不明）")


def unordered_why(spans, own_times):
    """Why scenes of one chapter cannot be put in order, for the pending reasons (r5.51, review). `own_times` says
    whether each scene wrote its own time (rather than taking the chapter's story_time)."""
    if any(s is None for s in spans):
        return "有的场没写故事时间，同一章各场要各写各的 time"
    if not all(own_times):
        return "有的场没写自己的 time，只能按本章的 story_time 算，同一章各场要各写各的 time"
    if any(s["day"] is None for s in spans):
        return "时间只写了钟点，本章的 story_time 却写了第几天，程序不替它补；time 要连第几天一起写，比如 D2 09:00"
    if len({s["day"] for s in spans}) > 1:
        return "一边写了第几天、一边没写"
    return "两场时间相同或两段时间重叠"


def load_ledger(path):
    raw = load_json(path)
    # Accept a project_state.py snapshot that keeps the ledger at data.facts.
    if isinstance(raw, dict) and isinstance(raw.get("data"), dict) and "facts" in raw["data"]:
        location = Path(__file__).with_name("project_state.py")
        spec = importlib.util.spec_from_file_location("fact_project_state", location)
        state_api = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(state_api)
        try:
            state_api._validate(raw)
        except (state_api.StateError, ValueError) as exc:
            raise FactError("Invalid project state snapshot: " + str(exc)) from exc
        raw = raw["data"]["facts"]
    need(isinstance(raw, dict) and raw.get("schema") == LEDGER_SCHEMA, "ledger schema must be " + LEDGER_SCHEMA)
    entities = raw.get("entities", {})
    need(isinstance(entities, dict), "entities must be an object")
    for key, entity in entities.items():
        need(isinstance(entity, dict) and text_of(entity.get("name")), "entity %s needs a name" % key)
        aliases = entity.setdefault("aliases", [entity["name"]])
        need(isinstance(aliases, list) and all(text_of(a) for a in aliases), "entity %s aliases must be strings" % key)
    chapters = raw.get("chapters", {})
    need(isinstance(chapters, dict), "chapters must be an object")
    for key, chapter in chapters.items():
        need(str(key).isdigit() and isinstance(chapter, dict) and chapter.get("status") in LAYERS,
             "chapter %s needs a numeric key and a valid status" % key)
        # r5.51: when the chapter's scenes happen in story time, for facts that do not carry their own time.
        try:
            chapter["_span"] = parse_span(chapter.get("story_time"))
        except FactError as exc:
            raise FactError("chapter %s: %s" % (key, exc)) from exc
    facts = raw.get("facts", [])
    need(isinstance(facts, list), "facts must be a list")
    seen = set()
    for order, fact in enumerate(facts):
        need(isinstance(fact, dict), "each fact must be an object")
        for field in ("id", "entity", "attribute", "source"):
            need(text_of(fact.get(field)), "fact %s needs %s" % (fact.get("id", order), field))
        need(fact["id"] not in seen, "duplicate fact id " + fact["id"])
        seen.add(fact["id"])
        need(fact["entity"] in entities, "fact %s names an undeclared entity" % fact["id"])
        need("value" in fact, "fact %s needs value" % fact["id"])
        need(type(fact.get("chapter")) is int and fact["chapter"] >= 0, "fact %s needs an integer chapter" % fact["id"])
        need(fact.get("layer") in LAYERS, "fact %s has invalid layer" % fact["id"])
        need(fact.get("basis") in DIRECT | INDIRECT, "fact %s has invalid basis" % fact["id"])
        need(isinstance(fact.get("persist", False), bool), "fact %s: persist must be true or false" % fact["id"])
        if fact["attribute"].startswith(KNOWN):  # r5.51: a "true" string would switch off the story-time checks
            need(isinstance(fact.get("change", False), bool), "fact %s: change must be true or false" % fact["id"])
        fact["_time"] = parse_time(fact.get("time"))
        fact["_span"] = parse_span(fact.get("time"))
        fact["_order"] = order
    return {"entities": entities, "chapters": chapters, "facts": facts}


def is_unknown(value):
    return isinstance(value, str) and value.strip().lower() in UNKNOWN


def same(left, right):
    return json.dumps(left, ensure_ascii=False, sort_keys=True) == json.dumps(right, ensure_ascii=False, sort_keys=True)


def reported(attribute):
    return attribute.startswith(REPORTED)


def author_confirmation(fact):
    """An explicitly sourced author decision does not depend on draft status.

    Source text is a declaration, not proof of authorship; an editor must verify
    the cited author decision. Requiring both fields prevents a mislabeled
    accepted prose fact from silently receiving this exception.
    """
    return (fact["layer"] == "author_confirmed" and fact["basis"] == "author_confirmed"
            and text_of(fact.get("source")))


def validate_baseline(ledger, before_chapter=None, chapters_dir=None):
    """Validate exactly the facts which could be used for this comparison.

    status checks all baseline layers; check uses only earlier chapters. Bad
    facts remain visible as problems and cannot become an apparent match by
    falling back to an older value for the same entity/attribute.
    """
    def in_scope(number):
        return before_chapter is None or number < before_chapter

    base = sorted((f for f in ledger["facts"] if f["layer"] in BASELINE_LAYERS
                   and in_scope(f["chapter"])), key=lambda f: (f["chapter"], f["_order"]))
    chapter_files = []
    if chapters_dir is not None:
        for key, info in sorted(ledger["chapters"].items(), key=lambda kv: int(kv[0])):
            if info["status"] not in BASELINE_LAYERS or not in_scope(int(key)):
                continue
            issue = {"chapter": int(key), "file": info.get("file")}
            if not text_of(info.get("file")) or not text_of(info.get("sha256")):
                issue.update(problem="CHAPTER_BINDING_MISSING", detail="请求核对原章，但该章缺少文件名或采纳时的 SHA-256。")
            else:
                root = Path(chapters_dir).resolve()
                path = (root / info["file"]).resolve()
                if Path(info["file"]).is_absolute() or not path.is_relative_to(root):
                    issue.update(problem="CHAPTER_PATH_OUTSIDE_ROOT", detail="原章路径超出指定正文目录，拒绝读取。")
                elif not path.is_file():
                    issue.update(problem="UNAVAILABLE", detail="无法读取该章原文，不能核实事实来源版本。")
                elif sha(path.read_bytes()) != info["sha256"]:
                    issue.update(problem="TEXT_CHANGED_SINCE_ACCEPTED", detail="原章已不是采纳时的版本，需要重新核对账本。")
            if "problem" in issue:
                chapter_files.append(issue)
    file_issues = {entry["chapter"]: entry for entry in chapter_files}
    problems, last = [], {}
    previous = story_predecessors(ledger, base)
    by_key_chapter = {}
    for fact in base:
        by_key_chapter.setdefault((fact["entity"], fact["attribute"]), {}).setdefault(fact["chapter"], []).append(fact)
    for fact in base:
        def problem(code, detail):
            problems.append({"fact": fact["id"], "chapter": fact["chapter"], "entity": fact["entity"],
                             "attribute": fact["attribute"], "problem": code, "detail": detail})

        confirmed = author_confirmation(fact)
        chapter_info = ledger["chapters"].get(str(fact["chapter"]))
        if fact["layer"] == "author_confirmed" and not confirmed:
            problem("AUTHOR_CONFIRMATION_REQUIRED", "author_confirmed 事实需要 basis=author_confirmed，并在 source 明示作者确认来源。")
        if not confirmed:
            if chapter_info is None:
                problem("SOURCE_CHAPTER_UNLISTED", "来源章未登记，不能确认正文已采纳；请补章节状态或标为非基线层。")
            elif chapter_info["status"] not in BASELINE_LAYERS:
                problem("SOURCE_CHAPTER_NOT_ACCEPTED", "来源章状态是 %s，该事实不能继续作为已采纳正文基线。" % chapter_info["status"])
            if fact["chapter"] in file_issues:
                issue = file_issues[fact["chapter"]]
                problem(issue["problem"], issue["detail"])
        if fact["basis"] in INDIRECT and not reported(fact["attribute"]) and not is_unknown(fact["value"]):
            problem("INDIRECT_BASIS_ACCEPTED", "已采纳的实际状态只靠%s支撑；应改记为 record./belief. 属性或补直接证据。" % fact["basis"])
        key = (fact["entity"], fact["attribute"])
        # r5.51: a who-knows-what chain whose facts all carry story time is read in story order, so an accepted
        # flashback (chapter 3 at 09:00, before the chapter-2 learning moment at 10:00) is not an unexplained change.
        if fact["id"] in previous:
            prior = previous[fact["id"]]
        elif is_knowledge(fact["attribute"]):
            # r5.51, fourth review: a who-knows-what fact with no usable story time is compared with the facts of the
            # nearest earlier chapter as a group, not with whichever fact happens to be listed just before it (within a
            # chapter the list order says nothing about story order); facts that cannot be ordered at all are left to
            # the story-order check of the whole chain below.
            earlier = [c for c in by_key_chapter[key] if c < fact["chapter"]]
            group = by_key_chapter[key][max(earlier)] if earlier else []
            prior = group[0] if group and one_value(group) else None
        else:
            prior = last.get(key)
        if prior and not same(prior["value"], fact["value"]) and fact.get("change") is not True:
            problem("UNEXPLAINED_CHANGE", "与 %s 的值不同，但没有标为 change。" % prior["id"])
        last[key] = fact
    # r5.51, third review: the story-time reading must not let through what no order can explain, e.g. "knows" and
    # "does not know" at the same minute with no change written.
    flagged = {(p["entity"], p["attribute"]) for p in problems}
    chains = {}
    for fact in base:
        if is_knowledge(fact["attribute"]) and not is_unknown(fact["value"]):
            chains.setdefault((fact["entity"], fact["attribute"]), []).append(fact)
    for key, chain in chains.items():
        if key in flagged or len(chain) < 2 or chain_orderable(ledger, chain) is not False:
            continue
        culprits = [f for f in chain if chain_orderable(ledger, [g for g in chain if g is not f]) is True] or chain
        fact = max(culprits, key=lambda f: (f["chapter"], f["_order"]))
        problems.append({"fact": fact["id"], "chapter": fact["chapter"], "entity": fact["entity"], "attribute": fact["attribute"],
                         "problem": "UNEXPLAINED_CHANGE",
                         "detail": "按故事时间排，和 %s 怎么排先后都有一处值变了却没写变化（例如同一时刻写了知道又写不知道）。"
                                   % "、".join(f["id"] for f in chain if f is not fact)})
    blocked_keys = {(p["entity"], p["attribute"]) for p in problems}
    usable = [f for f in base if (f["entity"], f["attribute"]) not in blocked_keys]
    return {"facts": usable, "problems": problems, "chapter_files": chapter_files}


def story_predecessors(ledger, facts):
    """For each known_by.<person> fact that carries story time, the fact that comes just before it in story time
    among the facts of its chain that also carry story time (None when there is none, or when that cannot be told:
    two candidates whose order is unknown and whose values differ, or a fact overlapping it with another value).
    Facts without story time are left out and keep the chapter order (r5.51, review rounds 1 and 2)."""
    chains = {}
    for fact in facts:
        if is_knowledge(fact["attribute"]):
            chains.setdefault((fact["entity"], fact["attribute"]), []).append(fact)
    previous = {}
    for chain in chains.values():
        timed = [f for f in chain if fact_span(ledger, f) is not None and fact_span(ledger, f)["day"] is not None]
        for fact in timed:
            span = fact_span(ledger, fact)
            earlier = [f for f in timed if f is not fact and strictly_before(fact_span(ledger, f), span)]
            overlapping = [f for f in timed if f is not fact and not strictly_before(fact_span(ledger, f), span)
                           and not strictly_before(span, fact_span(ledger, f)) and not same(f["value"], fact["value"])]
            tops = last_in_force(ledger, earlier) if earlier else []
            if overlapping or len({json.dumps(f["value"], sort_keys=True) for f in tops}) > 1:
                previous[fact["id"]] = None
            else:
                previous[fact["id"]] = max(tops, key=lambda f: (fact_span(ledger, f)["end"], fact_span(ledger, f)["start"], f["chapter"], f["_order"])) if tops else None
    return previous


def baseline(ledger, chapter):
    return validate_baseline(ledger, before_chapter=chapter)["facts"]


def latest(facts, entity, attribute):
    hits = [f for f in facts if f["entity"] == entity and f["attribute"] == attribute]
    return hits[-1] if hits else None


def public(fact):
    return {k: v for k, v in fact.items() if not k.startswith("_")} if fact else None


def status(ledger, chapters_dir=None):
    listed = sorted(int(k) for k in ledger["chapters"])
    accepted = sorted(int(k) for k, v in ledger["chapters"].items() if v["status"] in BASELINE_LAYERS)
    others = sorted(int(k) for k, v in ledger["chapters"].items() if v["status"] not in BASELINE_LAYERS)
    # Progress is the unbroken run of accepted chapters that starts at the first
    # listed chapter. It stops before a chapter that is not accepted and before a
    # chapter that is missing from the ledger (status unknown); the highest
    # chapter number on file is never taken as progress by itself.
    through = None
    for number in range(listed[0], listed[-1] + 1) if listed else []:
        if number not in accepted:
            break
        through = number
    gaps = [n for n in range(listed[0], listed[-1] + 1) if n not in listed] if listed else []
    validation = validate_baseline(ledger, chapters_dir=chapters_dir)
    problems, stale = validation["problems"], validation["chapter_files"]
    blocking = bool(problems or stale)
    return {"status": "LEDGER_PROBLEMS" if blocking else "OK",
            "accepted_from_chapter": listed[0] if listed and through is not None else None,
            "accepted_through_chapter": through,
            "accepted_chapters": accepted, "non_accepted_chapters": others, "unlisted_chapters_in_range": gaps,
            "note": ("进度只算从账上第一章起连续采纳的部分：遇到未采纳或未登记（状态未知）的章节就停，不按最大章号；"
                     "账上第一章之前的章节状态也未知；候选、摘要和计划不进入基线。"),
            "problems": problems, "chapter_files": stale}


def is_knowledge(attribute):
    """known_by.<person>: what a person in the story knows (r5.51). The reader's knowledge is not one of them."""
    return attribute.startswith(KNOWN) and attribute not in READER and bool(attribute[len(KNOWN):].strip())


def fact_span(ledger, fact):
    """A fact's own time (taking the day from its chapter's story_time when the time has no day and the chapter is
    one day), else the story time of its chapter, else None: only the chapter order is known."""
    frame = (ledger["chapters"].get(str(fact["chapter"])) or {}).get("_span")
    return with_day(fact["_span"], frame) if fact["_span"] else frame


def label(fact, span):
    when = "故事时间 %s" % span["text"] if span else "故事时间未写"
    return "%s（第%d章，%s）" % (fact["id"], fact["chapter"], when)


def boolean(value):
    return isinstance(value, bool)


def words(value):
    """How to say "became this value" and "already had this value" for a knowledge claim (r5.51)."""
    if value is True:
        return "才得知", "已经知道"
    return "才变成这个值", "已经是这个值"


def knowledge_notes(ledger, claim, chapter):
    """What must not be read as the person having learned it: the reader's knowledge, the person's guesses or beliefs,
    and facts that sit in drafts, candidates, summaries or plans (r5.51). Notes only; they never support a claim."""
    person = claim["attribute"][len(KNOWN):]
    notes = []
    for fact in ledger["facts"]:
        if fact["entity"] != claim["entity"] or fact["chapter"] >= chapter:
            continue
        if fact["attribute"] in READER and fact["layer"] in BASELINE_LAYERS and fact["value"] is True:
            notes.append("读者已经知道（%s，第%d章），不等于%s知道。" % (fact["id"], fact["chapter"], person))
        elif fact["attribute"].startswith("belief.%s." % person):
            notes.append("%s 的猜测或看法（%s：%s），不算%s已经知道。" % (fact["id"], fact["attribute"],
                                                                json.dumps(fact["value"], ensure_ascii=False), person))
        elif fact["attribute"] == claim["attribute"] and fact["layer"] not in BASELINE_LAYERS:
            notes.append("%s 在 %s 层（第%d章），废稿、候选、摘要和计划都不算证据。" % (fact["id"], fact["layer"], fact["chapter"]))
    return notes


def comes_after(ledger, later, earlier):
    """`later` is after `earlier` in story time: strictly, or at the same single moment when only `later` writes the
    change (the letter is in his hand, then he opens it: both at 10:00, the change is the later one) (r5.51)."""
    a, b = fact_span(ledger, later), fact_span(ledger, earlier)
    if strictly_before(b, a):
        return True
    return (a is not None and b is not None and a["day"] is not None and a["day"] == b["day"]
            and a["start"] == a["end"] == b["start"] == b["end"]
            and later.get("change") is True and earlier.get("change") is not True and not same(later["value"], earlier["value"]))


def last_in_force(ledger, facts):
    """The facts that nothing else in `facts` comes after in story time. More than one means their order is unknown
    (a whole-day chapter time against a time inside that day, or the same moment twice)."""
    return [f for f in facts if not any(other is not f and comes_after(ledger, other, f) for other in facts)]


def one_value(facts):
    return len({json.dumps(f["value"], sort_keys=True, ensure_ascii=False) for f in facts}) == 1


def first_after(ledger, after):
    return sorted(after, key=lambda f: (fact_span(ledger, f)["start"], fact_span(ledger, f)["end"], f["chapter"], f["_order"]))


UNRECORDED = "\0unrecorded-before-"  # r5.51: an assumed change nobody wrote down, just before an accepted fact


def orderable(events, extra=(), strict_change=True, budget=200000):
    """r5.51, third review: is there an order of these events, consistent with what is known of their story times, in
    which every one of them holds? Each event is {"id", "span", "kind", "value"}: kind "eq" (the state is this value
    there), "ne" (it is not), or "chg" (it becomes this value there; with strict_change the value just before was
    another one, which is what "这才知道" says, unless it is the same change as the last one, told again at a time
    that may be the same). The state changes only at a "chg"; an event whose time cannot be compared with another's
    may fall before or after it (the same moment may be told in either order). `extra` adds (earlier id, later id)
    pairs. Only orders the known times allow are walked, so long, mostly ordered chains are cheap. Returns True,
    False, or None when the search would take too long (more than `budget` distinct steps)."""
    n = len(events)
    index = {e["id"]: k for k, e in enumerate(events)}
    pred = [0] * n
    for i, a in enumerate(events):
        for j, b in enumerate(events):
            if i != j and strictly_before(a["span"], b["span"]):
                pred[j] |= 1 << i
    for earlier, later in extra:
        if earlier in index and later in index:
            pred[index[later]] |= 1 << index[earlier]
    values = {e["value"] for e in events}
    domain = {"true", "false"} if values <= {"true", "false"} else values | {"\0other"}

    def coincide(a, b):
        return not strictly_before(a, b) and not strictly_before(b, a)

    def retold(state, mask, event):
        """The same change told again: the two tellings may be the same moment, and so may everything told between."""
        last, since = state[2], state[3]
        if last is None:
            return False
        first = events[index[last]]["span"]
        between = [events[k]["span"] for k in range(n) if mask >> k & 1 and not since >> k & 1]
        return coincide(first, event["span"]) and all(coincide(x, first) and coincide(x, event["span"]) for x in between)

    def step(state, mask, event):
        kind, value = event["kind"], event["value"]
        here = mask | 1 << index[event["id"]]
        if state[0] == "val":
            if kind == "eq":
                if state[1] == value:
                    return state
                # an accepted state written after the claimed scene may follow a change nobody wrote down there
                after = event.get("jump_after")
                return ("val", value, None, 0) if after in index and mask >> index[after] & 1 else None
            if kind == "ne":
                return state if state[1] != value else None
            if state[1] != value:
                return ("val", value, event["id"], here)
            return state if (not strict_change or not event.get("strict", True) or retold(state, mask, event)) else None
        excluded = state[1]
        if kind == "eq":
            return ("val", value, None, 0) if value not in excluded else None
        if kind == "ne":
            left = excluded | {value}
            return ("free", left) if domain - left else None
        return ("val", value, event["id"], here) if (domain - excluded - {value} or not strict_change) else None

    full, seen, stack = (1 << n) - 1, set(), [(0, ("free", frozenset()))]
    while stack:
        mask, state = stack.pop()
        if mask == full:
            return True
        if (mask, state) in seen:
            continue
        seen.add((mask, state))
        if len(seen) > budget:
            return None
        for k in range(n):
            if not mask >> k & 1 and pred[k] & mask == pred[k]:
                following = step(state, mask, events[k])
                if following is not None:
                    stack.append((mask | 1 << k, following))
    return False


def single_point(span):
    return span is not None and span["day"] is not None and span["start"] == span["end"]


def fact_event(ledger, fact):
    return {"id": fact["id"], "span": fact_span(ledger, fact), "kind": "chg" if fact.get("change") is True else "eq",
            "value": json.dumps(fact["value"], sort_keys=True, ensure_ascii=False)}


def claim_event(cid, claim, span, kind=None):
    if kind is None:
        kind = "chg" if claim.get("change") is True and claim["basis"] in DIRECT else "eq"
    return {"id": cid, "span": span, "kind": kind, "value": json.dumps(claim["value"], sort_keys=True, ensure_ascii=False)}


def merge_retellings(events, foldable=None, anchors=None):
    """A claim's change with the same value at the same single moment as an earlier event's change is that change
    told again: turn it into an "eq" just after it. Only events in `foldable` (the candidate's claims) are folded;
    accepted facts at one moment stay separate events (orderable's retelling rule covers them, and folding them would
    hide a forget-learn-forget within one minute)."""
    kept, extra = [], []
    for event in events:
        twin = None if foldable is not None and event["id"] not in foldable else next(
            (k for k in kept if (anchors is None or k["id"] in anchors) and k["kind"] == "chg" and event["kind"] == "chg"
             and k["value"] == event["value"]
                     and single_point(k["span"]) and single_point(event["span"])
                     and k["span"]["start"] == event["span"]["start"] and k["span"]["day"] == event["span"]["day"]), None)
        if twin is not None:
            event = dict(event, kind="eq")
            extra.append((twin["id"], event["id"]))
        kept.append(event)
    return kept, extra


def chain_orderable(ledger, chain):
    """For the ledger self-check: can these accepted facts on one known_by key be put in some story order in which a
    value only changes where a change is written? (Two learnings in a row are not checked here.)"""
    return orderable([fact_event(ledger, f) for f in chain], strict_change=False)


def story_adjudicate(ledger, results, valid, claim_spans, facts, first=None):
    """r5.51, third review: the last word on each who-knows-what claim. Put the accepted facts on the same key, the
    chapter's own direct changes (change: true) and the claim in every story order their times allow. If no order
    fits, the claim contradicts them (TIME_CONFLICT or CONFLICT), whatever the earlier steps said. If some order fits,
    it is not a contradiction: an earlier conflict becomes KNOWLEDGE_PENDING (the order cannot be told, or only the
    chapter's own, unaccepted change makes it fit), unless the first step (knowledge_result, `first`) had found it
    consistent or a proposed change and only the same-chapter step turned it into a conflict: then that answer comes
    back. A CONSISTENT stays only if no change to another value can come between the fact it relies on and the scene
    (a retelling of the very change it relies on is the same moment). The chapter's own changes are never evidence for
    CONSISTENT."""
    by_id = {r["claim"]: r for r in results}
    first = first or {}
    conflicts = ("CONFLICT", "TIME_CONFLICT")
    shown = lambda ids: [("%s 之前可能没记下的一次变化" % i[len(UNRECORDED):]) if i.startswith(UNRECORDED) else i for i in ids]
    for cid, claim in valid.items():
        result, span = by_id[cid], claim_spans.get(cid)
        if (is_unknown(claim["value"]) or claim["basis"] not in DIRECT
                or result["status"] not in conflicts + ("CONSISTENT", "NO_BASELINE", "KNOWLEDGE_PENDING", "CHANGE_PROPOSED")):
            continue
        key = (claim["entity"], claim["attribute"])
        accepted = [f for f in facts if (f["entity"], f["attribute"]) == key and not is_unknown(f["value"])]
        facts_by_id_all = {f["id"]: f for f in accepted}
        a_events = [fact_event(ledger, f) for f in accepted]
        others = [(oid, o) for oid, o in valid.items()
                  if oid != cid and (o["entity"], o["attribute"]) == key and o.get("change") is True
                  and o["basis"] in DIRECT and not is_unknown(o["value"])]
        k_events = [claim_event(oid, o, claim_spans.get(oid), "chg") for oid, o in others]
        c_event = claim_event(cid, claim, span)
        events, extra = merge_retellings(a_events + k_events + [c_event], foldable={e["id"] for e in k_events} | {cid},
                                         anchors={e["id"] for e in a_events})
        by_event = {e["id"]: e for e in events}
        a_ids = {e["id"] for e in a_events}
        k_ids = {e["id"] for e in k_events if by_event[e["id"]]["kind"] == "chg"}
        all_own = set(k_ids)
        relaxed = False
        own_all = all_own | ({cid} if by_event[cid]["kind"] == "chg" else set())
        supplied = orderable([by_event[i] for i in a_ids | own_all], extra) is True
        if not supplied and orderable([by_event[i] for i in a_ids], extra) is False:
            # Accepted changes to a value it already had (the ledger self-check lets that through: "知道" and then
            # "这才知道" again, or "还不知道" and then "忘了") read two ways: the same change told again, or a change
            # back that nobody wrote down, somewhere before it. Find the fewest of them (later ones first) that,
            # read the second way, let the accepted facts fit, and keep both readings open: each gets an unrecorded
            # change back at an unknown time before it. Any order that fits is still not a contradiction.
            changes = sorted((i for i in a_ids if by_event[i]["kind"] == "chg"),
                             key=lambda i: ((fact_span(ledger, facts_by_id_all[i]) or {"start": (0, 0)})["start"],
                                            facts_by_id_all[i]["chapter"], i), reverse=True)

            def unrecorded(combo):
                added, edges, dropped = [], [], set()
                for i in combo:
                    value = by_event[i]["value"]
                    if value in ("true", "false"):
                        added.append({"id": UNRECORDED + i, "span": None, "kind": "chg",
                                      "value": "false" if value == "true" else "true"})
                        edges.append((UNRECORDED + i, i))
                    else:
                        dropped.add(i)  # not a yes/no value: read only as told again
                return added, edges, dropped
            for size in (1, 2, 3):
                found = None
                for combo in itertools.combinations(changes, size):
                    added, edges, dropped = unrecorded(combo)
                    if orderable([by_event[i] for i in a_ids - dropped] + added, list(extra) + edges) is True:
                        found = (added, edges, dropped)
                        break
                if found:
                    added, edges, dropped = found
                    by_event.update((e["id"], e) for e in added)
                    a_ids = (a_ids - dropped) | {e["id"] for e in added}
                    extra = list(extra) + edges
                    relaxed = True
                    break
        if not supplied and orderable([by_event[i] for i in a_ids], extra) is not True:
            continue  # the accepted facts cannot be ordered even with the chapter's changes; the ledger check reports that
        # Which of the chapter's own changes count. They are taken as written unless they cannot all hold together
        # with the accepted facts; then the largest set that can counts, earlier ones (by story time, then id) first.
        # A change claim is part of that set: it holds if it fits beside the chapter's earlier changes that count
        # (a later change that repeats or contradicts it is the one at fault). Any other claim holds if it fits
        # with at least one largest set of them.
        pick = lambda ids: [by_event[i] for i in ids] + [by_event[cid]]
        changes_here = by_event[cid]["kind"] == "chg"
        if not changes_here:
            # For a claim that writes no change: an accepted "he knows" (a state, not a change) with a story time,
            # placed after the scene, says he knew by then, not since when; he may have learned it off the page in
            # between (only an accepted change, "这才知道", says he did not know just before). Learning off the page
            # is ordinary; forgetting is not, so this holds only for "knows" (true).
            for i in a_ids:
                if by_event[i]["kind"] == "eq" and by_event[i]["value"] == "true":
                    by_event[i] = dict(by_event[i], jump_after=cid)
        prio = lambda i: (((0,) + claim_spans[i]["start"]) if claim_spans.get(i) else (1, 0, 0), i)
        members = sorted(k_ids | ({cid} if changes_here else set()), key=prio)
        if len(members) > 8:
            if result["status"] == "CONSISTENT":
                result.update(status="KNOWLEDGE_PENDING", reason="待核：本章在这件事上写的变化太多，按故事时间的最后一步没有做，要编辑按正文判断。")
            continue
        holds = lambda ids: orderable([by_event[i] for i in a_ids | set(ids)], extra) is True
        good = [g for g in (frozenset(m for b, m in enumerate(members) if mask >> b & 1) for mask in range(1 << len(members)))
                if holds(g)]
        if not good:
            continue
        chosen = max(good, key=lambda g: tuple(m in g for m in members))
        largest = [g for g in good if not any(g < h for h in good)]
        first_ones = {m for m in chosen if m != cid and strictly_before(claim_spans.get(m), span)}
        if changes_here:
            worlds = [g - {cid} for g in good if cid in g and first_ones <= g]
        else:
            worlds = [g for g in largest if orderable(pick(a_ids | g), extra) is True]
        k_ids = set(chosen) - {cid}
        fits = bool(worlds)
        became, already = words(claim["value"])
        scene = "本场（故事时间 %s）" % span["text"] if span else "本场（故事时间未写）"
        facts_by_id = {f["id"]: f for f in accepted}
        if fits is False:
            blame_ids = first_ones if changes_here else set(chosen)
            if result["status"] in conflicts or orderable(pick(a_ids | blame_ids), extra) is not False:
                continue
            culprits = [i for i in a_ids | blame_ids if orderable(pick((a_ids | blame_ids) - {i}), extra) is True]
            status, reason, relied = "TIME_CONFLICT", None, None
            own = sorted(i for i in culprits if i in k_ids)
            mine = [facts_by_id[i] for i in culprits if i in facts_by_id]
            if own:
                oid = own[0]
                ospan = claim_spans.get(oid)
                if strictly_before(ospan, span) and same(valid[oid]["value"], claim["value"]) and changes_here:
                    reason = "本章自相矛盾：%s 已经写 %s 那时%s，这一场（故事时间 %s）又写成这时%s。" % (oid, ospan["text"], became, span["text"], became)
                elif strictly_before(ospan, span) and not same(valid[oid]["value"], claim["value"]) and not changes_here:
                    reason = ("本章自相矛盾：%s 写 %s 那时变成 %s，这一场（故事时间 %s）写的却是 %s，又没写变化。"
                              % (oid, ospan["text"], json.dumps(valid[oid]["value"], ensure_ascii=False), span["text"],
                                 json.dumps(claim["value"], ensure_ascii=False)))
                elif span and ospan and strictly_before(span, ospan) and same(valid[oid]["value"], claim["value"]) and not changes_here:
                    reason = "本章自相矛盾：%s 写 %s 那时%s，这一场（故事时间 %s）却%s。" % (oid, ospan["text"], became, span["text"], already)
                else:
                    reason = "本章自相矛盾：本章 %s 写的变化，放在这一场前面或后面都和它对不上。" % "、".join(own)
            elif mine:
                fact = min(mine, key=lambda f: abs(fact_span(ledger, f)["start"][1] - (span["start"][1] if span else 0)) if fact_span(ledger, f) else 0)
                fspan, relied = fact_span(ledger, fact), fact
                where = label(fact, fspan)
                if strictly_before(span, fspan) and fact.get("change") is True and same(fact["value"], claim["value"]):
                    reason = ("已采纳的 %s写那时%s（change）；%s早于它，不能写成%s。要改这一场，或者写出更早的变化并请作者改那一章。"
                              % (where, became, scene, already)) if not changes_here else (
                              "已采纳的 %s写那时%s（change）；本章把这次变化提前到%s，和它冲突，要改本章，或请作者改那一章。" % (where, became, scene))
                elif strictly_before(span, fspan) and not same(fact["value"], claim["value"]) and fact.get("change") is not True:
                    reason = "已采纳的 %s 在%s之后还是 %s，中间没有写变化，和本场对不上；要改本章，或请作者改那一章。" % (
                        where, scene, json.dumps(fact["value"], ensure_ascii=False))
                elif strictly_before(fspan, span) and not same(fact["value"], claim["value"]) and not changes_here:
                    status = "CONFLICT"
                    reason = "在%s，已经生效的是 %s，值不同，且没有作为有直接证据的变化写出。" % (scene, where)
                elif strictly_before(fspan, span) and same(fact["value"], claim["value"]) and changes_here:
                    reason = "本章写这时%s（change），但 %s 在%s之前就%s。" % (became, where, scene, already)
                else:
                    reason = ("和已采纳的 %s 按故事时间排不通：本章的变化放在哪里都对不上。" % where if blame_ids
                              else "和已采纳的 %s 按故事时间排不通：已采纳的几条事实怎么排先后，这一场都对不上。" % where)
            else:
                reason = "和 %s 按故事时间排不通：怎么排先后都对不上。" % "、".join(shown(sorted(a_ids | blame_ids)))
            result.update(status=status, reason=reason, baseline=public(relied) if relied else result.get("baseline"))
            continue
        def robust(relied):
            if relied is None or (relied["id"], cid) in extra:
                return relied is not None
            # The chapter's own changes are never evidence for CONSISTENT, not even to rule out one another: each
            # of its changes away from the claimed value is weighed on its own, beside the accepted facts.
            negation = dict(by_event[cid], id="\0negation", kind="ne")
            edge = list(extra) + [(relied["id"], "\0negation")]
            if orderable([by_event[i] for i in a_ids] + [negation], edge) is not False:
                return False
            for i in sorted(all_own - {cid}):
                if by_event[i]["value"] != by_event[cid]["value"]:
                    if orderable([by_event[j] for j in a_ids | {i}] + [negation], edge) is not False:
                        return False
            return True

        before = first.get(cid)
        if before and before["status"] in ("CONSISTENT", "CHANGE_PROPOSED", "NO_BASELINE") and result["status"] != before["status"]:
            back = before["status"] != "CONSISTENT" or robust(facts_by_id.get((before.get("baseline") or {}).get("id")))
            if back and (result["status"] in conflicts or before["status"] == "CONSISTENT"):
                result.update(status=before["status"], reason=before["reason"], baseline=before.get("baseline"))
                continue
        if result["status"] in conflicts:
            if before and before["status"] == "KNOWLEDGE_PENDING" and orderable(pick(a_ids), extra) is True:
                # The accepted facts alone fit the scene and the first step had already said why it is pending
                # (say, the only evidence takes effect after the scene); only the same-chapter step made it a conflict.
                result.update(status="KNOWLEDGE_PENDING", reason=before["reason"], baseline=before.get("baseline"))
                continue
            relied = facts_by_id.get((result.get("baseline") or {}).get("id"))
            where = label(relied, fact_span(ledger, relied)) if relied else "前文"
            if orderable(pick(a_ids), extra) is not True and k_ids:
                needed = sorted(i for i in k_ids if orderable(pick(a_ids | k_ids - {i}), extra) is not True) or sorted(k_ids)
                reason = ("待核：按已采纳的 %s 看和这一场对不上，但本章 %s 写的变化可以排在中间，讲得通；本章的变化还没采纳，不能当证据，要作者看。"
                          % (where, "、".join(needed)))
            else:
                loose = sorted(e["id"] for e in pick(a_ids | k_ids)
                               if e["id"] != cid and not strictly_before(e["span"], span) and not strictly_before(span, e["span"]))
                if loose:
                    unclear = " %s 和这一场谁先谁后排不出来" % "、".join(shown(loose))
                else:
                    pool = [by_event[i] for i in a_ids | k_ids]
                    tangled = sorted({x["id"] for x in pool for y in pool if x is not y and x["value"] != y["value"]
                                      and not strictly_before(x["span"], y["span"]) and not strictly_before(y["span"], x["span"])})
                    unclear = ("已采纳的 %s 彼此谁先谁后排不出来" % "、".join(shown(tangled))) if tangled else "几条事实的先后排不出来"
                clash = (sorted(i for i in k_ids if orderable(pick(a_ids | {i}), extra) is not True)
                         if orderable(pick(a_ids), extra) is True else [])
                unwritten = [i[len(UNRECORDED):] for i in loose if i.startswith(UNRECORDED)]
                if unwritten and len(unwritten) == len(loose) and not clash:
                    # Only a change the ledger implies but never wrote down can put this scene right.
                    reason = ("待核：按已采纳的 %s 看和这一场对不上；但已采纳的 %s 写的变化，前面已经是这个值了，说明中间还有一次变化"
                              "账上没记、不知道在什么时候，可能就在这一场之前，讲得通。要编辑或作者按正文判断，或请作者在账本里补上那次变化。"
                              % (where, "、".join(label(facts_by_id[i], fact_span(ledger, facts_by_id[i])) for i in unwritten)))
                elif clash:
                    # The accepted facts agree with the scene; the doubt comes from the chapter's own change.
                    reason = ("待核：已采纳的事实和这一场对得上，但本章 %s 写的变化和这一场对不上；%s（只知道章节先后、没写第几天、"
                              "时间重叠或在同一时刻），有一种先后讲得通；本章的变化还没采纳，要编辑或作者按正文判断。"
                              % ("、".join(clash), unclear.strip()))
                else:
                    reason = ("待核：按已采纳的 %s 看和这一场对不上，但%s（只知道章节先后、没写第几天、时间重叠或在同一时刻），"
                              "有一种先后讲得通，要编辑或作者按正文判断。" % (where, unclear))
            result.update(status="KNOWLEDGE_PENDING", reason=reason)
        elif result["status"] == "CONSISTENT":
            relied = facts_by_id.get((result.get("baseline") or {}).get("id"))
            if relied is None:
                continue
            if not robust(relied):
                pool = [by_event[i] for i in a_ids | k_ids]
                rspan = fact_span(ledger, relied)
                between = sorted(e["id"] for e in pool if e["kind"] == "chg" and e["id"] != relied["id"]
                                 and e["value"] != by_event[cid]["value"]
                                 and not strictly_before(e["span"], rspan) and not strictly_before(span, e["span"]))
                result.update(status="KNOWLEDGE_PENDING",
                              reason="待核：%s 在%s之前已经是这个值，但 %s 写了变成别的值的变化，可能排在它和本场之间，先后排不出来。"
                              % (label(relied, rspan), scene, "、".join(shown(between)) or "有一条变化"))


def knowledge_result(ledger, facts, claim, span, stale_time=None):
    """Compare a known_by.<person> claim by story time (r5.51). `facts` are the validated baseline facts for this
    entity and attribute in chapter order (accepted chapters before the current one only). Returns status, reason and
    the fact relied on.

    Evidence that takes effect after the scene never supports it, and the value before a later change is not
    inferred from that change. What comes after the scene is used only to find contradictions, and only the first
    thing after the scene counts (a later forget-and-relearn is not "learned only then"). With only the chapter
    order known the answer is KNOWLEDGE_PENDING."""
    value = claim["value"]
    direct_change = claim.get("change") is True and claim["basis"] in DIRECT
    definite = not is_unknown(value)
    became, already = words(value)
    if span is None:
        prior = facts[-1]
        if stale_time:
            # r5.51 review: the ledger's story_time for this chapter belongs to the accepted earlier version.
            missing = ("本场没有写故事时间（time），claims 文件顶层也没有写 story_time（账本里本章的 story_time %s 属于另一版稿子或已废弃的稿子，"
                       "这一版不沿用它，要在 claims 里重写）" % stale_time)
        else:
            missing = "本场没有写故事时间（time），claims 文件顶层和账本里本章也都没有写 story_time"
        tail = "%s，只能按章节先后比；若本场是倒叙，可能早于 %s。" % (missing, label(prior, fact_span(ledger, prior)))
        if direct_change:
            return "CHANGE_PROPOSED", "本章用直接证据写出知情变化；作者采纳后才能进入基线。" + tail, prior
        if same(prior["value"], value):
            return "KNOWLEDGE_PENDING", "待核：" + tail + "写明故事时间后重跑，或由编辑按正文判断。", prior
        return ("KNOWLEDGE_PENDING", "待核：按章节先后，和已采纳前文 %s 的值不同；但%s若本场确实在它之后，就是矛盾，要改；"
                "写明故事时间后重跑，或由编辑按正文判断。" % (prior["id"], tail), prior)
    before, after, unsure = [], [], []
    for fact in facts:
        place = story_order(fact_span(ledger, fact), span)
        (before if place == "before" else after if place == "after" else unsure).append(fact)
    scene = "本场（故事时间 %s）" % span["text"]
    names = lambda group: "、".join(label(f, fact_span(ledger, f)) for f in group)
    ordered = first_after(ledger, after)
    nxt = ordered[0] if ordered else None
    if nxt is not None and any(f is not nxt and not strictly_before(fact_span(ledger, nxt), fact_span(ledger, f))
                               and (not same(f["value"], nxt["value"]) or (f.get("change") is True) != (nxt.get("change") is True))
                               for f in after):
        # r5.51, third review: several different facts may come first after the scene; which one is next cannot be
        # told, so nothing is concluded from "the next one" here (the ordering check in story_adjudicate decides).
        nxt, ordered = None, []

    def moved_earlier():
        """For a claim that writes the change here: the first accepted fact after the scene contradicts it."""
        if nxt is None:
            return None
        if nxt.get("change") is True and same(nxt["value"], value):
            return ("TIME_CONFLICT", "已采纳的 %s写那时%s（change）；本章把这次变化提前到%s，和它冲突，要改本章，或请作者改那一章。"
                    % (label(nxt, fact_span(ledger, nxt)), became, scene), nxt)
        if nxt.get("change") is not True and not same(nxt["value"], value) and not is_unknown(nxt["value"]):
            return ("TIME_CONFLICT", "本章把变化写在%s，但已采纳的 %s 在那以后还是原来的值，又没写变化，和它冲突；"
                    "要改本章，或请作者改那一章。" % (scene, label(nxt, fact_span(ledger, nxt))), nxt)
        return None

    if before:
        tops = last_in_force(ledger, before)
        if not one_value(tops):
            return ("KNOWLEDGE_PENDING", "待核：%s之前已经生效的有 %s，它们谁在后排不出来，值又不同。" % (scene, names(tops)), tops[0])
        effective = max(tops, key=lambda f: (fact_span(ledger, f)["end"], fact_span(ledger, f)["start"], f["chapter"], f["_order"]))
        where = label(effective, fact_span(ledger, effective))
        differing = [f for f in unsure if not same(f["value"], effective["value"])]
        if differing:
            return ("KNOWLEDGE_PENDING", "待核：%s之前已经生效的是 %s，但 %s 和本场谁先谁后定不了，值又不同。"
                    % (scene, where, names(differing)), effective)
        eff_span = fact_span(ledger, effective)
        strict = strictly_before(eff_span, span)
        same_moment = eff_span["start"] == eff_span["end"] == span["start"] == span["end"]
        if same(effective["value"], value):
            if nxt is not None and nxt.get("change") is True and same(nxt["value"], value):
                return ("KNOWLEDGE_PENDING", "待核：%s 在%s之前已经是这个值，%s 又写成那时%s，已采纳的证据前后对不上。"
                        % (where, scene, label(nxt, fact_span(ledger, nxt)), became), effective)
            if not direct_change:
                if not strict:
                    return "CONSISTENT", "与已采纳前文一致：%s 和%s是同一时刻（或在同一段时间里），写的就是这个值。" % (where, scene), effective
                return "CONSISTENT", "与已采纳前文一致：%s 在%s之前已经生效。" % (where, scene), effective
            earlier = [f for f in before if strictly_before(fact_span(ledger, f), span)]
            prior_tops = last_in_force(ledger, earlier) if earlier else []
            if prior_tops and one_value(prior_tops) and same(prior_tops[0]["value"], value):
                prior = max(prior_tops, key=lambda f: (fact_span(ledger, f)["end"], fact_span(ledger, f)["start"], f["chapter"], f["_order"]))
                return ("TIME_CONFLICT", "本章写这时%s（change），但 %s 在%s之前就%s。"
                        % (became, label(prior, fact_span(ledger, prior)), scene, already), prior)
            if same_moment and effective.get("change") is True:
                return "CONSISTENT", "与已采纳前文一致：%s 写的就是这一刻。" % where, effective
            return ("KNOWLEDGE_PENDING", "待核：%s 和%s落在同一时刻或同一段时间里，分不清本章写的变化是不是同一次。" % (where, scene), effective)
        if direct_change:
            found = moved_earlier()
            if found:
                return found
            if not strict:
                return ("KNOWLEDGE_PENDING", "待核：%s 和%s落在同一时刻或同一段时间里，分不清变化是在它之前还是之后。" % (where, scene), effective)
            return "CHANGE_PROPOSED", "本章用直接证据写出知情变化（%s之前是 %s）；作者采纳后才能进入基线。" % (scene, where), effective
        if is_unknown(effective["value"]) and definite:
            return ("UNSUPPORTED", "%s之前已经生效的 %s 是未知，本章没有标为变化或缺少直接证据，不能直接写成定论。" % (scene, where), effective)
        if not strict:
            return ("KNOWLEDGE_PENDING", "待核：%s 和%s落在同一时刻或同一段时间里，值不同，分不清是变化之前还是之后。" % (where, scene), effective)
        return "CONFLICT", "在%s，已经生效的是 %s，值不同，且没有作为有直接证据的变化写出。" % (scene, where), effective
    if after and not any(same(f["value"], value) for f in unsure):
        if direct_change:
            found = moved_earlier()
            if found:
                return found
        else:
            for fact in ordered:
                if same(fact["value"], value):
                    if fact.get("change") is True:
                        return ("TIME_CONFLICT", "已采纳的 %s写那时%s（change）；%s早于它，不能写成%s。要改这一场，或者写出更早的变化并请作者改那一章。"
                                % (label(fact, fact_span(ledger, fact)), became, scene, already), fact)
                    break
                if fact.get("change") is True:
                    break  # it changed away from something earlier: no conclusion about the scene
    if direct_change and not before and not after and not unsure:
        return "NO_BASELINE", "已采纳前文没有这项事实，程序无法核对，需要编辑或作者裁定。", None
    if after or unsure:
        parts = []
        if after:
            parts.append("%s 在%s之后才生效，不能支持本场；它写的是那以后的情况，那以前是什么，账上没有已经生效的记录" % (names(after), scene))
        if unsure:
            parts.append("%s 和本场谁先谁后定不了（只知道章节先后，或一边写了第几天、一边没写，或时间只写了钟点、第几天不明，或两段时间重叠）" % names(unsure))
        if direct_change:
            return "CHANGE_PROPOSED", "本章用直接证据写出知情变化；作者采纳后才能进入基线。另：" + "；".join(parts) + "。", (after or unsure)[0]
        return "KNOWLEDGE_PENDING", "待核：" + "；".join(parts) + "。", (after or unsure)[0]
    return "NO_BASELINE", "已采纳前文没有这项事实，程序无法核对，需要编辑或作者裁定。", None


def same_chapter_knowledge(ledger, results, valid, claim_spans):
    """Inside the candidate chapter (r5.51). The chapter's own changes (change: true, direct evidence) are candidates,
    not accepted, so they never make another claim consistent; but they show where the chapter contradicts itself,
    and they keep a claim pending where an accepted fact would say otherwise only because the chapter's own change has
    not been accepted yet. Only the change nearest to a scene counts on each side."""
    by_id = {r["claim"]: r for r in results}
    facts = {f["id"]: f for f in ledger["facts"]}
    open_status = ("NO_BASELINE", "KNOWLEDGE_PENDING", "CHANGE_PROPOSED")
    for cid, claim in valid.items():
        result, span = by_id[cid], claim_spans.get(cid)
        changes = {oid: other for oid, other in valid.items()
                   if oid != cid and (other["entity"], other["attribute"]) == (claim["entity"], claim["attribute"])
                   and other.get("change") is True and other["basis"] in DIRECT}
        if not changes:
            continue
        became, already = words(claim["value"])
        own_change = claim.get("change") is True and claim["basis"] in DIRECT
        earlier = [o for o in changes if strictly_before(claim_spans.get(o), span)]
        later = [o for o in changes if strictly_before(span, claim_spans.get(o))]
        unordered = [o for o in changes if o not in earlier and o not in later]
        tops = [o for o in earlier if not any(strictly_before(claim_spans.get(o), claim_spans.get(x)) for x in earlier)]
        firsts = [o for o in later if not any(strictly_before(claim_spans.get(x), claim_spans.get(o)) for x in later)]
        decided = False
        relied = facts.get((result.get("baseline") or {}).get("id"))
        if result["status"] == "TIME_CONFLICT" and relied is not None:
            # r5.51, second review: an accepted fact on the other side of the scene contradicts it only if nothing
            # changed in between; this chapter's own change to another value, between the scene and that fact, can
            # explain it. The chapter's change is not accepted, so this is pending, never consistent.
            rspan = fact_span(ledger, relied)
            if strictly_before(span, rspan):
                side, between = "之后", [o for o in later if strictly_before(claim_spans.get(o), rspan)]
            elif own_change and strictly_before(rspan, span):
                side, between = "之前", [o for o in earlier if strictly_before(rspan, claim_spans.get(o))]
            else:
                side, between = "", []
            between = sorted(o for o in between if not same(valid[o]["value"], claim["value"]))
            if between:
                result.update(status="KNOWLEDGE_PENDING",
                              reason="待核：已采纳的 %s 在这一场%s；本章 %s 在这中间写了变化，讲得通，但本章的变化还没采纳，不能当证据。"
                              % (label(relied, rspan), side, "、".join(between)))
        if tops and len({json.dumps(valid[o]["value"], sort_keys=True) for o in tops}) > 1:
            result.setdefault("notes", []).append("本章 %s 写的几处变化谁在后排不出来。" % "、".join(sorted(tops)))
            decided = True
        elif tops:
            top = tops[0]
            if same(valid[top]["value"], claim["value"]):
                if own_change and result["status"] in open_status + ("CONSISTENT",):
                    result.update(status="TIME_CONFLICT", reason="本章自相矛盾：%s 已经写 %s 那时%s，这一场（故事时间 %s）又写成这时%s。"
                                  % (top, claim_spans[top]["text"], became, span["text"], became))
                elif not own_change:
                    note = "本章 %s 写 %s 那时%s；它还没被采纳，不能当作证据。" % (top, claim_spans[top]["text"], became)
                    if result["status"] in ("NO_BASELINE", "KNOWLEDGE_PENDING"):
                        result.setdefault("notes", []).append(note)
                    elif (result["status"] == "CONFLICT" and relied is not None
                          and strictly_before(fact_span(ledger, relied), claim_spans.get(top))):
                        result.update(status="KNOWLEDGE_PENDING",
                                      reason="待核：已采纳的 %s 是原来的值，本章 %s 写 %s 那时%s，这一场在那以后；本章的变化还没采纳，采纳了就一致。"
                                      % (label(relied, fact_span(ledger, relied)), top, claim_spans[top]["text"], became))
            elif not own_change and result["status"] in open_status + ("CONSISTENT",):
                result.update(status="TIME_CONFLICT", reason="本章自相矛盾：%s 写 %s 那时变成 %s，这一场（故事时间 %s）写的却是 %s，又没写变化。"
                              % (top, claim_spans[top]["text"], json.dumps(valid[top]["value"], ensure_ascii=False),
                                 span["text"], json.dumps(claim["value"], ensure_ascii=False)))
            decided = True
        if not decided and firsts and not own_change and result["status"] in ("NO_BASELINE", "KNOWLEDGE_PENDING"):
            if len({json.dumps(valid[o]["value"], sort_keys=True) for o in firsts}) == 1 and same(valid[firsts[0]]["value"], claim["value"]):
                oid = firsts[0]
                result.update(status="TIME_CONFLICT", reason="本章自相矛盾：%s 写 %s 那时%s，这一场（故事时间 %s）却%s。"
                              % (oid, claim_spans[oid]["text"], became, span["text"], already))
                decided = True
        if not decided and unordered and not own_change:
            toward = sorted(o for o in unordered if same(valid[o]["value"], claim["value"]))
            away = sorted(o for o in unordered if not same(valid[o]["value"], claim["value"]))
            # r5.51, second review: a CONFLICT with an accepted earlier fact is explained if this chapter's own change
            # toward the claimed value may come between that fact and the scene (an untimed change may).
            explained = (result["status"] == "CONFLICT" and relied is not None
                         and any(claim_spans.get(o) is None or strictly_before(fact_span(ledger, relied), claim_spans.get(o))
                                 for o in toward))
            if result["status"] in ("NO_BASELINE", "KNOWLEDGE_PENDING") or (result["status"] == "CONSISTENT" and away) or explained:
                parts = []
                if explained:
                    parts.append("已采纳的 %s 是原来的值，这一场排在本章变化前面就和它矛盾" % label(relied, fact_span(ledger, relied)))
                if toward:
                    parts.append("%s 写那时%s：这一场排在它前面就自相矛盾，排在它后面也只能等作者采纳" % ("、".join(toward), became))
                if away:
                    parts.append("%s 写那时变成别的值：这一场排在它前面没问题，排在它后面又没写变化就自相矛盾" % "、".join(away))
                why = unordered_why([span] + [claim_spans.get(o) for o in unordered],
                                    [claim.get("time") is not None] + [valid[o].get("time") is not None for o in unordered])
                result.update(status="KNOWLEDGE_PENDING",
                              reason="待核：本章写了这件事的变化，和这一场谁先谁后排不出来（%s）。" % why + "；".join(parts) + "。")


def check(ledger, claims_path, candidate_override=None, chapters_dir=None):
    claims = load_json(claims_path)
    need(isinstance(claims, dict) and claims.get("schema") == CLAIMS_SCHEMA, "claims schema must be " + CLAIMS_SCHEMA)
    need(type(claims.get("chapter")) is int and claims["chapter"] >= 0, "claims need a nonnegative integer chapter")
    need(isinstance(claims.get("claims"), list), "claims must be a list")
    need(text_of(claims.get("extracted_by")), "claims need extracted_by (self_check / independent_agent / human)")
    chapter_span = parse_span(claims.get("story_time"))
    base_dir = Path(claims_path).resolve().parent
    candidate_path = Path(candidate_override) if candidate_override else base_dir / str(claims.get("candidate", ""))
    need(candidate_path.is_file(), "candidate text not found: " + str(candidate_path))
    data = candidate_path.read_bytes()
    actual = sha(data)
    text = data.decode("utf-8-sig")
    binding = {"path": str(candidate_path), "declared_sha256": claims.get("candidate_sha256"), "actual_sha256": actual,
               "bound": claims.get("candidate_sha256") == actual}
    # r5.51: when the candidate chapter happens in story time, for claims without their own time: the claims file's
    # story_time, else the ledger's entry for this chapter, but only while that entry is not an accepted version of
    # some other text (a rewrite of an accepted chapter must not inherit the old version's time).
    entry = ledger["chapters"].get(str(claims["chapter"])) or {}
    stale_time = None
    if chapter_span is None and entry.get("_span"):
        # r5.51, third review: only the time recorded for this very text (or for an entry without a recorded hash
        # that is not abandoned); a different version's or an abandoned draft's time is not borrowed.
        if entry.get("sha256") == actual or (not text_of(entry.get("sha256")) and entry.get("status") != "abandoned"):
            chapter_span = entry["_span"]
        else:
            stale_time = entry["_span"]["text"]
    validation = validate_baseline(ledger, before_chapter=claims["chapter"], chapters_dir=chapters_dir)
    facts = validation["facts"]
    problems_by_key = {}
    for problem in validation["problems"]:
        problems_by_key.setdefault((problem["entity"], problem["attribute"]), []).append(problem)
    results = []
    knowledge, claim_spans = {}, {}
    for cid, claim in zip(claim_ids(claims["claims"]), claims["claims"]):
        try:
            need(isinstance(claim, dict), "claim must be an object")
            for field in ("entity", "attribute", "basis", "quote"):
                need(text_of(claim.get(field)), "claim %s needs %s" % (cid, field))
            need("value" in claim, "claim %s needs value" % cid)
            need(claim["entity"] in ledger["entities"], "claim %s names an undeclared entity" % cid)
            need(claim["basis"] in DIRECT | INDIRECT, "claim %s has invalid basis" % cid)
            when = parse_time(claim.get("time"))
            own = parse_span(claim.get("time"))
            span = with_day(own, chapter_span) if own else chapter_span
            if is_knowledge(claim["attribute"]):
                # r5.51: "true"/"false" strings would silently switch off the story-time checks of a knowledge claim.
                need("change" not in claim or isinstance(claim["change"], bool),
                     "claim %s: change must be true or false (a JSON boolean, not a string)" % cid)
        except FactError as exc:
            results.append({"claim": cid, "status": "INVALID", "reason": str(exc)})
            continue
        result = {"claim": cid, "entity": claim["entity"], "attribute": claim["attribute"], "value": claim["value"],
                  "basis": claim["basis"], "quote_found": claim["quote"] in text}
        prior = latest(facts, claim["entity"], claim["attribute"])
        result["baseline"] = public(prior)
        physical = not reported(claim["attribute"])
        definite = not is_unknown(claim["value"])
        knows = is_knowledge(claim["attribute"])
        if knows:
            result["story_time"] = span["text"] if span else None
        if not result["quote_found"]:
            result.update(status="QUOTE_NOT_FOUND", reason="引文不在本版候选稿中，无法定位该主张。")
        elif physical and definite and claim["basis"] in INDIRECT:
            result.update(status="UNSUPPORTED",
                          reason="把%s当成实际发生的事。单据、录入时间、转述、推断或计划只能写成“记录显示／某人认为”，"
                                 "不能直接改写事实；改记为 record./belief. 属性或补出直接证据。" % claim["basis"])
        elif (claim["entity"], claim["attribute"]) in problems_by_key:
            result.update(status="LEDGER_PROBLEMS", reason="该属性的前文基线存在账本问题，先修正来源或事实链再核对。",
                          ledger_problems=problems_by_key[(claim["entity"], claim["attribute"])])
        elif knows:
            # r5.51: by story time, not by chapter number; see knowledge_result.
            hits = [f for f in facts if f["entity"] == claim["entity"] and f["attribute"] == claim["attribute"]]
            if hits:
                status_word, reason, relied = knowledge_result(ledger, hits, claim, span, stale_time)
            else:
                status_word, reason, relied = "NO_BASELINE", "已采纳前文没有这项事实，程序无法核对，需要编辑或作者裁定。", None
            result.update(status=status_word, reason=reason, baseline=public(relied))
            notes = knowledge_notes(ledger, claim, claims["chapter"])
            if notes:
                result["notes"] = notes
            knowledge[cid], claim_spans[cid] = claim, span
        elif prior is None:
            result.update(status="NO_BASELINE", reason="已采纳前文没有这项事实，程序无法核对，需要编辑或作者裁定。")
        elif same(prior["value"], claim["value"]):
            result.update(status="CONSISTENT", reason="与已采纳前文一致。")
        elif claim.get("change") is True and claim["basis"] in DIRECT:
            result.update(status="CHANGE_PROPOSED",
                          reason="本章用直接证据写出状态变化；作者采纳后才能进入基线。")
        elif is_unknown(prior["value"]) and definite:
            result.update(status="UNSUPPORTED",
                          reason="前文此项为未知（例如“没有归还记录”），本章没有标为变化或缺少直接证据，不能直接写成定论。")
        else:
            result.update(status="CONFLICT", reason="与已采纳前文 %s 的值不同，且没有作为有直接证据的变化写出。" % prior["id"])
        also = []
        if (result["status"] == "UNSUPPORTED" and not knows and prior and not is_unknown(prior["value"])
                and not same(prior["value"], claim["value"])):
            also.append("同时与已采纳前文 %s（%s）不一致。" % (prior["id"], prior["value"]))
        if when and claim["attribute"] == "first_seen":
            earlier = [f for f in facts if f["entity"] == claim["entity"] and f["_time"] and f["_time"] < when
                       and f["attribute"] in ("first_seen", "seen_at", "present_at")]
            if earlier:
                note = "已采纳前文更早已见到该物件（%s，%s），首次出现时间不能晚于它。" % (earlier[0]["id"], earlier[0].get("time"))
                if result["status"] in ("CONSISTENT", "NO_BASELINE", "CHANGE_PROPOSED"):
                    result.update(status="TIME_CONFLICT", baseline=public(earlier[0]), reason=note)
                else:
                    also.append(note)
        if also:
            result["also"] = also
        results.append(result)
    first = {r["claim"]: dict(r) for r in results if r.get("claim") in knowledge}
    same_chapter_knowledge(ledger, results, knowledge, claim_spans)
    story_adjudicate(ledger, results, knowledge, claim_spans, facts, first)
    for result in results:
        if result.get("claim") in knowledge:
            # The fact labels end in a full-width bracket; no space before the Chinese that follows (r5.51).
            result["reason"] = re.sub(r"） (?=[\u4e00-\u9fff])", "）", result["reason"])
    pending = ("NO_BASELINE", "CHANGE_PROPOSED", "KNOWLEDGE_PENDING")
    counts = {}
    for item in results:
        counts[item["status"]] = counts.get(item["status"], 0) + 1
    blocking = {"CONFLICT", "UNSUPPORTED", "TIME_CONFLICT", "QUOTE_NOT_FOUND", "INVALID"}
    if validation["problems"] or validation["chapter_files"]:
        overall = "LEDGER_PROBLEMS"
    elif not binding["bound"]:
        overall = "STALE"
    elif any(r["status"] in blocking for r in results):
        overall = "CONFLICTS"
    elif any(r["status"] in pending for r in results):
        overall = "NEEDS_HUMAN"
    elif results:
        overall = "CONSISTENT"
    else:
        overall = "UNTESTED"
    review_items = [{"id": "F-" + r["claim"], "status": r["status"],
                     "reason": r["reason"] + ("" if not r.get("notes") else " " + " ".join(r["notes"]))}
                    for r in results if r["status"] in pending]
    watch = watched_states(ledger, facts, claims["claims"], text, chapter_span)
    review_items.extend({"id": w["id"], "status": "WATCH", "reason": w["reason"]} for w in watch)
    return {"tool": "fact_guard", "command": "check", "status": overall, "chapter": claims["chapter"],
            "extracted_by": claims["extracted_by"], "candidate": binding,
            "baseline_rule": ("仅比较 chapter 小于 %d 且通过来源与事实链有效性检查的 accepted/author_confirmed 事实；"
                              "人物知情（known_by.人物）再按故事时间比：本场之后才生效的证据不支持一致，只知道章节先后时待核"
                              % claims["chapter"]),
            "ledger_problems": validation["problems"], "chapter_files": validation["chapter_files"],
            "counts": counts, "results": results, "watch": watch, "review_items": review_items,
            "limits": ("只核对声明的主张，不能发现没有提取的矛盾；主张是否从正文正确提取仍需人工或独立审读。"
                       "故事时间（time、story_time）也是提取时写下的：写错了时间，按时间的判断也会跟着错。"
                       "持续状态只按名字和别名列出，本章是否照顾到它要由审稿判断。")}


def watched_states(ledger, facts, claims, text, span=None):
    """Persistent baseline states whose entity the candidate mentions and no claim answers.

    `facts` is the validated baseline (earlier accepted chapters only), so a state
    whose source chapter is not accepted is never watched as if it were settled.
    """
    answered = {(c.get("entity"), c.get("attribute")) for c in claims if isinstance(c, dict)}
    latest_states, chains, inside = {}, {}, {}
    for fact in facts:  # baseline facts are in chapter order; the last one per state wins
        latest_states[(fact["entity"], fact["attribute"])] = fact
        chains.setdefault((fact["entity"], fact["attribute"]), []).append(fact)
    for key, chain in chains.items():
        # r5.51: who knows what is shown as it stands at this chapter's story time when that can be worked out;
        # changes that fall inside this chapter's story time are named, to be checked scene by scene.
        if is_knowledge(key[1]):
            latest_states[key] = knowledge_state_at(ledger, chain, span) or latest_states[key]
            if span is not None:
                inside[key] = [f for f in chain if fact_span(ledger, f) is not None
                               and story_order(fact_span(ledger, f), span) is None and fact_span(ledger, f)["day"] is not None]
    lines = text.splitlines()
    watch = []
    for (entity, attribute), fact in sorted(latest_states.items(), key=lambda kv: (kv[1]["chapter"], kv[1]["_order"])):
        persistent = fact.get("persist") or (is_knowledge(attribute) and any(f.get("persist") for f in chains[(entity, attribute)]))
        if not persistent or (entity, attribute) in answered:
            continue
        aliases = ledger["entities"][entity]["aliases"]
        where = sorted({number for number, line in enumerate(lines, 1) if any(alias in line for alias in aliases)})
        if not where:
            continue
        value = fact["value"] if isinstance(fact["value"], str) else json.dumps(fact["value"], ensure_ascii=False)
        name = ledger["entities"][entity]["name"]
        watch.append({"id": "W-" + fact["id"], "fact": fact["id"], "entity": entity, "attribute": attribute,
                      "value": fact["value"], "since_chapter": fact["chapter"], "source": fact["source"], "lines": where[:10],
                      "reason": "持续状态：%s 的 %s 是“%s”（%s，第%d章起）。本章第 %s 行提到%s。行动、路线、交接或谁知道什么，"
                                "是否与这个状态一致？一致就写明依据；不一致就改稿，或作为变化写成主张交作者裁定。"
                                % (name, attribute, value, fact["source"], fact["chapter"],
                                   "、".join(str(n) for n in where[:10]), name)
                                + later_note(ledger, fact, attribute, span)
                                + ("" if not inside.get((entity, attribute)) else
                                   "注意：本章的故事时间（%s）里这条知情状态有变化或排不出先后：%s；按每一场写的时间核，不按上面这一个值。"
                                   % (span["text"], "、".join(label(f, fact_span(ledger, f)) for f in inside[(entity, attribute)])))})
    return watch


def knowledge_state_at(ledger, chain, span):
    """The known_by fact in force at `span` (or, with no span, the last one in story time), when the order is clear;
    the first fact after `span` when none is in force yet; None when the story-time order cannot be worked out."""
    spans = [fact_span(ledger, f) for f in chain]
    if any(item is None for item in spans):
        return None
    if span is not None:
        if any(story_order(item, span) is None for item in spans):
            return None
        before = [f for f in chain if story_order(fact_span(ledger, f), span) == "before"]
        group = before or chain
    else:
        group = chain
    tops = last_in_force(ledger, group) if (span is None or before) else group
    if span is not None and not before:
        return min(chain, key=lambda f: (fact_span(ledger, f)["start"], f["chapter"], f["_order"]))
    if len({json.dumps(f["value"], sort_keys=True, ensure_ascii=False) for f in tops}) > 1:
        return None
    return max(tops, key=lambda f: (fact_span(ledger, f)["end"], fact_span(ledger, f)["start"], f["chapter"], f["_order"]))


def later_note(ledger, fact, attribute, span):
    """r5.51: a who-knows-what state that only takes effect after this chapter's story time is not yet in force."""
    if not is_knowledge(attribute) or story_order(fact_span(ledger, fact), span) != "after":
        return ""
    return "注意：这条知情状态在故事时间 %s 才成立，本章（故事时间 %s）早于它，按那时的知情核对。" % (
        fact_span(ledger, fact)["text"], span["text"])


def scan(ledger, candidate):
    text = Path(candidate).read_bytes().decode("utf-8-sig")
    lines = text.splitlines()
    hits = []
    for key, entity in ledger["entities"].items():
        for alias in entity["aliases"]:
            for number, line in enumerate(lines, 1):
                for match in re.finditer(re.escape(alias), line):
                    hits.append({"entity": key, "alias": alias, "line": number, "column": match.start() + 1,
                                 "context": line[max(0, match.start() - 15):match.end() + 15]})
    hits.sort(key=lambda h: (h["line"], h["column"]))
    return {"tool": "fact_guard", "command": "scan", "candidate": str(candidate),
            "sha256": sha(Path(candidate).read_bytes()), "hits": hits,
            "note": "每处命中都要在 claims 里给出主张，或在审稿中说明为何不涉及硬事实。别名之外的写法可能漏掉。"}


def impact(ledger, changed_chapter, entities=None, chapters_dir=None):
    changed = [f for f in ledger["facts"] if f["chapter"] == changed_chapter]
    touched = set(entities or []) | {f["entity"] for f in changed}
    ids = {f["id"] for f in changed}
    later = [f for f in ledger["facts"] if f["chapter"] > changed_chapter and f["layer"] in BASELINE_LAYERS
             and (f["entity"] in touched or ids & set(f.get("depends_on", [])))]
    by_chapter = {}
    for fact in later:
        by_chapter.setdefault(fact["chapter"], []).append({"fact": fact["id"], "entity": fact["entity"],
                                                          "attribute": fact["attribute"], "value": fact["value"],
                                                          "source": fact["source"]})
    text_hits, unavailable = [], []
    if chapters_dir:
        for key, info in sorted(ledger["chapters"].items(), key=lambda kv: int(kv[0])):
            number = int(key)
            if number <= changed_chapter:
                continue
            path = Path(chapters_dir) / info.get("file", "")
            if not info.get("file") or not path.is_file():
                unavailable.append(number)
                continue
            for line_no, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
                for key2 in sorted(touched):
                    for alias in ledger["entities"][key2]["aliases"]:
                        if alias in line:
                            text_hits.append({"chapter": number, "file": info["file"], "line": line_no,
                                              "entity": key2, "alias": alias})
    chapters = sorted(set(by_chapter) | {h["chapter"] for h in text_hits})
    return {"tool": "fact_guard", "command": "impact", "changed_chapter": changed_chapter,
            "entities": sorted(touched), "status": "REGRESSION_REQUIRED" if chapters else "NO_DECLARED_DEPENDENTS",
            "chapters_to_recheck": chapters, "ledger_dependents": by_chapter, "text_hits": text_hits,
            "unavailable_chapters": unavailable,
            "note": "列出的是需要回读的位置，不是结论；未取得的章节标为受限，不能宣称后文已核对。"}


def utf8_stdio():
    """Reports are UTF-8 on every platform; a Windows pipe would otherwise use the local code page."""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    commands = parser.add_subparsers(dest="command", required=True)
    one = commands.add_parser("status")
    one.add_argument("ledger", type=Path)
    one.add_argument("--chapters-dir", type=Path)
    two = commands.add_parser("check")
    two.add_argument("ledger", type=Path)
    two.add_argument("claims", type=Path)
    two.add_argument("--chapters-dir", type=Path)
    three = commands.add_parser("scan")
    three.add_argument("ledger", type=Path)
    three.add_argument("candidate", type=Path)
    four = commands.add_parser("impact")
    four.add_argument("ledger", type=Path)
    four.add_argument("--changed-chapter", type=int, required=True)
    four.add_argument("--entity", action="append")
    four.add_argument("--chapters-dir", type=Path)
    args = parser.parse_args()
    try:
        ledger = load_ledger(args.ledger)
        if args.command == "status":
            result = status(ledger, args.chapters_dir)
            code = 1 if result["status"] != "OK" else 0
        elif args.command == "check":
            result = check(ledger, args.claims, chapters_dir=args.chapters_dir)
            code = 1 if result["status"] in ("CONFLICTS", "STALE", "LEDGER_PROBLEMS") else 0
        elif args.command == "scan":
            result, code = scan(ledger, args.candidate), 0
        else:
            result, code = impact(ledger, args.changed_chapter, args.entity, args.chapters_dir), 0
    except (FactError, OSError, UnicodeError, ValueError) as exc:
        print(json.dumps({"status": "INPUT_ERROR", "error": str(exc)}, ensure_ascii=False))
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return code


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""r5.49: style_cards.py load wording (the card data does not change).

Three changes to what load prints: the sentence-length line says what a clause is and that the number is a rough
picture, not a requirement, and that linked actions may run as one sentence; an example that collides with another
loaded card's opposite phrasing is marked for a re-read instead of being dropped, and the other cards'
blacklist_patterns (regex) count as well as their blacklist words, with a pattern that does not compile skipped; and
with two or more cards one line says the order only settles the rough clause length. The examples added to cards in
these tests are invented here. r5.50 (author's task book 11-06, item 四.5): the library's composition rule no longer
says the deck's "以黑名单为准" but the same mark for a re-read, and the guide says so.
"""
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
SCRIPT = SKILL / "scripts" / "style_cards.py"
LIBRARY = SKILL / "assets" / "style-cards" / "cards.json"
MARK = "（撞上同用的另一张卡的相反写法：待复核，看这一场的处境、人物和动作合不合，再定用不用）"
TOGETHER = ("几张同用：先后只定句长的大概数；每张卡句子一节里随动作走的说法照样看。说明之间说法不一时（写不写过程、感官写不写主观"
            "感受），照这一场要读者看清什么来定，交代时说一句用了哪张的哪一条。")


def run(*args):
    proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT), *map(str, args)], capture_output=True, text=True,
                          encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


def module():
    spec = importlib.util.spec_from_file_location("style_cards_r549_under_test", SCRIPT)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def card_of(data, cid):
    return next(c for c in data["cards"] if c["id"] == cid)


def line_for(page, plain):
    return next(l for l in page.splitlines() if l.startswith("- 平常写“%s”" % plain))


class ClauseLine(unittest.TestCase):
    def test_the_sentence_length_line(self):
        data = json.loads(LIBRARY.read_text(encoding="utf-8"))
        code, out, err = run("load", "hemingway-iceberg", "tense-suspense-probe")
        self.assertEqual(code, 0, out + err)
        lo, hi = card_of(data, "hemingway-iceberg")["syntax_metrics"]["avg_clause_length"].split("-")
        self.assertIn("- 分句（逗号、句号隔开的一小段）大致 %s—%s 字：这种腔调的大致样子，不是要求；连着的动作，几个分句可以连成一句。"
                      % (lo, hi), out.splitlines())
        self.assertEqual(out.count("- 分句（逗号、句号隔开的一小段）大致 "), 2)  # one per card
        self.assertNotIn("- 分句大致", out)


class Collisions(unittest.TestCase):
    def setUp(self):
        self.data = json.loads(LIBRARY.read_text(encoding="utf-8"))
        self.mod = module()

    def test_a_blacklist_word_marks_for_a_reread(self):
        voice = card_of(self.data, "hemingway-iceberg")
        scene = card_of(self.data, "tense-suspense-probe")
        plain, example = next((p, e) for p, e in scene["kinetic_verbs"].items()
                              if any(w in e for w in voice["blacklist"]))
        code, out, err = run("load", "tense-suspense-probe", "hemingway-iceberg")
        self.assertEqual(code, 0, out + err)
        self.assertTrue(line_for(out, plain).endswith(MARK))
        self.assertNotIn("这一场不用", out)
        alone = self.mod.render(self.data, [scene])
        self.assertNotIn(MARK, alone)  # one card alone: nothing to collide with

    def test_a_blacklist_pattern_marks_too(self):
        voice = card_of(self.data, "hemingway-iceberg")
        base = card_of(self.data, "grimdark-high-fantasy")
        self.assertTrue(voice["blacklist_patterns"])
        hit = [(p, e) for p, e in base["kinetic_verbs"].items()
               if any(re.search(pat, e) for pat in voice["blacklist_patterns"])]
        self.assertTrue(hit)
        plain, example = hit[0]
        self.assertFalse(any(w in example for w in voice["blacklist"]))  # the pattern, not a word, makes it collide
        code, out, err = run("load", "grimdark-high-fantasy", "hemingway-iceberg")
        self.assertEqual(code, 0, out + err)
        self.assertTrue(line_for(out, plain).endswith(MARK))
        clean = next(p for p, e in base["kinetic_verbs"].items()
                     if not any(re.search(pat, e) for pat in voice["blacklist_patterns"])
                     and not any(w in e for w in voice["blacklist"]))
        self.assertNotIn(MARK, line_for(out, clean))

    def test_an_invalid_pattern_is_skipped_and_a_cards_own_pattern_does_not_count(self):
        data = json.loads(json.dumps(self.data))
        voice = card_of(data, "hemingway-iceberg")
        scene = card_of(data, "tense-suspense-probe")
        scene["kinetic_verbs"]["敲门"] = "指节在门板上叩了三下，停一停，又叩一下"
        scene["kinetic_verbs"]["开灯"] = "摸到墙上的拉绳，往下一拽，灯泡晃了两晃才亮"
        voice["blacklist_patterns"] = ["[叩(", "叩了[一二三四五六七八九十]下"] + voice["blacklist_patterns"]
        scene["blacklist_patterns"] = scene["blacklist_patterns"] + ["晃了两晃", "(?P<"]
        page = self.mod.render(data, [voice, scene])
        self.assertTrue(line_for(page, "敲门").endswith(MARK))
        self.assertNotIn(MARK, line_for(page, "开灯"))  # only the scene card's own pattern matches it
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "cards.json"
            path.write_bytes(json.dumps(data, ensure_ascii=False).encode("utf-8"))
            code, out, err = run("load", "tense-suspense-probe", "hemingway-iceberg", "--library", path)
            self.assertEqual(code, 0, out + err)
            self.assertTrue(line_for(out, "敲门").endswith(MARK))


class Together(unittest.TestCase):
    def test_one_line_after_the_precedence_line_only_when_several_cards_load(self):
        code, out, err = run("load", "tense-suspense-probe", "hemingway-iceberg", "rashomon-confessional-pov")
        self.assertEqual(code, 0, out + err)
        lines = out.splitlines()
        first = next(i for i, l in enumerate(lines) if l.startswith("几张同用：句长的大概数对不上时"))
        self.assertIn("不是判定", lines[first])
        self.assertNotIn("这一场不用", lines[first])
        self.assertEqual(lines[first + 1], TOGETHER)
        self.assertEqual(lines.count(TOGETHER), 1)
        code, out, err = run("load", "hemingway-iceberg")
        self.assertEqual(code, 0, out + err)
        self.assertNotIn(TOGETHER, out)
        self.assertNotIn("几张同用", out)

    def test_index_match_and_check_do_not_carry_the_new_lines(self):
        for args in (("index",), ("match", "--text", "荒村古宅探索"), ("check",)):
            code, out, err = run(*args)
            self.assertEqual(code, 0, (args, out + err))
            for text in (TOGETHER, MARK, "分句（逗号"):
                self.assertNotIn(text, out)

    def test_the_guide_says_how_the_card_library_rule_is_carried_out(self):
        # Review CL-3, then r5.50: the card library's composition rule carries the workshop's ruling (a mark for a
        # re-read) instead of the deck's "以黑名单为准", and the guide says so, so a chat-only writer reading both does
        # not get two rules; the deck's own words stay in the maintenance folder of the personal build.
        guide = (Path(__file__).resolve().parents[1] / "skills" / "novel-workshop" / "references" / "style-cards.md").read_text(encoding="utf-8")
        for phrase in ("`composition.rule`", "不自动不用", "只取句长的大概数", "没有 Python、直接读卡片库时", "r5.50 起",
                       "原话记在自用版的维护目录里"):
            self.assertIn(phrase, guide)
        self.assertNotIn("以黑名单为准", guide)
        rule = json.loads(LIBRARY.read_text(encoding="utf-8"))["composition"]["rule"]
        for phrase in ("取并集", "（词或句式），标“待复核”", "看这一场的处境、人物和动作合不合", "不自动不用", "按 precedence 从左到右取第一个有定义的风格"):
            self.assertIn(phrase, rule)
        self.assertNotIn("以黑名单为准", rule)


if __name__ == "__main__":
    unittest.main()

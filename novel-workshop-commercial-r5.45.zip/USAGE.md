# 使用说明：调用、确认、检查强度与交付状态

小说写作工坊 · `2026-10-26-r5.45-candidate`

本页说明怎样在不同的 AI 环境里真正用上工坊，而不只是“上传成功”。工坊是一组文件：模型读没读、照没照做，取决于平台和模型本身。下面的做法能把执行情况摆到明处，但不能替你保证。

## 一、按环境选择用法

| 环境 | 做法 | 能用到什么 |
| --- | --- | --- |
| 支持技能目录的环境（如 Claude Code、Codex 一类） | 导入 `skills/novel-workshop` 和 `skills/darwin-novel-workshop` 两个完整目录，或运行 `python install.py --dest 技能目录` | 完整方法；模型有执行权限时，还能运行检查脚本 |
| 有“项目指令”和附件的聊天产品（如 Claude 项目、ChatGPT 项目或自定义 GPT） | 把 [交付门卡](skills/novel-workshop/assets/delivery-gate-card.md) 全文贴进项目指令；上传 `portable-novel-workshop.md` 作为参考文件 | 完整方法；脚本一般不会运行 |
| 只有对话框 | 在第一条消息里贴交付门卡全文，再上传单文件 | 同上；新对话要重新提供 |

**平台自己管的技能目录（r5.40）。** 有的平台把导入的技能放在系统分配的目录里：目录名是平台给的编号，不叫 `novel-workshop`，里面还有平台自己的元数据文件。`install.py` 按固定名称在 `--dest` 下建 `novel-workshop/`、`darwin-novel-workshop/`，不会更新平台正在调用的那一份；在这类平台上只跑默认命令，不能说加载的版本已经换了。升级时用平台自己的更新或重新导入；要手动替换，先把平台登记的那两个目录整份备份，再把新版两个目录里的文件拷进去，平台的元数据文件留着不动。换完核对：在平台目录里算一个这一版改过的文件的 sha256（本版可以用 `scripts/inspiration_library.py`），和交付包 `PACKAGE-MANIFEST.json` 里同一文件记的对上，才算装上了，例如 `python -c "import hashlib,sys;print(hashlib.sha256(open(sys.argv[1],'rb').read()).hexdigest())" 文件路径`；再开一个新对话用。

单文件有三十多万字节（本版的商业版约 40 万字节）。有的平台只检索附件里的片段，不会通读。交付门卡只有一页，放在指令里能保证那几条底线一直在上下文中。本包不能保证任何其他平台会自动执行本地 Python 脚本；平台没有运行脚本时，模型应当把机器检查写成 UNTESTED，而不是 GREEN。

## 二、确认模块真的被读了

- 开工前问一句：“这次按哪一级处理？会读哪些模块和小节？”回答应当和 SKILL.md 的分级表对得上，比如 L1 要包括中文标点、句式专项“过度断句的还原”“段落：按焦点分段”“语感：搭配、照应与叫法”、模板腔复核“去模板腔时引入的新模板”、质量循环“文学质量的六个维度”“交付状态”。
- 抽查：请它逐字引用其中一个模块里的一条规则（例如中文标点模块对【能力名】的写法）。引不出来或引错，说明没读到；让它先读，再开工。
- 交付后看状态块里的“读过的模块”清单。清单里没有的模块，不能当作已经按它检查过。

这些办法只能发现“没读”，不能证明“读懂了”。

## 三、选择检查强度

| 你的请求 | 级别 | 交付时你会看到 |
| --- | --- | --- |
| 改几句、润一段、讨论设定 | L0 轻量 | 直接给结果，不附流程 |
| 写一整章，或整章精修、重写、去模板腔、审稿 | L1 整章 | 正文；四项交付状态记在工作记录里，你要报告时附上（只要正文时不插进正文） |
| 两章以上、批量重修、改已采纳的章节 | L2 多章 | 先做一章试点；每章各有状态；改了旧章时附回归核对清单 |

可以直接指定，例如“按 L1 严格交付”。想跳过试点，就明确说“授权一次处理第2—4章，不用试点”；这样处理出来的每章仍然是候选稿。说“继续”或“我累了，你决定”，表示在当前目标内接着做：普通的场景组织和措辞，助手自己选；会改变剧情的缺口，它会先指出来。

有 Python 时，严格任务可以在 `checks.json` 写 `"mode": "strict"`。严格模式下：

- 审稿通过要引自被审稿件的三处不同位置，覆盖开头、中段和结尾，每条引文至少 6 个非空白字符。重复出现的句子、互相重叠或紧挨着的片段只算一处；稿件短于 300 字符时不查分布。
- 要列出读过的全部来源；脚本给出的每条复核项都要有裁决和理由。
- 声明了的检查都必须实际运行。
- 整章任务（写、重写、精修、去模板腔、审稿；复用旧稿、零修改也算）要在审稿记录里交一份表达检查记录（`expression`）：按顺序列出读过的各段，首尾相接盖住整章，每段一句说明，再记有定位的修改和保留。说明写这一段的重复说明、总结旁白、短句和小动作怎样判的；只改了动作、持物、称谓这些连续性问题的，不算做过这一遍（r5.24 起写明）。没有它不能记 PASS；零修改也可以通过，不要求凑问题。只改局部的任务按声明的范围记，不能说整章已审。记过一版以后再改正文，新的记录要给改动的每一处各写一条，同一行里的几处也分开算（r5.16 起）；同一句话在几处出现、几处都改了，也是一处一条（r5.20 起）；每条改写记录只算它自己改掉的字：删掉的句子只算记录所引的旧文字原来所在的那一处，留下的一段两边都删了同一句，两边各要一条（r5.22 起）；删在保留或改写文字旁边的一段，带句末标点、省略号、破折号、后引号或后括号的，一句删掉又改了下一句开头的，也要单独记；几条记录一起核对时和它们排列的先后无关（r5.23 起）。格式见 `references/execution.md`。
- 这些门槛只能调严，不能调松。同一个运行里，重规划（`replan`）也不能放宽；作者要放宽，就另起一个运行（新的状态文件），让记录从一开始就写明较轻的审稿。
- 作品有标点规则文件时，标点检查要带上它（`"rules": "punctuation-rules.json"`）；不带的话，能力名带句号只算复核项，标“保留”就能放行。

需要独立审稿时加 `"review_policy": {"require_independent": true}`，标为自查的审稿就不能记为 PASS。

**这些条件能拦住偷懒和疏忽，拦不住有意伪造，也判断不了保留理由成不成立。** 审稿方式、读过的来源、保留理由都由审稿记录自己填写，交付门接受一条“有余韵”的保留理由，只说明它写了；不读稿件，照样能各摘一句凑满引文；检查清单也是写稿一方自己定的，只放无关痛痒的检查也能得到 GREEN。所以状态块说明的是“记录了什么”，不是“已被证实”，最终仍要靠你读稿判断。

## 四、读懂交付状态

```text
【交付状态】第5章｜候选稿 sha256:1a2b3c…
INPUT_READY：READY
MECHANICAL：GREEN
EDITORIAL：PASS［自查］……
AUTHOR：NOT_ACCEPTED
```

| 项目 | 意思 | 你需要做什么 |
| --- | --- | --- |
| INPUT_READY | 原稿、前文、规则文件都在，而且没被改过。不代表已经读过 | BLOCKED 时补材料 |
| MECHANICAL | 程序检查的结果。GREEN 只说明声明过的检查通过 | UNTESTED 表示没跑；STALE 表示检查后稿子又改过，要重跑 |
| EDITORIAL | 编辑判断，要附原文短引；写明是自查、独立代理还是人工编辑（审稿方式是自报的，脚本无法核实） | 自查不等于独立审稿；NEEDS_REVISION 表示要返修 |
| AUTHOR | 你有没有明确采纳这一版 | 满意就说“采纳这一版”；在那之前，它都是候选稿。你也可以说“不用审了，直接采纳”，记录会照实写“作者决定跳过审稿”，不会补写一份审稿；之后补做了审稿，状态按补审结果显示，跳审的经过留在记录里 |

四项不能互相替代。机器检查是 GREEN，不代表文笔好；编辑写了 PASS，不代表你同意。只有你明确采纳的版本，才会写回设定、状态档案和后续章节的事实基线。

脚本的 `status` 还会给出两样摘要：**阶段**（DRAFT、READY_FOR_AUTHOR、AUTHOR_ACCEPTED，或者 STALE、UNTESTED、NEEDS_REVISION、BLOCKED）和**权限裁决**（能不能说“机器检查通过”“已审”“独立审稿”“定本”，能不能改已采纳的文本，分别是 ALLOW、ALLOW_WITH_WARNING、REVIEW_REQUIRED 或 BLOCK）。这两样都从四项推算，以四项为准。稿件、事实主张、冻结的原稿或规则、检查脚本本身，任何一项变了，旧结果都显示 STALE。旧审稿只对它审过的那一版有效。

状态行还写出表达检查记录盖了多大范围（整章或局部、几段、几条处理记录）。交给你的文件是不是检查过的那一版，可以用 `status run.json --deliverable 文件` 核对：同一版是 `exact`；只差末尾换行是 `final_newline_only`；正文相同、只差换行符（CRLF／LF）或文件开头的 BOM 是 `line_endings_or_bom_only`；不是同一版是 `no`，这时不能说已审、已检查。

整章及以上的编辑审查，按六个维度各写一条结论：段落密度与语义分段、对白与标点、场景可还原性、叙事功能、跨章连续性、修订前后对照，每项是达到、有问题、未看或不适用。状态行会写出哪几项没看；有没看的维度，就不能说“精修完成”。

## 五、本地脚本（可选）

需要 Python 3.9 或更新版本。在 `skills/novel-workshop` 目录运行：

```bash
# 标点与断句：只读，给出行列、规则编号和等级
python3 scripts/punctuation_lint.py 正文/第05章.md --rules 作品/punctuation-rules.json --format text
# 同一引号内按行软换行的稿子（作品确认采用这种写法时）
python3 scripts/punctuation_lint.py 正文/第05章.md --rules 作品/punctuation-rules.json --dialogue-soft-wrap
# 修订稿和原稿对照：只列修改后新出现的问题和对白语气变化
python3 scripts/punctuation_lint.py 正文/第05章-修订.md --baseline 正文/第05章.md
# 跨章事实：比对事实主张（带原章目录时核对采纳时的原章哈希）、列出要回归的章节
python3 scripts/fact_guard.py check 作品/facts.json 作品/claims-第12章.json --chapters-dir 正文
python3 scripts/fact_guard.py impact 作品/facts.json --changed-chapter 8 --chapters-dir 正文
# 交付门：冻结输入、记录绑定版本的审稿、输出四项状态、记录作者采纳
python3 scripts/workflow_guard.py start run.json --task-id ch05 --spec checks.json
python3 scripts/workflow_guard.py record run.json --event-id v0 --review review.json
python3 scripts/workflow_guard.py status run.json --summary
# 要交出去的文件是不是检查过的那一版（不是时退出码 1）
python3 scripts/workflow_guard.py status run.json --deliverable 正文/第05章.md
python3 scripts/workflow_guard.py accept run.json --event-id a1 --decision acceptance.json
# 你决定跳过审稿、直接采纳当前这一版：照实记录，不补写审稿
python3 scripts/workflow_guard.py accept run.json --event-id a1 --decision acceptance.json --skip-review
# r5.39 起：任务已完成、正文没变，你要求再审一遍：先把你的决定写进 decision.json（author_decision、source、affected_scope），
# 再 replan、reserve、record；旧的结论留在记录里，额度不重置（references/execution.md“同一正文再审”）
python3 scripts/workflow_guard.py replan run.json --event-id p1 --spec checks.json --decision decision.json
# 升级以后旧结论 STALE：reserve 再 record 同一份旧审稿，只是把旧结论重新绑到新脚本上，不等于按新方法读过正文；
# 要按新方法审，record 一份重新读出来的审稿记录（r5.40，references/execution.md“同一正文再审”一节末尾）
# 多章交付：核对约定章数、实际文件、各章状态（漏章、空稿、旧审稿）
python3 scripts/delivery_manifest.py 作品/delivery.json
# 作者的几份规则文件互相打架：核对冲突登记表、列出待作者定的项、查新叫法在各章的已有用法（r5.21 起）
python3 scripts/rule_register.py check 作品/rule-conflicts.json --texts-root 作品/正文
python3 scripts/rule_register.py list 作品/rule-conflicts.json --status open --markdown
python3 scripts/rule_register.py collide --register 作品/rule-conflicts.json --texts-root 作品/正文 新叫法
# 整章写完以后（修改的五道工序第一遍）：语感扫描和分场检测，给人读的简短报告；作品的用词规则可选（r5.33 起）
python3 scripts/prose_lint.py 正文/第05章.md --rules 作品/prose-rules.json --format text
# 第三遍：台词按人物分栏，标出书面词、叙述专用的词和一口气很长的句子；作品的人物口吻表可选（r5.33 起）
python3 scripts/dialogue_lines.py 正文/第05章.md --names 甲,乙 --voices 作品/voice-lexicon.json
# 改稿以后（去 AI 腔、精修）：原稿里有、修订稿里没了的说法和动态补语，新出现的“X是Y的”判断句和坐标说法；留不留你定（r5.44 起）
python3 scripts/detail_check.py compare 正文/第05章.md 正文/第05章-修订.md
# 改写作规则以前（维护时用，r5.44 起）：写作对照例自检；新执行者的输出逐例核对（references/skill-evaluation.md“写作对照例”）
python3 scripts/detail_check.py anchors 对照例.json --self-test
python3 scripts/detail_check.py anchors 对照例.json --outputs 输出目录
# 本书的灵感库（r5.33 起，宪法 CON-012）：核对记录全不全；按章列出；把一章挑中的参考图排成素材卡的素材块
python3 scripts/inspiration_library.py check 作品/inspiration/library.json
python3 scripts/inspiration_library.py list 作品/inspiration/library.json --chapter 5
python3 scripts/inspiration_library.py card 作品/inspiration/library.json --chapter 5
# r5.34 起：挑中的条目写明借哪几样（take），素材块只写借的那几样、本书的改法和不借的；按人物、地方列出借过的图
python3 scripts/inspiration_library.py list 作品/inspiration/library.json --subject 老锁匠
# r5.35 起：写库只走 inspiration_write.py。先把第 1 版的库迁到第 2 版（默认在旁边写 library.v2.json，原件不动）
python3 scripts/inspiration_write.py migrate 作品/inspiration/library.json
python3 scripts/inspiration_write.py migrate 作品/inspiration/library.json --replace   # 原地换，原件先存进 library.history/
# 记下作者的选择：N 是你读库时 check 报的 revision；这期间有人写过库就报 CONFLICT（退出码 3），不写
python3 scripts/inspiration_write.py adopt 作品/inspiration/library.json --selection 选择.json --if-revision N --dry-run
python3 scripts/inspiration_write.py adopt 作品/inspiration/library.json --selection 选择.json --if-revision N
# 回退：写回某个修订，或者第 1 版原件（被换下的那一版另存一份）；看写库的历史
python3 scripts/inspiration_write.py restore 作品/inspiration/library.json --if-revision N --revision M
python3 scripts/inspiration_write.py restore 作品/inspiration/library.json --if-revision N --from 作品/inspiration/library.history/v1-original-xxxxxxxxxxxx.json
python3 scripts/inspiration_write.py history 作品/inspiration/library.json
# r5.37 起：迁到别的文件夹时，图片文件名相对的文件夹用 --root 指明（check 也给同一个 --root），找不到图就不迁
python3 scripts/inspiration_write.py migrate 作品/inspiration/library.json --out 新文件夹/library.json --root 作品/inspiration
# r5.37 起：退出码 4（COMMITTED_INCOMPLETE）是库已写成新修订号、日志没写完：不要再写一遍，下一次写库会补上日志
# r5.38 起：库里已经挑过的一条再写，选择文件 adopt 里那一条要写 "mode"："add"（再借这几样）、"replace"（只借这几样）、"use"（只多一个用处，不写 take）；
#           没写的报 ERROR，什么都不写；库里已经有这个选择的报 UNCHANGED，不写新版
# r5.38 起：只撤其中几样，选择文件写 "withdraw": [{"id": "条目编号", "parts": ["灯光"]}]；写进作者采纳正文的那一样不在这里撤
# 风格卡（r5.45 起）：写一场正文前看索引，每层挑一张或者不挑；字面线索；加载挑中的几张（只加载方向）；写完查有没有照搬卡里的原话
python3 scripts/style_cards.py index
python3 scripts/style_cards.py match --text "这一场的任务" --file 前文.txt
python3 scripts/style_cards.py load hemingway-iceberg tense-suspense-probe
python3 scripts/style_cards.py copied hemingway-iceberg tense-suspense-probe --file 稿子.txt
# 本书有自己的风格卡配置（关键词、不用的卡、你定的默认卡）时加 --project；核对卡片库和配置
python3 scripts/style_cards.py check --project 作品/style-cards.json
# 视觉素材（r5.35 起，可选，要你自己装五个项目，见下面一节）
python3 scripts/visual_materials_cli.py doctor --config 视觉配置.json --probe
python3 scripts/visual_materials_cli.py verify-run --run 运行文件夹
# 三章虚构演练（审稿与采纳都是模拟的，只用来熟悉流程）
python3 scripts/workflow_demo.py /临时目录/演练
```

格式说明见 `references/chinese-punctuation.md`、`references/continuity.md`（冲突登记表在“规则打架时”）、`references/execution.md`。整包测试：在交付包目录运行 `python3 tests/run_tests.py`。

### 视觉素材（r5.35 起，可选）

[视觉素材](skills/novel-workshop/references/visual-materials.md)给一章找参考图：SearXNG 和 Openverse 两路搜，Crawl4AI 读来源页，ImageHash 把近似图归组，OpenCLIP 按这一场的文字和你的参考图排序，看过图以后给你挑整张或局部，挑中的部分写进本书的灵感库。写作、审稿和灵感库的 `check`、`list`、`card` 不需要它。

- **要装的**：Pillow（解码图片）；ImageHash（`pip install ImageHash`）；Crawl4AI（`pip install crawl4ai`，再 `crawl4ai-setup`，需要 Python 3.10 以上）；OpenCLIP（`pip install open_clip_torch`，会带上 torch），权重另下，配置里写路径和 sha256；SearXNG 自己跑一个实例，设置里 `search.formats` 加上 `json`。Openverse 不用装，不登记也能用（限流低）。
- **配置**：照 `assets/visual-materials-config.example.json` 复制一份，填你的 SearXNG 地址、权重路径和哈希；密钥只放环境变量，配置里写变量名。用 `--config` 或环境变量 `NW_VISUAL_CONFIG` 指过去。
- **先看配齐没有**：`doctor` 逐项报代码在不在、这台机器配齐没有（Crawl4AI 只说能不能导入，浏览器起不起得来要 `--probe` 或跑一次 collect 才知道）；`--probe` 每项真调一次。跑完一次完整运行，用 `verify-run` 看这一次实际跑通了什么：每项分“跑过”（ran）和“证据现在还核得上”（live_verified），五项都 live_verified、图片文件都没变才算接通（`status` 为 `ALL_FIVE_LIVE`，退出码 0；否则 `NOT_ALL_LIVE`，退出码 1），差哪项就照实写哪项。
- **r5.37 起，候选包有编号**：`review-bundle` 写出的候选包有 `bundle_id`（review.md 开头）；看图记录和作者的选择（choice.json）都要写它。候选包重做过，旧的看图记录和选择移进运行文件夹的 `outdated/`，不搬到新包的图上；同一个文件以前看过的，在新的 observations.json 里写 `reuse: true` 才沿用。
- **r5.38 起，同一张图再挑要写 `mode`**：choice.json 每号可以写 `mode`：`add`（这几样也借）、`replace`（只借这几样）、`use`（只用到这一章这一场，不写 `take`）；库里挑过的图没写的，`adopt` 报 ERROR、什么都不写，请问作者是哪一种。`adopt.json` 是回执，`verify-run` 的 `chain` 只在回执对得上现在的 selection.json 时才算完成；改了选择还没写的报出来。看图记录按版本记，`seen_before` 是最新的一版。`rank` 只用文件对得上的图（缺了、变了的在 `not_ranked` 里，重新 collect），缓存换了格式，第一次会重算。
- **一次运行**的十步（写请求、`search`、`collect`、`dedupe`、`rank`、`review-bundle`、看图和 `review-record`、作者挑了以后 `select`、`adopt`、`verify-run`）见模块正文。搜索只发几个短词，不发正文；运行文件夹是这一次搜索的缓存，属于你的私人材料，删掉不影响写作。
- **本版在制作环境里的实际情况**：只有 ImageHash 真跑通；SearXNG 没有实例，Openverse 的请求被网络拒绝，Crawl4AI 和 OpenCLIP 装不上。在你的电脑上跑一次 `doctor --probe` 和一次完整运行，把 `doctor` 的输出、运行文件夹里的 `run.json`、`verify.json` 和 `review/review.md` 发给维护者（不用发图），才知道在你那里通不通：`doctor` 记着各项依赖的版本，`run.json` 记着每一步什么时候做完、成没成，review.md 能看出中文搜索词搜到了什么，哪一步失败以后接着跑的步骤照实记着。

Windows 上命令写 `python` 或 `py`。交付门、标点、文字检查、台词分栏、灵感库（含 r5.35 的写库脚本，锁文件用的是 Windows 也有的独占创建）、视觉素材、事实比对、批量清单、冲突登记表、风格卡这几个脚本不依赖 Linux 专有的功能，按设计可以在 Windows 上运行；它们和导出、安装脚本的输出都是 UTF-8；`project_state.py`（多人、多代理共用的项目状态文件）按设计只支持 Linux、macOS 等系统，三章演练用到了它，所以在 Windows 上会说明原因后退出。r5.24 在作者的 Windows 电脑上跑过一次全部测试：579 项里 99 项没过，原因都在测试和一处工具：测试写临时文件时 Windows 把换行存成 CRLF，测试却按 LF 的文字算哈希；冲突登记表工具只认 LF 的“原文开始”标记；一个安装测试在 JSON 里直接找带反斜杠的路径；依赖 `project_state.py` 的演练测试没有在 Windows 上跳过。r5.25 修了这几处，只在 Linux 上模拟 Windows 的换行和缺少 fcntl 重跑过，**还没有在 Windows 上重跑**；遇到问题，请把命令和完整输出发给维护者。在 Windows 上跑全部测试，按设计跳过的有：`test_r42.py` 里用三章演练项目的 12 项（`project_state.py` 不支持 Windows），`test_portability.py` 的 `WindowsLikeLock` 6 项（它在 Linux 上模拟 msvcrt，要用 Linux 的 /proc）；商业版另跳过一项要读自用版才有的评测记录的测试。r5.35 起：没装 Pillow 时，`test_visual_materials_pipeline.py` 里要解码图片的 24 项跳过（r5.37、r5.38 的 `test_r537_review_fixes.py`、`test_r538_review_fixes.py` 里要解码图片的也跳过，r5.38 的自用版没装 Pillow 时一共比装了多跳过 67 项）；装了 Crawl4AI 时，其中“没装 Crawl4AI”的一项跳过；商业版另有几项要读自用版维护目录里的批准记录和演示记录，也跳过。其余都应执行，跳过的项数和这里对不上，也请把完整输出发来。审稿记录里的 `candidate_sha256` 照抄 `workflow_guard.py status` 输出里的值，或对文件本身算哈希，不要拿聊天或内存里的文字算：Windows 存文件时换行是 CRLF，同样的文字字节不同。

## 六、这个包做不到的事

- 不能判断一段文字是不是 AI 写的，也不能用句号比例给文笔打分。
- 运行 Python 不等于完成了文学审稿。同一个模型复查自己，不等于独立编辑。
- 事实比对只核对声明过的主张；从正文里漏提的矛盾，程序发现不了。
- 交付门脚本拦得住疏忽，拦不住有意伪造：审稿方式、读过的来源、保留理由都由审稿记录自报；引文核对只证明引用的文字在这一版里，不证明审稿人读过；状态文件可以被手工改写。表达检查记录也一样：它证明记录全、范围对、引文找得到、版本对，不证明审得好，编出来的段落说明拦不住。
- 一次测试的结果，不能推广到所有题材、所有模型。本版的对照评测只用了同一个模型系列，结论见 VERIFICATION.md。
- 压缩包校验通过，只说明文件完整，不说明小说质量。
- 视觉素材的脚本看不见图：看图靠宿主助手打开图片文件，或者你自己看；相似度分数只是模型下两样东西有多接近，不是这张图适合小说的概率。`verify-run` 只核对运行文件夹里的记录和图片哈希，拦不住手工改写的记录。台词分栏只认台词旁边写明的说话人，代词指谁、跨段指代它判断不了，拿不准的单列给你。

#!/usr/bin/env python3
"""r5.6: evidence checks merged from two 2026-10-17 materials the author passed on (a breakdown record of a reference
work's opening and a general method draft). Only judgments the workshop did not have were taken, each with a new,
neutral example; nothing from the reference work itself is in this package.

What these tests hold: each such judgment sits once, in the section that already deals with that kind of evidence
(no parallel rule file, no second copy elsewhere), with its own example, and the evidence table keeps three cells per
row. Whether the judgments make reviews better is not tested here and has not been evaluated.
"""
import os
from pathlib import Path
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
REFS = ROOT / "skills" / "novel-workshop" / "references"


def section(name, heading):
    text = (REFS / name).read_text(encoding="utf-8")
    start = text.index("\n## " + heading + "\n")
    end = text.find("\n## ", start + 1)
    return text[start:] if end == -1 else text[start:end]


def row(table, start):
    rows = [line for line in table.splitlines() if line.startswith("| " + start)]
    if len(rows) != 1:
        raise AssertionError("expected one row starting with %r, found %d" % (start, len(rows)))
    return rows[0]


class EvidenceChecks(unittest.TestCase):
    def test_certainty_that_hardens_without_new_evidence(self):
        table = section("continuity.md", "动作状态与证据等级")
        line = row(table, "前文写“不知道”")
        self.assertEqual(line.count("|"), 4, line)  # three cells, like every row of that table
        self.assertIn("交作者确认", line)
        self.assertIn("不能反过来证明判断对", line)
        self.assertIn("原创示例：前文“她不知道渡船今天开不开", table)
        # Polishing must neither smooth the two places into agreement nor supply the missing evidence.
        polish = section("editing.md", "润色后的语义变化复核")
        self.assertIn("原稿自己前后的确定程度就不一致", polish)
        self.assertIn("也不替它补证据", polish)
        self.assertIn("(continuity.md)", polish)

    def test_an_evaluation_in_close_narration_is_not_the_others_motive(self):
        table = section("continuity.md", "动作状态与证据等级")
        line = row(table, "贴近人物的叙述或人物的话里的评价")
        self.assertEqual(line.count("|"), 4, line)
        self.assertIn("按正文写出的动作记", line)
        self.assertIn("仓库起火", table)

    def test_time_phrases_and_absolute_statements(self):
        checks = section("continuity.md", "衔接检查")
        for phrase in ("回切的锚点", "推不出确切日期", "“二十年前”这类概数不当精确值",
                       "“屋里只剩一张床”这类绝对说法", "不自动算错", "“镇上只有钟楼没变”这类修辞"):
            self.assertIn(phrase, checks)

    def test_two_accounts_that_disagree(self):
        flow = section("continuity.md", "当前状态与变化记录")
        self.assertIn("两种说法对不上时", flow)
        self.assertIn("矿井塌方", flow)
        self.assertIn("明确互斥", flow)
        self.assertIn("不替作者补上", flow)

    def test_news_to_a_character_is_not_a_repeat(self):
        keep = section("prose-audit.md", "该保留的写法：和形式相近的问题对照着看")
        group2 = keep[keep.index("**第 2 组"):keep.index("**第 3 组")]
        self.assertIn("某个人物这时才知道的事，再说一遍也不一定是重复", group2)

    def test_what_characters_say_about_medicine_or_law_is_story_evidence(self):
        scope = section("continuity.md", "建立证据范围")
        self.assertIn("不当现实的专业知识", scope)
        self.assertIn("(adversarial-review.md)", scope)

    def test_each_judgment_is_written_once(self):
        # Merged into the sections that already handle that kind of evidence, not kept as a second rule set.
        texts = {path.name: path.read_text(encoding="utf-8") for path in REFS.glob("*.md")}
        for phrase in ("渡船", "仓库起火", "矿井塌方", "回切的锚点", "这类绝对说法", "某个人物这时才知道的事",
                       "不当现实的专业知识", "原稿自己前后的确定程度"):
            homes = sorted(name for name, text in texts.items() if phrase in text)
            self.assertEqual(len(homes), 1, (phrase, homes))


if __name__ == "__main__":
    unittest.main()

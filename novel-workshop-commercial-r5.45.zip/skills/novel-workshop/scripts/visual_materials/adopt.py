"""Step 6: write the author's selection into the book's inspiration library, through inspiration_write.py only.

The write checks the library's revision (--if-revision): if someone wrote the library after you read it, nothing is
written and the answer says so; --rebase applies the choice to the newer revision when nobody touched the same
entries (additions with mode add or use go on top of what others added). The run's own folder is the cache of this
search; the library keeps only what the author chose.

r5.37: the selection must come from the run's current review bundle (its bundle_id); a selection made before the
bundle was rebuilt is refused. When the library file was written but its history could not be finished, the answer is
COMMITTED_INCOMPLETE with the new revision: do not write the same choice again.

r5.38 (the r5.37 review, point 1.2): adopt.json is a receipt of what was written: the sha256 of the selection file it
wrote, the bundle, the library's revision and sha256 after the write, and the write's operation_id. verify-run counts
the author's chain complete only when the receipt is for the current selection.json: a new choice that has not been
written yet is "waiting", however the earlier one went. Every receipt is also kept in run.json (adoptions), so an
earlier adoption stays visible as history.
"""
import importlib.util
import json
from pathlib import Path

from . import common
from .review import current_bundle

SCRIPTS = Path(__file__).resolve().parents[1]


def writer():
    spec = importlib.util.spec_from_file_location("nw_inspiration_write", SCRIPTS / "inspiration_write.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_adopt(folder, library, if_revision, rebase=False, dry_run=False):
    run = common.Run(folder)
    data = run.path("selection.json").read_bytes() if run.exists("selection.json") else None
    if data is None:
        raise common.VisualError("this run has no selection.json: run select with the author's choice first")
    try:
        made_from = json.loads(data.decode("utf-8-sig")).get("bundle_id")
    except (UnicodeError, ValueError, AttributeError) as exc:
        raise common.VisualError("cannot read selection.json: %s" % exc) from exc
    bundle_id = current_bundle(run)["bundle_id"]
    if made_from != bundle_id:
        raise common.VisualError("selection.json was made from bundle %s, but the run's review bundle is now %s: run "
                                 "select again with a choice for this bundle" % (made_from or "(none)", bundle_id))
    write = writer()
    try:
        report = write.adopt(library, data, if_revision, rebase=rebase, dry_run=dry_run)
    except write.Conflict as exc:
        report = {"status": "CONFLICT", "current_revision": exc.current, "changed": exc.changed, "error": str(exc)}
    except write.CommittedIncomplete as exc:
        report = {"status": "COMMITTED_INCOMPLETE", "revision": exc.revision, "sha256": exc.sha256,
                  "operation_id": exc.operation_id, "error": str(exc)}
    except write.LibraryError as exc:
        report = {"status": "ERROR", "error": str(exc)}
    if not dry_run:
        receipt = dict(report, library=Path(library).name, time=common.now(),
                       selection_sha256=common.sha256_bytes(data), bundle_id=bundle_id,
                       library_revision=report.get("revision"), library_sha256=report.get("sha256"),
                       operation_id=report.get("operation_id"))
        run.save("adopt.json", receipt)
        summary = {k: receipt.get(k) for k in ("status", "time", "selection_sha256", "bundle_id", "library",
                                               "library_revision", "operation_id")}
        manifest = run.manifest()
        manifest.setdefault("adoptions", []).append(summary)
        run.save("run.json", manifest)
        run.step("adopt", {"status": report.get("status"), "revision": report.get("revision"),
                           "selection_sha256": summary["selection_sha256"], "bundle_id": bundle_id,
                           "operation_id": summary["operation_id"]})
    return report

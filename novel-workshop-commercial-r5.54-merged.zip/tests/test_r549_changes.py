#!/usr/bin/env python3
"""r5.49: detail_check.py changes -- a sentence-by-sentence list of what a revision changed, for a person to re-read.

compare (r5.44) lists wording that is gone; it does not say which sentence went where. changes lines the two texts up
sentence by sentence and lists, with paragraph and sentence numbers: deleted sentences (with the words the revision
still has elsewhere), added sentences, changed sentences side by side, dialogue that changed, the author's keep lines
(原样在 / 改了 / 找不到), numbers with a unit that went or are new, sentences that only moved, and "对不上" (moved and
changed, split, merged, 拿不准). It never guesses a pairing it is not sure of, writes nothing and always ends with the
same limits line.

These tests pin the program's behaviour on invented passages. Whether a listed change made the text better or worse is
not something they can show; the tool says so itself.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
CHECK = ROOT / "skills" / "novel-workshop" / "scripts" / "detail_check.py"
LIMITS = "只列位置，不判对错：0 条不说明没改坏，条数多不说明改坏了；有没有作用、该不该改回，要人读。"

# Invented for these tests.
LANE_BEFORE = ("院墙上爬满了凌霄花。三轮车停在巷口，车斗里装着两筐橘子。\n"
               "卖橘子的女人蹲在车边数钱，数到第三遍才停手。\n"
               "“你明天几点到？”她冲着电话喊。「别等我。」那头的人说。\n"
               "雨是从七点开始下的。\n")
LANE_AFTER = ("三轮车停在巷口，车斗里只剩一筐橘子。\n"
              "卖橘子的女人蹲在车边数钱，数到第三遍才停手。\n"
              "“你明天到底几点到？”她冲着电话喊。\n"
              "雨是从八点开始下的，她十分着急，眼里闪过一丝慌乱。\n"
              "“灯给我留着。”她挂电话前补了一句。\n"
              "她走的那年夏天，凌霄花开得很凶。\n")
FERRY_BEFORE = ("码头的汽笛响了两声。\n"
                "阿岚把行李箱拖上跳板，轮子卡进木缝里，她用力一拽才拔出来。\n"
                "船舱里很闷。有人在角落里剥橘子。\n"
                "她想了想，又把船票掏出来看了一眼。\n"
                "甲板上的救生圈被人用粉笔写了个名字。\n")
FERRY_AFTER = ("阿岚把行李箱拖上跳板。轮子卡进木缝里。她用力一拽才拔出来。\n"
               "船舱里很闷，有人在角落里剥橘子。\n"
               "她把船票塞回口袋，没再看。\n"
               "码头的汽笛响了两声。\n"
               "甲板上那只救生圈，不知被谁用粉笔写了个名字。\n")
SNOW_BEFORE = ("雪下到第三天，镇上的邮车停了。\n"
               "杂货铺的老板娘每天早上都要扫一遍门口的台阶。\n"
               "小满把信纸折成四折，塞进棉袄内袋。\n"
               "他想了想，又把信掏出来看了一眼。\n")
SNOW_AFTER = ("雪下到第三天，镇上的邮车停了。\n"
              "小满把信纸折成四折，塞进棉袄内袋。\n"
              "他犹豫了很久，最后还是没寄。\n"
              "杂货铺老板娘每天天不亮就出来扫门口的台阶。\n")


def load():
    spec = importlib.util.spec_from_file_location("r549_detail_check", CHECK)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(*args):
    proc = subprocess.run([sys.executable, "-I", "-B", str(CHECK), *map(str, args)],
                          capture_output=True, text=True, encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


def texts(rows):
    return [r["text"] for r in rows]


def at(row):
    return (row["para"], row["sent"])


class Sentences(unittest.TestCase):
    def test_marks_and_line_breaks_cut_quotes_stay_whole(self):
        paras, units = load().text_units("灯灭了。她没动……窗外有人喊她的名字！\n"
                                         "“走吧。天要黑了。”他说。\n"
                                         "（她没回答。）然后呢？\n"
                                         "门口有人")
        self.assertEqual(len(paras), 4)
        self.assertEqual([(u["para"], u["sent"], u["text"]) for u in units],
                         [(1, 1, "灯灭了。"), (1, 2, "她没动……"), (1, 3, "窗外有人喊她的名字！"),
                          (2, 1, "“走吧。天要黑了。”他说。"),
                          (3, 1, "（她没回答。）"), (3, 2, "然后呢？"), (4, 1, "门口有人")])

    def test_blank_lines_and_indentation_are_not_paragraphs_or_text(self):
        paras, units = load().text_units("　　灯灭了。\n\n\n　　她没动。\n")
        self.assertEqual((len(paras), texts(units)), (2, ["灯灭了。", "她没动。"]))


class Changes(unittest.TestCase):
    def test_no_change_lists_nothing(self):
        dc = load()
        for after in (LANE_BEFORE, "\n\n".join("　　" + line for line in LANE_BEFORE.splitlines())):
            report = dc.changes(LANE_BEFORE, after)
            self.assertEqual(report["status"], "NOTHING_LISTED")
            for key in ("deleted", "added", "changed", "moved", "unaligned"):
                self.assertEqual(report[key], [], key)
            self.assertEqual(report["dialogue"], {"changed": [], "gone": [], "new": []})
            self.assertEqual(report["numbers"], {"gone": [], "new": []})
            self.assertEqual(report["counts"]["unchanged"], report["counts"]["original"]["sentences"])
            self.assertTrue(dc.changes_text(report).endswith(LIMITS + "\n"))

    def test_deleted_sentences_with_the_words_still_found_elsewhere(self):
        report = load().changes(LANE_BEFORE, LANE_AFTER)
        self.assertEqual(texts(report["deleted"]), ["院墙上爬满了凌霄花。", "「别等我。」那头的人说。"])
        self.assertEqual([at(r) for r in report["deleted"]], [(1, 1), (3, 2)])
        hint = report["deleted"][0]["still_in_revised"]
        self.assertEqual(hint, [{"word": "凌霄花", "paras": [6], "in_new_text": True}])
        self.assertEqual(report["deleted"][1]["still_in_revised"], [])
        out = load().changes_text(report)
        self.assertIn("    提示：修订稿别处还有这句里的“凌霄花”（第 6 段）；可能挪进了别的句子，要对着读。\n", out)
        only_old = load().changes("铁桶里接满了雨水。檐下的铁桶歪着。", "檐下的铁桶歪着。")
        self.assertEqual(only_old["deleted"][0]["still_in_revised"], [{"word": "铁桶", "paras": [1], "in_new_text": False}])
        self.assertIn("“铁桶”（第 1 段，在没改的句子里）。", load().changes_text(only_old))

    def test_added_sentences(self):
        report = load().changes(LANE_BEFORE, LANE_AFTER)
        self.assertEqual(texts(report["added"]), ["“灯给我留着。”她挂电话前补了一句。", "她走的那年夏天，凌霄花开得很凶。"])
        self.assertEqual([at(r) for r in report["added"]], [(5, 1), (6, 1)])

    def test_changed_sentences_side_by_side(self):
        dc = load()
        report = dc.changes(LANE_BEFORE, LANE_AFTER)
        pairs = [(at(r["original"]), r["original"]["text"], at(r["revised"]), r["revised"]["text"]) for r in report["changed"]]
        self.assertEqual(pairs, [
            ((1, 2), "三轮车停在巷口，车斗里装着两筐橘子。", (1, 1), "三轮车停在巷口，车斗里只剩一筐橘子。"),
            ((3, 1), "“你明天几点到？”她冲着电话喊。", (3, 1), "“你明天到底几点到？”她冲着电话喊。"),
            ((4, 1), "雨是从七点开始下的。", (4, 1), "雨是从八点开始下的，她十分着急，眼里闪过一丝慌乱。")])
        self.assertEqual(report["changed"][0]["edits"], [{"from": "装着两", "to": "只剩一"}])
        self.assertTrue(all(r["ratio"] >= dc.SIMILAR for r in report["changed"]))
        out = dc.changes_text(report)
        self.assertIn("  原稿第 1 段第 2 句：三轮车停在巷口，车斗里装着两筐橘子。\n"
                      "  修订稿第 1 段第 1 句：三轮车停在巷口，车斗里只剩一筐橘子。\n"
                      "    差在：「装着两」→「只剩一」\n", out)

    def test_short_sentences_that_share_no_two_letters_still_pair_in_place(self):
        report = load().changes("院门开着。炭灭了。檐灯还亮着。", "院门开着。炭红了。檐灯还亮着。")
        self.assertEqual([(r["original"]["text"], r["revised"]["text"]) for r in report["changed"]], [("炭灭了。", "炭红了。")])
        self.assertEqual((report["deleted"], report["added"]), ([], []))

    def test_dialogue_changed_gone_and_new(self):
        d = load().changes(LANE_BEFORE, LANE_AFTER)["dialogue"]
        self.assertEqual([(r["original"]["text"], r["revised"]["text"]) for r in d["changed"]],
                         [("“你明天几点到？”", "“你明天到底几点到？”")])
        self.assertEqual(d["gone"], [{"para": 3, "text": "「别等我。」"}])
        self.assertEqual(d["new"], [{"para": 5, "text": "“灯给我留着。”"}])
        moved = load().changes("“再等等。”他说。门外起风了。", "门外起风了。“再等等。”他压着嗓子说。")["dialogue"]
        self.assertEqual(moved, {"changed": [], "gone": [], "new": []})  # same words in the quote: not a dialogue change

    def test_numbers_with_a_unit_that_went_or_are_new(self):
        dc = load()
        n = dc.changes(LANE_BEFORE, LANE_AFTER)["numbers"]
        self.assertEqual([(r["text"], r["original_count"], r["revised_count"]) for r in n["gone"]],
                         [("两筐", 1, 0), ("七点", 1, 0)])
        self.assertEqual([(r["text"], at(r["where"][0])) for r in n["new"]], [("八点", (4, 1))])
        # 十分 (very), 一丝, 一筐 (a lone 一 before a classifier) are not counted; 第三遍 stands on both sides.
        listed = [r["text"] for r in n["gone"] + n["new"]]
        for word in ("十分", "一丝", "一筐", "第三遍"):
            self.assertNotIn(word, listed)
        n = dc.changes("他走了3公里，手机还剩百分之二十的电。半年没回家。",
                       "他走了５公里，手机还剩30%的电。半年没回家。")["numbers"]
        self.assertEqual([r["text"] for r in n["gone"]], ["3公里", "百分之二十"])
        self.assertEqual([r["text"] for r in n["new"]], ["5公里", "30%"])
        same = dc.changes("两个人等了一年。", "一年里，两个人一直在等。")["numbers"]
        self.assertEqual(same, {"gone": [], "new": []})  # moved with the words around them: same counts

    def test_moved_split_merged_and_unsure_are_not_guessed(self):
        report = load().changes(FERRY_BEFORE, FERRY_AFTER)
        self.assertEqual([(at(r["original"]), at(r["revised"]), r["original"]["text"]) for r in report["moved"]],
                         [((1, 1), (4, 1), "码头的汽笛响了两声。")])
        kinds = [(r["kind"], [at(p) for p in r["original"]], [at(p) for p in r["revised"]]) for r in report["unaligned"]]
        self.assertEqual(kinds, [("split", [(2, 1)], [(1, 1), (1, 2), (1, 3)]),
                                 ("merged", [(3, 1), (3, 2)], [(2, 1)]),
                                 ("unsure", [(4, 1)], [(3, 1)])])
        unsure = report["unaligned"][2]
        self.assertTrue(load().UNSURE <= unsure["ratio"] < load().SIMILAR)
        self.assertEqual((report["deleted"], report["added"]), ([], []))  # the unsure pair is listed once, not guessed
        self.assertEqual([(r["original"]["text"], r["revised"]["text"]) for r in report["changed"]],
                         [("甲板上的救生圈被人用粉笔写了个名字。", "甲板上那只救生圈，不知被谁用粉笔写了个名字。")])

    def test_moved_and_changed(self):
        report = load().changes(SNOW_BEFORE, SNOW_AFTER)
        self.assertEqual([(r["kind"], texts(r["original"]), texts(r["revised"])) for r in report["unaligned"]],
                         [("moved_changed", ["杂货铺的老板娘每天早上都要扫一遍门口的台阶。"], ["杂货铺老板娘每天天不亮就出来扫门口的台阶。"])])
        self.assertEqual(texts(report["deleted"]), ["他想了想，又把信掏出来看了一眼。"])
        self.assertEqual(texts(report["added"]), ["他犹豫了很久，最后还是没寄。"])

    def test_numbers_with_thousands_separators_are_one_number(self):  # review finding CL-5
        dc = load()
        n = dc.changes("他从抽屉里数出3,000元，压在茶杯底下。", "他从抽屉里数出5,000元，压在茶杯底下。")["numbers"]
        self.assertEqual((texts(n["gone"]), texts(n["new"])), (["3000元"], ["5000元"]))
        self.assertIn("没了“3000元”", dc.changes_text(dc.changes("他数出3,000元。", "他数出5,000元。")))
        n = dc.changes("渡口离这儿还有３，５００米。", "渡口离这儿还有2，500米。")["numbers"]  # full-width comma and digits
        self.assertEqual((texts(n["gone"]), texts(n["new"])), (["3500米"], ["2500米"]))
        for before, after in (("他数出3,000元。", "他数出3000元。"), ("他数出3，000元。", "他数出3,000元。"),
                              ("票价涨了1,200%。", "票价涨了1200%。")):
            self.assertEqual(dc.changes(before, after)["numbers"], {"gone": [], "new": []}, after)  # only the way it is written
        self.assertEqual([q for q, _ in dc.quantities(dc.text_units("借条上写着1,250,000.5元，第1,000名。")[1])],
                         ["1250000.5元", "第1000名"])
        # A list with 、 is still read number by number, and a separated number does not start inside a longer one.
        n = dc.changes("值班表上排的是101、102号。", "值班表上排的是101、103号。")["numbers"]
        self.assertEqual((texts(n["gone"]), texts(n["new"])), (["102号"], ["103号"]))
        n = dc.changes("门牌上写着1024，200米外就是渡口。", "门牌上写着1024，300米外就是渡口。")["numbers"]
        self.assertEqual((texts(n["gone"]), texts(n["new"])), (["200米"], ["300米"]))

    def test_a_closer_sentence_elsewhere_wins_over_a_weak_same_place_pairing(self):  # review finding CL-1
        dc = load()
        before = "院墙上爬满了凌霄花。老周把三轮车停在巷口的槐树下。卖橘子的女人蹲在车边数钱。巷子深处有人在剁肉。天快黑了。"
        after = "院墙上爬满了凌霄花。老周把伞靠在巷口的墙上。卖橘子的女人蹲在车边数钱。老周把三轮车停在巷口的那棵槐树下。天快黑了。"
        report = dc.changes(before, after)
        self.assertEqual([(r["kind"], [at(p) for p in r["original"]], [at(p) for p in r["revised"]]) for r in report["unaligned"]],
                         [("moved_changed", [(1, 2)], [(1, 4)])])
        self.assertGreaterEqual(report["unaligned"][0]["ratio"], 0.9)
        self.assertEqual(report["changed"], [])
        self.assertEqual(([at(r) for r in report["added"]], texts(report["added"])), ([(1, 2)], ["老周把伞靠在巷口的墙上。"]))
        self.assertEqual(texts(report["deleted"]), ["巷子深处有人在剁肉。"])
        # The same sentence word for word elsewhere: it only moved.
        report = dc.changes(before, after.replace("巷口的那棵槐树下", "巷口的槐树下"))
        self.assertEqual([(at(r["original"]), at(r["revised"])) for r in report["moved"]], [((1, 2), (1, 4))])
        self.assertEqual((report["changed"], report["unaligned"]), ([], []))
        self.assertEqual(texts(report["added"]), ["老周把伞靠在巷口的墙上。"])
        # The closer sentence already stays in place with another one: the same-place pairing is left alone.
        report = dc.changes(before.replace("巷子深处有人在剁肉。", "老周把三轮车停在巷口的那棵槐树下了。"), after)
        self.assertEqual([(at(r["original"]), at(r["revised"])) for r in report["changed"]], [((1, 2), (1, 2)), ((1, 4), (1, 4))])
        self.assertEqual((report["unaligned"], report["added"], report["deleted"]), ([], [], []))

    def test_the_rival_can_be_on_either_side_and_must_be_free_and_clearly_closer(self):  # CL-1, invented passages
        dc = load()
        yard = "晾衣绳上挂着三件衬衫。阿婆把竹椅搬到门槛外的枣树下。灶上的水开了。孙女在饭桌上写作业。院门吱呀响了一声。"
        yard_after = "晾衣绳上挂着三件衬衫。阿婆把扫帚靠在门槛外的墙上。灶上的水开了。阿婆把竹椅搬到门槛外的那棵枣树下。院门吱呀响了一声。"
        report = dc.changes(yard_after, yard)  # the original side holds the closer sentence
        self.assertEqual([(r["kind"], [at(p) for p in r["original"]], [at(p) for p in r["revised"]]) for r in report["unaligned"]],
                         [("moved_changed", [(1, 4)], [(1, 2)])])
        self.assertEqual((texts(report["deleted"]), texts(report["added"]), report["changed"]),
                         (["阿婆把扫帚靠在门槛外的墙上。"], ["孙女在饭桌上写作业。"], []))
        # The closer sentence elsewhere is still closer to another leftover: that pair moves, the same place stays.
        report = dc.changes("晾衣绳上挂着三件衬衫。阿婆把竹椅搬到门槛外的枣树下。灶上的水开了。院门吱呀响了一声。"
                            "巷子里有人喊收废品。阿婆把竹椅搬到门槛外的那棵枣树下了。",
                            "晾衣绳上挂着三件衬衫。阿婆把扫帚靠在门槛外的墙上。灶上的水开了。阿婆把竹椅搬到门槛外的那棵枣树下。"
                            "院门吱呀响了一声。巷子里有人喊收废品。")
        self.assertEqual([(at(r["original"]), at(r["revised"])) for r in report["changed"]], [((1, 2), (1, 2))])
        self.assertEqual([(r["kind"], [at(p) for p in r["original"]], [at(p) for p in r["revised"]]) for r in report["unaligned"]],
                         [("moved_changed", [(1, 6)], [(1, 4)])])
        # A 拿不准 pair gives way too.
        report = dc.changes("风停了。老马把搪瓷缸子放回窗台上。锅里的粥冒着泡。窗外有人走过。灯还亮着。",
                            "风停了。老马蹲在窗台下抽烟。锅里的粥冒着泡。窗外有人走过。老马把搪瓷缸子轻轻放回窗台上。灯还亮着。")
        self.assertEqual([(r["kind"], [at(p) for p in r["original"]], [at(p) for p in r["revised"]]) for r in report["unaligned"]],
                         [("moved_changed", [(1, 2)], [(1, 5)])])
        self.assertEqual((texts(report["added"]), report["deleted"]), (["老马蹲在窗台下抽烟。"], []))
        # Not clearly closer (by less than MOVE_MARGIN), even word for word: the same-place pairing stays.
        for after, extra in (("风停了。老马愣了一下，应了一声。锅里的粥冒着泡。窗外有人走过。小马应了一声。灯还亮着。", "小马应了一声。"),
                             ("风停了。老马轻轻应了一声。锅里的粥冒着泡。窗外有人走过。老马应了一声。灯还亮着。", "老马应了一声。")):
            report = dc.changes("风停了。老马应了一声。锅里的粥冒着泡。窗外有人走过。灯还亮着。", after)
            self.assertEqual([(at(r["original"]), at(r["revised"])) for r in report["changed"]], [((1, 2), (1, 2))], after)
            self.assertEqual((report["moved"], report["unaligned"], texts(report["added"])), ([], [], [extra]), after)

    def test_keep_lines_kept_changed_or_missing(self):
        dc = load()
        lines = [(1, "雪下到第三天，镇上的邮车停了。"), (2, "杂货铺的老板娘每天早上都要扫一遍门口的台阶。"),
                 (3, "他想了想，又把信掏出来看了一眼。"), (5, "门口那棵槐树被雪压断了。")]
        keep = dc.changes(SNOW_BEFORE, SNOW_AFTER, lines, "keep.txt")["keep"]
        rows = [(r["line"], r["status"], r["label"], r["in_original"]) for r in keep["lines"]]
        self.assertEqual(rows, [(1, "kept", "原样在", True), (2, "changed", "改了", True), (3, "missing", "找不到", True),
                                (5, "missing", "找不到", False)])
        self.assertEqual(keep["lines"][0]["where"], {"para": 1})
        closest = keep["lines"][1]["closest"]
        self.assertEqual((at(closest), closest["text"]), ((4, 1), "杂货铺老板娘每天天不亮就出来扫门口的台阶。"))
        out = dc.changes_text(dc.changes(SNOW_BEFORE, SNOW_AFTER, lines, "keep.txt"))
        self.assertIn("要留的句子（keep.txt，4 行）：原样在 1 行，改了 1 行，找不到 2 行", out)
        self.assertIn("    最像的一句：修订稿第 4 段第 1 句：杂货铺老板娘每天天不亮就出来扫门口的台阶。", out)
        self.assertIn("原稿里也没有这一行", out)


class Command(unittest.TestCase):
    def test_text_and_json_read_only_and_exit_codes(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            a, b, k = tmp / "a.txt", tmp / "b.txt", tmp / "keep.txt"
            a.write_bytes(SNOW_BEFORE.encode("utf-8"))
            b.write_bytes(SNOW_AFTER.encode("utf-8"))
            k.write_bytes("雪下到第三天，镇上的邮车停了。\n\n他想了想，又把信掏出来看了一眼。\n".encode("utf-8"))
            before = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in tmp.iterdir()}
            code, out, err = run("changes", a, b, "--keep", k)
            self.assertEqual(code, 0, err)
            self.assertTrue(out.startswith("改动逐句对照（原稿 → 修订稿）\n每一条只是要回头读的地方，不是结论。\n"), out)
            self.assertTrue(out.endswith(LIMITS + "\n"), out)
            for heading in ("- 删掉的句子", "- 新加的句子", "- 改了的句子", "- 台词", "- 要留的句子", "- 数字和数量",
                            "- 挪了位置、字没改", "- 对不上"):
                self.assertIn(heading, out)
            code, out, err = run("changes", a, b, "--format", "json")
            self.assertEqual(code, 0, err)
            data = json.loads(out)
            self.assertEqual((data["format"], data["status"], data["keep"], data["limits"]),
                             ("novel-workshop-detail-check-changes", "LISTED", None, LIMITS))
            code, out, err = run("changes", a, a, "--format", "json")
            self.assertEqual((code, json.loads(out)["status"]), (0, "NOTHING_LISTED"))
            self.assertEqual({p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in tmp.iterdir()}, before)
            for args in (("changes", a, tmp / "missing.txt"), ("changes", a, b, "--keep", tmp / "missing.txt")):
                code, out, err = run(*args)
                self.assertEqual((code, json.loads(out)["status"]), (2, "ERROR"), args)
            (tmp / "gbk.txt").write_bytes("雪下到第三天".encode("gbk"))
            (tmp / "blank.txt").write_bytes(b"\n\n")
            for args in (("changes", tmp / "gbk.txt", b), ("changes", a, b, "--keep", tmp / "gbk.txt"),
                         ("changes", a, b, "--keep", tmp / "blank.txt")):
                code, out, err = run(*args)
                self.assertEqual((code, json.loads(out)["status"]), (2, "ERROR"), args)

    def test_compare_keeps_its_fields(self):
        with tempfile.TemporaryDirectory() as tmp:
            a, b = Path(tmp) / "a.txt", Path(tmp) / "b.txt"
            a.write_bytes(LANE_BEFORE.encode("utf-8"))
            b.write_bytes(LANE_AFTER.encode("utf-8"))
            code, out, err = run("compare", a, b, "--format", "json")
            self.assertEqual(code, 0, err)
            self.assertEqual(set(json.loads(out)), {"format", "format_version", "status", "han", "lost_wording",
                                                    "lost_complements", "new_judgments", "new_positions", "note"})


if __name__ == "__main__":
    unittest.main()

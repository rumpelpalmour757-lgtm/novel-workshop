// 明暗主题只是这台浏览器的阅读偏好：没选过就跟随系统，点过就记住。
const THEME_KEY = "story_dashboard_theme";
const systemDark = window.matchMedia("(prefers-color-scheme: dark)");
let themeChoice = null;
try {
  const saved = localStorage.getItem(THEME_KEY);
  if (saved === "light" || saved === "dark") themeChoice = saved;
} catch {}

function effectiveTheme() {
  return themeChoice || (systemDark.matches ? "dark" : "light");
}

function applyTheme() {
  if (themeChoice) document.documentElement.dataset.theme = themeChoice;
  else delete document.documentElement.dataset.theme;
  const button = document.querySelector("#themeButton");
  if (!button) return;
  const label = effectiveTheme() === "dark" ? "切换到浅色" : "切换到深色";
  button.title = label;
  button.setAttribute("aria-label", label);
}

applyTheme();

const state = {
  workspace: null,
  activeView: "libraries",
  activeFile: null,
  originalContent: "",
  dirty: false,
  mode: "edit",
  restored: false,
  showLineNumbers: true,
  filter: "",
  loadingFile: false,
  saving: false,
  // 每份文稿打开时都是只读，点“开始编辑”才能改；服务端以 --allow-edit 启动是前提
  editing: false,
  saveError: null,
  lastSavedAt: 0,
  draftTimer: null,
  draftNotice: null,
  draftWarned: false,
  sidePanel: null,
  assist: { status: null, busy: false, selection: null, result: null, error: null, check: { busy: null, result: null } },
  // Google AI（官方 ACP 运行时）：页面令牌只放在内存里；sent 记着发出的那一轮对应哪一段选区，放进编辑器前要核对。
  acp: { token: null, status: null, loadError: null, busy: null, error: null, selection: null, preview: null, sent: null, pollTimer: null, inserted: null },
  deleting: false,
  searching: false,
  searchResults: [],
  searchTruncation: null,
  searchSequence: 0,
  searchTimer: null,
  // 记住作者手动展开/收起过的目录，重绘文件树时不要把人正在翻的章节文件夹关掉
  expandedDirs: new Set(),
  collapsedDirs: new Set(),
};

const elements = {
  workspaceName: document.querySelector("#workspaceName"),
  workspacePath: document.querySelector("#workspacePath"),
  connectionStatus: document.querySelector("#connectionStatus"),
  treeSearch: document.querySelector("#treeSearch"),
  libraryCount: document.querySelector("#libraryCount"),
  projectCount: document.querySelector("#projectCount"),
  fileCount: document.querySelector("#fileCount"),
  librariesBadge: document.querySelector("#librariesBadge"),
  projectsBadge: document.querySelector("#projectsBadge"),
  archiveTabs: [...document.querySelectorAll(".archive-tabs [role='tab']")],
  treePanel: document.querySelector("#treePanel"),
  treeLoading: document.querySelector("#treeLoading"),
  fileTree: document.querySelector("#fileTree"),
  refreshButton: document.querySelector("#refreshButton"),
  themeButton: document.querySelector("#themeButton"),
  mobileBackButton: document.querySelector("#mobileBackButton"),
  editorEmpty: document.querySelector("#editorEmpty"),
  editorWorkspace: document.querySelector("#editorWorkspace"),
  editorBody: document.querySelector("#editorBody"),
  editorContainer: document.querySelector("#editorContainer"),
  lineNumbersGutter: document.querySelector("#lineNumbersGutter"),
  lineNumbersButton: document.querySelector("#lineNumbersButton"),
  editorTitle: document.querySelector("#editorTitle"),
  breadcrumbs: document.querySelector("#breadcrumbs"),
  dirtyStatus: document.querySelector("#dirtyStatus"),
  documentMeta: document.querySelector("#documentMeta"),
  editorInput: document.querySelector("#editorInput"),
  previewPane: document.querySelector("#previewPane"),
  modeButtons: [...document.querySelectorAll(".mode-switch button")],
  deleteButton: document.querySelector("#deleteButton"),
  saveButton: document.querySelector("#saveButton"),
  cursorPosition: document.querySelector("#cursorPosition"),
  encodingLabel: document.querySelector("#encodingLabel"),
  toastRegion: document.querySelector("#toastRegion"),
  conflictDialog: document.querySelector("#conflictDialog"),
  reloadConflictButton: document.querySelector("#reloadConflictButton"),
  truncationNotice: null,
  sidebarToggle: document.querySelector("#sidebarToggle"),
  editToggle: document.querySelector("#editToggle"),
  discardButton: document.querySelector("#discardButton"),
  compareButton: document.querySelector("#compareButton"),
  assistButton: document.querySelector("#assistButton"),
  draftBanner: document.querySelector("#draftBanner"),
  draftText: document.querySelector("#draftText"),
  draftRestore: document.querySelector("#draftRestore"),
  draftCompare: document.querySelector("#draftCompare"),
  draftDiscard: document.querySelector("#draftDiscard"),
  sidePanel: document.querySelector("#sidePanel"),
  sidePanelTitle: document.querySelector("#sidePanelTitle"),
  sidePanelClose: document.querySelector("#sidePanelClose"),
  comparePanel: document.querySelector("#comparePanel"),
  compareSummary: document.querySelector("#compareSummary"),
  compareView: document.querySelector("#compareView"),
  assistPanel: document.querySelector("#assistPanel"),
  assistStatus: document.querySelector("#assistStatus"),
  assistConfigForm: document.querySelector("#assistConfigForm"),
  assistKey: document.querySelector("#assistKey"),
  assistModel: document.querySelector("#assistModel"),
  assistClear: document.querySelector("#assistClear"),
  assistScopeText: document.querySelector("#assistScopeText"),
  assistScopeMeta: document.querySelector("#assistScopeMeta"),
  assistInstruction: document.querySelector("#assistInstruction"),
  assistSend: document.querySelector("#assistSend"),
  assistError: document.querySelector("#assistError"),
  assistResult: document.querySelector("#assistResult"),
  assistDiff: document.querySelector("#assistDiff"),
  assistCandidate: document.querySelector("#assistCandidate"),
  assistApply: document.querySelector("#assistApply"),
  assistDiscard: document.querySelector("#assistDiscard"),
  assistNote: document.querySelector("#assistNote"),
  assistSample: document.querySelector("#assistSample"),
  assistListModels: document.querySelector("#assistListModels"),
  assistSelfTest: document.querySelector("#assistSelfTest"),
  assistCheckResult: document.querySelector("#assistCheckResult"),
  acpButton: document.querySelector("#acpButton"),
  acpPanel: document.querySelector("#acpPanel"),
  acpStatus: document.querySelector("#acpStatus"),
  acpLadder: document.querySelector("#acpLadder"),
  acpReal: document.querySelector("#acpReal"),
  acpVerification: document.querySelector("#acpVerification"),
  acpQuota: document.querySelector("#acpQuota"),
  acpOpenTurns: document.querySelector("#acpOpenTurns"),
  acpPreviewTarget: document.querySelector("#acpPreviewTarget"),
  acpConfigForm: document.querySelector("#acpConfigForm"),
  acpRuntimePath: document.querySelector("#acpRuntimePath"),
  acpSha256: document.querySelector("#acpSha256"),
  acpConfigClear: document.querySelector("#acpConfigClear"),
  acpRuntimeInfo: document.querySelector("#acpRuntimeInfo"),
  acpCheck: document.querySelector("#acpCheck"),
  acpConnect: document.querySelector("#acpConnect"),
  acpDisconnect: document.querySelector("#acpDisconnect"),
  acpMethod: document.querySelector("#acpMethod"),
  acpLogin: document.querySelector("#acpLogin"),
  acpModels: document.querySelector("#acpModels"),
  acpOptions: document.querySelector("#acpOptions"),
  acpScopeMeta: document.querySelector("#acpScopeMeta"),
  acpInstruction: document.querySelector("#acpInstruction"),
  acpSelftest: document.querySelector("#acpSelftest"),
  acpSendSelection: document.querySelector("#acpSendSelection"),
  acpStop: document.querySelector("#acpStop"),
  acpPreview: document.querySelector("#acpPreview"),
  acpPreviewMeta: document.querySelector("#acpPreviewMeta"),
  acpPreviewPieces: document.querySelector("#acpPreviewPieces"),
  acpPreviewText: document.querySelector("#acpPreviewText"),
  acpConfirmSend: document.querySelector("#acpConfirmSend"),
  acpPreviewCancel: document.querySelector("#acpPreviewCancel"),
  acpError: document.querySelector("#acpError"),
  acpProgress: document.querySelector("#acpProgress"),
  acpResult: document.querySelector("#acpResult"),
  acpResultTitle: document.querySelector("#acpResultTitle"),
  acpResultNote: document.querySelector("#acpResultNote"),
  acpCandidate: document.querySelector("#acpCandidate"),
  acpCopy: document.querySelector("#acpCopy"),
  acpInsert: document.querySelector("#acpInsert"),
  acpSnapshotNote: document.querySelector("#acpSnapshotNote"),
  acpDiagnostics: document.querySelector("#acpDiagnostics"),
};

class ApiError extends Error {
  constructor(status, code, message) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
  }
}

async function requestJson(url, options) {
  let response;
  try {
    response = await fetch(url, options);
  } catch {
    setConnection("offline", "连接中断");
    throw new ApiError(0, "network_error", "无法连接本地 Dashboard 服务");
  }

  let payload;
  try {
    payload = await response.json();
  } catch {
    payload = null;
  }

  if (!response.ok) {
    throw new ApiError(
      response.status,
      payload?.error?.code || "request_failed",
      payload?.error?.message || `请求失败（${response.status}）`,
    );
  }
  setConnection("online", connectionLabel());
  return payload;
}

function serverReadOnly() {
  return state.workspace?.readOnly !== false;
}

function connectionLabel() {
  return serverReadOnly() ? "只读 · 仅本机" : "可改稿 · 先备份后保存 · 仅本机";
}

function setConnection(status, label) {
  elements.connectionStatus.dataset.state = status;
  elements.connectionStatus.querySelector("span:last-child").textContent = label;
}

function showToast(message, kind = "success") {
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.dataset.kind = kind;
  const text = document.createElement("p");
  text.textContent = message;
  toast.append(text);
  elements.toastRegion.append(toast);
  window.setTimeout(() => toast.remove(), 4200);
}

function formatNumber(value) {
  return new Intl.NumberFormat("zh-CN").format(value || 0);
}

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KiB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MiB`;
}

function countCharacters(content) {
  return [...content.replace(/\s/g, "")].length;
}

// textarea 的 value 永远是 LF：读盘时先归一化，写盘时再换回原文件的换行符，
// 否则 CRLF 稿件会被一次改动整篇重写，而且脏标记永远对不上、清不掉。
function detectEol(content) {
  let crlf = 0;
  let lf = 0;
  let cr = 0;
  for (let index = 0; index < content.length; index += 1) {
    if (content[index] === "\r") {
      if (content[index + 1] === "\n") {
        crlf += 1;
        index += 1;
      } else {
        cr += 1;
      }
    } else if (content[index] === "\n") {
      lf += 1;
    }
  }
  // 按 LF/CRLF 的主流风格回写；只有纯 CR 文件才保留 CR。一个粘贴进来的孤立 CR
  // 不能把每个 LF 都扩散成 CR，反过来也不能让 CRLF 稿件整篇变成 LF。
  if (crlf > lf) return "\r\n";
  if (lf > 0) return "\n";
  if (cr > 0) return "\r";
  return "\n";
}

function normalizeEol(content) {
  return content.replaceAll("\r\n", "\n").replaceAll("\r", "\n");
}

function applyEol(content, eol) {
  return !eol || eol === "\n" ? content : content.replaceAll("\n", eol);
}

function activeEol() {
  return state.activeFile?.eol || "\n";
}

function currentByteSize() {
  return new TextEncoder().encode(applyEol(elements.editorInput.value, activeEol())).length;
}

function fileExtension(name) {
  const index = name.lastIndexOf(".");
  return index >= 0 ? name.slice(index + 1) : "";
}

function iconSvg(kind) {
  if (kind === "folder") {
    return `<svg class="tree-icon folder-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 6.5h6l2 2h9v10h-17z"></path></svg>`;
  }
  return `<svg class="tree-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3.5h8l4 4v13H6z"></path><path d="M14 3.5v4h4M9 12h6M9 16h5"></path></svg>`;
}

function createTreeEntry(node, depth = 0) {
  const item = document.createElement("li");
  if (node.type === "directory") {
    const details = document.createElement("details");
    details.dataset.path = node.path;
    const shouldOpen =
      state.expandedDirs.has(node.path) ||
      (depth === 0 && !state.collapsedDirs.has(node.path));
    details.open = shouldOpen;
    // 只记录作者亲手的展开/收起；首层程序化展开不算偏好。
    let recorded = shouldOpen;
    details.addEventListener("toggle", () => {
      if (details.open === recorded) return;
      recorded = details.open;
      if (details.open) {
        state.expandedDirs.add(node.path);
        state.collapsedDirs.delete(node.path);
        if (!node.loaded && !node.loading) loadDirectory(node);
      } else {
        state.expandedDirs.delete(node.path);
        state.collapsedDirs.add(node.path);
      }
    });
    const summary = document.createElement("summary");
    summary.innerHTML = iconSvg("folder");
    const label = document.createElement("span");
    label.className = "tree-label";
    label.textContent = node.name;
    summary.append(label);
    details.append(summary);

    const list = document.createElement("ul");
    node.children.forEach((child) => {
      const childItem = createTreeEntry(child, depth + 1);
      if (childItem) list.append(childItem);
    });
    if (node.loading) {
      const loading = document.createElement("li");
      loading.className = "tree-inline-status";
      loading.textContent = "正在读取目录…";
      list.append(loading);
    } else if (node.loadError) {
      const retry = document.createElement("li");
      retry.className = "tree-inline-status";
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = "目录加载失败，点击重试";
      button.addEventListener("click", () => loadDirectory(node));
      retry.append(button);
      list.append(retry);
    } else if (node.loaded && node.children.length === 0) {
      const empty = document.createElement("li");
      empty.className = "tree-inline-status";
      empty.textContent = "空目录";
      list.append(empty);
    }
    if (node.nextCursor && !node.loading) {
      const more = document.createElement("li");
      more.className = "tree-inline-status";
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = "加载更多";
      button.addEventListener("click", () => loadDirectory(node, { append: true }));
      more.append(button);
      list.append(more);
    }
    details.append(list);
    item.append(details);
    if (shouldOpen && !node.loaded && !node.loading && !node.loadError && !node.loadQueued) {
      node.loadQueued = true;
      window.queueMicrotask(() => {
        node.loadQueued = false;
        if (!node.loaded && !node.loading && !node.loadError) loadDirectory(node);
      });
    }
    return item;
  }

  const button = document.createElement("button");
  button.type = "button";
  button.className = "file-row";
  button.dataset.path = node.path;
  button.dataset.active = String(state.activeFile?.path === node.path);
  button.disabled = !node.editable;
  button.title = node.editable ? node.path : `${node.path}（此文件类型只展示，不可编辑）`;
  button.innerHTML = iconSvg("file");

  const label = document.createElement("span");
  label.className = "tree-label";
  label.textContent = node.name;
  button.append(label);

  const extension = document.createElement("span");
  extension.className = "file-ext";
  extension.textContent = fileExtension(node.name);
  button.append(extension);
  if (node.editable) {
    button.addEventListener("click", () => openFile(node.path));
  }
  item.append(button);
  return item;
}

function mergeDirectoryEntries(node, entries, append) {
  if (!append) {
    node.children = entries;
    return;
  }
  const existingPaths = new Set(node.children.map((entry) => entry.path));
  node.children.push(...entries.filter((entry) => !existingPaths.has(entry.path)));
}

async function loadDirectory(node, { append = false } = {}) {
  if (node.loading) return;
  node.loading = true;
  node.loadError = "";
  renderTree();
  try {
    const cursor = append && node.nextCursor ? `&cursor=${encodeURIComponent(node.nextCursor)}` : "";
    const page = await requestJson(`/api/tree?path=${encodeURIComponent(node.path)}${cursor}`);
    mergeDirectoryEntries(node, page.entries, append);
    node.nextCursor = page.nextCursor;
    node.loaded = true;
  } catch (error) {
    node.loadError = error.message;
    showToast(error.message, "error");
  } finally {
    node.loading = false;
    renderLoadedFileCount();
    renderTree();
  }
}

function loadedFileCount() {
  const paths = new Set();
  function visit(node) {
    if (node.type === "file") {
      paths.add(node.path);
      return;
    }
    node.children.forEach(visit);
  }
  state.workspace?.libraries.forEach(visit);
  state.workspace?.projects.forEach(visit);
  return paths.size;
}

function renderLoadedFileCount() {
  if (!state.workspace) return;
  const count = loadedFileCount();
  elements.fileCount.textContent = count ? `${formatNumber(count)}+` : "按需";
  elements.fileCount.title = "文稿随目录展开按需加载，不预先遍历整个工作区";
}

// 只改当前高亮行，不重建整棵树——重建会把作者正在翻的目录全部收起
function syncActiveRow() {
  const activePath = state.activeFile?.path;
  elements.fileTree.querySelectorAll(".file-row").forEach((row) => {
    row.dataset.active = String(row.dataset.path === activePath);
  });
}

function searchTruncationMessage() {
  const status = state.searchTruncation;
  if (!status) return "";
  const messages = [];
  if (status.byResults) {
    messages.push(
      `匹配结果超过 ${formatNumber(status.limits.maxResults)} 条，仅显示最先找到的部分，请输入更精确的文件名`,
    );
  }
  if (status.byNodes) {
    messages.push(
      `搜索达到 ${formatNumber(status.limits.maxNodes)} 个节点的扫描上限，后续目录尚未检查，请直接展开目标目录查找`,
    );
  }
  if (status.byDepth) {
    messages.push(
      `部分目录超过 ${formatNumber(status.limits.maxDepth)} 层，更深处未搜索；其他项目已继续搜索`,
    );
  }
  if (status.byReadError) {
    const paths = status.scanErrors.map((entry) => entry.path).filter(Boolean);
    const shown = paths.slice(0, 3).join("、") || "部分目录";
    const more = paths.length > 3 ? `等 ${formatNumber(paths.length)} 处` : "";
    messages.push(
      `${shown}${more}无法读取，搜索结果可能不完整。请检查目录访问权限或外挂盘挂载状态`,
    );
  }
  return messages.join("；");
}

function renderTree() {
  elements.fileTree.replaceChildren();
  elements.treeLoading.hidden = true;
  const query = state.filter.trim();
  const collection = query
    ? state.searchResults
    : state.workspace?.[state.activeView] || [];

  if (query && state.searching) {
    const message = document.createElement("div");
    message.className = "tree-message";
    const text = document.createElement("p");
    text.textContent = `正在搜索“${query}”…`;
    message.append(text);
    elements.fileTree.append(message);
    return;
  }

  if (!collection.length) {
    const message = document.createElement("div");
    message.className = "tree-message";
    const text = document.createElement("p");
    text.textContent = query
      ? state.searchTruncation
        ? `搜索未完成，暂时无法确认是否存在“${query}”`
        : `没有找到“${query}”`
      : state.activeView === "libraries"
        ? "工作区里还没有拆文库。运行拆文 skill 后，档案会出现在这里。"
        : "还没有识别到写作项目。长篇需包含正文、大纲、设定或追踪目录；短篇需包含正文.md，并同时包含小节大纲.md或设定.md。";
    message.append(text);
    elements.fileTree.append(message);
    const truncation = searchTruncationMessage();
    if (query && truncation) {
      const status = document.createElement("div");
      status.className = "tree-message";
      status.setAttribute("role", "status");
      const statusText = document.createElement("p");
      statusText.textContent = truncation;
      status.append(statusText);
      elements.fileTree.append(status);
    }
    return;
  }

  const list = document.createElement("ul");
  collection.forEach((node) => {
    const item = createTreeEntry(node);
    if (item) list.append(item);
  });
  const truncation = searchTruncationMessage();
  if (query && truncation) {
    const status = document.createElement("li");
    status.className = "tree-inline-status";
    status.setAttribute("role", "status");
    status.textContent = truncation;
    list.append(status);
  }
  elements.fileTree.append(list);
}

function truncationMessage(scanErrors = []) {
  const paths = scanErrors.map((entry) => entry.path).filter(Boolean);
  const shown = paths.slice(0, 3).join("、") || "部分目录";
  const more = paths.length > 3 ? `等 ${formatNumber(paths.length)} 处` : "";
  return `${shown}${more}无法读取，其中的文稿没有列出。请检查这些目录的访问权限和外挂盘挂载状态，恢复后刷新目录。`;
}

function renderTruncationNotice(limits, scanErrors) {
  if (!limits?.truncated) {
    elements.truncationNotice?.remove();
    elements.truncationNotice = null;
    return;
  }
  if (!elements.truncationNotice) {
    const notice = document.createElement("div");
    notice.id = "treeTruncationNotice";
    notice.className = "tree-message";
    notice.setAttribute("role", "status");
    notice.append(document.createElement("p"));
    elements.treePanel.insertBefore(notice, elements.fileTree);
    elements.truncationNotice = notice;
  }
  elements.truncationNotice.querySelector("p").textContent = truncationMessage(scanErrors);
}

function renderWorkspace() {
  const { workspace, stats, libraries, projects, limits, scanErrors } = state.workspace;
  elements.workspaceName.textContent = workspace.name;
  elements.workspacePath.textContent = workspace.path;
  elements.workspacePath.title = workspace.path;
  elements.libraryCount.textContent = formatNumber(stats.libraries);
  elements.projectCount.textContent = formatNumber(stats.projects);
  renderLoadedFileCount();
  elements.librariesBadge.textContent = formatNumber(libraries.length);
  elements.projectsBadge.textContent = formatNumber(projects.length);
  renderTruncationNotice(limits, scanErrors);
  renderTree();
}

async function loadWorkspace({ announce = false } = {}) {
  window.clearTimeout(state.searchTimer);
  state.searchSequence += 1;
  elements.treeLoading.hidden = false;
  elements.fileTree.replaceChildren();
  setConnection("", "连接中");
  try {
    state.workspace = await requestJson("/api/workspace");
    syncActionAvailability();
    state.searchResults = [];
    state.searchTruncation = null;
    state.searching = Boolean(state.filter.trim());
    renderWorkspace();
    if (!state.restored) await restoreViewState();
    if (state.filter.trim()) scheduleSearch();
    if (announce) showToast("工作区目录已刷新");
  } catch (error) {
    elements.treeLoading.hidden = true;
    const message = document.createElement("div");
    message.className = "tree-message";
    const text = document.createElement("p");
    text.textContent = error.message;
    message.append(text);
    elements.fileTree.replaceChildren(message);
    showToast(error.message, "error");
  }
}

// 离开有未保存修改的文稿前：先把修改记成草稿，再问作者。草稿下次打开这份文稿时可以恢复。
function confirmDiscard() {
  if (!state.dirty) return true;
  writeDraftNow();
  return window.confirm("当前文稿还有未保存的修改。离开后修改会留作草稿，下次打开这份文稿时可以恢复。确定打开另一份吗？");
}

function renderSaveState() {
  let key = "readonly";
  let label = "只读";
  if (state.saving) [key, label] = ["saving", "保存中"];
  else if (state.saveError) [key, label] = ["failed", "保存失败"];
  else if (state.dirty) [key, label] = ["dirty", "未保存"];
  else if (state.editing) [key, label] = state.lastSavedAt ? ["saved", "已保存"] : ["editing", "编辑中"];
  elements.dirtyStatus.dataset.state = key;
  elements.dirtyStatus.querySelector("span:last-child").textContent = label;
  elements.dirtyStatus.title = state.saveError
    ? `上次保存没有成功：${state.saveError}。修改还在页面里，也记成了草稿；磁盘上的原稿没有被改动。`
    : "";
}

function setDirty(dirty) {
  state.dirty = dirty;
  renderSaveState();
  syncActionAvailability();
}

function syncActionAvailability() {
  const busy = state.loadingFile || state.saving || state.deleting;
  const readOnly = serverReadOnly();
  elements.editorInput.readOnly = readOnly || !state.editing;
  if (state.workspace) setConnection("online", connectionLabel());
  elements.saveButton.disabled = readOnly || !state.editing || busy || !state.dirty;
  elements.saveButton.title = readOnly ? "写作台是以只读方式打开的" : "保存前自动备份原稿";
  elements.editToggle.disabled = readOnly || busy || !state.activeFile;
  elements.editToggle.setAttribute("aria-pressed", String(state.editing));
  elements.editToggle.querySelector("span").textContent = state.editing ? "结束编辑" : "开始编辑";
  elements.editToggle.title = readOnly
    ? "写作台是以只读方式打开的。要改稿：关掉写作台窗口，双击 open-workbench-edit 重新打开"
    : state.editing
      ? state.dirty ? "先保存或放弃修改，才能结束编辑" : "回到只读"
      : "打开这份文稿的编辑";
  elements.discardButton.hidden = !state.dirty;
  elements.discardButton.disabled = busy;
  elements.deleteButton.disabled = true;
  elements.deleteButton.hidden = true;
  renderSaveState();
  renderAssist();
  renderAcp();
}

function setSaving(saving) {
  state.saving = saving;
  syncActionAvailability();
}

function setEditing(editing) {
  if (editing && serverReadOnly()) {
    showToast("写作台是以只读方式打开的。要改稿：关掉写作台窗口，双击 open-workbench-edit 重新打开。", "error");
    return false;
  }
  if (!editing && state.dirty) {
    showToast("还有未保存的修改：先保存，或者点“放弃修改”。", "error");
    return false;
  }
  state.editing = editing;
  if (editing && state.mode === "preview") setMode("edit");
  syncActionAvailability();
  if (editing) window.requestAnimationFrame(() => elements.editorInput.focus());
  return true;
}

// ---- 草稿：未保存的修改记在这台浏览器里，换文件、刷新、关页面都不丢；保存成功或作者丢弃后才清掉。
const DRAFT_PREFIX = "story_dashboard_draft:";

function draftKey(path) {
  return `${DRAFT_PREFIX}${state.workspace?.workspace?.path || ""}:${path}`;
}

function readDraft(path) {
  try {
    const draft = JSON.parse(localStorage.getItem(draftKey(path)));
    return draft && typeof draft.text === "string" ? draft : null;
  } catch {
    return null;
  }
}

function clearDraft(path) {
  try {
    localStorage.removeItem(draftKey(path));
  } catch {}
}

function writeDraftNow() {
  window.clearTimeout(state.draftTimer);
  state.draftTimer = null;
  const file = state.activeFile;
  if (!file) return;
  try {
    if (state.dirty) {
      localStorage.setItem(
        draftKey(file.path),
        JSON.stringify({ text: elements.editorInput.value, baseVersion: file.version, savedAt: Date.now() }),
      );
    } else {
      localStorage.removeItem(draftKey(file.path));
    }
  } catch {
    if (!state.draftWarned) {
      state.draftWarned = true;
      showToast("这台浏览器不让记草稿：修改只在当前页面里，关页面前记得保存。", "error");
    }
  }
}

function scheduleDraft() {
  window.clearTimeout(state.draftTimer);
  state.draftTimer = window.setTimeout(writeDraftNow, 500);
}

function showDraftNotice() {
  const file = state.activeFile;
  const draft = file ? readDraft(file.path) : null;
  state.draftNotice = null;
  elements.draftBanner.hidden = true;
  if (!draft) return;
  if (draft.text === state.originalContent) {
    clearDraft(file.path);
    return;
  }
  state.draftNotice = draft;
  const when = new Date(draft.savedAt).toLocaleString("zh-CN", { hour12: false });
  const stale = draft.baseVersion !== file.version;
  elements.draftText.textContent = `这份文稿有一份 ${when} 留下、还没保存的草稿。`
    + (stale ? "那以后磁盘上的文稿又改过：恢复后保存时会先提示冲突，不会直接覆盖。" : "");
  elements.draftRestore.disabled = serverReadOnly();
  elements.draftRestore.title = serverReadOnly() ? "只读方式打开时不能恢复；双击 open-workbench-edit 重新打开" : "";
  elements.draftBanner.hidden = false;
}

function restoreDraft() {
  const file = state.activeFile;
  const draft = state.draftNotice;
  if (!file || !draft || serverReadOnly()) return;
  state.editing = true;
  if (state.mode === "preview") setMode("edit");
  elements.editorInput.value = draft.text;
  // 保存时按草稿当初依据的版本核对：磁盘后来改过，服务端会报冲突，不会悄悄覆盖。
  file.version = draft.baseVersion;
  elements.draftBanner.hidden = true;
  state.draftNotice = null;
  setDirty(elements.editorInput.value !== state.originalContent);
  updateDocumentMeta();
  scheduleLineNumbers();
  showToast("已恢复草稿，还没有保存");
}

function discardDraft() {
  if (!state.activeFile) return;
  if (!window.confirm("丢弃这份草稿？丢弃后找不回来。")) return;
  clearDraft(state.activeFile.path);
  elements.draftBanner.hidden = true;
  state.draftNotice = null;
}

function discardChanges() {
  if (!state.dirty || !state.activeFile) return;
  if (!window.confirm("放弃这份文稿里还没保存的修改，回到磁盘上的版本？")) return;
  elements.editorInput.value = state.originalContent;
  state.activeFile.version = state.activeFile.diskVersion;
  clearDraft(state.activeFile.path);
  state.saveError = null;
  setDirty(false);
  updateDocumentMeta();
  scheduleLineNumbers();
}

// ---- 对比：按段（行）比，前后相同的部分折起来。
function diffTokens(a, b) {
  let start = 0;
  while (start < a.length && start < b.length && a[start] === b[start]) start += 1;
  let endA = a.length;
  let endB = b.length;
  while (endA > start && endB > start && a[endA - 1] === b[endB - 1]) {
    endA -= 1;
    endB -= 1;
  }
  const midA = a.slice(start, endA);
  const midB = b.slice(start, endB);
  const ops = [];
  a.slice(0, start).forEach((text) => ops.push({ type: "same", text }));
  if (midA.length * midB.length > 4_000_000) {
    midA.forEach((text) => ops.push({ type: "del", text }));
    midB.forEach((text) => ops.push({ type: "add", text }));
  } else {
    const n = midA.length;
    const m = midB.length;
    const table = Array.from({ length: n + 1 }, () => new Uint32Array(m + 1));
    for (let i = n - 1; i >= 0; i -= 1) {
      for (let j = m - 1; j >= 0; j -= 1) {
        table[i][j] = midA[i] === midB[j] ? table[i + 1][j + 1] + 1 : Math.max(table[i + 1][j], table[i][j + 1]);
      }
    }
    let i = 0;
    let j = 0;
    while (i < n && j < m) {
      if (midA[i] === midB[j]) {
        ops.push({ type: "same", text: midA[i] });
        i += 1;
        j += 1;
      } else if (table[i + 1][j] >= table[i][j + 1]) {
        ops.push({ type: "del", text: midA[i] });
        i += 1;
      } else {
        ops.push({ type: "add", text: midB[j] });
        j += 1;
      }
    }
    while (i < n) ops.push({ type: "del", text: midA[i++] });
    while (j < m) ops.push({ type: "add", text: midB[j++] });
  }
  a.slice(endA).forEach((text) => ops.push({ type: "same", text }));
  return ops;
}

function sentences(text) {
  return text.match(/[^。！？；…\n]+[。！？；…」”』]*|\n/g) || [];
}

function renderDiff(container, ops, { joiner = "block" } = {}) {
  const fragment = document.createDocumentFragment();
  let sameRun = [];
  const flushSame = () => {
    if (!sameRun.length) return;
    if (joiner === "block" && sameRun.length > 4) {
      const head = sameRun.slice(0, 2);
      const tail = sameRun.slice(-2);
      [...head].forEach((text) => fragment.append(diffNode("same", text, joiner)));
      const fold = document.createElement(joiner === "block" ? "p" : "span");
      fold.className = "diff-fold";
      fold.textContent = `……（${sameRun.length - 4} 段相同）`;
      fragment.append(fold);
      tail.forEach((text) => fragment.append(diffNode("same", text, joiner)));
    } else {
      sameRun.forEach((text) => fragment.append(diffNode("same", text, joiner)));
    }
    sameRun = [];
  };
  ops.forEach((op) => {
    if (op.type === "same") {
      sameRun.push(op.text);
      return;
    }
    flushSame();
    fragment.append(diffNode(op.type, op.text, joiner));
  });
  flushSame();
  container.replaceChildren(fragment);
}

function diffNode(type, text, joiner) {
  const node = document.createElement(type === "same" ? (joiner === "block" ? "p" : "span") : type === "del" ? "del" : "ins");
  node.className = `diff-${type}${joiner === "block" ? " diff-block" : ""}`;
  node.textContent = text === "" ? "（空行）" : text;
  return node;
}

async function openCompare(source = "opened") {
  const file = state.activeFile;
  if (!file) return;
  let baseText = state.originalContent;
  let baseLabel = "打开时（或上次保存后）的版本";
  let otherText = elements.editorInput.value;
  let otherLabel = "页面里现在的文字";
  if (source === "disk") {
    try {
      const disk = await requestJson(`/api/file?path=${encodeURIComponent(file.path)}`);
      baseText = normalizeEol(disk.content);
      baseLabel = "磁盘上现在的版本";
    } catch (error) {
      showToast(error.message, "error");
      return;
    }
  } else if (source === "draft" && state.draftNotice) {
    otherText = state.draftNotice.text;
    otherLabel = "草稿";
  }
  const ops = diffTokens(baseText.split("\n"), otherText.split("\n"));
  const removed = ops.filter((op) => op.type === "del").length;
  const added = ops.filter((op) => op.type === "add").length;
  elements.compareSummary.textContent = removed || added
    ? `${baseLabel} → ${otherLabel}：删去 ${removed} 段、加入 ${added} 段（改动的段两边各算一次）。`
    : `${baseLabel}和${otherLabel}一样。`;
  renderDiff(elements.compareView, ops);
  setSidePanel("compare");
}

function setSidePanel(name) {
  state.sidePanel = name;
  elements.sidePanel.hidden = !name;
  elements.comparePanel.hidden = name !== "compare";
  elements.assistPanel.hidden = name !== "assist";
  elements.acpPanel.hidden = name !== "acp";
  elements.sidePanelTitle.textContent = name === "compare" ? "版本对比" : name === "assist" ? "改稿建议" : name === "acp" ? "Google AI（官方 ACP 运行时）" : "";
  elements.compareButton.setAttribute("aria-pressed", String(name === "compare"));
  elements.assistButton.setAttribute("aria-pressed", String(name === "assist"));
  elements.acpButton.setAttribute("aria-pressed", String(name === "acp"));
  document.body.classList.toggle("side-panel-open", Boolean(name));
  if (name === "assist") {
    captureSelection();
    loadAssistStatus();
  }
  if (name === "acp") {
    captureAcpSelection();
    loadAcpStatus();
  } else {
    window.clearTimeout(state.acp.pollTimer);
    state.acp.pollTimer = null;
  }
}

// ---- 改稿建议（可选的 Gemini）：只发作者选中的文字和要求；结果是候选，采纳才进文稿，保存照常走备份和版本核对。
async function loadAssistStatus() {
  try {
    state.assist.status = await requestJson("/api/assist/status");
  } catch (error) {
    state.assist.status = { state: "error", label: "读不到状态", lastError: error.message, model: "" };
  }
  renderAssist();
}

function captureSelection() {
  const input = elements.editorInput;
  if (!state.activeFile || elements.editorContainer.hidden) return;
  const start = input.selectionStart;
  const end = input.selectionEnd;
  state.assist.selection = end > start ? { start, end, text: input.value.slice(start, end), path: state.activeFile.path } : null;
  renderAssist();
}

function renderAssist() {
  if (!elements.assistPanel) return;
  const status = state.assist.status;
  const configured = status && ["configured", "connected", "failed"].includes(status.state);
  if (status) {
    elements.assistStatus.dataset.state = status.state;
    elements.assistStatus.textContent = assistStatusText(status);
    if (!elements.assistModel.value && status.model) elements.assistModel.value = status.model;
    const sample = status.selftestSample;
    elements.assistSample.textContent = sample ? `${sample.text}\n（要求：${sample.instruction}）` : "";
  }
  const checking = state.assist.check.busy;
  elements.assistListModels.disabled = !configured || Boolean(checking) || state.assist.busy;
  elements.assistSelfTest.disabled = !configured || Boolean(checking) || state.assist.busy;
  elements.assistListModels.textContent = checking === "list" ? "正在查…" : "查可用模型";
  elements.assistSelfTest.textContent = checking === "selftest" ? "等 Gemini 回复…" : "用合成示例试一次";
  const selection = state.assist.selection;
  if (selection && state.activeFile && selection.path === state.activeFile.path) {
    const chars = [...selection.text].length;
    elements.assistScopeText.textContent = selection.text.length > 400 ? `${selection.text.slice(0, 400)}……` : selection.text;
    elements.assistScopeMeta.textContent = `将发送：上面这 ${chars} 字，加上你写的要求；不发送文稿的其他部分、文件名和路径。`;
  } else {
    elements.assistScopeText.textContent = "";
    elements.assistScopeMeta.textContent = "先在文稿里选中要改的那段（原文视图下拖选），再回到这里。";
  }
  const ready = configured && selection && state.activeFile && selection.path === state.activeFile.path;
  elements.assistSend.disabled = !ready || state.assist.busy || Boolean(checking);
  elements.assistSend.querySelector("span").textContent = state.assist.busy
    ? "等 Gemini 回复…"
    : ready ? `把这 ${[...selection.text].length} 字发给 Gemini` : "发给 Gemini";
  elements.assistError.hidden = !state.assist.error;
  elements.assistError.textContent = state.assist.error || "";
  const result = state.assist.result;
  elements.assistResult.hidden = !result;
  elements.assistApply.disabled = !result || serverReadOnly();
  elements.assistApply.title = serverReadOnly() ? "只读方式打开时不能换进文稿，可以复制候选稿" : "";
}

async function sendAssist() {
  const selection = state.assist.selection;
  if (!selection || state.assist.busy) return;
  state.assist.busy = true;
  state.assist.error = null;
  renderAssist();
  try {
    const result = await requestJson("/api/assist/revise", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: selection.text, instruction: elements.assistInstruction.value }),
    });
    state.assist.result = { ...result, selection };
    elements.assistCandidate.value = result.candidate;
    elements.assistNote.hidden = !result.unchanged;
    elements.assistNote.textContent = result.unchanged ? "Gemini 原样交回了这段，没有改动。" : "";
    renderDiff(elements.assistDiff, diffTokens(sentences(selection.text), sentences(result.candidate)), { joiner: "inline" });
  } catch (error) {
    state.assist.error = error.message;
  } finally {
    state.assist.busy = false;
    await loadAssistStatus();
  }
}

function applyCandidate() {
  const result = state.assist.result;
  const file = state.activeFile;
  if (!result || !file) return;
  if (result.selection.path !== file.path) {
    state.assist.error = "这份候选稿属于另一份文稿，没有换进来。";
    renderAssist();
    return;
  }
  if (!state.editing && !setEditing(true)) return;
  const input = elements.editorInput;
  const { start, end, text } = result.selection;
  if (input.value.slice(start, end) !== text) {
    state.assist.error = "选中的那段在发出以后又改过了，没有替换。可以复制候选稿，自己贴到合适的位置。";
    renderAssist();
    return;
  }
  replaceEditorRange(start, end, elements.assistCandidate.value);
  state.assist.result = null;
  state.assist.selection = null;
  state.assist.error = null;
  renderAssist();
  showToast("候选稿已换进文稿，还没有保存");
}

// 把编辑器里 start–end 这一段换成 replacement。insertText 走浏览器自己的撤销栈：换进来以后 Ctrl+Z 能撤回。
// 换完文稿只是“未保存”（记成草稿），保存照常先备份、再核对版本。
// 文本框里的换行只有 LF：先把 CR/CRLF 换成 LF，替换后的核对才是拿同样的东西比。
function normalizeNewlines(text) {
  return String(text).replace(/\r\n?/g, "\n");
}

// 放进编辑器的文字：候选稿本身去掉首尾空白，选区自己开头、结尾的空白（全角缩进、换行）照原样留着，
// 免得放进来以后缩进没了、两段粘在一起。
function acpInsertionText(selectionText, candidate) {
  const lead = selectionText.match(/^\s*/u)[0];
  const trail = selectionText.match(/\s*$/u)[0];
  return `${lead}${normalizeNewlines(candidate).trim()}${trail}`;
}

function replaceEditorRange(start, end, rawReplacement) {
  const replacement = normalizeNewlines(rawReplacement);
  const input = elements.editorInput;
  if (state.mode === "preview") setMode("edit");
  input.focus();
  input.setSelectionRange(start, end);
  let inserted = false;
  try {
    inserted = document.execCommand("insertText", false, replacement);
  } catch {}
  if (!inserted || input.value.slice(start, start + replacement.length) !== replacement) {
    input.setRangeText(replacement, start, end, "end");
    input.dispatchEvent(new Event("input", { bubbles: true }));
  }
}

function discardCandidate() {
  state.assist.result = null;
  state.assist.error = null;
  renderAssist();
}

function formatWhen(iso) {
  const date = new Date(iso);
  return Number.isNaN(date.getTime()) ? "" : date.toLocaleString("zh-CN", { hour12: false });
}

// “已配置”只说明填了密钥；只有向 Google 官方地址的请求真的拿回候选稿，才说“已真实接通”。
function assistStatusText(status) {
  const where = status.keyLocation ? `，密钥在${status.keyLocation}` : "";
  const last = status.lastCall;
  if (status.state === "unconfigured") return "未配置：填入你自己的 Gemini API Key 才能用。不配置也不影响读写文稿。";
  if (status.state === "connected") {
    const version = last.modelVersion ? `（Google 返回的版本 ${last.modelVersion}）` : "";
    return `已真实接通：${formatWhen(last.at)} 向 Google 官方接口调用 ${last.model} 成功${version}${where}。`;
  }
  if (status.state === "failed") return `上次调用失败：${status.lastError || "没有成功"}（模型 ${status.model}${where}）`;
  if (status.state === "configured") {
    const custom = last && last.ok && last.endpoint !== "official"
      ? "上次调用用的不是 Google 官方地址，不算真实接通。"
      : "还没有真实调用成功过，可以在“配置 Gemini”里用合成示例试一次。";
    return `已配置（模型 ${status.model}${where}）。${custom}`;
  }
  return `读不到状态：${status.lastError || ""}`;
}

function renderCheckResult(kind, payload) {
  const box = elements.assistCheckResult;
  box.replaceChildren();
  box.hidden = false;
  box.dataset.state = kind;
  const line = (text) => {
    const p = document.createElement("p");
    p.textContent = text;
    box.append(p);
    return p;
  };
  if (kind === "error") {
    line(payload);
    return;
  }
  if (kind === "models") {
    const { models, configured, configuredListed, endpoint } = payload;
    line(`这个 Key 能用 ${models.length} 个能生成文字的模型。现在设置的 ${configured} ${configuredListed ? "在清单里" : "不在清单里：换成清单里的一个，或核对拼写"}。${endpoint === "official" ? "" : "（清单来自自定义服务地址，不是 Google 官方接口）"}`);
    if (models.length) {
      line("点一个模型名会填进上面的模型栏，再点“保存到本机”才生效：");
      const list = document.createElement("div");
      list.className = "assist-model-list";
      for (const model of models) {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = model.id;
        button.title = model.displayName || model.id;
        if (model.id === configured || model.baseModelId === configured) button.setAttribute("aria-current", "true");
        button.addEventListener("click", () => {
          elements.assistModel.value = model.id;
          elements.assistModel.focus();
          showToast(`已填进模型栏：${model.id}；点“保存到本机”生效`);
        });
        list.append(button);
      }
      box.append(list);
    }
    return;
  }
  const seconds = (payload.elapsedMs / 1000).toFixed(1);
  line(payload.real
    ? `成功：这是一次向 Google 官方接口的真实调用。模型 ${payload.model}，Google 返回的版本 ${payload.modelVersion || "没有给出"}，用了 ${seconds} 秒。`
    : `请求成功了，但用的不是 Google 官方地址（自定义服务地址），不算真实接通。用了 ${seconds} 秒。`);
  line(payload.unchanged ? "Gemini 原样交回了合成示例。候选稿：" : "候选稿（只是看看，不会写进任何文稿）：");
  const quote = document.createElement("blockquote");
  quote.className = "assist-scope-text";
  quote.textContent = payload.candidate;
  box.append(quote);
}

async function runAssistCheck(kind) {
  if (state.assist.check.busy || state.assist.busy) return;
  state.assist.check.busy = kind;
  renderAssist();
  try {
    const payload = await requestJson(kind === "list" ? "/api/assist/models" : "/api/assist/selftest", { method: "POST" });
    renderCheckResult(kind === "list" ? "models" : "selftest", payload);
  } catch (error) {
    renderCheckResult("error", error.message);
  } finally {
    state.assist.check.busy = null;
    await loadAssistStatus();
  }
}

async function saveAssistConfig(payload) {
  try {
    state.assist.status = await requestJson("/api/assist/config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    elements.assistKey.value = "";
    state.assist.error = null;
    showToast(payload.clear ? "已清除本机保存的 Gemini 配置" : "已保存到本机用户配置目录");
  } catch (error) {
    state.assist.error = error.message;
  }
  renderAssist();
}

// ---- Google AI（官方 ACP 运行时，可选）：登录、账号和令牌都由 Google 官方程序自己处理，页面只和本机服务说话。
// 每个会动东西的请求都带页面令牌（从同源的 GET 取得，只放在内存里）。回复只是候选：复制，或放进编辑器变成未保存的修改，
// 保存照常先备份、核对版本。只读方式打开时可以看、可以复制，不能放进编辑器。
const ACP_PIECE_LABELS = { frame: "固定的编辑说明", instruction: "“作者的要求：”加你写的要求", selection: "“要改的正文：”加你选中的那段", sample: "“要改的正文：”加工坊自带的合成示例" };
const ACP_STATE_HINTS = {
  not_checked: "还没检查官方程序：点“检查运行时”。不用这个功能就别连接，写作台不会在后台运行任何东西。",
  needs_login: "已经连上官方程序（握手成功），还没有登录。点“用 Google 登录”；以前在这台电脑上用 agy 登录过的，也可以直接点“选择模型和思考强度”试试。",
  authenticated: "登录成功（已认证）。“已认证”只说明登录成功，还没有真实请求过：点“选择模型和思考强度”。",
  ready: "可以发送。第一次先发合成示例，确认真的能拿回回复。",
};

function acpTaskActive() {
  const task = state.acp.status?.task;
  return Boolean(task && task.state !== "finished");
}

async function acpToken() {
  if (!state.acp.token) state.acp.token = (await requestJson("/api/acp/token")).token;
  return state.acp.token;
}

async function acpPost(route, body = {}) {
  const token = await acpToken();
  try {
    return await requestJson(`/api/acp/${route}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Novel-Workshop-Token": token },
      body: JSON.stringify(body),
    });
  } catch (error) {
    // 写作台重启过，令牌换了：下次点击重新取。被拒的请求什么也没做，不替作者自动重发。
    if (error instanceof ApiError && error.code === "acp_token_invalid") state.acp.token = null;
    throw error;
  }
}

async function loadAcpStatus() {
  try {
    state.acp.status = await requestJson("/api/acp/status");
    state.acp.loadError = null;
  } catch (error) {
    state.acp.loadError = error.message;
  }
  renderAcp();
  scheduleAcpPoll();
}

function scheduleAcpPoll() {
  window.clearTimeout(state.acp.pollTimer);
  state.acp.pollTimer = null;
  const status = state.acp.status;
  if (state.sidePanel === "acp" && (status?.busy || acpTaskActive())) {
    state.acp.pollTimer = window.setTimeout(loadAcpStatus, 800);
  }
}

// 一次会等官方程序的操作（检查、连接、登录、开会话）：等的时候照样刷新状态，能看到“正在登录”。
async function runAcp(route, body = {}) {
  if (state.acp.busy) return null;
  state.acp.busy = route;
  state.acp.error = null;
  // 换了程序、模型、思考强度或重新连接、登录：刚才的预览不再对应要发给谁，作废。
  if (["config", "check", "connect", "login", "models", "set-option"].includes(route)) state.acp.preview = null;
  renderAcp();
  const watch = window.setInterval(async () => {
    try {
      state.acp.status = await requestJson("/api/acp/status");
      renderAcp();
    } catch {}
  }, 1000);
  try {
    const result = await acpPost(route, body);
    if (result?.ladder) state.acp.status = result;
    else if (result?.status?.ladder) state.acp.status = result.status;
    return result;
  } catch (error) {
    state.acp.error = error.message;
    return null;
  } finally {
    window.clearInterval(watch);
    state.acp.busy = null;
    await loadAcpStatus();
  }
}

// 断开和停止不排队：登录等着、回复等着的时候也要能点。
async function acpImmediate(route, body = {}) {
  state.acp.error = null;
  if (route === "disconnect") state.acp.preview = null;
  try {
    const result = await acpPost(route, body);
    if (result?.ladder) state.acp.status = result;
  } catch (error) {
    state.acp.error = error.message;
  }
  await loadAcpStatus();
}

function captureAcpSelection() {
  const input = elements.editorInput;
  if (!state.activeFile || elements.editorContainer.hidden) {
    renderAcp();
    return;
  }
  const start = input.selectionStart;
  const end = input.selectionEnd;
  state.acp.selection = end > start
    ? { start, end, text: input.value.slice(start, end), path: state.activeFile.path, version: state.activeFile.version }
    : null;
  const preview = state.acp.preview;
  if (preview?.kind === "selection" && preview.selection?.text !== state.acp.selection?.text) {
    // 选区变了：刚才的预览不再是要发的东西。
    state.acp.preview = null;
  }
  renderAcp();
}

async function acpShowPreview(kind) {
  const selection = state.acp.selection;
  if (kind === "selection" && !selection) return;
  const payload = kind === "selftest"
    ? { kind: "selftest" }
    : { kind: "selection", text: selection.text, instruction: elements.acpInstruction.value, source: { path: selection.path, version: selection.version } };
  state.acp.error = null;
  try {
    const preview = await acpPost("preview", payload);
    state.acp.preview = { kind, payload, blocks: preview.blocks, snapshot: preview.snapshot, selection: kind === "selection" ? { ...selection } : null };
  } catch (error) {
    state.acp.error = error.message;
  }
  renderAcp();
}

async function acpConfirmSend() {
  const preview = state.acp.preview;
  if (!preview) return;
  let acknowledgeQuota = false;
  if (state.acp.status?.quotaPause) {
    const ok = window.confirm("上一次官方程序说额度受限，工坊暂停了发送。你在官方产品里看过额度、确定要再试一次吗？工坊不会自动重试，也不会改用 API。");
    if (!ok) return;
    acknowledgeQuota = true;
  }
  const { kind: _kind, ...rest } = preview.payload;
  const result = await runAcp(preview.kind === "selftest" ? "selftest" : "prompt", { ...rest, expectedDigest: preview.snapshot.digest, acknowledgeQuota });
  if (result?.taskId) {
    state.acp.sent = { taskId: result.taskId, kind: preview.kind, selection: preview.selection };
    state.acp.preview = null;
  }
  renderAcp();
}

async function acpCopy() {
  const text = elements.acpCandidate.value;
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
    showToast("已复制");
  } catch {
    elements.acpCandidate.focus();
    elements.acpCandidate.select();
    let copied = false;
    try {
      copied = document.execCommand("copy");
    } catch {}
    showToast(copied ? "已复制" : "复制没成功：手动选中候选稿再复制", copied ? "success" : "error");
  }
}

function acpInsert() {
  const task = state.acp.status?.task;
  const sent = state.acp.sent;
  const file = state.activeFile;
  if (serverReadOnly() || !task?.insertable || !task.candidate || !sent?.selection || sent.taskId !== task.id) return;
  if (!file || sent.selection.path !== file.path) {
    state.acp.error = "这份候选稿属于另一份文稿，没有放进来。可以复制，自己贴到合适的位置。";
    renderAcp();
    return;
  }
  if (!state.editing && !setEditing(true)) return;
  const { start, end, text } = sent.selection;
  if (elements.editorInput.value.slice(start, end) !== text) {
    state.acp.error = "选中的那段在发出以后又改过了，没有替换。可以复制候选稿，自己贴到合适的位置。";
    renderAcp();
    return;
  }
  replaceEditorRange(start, end, acpInsertionText(text, task.candidate));
  state.acp.inserted = task.id;
  state.acp.error = null;
  renderAcp();
  showToast("候选稿已放进编辑器，还没有保存；保存时照常先备份、核对版本");
}

function acpStatusText(status) {
  if (!status) return state.acp.loadError ? `读不到状态：${state.acp.loadError}` : "正在读取状态…";
  if (status.busy) return `${status.baseLabel || status.label}：${status.busy.label}……`;
  const detail = status.message || ACP_STATE_HINTS[status.state] || ACP_STATE_HINTS[status.baseState] || "";
  if (!detail) return status.label;
  return detail.startsWith(status.label) ? detail : `${status.label}：${detail}`;
}

function acpRealText(status) {
  if (!status) return "";
  const real = status.real;
  if (real && status.realCurrent) {
    const model = real.requestedModel ? `${real.requestedModel.name}${real.requestedModel.chosen ? "" : "（官方程序默认）"}` : "未知";
    const info = real.agentInfo ? `${real.agentInfo.title || real.agentInfo.name || "未知"} ${real.agentInfo.version || ""}`.trim() : "未知";
    return `已真实接通：${formatWhen(real.at)}，请求的模型 ${model}，官方程序回报的会话模型设置 ${real.reportedModel?.name || "未知"}，运行时 ${real.runtimePath}${real.runtimeVersion ? `（${real.runtimeVersion}）` : ""}，agentInfo ${info}。这只说明连接能用，不说明可以把订阅用于写小说。`;
  }
  if (real) return `以前真实接通过（${formatWhen(real.at)}），之后重新连接或登录过（工坊看不到这期间有没有在终端换账号、升级程序）：再发一次合成示例才算现在的状态。`;
  // 旧版本按“自称 Antigravity”记下的：没有核对程序来源，只当历史，不算真实接通。
  if (status.legacyReal && !(status.lastSimulated && String(status.lastSimulated.at) > String(status.legacyReal.at))) {
    return `以前接通过（旧规则，来源未核对，${formatWhen(status.legacyReal.at)}）：那是旧版本按“自称 Antigravity”记下的，不算真实接通。要算真实接通，填上你核对过的 SHA-256，再发一次合成示例。`;
  }
  if (status.realCleared) return `“已真实接通”的记录清掉了：${status.realCleared.reason}。`;
  if (status.lastSimulated) {
    const who = status.lastSimulated.agentInfo?.title || status.lastSimulated.agentInfo?.name || "未知";
    const why = status.lastSimulated.why?.length ? status.lastSimulated.why.join("；") : `对方自称“${who}”，不是 Antigravity`;
    return `${status.lastSimulated.countsAs === "simulated" ? "模拟：" : ""}收到过回复，但不算真实接通官方运行时：${why}。`;
  }
  return "还没有真实接通过：“已认证”不等于接通，只有一次真实请求拿回了完整回复才算。";
}

// 四件事分开显示：程序来源、ACP 握手、官方登录、模型回复。只写工坊真拿到的。
function renderAcpVerification(status) {
  const box = elements.acpVerification;
  const v = status?.verification;
  box.hidden = !v;
  if (!v) {
    box.replaceChildren();
    return;
  }
  const rows = [
    ["程序来源", v.source.state, `${v.source.label}${v.source.detail && v.source.state === "missing" ? `：${v.source.detail}` : ""}`],
    ["ACP 握手", v.handshake.state, `${v.handshake.label}${v.handshake.agentNote ? `；${v.handshake.agentNote}` : ""}${v.handshake.simulated ? "（模拟程序：工坊自己的测试程序，不是 Google 的）" : ""}`],
    ["官方登录", v.login.state, `${v.login.label}；${v.login.accountNote}${v.handshake.simulated ? "（模拟程序）" : ""}`],
    ["模型回复", v.reply.state, `${v.reply.label}${v.reply.why?.length ? `（${v.reply.why.join("；")}）` : ""}${v.reply.requestedModel ? `；请求的模型 ${v.reply.requestedModel.name}${v.reply.requestedModel.chosen ? "" : "（官方程序默认）"}` : ""}${v.reply.reportedModel ? `；官方程序回报的 ${v.reply.reportedModel.name}` : ""}；额度：${v.reply.quota.state === "limited" ? "官方程序说额度受限" : v.reply.quota.label}`],
  ];
  const fragment = document.createDocumentFragment();
  for (const [term, stateName, text] of rows) {
    const dt = document.createElement("dt");
    dt.textContent = term;
    const dd = document.createElement("dd");
    dd.dataset.state = stateName;
    dd.textContent = text;
    fragment.append(dt, dd);
  }
  box.replaceChildren(fragment);
}

function renderAcpRuntime(status) {
  const box = elements.acpRuntimeInfo;
  const runtime = status?.runtime;
  box.replaceChildren();
  box.hidden = !runtime;
  if (!runtime) return;
  box.dataset.state = runtime.state === "launchable" ? "ok" : "error";
  const lines = [
    runtime.message?.startsWith(runtime.label) ? runtime.message : `${runtime.label}：${runtime.message}`,
    runtime.path ? `路径：${runtime.path}${runtime.source === "path" ? "（在 PATH 里找到的）" : runtime.source === "env" ? "（环境变量 NOVEL_WORKSHOP_ACP_RUNTIME 指定，优先于这里填的）" : ""}` : null,
    runtime.kind ? `种类：${runtime.kind === "agy-cli" ? "官方 CLI（agy acp）" : "ACP Registry 发行包（agy_acp_server）"}；启动命令：${runtime.commandLine}` : null,
    runtime.kind === "agy-cli" ? `agy --version：${runtime.version || runtime.versionNote || "没查"}` : null,
    runtime.sha256 ? `大小 ${formatNumber(runtime.size)} 字节；${runtime.hashOf === "windows-shim" ? `启动脚本的 SHA-256 ${runtime.sha256}（这是 .cmd/.bat 启动脚本本身的，不是它启动的程序的：对得上也只核对了启动脚本，来源仍算未核对）` : `程序文件的 SHA-256 ${runtime.sha256}（解压以后的程序本身的）`}` : null,
    runtime.checksum ? `和你填的校验值：${runtime.checksum.match === true ? "一致" : runtime.checksum.match === false ? "不一致" : "没有填（来源未核对：最多只算协议结果）"}` : null,
    // ACP Registry 登记的是压缩包的校验值，和上面程序文件的不是一回事。
    runtime.kind === "registry-binary" && runtime.registry?.archiveSha256 ? `ACP Registry 登记的 ${runtime.registry.platformKey} 发行包 zip 的 SHA-256：${runtime.registry.archiveSha256}（压缩包的，不是程序文件的；解压前用 check-acp --zip 核对）` : null,
  ].filter(Boolean);
  for (const text of lines) {
    const p = document.createElement("p");
    p.textContent = text;
    box.append(p);
  }
  // 能启动、但值得你自己看一眼的地方（比如同组的其他用户能改这个程序或文件夹）。
  for (const warning of runtime.warnings || []) {
    const p = document.createElement("p");
    p.className = "acp-runtime-warning";
    p.textContent = `提醒：${warning}`;
    box.append(p);
  }
}

function renderAcpOptions(status) {
  const box = elements.acpOptions;
  const options = status?.connected ? status.session?.options || [] : [];
  box.hidden = !options.length;
  if (!options.length) {
    box.replaceChildren();
    return;
  }
  const busy = Boolean(state.acp.busy || status.busy) || acpTaskActive();
  const fragment = document.createDocumentFragment();
  for (const option of options) {
    const settable = option.category === "model" || option.category === "thought_level";
    const row = document.createElement("label");
    row.className = "acp-option";
    const name = document.createElement("span");
    name.textContent = option.category === "model" ? `模型（${option.name}）` : option.category === "thought_level" ? `思考强度（${option.name}）` : option.name;
    row.append(name);
    if (settable) {
      const select = document.createElement("select");
      select.disabled = busy;
      for (const value of option.values) {
        const entry = document.createElement("option");
        entry.value = value.value;
        entry.textContent = value.group ? `${value.group} · ${value.name}` : value.name;
        if (value.value === option.currentValue) entry.selected = true;
        select.append(entry);
      }
      select.addEventListener("change", () => runAcp("set-option", { configId: option.id, value: select.value }));
      row.append(select);
    } else {
      const value = document.createElement("span");
      value.className = "side-note";
      value.textContent = `${option.currentValue ?? "未知"}（只显示，工坊不改）`;
      row.append(value);
    }
    fragment.append(row);
  }
  const note = document.createElement("p");
  note.className = "side-note";
  const chosen = status.preferences?.model;
  note.textContent = `清单是官方程序这次给出的。${chosen ? `你选的模型：${chosen.name}。` : "没有选模型时用官方程序的默认。"}选的模型以后不在清单里时，工坊不发、也不替你换别的。`;
  fragment.append(note);
  box.replaceChildren(fragment);
}

function renderAcpMethods(status) {
  const methods = status?.connected ? status.handshake?.authMethods || [] : [];
  const select = elements.acpMethod;
  const signature = methods.map((method) => method.id).join("|");
  if (select.dataset.signature !== signature) {
    const previous = select.value;
    select.replaceChildren();
    for (const method of methods) {
      const option = document.createElement("option");
      option.value = method.id;
      option.textContent = `${method.name}（${method.id}）${method.id === "oauth-personal" ? "：个人订阅" : ""}${method.type === "terminal" ? "：要在终端里登录" : method.type === "env_var" ? "：要环境变量里的密钥，工坊不支持" : ""}`;
      select.append(option);
    }
    select.value = methods.some((method) => method.id === previous) ? previous : methods.some((method) => method.id === "oauth-personal") ? "oauth-personal" : methods[0]?.id || "";
    select.dataset.signature = signature;
  }
  return methods;
}

function renderAcpResult(status) {
  const task = status?.task;
  const active = acpTaskActive();
  elements.acpProgress.hidden = !active;
  if (active) {
    const counts = `已收到 ${formatNumber(task.chars)} 字；思考片段 ${task.thoughtChunks} 条、工具调用 ${task.toolCalls} 次、权限请求 ${task.permissionRequests} 次（都没有允许），内容不显示。`;
    const head = task.state === "cancelling" ? "正在停止：等官方程序确认……" : task.state === "preparing" ? "正在打开会话、核对模型……" : "正在等官方程序回复……";
    elements.acpProgress.replaceChildren();
    const p = document.createElement("p");
    p.textContent = `${head}${counts}`;
    elements.acpProgress.append(p);
    if (task.streamText) {
      const quote = document.createElement("blockquote");
      quote.className = "assist-scope-text";
      quote.textContent = `（还没结束，不完整）${task.streamText}`;
      elements.acpProgress.append(quote);
    }
  }
  const finished = task && task.state === "finished";
  const text = finished ? task.candidate || task.partial || "" : "";
  elements.acpResult.hidden = !finished;
  if (!finished) return;
  elements.acpResultTitle.textContent = (task.simulated ? "［模拟］" : "") + (task.candidate
    ? (task.kind === "selftest" ? "回复（合成示例，只是看看）" : "候选稿（只是候选）")
    : task.partial ? `不完整的部分输出（${task.outcomeLabel}，不当候选稿）` : task.outcomeLabel || "结果");
  elements.acpResultNote.textContent = task.message || "";
  elements.acpCandidate.hidden = !text;
  elements.acpCandidate.value = text;
  elements.acpCopy.hidden = !text;
  const matches = state.acp.sent?.taskId === task.id && state.acp.sent?.selection && state.activeFile?.path === state.acp.sent.selection.path;
  elements.acpInsert.hidden = !task.insertable;
  elements.acpInsert.disabled = serverReadOnly() || !matches || state.acp.inserted === task.id;
  elements.acpInsert.title = serverReadOnly()
    ? "只读方式打开时不能放进编辑器，可以复制"
    : !matches ? "这份候选稿不是这个页面刚发出的那一段，或者不属于现在打开的文稿；可以复制"
      : state.acp.inserted === task.id ? "已经放进编辑器了" : "放进编辑器，替换发出的那一段；文稿变成未保存";
  const snapshot = task.snapshot;
  elements.acpSnapshotNote.textContent = snapshot
    ? `这一轮发出的：${snapshot.pieces.map((piece) => `${ACP_PIECE_LABELS[piece.kind] || piece.kind} ${piece.chars} 字`).join("，")}；${snapshot.excluded}。请求的模型：${task.requested?.model?.name || "未知"}；官方程序回报的会话模型设置：${task.reportedModel?.name || "未知"}。`
    : "";
}

function acpTargetText(binding) {
  if (!binding) return "";
  const runtime = binding.runtime
    ? `${binding.runtime.simulated ? "［模拟］" : ""}${binding.runtime.agent || "官方程序"}（${binding.runtime.path}${binding.runtime.version ? `，${binding.runtime.version}` : ""}；${binding.runtime.source === "verified" ? "来源已核对" : "来源未核对"}）`
    : "还没有连接官方程序（或者旧连接已作废）";
  const setting = (entry) => (entry ? `${entry.name}${entry.chosen ? "" : "（官方程序默认）"}` : "官方程序没有给出");
  return `发给：${runtime}；模型：${setting(binding.model)}；思考强度：${setting(binding.thinking)}。这几样一变，这次确认就作废，要重新预览。`;
}

function renderAcpOpenTurns(status) {
  const box = elements.acpOpenTurns;
  const turns = status?.openTurns || [];
  // 另一个写作台（或 check-acp）还开着、正在进行的轮次：不算没人管的，只说一句，不给“我知道了”。
  const elsewhere = status?.runningElsewhere || [];
  box.hidden = !turns.length && !elsewhere.length;
  if (!turns.length && !elsewhere.length) {
    box.replaceChildren();
    return;
  }
  const fragment = document.createDocumentFragment();
  if (elsewhere.length) {
    const note = document.createElement("p");
    note.className = "side-note";
    note.textContent = `另一个写作台正在进行 ${elsewhere.length} 轮（${elsewhere.map((turn) => `${formatWhen(turn.sentAt)} 发出`).join("、")}），还没结束：等它结束，或者先关掉那一个。`;
    fragment.append(note);
  }
  if (!turns.length) {
    box.replaceChildren(fragment);
    return;
  }
  const head = document.createElement("p");
  head.className = "assist-error";
  // 全是发给模拟程序的：没有经过 Google，不说“可能用了额度”。
  head.textContent = turns.every((turn) => turn.simulated)
    ? `［模拟］有 ${turns.length} 轮发给模拟程序（工坊自己的测试程序）以后没有明确结果。没有经过 Google，不用额度；逐条点“我知道了”确认就行。`
    : `有 ${turns.length} 轮发出以后没有明确结果，可能已经被 Google 处理、用了额度。工坊不会自动重发。在官方产品里看过以后，逐条点“我知道了”（这是你自己的确认，工坊拿不到 Google 的回执）。`;
  fragment.append(head);
  for (const turn of turns) {
    const row = document.createElement("div");
    row.className = "acp-open-turn";
    const text = document.createElement("span");
    text.className = "side-note";
    text.textContent = `${turn.simulated ? "［模拟］" : ""}${formatWhen(turn.sentAt)} · ${turn.kind === "selftest" ? "合成示例" : "选段"}${turn.model ? ` · 模型 ${turn.model}` : ""}：${turn.reason}`;
    const button = document.createElement("button");
    button.type = "button";
    button.className = "tool-button quiet";
    button.textContent = "我知道了";
    button.disabled = Boolean(state.acp.busy);
    button.addEventListener("click", () => runAcp("acknowledge", { taskId: turn.taskId }));
    row.append(text, button);
    fragment.append(row);
  }
  box.replaceChildren(fragment);
}

function renderAcpPreview() {
  const preview = state.acp.preview;
  elements.acpPreview.hidden = !preview;
  if (!preview) return;
  const snapshot = preview.snapshot;
  elements.acpPreviewTarget.textContent = acpTargetText(snapshot.binding);
  elements.acpPreviewMeta.textContent = `一共 ${formatNumber(snapshot.totalChars)} 字，只有下面这几段；${snapshot.excluded}。每段的字数和 SHA-256 会记在本机（不记文字）。`;
  elements.acpPreviewPieces.replaceChildren(...snapshot.pieces.map((piece) => {
    const item = document.createElement("li");
    item.textContent = `${ACP_PIECE_LABELS[piece.kind] || piece.kind}：${piece.chars} 字，SHA-256 ${piece.sha256.slice(0, 12)}…`;
    return item;
  }));
  elements.acpPreviewText.textContent = preview.blocks.map((block) => block.text).join("\n\n");
  elements.acpConfirmSend.textContent = preview.kind === "selftest" ? "确认发送合成示例" : `确认发送这 ${formatNumber(snapshot.textChars)} 字`;
  // 服务端说现在不能发（旧连接作废、没连接）就灰掉；服务端发出前另外还会再核对一次。
  elements.acpConfirmSend.disabled = Boolean(state.acp.busy) || acpTaskActive() || !state.acp.status?.connected || !state.acp.status?.canSend;
}

function renderAcp() {
  if (!elements.acpPanel) return;
  const status = state.acp.status;
  const pageBusy = state.acp.busy;
  const busy = Boolean(pageBusy || status?.busy);
  const active = acpTaskActive();
  const connected = Boolean(status?.connected);
  const canSend = Boolean(status?.canSend);
  // 预览绑着那一次连接：连接作废、换了连接，页面上的旧预览也扔掉。
  const preview = state.acp.preview;
  if (preview && status && (!canSend || (preview.snapshot.binding?.runtime?.connection ?? null) !== (status.handshake?.connectionId ?? null))) state.acp.preview = null;
  elements.acpStatus.dataset.state = status ? (status.realCurrent && status.state === "ready" ? "connected" : status.condition ? "failed" : status.state) : "error";
  elements.acpStatus.textContent = acpStatusText(status);
  const step = status?.ladder?.step ?? 0;
  [...elements.acpLadder.children].forEach((item, index) => {
    item.dataset.done = String(index < step);
    if (index === step) item.setAttribute("aria-current", "step");
    else item.removeAttribute("aria-current");
  });
  elements.acpReal.textContent = `${status?.simulated ? "［模拟］" : ""}${acpRealText(status)}`;
  renderAcpVerification(status);
  const pausedButShownOtherwise = status?.quotaPause && status.state !== "quota_limited";
  elements.acpQuota.hidden = !pausedButShownOtherwise;
  elements.acpQuota.textContent = pausedButShownOtherwise ? `额度受限，发送仍然暂停：${status.quotaPause.message}` : "";
  renderAcpOpenTurns(status);
  if (status && document.activeElement !== elements.acpRuntimePath && document.activeElement !== elements.acpSha256 && !elements.acpConfigForm.dataset.dirty) {
    elements.acpRuntimePath.value = status.settings?.runtimeSource === "env" ? "" : status.settings?.runtimePath || "";
    elements.acpSha256.value = status.settings?.expectedSha256 || "";
  }
  renderAcpRuntime(status);
  const methods = renderAcpMethods(status);
  renderAcpOptions(status);
  const loggingIn = pageBusy === "login" || status?.busy?.code === "logging_in";
  elements.acpCheck.disabled = busy;
  elements.acpCheck.textContent = pageBusy === "check" ? "正在检查…" : "检查运行时";
  elements.acpConnect.disabled = busy || connected || !status;
  elements.acpConnect.textContent = pageBusy === "connect" ? "正在连接…" : "连接";
  elements.acpDisconnect.disabled = !connected && !loggingIn;
  elements.acpMethod.disabled = busy || !connected || !methods.length;
  elements.acpLogin.disabled = busy || active || !connected || !canSend || !methods.length;
  elements.acpLogin.textContent = loggingIn ? "等官方程序完成登录…" : "用 Google 登录（官方程序打开）";
  elements.acpModels.disabled = busy || active || !connected || !canSend;
  elements.acpModels.textContent = pageBusy === "models" ? "正在读取…" : "选择模型和思考强度";
  const selection = state.acp.selection;
  const selectionReady = Boolean(selection && state.activeFile && selection.path === state.activeFile.path);
  elements.acpScopeMeta.textContent = selectionReady
    ? `选中了 ${formatNumber([...selection.text].length)} 字。先点发送会列出要发的全部文字，确认以后才发；不发文稿的其他部分、文件名和路径。`
    : "要用自己的文字：先在文稿里选中那段（原文视图下拖选）。“发送合成示例”只发工坊自带的两句，不发文稿。";
  elements.acpSelftest.disabled = busy || active || !connected || !canSend;
  elements.acpSendSelection.disabled = busy || active || !connected || !canSend || !selectionReady;
  elements.acpSendSelection.textContent = selectionReady ? `用选中的 ${formatNumber([...selection.text].length)} 字发送` : "用选中文字发送";
  elements.acpStop.disabled = !active || status.task.state === "cancelling";
  elements.acpStop.textContent = active && status.task.state === "cancelling" ? "正在停止…" : "停止";
  renderAcpPreview();
  elements.acpError.hidden = !state.acp.error;
  elements.acpError.textContent = state.acp.error || "";
  renderAcpResult(status);
  const stderr = status?.diagnostics?.stderr || [];
  const protocolErrors = status?.diagnostics?.protocol?.protocolErrors || 0;
  elements.acpDiagnostics.textContent = [
    protocolErrors ? `不是协议消息的输出 ${protocolErrors} 行（已丢弃，没有进候选稿）` : null,
    ...stderr,
  ].filter(Boolean).join("\n") || "（没有）";
}

function renderBreadcrumbs(path) {
  elements.breadcrumbs.replaceChildren();
  path.split("/").forEach((part, index, parts) => {
    const label = document.createElement("span");
    label.textContent = part;
    elements.breadcrumbs.append(label);
    if (index < parts.length - 1) {
      const divider = document.createElement("i");
      divider.textContent = "／";
      elements.breadcrumbs.append(divider);
    }
  });
}

function updateDocumentMeta() {
  if (!state.activeFile) return;
  const content = elements.editorInput.value;
  elements.documentMeta.textContent = [
    formatBytes(currentByteSize()),
    `${formatNumber(countCharacters(content))} 字符`,
    fileExtension(state.activeFile.name).toUpperCase(),
  ].join("  ·  ");
}

function updateCursorPosition() {
  const content = elements.editorInput.value;
  const caret = elements.editorInput.selectionStart;
  const before = content.slice(0, caret);
  const lines = before.split("\n");
  updateActiveGutterLine(lines.length);
  elements.cursorPosition.textContent = `第 ${lines.length} 行，第 ${[...lines.at(-1)].length + 1} 列`;
}

function updateActiveGutterLine(currentLine) {
  const prevActive = elements.lineNumbersGutter.querySelector(".gutter-line.active");
  if (prevActive && prevActive.dataset.line === String(currentLine)) return;
  if (prevActive) prevActive.classList.remove("active");
  const target = elements.lineNumbersGutter.querySelector(`.gutter-line[data-line='${currentLine}']`);
  if (target) target.classList.add("active");
}

let lineMirror = null;
function getLineMirror() {
  if (!lineMirror) {
    lineMirror = document.createElement("div");
    lineMirror.className = "editor-line-mirror";
    document.body.appendChild(lineMirror);
  }
  return lineMirror;
}

function updateLineNumbers() {
  if (!state.showLineNumbers || elements.editorContainer.hidden) return;
  const input = elements.editorInput;
  const text = input.value;
  const lines = text.split("\n");
  const count = lines.length;

  const style = window.getComputedStyle(input);
  const mirror = getLineMirror();
  mirror.style.fontFamily = style.fontFamily;
  mirror.style.fontSize = style.fontSize;
  mirror.style.fontWeight = style.fontWeight;
  mirror.style.fontStyle = style.fontStyle;
  // 与 textarea 一样使用无单位行高，避免像素小数取整在长文中累积偏移。
  mirror.style.lineHeight = String(parseFloat(style.lineHeight) / parseFloat(style.fontSize));
  mirror.style.letterSpacing = style.letterSpacing;
  mirror.style.wordSpacing = style.wordSpacing;
  mirror.style.textTransform = style.textTransform;
  mirror.style.textIndent = style.textIndent;
  mirror.style.whiteSpace = "pre-wrap";
  mirror.style.wordBreak = style.wordBreak;
  mirror.style.overflowWrap = "break-word";
  mirror.style.tabSize = style.tabSize || "4";

  const padLeft = parseFloat(style.paddingLeft) || 0;
  const padRight = parseFloat(style.paddingRight) || 0;
  const innerWidth = input.clientWidth - padLeft - padRight;
  if (innerWidth <= 0) return;
  mirror.style.width = `${innerWidth}px`;

  mirror.innerHTML = lines.map((line) => `<div>${escapeHtml(line) || "&#8203;"}</div>`).join("");

  const caret = input.selectionStart || 0;
  const beforeCaret = text.slice(0, caret);
  const activeLineIndex = beforeCaret.split("\n").length - 1;

  elements.lineNumbersGutter.style.paddingTop = style.paddingTop;
  elements.lineNumbersGutter.style.paddingBottom = style.paddingBottom;
  elements.lineNumbersGutter.style.lineHeight = style.lineHeight;
  const children = mirror.children;
  const rows = document.createDocumentFragment();
  for (let i = 0; i < count; i++) {
    const isActive = i === activeLineIndex ? " active" : "";
    const row = document.createElement("div");
    row.className = `gutter-line${isActive}`;
    row.dataset.line = String(i + 1);
    row.textContent = String(i + 1);
    row.style.height = `${children[i].getBoundingClientRect().height}px`;
    rows.append(row);
  }
  elements.lineNumbersGutter.replaceChildren(rows);
  elements.lineNumbersGutter.scrollTop = input.scrollTop;
}

let lineNumbersFrame = null;
function scheduleLineNumbers() {
  if (lineNumbersFrame !== null) return;
  lineNumbersFrame = window.requestAnimationFrame(() => {
    lineNumbersFrame = null;
    updateLineNumbers();
  });
}

function setLineNumbersVisible(visible) {
  state.showLineNumbers = visible;
  elements.editorBody.classList.toggle("show-line-numbers", visible);
  elements.lineNumbersButton.setAttribute("aria-pressed", String(visible));
  scheduleLineNumbers();
  syncViewState();
}

function viewStateKey() {
  return `story_dashboard_view:${state.workspace.workspace.path}`;
}

function syncViewState() {
  if (!state.restored) return;
  const saved = {
    view: state.activeView,
    file: state.activeFile?.path || null,
    mode: state.mode,
    showLineNumbers: state.showLineNumbers,
  };
  try {
    localStorage.setItem(viewStateKey(), JSON.stringify(saved));
  } catch {}
  const url = new URL(window.location.href);
  url.searchParams.set("view", saved.view);
  if (saved.file) {
    url.searchParams.set("file", saved.file);
    url.searchParams.set("mode", saved.mode);
  } else {
    url.searchParams.delete("file");
    url.searchParams.delete("mode");
  }
  window.history.replaceState(null, "", url);
}

async function restoreViewState() {
  let saved = {};
  try {
    saved = JSON.parse(localStorage.getItem(viewStateKey())) || {};
  } catch {}
  const params = new URLSearchParams(window.location.search);
  // 显式链接优先于这个工作区上次打开的文稿。
  const linked = ["view", "file", "mode"].some((key) => params.has(key));
  const file = linked ? params.get("file") : saved.file;
  const mode = (linked ? params.get("mode") : saved.mode) === "preview" ? "preview" : "edit";
  const requestedView = linked ? params.get("view") : saved.view;
  const defaultView = state.workspace.libraries.length ? "libraries" : "projects";
  const view = ["libraries", "projects"].includes(requestedView)
    ? requestedView
    : typeof file === "string" ? deduceViewForPath(file) : defaultView;
  setLineNumbersVisible(saved.showLineNumbers !== false);
  setMode(mode);
  if (typeof file === "string" && file) await openFile(file, { force: true });
  setActiveView(view);
  state.restored = true;
  syncViewState();
}

function expandParentDirs(filePath) {
  if (!filePath) return;
  const parts = filePath.split("/");
  let current = "";
  for (let i = 0; i < parts.length - 1; i++) {
    current = current ? `${current}/${parts[i]}` : parts[i];
    state.expandedDirs.add(current);
    state.collapsedDirs.delete(current);
  }
}

function deduceViewForPath(filePath) {
  if (!state.workspace || !filePath) return state.activeView;
  const containsFile = ({ path }) => path === "." || filePath.startsWith(`${path}/`);
  if (state.workspace.libraries.some(containsFile)) {
    return "libraries";
  }
  if (state.workspace.projects.some(containsFile)) {
    return "projects";
  }
  return state.activeView;
}

async function openFile(path, { force = false } = {}) {
  if (state.loadingFile || (!force && !confirmDiscard())) return;
  state.loadingFile = true;
  syncActionAvailability();
  elements.fileTree.setAttribute("aria-busy", "true");
  try {
    const file = await requestJson(`/api/file?path=${encodeURIComponent(path)}`);
    const normalized = normalizeEol(file.content);
    file.eol = detectEol(file.content);
    file.content = normalized;
    file.diskVersion = file.version;
    state.activeFile = file;
    state.originalContent = normalized;
    state.editing = false;
    state.saveError = null;
    state.lastSavedAt = 0;
    state.assist.selection = null;
    state.assist.result = null;
    state.acp.selection = null;
    state.acp.preview = null;
    elements.editorInput.value = normalized;
    elements.editorTitle.textContent = file.name;
    renderBreadcrumbs(file.path);
    setDirty(false);
    expandParentDirs(file.path);
    setActiveView(deduceViewForPath(file.path));
    setMode(state.mode);
    updateDocumentMeta();
    updateCursorPosition();
    elements.editorEmpty.hidden = true;
    elements.editorWorkspace.hidden = false;
    document.body.classList.add("document-open");
    syncActiveRow();
    syncViewState();
    scheduleLineNumbers();
    showDraftNotice();
    if (state.sidePanel === "compare") setSidePanel(null);
    renderAssist();
  } catch (error) {
    showToast(error.message, "error");
  } finally {
    state.loadingFile = false;
    syncActionAvailability();
    elements.fileTree.removeAttribute("aria-busy");
  }
}

function escapeHtml(value) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function inlineMarkdown(value) {
  return value
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/__([^_]+)__/g, "<strong>$1</strong>")
    .replace(/(?<!\*)\*([^*\n]+)\*(?!\*)/g, "<em>$1</em>");
}

function markdownToSafeHtml(markdown) {
  const lines = escapeHtml(markdown).replaceAll("\r\n", "\n").split("\n");
  const output = [];
  let inCode = false;
  let codeLines = [];
  let codeStartLine = 1;
  let listType = null;

  const closeList = () => {
    if (listType) output.push(`</${listType}>`);
    listType = null;
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const lineNum = i + 1;
    if (line.trim().startsWith("```")) {
      closeList();
      if (inCode) {
        output.push(`<div class="preview-code-block" data-line="${codeStartLine}"><pre><code>${codeLines.join("\n")}</code></pre></div>`);
        codeLines = [];
      } else {
        codeStartLine = lineNum;
      }
      inCode = !inCode;
      continue;
    }
    if (inCode) {
      codeLines.push(line);
      continue;
    }

    const heading = line.match(/^(#{1,4})\s+(.+)$/);
    const unordered = line.match(/^\s*[-*+]\s+(.+)$/);
    const ordered = line.match(/^\s*\d+[.)]\s+(.+)$/);
    if (heading) {
      closeList();
      const level = heading[1].length;
      output.push(`<h${level} data-line="${lineNum}">${inlineMarkdown(heading[2])}</h${level}>`);
    } else if (unordered || ordered) {
      const nextType = unordered ? "ul" : "ol";
      if (listType !== nextType) {
        closeList();
        listType = nextType;
        output.push(`<${listType}>`);
      }
      output.push(`<li data-line="${lineNum}">${inlineMarkdown((unordered || ordered)[1])}</li>`);
    } else if (/^\s*([-*_])(?:\s*\1){2,}\s*$/.test(line)) {
      closeList();
      output.push(`<hr data-line="${lineNum}">`);
    } else if (line.startsWith("&gt; ")) {
      closeList();
      output.push(`<blockquote data-line="${lineNum}">${inlineMarkdown(line.slice(5))}</blockquote>`);
    } else if (line.trim()) {
      closeList();
      output.push(`<p data-line="${lineNum}">${inlineMarkdown(line)}</p>`);
    } else {
      closeList();
    }
  }
  if (inCode) output.push(`<div class="preview-code-block" data-line="${codeStartLine}"><pre><code>${codeLines.join("\n")}</code></pre></div>`);
  closeList();
  return output.join("");
}

function setMode(mode) {
  state.mode = mode;
  elements.modeButtons.forEach((button) => {
    button.setAttribute("aria-pressed", String(button.dataset.mode === mode));
  });
  const previewing = mode === "preview";
  elements.editorContainer.hidden = previewing;
  elements.previewPane.hidden = !previewing;
  if (previewing) {
    elements.previewPane.innerHTML = markdownToSafeHtml(elements.editorInput.value);
  } else {
    window.requestAnimationFrame(() => elements.editorInput.focus());
  }
  scheduleLineNumbers();
  syncViewState();
}

async function saveFile() {
  if (serverReadOnly()) return showToast("写作台是以只读方式打开的，不能保存");
  if (!state.activeFile || !state.dirty || state.saving || state.deleting) return;
  if (!state.editing) return showToast("先点“开始编辑”");
  // 请求发出前就把身份和正文快照下来：保存期间作者可能换文件、也可能接着敲字，
  // 收尾只允许写回这次真正送出去的那份，绝不能落到别的文稿头上。
  const file = state.activeFile;
  const sent = elements.editorInput.value;
  setSaving(true);
  try {
    const saved = await requestJson("/api/file", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        path: file.path,
        content: applyEol(sent, file.eol),
        expectedVersion: file.version,
      }),
    });
    file.mtimeMs = saved.mtimeMs;
    file.version = saved.version;
    file.diskVersion = saved.version;
    file.size = saved.size;
    showToast(`已备份原稿并保存《${file.name}》`);
    if (state.activeFile !== file) {
      clearDraft(file.path);
      return;
    }
    state.originalContent = sent;
    state.saveError = null;
    state.lastSavedAt = Date.now();
    // 保存途中敲进来的字仍是未保存修改，不能被这次结果抹平成「已保存」
    setDirty(elements.editorInput.value !== sent);
    writeDraftNow();
    updateDocumentMeta();
  } catch (error) {
    if (state.activeFile !== file) {
      showToast(`《${file.name}》保存失败：${error.message}`, "error");
      return;
    }
    state.saveError = error.message;
    setDirty(true);
    writeDraftNow();
    if (error instanceof ApiError && error.status === 409) {
      elements.conflictDialog.showModal();
    } else {
      showToast(`保存失败：${error.message}。修改还在，也记成了草稿。`, "error");
    }
  } finally {
    setSaving(false);
  }
}

async function deleteFile() { showToast("工坊工作台不提供删除文件功能"); }

async function searchWorkspace(query, sequence) {
  state.searching = true;
  renderTree();
  try {
    const result = await requestJson(
      `/api/search?q=${encodeURIComponent(query)}&scope=${encodeURIComponent(state.activeView)}`,
    );
    if (sequence !== state.searchSequence) return;
    state.searchResults = result.results;
    state.searchTruncation = result.truncated
      ? {
          ...(result.truncation || {
            byResults: true,
            byNodes: false,
            byDepth: false,
            byReadError: false,
          }),
          scanErrors: result.scanErrors || [],
          limits: result.limits,
        }
      : null;
  } catch (error) {
    if (sequence !== state.searchSequence) return;
    state.searchResults = [];
    state.searchTruncation = null;
    showToast(error.message, "error");
  } finally {
    if (sequence === state.searchSequence) {
      state.searching = false;
      renderTree();
    }
  }
}

function scheduleSearch() {
  window.clearTimeout(state.searchTimer);
  const query = state.filter.trim();
  state.searchSequence += 1;
  const sequence = state.searchSequence;
  if (!query) {
    state.searching = false;
    state.searchResults = [];
    state.searchTruncation = null;
    renderTree();
    return;
  }
  state.searching = true;
  renderTree();
  state.searchTimer = window.setTimeout(() => searchWorkspace(query, sequence), 180);
}

function setActiveView(view) {
  state.activeView = view;
  elements.archiveTabs.forEach((tab) => {
    const selected = tab.dataset.view === view;
    tab.setAttribute("aria-selected", String(selected));
    tab.tabIndex = selected ? 0 : -1;
  });
  elements.treePanel.setAttribute(
    "aria-labelledby",
    view === "libraries" ? "librariesTab" : "projectsTab",
  );
  if (state.filter.trim()) {
    scheduleSearch();
  } else {
    renderTree();
  }
  syncViewState();
}

elements.archiveTabs.forEach((tab) => {
  tab.addEventListener("click", () => setActiveView(tab.dataset.view));
  tab.addEventListener("keydown", (event) => {
    if (!["ArrowLeft", "ArrowRight"].includes(event.key)) return;
    event.preventDefault();
    const direction = event.key === "ArrowRight" ? 1 : -1;
    const current = elements.archiveTabs.indexOf(event.currentTarget);
    const next = elements.archiveTabs.at(
      (current + direction + elements.archiveTabs.length) % elements.archiveTabs.length,
    );
    setActiveView(next.dataset.view);
    next.focus();
  });
});

elements.treeSearch.addEventListener("input", (event) => {
  state.filter = event.currentTarget.value;
  scheduleSearch();
});

elements.treeSearch.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    event.currentTarget.value = "";
    state.filter = "";
    scheduleSearch();
  }
});

elements.refreshButton.addEventListener("click", () => loadWorkspace({ announce: true }));

elements.themeButton.addEventListener("click", () => {
  themeChoice = effectiveTheme() === "dark" ? "light" : "dark";
  try {
    localStorage.setItem(THEME_KEY, themeChoice);
  } catch {}
  applyTheme();
});

systemDark.addEventListener("change", applyTheme);
elements.mobileBackButton.addEventListener("click", () => {
  document.body.classList.remove("document-open");
  window.requestAnimationFrame(() => elements.treeSearch.focus());
});
elements.saveButton.addEventListener("click", saveFile);
elements.deleteButton.addEventListener("click", deleteFile);

elements.editorInput.addEventListener("input", () => {
  setDirty(elements.editorInput.value !== state.originalContent);
  scheduleDraft();
  updateDocumentMeta();
  updateCursorPosition();
  scheduleLineNumbers();
});

elements.editorInput.addEventListener("scroll", () => {
  elements.lineNumbersGutter.scrollTop = elements.editorInput.scrollTop;
}, { passive: true });

elements.lineNumbersButton.addEventListener("click", () => {
  setLineNumbersVisible(!state.showLineNumbers);
});

new ResizeObserver(scheduleLineNumbers).observe(elements.editorInput);
document.fonts.ready.then(scheduleLineNumbers);

["click", "keyup", "select"].forEach((eventName) => {
  elements.editorInput.addEventListener(eventName, updateCursorPosition);
});
["mouseup", "keyup", "select"].forEach((eventName) => {
  elements.editorInput.addEventListener(eventName, () => {
    if (state.sidePanel === "assist" && !state.assist.busy && !state.assist.result) captureSelection();
    else if (state.sidePanel === "acp") captureAcpSelection();
  });
});

elements.modeButtons.forEach((button) => {
  button.addEventListener("click", () => setMode(button.dataset.mode));
});

elements.conflictDialog.addEventListener("close", () => {
  const choice = elements.conflictDialog.returnValue;
  if (choice === "reload" && state.activeFile) {
    // 先把这边的修改记成草稿，再载入磁盘版本：载入后可以对比、再决定恢复哪一份。
    writeDraftNow();
    openFile(state.activeFile.path, { force: true });
  } else if (choice === "compare" && state.activeFile) {
    openCompare("disk");
  }
});

elements.editToggle.addEventListener("click", () => setEditing(!state.editing));
elements.discardButton.addEventListener("click", discardChanges);
elements.compareButton.addEventListener("click", () => (state.sidePanel === "compare" ? setSidePanel(null) : openCompare("opened")));
elements.assistButton.addEventListener("click", () => setSidePanel(state.sidePanel === "assist" ? null : "assist"));
elements.acpButton.addEventListener("click", () => setSidePanel(state.sidePanel === "acp" ? null : "acp"));
elements.sidePanelClose.addEventListener("click", () => setSidePanel(null));
elements.draftRestore.addEventListener("click", restoreDraft);
elements.draftDiscard.addEventListener("click", discardDraft);
elements.draftCompare.addEventListener("click", () => openCompare("draft"));
elements.assistSend.addEventListener("click", sendAssist);
elements.assistApply.addEventListener("click", applyCandidate);
elements.assistDiscard.addEventListener("click", discardCandidate);
elements.assistListModels.addEventListener("click", () => runAssistCheck("list"));
elements.assistSelfTest.addEventListener("click", () => runAssistCheck("selftest"));
elements.assistConfigForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const payload = {};
  if (elements.assistKey.value.trim()) payload.apiKey = elements.assistKey.value.trim();
  if (elements.assistModel.value.trim()) payload.model = elements.assistModel.value.trim();
  if (!Object.keys(payload).length) return;
  saveAssistConfig(payload);
});
elements.assistClear.addEventListener("click", () => {
  if (window.confirm("清除本机保存的 Gemini API Key 和模型设置？")) saveAssistConfig({ clear: true });
});

elements.acpCheck.addEventListener("click", () => runAcp("check"));
elements.acpConnect.addEventListener("click", () => runAcp("connect"));
elements.acpDisconnect.addEventListener("click", () => acpImmediate("disconnect"));
elements.acpLogin.addEventListener("click", () => runAcp("login", { methodId: elements.acpMethod.value }));
elements.acpModels.addEventListener("click", () => runAcp("models"));
elements.acpSelftest.addEventListener("click", () => acpShowPreview("selftest"));
elements.acpSendSelection.addEventListener("click", () => acpShowPreview("selection"));
elements.acpConfirmSend.addEventListener("click", acpConfirmSend);
elements.acpPreviewCancel.addEventListener("click", () => {
  state.acp.preview = null;
  renderAcp();
});
elements.acpStop.addEventListener("click", () => acpImmediate("cancel", { taskId: state.acp.status?.task?.id }));
elements.acpCopy.addEventListener("click", acpCopy);
elements.acpInsert.addEventListener("click", acpInsert);
elements.acpInstruction.addEventListener("input", () => {
  if (state.acp.preview?.kind === "selection") {
    state.acp.preview = null;
    renderAcp();
  }
});
for (const input of [elements.acpRuntimePath, elements.acpSha256]) {
  input.addEventListener("input", () => {
    elements.acpConfigForm.dataset.dirty = "1";
  });
}
elements.acpConfigForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const result = await runAcp("config", { runtimePath: elements.acpRuntimePath.value.trim(), expectedSha256: elements.acpSha256.value.trim() });
  if (result) {
    delete elements.acpConfigForm.dataset.dirty;
    showToast("已保存到本机用户配置目录；点“检查运行时”核对一遍");
  }
  renderAcp();
});
elements.acpConfigClear.addEventListener("click", async () => {
  if (!window.confirm("清除本机保存的官方程序路径和校验值？（不会动官方程序本身和它的登录）")) return;
  delete elements.acpConfigForm.dataset.dirty;
  await runAcp("config", { clear: true });
});

const SIDEBAR_KEY = "story_dashboard_sidebar";
function setSidebarCollapsed(collapsed) {
  document.body.classList.toggle("sidebar-collapsed", collapsed);
  elements.sidebarToggle.setAttribute("aria-expanded", String(!collapsed));
  elements.sidebarToggle.title = collapsed ? "展开文件栏" : "收起文件栏";
  try {
    localStorage.setItem(SIDEBAR_KEY, collapsed ? "1" : "0");
  } catch {}
  scheduleLineNumbers();
}
elements.sidebarToggle.addEventListener("click", () => {
  setSidebarCollapsed(!document.body.classList.contains("sidebar-collapsed"));
});
try {
  if (localStorage.getItem(SIDEBAR_KEY) === "1") setSidebarCollapsed(true);
} catch {}

document.addEventListener("keydown", (event) => {
  // 输入法正在组字时（拼音、注音、五笔候选），快捷键交给输入法，不抢。
  if (event.isComposing || event.keyCode === 229) return;
  const modifier = event.metaKey || event.ctrlKey;
  if (modifier && event.key.toLocaleLowerCase() === "s") {
    event.preventDefault();
    saveFile();
  }
  if (modifier && event.key.toLocaleLowerCase() === "k") {
    event.preventDefault();
    elements.treeSearch.focus();
    elements.treeSearch.select();
  }
});

window.addEventListener("pagehide", () => {
  if (state.dirty) writeDraftNow();
});

window.addEventListener("beforeunload", (event) => {
  if (state.dirty) writeDraftNow();
  if (state.dirty) {
    event.preventDefault();
    event.returnValue = "";
  }
});

loadWorkspace();

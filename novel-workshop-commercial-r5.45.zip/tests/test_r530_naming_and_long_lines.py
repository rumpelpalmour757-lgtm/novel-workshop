#!/usr/bin/env python3
"""r5.30: three checks from the author's newer rule files for one book (kept in the personal build only).

The author sent the seventh version of the book's revision rules, the fifth version of its consistency list and a
first issue ledger, which carry notes from reviewing chapters 11-56 and an outside reviewer's structural points.
Most of what they ask was already in the modules. Three checks were not; they now sit, with new examples, in the
places they belong to:

- progression: once a trigger is written down, every later occurrence of the condition needs an answer (it fires,
  or the text says why not and the boundary goes into the project's ability notes); an ability back after a long
  absence is recognised by its own signature and is not quietly made stronger on the way;
- serial production, unit review: a long line that comes back must bring something new each time, and two climaxes
  close together should not be won by the same steps (change the next one, not the one already written);
- continuity, renamed things: count how often each name is used before unifying, do not unify towards a name the
  book never used; before registering a retired name for the literal scan, check whether the current names or common
  phrases contain it.
"""
import importlib.util
import os
from pathlib import Path
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
REFS = SKILL / "references"


def read(name):
    path = REFS / name
    return path.read_text(encoding="utf-8") if path.is_file() else ""


def paragraph_with(text, phrase):
    return next((block for block in text.split("\n\n") if phrase in block), "")


def section(text, heading):
    if heading not in text:
        return ""
    return text.split(heading, 1)[1].split("\n## ", 1)[0]


def load_prose_lint():
    spec = importlib.util.spec_from_file_location("r530_prose_lint", SKILL / "scripts" / "prose_lint.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class TriggerWrittenDown(unittest.TestCase):
    def setUp(self):
        self.text = read("progression.md")

    def test_every_later_occurrence_of_the_condition_needs_an_answer(self):
        part = paragraph_with(self.text, "能力的触发条件写定以后")
        for phrase in ("后文每逢这个条件都要有着落", "要么让它照规则响", "要么在正文里交代这一次为什么没响",
                       "把这条边界补进项目档案的能力设定", "不回改已经写好的章节"):
            self.assertIn(phrase, part)

    def test_a_returning_ability_is_recognised_and_not_quietly_raised(self):
        part = paragraph_with(self.text, "能力的触发条件写定以后")
        for phrase in ("隔了很久才再出现的能力", "让读者一句话认出来", "别借这次露面悄悄加强它", "照成长点和解锁的规矩来"):
            self.assertIn(phrase, part)

    def test_it_sits_in_the_ability_section_and_the_older_text_stays(self):
        part = section(self.text, "## 系统与能力")
        self.assertIn("能力的触发条件写定以后", part)
        self.assertLess(part.index("“解锁”与“掌握完整法则”分开"), part.index("能力的触发条件写定以后"))
        self.assertLess(part.index("能力的触发条件写定以后"), part.index("系统提供已定义的信息与奖励"))
        self.assertIn("不在将要失败时凭空派发救命能力", part)


class LongLinesAndRepeatedWins(unittest.TestCase):
    def setUp(self):
        self.text = read("serial-production.md")

    def test_a_returning_line_brings_something_new(self):
        part = paragraph_with(self.text, "长线和惯用的解法也在这里回看")
        for phrase in ("每次至少带来一点新东西", "一个新事实，或者一个新问题", "读者会当这条线断了",
                       "就先别让它露面，或者写查的人卡在了哪一步"):
            self.assertIn(phrase, part)

    def test_close_climaxes_are_not_won_by_the_same_steps(self):
        part = paragraph_with(self.text, "长线和惯用的解法也在这里回看")
        for phrase in ("解决的步骤一模一样", "后一场读起来像重播", "在下一场的计划里换一个分胜负的办法",
                       "对手已经防着惯用的那一招", "已经写好的那一场不必回改"):
            self.assertIn(phrase, part)

    def test_it_sits_in_the_unit_review_and_keeps_its_limits(self):
        part = section(self.text, "## 阶段推进回看")
        self.assertIn("长线和惯用的解法也在这里回看", part)
        self.assertLess(part.index("补的时候不能改动已确认的能力上限"), part.index("长线和惯用的解法也在这里回看"))
        self.assertLess(part.index("长线和惯用的解法也在这里回看"), part.index("作品如有专用的连载配置"))
        self.assertIn("不规定每几章必须战斗", part)


class RenamedThings(unittest.TestCase):
    def setUp(self):
        self.text = read("continuity.md")
        self.part = paragraph_with(self.text, "改了叫法也要回读")

    def test_count_the_names_before_unifying(self):
        for phrase in ("也数一数每个叫法用了几次、在哪几章", "往一个全书从没用过的叫法上统一，等于新起一个名，交作者定",
                       "不为了同类的名字整齐改掉"):
            self.assertIn(phrase, self.part)
        self.assertLess(self.part.index("认不准的列待核，不合并"), self.part.index("也数一数每个叫法用了几次"))

    def test_check_what_a_registered_word_hides_before_registering_it(self):
        for phrase in ("所以登记以前，先拿这个词搜一遍称谓表里现行的叫法和已有的正文", "新叫法本身含着它",
                       "常常跨着两个词连在一起", "登记了会把正当的写法一起报出来，这样的不登记", "在称谓表里写明不再用"):
            self.assertIn(phrase, self.part)
        # The older sentences stay.
        for phrase in ("（登记“车厢”，“车厢板”也算）", "单字的叫法（只说一个“绳”）", "这些照样靠逐句看", "`min_occurrences` 写 1"):
            self.assertIn(phrase, self.part)

    def test_the_scanner_really_flags_what_the_paragraph_says(self):
        # The paragraph's claim, checked against the scanner it describes: a retired name hidden in the new name, and
        # one that runs across two words, are both reported.
        lint = load_prose_lint()
        for word, line in (("货单", "他把提货单折好，塞进衣袋。\n"), ("门卡", "风一大，后门卡住了。\n")):
            rules = {"terms": [{"id": "retired", "text": word, "min_occurrences": 1}]}
            self.assertEqual(lint.inspect_text(line, rules)["status"], "REVIEW", word)
        self.assertIn("提货单", self.part)
        self.assertIn("后门卡住了", self.part)

    def test_protected_headings_stay(self):
        for heading in ("## 规则打架时", "## 修订后的回归核对"):
            self.assertIn("\n" + heading + "\n", self.text)


class NewExamplesWrittenOnce(unittest.TestCase):
    def test_the_examples_are_new(self):
        self.assertIn("护符在危险临身前发烫", read("progression.md"))
        self.assertIn("托人去查的旧案", read("serial-production.md"))
        continuity = read("continuity.md")
        for example in ("“晾竿”改成“晾架”", "旧叫法“货单”改成了“提货单”", "换掉的“门卡”"):
            self.assertIn(example, continuity)

    def test_each_check_is_written_once(self):
        texts = {path.name: path.read_text(encoding="utf-8") for path in REFS.glob("*.md")}
        for phrase, home in (("后文每逢这个条件都要有着落", "progression.md"),
                             ("别借这次露面悄悄加强它", "progression.md"),
                             ("长线和惯用的解法也在这里回看", "serial-production.md"),
                             ("后一场读起来像重播", "serial-production.md"),
                             ("往一个全书从没用过的叫法上统一", "continuity.md"),
                             ("登记了会把正当的写法一起报出来", "continuity.md")):
            homes = sorted(name for name, text in texts.items() if phrase in text)
            self.assertEqual(homes, [home], phrase)


if __name__ == "__main__":
    unittest.main()

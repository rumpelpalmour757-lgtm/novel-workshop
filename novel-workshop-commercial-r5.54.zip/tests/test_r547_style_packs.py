#!/usr/bin/env python3
"""r5.47: the two style packs ship in the general part (assets/style-packs/), so the commercial build carries them too.

The author asked that the commercial version can use the urban-martial engine library and the realism engine as well,
still only when the author names one or the book's file enables it (references/style-packs.md). What changed in code is
the exporter: it lists every pack file (sale profile), pulls the whole packs in after the guide (personal mode follows
links and the packs' own SKILL.md links only a few files), and keeps them out of the single-file version. These tests
check that, the packs' data (library.json is the yaml re-serialized the way each pack's build_library.py does it) and
that the r5.46 repairs are still in the data. Nothing from the packs' scripts is run or imported here: the workshop
does not run them for the author, and r5.47 does not execute code taken out of them either (r5.46 did, for its own
helper functions; that check is not repeated).
"""
import importlib.util
import json
import os
from pathlib import Path
import re
import tempfile
import unittest
import zipfile

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
STYLE = SKILL / "assets" / "style-packs"
UME = STYLE / "urban-martial-style-engines"
UNRE = STYLE / "universal-novel-realism-engine"

try:
    import yaml
except ImportError:  # pragma: no cover - the commercial tests also run where PyYAML is missing
    yaml = None


def load_exporter():
    spec = importlib.util.spec_from_file_location("export_portable_r547", SKILL / "scripts" / "export_portable.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_yaml(path):
    return yaml.safe_load(path.read_text(encoding="utf-8"))


class Packaging(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.exporter = load_exporter()

    def test_the_file_list_is_the_folder(self):
        on_disk = sorted(p.relative_to(SKILL).as_posix() for p in STYLE.rglob("*")
                         if p.is_file() and "__pycache__" not in p.parts)
        self.assertEqual(list(self.exporter.STYLE_PACK_FILES), on_disk)
        self.assertGreater(len(on_disk), 200)
        self.assertLessEqual(set(self.exporter.STYLE_PACK_FILES) | {self.exporter.STYLE_PACK_GUIDE},
                             set(self.exporter.SALE_FILES))

    def test_both_profiles_carry_the_whole_packs(self):
        wanted = set(self.exporter.STYLE_PACK_FILES) | {"references/style-packs.md"}
        for mode in ("personal", "sale"):
            self.assertLessEqual(wanted, set(self.exporter.collect_core(SKILL, mode)), mode)

    def test_a_pack_file_outside_the_list_is_refused_in_sale_mode(self):
        exporter = load_exporter()
        exporter.SALE_FILES = frozenset(f for f in exporter.SALE_FILES if not f.endswith("/SKILL.md")
                                        or not f.startswith("assets/style-packs/urban"))
        with self.assertRaises(ValueError):
            exporter.collect_core(SKILL, "sale")

    def test_single_file_leaves_the_packs_out_and_the_folder_keeps_them(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "sale.zip"
            self.exporter.export(SKILL, target, mode="sale")
            with zipfile.ZipFile(target) as archive:
                names = set(archive.namelist())
                portable = archive.read("portable-novel-workshop.md").decode("utf-8")
                guide = archive.read("README.md").decode("utf-8")
        for name in self.exporter.STYLE_PACK_FILES:
            self.assertIn("novel-workshop/" + name, names)
        self.assertIn("内嵌内容：references/style-packs.md", portable)
        self.assertNotIn("内嵌内容：assets/style-packs/", portable)
        for marker in ("· 使用说明", "references/engines/", "RULE_80"):
            self.assertNotIn(marker, portable)
        self.assertIn("assets/style-packs/", guide)


class Data(unittest.TestCase):
    def test_versions_agree_inside_each_pack(self):
        for pack, version in ((UME, "2.0.2"), (UNRE, "17.1.2")):
            for doc in ("SKILL.md", "README.md"):
                title = next(line for line in (pack / doc).read_text(encoding="utf-8").splitlines() if line.startswith("# "))
                self.assertIn("v" + version, title, (pack.name, doc))
            library = json.loads((pack / "references" / "library.json").read_text(encoding="utf-8"))
            self.assertEqual(library["version"], version, pack.name)
            self.assertTrue((pack / "docs" / ("v%s修订.md" % version)).is_file())

    @unittest.skipIf(yaml is None, "needs PyYAML")
    def test_library_json_is_the_yaml(self):
        engines = {}
        for f in (UME / "references" / "engines").glob("*.yaml"):
            d = load_yaml(f)
            d["file"] = f"references/engines/{f.name}"
            engines[d["num"]] = d
        engines = dict(sorted(engines.items(), key=lambda kv: int(kv[0])))
        router = load_yaml(UME / "references" / "router.yaml")
        lib = {"version": router["router"]["version"], "router": router["router"], "global_rules": router["global_rules"],
               "checklist": router.get("checklist", []), "core": load_yaml(UME / "references" / "L0_core.yaml"),
               "engines": engines}
        self.assertEqual(json.dumps(lib, ensure_ascii=False, indent=1),
                         (UME / "references" / "library.json").read_text(encoding="utf-8"))
        kernel = load_yaml(UNRE / "references" / "kernel.yaml")
        carts = {}
        for f in sorted((UNRE / "references" / "cartridges").glob("*.yaml")):
            c = load_yaml(f)
            c["file"] = f"references/cartridges/{f.name}"
            carts[c["num"]] = c
        rules = load_yaml(UNRE / "references" / "rules.yaml")
        lib = {"version": kernel["version"], "kernel": kernel, "cartridges": carts, "rules": rules["rules"],
               "metrics": rules["metrics"], "counters": rules["counters"],
               "layers": load_yaml(UNRE / "references" / "layers.yaml")["sections"],
               "state_schema": load_yaml(UNRE / "references" / "state_schema.yaml")["schema"],
               "interop": load_yaml(UNRE / "references" / "interop.yaml")}
        self.assertEqual(json.dumps(lib, ensure_ascii=False, indent=1),
                         (UNRE / "references" / "library.json").read_text(encoding="utf-8"))

    @unittest.skipIf(yaml is None, "needs PyYAML")
    def test_r546_repairs_are_still_there(self):
        router = load_yaml(UME / "references" / "router.yaml")
        self.assertIn("知道心", router["global_rules"]["lexicon"]["ban_except"])
        engines = {d["num"]: d for d in (load_yaml(f) for f in (UME / "references" / "engines").glob("*.yaml"))}
        for a, b in (("10", "92"), ("54", "136"), ("07", "100")):
            self.assertIn(b, engines[a]["conflicts"])
            self.assertIn(a, engines[b]["conflicts"])
        self.assertIsInstance(engines["73"]["changes"], list)
        self.assertIn('"只见(?!过|到|了)"', (UME / "scripts" / "lint_text.py").read_text(encoding="utf-8"))
        rules = load_yaml(UNRE / "references" / "rules.yaml")
        r80 = next(r for r in rules["rules"] if r["id"].startswith("RULE_80"))
        self.assertEqual(r80["pattern"], "([^\\n]{221,})")
        self.assertTrue(re.search(r80["pattern"], r80["example"]["match"]))
        self.assertFalse(re.search(r80["pattern"], r80["example"]["no_match"]))
        self.assertIsNone(re.search(r80["pattern"], "字" * 220))
        reduplication = re.compile(rules["counters"]["reduplication"])
        self.assertEqual(len(reduplication.findall("一步一步地蹭，火一下一下地往上蹿")), 0)
        self.assertEqual(len(reduplication.findall("他看了看门，想一想再说")), 2)


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""r5.61, package one: the visual notes card (assets/visual-notes-card.md) and the three pages that point to it
(references/drafting.md, chapter-confirmation.md, projects.md).

The card is a summary for a host that may not run scripts: what to check first, the host's own search, an image the
host drew, notes kept by hand, the short way in a chat, and what survives to the next conversation. These tests pin
its sections and phrases, that its notes line up with the library's fields, that what it says about a library brought
back without its folder is what check and card do, and the four ways the chapter gate takes the preparation stage
that the new sentence on chapter-confirmation.md relies on (chapter_gate.py is not changed). They do not say a host
reads the card or does what it says. The examples are made up for these tests.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
SCRIPTS = SKILL / "scripts"
CARD = SKILL / "assets" / "visual-notes-card.md"
HARD = ("永远", "绝不", "必须", "严禁")
SECTIONS = ("## 1. 先看宿主有什么", "## 2. 宿主自己找图", "## 3. 宿主画的图", "## 4. 手记：没有脚本时怎么记",
            "## 5. 只有对话框时（比如在手机上）：从一张图接到“记下来”", "## 6. 记录留不留得住")
LINK = "[看图与手记卡](../assets/visual-notes-card.md)"
# The new sentences on the three pages (HOST-23, 25, 26, 27), as they are written there.
NEW = {
    "references/drafting.md": [
        "想把这张图留到以后用，说一声，再照 [看图与手记卡](../assets/visual-notes-card.md) 第 5 节记下借了哪几样：能跑脚本的记进 "
        "[灵感库](inspiration-library.md)，跑不了的记一条手记，不向作者要文件名和哈希。"],
    "references/chapter-confirmation.md": [
        "宿主自己找的图不在这三种里，算“视觉准备”一节说的“别的做法”，同样要作者当章同意、不带到下一章：记作者当章的原话和日期、"
        "每张图的来源页、这一章实际看到了什么、作者的选择和用途；能跑脚本的，作者的话用 `chapter_policy` 记（这一章记成 "
        "`visual_required:false`，不拿别的 `mode` 顶替），看了哪些图写进这一次展示的内容。没有库的，上面说的“灵感库里的条目”指 "
        "[看图与手记卡](../assets/visual-notes-card.md) 手记里那一条的编号和日期，文件和哈希没有的照实写。",
        "；作者给了图、或者同意宿主自己找图的，照样看图、照样记。"],
    "references/projects.md": [
        "；用了参考图的，另带本书的 `inspiration/` 整个文件夹，或者那份手记（[看图与手记卡](../assets/visual-notes-card.md) 第 6 节）。"],
}


def load(name):
    spec = importlib.util.spec_from_file_location("r561_host_" + name, SCRIPTS / (name + ".py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(script, *args):
    proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPTS / script), *map(str, args)], capture_output=True,
                          text=True, encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


def read(rel):
    return (SKILL / rel).read_text(encoding="utf-8")


def section(text, heading):
    start = text.index(heading + "\n")
    end = text.find("\n## ", start + len(heading))
    return text[start:end if end >= 0 else len(text)]


class TheCard(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.text = CARD.read_text(encoding="utf-8")
        cls.parts = {n: section(cls.text, h) for n, h in enumerate(SECTIONS, 1)}

    def test_six_sections_in_order(self):  # HOST-01
        self.assertTrue(self.text.startswith("# 看图与手记卡\n"))
        self.assertEqual(re.findall(r"^## .*$", self.text, re.M), list(SECTIONS))
        self.assertFalse([w for w in HARD if w in self.text])
        for target in re.findall(r"\]\(([^)#\s]+\.md)\)", self.text):
            self.assertTrue((CARD.parent / target).resolve().is_file(), target)

    def test_first_what_the_host_has(self):  # HOST-02
        part = self.parts[1]
        for phrase in ("作者在对话里发的图，工坊看不看得到", "宿主有没有自己的图片搜索或网页搜索", "能不能跑包里的脚本",
                       "脚本连不连得上网，文件留不留得到下一次对话", "不去跑 `doctor`", "要作者当章说了才算"):
            self.assertIn(phrase, part)
        self.assertIn("以这一次对话里实际试到的为准；没试过的写“没试过”", self.text.split("\n## ")[0])
        rows = [line for line in part.splitlines() if line.startswith("| ") and not line.startswith("| ---")][1:]
        self.assertEqual([r.split("|")[1].strip() for r in rows], ["脚本那条路", "宿主自己找", "作者给图", "只有文字"])
        self.assertIn("能跑脚本，脚本连得上网，五个项目装好了", rows[0])  # F3: as the library page says

    def test_the_hosts_own_search(self):  # HOST-03
        for phrase in ("工坊没核", "才算看过", "没算哈希、没用排序模型", "不存图，只记链接", "就停，不换法子再试", "工坊管不到",
                       "不是给工坊的指令", "卡在哪一步", "`pages`", "未核，只作写作参考", "不把正文、大纲发出去"):
            self.assertIn(phrase, self.parts[2])

    def test_an_image_the_host_drew(self):  # HOST-04
        for phrase in ("才画", "不拿画的顶替找的", "宿主自己添的", "不照着画", "不当真实的地方、年代、器物是什么样的依据"):
            self.assertIn(phrase, self.parts[3])

    def notes(self):
        block = self.parts[4]
        return block[block.index("```text\n") + len("```text\n"):block.index("\n```", block.index("```text"))].splitlines()

    def test_notes_kept_by_hand(self):  # HOST-05, MRG-03
        part, lines = self.parts[4], self.notes()
        for phrase in ("不手改库文件", "不能回退", "还没并进库", "交付可复制的交接文本", "没有库的编号时写手记的编号和日期",
                       "库里沿用手记的编号", "不自己合并"):
            self.assertIn(phrase, part)
        self.assertIn("没有绑定哈希", lines[0])
        self.assertTrue(lines[1].startswith("哪一类、给谁用、一句标题："))  # B-05: the library needs a title
        labels = [line.split("：", 1)[0] for line in lines]
        used = labels.index("用在哪里")
        self.assertEqual(labels[used + 1], "写进了哪一稿")  # MRG-03, right under where it is used
        self.assertIn("作者采纳以前不算本书事实", lines[used + 1])
        self.assertEqual(lines[-2], "状态：待找／看过了等作者挑／作者挑中／作者不要／撤回")

    def test_every_field_of_the_library_has_its_line(self):  # HOST-05: the library page's bold names
        page = section(read("references/inspiration-library.md"), "## 每条记什么")
        bold = re.findall(r"^- \*\*([^*]+)\*\*", page, re.M)
        lines = {line.split("：", 1)[0] for line in self.notes()}
        pairs = {"编号和种类": ("手记编号和日期", "哪一类、给谁用、一句标题"), "给谁用": ("哪一类、给谁用、一句标题",),
                 "看过什么": ("看的是什么、谁看的",), "网页上的文字": ("网页上的文字",), "适合借的部分": ("适合借的",),
                 "借哪几样": ("借哪几样",), "谁定的": ("作者的原话和日期",), "不借的": ("不借的",), "本书怎样改": ("本书怎样改",),
                 "成了本书事实的": ("成了本书事实的",), "出处": ("图从哪来",), "状态": ("状态",), "用在哪里": ("用在哪里",),
                 "和设定不一样的": ("和设定不一样的",)}
        self.assertEqual(set(bold) - {"图片版本"}, set(pairs))  # a field added to the library page needs a line here
        for name, on_card in pairs.items():
            for line in on_card:
                self.assertIn(line, lines, name)

    def test_the_card_uses_the_librarys_names(self):  # HOST-05: what the card says can be written into the library
        lib = load("inspiration_library")
        write = load("inspiration_write")
        self.assertEqual(set(lib.SHOWN_AS), {"original", "reduced", "unknown"})  # 原图、缩小过的、说不清
        self.assertLessEqual({"author_chat", "host_generated", "link", "search", "text"}, set(lib.SOURCE_TYPES_V2))
        self.assertIn("conversation", lib.VIEWS)
        self.assertIn("drafted", lib.ENTRY_FIELDS_V2)
        self.assertLessEqual({"to_find", "candidate", "picked", "rejected", "withdrawn"}, set(lib.STATUSES_V2))
        self.assertLessEqual({"record", "drafted"}, set(write.KINDS_OF_CHANGE))
        lines = self.notes()
        for words in ("作者在对话里发的", "网页上的", "宿主画的", "还没找到", "看了对话里的图", "作者用文字说的"):
            self.assertTrue([line for line in lines if words in line], words)

    def test_the_short_way_in_a_chat(self):  # HOST-06
        steps = re.findall(r"^(\d)\. (.*)$", self.parts[5], re.M)
        self.assertEqual([n for n, _ in steps], ["1", "2", "3", "4", "5"])
        text = dict(steps)
        self.assertIn("不向作者要文件名和哈希", text["1"])
        self.assertIn("看到了什么、看不清什么", text["2"])
        for phrase in ("先问，不按整张写", "只借看得见的，不给情节", "以设定为准", "不照搬"):  # F4
            self.assertIn(phrase, text["3"])
        self.assertIn("要接着写成一整章的", text["4"])  # B-12
        self.assertIn("不说重新看过图", text["5"])

    def test_what_survives(self):  # HOST-07
        for phrase in ("两边都记了的以库为准", "`library.history/`", "`images/`", "`library.json`", "file not found",
                       "手记就是唯一的一份"):
            self.assertIn(phrase, self.parts[6])


class ALibraryBroughtBackAlone(unittest.TestCase):  # HOST-07: what the card says about it is what the scripts do
    def test_check_says_the_file_is_missing_and_card_still_works(self):
        with tempfile.TemporaryDirectory() as tmp:
            book = Path(tmp) / "book" / "inspiration"
            book.mkdir(parents=True)
            library = book / "library.json"
            library.write_bytes(json.dumps({"schema": "inspiration-library/2", "book": "测试", "revision": 0,
                                            "entries": []}).encode("utf-8"))
            (Path(tmp) / "门口.png").write_bytes(b"a made-up picture")
            code, out, err = run("inspiration_write.py", "add-image", library, "--image", Path(tmp) / "门口.png",
                                 "--if-revision", 0, "--title", "修车铺门口", "--seen", "门边一条长凳", "--by", "工坊")
            self.assertEqual(code, 0, out + err)
            entry_id = json.loads(out)["id"]
            code, out, err = run("inspiration_write.py", "add-image", library, "--id", entry_id, "--if-revision", 1,
                                 "--take", "门边一条长凳=stable", "--words", "长凳要", "--chapter", 7)
            self.assertEqual(code, 0, out + err)
            self.assertEqual(run("inspiration_library.py", "check", library)[0], 0)
            alone = Path(tmp) / "next-time" / "library.json"
            alone.parent.mkdir()
            shutil.copyfile(library, alone)
            code, out, err = run("inspiration_library.py", "check", alone)
            self.assertEqual(code, 1, out + err)
            self.assertTrue([p for p in json.loads(out)["problems"] if "file not found" in p])
            code, out, err = run("inspiration_library.py", "card", alone, "--chapter", 7)
            self.assertEqual(code, 0, out + err)
            self.assertIn("门边一条长凳", out)


class ThePages(unittest.TestCase):  # HOST-23, HOST-25, HOST-26, HOST-27
    def test_each_new_sentence_is_there_once(self):
        for rel, sentences in NEW.items():
            text = read(rel)
            for sentence in sentences:
                with self.subTest(page=rel, sentence=sentence[:20]):
                    self.assertEqual(text.count(sentence), 1)
                    self.assertFalse([w for w in HARD if w in sentence])

    def test_where_they_are(self):
        drafting = section(read("references/drafting.md"), "## 从一张图和一句感受开始")
        self.assertIn(LINK, drafting)
        self.assertIn("不向作者要文件名和哈希", drafting)
        self.assertIn("**落笔前备料。**", read("references/drafting.md"))  # named in the register, not touched
        page = read("references/chapter-confirmation.md")
        joined = section(page, "## 和工坊原有规则怎么接")
        rule = next(line for line in joined.splitlines() if line.startswith("- **什么算实际的视觉准备**"))
        self.assertTrue(rule.endswith(NEW["references/chapter-confirmation.md"][0]))
        self.assertIn("交付门只核出处填没填，不核是不是真看过图。宿主自己找的图不在这三种里", rule)
        self.assertIn("用作者给图或复用来代替找图链路，要作者当章同意", rule)  # unchanged
        self.assertIn("某一章批准的降级不带到下一章", page)  # unchanged
        policies = section(page, "## 两项策略：写前看图，初稿由作者交教师")
        self.assertIn("没有图就从设定、大纲和前文里找；作者给了图、或者同意宿主自己找图的，照样看图、照样记。", policies)
        for locked in ("## 确认是什么意思",):  # the locked section has none of the new words
            self.assertNotIn("宿主自己找", section(page, locked))
        move = section(read("references/projects.md"), "## 换AI或会话")
        self.assertIn("`inspiration/` 整个文件夹", move)
        self.assertIn(LINK, move)


class TheChapterGate(unittest.TestCase):
    """HOST-25: how the preparation stage is recorded for images the host found itself. chapter_gate.py is not
    changed; these are the four ways it already answers, through learning_loop's events, on a made-up chapter."""

    def setUp(self):
        self.loop = load("learning_loop")
        self.gate = load("chapter_gate")
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.serial = 0

    def book(self, name):
        path = Path(self.temp.name) / (name + ".md")
        payload = {"schema_version": 1, "project_id": "book", "revision": 0, "data": {}}
        path.write_bytes(("<!-- NOVEL_WORKSHOP_LEARNING_START -->\n```json\n" + json.dumps(payload) +
                          "\n```\n<!-- NOVEL_WORKSHOP_LEARNING_END -->\n").encode("utf-8"))
        for stage in ("scope", "outline"):
            shown = self.send(path, "present", stage, content="合成：" + stage, source_ref="fixture://" + stage)
            self.send(path, "confirm", stage, presentation_id=shown["presentation_id"],
                      presentation_version=shown["presentation_version"], source_ref="fixture://author",
                      actor_role="author", mode="human", author_quote="可以。")
        return path

    def send(self, path, action, stage=None, **fields):
        self.serial += 1
        event = {"event_id": "g%d" % self.serial, "op": "chapter_gate", "action": action, "chapter_id": "c1", **fields}
        if stage:
            event["stage"] = stage
        return self.loop.apply_event(path, event, "book", self.loop.read_store(path)[1])

    def evidence(self, mode):
        return {"mode": mode, "source_refs": ["手记 N-03，2026-11-26（作者在对话里发的图，没有文件和哈希）"],
                "observation_ref": "手记 N-03 的“看到的”", "selection_ref": "手记 N-03 的“借哪几样”和作者的原话"}

    def test_the_four_ways(self):
        path = self.book("a")
        with self.assertRaises(self.loop.LoopError) as caught:
            self.send(path, "present", "preparation", content="写前准备", source_ref="fixture://prep")
        self.assertIn("chapter_policy", str(caught.exception))  # the way out it names itself
        with self.assertRaises(self.loop.LoopError):
            self.send(path, "present", "preparation", content="写前准备", source_ref="fixture://prep",
                      visual_evidence=self.evidence("host_search"))  # no such mode
        shown = self.send(path, "present", "preparation", content="写前准备", source_ref="fixture://prep",
                          visual_evidence=self.evidence("author_images"))
        self.assertTrue(shown["presentation_id"])  # the author's images named by a note's number
        path = self.book("b")
        self.send(path, "chapter_policy", visual_required=False, source_ref="对话第 7 条", actor_role="author",
                  mode="human", author_quote="这一章就用你自己搜到的那两张。")
        shown = self.send(path, "present", "preparation", content="写前准备：看了宿主自己找的两张图，见手记 N-04、N-05",
                          source_ref="fixture://prep")
        self.assertTrue(shown["presentation_id"])
        policy = self.gate.status(self.loop.read_store(path)[0], "c1")["workflow_policy"]
        self.assertEqual((policy["visual_required"], policy["basis"], policy["author_quote"]),
                         (False, "chapter", "这一章就用你自己搜到的那两张。"))


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""r5.31: the stakes module (张力与代价).

The author read three accepted chapters of their own book and said they were flat: the prose was fine, something was
missing, they could not say what. The workshop's rules up to r5.30 were mostly prohibitions (no coughing blood, no
sudden ability, no narrator summary, no forced cliffhanger); they stop a chapter from being written badly, not from
being written flat. Nothing asked, per chapter, who could lose what, where the protagonist had to choose, whether the
opponent had a face, whether the tempo ever changed, whether a question was left open, or who was standing by to
catch the protagonist if he fell. r5.31 adds references/stakes.md with those five questions and the "who is
underwriting the scene" check, makes the five questions part of every L1 task (SKILL.md, the delivery-gate card, the
chapter work card in drafting.md, the editorial verdict in quality-loop.md), links it from serial production, pacing
and planning, rewords the planning sentence that read as "cost is not required", and adds the module to the sale
export.

These tests pin what the text says and what it must not turn into:
- the five questions are there, each with what counts and what does not;
- an unanswered question in one chapter is a review item, not an error; two or more chapters in a row is a problem;
- restraint is about sentences, not events: the module does not become "every chapter must have a fight / a
  cliffhanger / a loss";
- the fix order starts inside existing events; coughing blood, a new ability, a dumber opponent and a narrator
  announcing the change are named as non-fixes; accepted chapters are flagged, not edited;
- the example is new and carries no prefilled book facts;
- the routing, the L1 requirement, the gate card (still within its byte budget), the work card, the editorial
  verdict, the neighbours and the sale export all point at it.
Whether chapters revised with the module read less flat is not something these tests can show; the blind comparison
is in the maintenance records (EVAL-REPORT, repro/r5.31).
"""
import importlib.util
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
MODULE = "references/stakes.md"


def read(relative):
    path = SKILL / relative
    return path.read_text(encoding="utf-8") if path.is_file() else ""


def section(text, heading):
    start = text.find("\n## " + heading)
    if start == -1:
        return ""
    end = text.find("\n## ", start + 4)
    return text[start:end if end != -1 else len(text)]


def paragraph_with(text, phrase):
    return next((block for block in text.split("\n\n") if phrase in block), "")


def card_item(number):
    card = read("assets/delivery-gate-card.md")
    return next((line for line in card.splitlines() if line.startswith("%d. **" % number)), "")


class FiveQuestions(unittest.TestCase):
    def test_each_question_says_what_counts_and_what_does_not(self):
        part = section(read(MODULE), "每章五问")
        # r5.34 (the r5.32 review, point 4, approved by the author 2026-10-23): the first question also asks what was
        # gained and which old expectation was paid off; "差点失去" still counts only with a later account.
        self.assertIn("1. **谁得到或失去了什么？哪个旧期待兑现了？**", part)
        self.assertIn("“差点失去”只在后文真有账的时候才算", part)
        self.assertIn("2. **主角在哪一句做了两难的选择？**", part)
        self.assertIn("只有一个明显正确的选项不算；别人事后指出“你本可以”不算", part)
        self.assertIn("3. **对手有没有脸？**", part)
        self.assertIn("背影、制服、职务、一个组织的名字不算脸", part)
        self.assertIn("被抓过的人再出现还是同一个层级，也答不上", part)
        self.assertIn("4. **压力最高的一句在哪里？它和本章最松的一句读起来有没有差别？**", part)
        self.assertIn("差别不靠感叹号和短句堆出来，靠人物在那一句做了平时不会做的事", part)
        self.assertIn("5. **本章留下哪个没答的问题？**", part)
        self.assertIn("在本章里提出又在本章里解决的不算", part)

    def test_answers_point_into_the_text_and_are_not_invented(self):
        part = section(read(MODULE), "每章五问")
        self.assertIn("答案要能在正文里指到位置", part)
        self.assertIn("答不上来就照实写“答不上”，不编一个", part)

    def test_one_chapter_is_a_review_item_two_in_a_row_is_a_problem(self):
        part = section(read(MODULE), "每章五问")
        self.assertIn("一章里有一两问答不上，不是错误，记为复核项，写明这一章的作用（过渡、日常、放松）", part)
        self.assertIn("连着两章以上五问大半答不上，才作为问题提出", part)
        self.assertIn("“阶段推进回看”里“连续几章局势、资源和关系都没变”是同一件事", part)
        self.assertIn("按那张简表逐章填五问，看从哪一章起连着答不上", part)

    def test_a_quiet_chapter_may_carry_an_old_question_but_must_sharpen_it(self):
        part = section(read(MODULE), "每章五问")
        # r5.32 (CON-011, NWC-1.3, approved by the author 2026-10-22): the last scene of a chapter stops at the turn or
        # the new question; "不要求悬崖" yielded to it. The old question that must be sharpened stays.
        # r5.34 (NWC-1.5): the stop at the turn is for a last scene that is a confrontation.
        self.assertIn("章末那一场是对手戏的，按 [分场戏剧张力与正文具象化](scene-dramaturgy.md) 停在翻转或新悬念出现的那一下（CON-011）", part)
        self.assertIn("可以是读者已经攥着的旧问题，但本章得让它更要紧一点", part)


class RestraintIsAboutSentences(unittest.TestCase):
    def test_the_gap_is_named(self):
        part = section(read(MODULE), "克制是对句子的，不是对事件的")
        self.assertIn("它们管的是句子和设定，不管事件该不该发生", part)
        self.assertIn("规则防的是写坏，防不了写平", part)
        self.assertIn("六个维度都“达到”，仍然可以是一章没有人在乎的事", part)

    def test_no_quota_creeps_in(self):
        text = read(MODULE)
        self.assertTrue(text)
        for pattern in (r"每章(都)?(必须|务必|一定要)[^。；\n]{0,10}(战斗|打|悬崖|断章|失去|死)",
                        r"(每|隔)[^。；\n]{0,6}章(必须|务必|一定)",
                        r"(必须|务必|一定要)[^。；\n]{0,8}(吐血|折寿|死人|牺牲)"):
            self.assertIsNone(re.search(pattern, text), pattern)
        # r5.32 (CON-011): "不把每章改成悬崖" yielded to the scene ending of CON-011; the other limits stay.
        self.assertNotIn("不把每章改成悬崖", text)
        self.assertIn("不把主角写成从此什么都失去（一章里失去一样，后文有账）", text)


class WhoIsUnderwriting(unittest.TestCase):
    def test_the_question_is_whether_the_stronger_one_could_do_it_instead(self):
        # r5.34 (the r5.32 review, point 4, approved by the author 2026-10-23): a stronger person present all along is
        # not the fault; the fault is when the protagonist's choices no longer change the result. The first remedy is a
        # step only the protagonist can do; keeping the stronger one away is the second, and not every chapter.
        part = section(read(MODULE), "谁在兜底")
        self.assertIn("比主角强的人（有武器、有权限、能叫来支援）能不能替他办成这一章的关键目标？主角的本事、关系、判断或选择有没有改变结果？", part)
        self.assertIn("强的人全程在场不是毛病", part)
        self.assertIn("毛病是强的人一出手，主角做什么都不影响结果", part)
        self.assertIn("补法先找只有主角办得到的那一步", part)
        self.assertIn("其次才是让强的人在关键一步上不在", part)
        self.assertIn("失联、分队、强者暂离不连着用", part)
        self.assertNotIn("主角做的每个选择都不算数", part)

    def test_a_written_limit_must_have_bound_once(self):
        part = section(read(MODULE), "谁在兜底")
        self.assertIn("已经写定的限制有没有真的限制过他", part)
        self.assertIn("一次只能护住一个人，就得有一次来了两个", part)
        self.assertIn("限制从没卡住过主角，读者就不再为它紧张", part)
        self.assertIn("这不是让能力突然失灵", part)
        self.assertIn("](progression.md)", part)


class HowToFix(unittest.TestCase):
    def test_the_order_starts_inside_existing_events(self):
        part = section(read(MODULE), "怎样补，怎样不补")
        self.assertIn("先给主角一个会失去的人（已经提过名、还没露面的那个最省），再给对手一张脸", part)
        self.assertIn("再在已有事件里挑一处改成当场的两难；最后才是加新事件", part)
        self.assertIn("能在已写的事里补出压力，就不另起一场", part)

    def test_added_pressure_is_a_draft_increment_not_a_fact(self):
        # From the single-chapter blind comparison: the arm with the module gave the opponent a threat that binds the
        # next chapter. Such additions are flagged to the author, never slipped into the fact baseline.
        part = section(read(MODULE), "怎样补，怎样不补")
        self.assertIn("补出来的代价、威胁和对手自己说的话是新事实", part)
        self.assertIn("记成草稿增量，在工作记录里单列给作者，不悄悄进事实基线", part)
        self.assertIn("对手的上家、身份这类作者保留的答案，不借他的一句话提前定下", part)
        self.assertIn("](drafting.md)“本章工作卡”", part)

    def test_the_non_fixes_are_named(self):
        part = section(read(MODULE), "怎样补，怎样不补")
        # r5.32 (CON-011): "不把每章改成悬崖" left this list; scene endings follow CON-011.
        for phrase in ("不吐血、不折寿", "不借这一章解锁新能力救场", "不让对手变笨来衬托",
                       "不让旁白宣布“这一次不一样了”"):
            self.assertIn(phrase, part)

    def test_accepted_chapters_are_flagged_not_edited(self):
        part = section(read(MODULE), "怎样补，怎样不补")
        self.assertIn("已采纳的章节只标不改，改法交作者", part)
        self.assertIn("](quality-loop.md)", part)


class Example(unittest.TestCase):
    def test_the_example_is_new_and_answers_all_five(self):
        part = section(read(MODULE), "原创示例")
        for word in ("阿槐", "更夫", "烂板", "退热药"):
            self.assertIn(word, part)
        self.assertIn("**平的写法**", part)
        self.assertIn("**改法**", part)
        self.assertIn("**批注**", part)
        self.assertIn("事件不变，只改谁在扛", part)
        self.assertIn("没有加能力，没有吐血，没有旁白讲她学会了什么", part)
        self.assertIn("灯灭把兜底的人支开", part)

    def test_the_source_is_recorded_and_carries_no_book_material(self):
        module = read(MODULE)
        last = ([line for line in module.splitlines() if line.strip()] or [""])[-1]
        self.assertTrue(last.startswith("来源：作者 2026-10-21"), last)
        self.assertIn("不含该作品的原文、短引、人物或设定", last)
        notes = read("assets/third-party/SOURCE-NOTES.md")
        row = next((line for line in notes.splitlines() if "](../../references/stakes.md)" in line), "")
        self.assertIn("作者对自己作品前三章的反馈", row)
        self.assertIn("送药过河的例子是新写的", row)


class Wiring(unittest.TestCase):
    def test_flat_chapters_are_routed_to_the_module(self):
        rows = [line for line in read("SKILL.md").splitlines() if line.startswith("| ")]
        row = next((line for line in rows if "(references/stakes.md)" in line and "L1 整章" not in line), "")
        self.assertTrue(row, "SKILL.md has no routing row for the module")
        task = row.split("|")[1]
        for word in ("平淡", "代价", "两难", "脸", "悬念", "不够用"):
            self.assertIn(word, task)
        # r5.32 (CON-011): "不每章断章" left the routing row.
        self.assertIn("不加能力、不吐血", row.split("|")[3])
        self.assertNotIn("不每章断章", row)

    def test_the_five_questions_are_part_of_every_whole_chapter_task(self):
        level = next(line for line in read("SKILL.md").splitlines() if line.startswith("| L1 整章 |"))
        self.assertIn("[张力与代价](references/stakes.md)“每章五问”", level)
        self.assertIn("编辑裁决里写五问的答案，答不上的照实写、记为复核项", level)
        self.assertIn("张力与代价“每章五问”", card_item(1))
        self.assertIn("另答五问（得失、两难、对手的脸、最紧的一句、没答的问题），答不上照实写", card_item(9))  # r5.34
        self.assertLessEqual(len(read("assets/delivery-gate-card.md").encode("utf-8")), 5004)

    def test_the_work_card_and_the_verdict_ask_them(self):
        card = paragraph_with(read("references/drafting.md"), "连载长篇的工作卡另记三项")
        self.assertIn("接 [张力与代价](stakes.md) 的五问", card)
        # r5.34: the work card asks the new question about the stronger person.
        self.assertIn("再看一眼谁在兜底——比主角强的人能不能替他办成这一章的关键目标，主角的本事和选择改不改变结果", card)
        verdict = paragraph_with(read("references/quality-loop.md"), "`editorial_review`")
        self.assertIn("张力按 [张力与代价](stakes.md)“每章五问”逐问写一句答案", verdict)
        self.assertIn("答不上的照实写“答不上”并记为复核项，不编一个；脚本不核对这几句，它们是编辑判断", verdict)

    def test_neighbours_point_to_it_and_planning_no_longer_waives_cost(self):
        serial = section(read("references/serial-production.md"), "阶段推进回看")
        self.assertIn("同一张表再加 [张力与代价](stakes.md) 的五问，逐章填", serial)
        self.assertIn("一章答不上记作用，连着两章以上才是问题", serial)
        self.assertIn("见 [张力与代价](stakes.md)", read("references/pacing.md"))
        planning = read("references/planning.md")
        self.assertNotIn("也不要求每个故事都设置阴谋、失败或额外代价", planning)
        self.assertIn("也不要求每个故事都设置阴谋或折磨；但每个剧情单元要写清人物可能失去什么、在哪里要选，这一条不因题材轻松而免", planning)
        self.assertIn("](stakes.md)", planning)

    def test_the_module_links_back(self):
        module = read(MODULE)
        for target in ("pacing.md", "sentence-craft.md", "prose-audit.md", "drafting.md", "quality-loop.md",
                       "serial-production.md", "progression.md"):
            self.assertIn("](%s)" % target, module, target)

    def test_the_sale_export_carries_the_module(self):
        spec = importlib.util.spec_from_file_location("r531_export", SKILL / "scripts" / "export_portable.py")
        exporter = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(exporter)
        self.assertIn(MODULE, set(exporter.SALE_FILES))
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "sale.zip"
            proc = subprocess.run([sys.executable, "-I", "-B", str(SKILL / "scripts" / "export_portable.py"), str(target),
                                   "--mode", "sale"], capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
            archive = zipfile.ZipFile(target)
            self.assertIn("novel-workshop/" + MODULE, archive.namelist())
            portable = archive.read("portable-novel-workshop.md").decode("utf-8")
            self.assertIn("# 张力与代价", portable)
            self.assertIn("## 每章五问", portable)

    def test_each_judgment_lives_in_one_module(self):
        texts = {path.name: path.read_text(encoding="utf-8") for path in (SKILL / "references").glob("*.md")}
        # r5.34: the judgment about the stronger person was rewritten (see WhoIsUnderwriting).
        for phrase in ("规则防的是写坏，防不了写平", "毛病是强的人一出手，主角做什么都不影响结果", "限制从没卡住过主角"):
            homes = sorted(name for name, text in texts.items() if phrase in text)
            self.assertEqual(homes, ["stakes.md"], phrase)


if __name__ == "__main__":
    unittest.main()

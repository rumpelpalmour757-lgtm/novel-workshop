#!/usr/bin/env python3
"""r5.33: CON-012 "先备料，后落笔" (constitution NWC-1.4), the delivery gate's voice_material check and the inspiration
library.

After the five revision passes were in, the author sent a chapter written from their own manuscript plus reference
images and said "这个真的是我想写出来的这种"; they wanted the method in the constitution and an inspiration library,
images both from the author and recommended by the workshop. The author approved the CON-012 text word for word
("批准，按这段改"), with the heading "十二条原则" and a gate check for the card. These tests pin:

- the constitution text, version line, revision record and registry entry of CON-012;
- workflow_guard.py's voice_material check: the card is frozen at the start; voice samples need a source and the text
  (or a reason there is none); every material block needs a Scene ID, the things and where they come from; with a beat
  card every core and action scene needs its block;
- inspiration_library.py: check (record complete, files and hashes, links with a license, search words), list and card
  (material blocks the gate can read); read-only and offline;
- the wiring (SKILL.md, drafting, execution, the card, the module, the sale export).
Whether the material is good, or used well in the draft, is the editor's and the author's call.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
GUARD = SKILL / "scripts" / "workflow_guard.py"
LIBRARY = SKILL / "scripts" / "inspiration_library.py"
MODULE = "references/inspiration-library.md"
TEMPLATE = "assets/inspiration-library-template.json"
CARD = "assets/voice-material-card.md"


def read(relative):
    path = SKILL / relative
    return path.read_text(encoding="utf-8") if path.is_file() else ""


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(script, *args, cwd=None):
    proc = subprocess.run([sys.executable, "-I", "-B", str(script), *map(str, args)], cwd=cwd, capture_output=True,
                          text=True, encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


class Constitution(unittest.TestCase):
    """NWC-1.4: what the author approved on 2026-10-23, word for word where it matters."""

    def test_con012_is_the_approved_text(self):
        text = read("CONSTITUTION.md")
        part = text[text.index("### CON-012"):text.index("## 三、受控变更")]
        self.assertIn("### CON-012 先备料，后落笔（硬，料好不好靠编辑）", part)
        for phrase in ("写或重写一整章，起草前先备两样料。一是声音样本：作者自己写的、已采纳的原文两三段，或者作者指定的目标稿。",
                       "二是现场素材：每个核心场看得见、摸得到、听得到的东西（光线、物件、衣着、声音、气味），每样写明出处",
                       # r5.35: NWC-1.6 (approved by the author): the material lands in what people do and notice.
                       "素材里的东西要落在人的动作和感知里，不只摆着", "不要求每件陈设都被碰、被拿或变成道具",
                       "各模块的规则和检查（包括 CON-011 的几处数量）是交稿时要做到的，写完以后按修改的五道工序查，不边写边对着清单凑。",
                       "边写边对着规则写，写出来的是照章办事的文字。",
                       "改作者的旧稿时，原稿本身就是声音样本。只润色、只改标点的任务不另备素材。",
                       "作者说过是 AI 写的文字不当声音样本；作者明确指定为目标稿的可以用，记明是 AI 协助写的。",
                       "参考图、灵感库和已定设定、已采纳正文对不上的，以设定和正文为准，列给作者。",
                       "图里没有的不替图编；图只给看得见的东西，不给情节和设定。灵感库只记来源、授权和看得见的东西，图本身只在自用版。",
                       "那把扳手后来成了交锋里的道具", "读起来像在交作业",
                       "交付门的素材卡检查（落笔前冻结，样本和每个核心场的素材都要写明出处）"):
            self.assertIn(phrase, part)

    def test_version_heading_and_record(self):
        text = read("CONSTITUTION.md")
        # r5.34: NWC-1.5 (CON-011 amended, approved by the author) replaced the version line; this entry stays.
        # r5.35: NWC-1.6 (CON-012 amended, approved by the author) replaced it again; this entry stays.
        self.assertIn("版本：NWC-1.7（2026-11-01，作者批准 r5.49 修订方案（回复“按照你的想法去做”），按方案修订 CON-011：情绪的落点并列台词、选择、注意力、处境、内心、动作、生理反应和微动作、道具和感知，也可以留白，不同人物、不同场面不套同一种反应；NWC-1.6 在 2026-10-23 修订了 CON-012）", text)
        self.assertIn("## 二、十二条原则", text)
        self.assertIn("NWC-1.4，2026-10-23（r5.33）：作者拿自己的原稿加参考图写出第一章的新稿", text)
        self.assertIn("作者看过全文后批准（“批准，按这段改”），同时批准第二节标题改为“十二条原则”、交付门加素材卡检查", text)
        self.assertIn("NWC-1.3，2026-10-22（r5.32）", text)  # the earlier entries stay

    def test_the_registry_knows_con012(self):
        registry = json.loads(read("assets/constitution-rules.json"))
        self.assertEqual((registry["version"], registry["date"]), ("NWC-1.7", "2026-11-01"))  # r5.49: NWC-1.7 amends CON-011
        rule = registry["rules"][-1]
        self.assertEqual((rule["id"], rule["title"], rule["kind"]), ("CON-012", "先备料，后落笔", "hard"))
        refs = {(ref["type"], ref.get("file"), ref.get("contains")) for ref in rule["enforced_by"]}
        self.assertIn(("script", "novel-workshop/scripts/workflow_guard.py", "def read_material_card("), refs)
        self.assertIn(("script", "novel-workshop/scripts/inspiration_library.py", "def check_library("), refs)
        self.assertTrue(any(ref["type"] == "test" for ref in rule["enforced_by"]))


SAMPLE = """# 声音样本与现场素材卡

## 声音样本：作者自己的原文

- **样本来源**：第六章第 29—35 行（作者原文，已采纳）
- **原文**：
  程棠把钥匙在指头上转了一圈：“明早再来？”
  “今晚得交。”
- **样本来源**：第三章第 1—2 行（作者指定的目标稿，AI 协助写的）
- **原文**：雨还没停，修车铺的卷帘门拉下一半。

- **从样本里看出来的**：短句，台词不带“说”。

## 现场素材：每个核心场一块

- **Scene ID**：S1
- **看得见、摸得到的东西**：墙上按尺寸挂的扳手；沾油的千斤顶；门口漏雨的铁皮檐
- **出处**：作者的参考图 2；灵感库 IMG-001
- **和已定设定不一样的**：无
"""
BEATS = """# Scene Beat Card (单场戏剧节拍卡)

- **Scene ID / Chapter**: S1 / 第七章
- **Scene Type**: `Core Conflict (核心博弈戏)`
- **POV Character & Sensory Limit (视角人物与感知盲区)**: 宋青；看不见柜台后面
- **Polarity Shift (局势极性变化)**: `[求人] -> [欠人]`
- **Core Prop Anchor (核心交互道具)**: 扳手、千斤顶
1. **入场动作与诉求 (Goal - Late In)**: 要老范今天就修好车
2. **对手反制与阻碍 (Obstacle & Escalation)**: 老范说零件没有
3. **破局点/意外转折 (The Turn)**: 她把扳手递过去
4. **出场悬念钩子 (Exit Hook - Early Out)**: 车修好了，钥匙留在柜台上
- **禁止直接概括的过程**: 递扳手那几句
- **潜台词冰山 (Subtext)**: 谁求谁
- **情绪生理化映射 (Embodiment)**: 她把钥匙圈转了两圈

- **Scene ID / Chapter**: S2 / 第七章
- **Scene Type**: Transition (过场桥段-限200字)
"""
CHAPTER = "第七章　修车铺\n\n宋青进门时，铁皮檐还在滴水。墙上的扳手按尺寸挂着。\n\n老范拨开千斤顶：“零件没有。”\n"


class MaterialGate(unittest.TestCase):
    """workflow_guard.py voice_material: run through start / check / status like a real task."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.work = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, name, text):
        (self.work / name).write_bytes(text.encode("utf-8"))

    def guard(self, *args):
        code, out, err = run(GUARD, *args, cwd=self.work)
        try:
            return code, json.loads(out)
        except ValueError:
            return code, {"raw": out + err}

    def project(self, card=SAMPLE, beats=None, source="material.md"):
        self.write("draft.md", CHAPTER)
        self.write("material.md", card)
        checks = [{"id": "material", "type": "voice_material", "source": source}]
        if beats is not None:
            self.write("beats.md", beats)
            checks.append({"id": "beats", "type": "scene_beats", "source": "beats.md"})
        self.write("checks.json", json.dumps({"candidate": "draft.md", "checks": checks}))
        code, out = self.guard("start", "state.json", "--task-id", "ch7", "--spec", "checks.json")
        if code:
            return code, out
        return self.guard("check", "checks.json")

    def material(self, out):
        return next(c for c in out["checks"] if c["id"] == "material")

    def test_a_filled_card_passes(self):
        code, out = self.project()
        self.assertEqual(out["status"], "GREEN", out)
        actual = self.material(out)["actual"]
        self.assertEqual((actual["samples"], actual["no_sample"], actual["scenes"]), (2, None, ["S1"]))

    def test_a_card_without_sources_does_not_pass(self):
        cases = ((read(CARD), "no voice sample"), (read(CARD), "Scene ID is empty"),
                 (SAMPLE.replace("- **出处**：作者的参考图 2；灵感库 IMG-001\n", ""), "S1: empty: 出处"),
                 (SAMPLE.replace("- **出处**：作者的参考图 2；灵感库 IMG-001", "- **出处**："), "S1: empty: 出处"),
                 (SAMPLE.replace("- **看得见、摸得到的东西**：墙上按尺寸挂的扳手；沾油的千斤顶；门口漏雨的铁皮檐", "- **看得见、摸得到的东西**："),
                  "S1: empty: 看得见、摸得到的东西"),
                 (SAMPLE.replace("- **原文**：雨还没停，修车铺的卷帘门拉下一半。", "- **原文**："), "needs both 样本来源"),
                 (SAMPLE + "\n- **没有样本**：新书\n", "keep one of them"),
                 (SAMPLE.split("## 现场素材")[0], "no scene material"),
                 (SAMPLE + "\n- **Scene ID**：S1\n- **看得见、摸得到的东西**：一盏灯\n- **出处**：设定\n", "Scene ID S1 has two material blocks"))
        for card, why in cases:
            with self.subTest(why=why):
                self.tearDown()
                self.setUp()
                code, out = self.project(card)
                self.assertEqual(out["status"], "RED", out)
                problems = self.material(out)["actual"]["problems"]
                self.assertTrue(any(why in p for p in problems), problems)

    def test_no_sample_with_a_reason_passes(self):
        card = SAMPLE.split("## 声音样本")[0] + "## 声音样本\n\n- **没有样本**：新书，作者只给了大纲\n\n## 现场素材" \
            + SAMPLE.split("## 现场素材")[1]
        code, out = self.project(card)
        self.assertEqual(out["status"], "GREEN", out)
        self.assertEqual(self.material(out)["actual"]["no_sample"], "新书，作者只给了大纲")

    def test_every_core_scene_on_the_beat_card_needs_material(self):
        code, out = self.project(SAMPLE.replace("- **Scene ID**：S1", "- **Scene ID**：S2"), BEATS)
        self.assertEqual(out["status"], "RED", out)
        problems = self.material(out)["actual"]["problems"]
        self.assertTrue(any("without a material block: S1" in p for p in problems), problems)
        # NWC-1.5 (r5.34): an Other scene may have a material block too; S2 here is a transition.
        self.assertTrue(any("not core, action or other scenes on the beat card: S2" in p for p in problems), problems)
        self.tearDown()
        self.setUp()
        code, out = self.project(SAMPLE, BEATS)
        self.assertEqual(out["status"], "GREEN", out)
        self.assertEqual(self.material(out)["actual"]["planned_scenes"], ["S1"])

    def test_the_card_is_frozen_when_the_task_starts(self):
        self.project()
        self.write("material.md", SAMPLE.replace("门口漏雨的铁皮檐", "门口的铁皮檐"))
        code, out = self.guard("status", "state.json")
        self.assertEqual(out["gate"]["input_ready"], "BLOCKED", out["gate"])
        self.assertIn("changed: material.md", out["gate"]["input_problems"])

    def test_the_card_is_not_the_candidate(self):
        code, out = self.project(source="draft.md")
        self.assertNotEqual(code, 0)
        self.assertIn("must differ from candidate", json.dumps(out, ensure_ascii=False))

    def test_the_library_card_output_reads_as_material(self):
        guard = load(GUARD, "r533_guard")
        with tempfile.TemporaryDirectory() as tmp:
            library = Path(tmp) / "library.json"
            library.write_bytes(json.dumps(LIBRARY_DATA, ensure_ascii=False).encode("utf-8"))
            (Path(tmp) / "images").mkdir()
            (Path(tmp) / "images" / "IMG-001.jpg").write_bytes(IMAGE)
            code, out, err = run(LIBRARY, "card", library, "--chapter", "7")
        self.assertEqual(code, 0, err)
        found, problems = guard.read_material_card(SAMPLE.split("## 现场素材")[0] + "## 现场素材\n\n" + out)
        self.assertEqual(found["scenes"], ["S1"])
        self.assertEqual(problems, [])


IMAGE = b"\xff\xd8\xff\xe0 not a real jpeg, only bytes to hash"
LIBRARY_DATA = {
    "schema": "inspiration-library/1", "book": "测试", "note": "测试数据",
    "entries": [
        {"id": "IMG-001", "kind": "place", "title": "修车铺里间", "visible": "墙上按尺寸挂的扳手；沾油的千斤顶",
         "source": {"type": "author_file", "file": "images/IMG-001.jpg", "sha256": hashlib.sha256(IMAGE).hexdigest(),
                    "creator": "作者", "license": "作者自己的图"},
         # r5.34: a picked entry says which parts the author takes ("整张" for the whole image).
         "status": "picked", "take": ["整张"], "use": [{"chapter": 7, "scene": "S1"}], "conflicts": ["照片里有电动扳手，本书没有电"]},
        {"id": "WEB-001", "kind": "prop", "title": "手摇报警器", "visible": "铸铁外壳掉漆",
         "source": {"type": "link", "url": "https://commons.wikimedia.org/wiki/File:Example.jpg", "site": "维基共享资源",
                    "license": "未核，只作写作参考", "retrieved": "2026-10-23"},
         "status": "candidate", "use": [], "conflicts": []},
        {"id": "Q-001", "kind": "light", "title": "雨夜门口", "visible": "",
         "source": {"type": "search", "queries": ["雨夜 修车铺 门口", "repair shop night rain"]},
         "status": "to_find", "use": [{"chapter": 7, "scene": "S2"}], "conflicts": []},
    ],
}


class Library(unittest.TestCase):
    """inspiration_library.py: the record is complete; it reads, it never fetches or writes."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        (self.root / "images").mkdir()
        (self.root / "images" / "IMG-001.jpg").write_bytes(IMAGE)

    def tearDown(self):
        self.tmp.cleanup()

    def library(self, data=None):
        path = self.root / "library.json"
        path.write_bytes(json.dumps(LIBRARY_DATA if data is None else data, ensure_ascii=False).encode("utf-8"))
        return path

    def test_a_complete_library_passes(self):
        path = self.library()
        before = hashlib.sha256(path.read_bytes()).hexdigest()
        code, out, err = run(LIBRARY, "check", path)
        report = json.loads(out)
        self.assertEqual((code, report["status"], report["entries"]), (0, "OK", 3), out + err)
        self.assertEqual(report["by_status"], {"to_find": 1, "candidate": 1, "picked": 1, "rejected": 0})
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), before)

    def test_what_an_incomplete_record_looks_like(self):
        def changed(index, **fields):
            data = json.loads(json.dumps(LIBRARY_DATA))
            entry = data["entries"][index]
            for key, value in fields.items():
                if value is None:
                    entry.pop(key, None)
                else:
                    entry[key] = value
            return data

        link = dict(LIBRARY_DATA["entries"][1]["source"])
        cases = ((changed(0, visible=""), "IMG-001: visible is empty"),
                 (changed(0, source=dict(LIBRARY_DATA["entries"][0]["source"], sha256="0" * 64)), "IMG-001: the file changed"),
                 (changed(0, source=dict(LIBRARY_DATA["entries"][0]["source"], file="images/none.jpg")), "file not found"),
                 (changed(0, source={k: v for k, v in LIBRARY_DATA["entries"][0]["source"].items() if k != "sha256"}),
                  "needs its sha256"),
                 (changed(1, source=dict(link, license="")), "WEB-001: license is empty"),
                 (changed(1, source=dict(link, url="commons.wikimedia.org/x")), "WEB-001: url must be"),
                 (changed(2, status="picked", visible="雨"), "needs the image itself"),
                 (changed(2, source={"type": "search", "queries": []}), "queries must be"),
                 (changed(1, status="to_find"), "an entry still to find has a search source"),
                 (changed(0, kind="photo"), "kind must be one of"),
                 (changed(0, status="maybe"), "status must be one of"),
                 (changed(0, use=[{"chapter": 0}]), "each use is"),
                 (changed(0, conflicts="无"), "conflicts must be a list"),
                 (changed(1, id="IMG-001"), "the id is used twice"),
                 (changed(0, colour="red"), "unknown field"))
        for data, why in cases:
            with self.subTest(why=why):
                code, out, err = run(LIBRARY, "check", self.library(data))
                report = json.loads(out)
                self.assertEqual((code, report["status"]), (1, "PROBLEMS"), out)
                self.assertTrue(any(why in p for p in report["problems"]), report["problems"])

    def test_list_and_card(self):
        path = self.library()
        code, out, err = run(LIBRARY, "list", path, "--chapter", "7")
        self.assertEqual(code, 0, err)
        self.assertIn("IMG-001  [place/picked]  修车铺里间  用在：第7章 S1", out)
        self.assertIn("Q-001  [light/to_find]", out)
        self.assertNotIn("WEB-001", out)
        code, out, err = run(LIBRARY, "list", path, "--status", "candidate", "--format", "json")
        self.assertEqual([e["id"] for e in json.loads(out)], ["WEB-001"])
        code, out, err = run(LIBRARY, "card", path, "--chapter", "7")
        self.assertEqual(code, 0, err)
        # r5.34: the block shows what the author takes; "整张" brings the whole visible description.
        for line in ("- **Scene ID**：S1", "- **看得见、摸得到的东西**：（IMG-001）整张：墙上按尺寸挂的扳手；沾油的千斤顶",
                     "- **出处**：灵感库 IMG-001（作者的图 images/IMG-001.jpg）",
                     "- **和已定设定不一样的**：IMG-001：照片里有电动扳手，本书没有电", "还没找到图的（搜索词）：",
                     "- Q-001 雨夜门口：雨夜 修车铺 门口；repair shop night rain"):
            self.assertIn(line, out)
        code, out, err = run(LIBRARY, "card", path, "--chapter", "8")
        self.assertIn("第 8 章在灵感库里没有挑中的条目，也没有待找的。", out)
        # Only what the author picked goes into the card; a candidate for the same scene does not.
        data = json.loads(json.dumps(LIBRARY_DATA))
        data["entries"][1]["use"] = [{"chapter": 7, "scene": "S1"}]
        code, out, err = run(LIBRARY, "card", self.library(data), "--chapter", "7")
        self.assertIn("IMG-001", out)
        self.assertNotIn("WEB-001", out)

    def test_bad_input(self):
        bad = self.root / "bad.json"
        for content in (b"{not json", json.dumps({"schema": "x", "entries": []}).encode("utf-8"),
                        json.dumps({"schema": "inspiration-library/1", "entries": {}}).encode("utf-8")):
            bad.write_bytes(content)
            code, out, err = run(LIBRARY, "check", bad)
            self.assertEqual((code, json.loads(out)["status"]), (2, "ERROR"))
        code, out, err = run(LIBRARY, "card", self.library(), "--chapter", "0")
        self.assertEqual((code, json.loads(out)["status"]), (2, "ERROR"))

    def test_it_never_goes_online_or_writes(self):
        source = LIBRARY.read_text(encoding="utf-8")
        for word in ("urllib", "socket", "http.client", "requests", "subprocess", "open(", "write_bytes", "write_text"):
            self.assertNotIn(word, source, word)

    def test_the_template(self):
        template = json.loads(read(TEMPLATE))
        # r5.35: the template is format 2 (format-1 libraries are still read, see test_r535_library_v2).
        self.assertEqual(template["schema"], "inspiration-library/2")
        self.assertEqual([e["status"] for e in template["entries"]], ["picked", "candidate", "to_find"])
        self.assertIn("网上的图只记链接、来源和授权，不成批下载；图本身只在自用版", template["note"])
        code, out, err = run(LIBRARY, "check", SKILL / TEMPLATE)
        self.assertEqual(json.loads(out)["problems"][0], "IMG-001: file not found: images/IMG-001.jpg")


class Wiring(unittest.TestCase):
    def test_module(self):
        text = read(MODULE)
        self.assertTrue(text.startswith("# 灵感库：参考图和现场素材\n"))
        for heading in ("## 图从哪里来", "## 不成批抓图", "## 每条记什么", "## 怎样用", "## 核对", "## 和别的模块怎样分工"):
            self.assertIn("\n" + heading + "\n", text)
        for phrase in ("宪法 CON-012“先备料，后落笔”", "**作者给的图**", "**工坊推荐**", "中文、英文各写几个",
                       "不写爬虫成批下载网站上的图", "图本身只在作者有权保存时才存", "而且只在自用版，不进商业版",
                       "未核，只作写作参考", "作者挑中的才算入库", "只写图里看得见的", "以设定为准",
                       "不把真人的脸写成人物，也不写真人的名字", "不照着知名画作、电影剧照、游戏画面一格一格地写",
                       "`python3 scripts/inspiration_library.py card 本书/inspiration/library.json --chapter 7`"):
            self.assertIn(phrase, text)
        last = [line for line in text.splitlines() if line.strip()][-1]
        self.assertTrue(last.startswith("来源：作者 2026-10-23 的决定。"), last)

    def test_skill_drafting_execution_and_card(self):
        level = next(line for line in read("SKILL.md").splitlines() if line.startswith("| L1 整章 |"))
        self.assertIn("（参考图和本书的 [灵感库](references/inspiration-library.md)），看着这三样起草（CON-012）", level)
        self.assertIn("检查清单另声明 `voice_material`（素材卡，CON-012）", level)
        rows = [line for line in read("SKILL.md").splitlines() if line.startswith("| ")
                and "](references/inspiration-library.md)" in line and not line.startswith("| L1 整章 |")]
        self.assertEqual(len(rows), 1, rows)
        self.assertIn("本书的灵感库用 [inspiration_library.py](scripts/inspiration_library.py)", read("SKILL.md"))
        self.assertIn("这是宪法 CON-012“先备料，后落笔”：检查清单里声明 `voice_material`", read("references/drafting.md"))
        self.assertIn("本书 [灵感库](inspiration-library.md) 里挑中的条目也用上", read("references/drafting.md"))
        self.assertIn("| `voice_material` | `source`（这一章的声音样本与现场素材卡", read("references/execution.md"))
        card = read(CARD)
        for phrase in ("写或重写一整章时，落笔前填（宪法 CON-012）", "检查清单里声明 `voice_material`（`source` 写这张卡）",
                       "- **样本来源**：", "- **原文**：", "- **没有样本**：", "- **出处**：", "素材里的东西要落在人的动作和感知里，不只摆着（CON-012，NWC-1.6）"):  # r5.35
            self.assertIn(phrase, card)
        notes = read("assets/third-party/SOURCE-NOTES.md")
        row = next((line for line in notes.splitlines() if "](../../references/inspiration-library.md)" in line), "")
        self.assertIn("宪法 CON-012“先备料，后落笔”（作者批准条文，NWC-1.4）", row)

    def test_the_sale_export_carries_the_library(self):
        exporter = load(SKILL / "scripts" / "export_portable.py", "r533m_export")
        for name in (MODULE, TEMPLATE, "scripts/inspiration_library.py"):
            self.assertIn(name, set(exporter.SALE_FILES))
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "sale.zip"
            code, out, err = run(SKILL / "scripts" / "export_portable.py", target, "--mode", "sale")
            self.assertEqual(code, 0, out + err)
            with zipfile.ZipFile(target) as archive:
                names = set(archive.namelist())
                portable = archive.read("portable-novel-workshop.md").decode("utf-8")
            self.assertIn("# 灵感库：参考图和现场素材", portable)
            self.assertIn("### CON-012 先备料，后落笔", portable)
            self.assertTrue(any(n.endswith("novel-workshop/scripts/inspiration_library.py") for n in names))
            self.assertFalse([n for n in names if "project-packs" in n])


if __name__ == "__main__":
    unittest.main()

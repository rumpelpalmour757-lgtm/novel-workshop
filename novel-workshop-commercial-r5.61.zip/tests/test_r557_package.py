#!/usr/bin/env python3
"""r5.57: the version is the same everywhere, and the release notes say what this release did.

r5.56 pinned its version in test_r556_package.py; from r5.57 on that file checks that the r5.56 entries stay in the
changelog and the verification notes as history, and the current version is pinned here, the same way.

The release notes are checked for what they must cover: the three things this release did (a format-only task is a
task of its own, fidelity conversion, with how it is checked and how the delivery is worded; what to do when the author
takes an acceptance back, with what the delivery gate cannot do yet; the number in the examples page's title), that
no script changed, how to upgrade from r5.56 and from earlier releases, and what was not verified. These tests only
check that the notes say so; they do not show that the workshop handles these tasks well, or that anything writes
better.

r5.58: the current version is pinned in test_r558_package.py now, the same way. The tests here that pinned r5.57 as the
current version (on the five pages, in the manifest, in the newest changelog and verification entries, in README's
version line and "本版" section) check instead that the r5.57 entries stay where they were, below the newer ones, with
what they said, and that README lists r5.57 among the earlier releases. Each looks its entry up by the heading and
fails when the heading is missing, so a renamed or dropped entry does not pass by finding nothing.
"""
import json
import os
from pathlib import Path
import re
import sys
import unittest

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
VERSION = "2026-11-15-r5.57"
TITLE = "小说写作工坊 r5.57"
PAGES = ("README.md", "QUICKSTART.md", "USAGE.md", "EXAMPLES.md", "skills/novel-workshop/SKILL.md")
README_LINE = ("版本：小说写作工坊 r5.57（`2026-11-15-r5.57`）。在 r5.56 上做三件事：只换格式、不动字句的算单独一类任务"
               "（保真转换），写明怎样核、交付怎样写；补上作者收回采纳时怎么办，照实写交付门现在的限制；改正使用示例标题里的条数。")
BOUND_SCRIPTS = ("`workflow_guard.py`", "`punctuation_lint.py`", "`prose_lint.py`", "`fact_guard.py`", "`project_state.py`")


def read(path):
    return (ROOT / path).read_text(encoding="utf-8")


def newest_entry(text):
    """The text of the first '## ' section of a changelog-like page, heading included."""
    parts = re.split(r"(?m)^(?=## )", text)
    return parts[1] if len(parts) > 1 else ""


def entry_for(text, version):
    """The '## ' section of a changelog-like page whose heading starts with version, heading included ("" if none)."""
    return next((part for part in re.split(r"(?m)^(?=## )", text)[1:] if part.startswith("## " + version)), "")


def part(text, heading):
    """From a '### ' heading to the next '### ' heading ("" if the heading is missing)."""
    start = text.find("\n### " + heading)
    if start < 0:
        return ""
    end = text.find("\n### ", start + 1)
    return text[start:] if end < 0 else text[start:end]


class Version(unittest.TestCase):
    def test_the_r557_records_stay_as_history(self):
        # r5.58: this test pinned r5.57 as the current version on the five pages, in the manifest and at the top of
        # CHANGELOG.md and VERIFICATION.md. The current version is pinned in test_r558_package.py now; here the r5.57
        # entries are looked up by their headings and must still be there with what they said, below a newer entry.
        changelog, verification = read("CHANGELOG.md"), read("VERIFICATION.md")
        entry = entry_for(changelog, VERSION)
        self.assertTrue(entry.startswith("## %s（%s）" % (VERSION, TITLE)), entry[:60])
        self.assertNotEqual(newest_entry(changelog), entry)  # a newer release carries this test
        self.assertIn("这一版在 r5.56（`2026-11-14-r5.56`）上做", entry)
        checked = entry_for(verification, VERSION)
        self.assertTrue(checked.startswith("## " + VERSION + " 的验证"), checked[:60])
        self.assertNotEqual(newest_entry(verification), checked)
        self.assertIn("运行 1694 项", checked)
        manifest = json.loads(read("PACKAGE-MANIFEST.json"))
        self.assertNotEqual(manifest["version"], VERSION)
        for page in PAGES:
            # r5.58: the version lines name the newer release; r5.57 is not stated as the current version anywhere
            self.assertNotIn("`" + VERSION + "`", read(page).split("\n## ", 1)[0], page)

    def test_the_r557_headings_do_not_call_it_a_candidate(self):
        # r5.58: the version lines of the five pages name r5.58 now (test_r558_package.py checks them); the r5.57
        # headings that stay in the history still must not call r5.57 a candidate.
        for page in ("CHANGELOG.md", "VERIFICATION.md"):
            entry = entry_for(read(page), VERSION)
            self.assertTrue(entry, page)
            self.assertNotIn("候选", entry.splitlines()[0], page)

    def test_the_readme_lists_r557_among_the_earlier_releases(self):
        # r5.58: README's version line and "本版" section describe r5.58 now (test_r558_package.py pins them); r5.57
        # moved into "历次版本" as one line, above r5.56, the way r5.56 did in r5.57.
        readme = read("README.md")
        self.assertNotIn(README_LINE, readme)
        current = next(p for p in re.split(r"(?m)^(?=## )", readme) if p.startswith("## 本版"))
        self.assertFalse(current.startswith("## 本版（r5.57）"), current[:40])
        history = readme.split("## 历次版本", 1)[1].split("\n## ", 1)[0]
        line = next((l for l in history.splitlines() if l.startswith("- **r5.57**：")), "")
        for phrase in ("保真转换", "格式检查通过，文学质量未审", "收回采纳", "三十个"):
            self.assertIn(phrase, line, phrase)
        self.assertLess(history.index("- **r5.57**："), history.index("- **r5.56**："))


class ReleaseNotes(unittest.TestCase):
    def setUp(self):
        # r5.58: the r5.57 entry is no longer the newest one; it is looked up by its heading.
        self.entry = entry_for(read("CHANGELOG.md"), VERSION)
        self.assertTrue(self.entry.startswith("## %s（%s）" % (VERSION, TITLE)), self.entry[:60])

    def test_the_opening_says_where_it_comes_from_and_what_it_does_not_claim(self):
        opening = self.entry.split("\n### ", 1)[0]
        for phrase in ("在 r5.56", "BJM", "按编排方的想法来", "同一个模型（Claude）的新实例", "不是独立评审", "不说明写得更好",
                       "r5.56 的包原样留着"):
            self.assertIn(phrase, opening, phrase)

    def test_the_entry_says_what_changed(self):
        fidelity = part(self.entry, "一、")
        for phrase in ("`references/editing.md`", "“先定范围”", "保真转换", "不动标点", "`references/chinese-punctuation.md`",
                       "不扩大", "格式检查通过，文学质量未审", "`detail_check.py changes`", "`--keep`",
                       "`punctuation_lint.py --baseline`", "MECHANICAL", "`SKILL.md`", "`references/chapter-confirmation.md`",
                       "`references/author-preferences.md`", "`references/file-delivery.md`", "`assets/revision-card.md`",
                       "`workflow_guard.py accept --skip-review`", "`replan`"):
            self.assertIn(phrase, fidelity, phrase)
        withdrawal = part(self.entry, "二、")
        for phrase in ("`references/quality-loop.md`", "收回采纳", "`reopen`", "`final`", "`fact_guard.py impact`", "候选",
                       "`references/chapter-confirmation.md`", "`workflow_guard.py` 还没有收回采纳的命令", "没有改"):
            self.assertIn(phrase, withdrawal, phrase)
        skipped = part(self.entry, "三、")
        for phrase in ("`--deliverable`", "“说定本”", "BLOCK", "作者原话和出处"):
            self.assertIn(phrase, skipped, phrase)
        title = part(self.entry, "四、")
        for phrase in ("二十六个可复制的使用示例", "三十个可复制的使用示例", "`tests/test_r535_starter.py`"):
            self.assertIn(phrase, title, phrase)

    def test_the_entry_says_no_script_changed(self):
        tests = part(self.entry, "五、")
        for phrase in ("`tests/test_r557_rules.py`", "`tests/test_r557_package.py`", "`tests/test_r556_package.py`",
                       "`tests/test_r556_rules.py`", "`tests/test_r535_starter.py`", "逐字节相同", "没有改任何脚本") \
                + BOUND_SCRIPTS:
            self.assertIn(phrase, tests, phrase)

    def test_the_decisions_made_on_the_way_are_listed_and_can_be_changed(self):
        decided = part(self.entry, "这一版顺带定下的几处做法")
        for phrase in ("跳过审稿采纳", "章标题", "交付门卡", "5004", "L0、L1、L2", "要改"):
            self.assertIn(phrase, decided, phrase)

    def test_the_entry_says_how_to_upgrade(self):
        upgrade = part(self.entry, "怎样升级")
        for phrase in ("从 r5.56 升上来", "python install.py --upgrade --dry-run", "`assets/project-packs/`", "交付记录照旧",
                       "五个绑定脚本", "r5.56 一节"):
            self.assertIn(phrase, upgrade, phrase)

    def test_the_entry_and_the_verification_notes_say_what_was_not_verified(self):
        # r5.58: the r5.57 verification entry is looked up by its heading too.
        verification = entry_for(read("VERIFICATION.md"), VERSION)
        self.assertTrue(verification.startswith("## " + VERSION + " 的验证"), verification[:60])
        for text in (part(self.entry, "没有验证的"), part(verification, "没有验证的")):
            for phrase in ("同一个模型", "Word", "PDF", "原生 Windows", "macOS", "办得好不好", "不说明写得更好"):
                self.assertIn(phrase, text, phrase)

    def test_the_verification_notes_name_what_was_run(self):
        verification = entry_for(read("VERIFICATION.md"), VERSION)
        self.assertTrue(verification.startswith("## " + VERSION + " 的验证"), verification[:60])
        for phrase in ("python3 -I -B tests/run_tests.py", "`__pycache__`", "`tests/test_r557_rules.py`",
                       "`tests/test_r557_package.py`", "成对测试", "只作维护记录", "同一个模型", "升级和退回",
                       "`novel-workshop/assets/project-packs/_author/`", "私料核对"):
            self.assertIn(phrase, verification, phrase)
        pairs = part(verification, "成对测试")
        for phrase in ("30 次", "30/30", "18/18", "不说明"):
            self.assertIn(phrase, pairs, phrase)


if __name__ == "__main__":
    unittest.main()

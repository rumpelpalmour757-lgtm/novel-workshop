# 学习与自我纠错执行

## 范围与入口

作者已启用本模块时，在写作或改稿中执行“选示范、判断适用、交稿、自检或教师反馈、取舍、返工、复查、留经验”。宿主代理实际调用写作者和教师；[执行脚本](../scripts/learning_loop.py)只负责条件保存、版本绑定与下一步提示，不伪装成模型、后台调度器或参数训练。无外部教师配置时使用当前宿主可用模型，注明角色与上下文；不要借用别家模型名称。

保留既有创作模块、作者规则、事实记录及[交付门](execution.md)。此模块不另设定稿门，不改宪法，不自动写回作者定稿，不将简短取舍说明当作可读取的内部思维链。只有正文的请求，过程记录留在项目，不插进小说。

作者已开启[每章逐阶段确认](chapter-confirmation.md)时，先服从章节阶段推进：教师审查及反馈整理在已获准的相应阶段执行，下一阶段须等作者确认。学习循环的 `finish/learn` 不代替章节确认或作者定稿。章节确认事件独立于本学习开关，进度同存项目的 `data.chapter_confirmations`，不另立 AUTHOR 状态。

作者采用手动教师交接时，完整初稿先交作者，再等待作者返回教师意见或改稿。原始回传先作为教师材料保存，不自行认定其全部正确或已获作者采纳。工坊核对原稿和回传版本，逐条判采纳/拒绝/暂缓与理由，形成整份修订计划交作者确认；实际修订、复查与示范条件由工坊整理，不要求作者逐条手工标注。原稿、回传、取舍和过程及时保存；可调用示范按实际复查与作者接受证据登记，没有教师对当前最终稿的复查就不伪造该认可。下一章仍先检索、判断条件和例外，再应用。

## 唯一记录

已有项目 JSON 权威时使用原文件，仅增改学习命名空间 `data.demonstration_learning`、`data.demonstrations`、`data.learning_runs`、`data.learning_events`，以及章节协作的 `data.chapter_confirmations`、`data.chapter_workflow_policy`；用 `project_state.commit_state` 严格 CAS，不做自动三向合并。人物、设定、章节和其他字段完整保留。

仅有 Markdown 档案的项目，保留其故事权威，在该项目内使用一个由 PROJECT 明确链接的 Markdown 学习记录。它只保存本模块记录，不含人物、设定或章节权威，不初始化空 `story-state.json`。唯一数据块使用以下固定标记；块外文字写入时原样保留：

````text
<!-- NOVEL_WORKSHOP_LEARNING_START -->
```json
{"schema_version":1,"project_id":"本书分支","revision":0,"data":{"demonstration_learning":{"enabled":true,"loop_enabled":true,"max_revisions":2},"demonstrations":{},"learning_runs":{},"learning_events":{}}}
```
<!-- NOVEL_WORKSHOP_LEARNING_END -->
````

Markdown 写入需全文 SHA256 条件检查、稳定 POSIX 文件锁和同目录原子替换；冲突时重读，不强制覆盖。Windows 原生环境若无受支持锁，使用宿主提供的受保护保存或交付待应用补丁，不降级成无锁覆盖。记录成功不认证外部来源、评审独立性或文学质量。

## 每次执行

1. 协调者运行 `status` 读取状态和版本，运行 `context` 取最多三条当前项目、任务和标签相符的认可示范；沿用[示范隔离](demonstration-learning.md)。匿名评测必须排除当前场景组；写作者仅拿过滤材料，不拿原库路径。
2. `start` 保存本轮实际输入、来源、任务、场景组及不可改动要求；冻结被选案例的版本。`plan` 逐条记录 `apply/adapt/decline`、适用条件检查、例外检查和短理由，并给出本轮核查项。拒绝应用不阻塞写作，没有适用示范时正常执行。
3. 宿主写作者交出真实候选后用 `draft` 记录文字、来源和执行上下文。可原样保留，不要求制造差异。
4. 宿主自检或调用教师，`review` 保存实际判断、问题、证据、范围，绑定本轮 `run_id`、稿件 SHA256 和评审身份。`self_check` 不算独立审稿；独立代理须记录与写作者不同的上下文标识。没有真实评审输出就保持待审。
5. 有问题时用 `decide` 逐条记 `adopt/decline/defer` 和理由。不得凭教师身份盲从；事实、当前任务及作者锁定内容优先。`revise` 只处理已采纳问题，保存父稿到新稿的关联，并计入返工次数。修改一字也需要对新哈希重新评审；旧反馈不能替代新复查。
6. 新复查明确关联要复查的旧反馈，确认当前稿通过后 `finish`。只有自查时标自查完成；教师复查通过才标教师已审。问题未解、达到本轮返工额度或无法判断时用 `stop` 留下原因，不循环到自评分通过。既有 `workflow_guard` 有更小预算时服从它，本模块次数上限只是附加保护。
7. `learn` 仅从这次真实输入、实际最终稿、取舍和当前稿评审提炼案例。条件、例外、简短依据及来源必填。自查材料保持 `candidate`；教师实际复查通过可记 `teacher_approved`；作者接受必须另记指向当前哈希的原话和出处。新案例不因保存而自动变全局规则，也不声称迁移已验证。

正常写作无需向作者逐条提问。作者负责方向、审美校准与抽查；只有当前任务无法自行解决的事实或方向冲突才交作者裁决。教师反馈可以由作者贴入，或由已配置且已授权的模型接口取得；本模块不新增外发服务或费用授权。

## 命令与事件契约

```bash
python3 scripts/learning_loop.py status /项目/学习记录.md
python3 scripts/learning_loop.py context /项目/学习记录.md --project-id 本书 --task dialogue_revision --tag 回应 --exclude-group 当前场景
python3 scripts/learning_loop.py apply /项目/学习记录.md /项目/本轮事件.json --project-id 本书 --if-version 'status返回的version'
```

事件总有 `event_id`、`op`；涉及任务时有 `run_id`。同 ID 同载荷重试返回 `unchanged`，同 ID 不同载荷拒绝。成功后核对返回状态或 `status`；返回丢失先回读，不能盲目再生成新 ID 重做。具体字段与示例见脚本 `--help`；JSON 输入不能执行任意命令。

`learning_events` 保留原事件载荷及其哈希，历史接受证据不因当前稿换版而丢失。稿件除文字哈希外还有登记实例编号；同一文字重新登记也不能直接借用旧实例的评审。`pending_rechecks` 保存累计必须覆盖的旧反馈 ID，是否还有未解复查应看当前实例的通过评审是否覆盖这些 ID，不能仅凭该列表非空判未完成。

替换已完成而目录持久化确认失败时，返回 `saved_durability_uncertain`（退出码 4）和警告。先回读核实，不能声称完全未写入，也不能换新事件 ID 盲目重试；相同事件重试仍按幂等处理。

| 操作 | 最小内容 |
| --- | --- |
| `configure` | `loop_enabled` 布尔值，可选 `max_revisions`（1–5） |
| `start` | `task`、`tags`、`group_id`、`input_text`、`source_ref`、`constraints` |
| `plan` | `applications`（每项含 `case_id, decision, reason, conditions_checked, exceptions_checked`）、`checks` |
| `draft` | `text`、`source_ref`、`actor:{name,context_id}` |
| `review` | `review_id`、`draft_sha256`、`reviewer:{name,role,mode,context_id}`、`verdict`、`findings`、`source_ref`；复查加 `rechecks` |
| `decide` | `review_id`、`decisions`（每项含 `finding_id,decision,reason`） |
| `revise` | `parent_sha256`、`text`、`source_ref`、`actor`、`review_id` |
| `finish` | 当前 `draft_sha256` |
| `stop` | `reason` |
| `author_accept` | 当前 `draft_sha256`、`quote`、`source_ref`；只记录接受证据，不改正文 |
| `learn` | `case_id`、`why`、`when`、`except`、`decisions`；可选 `split`（默认 development） |
| `case_status` | `case_id`、`status`（rejected/retired）、`reason` |

评审 `role` 是 writer/teacher/author；`mode` 是 self_check/independent_agent/human；`verdict` 是 pass/revise/blocked。问题含 `id,issue,evidence,scope`。通过不能同时列未解决问题。自查 mode 不能用 teacher/author 角色冒充外部认可；human 记录也只是对真实来源的声明，不是脚本验证了人类身份。

`conditions_checked` 用“条件原文→是否满足”的布尔映射，`exceptions_checked` 用“例外原文→是否命中”的映射，覆盖所选案例的每条条件和例外；也可用列出已检查原文的字符串数组，分别表示条件满足、例外未命中。条件不满足或例外命中时只能 `decline`。案例冻结后若被退役或换版，不能继续采用旧快照；说明原因并拒用，或停止后重开任务。改稿前须先取舍当前稿的每条问题，复查须覆盖这次修改涉及的全部评审，不能只覆盖其中一条而漏掉其他反馈。

## 停用与结果回流

`configure loop_enabled:false` 立即停用新循环，恢复原写作入口，保留历史和既有示范；`case_status` 拒绝或退役后示范立即不再检索。回退只撤回本模块的明确改动，不恢复整份旧故事状态。不要用失败试验覆盖原流程，也不要删除不利结果。

功能验证至少覆盖：旧 JSON 兼容、Markdown 非学习文字保留、错误项目/旧版本零写入、事件幂等、例外拒用、反馈与新稿绑定、返工上限、教师与作者状态分离、停用后正常原流程，以及一次宿主实际执行。写作质量是否改善另作同题对照，不能由功能测试推导。

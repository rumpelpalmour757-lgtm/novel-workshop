#!/usr/bin/env python3
"""r5.32: scene dramaturgy and embodiment (分场戏剧张力与正文具象化) as the default, under CON-011.

The author forwarded an implementation spec (the full version: 《novel-workshop (r5.29 -> r5.30) 完整升级规范：中观分场戏剧
张力与正文具象化模块》). A three-way blind comparison (two rounds, three tasks; maintenance records) found that the spec's
own text built the best scenes in all three tasks, at a cost in pressure or restraint in two of them, and that the
workshop's rewritten version never beat the previous release. With those results in front of them the author chose
"通用版默认就按规范" and approved the constitution amendment NWC-1.3: a new principle CON-011, one sentence added to
CON-009, and the heading "十一条原则". These tests pin what that decision put in place:

- the constitution text is the approved text, the registry knows CON-011 and every point it names exists;
- references/scene-dramaturgy.md carries the spec's module text (sections 1-3) and says how the workshop runs it;
  assets/scene-beat-card.md is the spec's card;
- the module is part of every whole-chapter writing task (SKILL.md, the gate card, the work card, the audit and review
  baselines, the dialogue checklist, the review template), and the rules it overrides were rewritten to yield to it;
- prose_lint.py runs floating-dialogue, tension-telling and weak-scene-ending by default; the author can turn one off
  for a book only with a reason;
- the delivery gate checks a declared beat card (filled, a real turn, frozen at start), refuses PASS for a flat scene
  or a scene scored below 3, and, in a task with a beat card, refuses to keep a scene-rule hit in the narration.
  (NWC-1.5, r5.34, approved by the author on 2026-10-23 after the r5.32 review: such a hit may now be kept with a
  reason of its own, and the four beats are for confrontations; the tests changed for that say so where they do.)
Whether chapters written this way read better is not something these tests can show; the comparison and its limits
are in the maintenance records (scene-dramaturgy-2026-10-22/eval).
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
MODULE = "references/scene-dramaturgy.md"
CARD = "assets/scene-beat-card.md"
LINT = SKILL / "scripts" / "prose_lint.py"
GUARD = SKILL / "scripts" / "workflow_guard.py"
SCENE_RULES = ("floating-dialogue", "tension-telling", "weak-scene-ending")


def read(relative):
    path = SKILL / relative
    return path.read_text(encoding="utf-8") if path.is_file() else ""


def section(text, heading):
    start = text.find("\n## " + heading)
    if start == -1:
        return ""
    end = text.find("\n## ", start + 4)
    return text[start:end if end != -1 else len(text)]


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def lint():
    return load(LINT, "r532_prose_lint")


def guard():
    return load(GUARD, "r532_guard")


def rules_of(report, rule=None):
    return [f["rule"] for f in report["findings"] if rule is None or f["rule"] == rule]


BARE = ["“你去不去？”", "“不去。”", "“为什么？”他问。", "“没空。”", "“那我自己去。”她说。"]


class Constitution(unittest.TestCase):
    """NWC-1.3: what the author approved on 2026-10-22, word for word where it matters."""

    def test_con011_is_the_approved_text(self):
        text = read("CONSTITUTION.md")
        part = text[text.index("### CON-011"):text.index("## 三、受控变更")]
        self.assertIn("### CON-011 分场张力与正文具象（硬，戏剧判断靠编辑）", part)
        for phrase in ("视角人物这一场必须拿到的具体结果、在场的主动阻力、失败当场的损失、开场和收场处境的方向性翻转",
                       # NWC-1.5 (r5.34): only a scene where nothing changes is compressed; the four beats are for
                       # confrontations; no scene ends on a summing-up.
                       "进场出场什么都没变的，才压成 100—200 字的过场，不扩成独立场景",
                       "不用“空气仿佛凝固”“心中五味杂陈”这类直述词替读者下结论",
                       "按四拍推进，晚进早出，停在翻转或新悬念出现的那一下", "哪一场都不写总结性的收尾",
                       "整章写作、整章重写和整章审稿。只润色、只改标点的任务不重排场景",
                       "作者对本书另有明确决定的（全知视角、有意的慢场景、直写情绪等），按作者的",
                       "已采纳的章节，查出的问题只标不改，改法交作者",
                       "重头对手戏开场 300 字内落下道具、过场 100—200 字、连续 5 段以上光台词要落地",
                       "不受 CON-009“指标只是线索”的限制",
                       "张力与代价、节奏里“不每章断章”的说法让位于本条",
                       "`polarity_shifted`、`prop_embodiment_score`"):
            self.assertIn(phrase, part)

    def test_version_heading_and_con009(self):
        text = read("CONSTITUTION.md")
        # r5.33: NWC-1.4 (2026-10-23, CON-012, approved by the author) replaced the version line and the heading; r5.34:
        # NWC-1.5 (CON-011 amended, approved by the author) replaced it again. Earlier entries stay in the record.
        # r5.35: NWC-1.6 (CON-012 amended) replaced the version line; the NWC-1.5 entry stays in the record.
        self.assertIn("版本：NWC-1.7（2026-11-01，作者批准 r5.49 修订方案（回复“按照你的想法去做”），按方案修订 CON-011：情绪的落点并列台词、选择、注意力、处境、内心、动作、生理反应和微动作、道具和感知，也可以留白，不同人物、不同场面不套同一种反应；NWC-1.6 在 2026-10-23 修订了 CON-012）", text)
        self.assertIn("NWC-1.5，2026-10-23（r5.34）", text)
        self.assertIn("## 二、十二条原则", text)
        self.assertNotIn("## 二、十条原则", text)
        self.assertNotIn("## 二、十一条原则", text)
        con009 = text[text.index("### CON-009"):text.index("### CON-010")]
        self.assertIn("不能为了指标机械改稿。尊重不同作品的节奏。分场写作里的几处数量要求按 CON-011 执行。", con009)
        self.assertIn("NWC-1.3，2026-10-22（r5.32）：作者转来一份分场规范，选定“通用版默认就按规范”，批准三处", text)

    def test_the_registry_knows_con011(self):
        registry = json.loads(read("assets/constitution-rules.json"))
        self.assertEqual((registry["version"], registry["date"]), ("NWC-1.7", "2026-11-01"))  # r5.49: NWC-1.7
        rule = next(r for r in registry["rules"] if r["id"] == "CON-011")
        self.assertEqual((rule["title"], rule["kind"]), ("分场张力与正文具象", "hard"))
        kinds = {ref["type"] for ref in rule["enforced_by"]}
        self.assertTrue({"doc", "script", "test"} <= kinds, kinds)
        files = {ref.get("file") for ref in rule["enforced_by"]}
        for name in ("novel-workshop/references/scene-dramaturgy.md", "novel-workshop/scripts/workflow_guard.py",
                     "novel-workshop/scripts/prose_lint.py"):
            self.assertIn(name, files)


class Module(unittest.TestCase):
    def test_the_spec_text_is_there(self):
        module = read(MODULE)
        for heading in ("## 1. 成场铁律：无冲突不立景 (No Conflict, No Scene)",
                        "## 2. 正文感转译：从“叙述总结”到“感官现场” (Summary-to-Scene Translation)",
                        "### 2.1 情绪生理化与微动作化", "### 2.2 强制道具锚点 (Mandatory Prop Anchor)",
                        "### 2.3 严格锁死 POV 感知边界", "### 2.4 对话的“错位回应”与潜台词",
                        "## 3. 场内博弈节拍 (Micro-Beats Progression)"):
            self.assertIn(heading, module)
        for phrase in ("必须压缩为 100~200 字以内的过场桥段", "入场欲望 (Immediate Goal)", "在场阻力 (Active Obstacle)",
                       "筹码与代价 (Stakes)", "极性翻转 (Polarity Turn)", "无效水戏（Flat Scene）",
                       "严禁直接使用“他感到一阵恐慌”", "陈默夹着烟的指尖顿在半空",
                       "每场重头对手戏必须在开场前 300 字内引入 **1~2 个可交互的具体物理道具**",
                       "禁止全知跳出透底", "拒绝直球审讯室问答", "剔除说明性台词 (No As-You-Know-Bob)",
                       "晚进早出（Late in, Early out）", "戛然而止（Early Out）", "“两人各自回家休息”"):
            self.assertIn(phrase, module)

    def test_how_the_workshop_runs_it(self):
        module = read(MODULE)
        head = module.split("## 1.")[0]
        for phrase in ("它是宪法 [CON-011](../CONSTITUTION.md) 的落点，整章写作、整章重写和整章审稿默认都按本页做",
                       "作者对本书另有明确决定的", "已采纳的章节，按本页查出的问题只标不改", "只润色、只改标点的任务不重排场景"):
            self.assertIn(phrase, head)
        part = section(module, "4. 在工坊里怎样执行")
        for phrase in ("`scene_beats`", "交付门在任务开始时冻结这张卡", "`floating-dialogue`", "`tension-telling`",
                       # NWC-1.5 (r5.34): a narration hit is rewritten or kept with a reason of its own.
                       "`weak-scene-ending`", "叙述里的命中逐处改写，或者逐处写明这一处的理由保留", "`in_quote`", "`polarity_shifted`",
                       "`prop_embodiment_score`", "[flat-scene]", "都不能记 PASS", "](../assets/scene-beat-card.md)",
                       "](stakes.md)", "](dialogue-craft.md)", "](prose-audit.md)"):
            self.assertIn(phrase, part)

    def test_the_source_is_recorded(self):
        module = read(MODULE)
        last = ([line for line in module.splitlines() if line.strip()] or [""])[-1]
        self.assertTrue(last.startswith("来源：作者 2026-10-22"), last)
        self.assertIn("第 1—3 节照录规范第三节的模块全文", last)
        self.assertIn("批准宪法 CON-011（NWC-1.3）", last)
        notes = read("assets/third-party/SOURCE-NOTES.md")
        row = next((line for line in notes.splitlines() if "](../../references/scene-dramaturgy.md)" in line), "")
        self.assertIn("作者选定按规范作为通用版的默认", row)
        self.assertIn("](../scene-beat-card.md)", row)


class BeatCard(unittest.TestCase):
    def test_the_card_is_the_spec_card(self):
        card = read(CARD)
        self.assertTrue(card.startswith("# Scene Beat Card (单场戏剧节拍卡)"))
        # NWC-1.5 (r5.34): the card gained the Other type and its Change field.
        for field in ("- **Scene ID / Chapter**:", "- **Scene Type**: `[Core Conflict (核心博弈戏) | Action/Crisis (动作危机戏) | "
                      "Other (其他场：兑现/靠近/停留/探索) | Transition (过场桥段-限200字)]`",
                      "- **POV Character & Sensory Limit (视角人物与感知盲区)**:", "- **Change (这一场变了什么)**:",
                      "- **Polarity Shift (局势极性变化)**: `[  ] -> [  ]`", "- **Core Prop Anchor (核心交互道具)**:",
                      "1. **入场动作与诉求 (Goal - Late In)**:", "2. **对手反制与阻碍 (Obstacle & Escalation)**:",
                      "3. **破局点/意外转折 (The Turn)**:", "4. **出场悬念钩子 (Exit Hook - Early Out)**:",
                      "- **禁止直接概括的过程**:", "- **潜台词冰山 (Subtext)**:", "- **情绪生理化映射 (Embodiment)**:"):
            self.assertIn(field, card)
        self.assertIn("一章几场，就把下面从 `Scene ID` 起的一块复制几份", card)
        self.assertIn("卡不交给作者，不附在正文后", card)

    def test_the_blank_card_does_not_pass(self):
        scenes, problems = guard().read_beat_card(read(CARD))
        self.assertTrue(problems)
        self.assertTrue(any("Scene ID is empty" in p for p in problems), problems)
        self.assertTrue(any("Scene Type" in p for p in problems), problems)


FILLED = """# Scene Beat Card (单场戏剧节拍卡)

- **Scene ID / Chapter**: S1 / 第七章
- **Scene Type**: `Core Conflict (核心博弈戏)`
- **POV Character & Sensory Limit (视角人物与感知盲区)**: 宋青；看不见柜台后面的账本
- **Polarity Shift (局势极性变化)**: `[求人] -> [欠人]` *(例：胜券在握 -> 被抓把柄，禁止填无变化)*
- **Core Prop Anchor (核心交互道具)**: 当票、车钥匙

## Four-Step Beat Map (四步博弈节拍)
1. **入场动作与诉求 (Goal - Late In)**: 拍下当票，要老范今天就把表还她
2. **对手反制与阻碍 (Obstacle & Escalation)**: 老范说五点关门，利息还差一半
3. **破局点/意外转折 (The Turn)**: 她把车钥匙押在柜台上
4. **出场悬念钩子 (Exit Hook - Early Out)**: 钥匙留在柜台上，她抱着表出门

## Anti-Summary Redlines (本场禁写红线)
- **禁止直接概括的过程**: 押钥匙那几句一步一步写
- **潜台词冰山 (Subtext)**: 谈利息，争的是谁求谁
- **情绪生理化映射 (Embodiment)**: 她把钥匙圈在指头上转了两圈才放下

- **Scene ID / Chapter**: S2 / 第七章
- **Scene Type**: Transition (过场桥段-限200字)
"""
CHAPTER = ("第七章　当铺\n\n宋青进门时，铁栅已经拉下一半。她把当票拍在柜台上。\n\n"
           "老范拨了一下算盘：“五点关门，利息还差一半。”\n\n她摸出车钥匙，在指头上转了两圈，押在当票上。\n\n"
           "老范把表从栅栏底下推出来，钥匙留在了柜台上。\n\n出了门，雨刚停，她把表揣进怀里往车站走。\n")


class Gate(unittest.TestCase):
    """The beat card check, the scene conclusions and the must-rewrite rule, run through workflow_guard.py."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.work = Path(self.tmp.name)
        self.events = 0

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, name, text):
        (self.work / name).write_bytes(text.encode("utf-8"))

    def run_guard(self, *args):
        proc = subprocess.run([sys.executable, "-I", "-B", str(GUARD), *map(str, args)], cwd=self.work,
                              capture_output=True, text=True, encoding="utf-8")
        try:
            return proc.returncode, json.loads(proc.stdout)
        except ValueError:
            return proc.returncode, {"raw": proc.stdout + proc.stderr}

    def project(self, card=FILLED, chapter=CHAPTER, beats=True, rules=None):
        self.write("draft.md", chapter)
        self.write("beats.md", card)
        prose = {"id": "prose", "type": "prose"}
        if rules is not None:
            self.write("rules.json", json.dumps(rules, ensure_ascii=False))
            prose["rules"] = "rules.json"
        checks = [prose]
        if beats:
            checks.append({"id": "beats", "type": "scene_beats", "source": "beats.md"})
        self.write("checks.json", json.dumps({"candidate": "draft.md", "checks": checks}))
        code, out = self.run_guard("start", "state.json", "--task-id", "ch7", "--spec", "checks.json")
        self.assertEqual(code, 0, out)
        return self.run_guard("check", "checks.json")

    def review(self, verdict="PASS", scenes=None, dispositions=(), issues=(), inputs=("beats.md",)):
        review = {"schema": "editorial-review/2", "verdict": verdict,
                  "candidate_sha256": hashlib.sha256((self.work / "draft.md").read_bytes()).hexdigest(),
                  "reviewer": {"mode": "self_check", "label": "测试数据：只验证结构"},
                  "checked_against": ["测试数据：节拍卡"], "inputs_read": list(inputs),
                  "evidence": [{"in": "candidate", "quote": "她把当票拍在柜台上"}],
                  "issues": list(issues), "counter_evidence": "测试数据，不是真实文学审稿。",
                  "machine_dispositions": [{"id": key, "decision": decision, "reason": "测试数据：逐处看过"}
                                           for key, decision in dispositions]}
        if scenes is not None:
            review["scenes"] = scenes
        self.write("review.json", json.dumps(review, ensure_ascii=False))
        self.events += 1
        return self.run_guard("record", "state.json", "--event-id", "r%d" % self.events, "--review", "review.json")

    @staticmethod
    def scene(key="S1", shifted=True, score=4):
        return {"id": key, "polarity_shifted": shifted, "prop_embodiment_score": score,
                "note": "求人到欠人，当票和车钥匙在柜台上推来推去"}

    def test_a_filled_card_passes(self):
        code, out = self.project()
        self.assertEqual(out["status"], "GREEN", out)
        beats = next(c for c in out["checks"] if c["id"] == "beats")
        self.assertEqual([(s["id"], s["type"]) for s in beats["actual"]["scenes"]], [("S1", "core"), ("S2", "transition")])
        self.assertEqual(beats["actual"]["scenes"][0]["polarity"], ["求人", "欠人"])

    def test_a_blank_or_flat_card_does_not(self):
        for bad, why in ((FILLED.replace("`[求人] -> [欠人]`", "`[求人] -> [求人]`"), "Polarity Shift"),
                         (FILLED.replace("`[求人] -> [欠人]`", "无变化"), "Polarity Shift"),
                         (FILLED.replace("当票、车钥匙", "*(本场用于承载情绪/动作的 1~2 个具体物理物品)*"), "Core Prop Anchor"),
                         (FILLED.replace("她把车钥匙押在柜台上", ""), "3 破局点"),
                         (read(CARD), "Scene ID is empty")):
            with self.subTest(why=why):
                self.tearDown()
                self.setUp()
                code, out = self.project(card=bad)
                self.assertEqual(out["status"], "RED", out)
                problems = next(c for c in out["checks"] if c["id"] == "beats")["actual"]["problems"]
                self.assertTrue(any(why in p for p in problems), problems)

    def test_the_card_is_frozen_when_the_task_starts(self):
        self.project()
        self.write("beats.md", FILLED.replace("她抱着表出门", "她把表退了回去"))
        code, out = self.run_guard("status", "state.json")
        self.assertEqual(out["gate"]["input_ready"], "BLOCKED", out["gate"])
        self.assertIn("changed: beats.md", out["gate"]["input_problems"])

    def test_pass_needs_every_planned_scene_turned_and_carried(self):
        self.project()
        code, out = self.review(scenes=None)
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertIn("S1", out["message"])
        for scenes, phrase in (([self.scene(shifted=False)], "flat scene"), ([self.scene(score=2)], "below 3"),
                               ([self.scene(), self.scene("S9")], "not on the beat card")):
            with self.subTest(phrase=phrase):
                code, out = self.review(scenes=scenes)
                self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
                self.assertIn(phrase, out["message"])
        code, out = self.review(scenes=[self.scene()])
        self.assertEqual(code, 0, out)
        code, status = self.run_guard("status", "state.json")
        self.assertEqual(status["gate"]["editorial"], "PASS[self_check]")

    def test_a_flat_scene_can_be_recorded_as_needing_revision(self):
        self.project()
        code, out = self.review(verdict="NEEDS_REVISION", scenes=[self.scene(shifted=False)],
                                issues=[{"quote": "她把当票拍在柜台上", "expected": "这一场要翻转", "impact": "flat-scene，打回重写"}])
        self.assertEqual(code, 0, out)

    def test_scene_rule_hits_in_the_narration_may_be_kept_with_a_reason(self):
        # Until r5.33 PASS refused to keep such a hit. NWC-1.5 (r5.34, approved by the author): the three checks are
        # literal hints; each hit is rewritten or kept with a reason of its own, and the reviewer judges the reason.
        code, out = self.project(chapter=CHAPTER.replace("出了门，雨刚停，", "出了门，空气仿佛凝固了，"))
        items = [(item["id"], item.get("rule"), item.get("in_quote")) for item in out["review_items"]]
        self.assertEqual([x[1] for x in items], ["tension-telling"], items)
        self.assertIs(items[0][2], False)
        code, out = self.review(scenes=[self.scene()], dispositions=[(items[0][0], "keep")])
        self.assertEqual(code, 0, out)

    def test_a_hit_in_a_characters_line_may_be_kept(self):
        code, out = self.project(chapter=CHAPTER.replace("“五点关门，利息还差一半。”", "“我这心里五味杂陈。五点关门，利息还差一半。”"))
        items = [(item["id"], item.get("in_quote")) for item in out["review_items"]]
        self.assertEqual([x[1] for x in items], [True], items)
        code, out = self.review(scenes=[self.scene()], dispositions=[(items[0][0], "keep")])
        self.assertEqual(code, 0, out)

    def test_a_polish_task_without_a_card_keeps_them_as_review_items(self):
        code, out = self.project(chapter=CHAPTER.replace("出了门，雨刚停，", "出了门，空气仿佛凝固了，"), beats=False)
        items = [item["id"] for item in out["review_items"]]
        self.assertEqual(len(items), 1)
        code, out = self.review(dispositions=[(items[0], "keep")], inputs=())
        self.assertEqual(code, 0, out)

    def test_the_authors_exemption_goes_into_the_rules_file(self):
        code, out = self.project(chapter=CHAPTER.replace("出了门，雨刚停，", "出了门，空气仿佛凝固了，"),
                                 rules={"off": [{"rule": "tension-telling", "reason": "作者：本书允许直写氛围"}]})
        self.assertEqual(out["review_items"], [])


class DefaultFlow(unittest.TestCase):
    """The module is part of every whole-chapter writing task."""

    def test_skill_reads_it_for_every_whole_chapter_task(self):
        level = next(line for line in read("SKILL.md").splitlines() if line.startswith("| L1 整章 |"))
        self.assertIn("写或重写整章时读 [分场戏剧张力与正文具象化](references/scene-dramaturgy.md) 全文，落笔前按 "
                      "[分场节拍卡](assets/scene-beat-card.md) 对齐四步节拍与道具锚点（CON-011）", level)
        self.assertIn("检查清单声明 `scene_beats`（节拍卡），审稿记录写 `scenes`", level)
        self.assertIn("`prose_lint.py` 三项分场检测在叙述里的命中逐处改写或写明理由保留", level)  # NWC-1.5, r5.34
        rows = [line for line in read("SKILL.md").splitlines()
                if line.startswith("| ") and "(references/scene-dramaturgy.md)" in line and not line.startswith("| L1 整章 |")]
        self.assertEqual(len(rows), 1)
        for word in ("精修过的流水账", "进场和出场处境一样", "脱离物理空间", "空气仿佛凝固", "整章写作和重写默认都读"):
            self.assertIn(word, rows[0])

    def test_the_gate_card_carries_it_within_its_budget(self):
        card = read("assets/delivery-gate-card.md")
        self.assertLessEqual(len(card.encode("utf-8")), 5004)

        def item(number):
            return next(line for line in card.splitlines() if line.startswith("%d. **" % number))
        self.assertIn("写或重写读分场模块、先填节拍卡", item(1))
        # r5.48: the one route (physiological reactions) became a choice by the scene, and a stock reaction is no fix.
        self.assertIn("情绪直述按这一场选写法（见改稿卡），换成现成反应不算改好，它出现一次也要看", item(4))
        self.assertIn("写或重写另写 scenes，没翻转或低于 3 分不能 PASS；分场检测的命中逐处改或写理由", item(9))  # NWC-1.5

    def test_drafting_audit_and_review_carry_it(self):
        drafting = read("references/drafting.md")
        for phrase in ("先填 [分场节拍卡](../assets/scene-beat-card.md)，对齐四步戏剧节拍与道具锚点，再生成正文（CON-011）",
                       "坚持晚进早出（Late in, Early out）", "每场重头对手戏开场 300 字内建立感官与道具锚点",
                       "不写连续多段脱离物理动作的纯对话（Talking Heads）", "场景和章末不写总结性陈词",
                       # NWC-1.5 (r5.34): only a scene with no obstacle and no change is compressed.
                       "没有在场阻力、也没有什么变化的，压成 100—200 字的过场", "高压过后可以用 100—200 字的过场放松片刻"):
            self.assertIn(phrase, drafting)
        audit = section(read("references/prose-audit.md"), "场景戏剧张力与具象化（Scene Dramaturgy & Embodiment）")
        for mark in ("`[flat-scene]`", "`[floating-dialogue]`", "`[tension-telling]`", "`prop_embodiment_score`"):
            self.assertIn(mark, audit)
        baseline = section(read("references/adversarial-review.md"), "内置审稿基准")
        self.assertIn("进场和出场的处境有没有方向性翻转（没有就是 [flat-scene]", baseline)
        self.assertIn("重头对手戏开场 300 字内有没有可交互的道具", baseline)
        checklist = read("assets/sentence-dialogue-checklist.md")
        self.assertIn("连着 5 段以上的对白，中间有没有落到人物的动作、位置或手上的道具上", checklist)
        self.assertIn("对手戏里一方抛出尖锐问题或施压时，另一方是不是顺从地直接回答", checklist)
        template = json.loads(read("assets/editorial-review-template.json"))
        self.assertEqual(set(template["scenes"][0]), {"id", "polarity_shifted", "prop_embodiment_score", "note"})
        self.assertIn("scenes 是分场结论", template["note"])
        self.assertIn("**分场结论。**", read("references/quality-loop.md"))
        self.assertIn("| `scene_beats` | `source`（这一章的节拍卡", read("references/execution.md"))

    def test_the_rules_it_overrides_yield(self):
        stakes, pacing, planning = read("references/stakes.md"), read("references/pacing.md"), read("references/planning.md")
        for text in (stakes, pacing, planning, read("SKILL.md")):
            for phrase in ("不每章断章", "不把每章改成悬崖", "不强制断章", "不强制每章悬崖式断章", "把每章都改成悬崖式断章"):
                self.assertNotIn(phrase, text)
        # NWC-1.5 (r5.34): the stop at the turn is for confrontations; other scenes end where their change lands.
        self.assertIn("章末那一场是对手戏的，按 [分场戏剧张力与正文具象化](scene-dramaturgy.md) 停在翻转或新悬念出现的那一下（CON-011）", stakes)
        self.assertIn("对手戏、冲突戏（章末那一场也是）停在翻转的最高点或新悬念出现的那一下", pacing)
        self.assertNotIn("情绪直写是可选择的表达", read("references/prose-audit.md"))
        self.assertNotIn("不能被动作准确表达的情绪可直接写", read("references/sentence-craft.md"))
        self.assertNotIn("情绪可以直写", read("references/short-fiction.md"))
        self.assertIn("对手戏里一方抛出尖锐问题或施压时，另一方不顺从地直接回答", read("references/dialogue-craft.md"))
        self.assertIn("施压之外，直白真诚同样有效", read("references/dialogue-craft.md"))

    def test_the_sale_export_carries_both_files(self):
        exporter = load(SKILL / "scripts" / "export_portable.py", "r532_export")
        self.assertIn(MODULE, set(exporter.SALE_FILES))
        self.assertIn(CARD, set(exporter.SALE_FILES))
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "sale.zip"
            proc = subprocess.run([sys.executable, "-I", "-B", str(SKILL / "scripts" / "export_portable.py"), str(target),
                                   "--mode", "sale"], capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
            with zipfile.ZipFile(target) as archive:
                portable = archive.read("portable-novel-workshop.md").decode("utf-8")
            self.assertIn("## 1. 成场铁律：无冲突不立景", portable)
            self.assertIn("# Scene Beat Card (单场戏剧节拍卡)", portable)


class SceneRulesByDefault(unittest.TestCase):
    TEXT = "\n\n".join(BARE + ["空气仿佛凝固了。他指节泛白。", "他知道，一切才刚刚开始。"]) + "\n"

    def test_the_three_rules_run_by_default_and_stock_reaction_does_not(self):
        report = lint().inspect_text(self.TEXT)
        # r5.33: the four language scans of the five revision passes (references/revision-passes.md) run by default too.
        self.assertEqual(report["checks_run"], ["placeholder", "repeated-paragraph"] + list(SCENE_RULES)
                         + ["frequent-words", "negation-ending", "parallel-run", "list-of-three"])
        self.assertEqual(sorted(set(rules_of(report))), sorted(SCENE_RULES))
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "draft.md"
            path.write_bytes(self.TEXT.encode("utf-8"))
            run = lambda *extra: json.loads(subprocess.run([sys.executable, "-I", "-B", str(LINT), str(path), *extra],
                                                           capture_output=True, text=True, encoding="utf-8").stdout)
            self.assertEqual(sorted(set(rules_of(run()))), sorted(SCENE_RULES))
            self.assertIn("stock-reaction", rules_of(run("--hint", "stock-reaction")))

    def test_without_the_scene_rules_the_report_is_the_old_one(self):
        report = lint().inspect_text(self.TEXT, None, "blank", (), False)
        self.assertEqual((report["status"], report["checks_run"]), ("NO_FLAGS", ["placeholder", "repeated-paragraph"]))

    def test_only_the_author_turns_one_off_and_says_why(self):
        checker = lint()
        report = checker.inspect_text(self.TEXT, {"off": [{"rule": "tension-telling", "reason": "作者：本书允许直写"}]})
        self.assertNotIn("tension-telling", report["checks_run"])
        self.assertEqual(report["turned_off"], [{"rule": "tension-telling", "reason": "作者：本书允许直写"}])
        for rules in ({"off": ["tension-telling"]}, {"off": [{"rule": "tension-telling"}]},
                      {"off": [{"rule": "tension-telling", "reason": " "}]}, {"off": [{"rule": "stock-reaction", "reason": "x"}]},
                      {"off": [{"rule": "tension-telling", "reason": "x"}], "hints": ["tension-telling"]},
                      {"hints": ["nope"]}, {"terms": [{"id": "floating-dialogue", "text": "x", "min_occurrences": 1}]}):
            with self.assertRaises(ValueError, msg=rules):
                checker.inspect_text(self.TEXT, rules)

    def test_validate_rules_still_returns_two_values(self):
        terms, ignores = lint().validate_rules({"terms": [], "ignore": [], "hints": ["stock-reaction"]})
        self.assertEqual((terms, ignores), ([], []))

    def test_an_exemption_names_the_rule(self):
        rules = {"ignore": [{"rule": "floating-dialogue", "line": 1, "text": BARE[0], "reason": "作者要这段抢白连着走"}]}
        report = lint().inspect_text("\n\n".join(BARE) + "\n", rules)
        self.assertEqual(report["findings"], [])
        self.assertEqual([s["rule"] for s in report["suppressed"]], ["floating-dialogue"])


class Words(unittest.TestCase):
    def test_the_specs_telling_words(self):
        checker = lint()
        for phrase in ("气氛顿时紧张起来", "气氛一下子凝固", "空气仿佛凝固了", "空气死一般寂静", "两人之间火药味十足",
                       "剑拔弩张的气氛", "压抑的气氛蔓延开来", "心中五味杂陈", "内心掀起惊涛骇浪", "感到一阵莫名的恐慌",
                       "他感到一阵恐慌", "心中百感交集", "各怀鬼胎", "两人聊了很久", "经过一番苦战"):
            report = checker.inspect_text("他看着门。%s。\n\n门开了。\n" % phrase)
            self.assertIn("tension-telling", rules_of(report), phrase)
        self.assertEqual(rules_of(checker.inspect_text("屋里有火药味，窗开着。\n\n门开了。\n")), [])

    def test_the_specs_deflating_endings(self):
        checker = lint()
        for phrase in ("他知道一切才刚刚开始", "暴风雨即将来临", "两人不欢而散", "各自回房休息", "两人各自回家休息",
                       "经过这次交谈，他明白了一个道理"):
            text = "他推门出去。\n\n街上没有人。%s。\n" % phrase
            self.assertIn("weak-scene-ending", rules_of(checker.inspect_text(text)), phrase)
            early = "%s。\n\n他推门出去。\n\n街上没有人。\n\n车还停着。\n" % phrase
            self.assertNotIn("weak-scene-ending", rules_of(checker.inspect_text(early)), phrase)
        self.assertEqual(rules_of(checker.inspect_text("他推门出去。\n\n雨这才开始下。\n")), [])
        # A line of break marks ends a scene: the two paragraphs before it are a scene's ending too.
        broken = "他说，这只是开始。\n\n门关上了。\n\n※※※\n\n天亮了。\n\n车还停着。\n"
        self.assertEqual([(f["rule"], f["line"]) for f in checker.inspect_text(broken)["findings"]],
                         [("weak-scene-ending", 1)])

    def test_a_label_in_a_characters_line_is_marked(self):
        finding = lint().inspect_text("“我心里五味杂陈。”她说。\n")["findings"][0]
        self.assertTrue(finding["in_quote"])
        self.assertIn("是人物自己的口吻就保留", finding["message"])
        outside = lint().inspect_text("她心里五味杂陈。\n")["findings"][0]
        self.assertFalse(outside["in_quote"])
        self.assertIn("CON-011", outside["message"])


class FloatingDialogue(unittest.TestCase):
    def run_hint(self, paragraphs, mode="blank"):
        joiner = "\n\n" if mode == "blank" else "\n"
        return rules_of(lint().inspect_text(joiner.join(paragraphs) + "\n", None, mode), "floating-dialogue")

    def test_five_bare_lines_in_a_row(self):
        report = lint().inspect_text("\n\n".join(BARE) + "\n")
        finding = next(f for f in report["findings"] if f["rule"] == "floating-dialogue")
        self.assertEqual((finding["line"], finding["paragraphs"], finding["last_line"]), (1, 5, 9))

    def test_four_are_not_enough_and_an_action_breaks_the_run(self):
        self.assertEqual(self.run_hint(BARE[:4]), [])
        self.assertEqual(self.run_hint(BARE[:2] + ["她把伞立在门边：“为什么？”"] + BARE[3:]), [])
        self.assertEqual(self.run_hint(BARE[:2] + ["门外的雨下大了。"] + BARE[2:]), [])
        self.assertEqual(self.run_hint(BARE[:2] + ["“为什么？”他把伞靠在门边，回头问。"] + BARE[3:]), [])

    def test_only_a_speaker_and_a_speech_verb_count_as_bare(self):
        self.assertEqual(self.run_hint(["“走吗？”老周冷笑。"] + BARE[1:]), ["floating-dialogue"])
        self.assertEqual(self.run_hint(["“走吗？”他握住钥匙。"] + BARE[1:]), [])

    def test_the_paragraph_mode_decides_what_a_paragraph_is(self):
        self.assertEqual(self.run_hint(BARE, "line"), ["floating-dialogue"])
        self.assertEqual(rules_of(lint().inspect_text("\n".join(BARE) + "\n", None, "blank"), "floating-dialogue"), [])


if __name__ == "__main__":
    unittest.main()

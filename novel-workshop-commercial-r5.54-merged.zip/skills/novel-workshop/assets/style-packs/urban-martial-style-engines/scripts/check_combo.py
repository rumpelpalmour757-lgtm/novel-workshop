#!/usr/bin/env python3
"""检查一次写作要加载的引擎能否同时用，排好槽位，并列出要读的文件。

一次写作 = 一场或一章：最多3个引擎全文，一槽一个——
槽1人物底色（L1或L4）、槽2战斗物理（L3）、槽3副本规则（L2或L4）。
本书锁定的L1用 --book 或 --profile 传入：它们的身份锁每次都带上，不占槽。
用法：
  python scripts/check_combo.py 21 02 50 --book 06
  python scripts/check_combo.py 21 02 50 --profile ../本书设定.yaml
  python scripts/check_combo.py --recipe 寒门开局
  python scripts/check_combo.py --profile ../本书设定.yaml --volume 2   # 按设定档第2卷的配方
  python scripts/check_combo.py --list          # 全部引擎；也可 --list L3
退出码：0 可以加载；1 有问题。只用标准库；--profile 需要 PyYAML。
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import E, R, SLOTS, SLOT_KEYS, check, expand_recipe, expand_volume, label, load_profile, norm  # noqa: E402


def show_alts(alts, note, note_name):
    for s, rest in alts.items():
        if rest:
            print(f"{SLOTS[s]['name']}可换：{'、'.join(map(label, rest))}")
    if note:
        print(f"{note_name}：{note}")


def listing(layer):
    for lay in ("L1", "L2", "L3", "L4"):
        if layer not in ("ALL", lay):
            continue
        print(f"\n{lay}")
        for n, e in E.items():
            if e["layer"] == lay:
                tags = f"［{'、'.join(e['tags'])}］" if e.get("tags") else ""
                print(f"  {n} {e['name']}（{e['group']}）{tags}—— {e['load_when']}")
    print("\n配方：" + "、".join(R["recipes"]))


def main():
    ap = argparse.ArgumentParser(description="检查引擎组合")
    ap.add_argument("nums", nargs="*", help="本次加载的引擎编号，最多3个")
    ap.add_argument("--book", nargs="*", default=[], help="本书锁定的L1（1主+1副）")
    ap.add_argument("--profile", help="本书设定档，取其中的 L1")
    ap.add_argument("--volume", type=int, help="按设定档 volumes 的第几卷取引擎（从1数）")
    ap.add_argument("--recipe", help="配方名，如 寒门开局")
    ap.add_argument("--list", nargs="?", const="ALL", help="列出引擎，可加层级 L1–L4")
    args = ap.parse_args()
    if args.list:
        return listing(args.list.upper())

    nums = [norm(n) for n in args.nums]
    book = [norm(n) for n in args.book]
    prof = load_profile(args.profile) if args.profile else {}
    book += prof.get("L1", [])
    if args.volume:
        if not prof:
            sys.exit("--volume 要和 --profile 一起用")
        v_nums, alts, note, vname = expand_volume(prof, args.volume)
        nums += v_nums
        print(f"按{vname}取引擎")
        show_alts(alts, note, "本卷说明")
    if args.recipe:
        r_nums, r_book, alts, note = expand_recipe(args.recipe)
        nums += r_nums
        if book and r_book and set(r_book) - set(book):
            print(f"配方建议的本书L1是{'、'.join(map(label, r_book))}；本书已锁定{'、'.join(map(label, book))}，按本书")
        elif not book:
            book = r_book
        show_alts(alts, note, "配方说明")

    nums, book, slots, problems, notes = check(nums, book)
    if book:
        print("本书L1：" + "、".join(map(label, book)))
    print("槽位：")
    for s in SLOT_KEYS:
        n = slots[s]
        print(f"  {SLOTS[s]['name']}：{label(n) if n else '（空）'}")
    print("要读的文件：")
    ordered = [slots[s] for s in SLOT_KEYS if slots[s]] + [n for n in nums if n not in slots.values()]
    for f in ["references/L0_core.yaml", "references/router.yaml"] + [E[n]["file"] for n in ordered]:
        print(f"  {f}")
    for x in notes:
        print(f"提示：{x}")
    for x in problems:
        print(f"问题：{x}")
    print("结论：" + ("有问题，先调整组合。" if problems else "可以加载。"))
    sys.exit(1 if problems else 0)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""r5.60: the technique card is read at three times, and the pages around it say how a card is used.

What was decided (the decisions are in the maintenance records, outside the package; none of the author's words are
quoted here). Most of it the author decided; a few follow-up details were written first on the maker's proposal, the
author was told and has not objected, and they stay open to the author's change. Two of them are about a request for
the text alone: one sentence outside the text still names a narrowed card, and the author has since approved that
exception; one still names a card the author has not seen or has seen and not decided on, and there the author's
answer was to go by the advice given, which was to leave it as written.

- A card has an upper half, a lower half and a block at the bottom. The upper half is read when a card is picked, when
  a scene is drafted and when the scene is checked afterwards; each of the three times reads its own columns. The
  lower half (evidence, trial writes, relation to the modules) is read when a card is made, changed or reviewed. The
  bottom block records how the card did in this book.
- Drafting reads the positive columns only. Where the card fails, what overuse looks like and what must not be taken
  from the original are not read while drafting; one fixed sentence stands in for the last of these.
- At most two cards for one scene.
- A card can be stored first as a candidate ("候选，没试写") with seven columns; it is not used for prose until the
  three trial writes are done and the workshop judges it usable.
- A change that only narrows (one more case under "失效情境" or "用过头的样子", the four method columns untouched) is
  tested on the new case only and keeps the author's adoption; the author is told at the next delivery, also when the
  author asked for the text alone, and the change is withdrawn if the author disagrees. Any other change is as before.
- Two more states, "归档" and "收进了规矩", set only when the author decides card by card.
- The index carries the head's columns, and the page on the technique library says how a scene uses cards. The
  drafting page, the beat card, the delivery note and the consolidation step have their own test file.
- The chain column asks for a last link that can be seen (who learned what, who got or lost what, what was said
  and cannot be taken back). A card that can only name a mood or an atmosphere says so under "失效情境": that
  column is read when a card is picked, the chain column is not. The author approved adding the sentence on
  2026-11-26; its second half was reworded to name that column.

These tests check that the structure and the sentences are there. They do not show that taking a reference apart, or writing with a card, gets any better: the template
has not been used on a real reference yet.
"""
import os
from pathlib import Path
import re
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
REFS = SKILL / "references"
ASSETS = SKILL / "assets"
CARD = ASSETS / "technique-card-template.md"
PAGE = REFS / "deconstruction-library.md"
STUDY = REFS / "reference-study.md"
NOTES = ASSETS / "third-party" / "SOURCE-NOTES.md"
# The sentence added to the chain column, the sentence before it, the sentences after it, and the column its
# second half names.
CHAIN_BEFORE = "- **作用链**：原先的处境或期待 → 触发 → 人物的选择或回应 → 信息、关系、情绪或局势的变化。"
CHAIN_NOTE_COLUMN = "失效情境"
CHAIN_SENTENCE = ("末一环写成一件看得见的事：谁知道了什么，谁拿到或丢了什么，哪句话说出口收不回了。"
                  "只写得出情绪或气氛的，在“" + CHAIN_NOTE_COLUMN + "”里注明“这一手不推剧情”，挑卡时读得到。")
CHAIN_AFTER = "用自己的话写，不复述情节：读起来像“这一章他先……然后……”，就是在复述剧情，重写。不能空。"

HALVES = ["上半：挑卡、起草、写完自查时读这一半", "下半：建卡、改卡、复盘时读这一半", "本书适配与使用记录"]
UPPER = ["卡头", "做法", "对白另填（这张卡管对白时）", "场景另填（这张卡管场景时）",
         "失效情境、用过头的样子、不可搬用的（起草时不读）"]
LOWER = ["先存成候选卡", "来源证据", "另填里原作的情形", "可替换的", "反例与局限",
         "新写的演示（对白另填，这张卡管对白时）", "留卡前试写（工坊自己写几句）", "和工坊已有模块的关系", "改卡分轻重"]
BOTTOM = ["另填里要照本书答的两栏（起草时也读）", "工坊的判断、本书试用、作者采纳（三件事分开记）", "用过以后的问题"]
# What a drafter reads: the head, the method, the two optional parts, and the two columns answered for this book.
READ_WHEN_DRAFTING = UPPER[:4] + BOTTOM[:1]
NOT_READ_WHEN_DRAFTING = UPPER[4]


def read(path):
    return path.read_text(encoding="utf-8") if path.is_file() else ""


def half(text, heading):
    """The body under a '## ' heading, up to the next '## ' heading ("" if there is none)."""
    match = re.search(r"(?ms)^## " + re.escape(heading) + r"\n(.*?)(?=^## |\Z)", text)
    return match.group(1) if match else ""


def part(text, heading):
    """The body under a '### ' heading, up to the next '## ' or '### ' heading ("" if there is none)."""
    match = re.search(r"(?ms)^### " + re.escape(heading) + r"\n(.*?)(?=^#{2,3} |\Z)", text)
    return match.group(1) if match else ""


def bullet(text, start):
    """The one line that starts with start ("" if there is none, or more than one)."""
    found = [line for line in text.splitlines() if line.startswith(start)]
    return found[0] if len(found) == 1 else ""


class ThreeTimes(unittest.TestCase):
    def setUp(self):
        self.text = read(CARD)
        self.opening = half(self.text, HALVES[0]).split("\n### ", 1)[0]

    def test_two_halves_and_a_block_at_the_bottom(self):
        self.assertEqual(re.findall(r"(?m)^## (.+)$", self.text), HALVES)
        for heading, parts in zip(HALVES, (UPPER, LOWER, BOTTOM)):
            self.assertEqual(re.findall(r"(?m)^### (.+)$", half(self.text, heading)), parts, heading)
        top = self.text.split("\n## ", 1)[0]
        for phrase in ("一张卡上下两半，最底下另有一块：", "挑卡、起草、写完自查时读，每个时候读哪几栏见上半开头",
                       "下半是来源证据、留卡前试写、和工坊已有模块的关系这些，建卡、改卡、复盘时读",
                       "最底下一块是本书适配与使用记录，记这张卡在本书用得怎样",
                       "跨作品用仍要作者明说，见最底下一块"):
            self.assertIn(phrase, top)

    def test_each_time_reads_its_own_columns(self):
        self.assertIn("这一半分三个时候读。", self.opening)
        pick = bullet(self.opening, "- 挑卡的时候，")
        for phrase in ("先看卡头的状态和工坊的判断，再读“什么时候拿出来用”“失效情境”",
                       "一场最多用两张，挑最对的；其余命中的只在节拍卡上记一笔，不读进起草",
                       # the author's later decision: a card the author declined or withdrew is not picked
                       "也看最底下一块“作者采纳状态”一栏：作者说过不要、或者撤回过采纳的卡不挑，工坊的判断是“可用”也不挑；"
                       "作者以后又明说要用的，照作者新的话办。",
                       "这一栏是“没给作者看”或“作者看过、没定”的，工坊的判断是“可用”的可以拿来写；"
                       "交稿时照样在正文外说明这一场用了哪张、第几版、为什么（照“本书试用”一栏），列给作者看不算作者采纳。"):
            self.assertIn(phrase, pick)
        draft = bullet(self.opening, "- 起草的时候，")
        for phrase in ("读卡头、做法和两块另填，加最底下一块的“另填里要照本书答的两栏”",
                       "另读一句固定的话：“不搬原作的人物、台词和桥段。”",
                       "这一半末尾的三栏（失效情境、用过头的样子、不可搬用的）不读；下半的栏也不读"):
            self.assertIn(phrase, draft)
        check = bullet(self.opening, "- 写完自查的时候，")
        for phrase in ("拿“用过头的样子”核一遍，再对着“不可搬用的”整栏看有没有搬原作的东西",
                       "也看作用链在这一场走到没有", "不为了走到硬补",
                       "“本书试用”不记成“写进了草稿”，照实写这一场作用链没走到",
                       "“用过以后的问题”里也记一条，写明是工坊自查查出的",
                       "这一步只核有没有照做，不判写得好不好"):
            self.assertIn(phrase, check)
        for phrase in ("起草、改写都只用工坊的判断是“可用”的卡", "只作参考、待核的不拿来写正文",
                       "状态是“候选，没试写”的还没判成“可用”，也不拿来写正文", "改写照起草的读法读卡",
                       "填卡的人留意：起草时读的栏里写关系、处境和条件，原作的人和事写在下半。"):
            self.assertIn(phrase, self.opening)

    def test_the_columns_drafting_does_not_read_sit_apart(self):
        apart = part(self.text, NOT_READ_WHEN_DRAFTING)
        fields = re.findall(r"(?m)^- \*\*(.+?)\*\*", apart)
        self.assertEqual(fields, ["失效情境", "用过头的样子", "不可搬用的"])
        for phrase in ("“失效情境”挑卡时读，写完自查时作用链没走到的也回头看",
                       "“用过头的样子”“不可搬用的”写完自查时对照", "起草时只读上半开头那一句固定的话"):
            self.assertIn(phrase, apart)
        # The parts a drafter reads hold none of the three columns, nothing of the original, no counter-example and
        # no demonstration; what they need of the original is in the lower half.
        for heading in READ_WHEN_DRAFTING:
            body = part(self.text, heading)
            self.assertTrue(body, heading)
            for name in ("**失效情境**", "**用过头的样子**", "**不可搬用的**", "**新写的演示**",
                         "**原作里没起作用的地方**", "**可替换的**", "**这部参考自己的局限**",
                         "原作里用这手法的是什么营生", "原作靠什么物件、光、声响撑着", "原作在这一处展开还是压缩"):
                self.assertNotIn(name, body, (heading, name))
        original = part(self.text, "另填里原作的情形")
        self.assertEqual(re.findall(r"(?m)^- \*\*(.+?)\*\*", original), ["跟着什么样的人", "东西和感知", "详略"])
        for phrase in ("原作里用这手法的是什么营生、脾气、文化层的人，此刻什么处境。", "原作靠什么物件、光、声响撑着。",
                       "原作在这一处展开还是压缩、为什么。", "起草时不读"):
            self.assertIn(phrase, original)
        book = part(self.text, BOTTOM[0])
        self.assertEqual(re.findall(r"(?m)^- \*\*(.+?)\*\*", book), ["跟着什么样的人", "详略"])
        for phrase in ("换成本书的谁，词和口气要改哪些。", "本书这一处该不该同样展开。", "不写“同原作”"):
            self.assertIn(phrase, book)
        lower = half(self.text, HALVES[1])
        self.assertIn("建卡、改卡、复盘时读这一半；挑卡、起草、写完自查时都不读。", lower)
        for name in ("**新写的演示**", "**原作里没起作用的地方**", "**可替换的**", "**这部参考自己的局限**"):
            self.assertIn(name, lower)

    def test_the_method_comes_before_the_evidence_only_in_reading(self):
        # The page is ordered by when a column is read; a card is still filled from the evidence first.
        self.assertEqual(re.findall(r"(?m)^- \*\*(.+?)\*\*", part(self.text, "做法")),
                         ["什么时候拿出来用", "作用链", "成立条件", "在本书怎样重新实现"])
        self.assertIn("先填来源证据，再填上半的做法和两块另填", half(self.text, HALVES[1]))
        # The chain column: the added sentence stands once, between the sentences that were there, and the column
        # still ends by saying it cannot stay empty.
        self.assertEqual(bullet(part(self.text, "做法"), "- **作用链**："), CHAIN_BEFORE + CHAIN_SENTENCE + CHAIN_AFTER)
        self.assertEqual(self.text.count(CHAIN_SENTENCE), 1)
        # The note for a card that only reaches a mood goes where the picking step reads: that step reads the
        # column the sentence names, and it does not read the chain column.
        pick = bullet(self.opening, "- 挑卡的时候，")
        self.assertIn("“" + CHAIN_NOTE_COLUMN + "”", pick.split("。", 1)[0])
        self.assertNotIn("作用链", pick)
        # the single-file version is built from the template and carries the sentence too
        self.assertIn(CHAIN_SENTENCE, read(ROOT / "portable-novel-workshop.md"))


class TheHead(unittest.TestCase):
    def setUp(self):
        self.text = read(CARD)
        self.head = part(self.text, "卡头")

    def test_the_head_columns(self):
        self.assertEqual(re.findall(r"(?m)^- \*\*(.+?)\*\*", self.head),
                         ["编号与修订号", "卡的状态", "技法名和一句话做法", "管哪一样", "检索标签", "工坊的判断、和模块的关系"])

    def test_the_states(self):
        state = bullet(self.head, "- **卡的状态**：")
        for phrase in ("**卡的状态**：候选，没试写／在用／被取代（被哪一张、从哪天起）／并进了别的卡／拆开了／"
                       "归档（哪天、作者的原话）／收进了规矩（哪天、作者的原话、收进了哪一处）。",
                       "一次填全的新卡写“在用”。", "“在用”只说这张卡没被取代、没归档这些，能不能拿来写正文，看工坊的判断。",
                       "先存成候选卡的，写“候选，没试写”，不拿来写正文，起草、改写都一样",
                       "补了三样试写以后，状态改成“在用”（见下半“先存成候选卡”）；",
                       "补完以后工坊的判断不是“可用”的也写“在用”，仍不拿来写正文。",
                       "归档、收进了规矩这两种，作者逐张定了才改",
                       "这两种卡挑卡时都不挑，查旧章的依据时还查得到。", "旧卡不删"):
            self.assertIn(phrase, state)

    def test_a_fourth_kind_and_tags_from_the_card_s_own_categories(self):
        kind = bullet(self.head, "- **管哪一样**：")
        for phrase in ("**管哪一样**：对白／场景／两样都管／叙述和描写（动作、体感、描写顺序这类）。",
                       "管叙述和描写的，对白另填不填，场景另填只填“视角”“东西和感知”两栏",
                       "一处写法既管叙述描写、又管对白或场景的，照对白或场景那一类选"):
            self.assertIn(phrase, kind)
        tags = self.head.split("- **检索标签**：", 1)[1].split("\n- **", 1)[0]
        for phrase in ("筛出来的卡仍要读“什么时候拿出来用”，标签对上了不等于这一场该用",
                       "只用这张卡里已有的分类，不另起，拿不准的写“不确定”",
                       "其他场写明是兑现、靠近、停留、探索里的哪一种", "管叙述和描写的，这一栏空着"):
            self.assertIn(phrase, tags)
        # every tag value is a category one of the two optional parts already has
        dialogue, scene = part(self.text, UPPER[2]), part(self.text, UPPER[3])
        for value, home in (("句内", dialogue), ("来回", dialogue), ("被逼问", dialogue),
                            ("核心博弈戏／动作危机戏／其他场", scene), ("兑现、靠近、停留、探索", scene),
                            ("入场、受阻加码、翻转、收尾", scene), ("下一场开头", scene), ("其他场里的那一下变化", scene)):
            self.assertIn(value, tags, value)
            self.assertIn(value, home, value)

    def test_the_head_copies_the_judgement_and_the_relation(self):
        copied = bullet(self.head, "- **工坊的判断、和模块的关系**：")
        for phrase in ("可用／只作参考／待核", "同样（模块里已经有同样的做法）／多一样（多一个条件或一个例子）／"
                       "不一样（和模块说法不一样）／没有（模块里没有）", "“不一样”的，作者定以前照模块办",
                       "“没有”的，提给作者时说明这是模块外的做法", "那两栏还空着的，这两项也空着"):
            self.assertIn(phrase, copied)


class CandidateFirst(unittest.TestCase):
    def test_seven_columns_and_the_same_threshold(self):
        text = read(CARD)
        first = part(text, "先存成候选卡")
        for phrase in ("建卡可以一次填全，也可以先存成候选卡。",
                       "至少填七栏：定位和短引、技法名和一句话做法、作用链、什么时候拿出来用、失效情境、来源记录、不可搬用的",
                       "编号、管哪一样、检索标签也在存的时候一起填；卡的状态写“候选，没试写”",
                       "（“原文写了什么，我读出来什么”“对应的模块和节”“工坊的判断”），可以先空着，升“可用”以前补上",
                       "只有作者要求建库或项目已授权维护时才保存",
                       "候选的卡不拿来写正文，起草、改写都一样",
                       "先补做留卡前试写里换一个人物、换一个场面、不该用的场面这三样，升成“可用”，门槛和一次填全的卡一样"):
            self.assertIn(phrase, first)
        # the seven are columns of the card, and the three that may wait still say they cannot stay empty
        for name in ("定位和短引", "技法名和一句话做法", "作用链", "什么时候拿出来用", "失效情境", "来源记录", "不可搬用的",
                     "原文写了什么，我读出来什么", "对应的模块和节", "工坊的判断"):
            self.assertEqual(len(re.findall(r"(?m)^- \*\*" + re.escape(name) + r"\*\*", text)), 1, name)
        self.assertEqual(text.count("不能空"), 10)
        # the threshold itself is where it was
        self.assertIn("要判成“可用”，换人物、换场面、不该用的场面这三样试写都要做过", part(text, "留卡前试写（工坊自己写几句）"))
        # a candidate technique card is not a candidate judgement card
        self.assertIn("技法卡的状态里也有“候选”（“候选，没试写”），说的是留卡前的三样试写还没做，和判断卡的“候选”不是一回事。",
                      text.split("\n## ", 1)[0])


class OnlyNarrowing(unittest.TestCase):
    def setUp(self):
        self.text = read(CARD)
        self.change = part(self.text, "改卡分轻重")

    def test_what_counts_and_what_does_not(self):
        counts = bullet(self.change, "  - 什么算：")
        for phrase in ("只在“失效情境”“用过头的样子”里加拦截条件（多写一种不该用的情形，或一种用过头的样子）",
                       "“技法名和一句话做法”“作用链”“成立条件”“在本书怎样重新实现”四栏一字没动",
                       "在“失效情境”里补一句同一场不该和哪一张一起用，也算"):
            self.assertIn(phrase, counts)
        does_not = bullet(self.change, "  - 什么不算：")
        for phrase in ("这四栏动了字", "只在“什么时候拿出来用”里收窄触发条件", "删掉、改松原有的句子", "这几种照“别的改动”办"):
            self.assertIn(phrase, does_not)

    def test_the_new_case_is_tested_and_the_adoption_stays_only_if_the_author_is_told(self):
        self.assertIn("只补测新加的那个反例，拿新加的那种情形试写一回", bullet(self.change, "  - 补测："))
        kept = bullet(self.change, "  - 采纳：")
        for phrase in ("作者原来的采纳保留", "另记一行，写作者采纳的是第几版、哪一版只收窄、改了哪一句",
                       "哪一章交稿时告诉了作者，等告诉了再补上"):
            self.assertIn(phrase, kept)
        told = bullet(self.change, "  - 告诉作者：")
        for phrase in ("下次交稿，这一章用没用到这张卡，都在正文外的说明里列一句这一轮改过的卡，告诉作者改了哪一句",
                       "作者只要正文的，这一句也在正文外另说，只说改了哪张卡的哪一句"):
            self.assertIn(phrase, told)
        self.assertIn("工坊撤回这次改动，卡上的说法改回收窄以前的，作者原来的采纳照旧", bullet(self.change, "  - 作者不同意的："))

    def test_any_other_change_is_as_before(self):
        other = bullet(self.change, "- **别的改动**：")
        self.assertIn("留卡前试写那几问重做一遍；新的一版照“作者采纳状态”记，旧版的采纳不带过来", other)
        adoption = bullet(part(self.text, BOTTOM[1]), "- **作者采纳状态**：")
        # the rule stands as it was; the exception follows it and points at the one place that defines it
        self.assertIn("旧版的采纳不带过来。只收窄的改动除外，照下半“改卡分轻重”办。新卡默认“没给作者看”。", adoption)
        after = bullet(part(self.text, BOTTOM[2]), "- **卡怎么改**：")
        self.assertIn("改完以后照下半“改卡分轻重”：只收窄的改动，只补测新加的那个反例；别的改动，留卡前试写那几问重做一遍", after)

    def test_two_cards_that_do_not_go_together(self):
        near = bullet(part(self.text, "和工坊已有模块的关系"), "- **相邻的卡**：")
        self.assertIn("同一场不该一起用的，另在“失效情境”里写一句，那一栏挑卡时读；写在一张卡上就够，不要求两张都写，也不另做检查", near)


class ThisBook(unittest.TestCase):
    def test_what_belongs_to_one_book_stays_with_it(self):
        text = read(CARD)
        bottom = half(text, HALVES[2]).split("\n### ", 1)[0]
        for phrase in ("其中“另填里要照本书答的两栏”起草时也读", "跨作品用仍要作者明说",
                       "作者明说带到别的书的，在那本书另起一份这一块，原来那本书的这一块留在原来那本书里",
                       "“在本书怎样重新实现”一栏照那本书重写",
                       "授权不明的原文短引留在原来那本书的私人记录里，不随通用部分走"):
            self.assertIn(phrase, bottom)
        kept_private = ("作者给的原文授权不明的，这一栏只写位置，再写一句短引放在哪里；短引本身留在本书的私人记录里"
                        "（[来源记录](reference-source-template.md)里“授权”一栏说的那一处）。")
        self.assertIn(kept_private, bullet(part(text, "来源证据"), "- **定位和短引**："))
        self.assertIn(kept_private, bullet(part(text, "反例与局限"), "- **原作里没起作用的地方**："))
        self.assertIn("授权不明的，短引只留在本书的私人记录里", read(ASSETS / "reference-source-template.md"))

    def test_the_delivery_says_which_card(self):
        trial = bullet(part(read(CARD), BOTTOM[1]), "- **本书试用**：")
        for phrase in ("交稿时在正文外说明这一场用了哪张技法卡、第几版、为什么",
                       "作者只要正文的，这一句记在工作记录里，作者问起再说",
                       "用的卡“作者采纳状态”一栏是“没给作者看”或“作者看过、没定”的，作者只要正文时也在正文外另说一句，只说用了哪张。",
                       "整章任务的，交稿时照上一句逐场说，各场用了哪张在节拍卡上也照记",
                       "这一轮改过的卡也列在这一处，照下半“改卡分轻重”；改过的卡那一句，作者只要正文的也在正文外另说",
                       "列给作者看不算作者采纳"):
            self.assertIn(phrase, trial)
        problems = part(read(CARD), BOTTOM[2])
        self.assertIn("写完自查查出作用链没走到的，也记一条，写明是工坊自查查出的。", problems)
        # r5.60, the author said yes: the author declining only the lines written from a card is not the author
        # declining the card
        self.assertIn("用了这张卡、作者不要或者审稿查出问题的，一次记一条。" + "作者只是不要照这张卡写出来的那几句、没说不要这张卡的，记在这里，“作者采纳状态”不记“作者不要”。", problems)
        # the author's later decision, on the adoption column and at the head of the bottom block
        adoption = bullet(part(read(CARD), BOTTOM[1]), "- **作者采纳状态**：")
        for phrase in ("这一栏挑卡时也看（见上半开头“挑卡的时候”一条）：记着“作者不要”“作者撤回”的卡不挑，作者以后又明说要用的，照作者新的话办。",
                       "这样的卡工坊后来改过一版的，原来记的那一行照留，新的一版也不挑，等作者明说要用。"):
            self.assertIn(phrase, adoption)
        self.assertIn("“作者采纳状态”一栏挑卡时也看", half(read(CARD), HALVES[2]).split("\n### ", 1)[0])


class WhatDidNotChange(unittest.TestCase):
    # Sentences of the r5.59 card that hold the author's powers or keep counts out of the judgement: each is in the
    # r5.60 card once, word for word.
    KEPT = ("各栏都不按字数、条数、出现次数填，也不按填满了多少算好坏；下面每栏写了什么时候可以空着。",
            "多出现几次不算多一份证据，也不说明它更好。", "写成“回头看的是……”，不写成次数线。", "不按成立了几问打分。",
            "把两边的原句列给作者", "记进新增设定清单列给作者，不写成本书的设定。", "作者采纳的是哪一版要对得上。",
            "列给作者，不硬判。", "列给作者看要不要进模块，不自己改模块", "定不了的列给作者；作者定以前照模块办",
            "沉默、接着要下一章、工坊自评、审稿通过、老师说好，都不算作者采纳",
            "作者采纳只管本书；要用到别的书，作者另外明说才算。", "作者没说的不猜。",
            "改卡只改卡上的说法，不改作者的设定和作者采纳的正文", "只缩条件，不把作者一次局部的意见扩成通则。")

    def test_the_kept_sentences_are_there_once(self):
        text = read(CARD)
        for sentence in self.KEPT:
            self.assertEqual(text.count(sentence), 1, sentence)

    def test_no_unconditional_words_and_no_count_thresholds(self):
        text = read(CARD)
        for word in ("永远", "绝不", "必须", "严禁", "一律", "任何时候", "禁止", "不得", "入库"):
            self.assertNotIn(word, text, word)
        # the one number that is a limit is the author's: two cards for a scene
        self.assertEqual(text.count("一场最多用两张"), 1)


class ThePagesAround(unittest.TestCase):
    def test_the_index_carries_the_head(self):
        section = half(read(PAGE), "按需建立与维护技法库")
        for phrase in ("先做轻量索引：卡片编号、机制名称、来源、适用场景、管哪一样和检索标签（照[技法卡模板]"
                       "(../assets/technique-card-template.md)卡头那两栏，拿不准的写“不确定”）、"
                       "卡的状态（“候选，没试写”“在用”“归档”这些）和实际路径。",
                       "索引里这几栏照卡头抄；卡头的技法名、管哪一样、检索标签或状态改了，同一次把索引那一行也改掉；两边对不上时以卡为准。",
                       "按标签筛过以后，仍读卡上的“什么时候拿出来用”。",
                       "同一机制正文保留一个维护位置，索引只链接或定位，不复制多份。"):
            self.assertIn(phrase, section)

    def test_how_a_scene_uses_cards(self):
        section = half(read(PAGE), "按需建立与维护技法库")
        for phrase in ("当前写作按场景检索少量有关卡片：先按索引的检索标签筛，再照卡上半开头写的读法挑卡、起草、写完自查",
                       "只用工坊的判断是“可用”的卡，状态是“候选，没试写”的、归档的、收进了规矩的不挑，作者说过不要、或者撤回过采纳的也不挑",
                       "一场最多用两张，挑最对的，其余命中的只在节拍卡上记一笔，不读进起草；无命中就继续原创。",
                       "交稿时在正文外说明这一场用了哪张技法卡（编号、第几版）、为什么",
                       "整章任务的，交稿时逐场说，各场用了哪张在节拍卡上照记",
                       "作者只要正文的，改过的卡那一句也在正文外另说，只说改了哪张卡的哪一句", "列给作者看不算作者采纳。",
                       "入库不自动生成新故事，也不把未采纳的应用升级成作者固定偏好。",
                       "技法卡的状态里也有“候选”（“候选，没试写”），说的是留卡前的三样试写还没做，和判断卡的“候选”不是一回事。"):
            self.assertIn(phrase, section)
        # the page sends the reader to the card for the three times and does not repeat them
        self.assertNotIn("拿“用过头的样子”核一遍", read(PAGE))
        study = half(read(STUDY), "形成机制卡")
        self.assertIn("素材很多时先做索引，按检索标签筛出当前场景相关的少数卡片，照技法卡模板上半开头写的读法读，"
                      "只用工坊的判断是“可用”的卡；没有合适参考也能继续原创。", study)

    def test_the_two_source_rows_name_no_one(self):
        notes = read(NOTES)
        first = next((line for line in notes.splitlines()
                      if line.startswith("| 参考材料：作者转来的一份对 r5.59 技法卡模板的外部评估")), "")
        for phrase in ("句子都是工坊新写的，没有引评估的原话", "不随包分发"):
            self.assertIn(phrase, first)
        second = next((line for line in notes.splitlines() if line.startswith("| 参考材料：作者转来的一份外部写作技法资料包")), "")
        for phrase in ("原包没有附许可文件，也没写是谁写的", "只读文件对照，没有运行它的脚本", "借了五处做法",
                       "没有带它的原文、例子、模板和脚本，也没有带按字数、次数、比例定的门槛", "不推定任何授权"):
            self.assertIn(phrase, second)
        for row in (first, second):
            # no address and no file name: who made the two is not written in the package
            self.assertNotRegex(row, r"https?://|\.zip|\.com|`")

if __name__ == "__main__":
    unittest.main()

"""Chapter confirmation behavior; all chapters and author evidence are synthetic."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import chapter_gate as gate
import learning_loop as loop
import project_state


def sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


class ChapterGateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "state.json"
        self.serial = 0
        project_state.init_state(self.path, "book", {
            "characters": {}, "settings": {}, "chapters": {},
            "demonstration_learning": {"enabled": False, "loop_enabled": False}})

    def payload(self):
        return loop.read_store(self.path)[0]

    def event(self, action, stage, chapter="c1", **fields):
        self.serial += 1
        return {"event_id": "gate-" + str(self.serial), "op": "chapter_gate",
                "chapter_id": chapter, "action": action, "stage": stage, **fields}

    def send(self, event, version=None):
        return loop.apply_event(self.path, event, "book",
                                version or loop.read_store(self.path)[1])

    def rejected(self, event, version=None):
        before = self.path.read_bytes()
        with self.assertRaises(loop.LoopError) as caught:
            self.send(event, version)
        self.assertEqual(self.path.read_bytes(), before)
        return caught.exception

    def present(self, stage, chapter="c1", **fields):
        values = {"content": "合成成果：" + stage, "source_ref": "fixture://" + stage}
        if stage in {"draft", "revision", "final"}:
            values["artifact_sha256"] = sha("合成候选稿")
        return self.send(self.event("present", stage, chapter, **{**values, **fields}))

    def confirmation(self, presented, **fields):
        values = {"presentation_id": presented["presentation_id"],
                  "presentation_version": presented["presentation_version"],
                  "actor_role": "author", "mode": "human", "author_quote": "本阶段成立，继续。",
                  "source_ref": "fixture://synthetic-author"}
        if presented["current_stage"] == "final":
            values.update(decision="accept_final_version", author_quote="明确采纳当前候选稿。")
        return self.event("confirm", presented["current_stage"], presented["chapter_id"],
                          **{**values, **fields})

    def advance_until(self, target, chapter="c1"):
        for stage in gate.STAGES:
            if stage == target:
                return
            self.send(self.confirmation(self.present(stage, chapter)))

    def finish_chapter(self, chapter="c1"):
        for stage in gate.STAGES:
            result = self.send(self.confirmation(self.present(stage, chapter)))
        return result

    def configure_policy(self, **fields):
        event = self.event("configure", None, visual_required=True, teacher_handoff="user_return",
                           actor_role="author", mode="human", author_quote="每章看图后由我交教师。",
                           source_ref="fixture://workflow-choice")
        event.pop("chapter_id")
        event.pop("stage")
        return self.send({**event, **fields})

    def visual_evidence(self, mode="author_images"):
        evidence = {"mode": mode, "source_refs": ["fixture://chapter-images"],
                    "observation_ref": "fixture://image-observation",
                    "selection_ref": "fixture://author-selection"}
        if mode == "pipeline_run":
            evidence.update(run_ref="fixture://visual-run", verification_ref="fixture://run-verification")
        if mode == "reuse":
            evidence.update(reuse_author_quote="本章复用这组图。", reuse_source_ref="fixture://reuse-choice")
        return evidence

    def prepare_policy_draft(self, chapter="c1"):
        self.advance_until("preparation", chapter)
        self.send(self.confirmation(self.present("preparation", chapter,
                                                visual_evidence=self.visual_evidence())))
        draft = self.present("draft", chapter)
        self.send(self.confirmation(draft))
        return draft

    def teacher_return_event(self, draft, **fields):
        event = self.event("teacher_return", None, draft["chapter_id"],
                           draft_presentation_id=draft["presentation_id"],
                           draft_presentation_version=draft["presentation_version"],
                           draft_sha256=draft["artifact_sha256"],
                           returned_text="教师原文：保留开场。\n第二场需补动机。",
                           source_ref="fixture://author-return", teacher_name="unknown")
        event.pop("stage")
        return {**event, **fields}

    def test_workflow_policy_requires_author_evidence_and_creates_no_chapter(self):
        for fields in ({"actor_role": "teacher"}, {"mode": "independent_agent"},
                       {"author_quote": " "}, {"source_ref": ""},
                       {"visual_required": "true"}, {"teacher_handoff": "automatic"}):
            with self.subTest(fields=fields):
                with self.assertRaises(loop.LoopError):
                    self.configure_policy(**fields)
        result = self.configure_policy()
        data = self.payload()["data"]
        self.assertEqual(data["chapter_workflow_policy"]["author_quote"], "每章看图后由我交教师。")
        self.assertTrue(data["chapter_workflow_policy"]["visual_required"])
        self.assertNotIn("chapter_confirmations", data)
        self.assertEqual(result["next_action"], "present")
        malformed = self.payload()
        malformed["data"]["chapter_workflow_policy"] = []
        with self.assertRaises(loop.LoopError):
            loop._validate(malformed)

    def test_visual_required_rejects_missing_or_incomplete_evidence(self):
        self.configure_policy()
        self.advance_until("preparation")
        self.rejected(self.event("present", "preparation", content="无需视觉", source_ref="fixture://skip"))
        for field in ("mode", "source_refs", "observation_ref", "selection_ref"):
            evidence = self.visual_evidence()
            evidence.pop(field)
            with self.subTest(field=field):
                self.rejected(self.event("present", "preparation", content="合成准备", source_ref="fixture://prep",
                                         visual_evidence=evidence))
        for sources in ([], "fixture://one", [" "]):
            evidence = {**self.visual_evidence(), "source_refs": sources}
            self.rejected(self.event("present", "preparation", content="合成准备", source_ref="fixture://prep",
                                     visual_evidence=evidence))
        self.assertEqual(gate.status(self.payload(), "c1")["current_stage"], "preparation")

    def test_visual_modes_require_their_own_evidence_and_bind_versions(self):
        self.configure_policy()
        self.advance_until("preparation")
        for mode, extra_fields in (("pipeline_run", ("run_ref", "verification_ref")),
                                   ("author_images", ()),
                                   ("reuse", ("reuse_author_quote", "reuse_source_ref"))):
            evidence = self.visual_evidence(mode)
            for field in extra_fields:
                incomplete = {key: value for key, value in evidence.items() if key != field}
                with self.subTest(mode=mode, missing=field):
                    self.rejected(self.event("present", "preparation", content="合成准备", source_ref="fixture://prep",
                                             visual_evidence=incomplete))
            presented = self.present("preparation", visual_evidence=evidence)
            record = self.payload()["data"]["chapter_confirmations"]["c1"]["history"][-1]
            self.assertEqual(record["visual_evidence"], evidence)
            changed = {**evidence, "selection_ref": "fixture://new-selection"}
            next_presented = self.present("preparation", visual_evidence=changed)
            self.assertNotEqual(presented["presentation_version"], next_presented["presentation_version"])

    def test_confirmed_draft_waits_for_teacher_and_blocks_review(self):
        self.configure_policy()
        draft = self.prepare_policy_draft()
        state = gate.status(self.payload(), "c1")
        self.assertEqual((state["chapter_status"], state["next_action"], state["current_stage"]),
                         ("await_teacher_return", "teacher_return", "review"))
        self.assertEqual(state["last_valid_confirmation"]["presentation_id"], draft["presentation_id"])
        self.rejected(self.event("present", "review", content="尚无教师返回", source_ref="fixture://review"))

    def test_teacher_return_keeps_original_text_and_does_not_confirm_any_stage(self):
        self.configure_policy()
        draft = self.prepare_policy_draft()
        original = "教师逐字意见：\n  保留这个空格。\n\n第二段待议。\n"
        before = copy.deepcopy(self.payload()["data"]["chapter_confirmations"]["c1"]["history"])
        event = self.teacher_return_event(draft, returned_text=original)
        result = self.send(event)
        chapter = self.payload()["data"]["chapter_confirmations"]["c1"]
        returned = chapter["teacher_returns"][0]
        self.assertEqual(returned["returned_text"], original)
        self.assertEqual(returned["returned_sha256"], sha(original))
        self.assertEqual(returned["event_id"], event["event_id"])
        self.assertEqual(returned["source_ref"], event["source_ref"])
        self.assertEqual(returned["teacher_name"], "unknown")
        self.assertEqual(chapter["history"], before)
        self.assertEqual((result["current_stage"], result["next_action"]), ("review", "present"))
        self.assertEqual(result["teacher_return_id"], event["event_id"])
        self.assertEqual(result["returned_sha256"], sha(original))
        resumed = gate.status(self.payload(), "c1")
        self.assertEqual(resumed["valid_teacher_returns"][0]["teacher_return_id"], event["event_id"])
        self.assertEqual(resumed["valid_teacher_returns"][0]["returned_sha256"], sha(original))
        self.assertNotIn("AUTHOR", self.payload()["data"])

    def test_teacher_return_requires_waiting_review_and_complete_current_draft_binding(self):
        self.configure_policy()
        scope = self.present("scope")
        self.rejected(self.teacher_return_event(scope, draft_sha256=sha("合成候选稿")))
        draft = self.prepare_policy_draft()
        for fields in ({"draft_presentation_id": "old-instance"},
                       {"draft_presentation_version": sha("old-version")},
                       {"draft_sha256": sha("old-draft")}, {"chapter_id": "c2"},
                       {"returned_text": " "}, {"source_ref": ""}, {"teacher_name": ""}):
            with self.subTest(fields=fields):
                self.rejected(self.teacher_return_event(draft, **fields))
        returned = self.send(self.teacher_return_event(draft))
        review = self.present("review", teacher_return_id=returned["teacher_return_id"])
        self.rejected(self.teacher_return_event(draft))
        self.send(self.confirmation(review))
        self.rejected(self.teacher_return_event(draft))

    def test_review_binds_specific_teacher_return_and_its_text_hash(self):
        self.configure_policy()
        draft = self.prepare_policy_draft()
        first = self.send(self.teacher_return_event(draft, returned_text="第一份教师意见"))
        second = self.send(self.teacher_return_event(draft, returned_text="第二份教师意见"))
        self.rejected(self.event("present", "review", content="未指回传", source_ref="fixture://review"))
        self.rejected(self.event("present", "review", content="错指回传", source_ref="fixture://review",
                                 teacher_return_id="missing"))
        review = self.present("review", teacher_return_id=first["teacher_return_id"])
        record = self.payload()["data"]["chapter_confirmations"]["c1"]["history"][-1]
        self.assertEqual(record["teacher_return_id"], first["teacher_return_id"])
        self.assertEqual(record["returned_sha256"], sha("第一份教师意见"))
        resumed = gate.status(self.payload(), "c1")
        self.assertEqual(resumed["teacher_return_id"], first["teacher_return_id"])
        self.assertEqual(resumed["returned_sha256"], sha("第一份教师意见"))
        self.assertEqual(len(resumed["valid_teacher_returns"]), 2)
        changed = self.present("review", teacher_return_id=second["teacher_return_id"])
        self.assertNotEqual(review["presentation_version"], changed["presentation_version"])
        self.send(self.confirmation(changed))
        self.assertEqual(gate.status(self.payload(), "c1")["current_stage"], "revision")

    def test_reopened_same_text_draft_cannot_reuse_old_teacher_return(self):
        self.configure_policy()
        draft = self.prepare_policy_draft()
        event = self.teacher_return_event(draft)
        returned = self.send(event)
        self.send(self.event("reopen", "draft", reason="重新交初稿", author_quote="重开初稿。",
                             source_ref="fixture://reopen-draft"))
        replacement = self.present("draft")
        self.assertEqual(replacement["presentation_version"], draft["presentation_version"])
        self.assertNotEqual(replacement["presentation_id"], draft["presentation_id"])
        self.send(self.confirmation(replacement))
        self.assertEqual(gate.status(self.payload(), "c1")["next_action"], "teacher_return")
        self.assertNotIn("valid_teacher_returns", gate.status(self.payload(), "c1"))
        self.rejected(self.teacher_return_event(draft))
        self.rejected(self.event("present", "review", content="旧教师意见", source_ref="fixture://review",
                                 teacher_return_id=returned["teacher_return_id"]))
        self.assertEqual(self.payload()["data"]["chapter_confirmations"]["c1"]["teacher_returns"][0]["event_id"],
                         event["event_id"])
        fresh = self.send(self.teacher_return_event(replacement))
        self.present("review", teacher_return_id=fresh["teacher_return_id"])

    def test_policy_changes_only_apply_to_chapters_first_presented_after_configuration(self):
        self.send(self.confirmation(self.present("scope", "legacy")))
        self.configure_policy()
        self.send(self.confirmation(self.present("scope", "frozen")))
        self.configure_policy(visual_required=False, teacher_handoff="host", author_quote="以后由宿主审核。")
        self.send(self.confirmation(self.present("outline", "legacy")))
        self.present("preparation", "legacy")
        self.send(self.confirmation(self.present("outline", "frozen")))
        self.rejected(self.event("present", "preparation", "frozen", content="缺视觉", source_ref="fixture://prep"))
        self.prepare_policy_draft("new-host")
        self.present("review", "new-host")
        chapters = self.payload()["data"]["chapter_confirmations"]
        self.assertFalse(chapters["legacy"]["workflow_policy"]["visual_required"])
        self.assertTrue(chapters["frozen"]["workflow_policy"]["visual_required"])
        self.assertEqual(chapters["new-host"]["workflow_policy"]["teacher_handoff"], "host")

    def test_policy_and_teacher_return_retries_share_outer_cas_and_idempotency(self):
        config = self.event("configure", None, visual_required=True, teacher_handoff="user_return",
                            actor_role="author", mode="human", author_quote="由我回传。", source_ref="fixture://choice")
        config.pop("chapter_id")
        config.pop("stage")
        stale = loop.read_store(self.path)[1]
        self.send(config, stale)
        self.assertEqual(self.send(config, stale)["status"], "unchanged")
        self.assertEqual(self.rejected({**config, "event_id": "new-config"}, stale).code, "stale_version")
        draft = self.prepare_policy_draft()
        event = self.teacher_return_event(draft)
        stale = loop.read_store(self.path)[1]
        first = self.send(event, stale)
        self.assertEqual(self.send(event, stale)["teacher_return_id"], first["teacher_return_id"])
        self.rejected({**event, "returned_text": "改过的原始回传"})
        self.assertEqual(len(self.payload()["data"]["chapter_confirmations"]["c1"]["teacher_returns"]), 1)

    def test_all_seven_stages_require_their_current_confirmation(self):
        self.assertEqual(gate.STAGES, ("scope", "outline", "preparation", "draft", "review", "revision", "final"))
        for index, stage in enumerate(gate.STAGES):
            if index + 1 < len(gate.STAGES):
                self.rejected(self.event("present", gate.STAGES[index + 1], content="跳关",
                                         source_ref="fixture://skip"))
            presented = self.present(stage)
            self.assertEqual(presented["next_action"], "confirm")
            self.assertEqual(gate.status(self.payload(), "c1")["current_stage"], stage)
            result = self.send(self.confirmation(presented))
        self.assertEqual(result["next_action"], "record_existing_author_gate")
        self.assertEqual(result["chapter_status"], "final_confirmation_recorded")

    def test_confirmation_requires_author_evidence_and_exact_stage_version(self):
        presented = self.present("scope")
        for fields in ({"author_quote": " "}, {"source_ref": ""}, {"actor_role": "teacher"},
                       {"mode": "independent_agent"}, {"presentation_version": sha("旧版")}):
            with self.subTest(fields=fields):
                self.rejected(self.confirmation(presented, **fields))
        wrong_stage = self.confirmation(presented)
        wrong_stage["stage"] = "outline"
        self.rejected(wrong_stage)
        self.send(self.confirmation(presented))
        self.rejected(self.confirmation(presented))

    def test_reducer_failures_and_status_are_read_only_and_malformed_namespace_rejected(self):
        payload = self.payload()
        before = copy.deepcopy(payload)
        self.assertEqual(gate.status(payload, "new")["current_stage"], "scope")
        with self.assertRaises(ValueError):
            gate.apply(payload, self.event("present", "draft", content="跳关", source_ref="fixture://skip"), "book")
        self.assertEqual(payload, before)
        malformed = copy.deepcopy(payload)
        malformed["data"]["chapter_confirmations"] = []
        with self.assertRaises(loop.LoopError):
            loop._validate(malformed)
        with self.assertRaises(ValueError):
            gate.status(malformed, "c1")

    def test_final_needs_hash_explicit_decision_and_more_than_continue(self):
        self.advance_until("final")
        for artifact in (None, "", "bad", "x" * 64):
            self.rejected(self.event("present", "final", content="合成定稿候选", source_ref="fixture://final",
                                     artifact_sha256=artifact))
        presented = self.present("final")
        for quote in ("继续", "继续吧。", " 继续写！ ", "继续下一章。", "请接着写。", "进入下一步。",
                      "我先看看。", "暂不定稿，继续改。", "先别封稿，等我再看一遍。"):
            self.rejected(self.confirmation(presented, author_quote=quote))
        self.rejected(self.confirmation(presented, decision="continue"))
        absent_decision = self.confirmation(presented)
        absent_decision.pop("decision")
        self.rejected(absent_decision)
        sealed = self.send(self.confirmation(presented, author_quote="这一章，封稿，开始下一章"))
        self.assertEqual(sealed["next_action"], "record_existing_author_gate")
        self.assertEqual(sealed["last_valid_confirmation"]["artifact_sha256"], presented["artifact_sha256"])

    def test_draft_review_revision_and_final_bind_the_actual_artifact(self):
        self.advance_until("draft")
        self.rejected(self.event("present", "draft", content="合成初稿", source_ref="fixture://draft"))
        draft_hash, revision_hash = sha("初稿A"), sha("修订稿B")
        self.send(self.confirmation(self.present("draft", artifact_sha256=draft_hash)))
        self.rejected(self.event("present", "review", content="错稿审查", source_ref="fixture://review",
                                 artifact_sha256=revision_hash))
        review = self.present("review")
        self.assertEqual(review["artifact_sha256"], draft_hash)
        self.send(self.confirmation(review))
        self.rejected(self.event("present", "revision", content="合成修订稿", source_ref="fixture://revision"))
        self.send(self.confirmation(self.present("revision", artifact_sha256=revision_hash)))
        self.rejected(self.event("present", "final", content="偷换旧初稿", source_ref="fixture://final",
                                 artifact_sha256=draft_hash))
        self.assertEqual(self.send(self.confirmation(self.present("final", artifact_sha256=revision_hash)))["next_action"],
                         "record_existing_author_gate")

    def test_same_text_represent_creates_new_instance_and_rejects_old_confirmation(self):
        first = self.present("scope")
        second = self.present("scope")
        self.assertEqual(first["presentation_version"], second["presentation_version"])
        self.assertNotEqual(first["presentation_id"], second["presentation_id"])
        self.rejected(self.confirmation(first))
        self.send(self.confirmation(second))
        history = self.payload()["data"]["chapter_confirmations"]["c1"]["history"]
        self.assertEqual([item["status"] for item in history], ["superseded", "confirmed"])
        self.assertEqual(history[0]["content"], "合成成果：scope")

    def test_reopen_invalidates_target_and_every_later_instance_but_keeps_evidence(self):
        self.finish_chapter()
        old = self.payload()["data"]["chapter_confirmations"]["c1"]["history"]
        old_preparation = old[2]["version"]
        self.rejected(self.event("reopen", "outline", reason="方案变化", author_quote="", source_ref="fixture://change"))
        self.send(self.event("reopen", "outline", reason="作者修改方案", author_quote="重新做本章方案。",
                             source_ref="fixture://synthetic-change"))
        state = gate.status(self.payload(), "c1")
        self.assertEqual((state["current_stage"], state["next_action"]), ("outline", "present"))
        history = self.payload()["data"]["chapter_confirmations"]["c1"]["history"]
        self.assertEqual(history[0]["status"], "confirmed")
        self.assertTrue(all(x["status"] == "invalidated" for x in history[1:7]))
        self.assertEqual(history[6]["confirmation"]["author_quote"], "明确采纳当前候选稿。")
        stale = {"chapter_id": "c1", "current_stage": "outline", "presentation_id": old[1]["presentation_id"],
                 "presentation_version": old[1]["version"]}
        self.rejected(self.confirmation(stale))
        self.send(self.confirmation(self.present("outline")))
        new_preparation = self.present("preparation")
        self.assertNotEqual(new_preparation["presentation_version"], old_preparation)

    def test_chapters_cannot_borrow_confirmations_or_reopen_future_stages(self):
        first = self.present("scope", "c1")
        second = self.present("scope", "c2")
        self.assertNotEqual(first["presentation_version"], second["presentation_version"])
        borrowed = self.confirmation(first)
        borrowed["chapter_id"] = "c2"
        self.rejected(borrowed)
        self.rejected(self.event("reopen", "final", "c2", reason="试图跳关", author_quote="继续。",
                                 source_ref="fixture://skip"))
        self.send(self.confirmation(first))
        self.assertEqual(gate.status(self.payload(), "c2")["current_stage"], "scope")

    def test_retries_are_idempotent_and_new_events_require_current_cas(self):
        event = self.event("present", "scope", content="合成范围", source_ref="fixture://scope")
        old_version = loop.read_store(self.path)[1]
        first = self.send(event, old_version)
        saved = self.path.read_bytes()
        repeated = self.send(copy.deepcopy(event), old_version)
        self.assertEqual(repeated["status"], "unchanged")
        self.assertEqual(repeated["presentation_id"], first["presentation_id"])
        self.assertEqual(self.path.read_bytes(), saved)
        self.rejected({**event, "content": "改过的范围"})
        self.assertEqual(self.rejected(self.confirmation(first), old_version).code, "stale_version")
        confirmation = self.confirmation(first)
        confirmed = self.send(confirmation)
        self.assertEqual(self.send(confirmation, old_version)["status"], "unchanged")
        self.assertEqual(confirmed["current_stage"], "outline")

    def test_existing_story_author_status_and_unrelated_data_survive(self):
        original = {"characters": {"L": {"name": "合成角色"}}, "settings": {"weather": "雨"},
                    "chapters": {"c1": {"text": "原有正文", "AUTHOR": "awaiting_author"}},
                    "delivery": {"FACT": "pass", "COPY": "pass", "TEACHER": "pass", "AUTHOR": "waiting"},
                    "notes": ["原有说明"]}
        self.path = Path(self.temp.name) / "original.json"
        project_state.init_state(self.path, "book", original)
        self.finish_chapter()
        for key, value in original.items():
            self.assertEqual(self.payload()["data"][key], value)
        self.assertEqual(set(self.payload()["data"]) - set(original), {"chapter_confirmations", "learning_events"})

    def test_chapter_confirmation_works_with_learning_disabled(self):
        presented = self.present("scope")
        self.assertEqual(self.send(self.confirmation(presented))["current_stage"], "outline")
        self.assertFalse(loop.status(self.path)["loop_enabled"])
        self.assertNotIn("learning_runs", self.payload()["data"])

    def test_learning_finish_does_not_confirm_any_chapter(self):
        self.present("scope")
        before = copy.deepcopy(self.payload()["data"]["chapter_confirmations"])
        def learning(op, **fields):
            self.serial += 1
            return self.send({"event_id": "learning-" + str(self.serial), "op": op,
                              "run_id": "synthetic-run", **fields})
        # Case selection and the learning loop retain their own switches.
        snapshot = project_state.read_state(self.path)
        data = copy.deepcopy(snapshot["data"])
        data["demonstration_learning"]["enabled"] = True
        project_state.commit_state(self.path, snapshot["version"], data)
        learning("configure", loop_enabled=True)
        learning("start", task="dialogue_revision", tags=[], group_id="fixture-group", input_text="合成原稿",
                 source_ref="fixture://input", constraints=[])
        learning("plan", applications=[], checks=[])
        learning("draft", text="合成初稿", source_ref="fixture://draft",
                 actor={"name": "fixture-writer", "context_id": "fixture-writer"})
        learning("review", review_id="teacher", draft_sha256=sha("合成初稿"),
                 reviewer={"name": "fixture-teacher", "context_id": "fixture-teacher", "role": "teacher",
                           "mode": "independent_agent"}, verdict="pass", findings=[], source_ref="fixture://review")
        learning("finish", draft_sha256=sha("合成初稿"))
        self.assertEqual(self.payload()["data"]["chapter_confirmations"], before)

    def test_markdown_storage_and_status_cli_resume_pending_without_writing(self):
        self.path = Path(self.temp.name) / "learning.md"
        prefix, suffix = "# 合成记录\n保留说明。\n", "\n末尾手写说明。\n"
        payload = {"schema_version": 1, "project_id": "book", "revision": 0, "data": {}}
        self.path.write_text(prefix + "<!-- NOVEL_WORKSHOP_LEARNING_START -->\n```json\n" +
                             json.dumps(payload) + "\n```\n<!-- NOVEL_WORKSHOP_LEARNING_END -->" + suffix,
                             encoding="utf-8")
        self.send(self.confirmation(self.present("scope")))
        presented = self.present("outline")
        before = self.path.read_bytes()
        result = subprocess.run([sys.executable, str(ROOT / "scripts/chapter_gate.py"), "status", str(self.path),
                                 "--chapter-id", "c1"], capture_output=True, text=True, encoding="utf-8", check=True)
        resumed = json.loads(result.stdout)
        self.assertEqual(resumed["presentation_id"], presented["presentation_id"])
        self.assertEqual(resumed["last_valid_confirmation"]["stage"], "scope")
        self.assertEqual(self.path.read_bytes(), before)
        self.assertTrue(before.startswith(prefix.encode()) and before.endswith(suffix.encode()))


if __name__ == "__main__":
    unittest.main()

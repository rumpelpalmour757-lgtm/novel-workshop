// Google AI（官方 ACP 运行时）在本机的三样记录，都在写作台的用户配置目录里：
// - acp-status.json：给作者看的状态（运行时、握手、登录、“已真实接通”、上一轮、额度暂停）。每次写都先重读磁盘上的那份，
//   只改这次要改的字段再整份换上（先写临时文件再改名），不会拿进程里的旧副本盖掉别处写的新内容；
//   文件坏了（不是 JSON、格式版本不认识）就报出来，不当成空的，也不往上写。
// - acp-events.jsonl：只追加的事件记录，一行一条：序号、时间、事件、这一轮的编号、内容摘要、运行时和模型设置、结果。
//   没有正文、令牌和账号信息。一轮真正发出之前先写“sent”并落盘（fsync），结束时写“finished”；
//   写作台中途被关掉，下次启动时能看到“发出了但没有结束”的那一轮，标成结果未知，等作者自己确认。
//   超过上限（默认 512 KiB）换一个新文件，旧的留一份；还没了结的轮次会抄到新文件里，不会因为换文件丢掉。
// - acp.lock：单实例锁。同一时间只让一个写作台（或 check-acp）用 Google AI；第二个会被告知已经有一个在用。
//   Node 没有跨平台的文件锁，这里用“独占创建锁文件 + 记下进程号和开机时间 + 每 30 秒续一次”：进程不在了、
//   锁是这次开机以前留下的、（Linux 上）那个进程号已经被比锁更晚启动的程序用上了、或者两分钟没有续上，都算作废，可以接手。
//   接手是先把旧锁改名挪开、确认挪开的正是刚才看到的那一份，再新建；不是（别人抢先建了新锁）就放回去，不会两个都以为拿到了锁。

import { randomUUID } from "node:crypto";
import { readFileSync, unlinkSync } from "node:fs";
import { chmod, link, mkdir, open, readFile, rename, stat, unlink, utimes, writeFile } from "node:fs/promises";
import { uptime } from "node:os";
import { dirname } from "node:path";

export const STORE_FORMAT = "novel-workshop-acp/1";
export const EVENTS_CAP_BYTES = 512 * 1024;
const OPEN_OUTCOMES = new Set(["unknown", "cancel_unconfirmed"]);

export class StoreError extends Error {
  constructor(path, reason) {
    super(`本机记录 ${path} 读不出来：${reason}。工坊不会悄悄当成空的，也不往上写；把它改个名字（或删掉）以后再试`);
    this.name = "StoreError";
    this.path = path;
    this.reason = reason;
  }
}

// 读一份 JSON 记录：没有文件就是空的；文件在却读不懂（坏了、版本不认识）就报错。
export async function readJsonStrict(path) {
  let text;
  try {
    text = await readFile(path, "utf8");
  } catch (error) {
    if (error?.code === "ENOENT") return {};
    throw new StoreError(path, `打不开（${error?.code || "出错"}）`);
  }
  if (!text.trim()) throw new StoreError(path, "文件是空的");
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new StoreError(path, "不是有效的 JSON");
  }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new StoreError(path, "内容不是一个对象");
  if (parsed.format !== undefined && parsed.format !== STORE_FORMAT) throw new StoreError(path, `格式版本“${String(parsed.format).slice(0, 60)}”不认识`);
  return parsed;
}

export async function writePrivateJson(path, data) {
  await mkdir(dirname(path), { recursive: true, mode: 0o700 });
  const temporary = `${path}.${process.pid}.${randomUUID().slice(0, 8)}.tmp`;
  try {
    await writeFile(temporary, `${JSON.stringify(data, null, 2)}\n`, { encoding: "utf8", mode: 0o600 });
    await chmod(temporary, 0o600).catch(() => {});
    await rename(temporary, path);
  } catch (error) {
    await unlink(temporary).catch(() => {});
    throw error;
  }
}

export class RecordStore {
  constructor(path) {
    this.path = path;
    this.chain = Promise.resolve();
    this.memory = {};
    this.writeError = null;
  }

  // 每次都读磁盘上的那份（另一个进程可能刚写过）；坏了就抛 StoreError。
  async load() {
    await this.chain;
    const fresh = await readJsonStrict(this.path);
    // 写不进去的时候，磁盘上的是旧的：这次运行里改过的字段以内存为准。
    this.memory = this.writeError ? { ...fresh, ...this.memory } : fresh;
    return this.memory;
  }

  // 只改 patch 里的字段；值为 null 的字段删掉。写之前重读，写完才算数。
  update(patch) {
    const run = this.chain.then(async () => {
      const fresh = await readJsonStrict(this.path);
      const next = { ...fresh, ...patch, format: STORE_FORMAT };
      for (const [key, value] of Object.entries(patch)) if (value === null || value === undefined) delete next[key];
      this.memory = next;
      try {
        await writePrivateJson(this.path, next);
        this.writeError = null;
      } catch (error) {
        this.writeError = error?.code || "写不进去";
      }
      return next;
    });
    this.chain = run.then(() => {}, () => {});
    return run;
  }
}

function eventKey(event) {
  return typeof event?.taskId === "string" ? event.taskId : null;
}

// 从事件里找还没了结的轮次：发出了但没有结束的（写作台中途退出），或者结束时是结果未知、取消未确认的，作者还没确认过。
export function openTurns(events) {
  const turns = new Map();
  for (const event of events) {
    const key = eventKey(event);
    if (!key) continue;
    const turn = turns.get(key) || { taskId: key };
    if (event.event === "sent") turn.sent = turn.sent || event;
    else if (event.event === "finished") turn.finished = event;
    else if (event.event === "acknowledged") turn.acknowledged = event;
    turns.set(key, turn);
  }
  return [...turns.values()].filter((turn) => turn.sent && !turn.acknowledged && (!turn.finished || OPEN_OUTCOMES.has(turn.finished.outcome)));
}

export class EventJournal {
  constructor(path, { capBytes = EVENTS_CAP_BYTES } = {}) {
    this.path = path;
    this.oldPath = path.replace(/\.jsonl$/, ".old.jsonl");
    this.capBytes = capBytes;
    this.seq = null;
    this.chain = Promise.resolve();
  }

  // 读出全部事件（先旧文件，再新文件）。读不懂的行（比如进程被杀时只写了一半）跳过并记数。
  async read() {
    const out = { events: [], badLines: 0 };
    for (const path of [this.oldPath, this.path]) {
      let text;
      try {
        text = await readFile(path, "utf8");
      } catch (error) {
        if (error?.code === "ENOENT") continue;
        throw new StoreError(path, `打不开（${error?.code || "出错"}）`);
      }
      for (const line of text.split("\n")) {
        if (!line.trim()) continue;
        try {
          const event = JSON.parse(line);
          if (event && typeof event === "object" && Number.isInteger(event.seq) && typeof event.event === "string") out.events.push(event);
          else out.badLines += 1;
        } catch {
          out.badLines += 1;
        }
      }
    }
    return out;
  }

  append(entry) {
    const run = this.chain.then(async () => {
      if (this.seq === null) {
        const { events } = await this.read();
        this.seq = events.reduce((max, event) => Math.max(max, event.seq), 0);
      }
      await mkdir(dirname(this.path), { recursive: true, mode: 0o700 });
      const info = await stat(this.path).catch(() => null);
      let carried = [];
      if (info && info.size > this.capBytes) {
        // 换文件之前记下还没了结的轮次，抄进新文件，免得旧文件再被换掉时丢了。
        // 发出和结束两行都抄过去（先发出、后结束），换多少次文件，这一轮的结果和原因都不变。
        carried = openTurns((await this.read()).events).flatMap((turn) => [turn.sent, turn.finished].filter(Boolean));
        await rename(this.path, this.oldPath);
      }
      const lines = [];
      for (const event of carried) {
        this.seq += 1;
        lines.push({ ...event, seq: this.seq, carriedFrom: event.seq });
      }
      this.seq += 1;
      const record = { seq: this.seq, at: new Date().toISOString(), ...entry };
      lines.push(record);
      const handle = await open(this.path, "a+", 0o600);
      try {
        // 上一个写的进程如果在一行中间死掉了，先补一个换行，免得这一条和那半行粘成一行。
        const size = (await handle.stat()).size;
        let prefix = "";
        if (size > 0) {
          const last = Buffer.alloc(1);
          await handle.read(last, 0, 1, size - 1);
          if (last[0] !== 0x0a) prefix = "\n";
        }
        await handle.appendFile(prefix + lines.map((line) => `${JSON.stringify(line)}\n`).join(""), "utf8");
        await handle.sync();
      } finally {
        await handle.close();
      }
      return record;
    });
    this.chain = run.then(() => {}, () => {});
    return run;
  }
}

// ---- 单实例锁
const HELD = new Set();
let exitHookInstalled = false;
export const LOCK_HEARTBEAT_MS = 30_000;
export const LOCK_STALE_MS = 120_000;
const BOOT_SLACK_MS = 60_000;
const UNKNOWN_HOLDER = Object.freeze({ pid: null, tool: "未知", startedAt: null });

function processAlive(pid) {
  if (!Number.isInteger(pid) || pid <= 0) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return error?.code === "EPERM";
  }
}

export function bootTimeMs() {
  return Date.now() - uptime() * 1000;
}

// Linux：从 /proc 读出这个进程是什么时候启动的（毫秒）；读不到（不是 Linux、/proc 看不到别的进程，或者进程不在了）就是 null。
// 读不到时这一条不算数：锁照样按开机时间和两分钟没续上判断。
let procRoot = "/proc";
// 测试用：把 /proc 换成一个不存在的目录，模拟看不到 /proc 的环境（比如 macOS，或者 hidepid 的容器）。
export function setProcRootForTests(root) {
  procRoot = root || "/proc";
}

export function linuxProcessStartMs(pid) {
  try {
    const text = readFileSync(`${procRoot}/${pid}/stat`, "utf8");
    const fields = text.slice(text.lastIndexOf(")") + 2).split(" ");
    const ticks = Number(fields[19]);
    const btime = Number(/^btime\s+(\d+)/m.exec(readFileSync(`${procRoot}/stat`, "utf8"))?.[1]);
    if (!Number.isFinite(ticks) || !Number.isFinite(btime)) return null;
    // starttime 以时钟滴答计；Linux 上 USER_HZ 几乎都是 100。
    return btime * 1000 + ticks * 10;
  } catch {
    return null;
  }
}

// 锁是不是作废了，作废的原因是什么；没作废返回 null。
export function staleReason(holder, info, { staleMs = LOCK_STALE_MS } = {}) {
  if (!holder) return "锁文件读不懂";
  if (holder.pid === process.pid && ![...HELD].some((lock) => lock.token === holder.token)) return "这个进程里已经放开了";
  if (!processAlive(holder.pid)) return "拿着锁的进程已经不在了";
  const startedAt = Date.parse(holder.startedAt);
  if (Number.isFinite(startedAt) && startedAt < bootTimeMs() - BOOT_SLACK_MS) return "锁是这次开机以前留下的";
  if (holder.pid !== process.pid && Number.isFinite(startedAt)) {
    const processStart = linuxProcessStartMs(holder.pid);
    if (processStart !== null && processStart > startedAt + 5000) return "这个进程号已经被别的程序用上了";
  }
  if (info && Date.now() - info.mtimeMs > staleMs) return "拿着锁的程序太久没有续上";
  return null;
}

async function readHolder(path) {
  try {
    const holder = JSON.parse(await readFile(path, "utf8"));
    return holder && typeof holder === "object" ? holder : null;
  } catch {
    return null;
  }
}

function publicHolder(holder) {
  return holder ? { pid: holder.pid ?? null, tool: holder.tool || "未知", startedAt: holder.startedAt || null, token: holder.token || null } : UNKNOWN_HOLDER;
}

export class InstanceLock {
  constructor(path, { heartbeatMs = LOCK_HEARTBEAT_MS, staleMs = LOCK_STALE_MS } = {}) {
    this.path = path;
    this.token = randomUUID();
    this.held = false;
    this.heartbeatMs = heartbeatMs;
    this.staleMs = staleMs;
    this.heartbeat = null;
    this.beforeTakeover = null;
  }

  forget() {
    if (this.heartbeat) clearInterval(this.heartbeat);
    this.heartbeat = null;
    this.held = false;
    HELD.delete(this);
  }

  async touch() {
    const holder = await readHolder(this.path);
    if (holder?.token !== this.token) return;
    const now = new Date();
    await utimes(this.path, now, now);
  }

  async acquire(tool) {
    if (this.held) {
      // 每次用之前确认锁还是自己的：电脑睡了很久，别的写作台可能已经当它作废接手了。
      const holder = await readHolder(this.path);
      if (holder?.token === this.token) return { ok: true };
      const exists = await stat(this.path).then(() => true, () => false);
      this.forget();
      if (exists) return { ok: false, holder: publicHolder(holder), lost: true };
      // 锁文件被人删了：下面重新建。
    }
    await mkdir(dirname(this.path), { recursive: true, mode: 0o700 });
    for (let attempt = 0; attempt < 4; attempt += 1) {
      let handle;
      try {
        handle = await open(this.path, "wx", 0o600);
      } catch (error) {
        if (error?.code !== "EEXIST") throw error;
        const info = await stat(this.path).catch(() => null);
        const holder = await readHolder(this.path);
        if (!holder && info && Date.now() - info.mtimeMs < 3000) return { ok: false, holder: UNKNOWN_HOLDER };
        if (holder && !staleReason(holder, info, { staleMs: this.staleMs })) return { ok: false, holder: publicHolder(holder) };
        if (this.beforeTakeover) await this.beforeTakeover();
        // 接手作废的锁：先改名挪开，再看挪开的是不是刚才看到的那一份。
        const grave = `${this.path}.stale-${this.token}`;
        try {
          await rename(this.path, grave);
        } catch (renameError) {
          if (renameError?.code === "ENOENT") continue;
          throw renameError;
        }
        const taken = await readHolder(grave);
        if ((taken?.token ?? null) === (holder?.token ?? null)) {
          await unlink(grave).catch(() => {});
          continue;
        }
        // 挪开的是别人刚建好的新锁：放回去（link 不会盖掉已有的文件），自己不接手。
        await link(grave, this.path).catch(async () => {
          if (!(await stat(this.path).then(() => true, () => false))) await rename(grave, this.path).catch(() => {});
        });
        await unlink(grave).catch(() => {});
        return { ok: false, holder: publicHolder(taken) };
      }
      try {
        await handle.writeFile(JSON.stringify({ pid: process.pid, token: this.token, tool, startedAt: new Date().toISOString(), bootAt: new Date(bootTimeMs()).toISOString() }), "utf8");
      } finally {
        await handle.close();
      }
      // 写完再读一遍，确认锁文件里是自己。
      const mine = await readHolder(this.path);
      if (mine?.token !== this.token) return { ok: false, holder: publicHolder(mine) };
      this.held = true;
      HELD.add(this);
      this.heartbeat = setInterval(() => {
        this.touch().catch(() => {});
      }, this.heartbeatMs);
      this.heartbeat.unref?.();
      if (!exitHookInstalled) {
        exitHookInstalled = true;
        process.once("exit", () => {
          for (const lock of [...HELD]) lock.releaseSync();
        });
      }
      return { ok: true };
    }
    return { ok: false, holder: publicHolder(await readHolder(this.path)) };
  }

  // 现在是谁拿着锁（不是自己、没有作废的才算）。
  async otherHolder() {
    if (this.held) return null;
    const info = await stat(this.path).catch(() => null);
    const holder = await readHolder(this.path);
    if (!holder || holder.token === this.token) return null;
    return staleReason(holder, info, { staleMs: this.staleMs }) ? null : publicHolder(holder);
  }

  releaseSync() {
    if (!this.held) return;
    try {
      const holder = JSON.parse(readFileSync(this.path, "utf8"));
      if (holder?.token === this.token) unlinkSync(this.path);
    } catch {}
    this.forget();
  }
}

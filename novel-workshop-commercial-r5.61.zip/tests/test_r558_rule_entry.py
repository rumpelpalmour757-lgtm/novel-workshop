#!/usr/bin/env python3
"""r5.58: rules from the author's files after they are entered, and how an unclear or unfollowed rule is read.

What is pinned and why:

1. A new rule entered in the register is applied to chapters written from then on; adopted chapters are not changed
   because of it. Where they differ, the places are listed for the author (`rule_register.py collide` gives chapter and
   line), and the author names which to change. A rule file that says "change the earlier chapters too" is listed the
   same way: rule files are tier 5 of the constitution, adopted story facts tier 4. continuity.md said only "then the new
   version is applied" (continuity.md:25 in r5.57) and left adopted chapters open; the constitution already gave the
   answer (tier 4 over tier 5, CON-001), so it is written in the module, not the constitution. The same sentence covers
   the scope a rule gives itself and a temporary rule with an end date (recorded in the source's `note`; `check` does
   not read dates).
2. When a whole rule file is replaced and the old version marked superseded, a specific exception the new version
   neither rewrote nor named stays in force (constitution section 1, the three cases after the five steps); the
   register cites the old version for it. `rule_register.py check` is run on a synthetic register for the three cases
   the sentence implies: decided and citing only the old version is OK; open and citing only the old version is
   reported ("cites only superseded sources", rule_register.py has not changed); open with the new general rule listed
   as a side is OK.
3. Item 3 of the r5.58 proposal ("先分强弱"): the author took option B, so the constitution and its five steps are
   unchanged and two sentences went into the modules (quality-loop.md: a rule in the author's manual that was not
   followed is not by that alone a plain breach; continuity.md: a vague rule is read by its purpose, not made into a
   count). The tests pin the two sentences and that option A's wording and the `strength` field were not added.

These tests check wording and tool behaviour only. They do not show that adopted chapters are handled better, or that
a review sorts its findings better; no paired scenario test has been run on these sentences.
"""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
SCRIPT = SKILL / "scripts" / "rule_register.py"


def page(rel):
    return (SKILL / rel).read_text(encoding="utf-8")


def run(*args):
    proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT)] + [str(a) for a in args], capture_output=True,
                          text=True, encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


def save(path, text):
    """Fixtures are written as UTF-8 bytes, so a Windows run sees the same line breaks (test_r525_windows.py)."""
    Path(path).write_bytes(text.encode("utf-8"))


def paragraph(text, start):
    """The paragraph (one line in these pages) that starts with `start`."""
    return next(line for line in text.splitlines() if line.startswith(start))


INTAKE = "**先查再入册。**"
STEP3 = "3. 专门的还是通用的。"


class NewRulesAndAdoptedChapters(unittest.TestCase):
    def test_a_new_rule_does_not_rewrite_adopted_chapters(self):
        line = paragraph(page("references/continuity.md"), INTAKE)
        applied = "三件事的结果都进登记表，然后才按新版执行。"
        added = ("按新版执行，管的是以后新写的章节和新写的部分；已采纳的章节不因为新规则自动改：和新规则不一样的地方"
                 "（`collide` 能列出旧叫法在哪一章哪一行）列出来请作者定，作者点明改哪些，再走受控变更（宪法第三节），"
                 "后文照“修订后的回归核对”回读。")
        self.assertIn(applied + added, line)
        self.assertLess(line.index(added), line.index("口径表、`prose_lint` 的用词规则、章节检查模板随之更新，更新也记一条。"))
        for phrase in ("规则文件里写着“前文也统一改”的，同样列出来请作者点明改哪些：规则文件在宪法第一节第 5 层，压不过第 4 层已采纳的故事事实。",
                       "作者让精修一章已采纳的稿子，用词规则在这一章里报出的旧叫法也照这样列给作者，不顺手换掉；"
                       "作者对这一章另有限定的，照“规则打架时”第 3 步末尾那句办。",
                       "规则自己写明了管哪几章、哪段时间的，照它写的范围；范围里有已采纳的章节的，那几章仍照上面列出来请作者定，不自己改。",
                       "写明了期限的临时规则（比如征文期间每章开头加一行活动标签），过了期限就不再据它写新章；"
                       "登记表里在这份来源的 `note` 写明期限（`check` 不看日期），到期以后在同一处 `note` 记一笔："
                       "哪天到期、从第几章起不再照它写，并在给作者的核对单里列一次。"):
            self.assertIn(phrase, line)
        # "a new upload does not replace everything" stays as it was
        self.assertIn("新上传不自动全面换版；明确“以此为准”才有相应优先级。", page("references/continuity.md"))

    def test_the_sentence_it_points_to_is_still_at_the_end_of_step_3(self):
        step3 = paragraph(page("references/continuity.md"), STEP3)
        self.assertTrue(step3.endswith("限定里仍要求改的那类（比如会让读者认错东西、算错数的）照样改。"), step3[-40:])
        self.assertIn("作者对已定稿的章节另有限定（比如再改只做必要的微调），按限定来", step3)


class OldExceptionsWhenTheWholeFileIsReplaced(unittest.TestCase):
    def test_a_superseded_version_keeps_the_exceptions_the_new_one_did_not_touch(self):
        step3 = paragraph(page("references/continuity.md"), STEP3)
        added = ("整份条例换了新版、旧版在登记表里标成被取代，说的是旧版不再是现行的那一版，不等于旧版里每一条都撤销了："
                 "新版没有改写、也没有点名删掉的具体例外照旧有效，登记时写明它引自旧版（`source` 写旧版的 `id`），"
                 "先查再入册时把这样的旧例外列给作者看一眼；这样的条目还没定的，把新版里那条通则也列为一边，"
                 "否则 `check` 会报它只引了被取代的来源。")
        self.assertIn("这个称呼留着。" + added + "作者对已定稿的章节另有限定", step3)
        # the constitution's three cases are where this comes from; they are unchanged
        self.assertIn("旧条例给某个人物的对白留了一个称呼的例外，新一版条例要求全书统一称呼，却没有提这个例外——例外照旧（第 3 步）",
                      page("CONSTITUTION.md"))


class TheRegisterCheck(unittest.TestCase):
    """A synthetic register: the old version of a style sheet superseded by the new one, run through rule_register.py."""

    OLD_SIDE = {"source": "v3", "where": "第二条", "quote": "樊九斤的对白里可以管师父叫“老舵”"}
    NEW_SIDE = {"source": "v4", "where": "第二条", "quote": "全书对白里称呼师父一律用“师父”"}

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)
        save(self.dir / "rules-v3.md", "# 口径表（第三版）\n\n一、渡口的铜哨叫“号子”。\n二、樊九斤的对白里可以管师父叫“老舵”。\n")
        save(self.dir / "rules-v4.md", "# 口径表（第四版）\n\n一、渡口的铜哨叫“号角”，前文也统一改。\n二、全书对白里称呼师父一律用“师父”。\n")
        save(self.dir / "ch05.md", "第五章\n老船工说：“早年那铜哨就叫号子。”\n樊九斤吹响了号子。\n")

    def check(self, item, **source_extra):
        register = {"schema": "rule-conflicts/1", "project": "合成书", "updated": "2026-11-16",
                    "sources": [dict({"id": "v4", "title": "口径表", "file": "rules-v4.md", "version": "第四版",
                                      "date": "2026-11-10", "status": "in_force"}, **source_extra),
                                {"id": "v3", "title": "口径表", "file": "rules-v3.md", "version": "第三版",
                                 "date": "2026-10-01", "status": "superseded", "superseded_by": "v4"}],
                    "texts": {"ch05": "ch05.md"}, "items": [item]}
        path = self.dir / "rule-conflicts.json"
        save(path, json.dumps(register, ensure_ascii=False))
        code, out, err = run("check", path, "--texts-root", self.dir)
        self.assertEqual(err, "")
        return code, json.loads(out)

    def exception(self, status, sides):
        item = {"id": "E-1", "kind": "exception", "title": "樊九斤对白里管师父叫“老舵”", "status": status, "sides": sides}
        if status == "open":
            item.update(ask="旧版留给樊九斤对白的“老舵”还要不要？", meanwhile="已采纳的章不动，新写的对白先避开这个称呼")
        else:
            item.update(resolution="新版没有改写、也没有点名删掉这条例外，照旧（第 3 步）",
                        decided_by={"who": "workshop", "when": "2026-11-16", "rule_applied": 3})
        return item

    def test_a_decided_exception_may_cite_only_the_superseded_version(self):
        code, report = self.check(self.exception("decided", [self.OLD_SIDE]))
        self.assertEqual((code, report["status"], report["problems"]), (0, "OK", []))

    def test_an_open_item_citing_only_the_superseded_version_is_reported(self):
        code, report = self.check(self.exception("open", [self.OLD_SIDE]))
        self.assertEqual((code, report["status"]), (1, "FAIL"))
        self.assertEqual(report["problems"],
                         ["item E-1 is open but cites only superseded sources; re-check it against the current version"])

    def test_listing_the_new_general_rule_as_a_side_is_ok(self):
        code, report = self.check(self.exception("open", [self.OLD_SIDE, self.NEW_SIDE]))
        self.assertEqual((code, report["status"], report["problems"]), (0, "OK", []))

    def test_check_does_not_read_the_end_date_in_a_note(self):
        note = "合成：征文期间每章开头加一行活动标签，到 2026-11-01 为止；2026-11-02 到期，从第 14 章起不再照它写"
        code, report = self.check(self.exception("decided", [self.OLD_SIDE]), note=note)
        self.assertEqual((code, report["status"]), (0, "OK"))

    def test_collide_gives_chapter_and_line_of_the_old_name(self):
        self.check(self.exception("decided", [self.OLD_SIDE]))
        code, out, err = run("collide", "--register", self.dir / "rule-conflicts.json", "--texts-root", self.dir, "号子", "号角")
        report = json.loads(out)
        self.assertEqual((code, err, report["complete"]), (0, "", True))
        self.assertEqual([(hit["text"], hit["line"]) for hit in report["words"]["号子"]], [("ch05", 2), ("ch05", 3)])
        self.assertEqual(report["words"]["号角"], [])


class RulesThatAreVagueOrNotFollowed(unittest.TestCase):
    """Item 3 of the proposal, option B: two sentences in the modules, the constitution's five steps unchanged."""

    def test_the_review_sentence(self):
        line = paragraph(page("references/quality-loop.md"), "区分四类发现：")
        self.assertIn("后两类不能自动升级为硬性错误。照作者的条例、手册、文风卡审稿时，有条目没照做，不单凭这一条记成明确违背要求。"
                      "条目自己写了程度或例外的，照它的目的读：有原文依据的节奏、表达问题照第二类记，没有的记为可选方向。"
                      "拿不准是不是作者有意的要求，列给作者，不径直记成可选。审稿记录里写明是哪一条没照做、记成了哪一类，让作者看得到。"
                      "安静、留白、题材惯例与不可靠叙述本身都不是缺陷", line)

    def test_the_vague_rule_sentence(self):
        line = paragraph(page("references/continuity.md"), "作者给的条例、口径表、台账里有两种话。")
        self.assertIn("规定（以后怎么叫、哪些词不用、改一处要连带重算或回读哪里）照办。规定写得模糊的（比如“打斗要利落”），"
                      "按它的目的理解，把怎么理解的写进交付说明或工作记录（作者只要正文的，记进工作记录），"
                      "不自己改成可以计数的指标；写明了数字的不算模糊。描述（某章写了什么", line)

    def test_option_a_was_not_taken(self):
        constitution = page("CONSTITUTION.md")
        self.assertNotIn("**先分强弱。**", constitution)
        self.assertIn("上面的顺序只管上层压下层。同一层里两条规则打架（最常见的是第 5 层：作者的条例、手册、清单、口径表互相之间，"
                      "或和项目档案之间），或者规则和已采纳的正文对不上，按下面的顺序定，哪一步定了就停，写明是按哪一步定的：", constitution)
        self.assertIn("卷进冲突的规则，在登记表里写明它是规定还是描述、管全书还是某一处、原句在哪。", constitution)
        self.assertNotIn("strength", SCRIPT.read_text(encoding="utf-8"))
        self.assertNotIn("strength", page("assets/rule-conflicts-template.json"))


if __name__ == "__main__":
    unittest.main()

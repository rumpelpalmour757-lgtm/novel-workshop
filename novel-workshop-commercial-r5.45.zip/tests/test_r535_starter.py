#!/usr/bin/env python3
"""r5.35: the starter example, one image and one sentence (the r5.34 review, point 5).

A first-time user should be able to send one picture and one sentence ("我喜欢这里的拥挤和破旧，但说不出来") and get a
few short readable candidates back, without filling in a character sheet or learning the workshop's words first. The
task level, the material and the people are sorted out inside. These tests pin where that is written: the drafting
module's section, the SKILL row that sends such a request there, the quick start's first-use section and the two new
examples. Whether the candidates read well is the author's judgement and is not tested here.
"""
import os
from pathlib import Path
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"


def read(path):
    return path.read_text(encoding="utf-8")


class Starter(unittest.TestCase):
    def test_the_drafting_section(self):
        text = read(SKILL / "references" / "drafting.md")
        part = text[text.index("## 从一张图和一句感受开始"):text.index("## 本章工作卡")]
        for phrase in ("不让作者先填表，也不要他先懂任务级别、节拍卡、素材卡。这些在内部做", "这是一段描写的试写，不是整章",
                       "分清哪些是图里看到的、哪些是推测", "看不了图就照实说", "不替图编内容", "照实说这一次没有声音样本",
                       "不假装是作者的口吻", "先给两三段能读的候选，每段一两百字，侧重不同", "每段后面一句话说它借了图里的哪几样",
                       "不必都变成道具（CON-012）", "只问一个问题：喜欢哪一段、哪里不对",
                       "要接着写成一整章的，再走本章工作卡、节拍卡、素材卡"):
            self.assertIn(phrase, part)
        self.assertLess(text.index("## 从一张图和一句感受开始"), text.index("## 本章工作卡"))

    def test_the_skill_row(self):
        row = next(line for line in read(SKILL / "SKILL.md").splitlines()
                   if line.startswith("| 只有一张图（照片、游戏截图、实景）加一句感受"))
        for phrase in ("[drafting.md](references/drafting.md)“从一张图和一句感受开始”", "不让作者先填表",
                       "没有作者的原文照实说没有声音样本", "先给两三段侧重不同的短候选", "只问喜欢哪段"):
            self.assertIn(phrase, row)

    def test_the_quick_start(self):
        text = read(ROOT / "QUICKSTART.md")
        first = text.index("## 第一次用：一张图加一句话就能开始")
        self.assertLess(first, text.index("## 方式一：手动导入技能"))
        part = text[first:text.index("## 方式一：手动导入技能")]
        for phrase in ("不用先填人物表，也不用先懂工坊的术语", "我喜欢这里的拥挤和破旧，但说不出来", "两三段短的候选",
                       "没有你自己写过的文字时，它会照实说这次没有你的声音样本", "[使用示例](EXAMPLES.md) 第 24 条"):
            self.assertIn(phrase, part)

    def test_the_examples(self):
        text = read(ROOT / "EXAMPLES.md")
        self.assertTrue(text.startswith("# 二十六个可复制的使用示例"))  # r5.45: the style-card example is the 26th
        self.assertIn("## 24. 只有一张图和一句感受", text)
        self.assertIn("## 25. 让工坊自己找图（五个项目）", text)
        part = text[text.index("## 25."):]
        for phrase in ("搜索只发几个短词，不发正文", "只把我点名的那几样记进灵感库", "五项都在你的机器上实际跑通过一次（`verify-run`）才算接通",
                       "没装、没网照常写作"):
            self.assertIn(phrase, part)

    def test_the_demo_is_labelled(self):
        demo = ROOT / "maintenance" / "acceptance-2026-10-23-r535" / "starter-demo.md"
        if not demo.is_file():
            self.skipTest("no maintenance folder next to the skills (only the personal build has it)")
        text = read(demo)
        for phrase in ("**这是流程演示，不是效果验收。**", "没有用作者的图；作者没有读这三段"):
            self.assertIn(phrase, text)


if __name__ == "__main__":
    unittest.main()

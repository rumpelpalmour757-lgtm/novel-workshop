"""mount.py、lint_text.py、export_prompt.py 共用的部分，只用标准库。

读 references/library.json（由 build_library.py 生成），解析弹药包与语域，读本书设定档，按编码读正文，按场景词给弹药包打分。
"""
import json
import sys
from pathlib import Path

for _s in (sys.stdout, sys.stderr):   # Windows 下重定向到文件时，个别符号编码不了也不报错
    try:
        _s.reconfigure(errors="replace")
    except AttributeError:
        pass

ROOT = Path(__file__).resolve().parent.parent
_LIB_FILE = ROOT / "references" / "library.json"
if not _LIB_FILE.exists():
    sys.exit("找不到 references/library.json：先运行 python scripts/build_library.py")
LIB = json.loads(_LIB_FILE.read_text(encoding="utf-8"))
K, C, RULES, METRICS, COUNTERS = LIB["kernel"], LIB["cartridges"], LIB["rules"], LIB["metrics"], LIB["counters"]
PACKS = LIB["interop"]["packs"]
REG_ALIAS = {"现代": "modern", "都市": "modern", "古风": "ancient", "古代": "ancient", "历史": "ancient",
             "仙侠": "ancient", "武侠": "ancient", "废土": "wasteland", "赛博": "wasteland", "科幻": "wasteland",
             "无": "none", "none": "none"}
MAX_CARTS = 2


def register_of(name):
    if not name:
        return None
    key = REG_ALIAS.get(name, name)
    if key != "none" and key not in K["registers"]:
        sys.exit(f"没有这个语域：{name}。可选：现代、古风、废土（或 modern、ancient、wasteland）")
    return None if key == "none" else key


def cart_of(arg):
    """弹药包可以写编号（1）、英文id（combat_survival）、简称（搏杀、手艺、查案、市井、情感、结构），或名字里的一段。"""
    a = str(arg).strip()
    if a in C:
        return a
    for n, c in C.items():
        if a in (c["id"], c.get("short")) or a in c["name"]:
            return n
    sys.exit(f"没有这个弹药包：{arg}。可选：" + "；".join(f"{n} {c['name']}" for n, c in C.items()))


def label(n):
    return f"{n} {C[n]['name']}"


def read_text(path):
    """先按 UTF-8（带不带BOM都行），不行再按 GB18030（Windows 记事本的老格式）。- 表示标准输入。"""
    data = sys.stdin.buffer.read() if path == "-" else Path(path).read_bytes()
    for enc in ("utf-8-sig", "gb18030"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def as_list(v):
    """设定档里只写一项时（skip: RULE_45、allow: 林灵瞳）也当一项，不拆成单字：拆开的话 R 开头会跳过全部禁令。"""
    if v is None or v == "":
        return []
    return v if isinstance(v, list) else [v]


def load_profile(path):
    """读本书设定档里的 realism 段：register、pack、skip、allow、cartridges。没有 realism 段就读顶层同名字段。"""
    try:
        import yaml
    except ImportError:
        sys.exit("读本书设定档需要 PyYAML：pip install pyyaml。不装也行：改用 --register、--pack、--skip、--allow 参数")
    p = Path(path)
    if not p.exists():
        sys.exit(f"找不到设定档：{path}")
    d = yaml.safe_load(read_text(p)) or {}
    r = d.get("realism") or d
    return {"register": r.get("register"), "pack": r.get("pack"),
            "skip": [str(x) for x in as_list(r.get("skip"))], "allow": [str(x) for x in as_list(r.get("allow"))],
            "cartridges": [str(x) for x in as_list(r.get("cartridges"))]}


def score_scenes(text):
    """按触发词给每个弹药包打分：两字以上的词每次命中算1分，单字词（杀、修、钱、家）算0.25分。"""
    scores = {}
    for n, c in C.items():
        hits, total = {}, 0.0
        for t in c["triggers"]:
            k = text.count(t)
            if k:
                hits[t] = k
                total += k * (1 if len(t) > 1 else 0.25)
        scores[n] = (round(total, 2), hits)
    return scores


def suggest(text, limit=MAX_CARTS):
    ranked = sorted(score_scenes(text).items(), key=lambda kv: -kv[1][0])
    return [(n, s, h) for n, (s, h) in ranked if s >= 1][:limit]

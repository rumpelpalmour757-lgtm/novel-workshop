#!/usr/bin/env python3
"""r5.59: a verdict names the A/B files it was made on, and `verdict` only takes one that matches this evaluation.

The author agreed to take this into r5.59 (with two more notes on the review pages). Up to the r5.59 candidate before
this change, `verdict` checked only the task and the judge mode. The maintenance page itself says to start a new
evaluation directory when a run was killed and could not clean up; blinding again there draws a new random side, so
A and B can be the other way round. A verdict a reviewer made on the packets the old directory handed out was then
recorded in the new one without a word, and `unblind` turned "the reviewer preferred the old version" into
"candidate improved". `ReversedConclusion` replays that with two evaluation directories, E1 (`--seed 1`, A is the
baseline) and E2 (`--seed 0`, A is the candidate), and one verdict made on E1's packets that prefers A. Run against
the candidate before this change, the verdict goes into E2 with exit code 0 and E2 reveals `improved`
(`test_a_verdict_made_on_another_directorys_packets_is_refused` fails there); now `blind` returns the SHA-256 of A.md
and B.md, the coordinator copies them into the verdict's `packets`, and `verdict` refuses a verdict whose `packets`
are missing or differ from what this directory sealed.

What is not changed and still checked elsewhere: the r5.58 checks of `blind` (version clues, empty outputs, cleaning
up after a failed command) in test_r558_blind_markers.py, and the r5.59 protected sections and groups in
test_r559_maintenance.py. Verdicts sealed before r5.59 have no `packets`; `verify` checks only the sealed hashes, so
they are revealed and counted as before (`test_a_verdict_sealed_before_r559_is_revealed_as_before`).

The check binds a verdict to the A/B bytes and labels, not to the evaluation directory: a directory that blinded the
same files under the same labels takes the other directory's verdict, and it reveals what the reviewer meant
(`test_the_same_sides_in_another_directory_are_taken`). The script's own description first said such a verdict
"cannot be recorded in the new one"; the review before delivery found that true only when A and B came out the other
way round, and the description now says so (r5.59).

The hashes show which files a verdict was made on. They do not show that the reviewer had not seen the mapping, and
nothing here shows that the comparison is right. Every passage below is newly written for this file.
"""

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILLS = ROOT / "skills"
TOOL = SKILLS / "darwin-novel-workshop" / "scripts" / "darwin_eval.py"
OLD, NEW = "门开了。", "门被推开了一条缝。"


def sha(data):
    return hashlib.sha256(data if isinstance(data, bytes) else data.encode("utf-8")).hexdigest()


def write(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.encode("utf-8"))
    return path


def read(path):
    return Path(path).read_text(encoding="utf-8")


class Packets(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.dir = Path(self.temp.name)
        write(self.dir / "arms" / "base" / "novel-workshop" / "SKILL.md", "旧规则")
        write(self.dir / "arms" / "cand" / "novel-workshop" / "SKILL.md", "新规则")
        self.base_out = write(self.dir / "out" / "base.txt", OLD)
        self.cand_out = write(self.dir / "out" / "cand.txt", NEW)

    def cli(self, *args, code=0):
        proc = subprocess.run([sys.executable, "-I", "-B", str(TOOL), *map(str, args)], capture_output=True, text=True,
                              encoding="utf-8")
        self.assertEqual(proc.returncode, code, proc.stdout + proc.stderr)
        return json.loads(proc.stdout)

    def evaluation(self, name, seed):
        work = self.dir / name
        write(work / "TASKS.json", json.dumps({"tasks": [{"id": "t1", "split": "holdout"}],
                                               "dimensions": [{"id": "prose", "hard": False}]}))
        self.cli("freeze", work, "--baseline", self.dir / "arms" / "base", "--candidate", self.dir / "arms" / "cand")
        blinded = self.cli("blind", work, "--task", "t1", "--baseline-output", self.base_out,
                           "--candidate-output", self.cand_out, "--seed", seed)
        return work, blinded

    def verdict(self, name, packets=None, result="A", evidence="A 的“门开了。”更干净"):
        value = {"task": "t1", "judge": {"mode": "human", "label": "评审甲"},
                 "dimensions": {"prose": {"result": result, "evidence": evidence}}}
        if packets is not None:
            value["packets"] = packets
        return write(self.dir / name, json.dumps(value, ensure_ascii=False))

    def refused(self, work, path, words):
        seals = (work / "SEALS.log").read_bytes()
        report = self.cli("verdict", work, "--task", "t1", "--file", path, code=2)
        self.assertEqual(report["status"], "ERROR")
        self.assertIn(words, report["message"])
        # nothing written: no verdict, the seal log as it was, and the mapping still cannot be revealed
        self.assertFalse((work / "verdicts" / "t1.json").exists())
        self.assertEqual((work / "SEALS.log").read_bytes(), seals)
        self.cli("unblind", work, "--task", "t1", code=2)
        return report


class BlindReturnsTheHashes(Packets):
    def test_blind_returns_the_two_packet_hashes(self):
        work, blinded = self.evaluation("E1", 1)
        mapping = json.loads(read(work / "sealed" / "t1.mapping.json"))
        self.assertEqual(blinded["files"], ["A.md", "B.md"])  # as before
        self.assertEqual(blinded["packets"], {label: sha((work / "packets" / "t1" / (label + ".md")).read_bytes())
                                              for label in ("A", "B")})
        self.assertEqual(blinded["packets"], {label: item["sha256"] for label, item in mapping["packets"].items()})
        # the result does not say which side is which
        self.assertNotIn("mapping", blinded)
        self.assertNotIn("baseline", json.dumps(blinded))


class ReversedConclusion(Packets):
    """The two evaluation directories of the reproduction: E1 hands out A = old, E2 has A = new."""

    def setUp(self):
        super().setUp()
        self.e1, self.b1 = self.evaluation("E1", 1)
        self.e2, self.b2 = self.evaluation("E2", 0)
        # the precondition of the reproduction: the same outputs, blinded twice, came out the other way round
        self.assertEqual(json.loads(read(self.e1 / "sealed" / "t1.mapping.json"))["mapping"],
                         {"A": "baseline", "B": "candidate"})
        self.assertEqual(json.loads(read(self.e2 / "sealed" / "t1.mapping.json"))["mapping"],
                         {"A": "candidate", "B": "baseline"})
        self.assertEqual(read(self.e1 / "packets" / "t1" / "A.md"), OLD)
        self.assertEqual(read(self.e2 / "packets" / "t1" / "A.md"), NEW)
        # what the coordinator noted when handing out each directory's packets (blind returns the same, see above)
        self.p1, self.p2 = ({label: sha((work / "packets" / "t1" / (label + ".md")).read_bytes()) for label in ("A", "B")}
                            for work in (self.e1, self.e2))

    def test_a_verdict_made_on_another_directorys_packets_is_refused(self):
        # The reviewer read E1's packets and preferred A ("门开了。", the old version). Recorded in E2 it would read
        # as "candidate improved".
        from_e1 = self.verdict("from-e1.json", self.p1)
        self.refused(self.e2, from_e1, "do not match the A/B files this evaluation directory sealed")
        # In E1, where it was made, it is recorded and reveals what the reviewer meant: the candidate regressed.
        self.cli("verdict", self.e1, "--task", "t1", "--file", from_e1)
        revealed = self.cli("unblind", self.e1, "--task", "t1")
        self.assertEqual(revealed["candidate_vs_baseline"], {"prose": "regressed"})
        self.assertEqual(self.cli("verify", self.e1)["status"], "OK")

    def test_the_reproductions_verdict_without_packets_is_refused(self):
        # the verdict file of the reproduction, as the reviewer handed it back: no packets
        bare = self.verdict("bare.json")
        for work in (self.e2, self.e1):
            with self.subTest(work=work.name):
                self.refused(work, bare, "verdict.packets must give the SHA-256 of A.md and B.md")

    def test_a_and_b_swapped_is_refused(self):
        swapped = {"A": self.p2["B"], "B": self.p2["A"]}
        self.refused(self.e2, self.verdict("swapped.json", swapped), "do not match")

    def test_the_packets_must_name_both_files_and_nothing_else(self):
        right = self.p2
        for name, packets in (("one.json", {"A": right["A"]}), ("extra.json", dict(right, C=right["A"])),
                              ("list.json", [right["A"], right["B"]]), ("number.json", {"A": 1, "B": right["B"]}),
                              ("empty.json", {"A": "", "B": right["B"]}),
                              ("nested.json", {"A": {"sha256": right["A"]}, "B": {"sha256": right["B"]}})):
            with self.subTest(name=name):
                self.refused(self.e2, self.verdict(name, packets), "verdict.packets must give the SHA-256")

    def test_the_matching_verdict_is_recorded(self):
        # The same judgment made on E2's own packets: the reviewer prefers the old version, which is B there.
        own = self.verdict("own.json", {label: value.upper() for label, value in self.p2.items()},
                           result="B", evidence="B 的“门开了。”更干净")  # case does not matter in a hash
        self.assertEqual(self.cli("verdict", self.e2, "--task", "t1", "--file", own)["task"], "t1")
        self.assertEqual(self.cli("unblind", self.e2, "--task", "t1")["candidate_vs_baseline"], {"prose": "regressed"})
        summary = self.cli("summarize", self.e2)
        self.assertEqual((summary["improved"], summary["regressed"]), (0, 1))
        self.assertTrue(summary["decision"].startswith("NO_CLEAR_IMPROVEMENT"), summary["decision"])
        self.assertEqual(summary["integrity"]["status"], "OK")


class SameSides(Packets):
    def test_the_same_sides_in_another_directory_are_taken(self):
        # E1 and E3 blind the same two outputs with the same seed: the same files under the same labels. A verdict made
        # on E1's packets is recorded in E3 and reveals there what it meant in E1; nothing is turned around.
        e1, b1 = self.evaluation("E1", 1)
        e3, b3 = self.evaluation("E3", 1)
        self.assertEqual(b1["packets"], b3["packets"])
        from_e1 = self.verdict("from-e1.json", b1["packets"])
        self.assertEqual(self.cli("verdict", e3, "--task", "t1", "--file", from_e1)["task"], "t1")
        self.assertEqual(self.cli("unblind", e3, "--task", "t1")["candidate_vs_baseline"], {"prose": "regressed"})


class SealedBeforeR559(Packets):
    def test_a_verdict_sealed_before_r559_is_revealed_as_before(self):
        # An evaluation that recorded its verdict with an earlier version has no packets in it. Nothing re-reads the
        # format of a sealed verdict, so it is revealed and summarized as before.
        spec = importlib.util.spec_from_file_location("r559_packets_darwin_eval", TOOL)
        darwin = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(darwin)
        work, _ = self.evaluation("E1", 1)
        target = work / "verdicts" / "t1.json"
        darwin.save(target, {"task": "t1", "judge": {"mode": "human", "label": "早先记下的"},
                             "dimensions": {"prose": {"result": "B", "evidence": "B 的“门被推开了一条缝。”更具体"}}})
        darwin.seal(work, "verdict", target)
        self.assertEqual(self.cli("verify", work)["status"], "OK")
        self.assertEqual(self.cli("unblind", work, "--task", "t1")["candidate_vs_baseline"], {"prose": "improved"})
        self.assertEqual(self.cli("summarize", work)["integrity"]["status"], "OK")


class Docs(unittest.TestCase):
    def test_the_maintenance_page(self):
        text = read(SKILLS / "darwin-novel-workshop" / "SKILL.md")
        for phrase in (
                "`blind` 生成匿名 A／B 包，封存实际的 A／B 文件和另存的映射，结果里给出 A.md、B.md 两个文件的 SHA-256（`packets`）",
                "`verdict` 在揭晓前封存裁决，只收 `packets` 和这个评估目录封存的 A／B 对得上的",
                "把 A／B 交给评审时，记下交出的是哪一个评估目录，以及 `blind` 结果里那两个文件的 SHA-256。",
                "评审交回裁决以后，由协调者照记下的哈希写进裁决的 `packets`，不让评审自己填。",
                "`verdict` 只收和这个评估目录封存的 A／B 对得上的裁决。",
                "旧目录发出去的那份裁决不能记进新目录：请评审照新目录的材料重看，或者照实记成这道题在新目录里没有裁决。",
                "若采用多名评审，交出材料以前先定下名单：有哪几位，各看哪一份材料，裁决交到哪里（r5.59）。收回来以后逐位核对。",
                "没交的、写坏的、对不上材料的，只向那几位补收，用原来那份材料；已经有效的裁决留着，不换人，也不重跑去替换。",
                "记录里写真实人数、分歧与原文依据；多数意见不能抵消保留原句、事实边界等硬约束失败。"):
            self.assertIn(phrase, text)
        self.assertNotIn("若采用多名评审，记录真实人数、分歧与原文依据；", text)
        # the hashes are copied by the coordinator; a refused verdict is not made to fit by changing them
        self.assertIn("哈希抄错了被拒的，查交出记录，不为了记得上去改哈希。", text)
        # a task blinded before r5.59 got no hashes from blind: they come from the copies handed out, not from the
        # evaluation directory (which would match whatever it holds)
        self.assertIn("r5.59 以前 `blind` 过、还没记裁决的题，结果里没有这两个哈希：照当时交给评审的那两份副本算，"
                      "不照评估目录里现在的文件算。", text)
        self.assertIn("r5.59 以前封存的裁决没有 `packets`，照旧能揭晓、能汇总。", text)

    def test_the_evaluation_page(self):
        text = read(SKILLS / "novel-workshop" / "references" / "skill-evaluation.md")
        item = next(line for line in text.splitlines() if line.startswith("4. 独立评审只收到任务"))
        self.assertTrue(item.endswith("请了几位评审的，缺的、写坏的只向那几位补收，用同一份匿名材料；已经交回、写得合格的不换人重评，"
                                      "这和生成那一头不挑最好的一次是一个道理（r5.59）。"), item)

    def test_the_script_says_so(self):
        text = read(TOOL)
        self.assertIn("verdict.packets", text)
        self.assertIn("Verdicts name the A/B files they were made on (r5.59)", text)
        # r5.59 review: what the check binds, said in the description the way the tests above show it
        description = " ".join(text.split('"""')[1].split())
        self.assertIn("cannot be recorded in the new one when A and B came out the other way round there (it would turn "
                      "the reviewer's preference around); the check binds a verdict to the A/B bytes and labels, as the "
                      "coordinator noted them at hand-out, not to the directory.", description)
        self.assertIn("Hashes copied from the new directory's blind instead of the hand-out record would get past the check.",
                      description)


if __name__ == "__main__":
    unittest.main()

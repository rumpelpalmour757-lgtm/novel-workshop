#!/usr/bin/env python3
"""r5.35: who speaks a line, and narration words in speech kept to what they are (the r5.34 review, point 1).

The review reproduced on r5.33 and r5.34: dialogue_lines.py gave a line to the one name in its paragraph, so in
他对宋青说：“先别碰。” (and 递工具给宋青, 看向宋青) the person spoken to became the speaker, and that person's
avoid words were checked against someone else's line. A book's one-word narration entry also hit inside a longer term
that characters say. The author added the craft words for the problem: 声口 (a character speaks like himself),
语域错位 (a narration-register word in a spoken line), 作者腹语 (the author talking through a character), and the
mirror that is fine, free indirect speech (a character's voice in the narration).

These tests pin, with names made up for the tests:

- a line goes to a speaker only on clear evidence next to it: a speaking tag's subject (before or after the line),
  the subject of the clause a colon closes, or of the sentence right before the line in its paragraph, or a beat set
  off by commas between two parts of one line;
- the person spoken to, handed something, looked at or pushed, a name before 的, and people after 让/被 are never
  taken for the speaker; a pronoun or an unlisted person as subject leaves the line not attributed; two possible
  speakers are listed as candidates;
- avoid words are checked only against a line's clear speaker;
- narration_only entries can name longer terms characters say (except), the hint asks a question instead of giving a
  replacement, and a voice file can record lines the author decided one by one (cases), shown with the hint;
- the report's three questions: 声口, to whom and why, 语域错位 (and the mirror is not a fault).
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
LINES = SKILL / "scripts" / "dialogue_lines.py"
NAMES = ["宋青", "林满", "程棠", "老周"]


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def lines():
    return load(LINES, "r535_dialogue_lines")


def who(text, names=NAMES, voices=None, mode="blank"):
    """[(quoted text, speaker or None, candidates)] in order."""
    report = lines().inspect(text, mode, names, voices)
    out = [(x["line"], x["text"], x["speaker"], x["candidates"]) for items in report["speakers"].values() for x in items]
    out += [(x["line"], x["text"], None, x["candidates"]) for x in report["unattributed"]]
    order = {t: n for n, t in enumerate(m for m in _quotes(text))}
    return [x[1:] for x in sorted(out, key=lambda x: (x[0], order.get(x[1], 0)))]


def _quotes(text):
    import re
    return [m.group() for m in re.finditer(r"“[^”]*”", text)]


def run(script, *args):
    proc = subprocess.run([sys.executable, "-I", "-B", str(script), *map(str, args)],
                          capture_output=True, text=True, encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


class NotTheSpeaker(unittest.TestCase):
    """The review's three cases and their kin: the name in the narration is not who speaks."""

    def test_the_reviews_three_cases(self):
        for text in ("他对宋青说：“先别碰。”", "他将工具递给宋青，说：“先别碰。”", "他看向宋青：“先别碰。”"):
            self.assertEqual(who(text), [("“先别碰。”", None, [])], text)

    def test_spoken_to_handed_looked_at_pushed(self):
        for text in ("他问宋青：“先别碰？”", "他冲宋青喊：“先别碰！”", "他看了宋青一眼，低声说：“先别碰。”",
                     "他推开宋青：“先别碰。”", "他推开宋青说：“先别碰。”", "他跟宋青说：“先别碰。”", "他拦住宋青：“先别碰。”",
                     "“先别碰。”他对宋青说。", "“先别碰。”他指给宋青。", "“钥匙放下。”男人看向宋青，“人可以走。”"):
            for line in who(text):
                self.assertIsNone(line[1], text)
                self.assertNotIn("宋青", line[2], text)

    def test_a_possessive_or_someone_unlisted_is_not_a_speaker(self):
        for text in ("宋青的手顿在半空。“先别碰。”", "老周的徒弟说：“先别碰。”", "她把表收回去：“明天再来。”",
                     "宋青看了她一眼，女孩抬手：“先别碰。”", "“先别碰。”他说。", "他知道：“先别碰。”"):
            self.assertEqual([line[1] for line in who(text)], [None], text)


class TheSpeaker(unittest.TestCase):
    """Clear speakers are still found, before or after the line."""

    def test_tags(self):
        cases = {
            "宋青说：“先别碰。”": ["宋青"],
            "“先别碰。”宋青说。": ["宋青"],
            "宋青低声问道：“先别碰？”": ["宋青"],
            "林满对宋青说：“先别碰。”": ["林满"],
            "宋青问林满：“先别碰？”": ["宋青"],
            "宋青听见林满说：“先别碰。”": ["林满"],
            "老周看了程棠一眼，低声说：“先别碰。”": ["老周"],
            "“先别碰。”宋青对林满说，“碰了就赔。”": ["宋青", "宋青"],
            "“先别碰。”老周说完转身就走，程棠问他去哪。": ["老周"],
            "宋青说：“先别碰。”林满说：“碰了又怎样？”": ["宋青", "林满"],
            "宋青放下表，林满开口：“先别碰。”": ["林满"],
        }
        for text, speakers in cases.items():
            self.assertEqual([line[1] for line in who(text)], speakers, text)

    def test_colon_and_the_sentence_before(self):
        cases = {
            "老周握住钥匙：“谁给你的？”": ["老周"],
            "这时老周抬起头：“先别碰。”": ["老周"],
            "门口的宋青抬起头：“先别碰。”": ["宋青"],
            "老周看了程棠一眼：“那就上去。”": ["老周"],
            "老周说着，从柜下拿出一张表：“先填。”": ["老周"],
            "程棠没松手。“今晚得交。”": ["程棠"],
            "林满盯着那盏灯，刚要开口，宋青已经按住她的手。“先别碰它。”": ["宋青"],
        }
        for text, speakers in cases.items():
            self.assertEqual([line[1] for line in who(text)], speakers, text)

    def test_a_beat_between_two_parts_of_one_line(self):
        self.assertEqual([line[1] for line in who("“三斤。”宋青又压了一次价，“多的算我请你。”")], ["宋青", "宋青"])
        self.assertEqual([line[1] for line in who("“慢点放。”老周托住箱底，“先放左边。”")], ["老周", "老周"])
        # A beat after the line alone, with no speaking verb, is only a possibility.
        self.assertEqual(who("“走。”老周转身出门。"), [("“走。”", None, ["老周"])])

    def test_a_speaking_verb_inside_another_word_is_not_a_tag(self):
        # 知道, 听说, 问题: the one-character verb is part of another word, so the clause after the line is a beat.
        for text, name in (("“先别碰。”宋青知道林满不会听。", "宋青"), ("“先别碰。”老周听说过这事。", "老周"),
                           ("“先别碰。”宋青问题不少，林满没理。", "宋青")):
            self.assertEqual(who(text), [("“先别碰。”", None, [name])], text)
        report = lines().inspect("宋青知道：“先别碰。”", "blank", NAMES, None)
        self.assertEqual([x["basis"] for x in report["speakers"]["宋青"]], ["colon"])

    def test_the_line_mode_keeps_paragraphs_apart(self):
        # A line alone on its line has no evidence next to it, whoever acted on the line before.
        self.assertEqual(who("宋青把表收回去。\n“明天再来。”\n", mode="line"), [("“明天再来。”", None, [])])


class Open(unittest.TestCase):
    """When two people could be meant, both are listed and nobody is picked."""

    def test_candidates(self):
        cases = {
            "老周让程棠说：“先别碰。”": ["程棠", "老周"],
            "宋青和林满站在门口。“先别碰。”": ["宋青", "林满"],
            "程棠想上前帮忙，被老周拦了下来：“你先看好门口。”": ["程棠", "老周"],
            "老周看了程棠一眼。“滚。”他说。": ["老周"],
        }
        for text, candidates in cases.items():
            self.assertEqual(who(text), [(_quotes(text)[0], None, candidates)], text)


class Flags(unittest.TestCase):
    VOICES = {
        "speakers": {"宋青": {"avoid": ["仿佛"]}, "林满": {"avoid": []}},
        "narration_only": [{"text": "勘", "except": ["勘测队"], "note": "叙述用词"}],
        "cases": [{"word": "勘", "chapter": 3, "speaker": "林满", "was": "“你勘过没有？”", "now": "“你看过没有？”",
                   "decided": "作者 2026-10-01", "scope": "林满在门口问，只管这一句"}],
    }

    def flags(self, text):
        report = lines().inspect(text, "blank", (), self.VOICES)
        return [(f["kind"], f["word"]) for x in report["flagged"] for f in x["flags"]], report

    def test_avoid_words_follow_only_a_clear_speaker(self):
        self.assertEqual(self.flags("宋青说：“仿佛要下雨了。”")[0], [("avoid", "仿佛")])
        # The review's fifth case: the line is not 宋青's, so 宋青's avoid list says nothing about it.
        self.assertEqual(self.flags("他对宋青说：“仿佛要下雨了。”")[0], [])

    def test_a_term_is_not_a_narration_word(self):
        self.assertEqual(self.flags("林满说：“勘测队明天到。”")[0], [])
        found, report = self.flags("林满说：“勘测队的人勘过没有？”")
        self.assertEqual(found, [("narration", "勘")])
        note = report["flagged"][0]["flags"][0]["note"]
        # r5.37 (the r5.35 review, point 4): a hint, not a verdict; the word may be this person's own.
        for phrase in ("叙述里的词“勘”进了台词", "这个人在这个场合、对这个人、为了这个目的，会不会这么说", "语域错位",
                       "也可能正是他的声口", "这是提示，不是判定",
                       "作者逐处定过：第3章林满“你勘过没有？”→“你看过没有？”（作者 2026-10-01，只管那一处）"):
            self.assertIn(phrase, note)
        self.assertNotIn("口头说“", note)

    def test_say_is_a_reference(self):
        voices = {"narration_only": [{"text": "抵达", "say": "到了"}]}
        report = lines().inspect("老周说：“我们抵达的时候门就锁了。”", "blank", (), voices)
        note = report["flagged"][0]["flags"][0]["note"]
        self.assertIn("本书记过的口头说法：“到了”，只作参考，换词先看意思变没变", note)

    def test_bad_entries_are_refused(self):
        checker = lines()
        for bad in ({"narration_only": [{"text": "勘", "except": "勘测队"}]},
                    {"narration_only": [{"text": "勘", "except": ["测量队"]}]},
                    {"narration_only": [{"text": "勘", "except": ["勘"]}]},
                    {"cases": [{"word": "勘", "chapter": 3, "was": "a", "now": "b"}]},
                    {"cases": [{"word": "勘", "chapter": 0, "was": "a", "now": "b", "decided": "作者"}]},
                    {"cases": [{"word": "勘", "chapter": True, "was": "a", "now": "b", "decided": "作者"}]},
                    {"cases": [{"word": "勘", "chapter": 3, "was": "a", "now": "b", "decided": "作者", "who": "x"}]},
                    {"cases": {}}):
            with self.assertRaises(ValueError, msg=bad):
                checker.inspect("“走。”\n", "blank", (), bad)


class Report(unittest.TestCase):
    def test_the_three_questions_and_the_limits(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "第七章.txt"
            path.write_bytes("他对宋青说：“先别碰。”\n\n宋青说：“然而我偏要碰。”\n".encode("utf-8"))
            before = hashlib.sha256(path.read_bytes()).hexdigest()
            code, out, err = run(LINES, path, "--names", "宋青")
            self.assertEqual(code, 0, err)
            for phrase in ("== 宋青，1 处", "== 叙述里没写明是谁说的，1 处", "这词像不像他说的（声口）", "他此刻对谁说、为什么说、急不急",
                           "急的人也可以把话说完整", "叙述层的词进了台词没有（语域错位；他身份里本来就说的术语、行话不算）",
                           "这个人在这个场合、对这个人、为了这个目的，会不会这样说",
                           "受话人、递东西给的人、看着的人不算说话人"):
                self.assertIn(phrase, out)
            self.assertNotIn("急就砍短", out)
            code, out, err = run(LINES, path, "--names", "宋青", "--format", "json")
            report = json.loads(out)
            self.assertEqual([x["basis"] for x in report["speakers"]["宋青"]], ["tag"])
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), before)


def read(relative):
    return (SKILL / relative).read_text(encoding="utf-8")


class Modules(unittest.TestCase):
    """The words for the problem, the direction that is not a problem, and the rules that judge by what a line does
    (the r5.33 and r5.34 reviews, point 4: no quota, no deleting by new facts only, no uniform plain-speech downgrade)."""

    def test_the_five_passes(self):
        text = read("references/revision-passes.md")
        why = text[text.index("## 为什么要分开读"):text.index("## 第一遍")]
        # r5.37 (the r5.35 review, point 4): the author's direction is where to look first, not a law.
        for phrase in ("一样人，便还他一样说话", "声口", "人物语言性格化", "语域错位", "毛病不在词本身，在词和场合的错配", "作者腹语",
                       "人物声音进叙述是技巧，叙述声音进台词是病", "它是查的起点，不是每一句的定论",
                       "这个人，在这个场合、对这个人、为了这个目的，会不会这样说", "这是查的出发点，不是每一句的定论"):
            self.assertIn(phrase, why)
        self.assertNotIn("才是毛病", why)
        self.assertNotIn("模型写字时没有", why)
        for phrase in ("哪一步认识的变化、哪一处停顿、哪一点情绪的余韵", "带着人物新的判断、他的口气或这一刻的情绪的，留",
                       "不按句数、字数或新事实的多少一刀切", "听的人确实不懂、要靠这句话做决定的，照说",
                       "可急的人也可以把一句话说完整、说准确", "不把动词一律换成“弄、搞、打”", "摘掉引号像叙述，不等于是假台词",
                       "作者逐处定过的，照作者的，不推成全书替换", "叙述贴着人物、带着他口气的地方不在这一遍改的范围",
                       "左右手逐处看作用", "不按全章几处的配额删"):
            self.assertIn(phrase, text)
        for gone in ("急就砍短", "左右手分工全章只留一处", "读者推得出来的，删", "叙述里写“勘验”，人物嘴里说“看看”"):
            self.assertNotIn(gone, text)

    def test_dialogue_craft(self):
        text = read("references/dialogue-craft.md")
        part = text[text.index("## 声口和语域"):text.index("## 顺着回应改")]
        for phrase in ("**声口**", "**语域错位**", "**作者腹语**", "**方向（查的起点，不是定律）**", "**不当全局禁令**",
                       "查语域错位时只动台词这一边", "要是说话的是来查账的稽查员，“勘验”可能正是他的声口，就不改"):
            self.assertIn(phrase, part)
        self.assertNotIn("急就砍短", text)
        self.assertIn("只认台词旁边写明的说话人，受话人不算", text)

    def test_the_scope_comes_before_the_spec(self):
        text = read("references/scene-dramaturgy.md")
        head = text.split("## 1. ")[0]
        for phrase in ("**先看范围（NWC-1.5", "管的是对手戏、冲突戏", "不套“受阻—加码—翻转—切走”",
                       "“第一轮交锋必然受挫”（3.2）是作者批准保留的原文"):
            self.assertIn(phrase, head)

    def test_the_checklist(self):
        self.assertIn("叙述用的词进没进台词（语域错位）？这个人此刻对谁说、急不急", read("assets/sentence-dialogue-checklist.md"))


if __name__ == "__main__":
    unittest.main()

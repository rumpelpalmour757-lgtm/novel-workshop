#!/usr/bin/env python3
"""Reduce chapter confirmations in the existing project ledger; never write prose."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import re
import sys


STAGES = ("scope", "outline", "preparation", "draft", "review", "revision", "final")
DEFAULT_POLICY = {"visual_required": False, "teacher_handoff": "host"}


class GateError(ValueError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def _need(condition, message, code="invalid_event"):
    if not condition:
        raise GateError(code, message)


def _text(value, name):
    _need(isinstance(value, str) and bool(value.strip()), name + " must be non-empty text")
    return value


def _artifact(value, required=False):
    _need((value is None and not required) or
          (isinstance(value, str) and re.fullmatch(r"[0-9a-fA-F]{64}", value) is not None),
          "artifact_sha256 must be a complete SHA256; final requires it")
    return value.lower() if isinstance(value, str) else None


def validate_policy(policy, code="invalid_store"):
    """Check recorded policy structure, without authenticating its provenance."""
    _need(isinstance(policy, dict) and type(policy.get("visual_required")) is bool
          and policy.get("teacher_handoff") in ("user_return", "host"),
          "chapter_workflow_policy requires visual_required:boolean and teacher_handoff:user_return|host", code)
    return policy


def _policy(chapter):
    return validate_policy(chapter.get("workflow_policy", DEFAULT_POLICY))


def _visual_evidence(value):
    _need(isinstance(value, dict), "visual_evidence must be an object")
    mode = value.get("mode")
    _need(mode in ("pipeline_run", "author_images", "reuse"), "Invalid visual evidence mode")
    sources = value.get("source_refs")
    _need(isinstance(sources, list) and bool(sources)
          and all(isinstance(ref, str) and ref.strip() for ref in sources),
          "visual_evidence.source_refs must be a non-empty list of text references")
    fields = ["observation_ref", "selection_ref"]
    if mode == "pipeline_run":
        fields += ["run_ref", "verification_ref"]
    if mode == "reuse":
        fields += ["reuse_author_quote", "reuse_source_ref"]
    for field in fields:
        _text(value.get(field), "visual_evidence." + field)
    return copy.deepcopy(value)


def _version(chapter, presentation):
    bound = {key: presentation[key] for key in
             ("stage", "content", "source_ref", "artifact_sha256", "dependencies")}
    bound.update(project_id=chapter["project_id"], chapter_id=chapter["chapter_id"])
    # Omit new fields on legacy records so their existing versions still verify.
    for key in ("visual_evidence", "teacher_return_id", "returned_sha256"):
        if key in presentation:
            bound[key] = presentation[key]
    if "workflow_policy" in chapter:
        bound["workflow_policy"] = chapter["workflow_policy"]
    raw = json.dumps(bound, ensure_ascii=False, sort_keys=True,
                     separators=(",", ":"), allow_nan=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _chapter(payload, chapter_id):
    _text(chapter_id, "chapter_id")
    _need(isinstance(payload, dict) and isinstance(payload.get("data"), dict),
          "Store must contain a data object", "invalid_store")
    _text(payload.get("project_id"), "project_id")
    chapters = payload["data"].get("chapter_confirmations", {})
    _need(isinstance(chapters, dict), "chapter_confirmations must be an object", "invalid_store")
    chapter = chapters.get(chapter_id)
    if chapter is None:
        _need(chapter_id not in chapters, "Chapter record must be an object", "invalid_store")
        return {"chapter_id": chapter_id, "project_id": payload["project_id"], "history": []}
    _need(isinstance(chapter, dict) and chapter.get("chapter_id") == chapter_id
          and chapter.get("project_id") == payload["project_id"]
          and isinstance(chapter.get("history"), list), "Invalid chapter record", "invalid_store")
    _need(all(isinstance(item, dict) and item.get("action") in {"present", "reopen"}
              and item.get("stage") in STAGES for item in chapter["history"]),
          "Invalid chapter history", "invalid_store")
    _policy(chapter)
    returns = chapter.get("teacher_returns", [])
    _need(isinstance(returns, list), "teacher_returns must be an array", "invalid_store")
    for returned in returns:
        _need(isinstance(returned, dict) and returned.get("chapter_id") == chapter_id
              and returned.get("project_id") == payload["project_id"]
              and all(isinstance(returned.get(key), str) and returned[key].strip() for key in
                      ("event_id", "draft_presentation_id", "draft_presentation_version", "draft_sha256",
                       "returned_text", "source_ref", "teacher_name"))
              and returned.get("returned_sha256") == hashlib.sha256(returned["returned_text"].encode("utf-8")).hexdigest(),
              "Invalid teacher return record", "invalid_store")
    return chapter


def _teacher_returns(chapter):
    draft = next((item for item in chapter["history"] if item["action"] == "present"
                  and item["stage"] == "draft" and item.get("status") == "confirmed"), None)
    if draft is None:
        return []
    return [item for item in chapter.get("teacher_returns", [])
            if item["draft_presentation_id"] == draft["presentation_id"]
            and item["draft_presentation_version"] == draft["version"]
            and item["draft_sha256"] == draft["artifact_sha256"]]


def _progress(chapter):
    live = {}
    for item in chapter["history"]:
        if item["action"] == "present" and item.get("status") in {"pending", "confirmed"}:
            _need(item["stage"] not in live, "Duplicate live stage", "invalid_store")
            live[item["stage"]] = item
    dependencies, last = [], None
    for index, stage in enumerate(STAGES):
        item = live.get(stage)
        if item is not None:
            _need(item.get("dependencies") == dependencies and item.get("version") == _version(chapter, item),
                  "Presentation content or dependencies changed", "invalid_store")
            if stage == "review" and _policy(chapter)["teacher_handoff"] == "user_return":
                _need(any(returned["event_id"] == item.get("teacher_return_id")
                          and returned["returned_sha256"] == item.get("returned_sha256")
                          for returned in _teacher_returns(chapter)),
                      "Review lacks a teacher return bound to the confirmed draft", "invalid_store")
        if item is None or item["status"] == "pending":
            _need(not any(key in live for key in STAGES[index + 1:]),
                  "Future stage exists before prior confirmation", "invalid_store")
            return stage, item, dependencies, last
        confirmation = item.get("confirmation")
        _need(isinstance(confirmation, dict) and confirmation.get("event_id"),
              "Confirmed stage lacks author evidence", "invalid_store")
        dependencies.append({"stage": stage, "presentation_id": item["presentation_id"],
                             "version": item["version"], "confirmation_event_id": confirmation["event_id"]})
        last = item
    return None, None, dependencies, last


def _summary(chapter):
    stage, current, _, last = _progress(chapter)
    state = "final_confirmation_recorded" if stage is None else "awaiting_confirmation" if current else "awaiting_presentation"
    if not chapter["history"]:
        state = "not_started"
    returns = _teacher_returns(chapter)
    waiting_teacher = (stage == "review" and current is None
                       and _policy(chapter)["teacher_handoff"] == "user_return" and not returns)
    if waiting_teacher:
        state = "await_teacher_return"
    confirmed = None if last is None else {
        "stage": last["stage"], "presentation_id": last["presentation_id"],
        "presentation_version": last["version"], "artifact_sha256": last["artifact_sha256"],
        "confirmation": copy.deepcopy(last["confirmation"])}
    result = {"status": state, "chapter_status": state, "chapter_id": chapter["chapter_id"],
              "project_id": chapter["project_id"], "current_stage": stage,
              "presentation_id": current["presentation_id"] if current else None,
              "presentation_version": current["version"] if current else None,
              "artifact_sha256": current["artifact_sha256"] if current else None,
              "last_valid_confirmation": confirmed,
              "next_action": "record_existing_author_gate" if stage is None else "teacher_return" if waiting_teacher
                             else "confirm" if current else "present"}
    if returns:
        result["valid_teacher_returns"] = [
            {"teacher_return_id": item["event_id"], **{key: item[key] for key in
             ("returned_sha256", "draft_presentation_id", "draft_presentation_version", "draft_sha256")}}
            for item in returns]
    if current and "teacher_return_id" in current:
        result.update(teacher_return_id=current["teacher_return_id"], returned_sha256=current["returned_sha256"])
    return result


def status(payload, chapter_id):
    """Return resumable progress without modifying the supplied project payload."""
    return _summary(_chapter(payload, chapter_id))


def _evidence(event, require_actor=True):
    if require_actor or "actor_role" in event or "mode" in event:
        _need(event.get("actor_role") == "author" and event.get("mode") == "human",
              "Only an actual human author confirmation may advance a chapter")
    return {"event_id": event["event_id"],
            "author_quote": _text(event.get("author_quote"), "author_quote"),
            "source_ref": _text(event.get("source_ref"), "source_ref")}


def _final_decision(event):
    quote = re.sub(r"[\W_]+", "", event["author_quote"], flags=re.UNICODE)
    # A deliberately small, conservative check, not natural-language intent
    # authentication. Unrecognized or qualified wording stays pending.
    accepting = re.search(r"采纳|定稿|封稿|采用|(?:就用|用|保留)(?:这|此|当前|本)(?:一)?(?:版本|版|稿)", quote)
    qualified = re.search(r"(?:暂不|先不|还不|尚不|不能|不可|不要|不予|不想|不再|尚未|没有|拒绝|撤回|暂缓|先别|别|不|未)"
                          r".{0,6}(?:采纳|定稿|封稿|采用|就用|用|保留)", quote)
    _need(event.get("decision") == "accept_final_version" and accepting and not qualified,
          "Final requires unqualified explicit acceptance of the current artifact; clarify the author's wording")


def apply(payload, event, project_id):
    """Deterministically apply one event; failed events leave payload untouched.

    The caller owns CAS, event retry deduplication, locking and persistence.
    Author identity, quoted evidence and literary quality cannot be authenticated.
    """
    _need(isinstance(event, dict) and event.get("op") == "chapter_gate", "Expected chapter_gate event")
    _text(event.get("event_id"), "event_id")
    _need(isinstance(payload, dict) and isinstance(payload.get("data"), dict),
          "Store must contain a data object", "invalid_store")
    _text(payload.get("project_id"), "project_id")
    _need(payload["project_id"] == project_id, "Requested project differs from store", "project_mismatch")
    action, stage = event.get("action"), event.get("stage")
    if action == "configure":
        evidence = _evidence(event)
        policy = {key: event.get(key) for key in DEFAULT_POLICY}
        validate_policy(policy, "invalid_event")
        policy.update(**evidence, actor_role="author", mode="human")
        payload["data"]["chapter_workflow_policy"] = policy
        return {"project_id": project_id, "chapter_workflow_policy": copy.deepcopy(policy),
                "next_action": "present"}
    chapter = copy.deepcopy(_chapter(payload, event.get("chapter_id")))
    _need(action in ("present", "confirm", "reopen", "teacher_return")
          and (action == "teacher_return" or stage in STAGES), "Invalid chapter action or stage")
    current_stage, current, dependencies, _ = _progress(chapter)
    history = chapter["history"]
    _need(not any(item.get("event_id", item.get("presentation_id")) == event["event_id"] or
                  item.get("confirmation", {}).get("event_id") == event["event_id"]
                  for item in history + chapter.get("teacher_returns", [])),
          "Chapter event_id already exists; retries belong to the ledger", "duplicate_event")
    returned = None
    if action == "teacher_return":
        _need(_policy(chapter)["teacher_handoff"] == "user_return"
              and current_stage == "review" and current is None,
              "Teacher results may only be recorded while waiting for review presentation", "invalid_transition")
        draft = next(item for item in history if item["action"] == "present"
                     and item["stage"] == "draft" and item.get("status") == "confirmed")
        _need(event.get("draft_presentation_id") == draft["presentation_id"]
              and event.get("draft_presentation_version") == draft["version"]
              and event.get("draft_sha256") == draft["artifact_sha256"],
              "Teacher return must bind this chapter's current confirmed draft instance, version and hash",
              "invalid_transition")
        returned = {key: _text(event.get(key), key) for key in
                    ("returned_text", "source_ref", "teacher_name")}
        returned.update(event_id=event["event_id"], chapter_id=chapter["chapter_id"], project_id=project_id,
                        draft_presentation_id=draft["presentation_id"], draft_presentation_version=draft["version"],
                        draft_sha256=draft["artifact_sha256"],
                        returned_sha256=hashlib.sha256(returned["returned_text"].encode("utf-8")).hexdigest())
        chapter.setdefault("teacher_returns", []).append(returned)
    elif action == "reopen":
        evidence = _evidence(event, require_actor=False)
        reason = _text(event.get("reason"), "reason")
        _need(bool(history) and (current_stage is None or STAGES.index(stage) <= STAGES.index(current_stage)),
              "Cannot reopen a future or unstarted chapter stage", "invalid_transition")
        invalidated = []
        for item in history:
            if item["action"] == "present" and STAGES.index(item["stage"]) >= STAGES.index(stage):
                item.update(status="invalidated", invalidated_by=event["event_id"])
                invalidated.append(item["presentation_id"])
        history.append({"action": "reopen", "stage": stage, **evidence, "reason": reason,
                        "invalidated_presentation_ids": invalidated})
    else:
        _need(stage == current_stage, "Only the current stage may be presented or confirmed", "invalid_transition")
        if action == "present":
            if not history:
                chapter["workflow_policy"] = copy.deepcopy(validate_policy(
                    payload["data"].get("chapter_workflow_policy", DEFAULT_POLICY)))
            artifact = _artifact(event.get("artifact_sha256"), stage in {"draft", "revision", "final"})
            confirmed = {item["stage"]: item for item in history
                         if item["action"] == "present" and item["status"] == "confirmed"}
            bindings = {}
            if stage == "preparation" and (_policy(chapter)["visual_required"] or "visual_evidence" in event):
                bindings["visual_evidence"] = _visual_evidence(event.get("visual_evidence"))
            if stage == "review":
                draft_artifact = confirmed["draft"]["artifact_sha256"]
                _need(artifact is None or artifact == draft_artifact,
                      "Review must bind the confirmed draft artifact", "invalid_transition")
                artifact = draft_artifact
                if _policy(chapter)["teacher_handoff"] == "user_return":
                    teacher_return = next((item for item in _teacher_returns(chapter)
                                           if item["event_id"] == event.get("teacher_return_id")), None)
                    _need(teacher_return is not None,
                          "Review must name a teacher_return_id bound to the current confirmed draft",
                          "invalid_transition")
                    bindings.update(teacher_return_id=teacher_return["event_id"],
                                    returned_sha256=teacher_return["returned_sha256"])
            if stage == "final":
                _need(artifact == confirmed["revision"]["artifact_sha256"],
                      "Final must bind the confirmed revision artifact; reopen revision to change it",
                      "invalid_transition")
            record = {"action": "present", "stage": stage, "presentation_id": event["event_id"],
                      "content": _text(event.get("content"), "content"),
                      "source_ref": _text(event.get("source_ref"), "source_ref"),
                      "artifact_sha256": artifact,
                      "dependencies": dependencies, "status": "pending", **bindings}
            record["version"] = _version(chapter, record)
            if current:
                current.update(status="superseded", superseded_by=event["event_id"])
            history.append(record)
        else:
            _need(current is not None and event.get("presentation_id") == current["presentation_id"],
                  "Confirmation must name the current presentation instance", "invalid_transition")
            version = event.get("presentation_version", event.get("version"))
            _need(version == current["version"] and
                  ("version" not in event or event["version"] == version),
                  "Confirmation must bind the current presentation version", "invalid_transition")
            evidence = _evidence(event)
            evidence.update(actor_role="author", mode="human")
            if stage == "final":
                _artifact(current["artifact_sha256"], required=True)
                _final_decision(event)
                evidence["decision"] = "accept_final_version"
            current.update(status="confirmed", confirmation=evidence)
    result = _summary(chapter)
    if returned is not None:
        result.update(teacher_return_id=returned["event_id"], returned_sha256=returned["returned_sha256"])
    payload["data"].setdefault("chapter_confirmations", {})[chapter["chapter_id"]] = chapter
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    command = commands.add_parser("status")
    command.add_argument("store", type=Path)
    command.add_argument("--chapter-id", required=True)
    args = parser.parse_args(argv)
    try:
        # Import only for the read CLI: learning_loop imports this reducer.
        from learning_loop import read_store
        payload, store_version = read_store(args.store)
        print(json.dumps({**status(payload, args.chapter_id), "store_version": store_version},
                         ensure_ascii=False, indent=2, allow_nan=False))
        return 0
    except (OSError, ValueError, TypeError, KeyError) as exc:
        print(json.dumps({"status": "error", "code": getattr(exc, "code", "invalid_store"),
                          "message": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

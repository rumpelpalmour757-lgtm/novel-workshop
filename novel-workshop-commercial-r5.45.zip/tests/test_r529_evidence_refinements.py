#!/usr/bin/env python3
"""r5.29: three checks the continuity module did not have, from the rest of the reference increments.

The author sent the increment records that had been missing from the private technique card (nine further segments
of the same reference work, kept with their notes in the personal build only). Their forty-five writing techniques
already had homes in the modules and were not added. Their checks were compared with the modules one by one; most
were already there. Four were not; they now sit, with new examples, in the three paragraphs they belong to:

- how old or new a thing looks is its present state, not the date of what it stands for; before calling two
  statements contradictory, make sure they measure the same thing; a date worked out from several statements is
  recorded as worked out, and one that leans on a character's words counts only as that character's word;
- a slip, an omission or two accounts that do not match, caught by someone in the scene itself, is written
  conflict, not an error the author missed: both versions stay as written, and what follows is tracked;
- a cause given later for a quick change of mood joins up the story, but whether the change reads too fast is
  still judged by reading the scenes together.
"""
import os
from pathlib import Path
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
REFS = SKILL / "references"


def paragraph_with(text, phrase):
    return next((block for block in text.split("\n\n") if phrase in block), "")


class EvidenceRefinements(unittest.TestCase):
    def setUp(self):
        module = REFS / "continuity.md"
        self.text = module.read_text(encoding="utf-8") if module.is_file() else ""

    def test_a_things_look_is_not_the_date_of_the_event(self):
        part = paragraph_with(self.text, "时间和陈设的说法，先分清是哪一种再比对")
        for phrase in ("东西看着新还是旧，说的是它现在的状态，不是相关的事发生在哪一年",
                       "两句不自动互斥", "正文没写就不替作者补", "要报矛盾，先确认两句说的是同一个量"):
            self.assertIn(phrase, part)
        # The older sentences of the paragraph stay.
        self.assertIn("“二十年前”这类概数不当精确值", part)
        self.assertIn("前文没有逐件列出的东西，后来出现不自动算错", part)

    def test_a_worked_out_date_is_recorded_as_worked_out(self):
        part = paragraph_with(self.text, "时间和陈设的说法，先分清是哪一种再比对")
        for phrase in ("记成推算，写明凭的是哪几句", "用到了人物的说法，推出的结果也只算那个人物的说法",
                       "不当成正文写明的日期"):
            self.assertIn(phrase, part)

    def test_a_slip_caught_in_the_scene_is_written_conflict(self):
        part = paragraph_with(self.text, "区别明确矛盾、信息缺口与刻意悬念")
        for phrase in ("场内有人当场指出、追问的，是写出来的冲突，不是作者没察觉的错误",
                       "两个数照原文留着，不替作者统一", "记下谁说了什么、谁发现了，再追踪后文怎样对上",
                       "正文自己没注意到、场内也没有人反应的出入，才按矛盾或缺口报"):
            self.assertIn(phrase, part)
        self.assertIn("不把未揭晓的伏笔直接当漏洞", part)

    def test_a_later_cause_does_not_settle_how_it_reads(self):
        part = paragraph_with(self.text, "情绪也有交接")
        self.assertIn("刚发生背叛或伤亡，不无缘无故恢复日常语气", part)
        for phrase in ("后文交代了缘故", "因果就接上了", "仍要从前一场连着读下来判断", "补出的缘故不代替读感"):
            self.assertIn(phrase, part)

    def test_the_examples_are_new(self):
        # The workshop's own examples: a village stage and a counting-house clerk.
        self.assertIn("镇口的戏台，台板大半是新铺的", self.text)
        self.assertIn("“这台子搭起来五十八年了”", self.text)
        self.assertIn("两个伙计对着账房报同一车货", self.text)

    def test_each_check_is_written_once(self):
        texts = {path.name: path.read_text(encoding="utf-8") for path in REFS.glob("*.md")}
        for phrase in ("说的是它现在的状态，不是相关的事发生在哪一年", "推出的结果也只算那个人物的说法",
                       "是写出来的冲突，不是作者没察觉的错误", "补出的缘故不代替读感"):
            homes = sorted(name for name, text in texts.items() if phrase in text)
            self.assertEqual(homes, ["continuity.md"], phrase)

    def test_the_source_is_recorded(self):
        notes = (SKILL / "assets" / "third-party" / "SOURCE-NOTES.md").read_text(encoding="utf-8")
        row = next((line for line in notes.splitlines() if "第二十七至三十三段、第三十五、三十六段的增量记录" in line), "")
        self.assertIn("](../../references/continuity.md)", row)
        self.assertIn("四十五条写法都落在已有模块上，没有收入", row)
        self.assertIn("不含该作品的原文、短引、人物或设定", row)


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""r5.22: the same-tier order of the constitution follows what the author approved (NWC-1.2.1).

The 10-19 review of r5.21 (P2-C521-01): the approval of NWC-1.2 names the order "the author's latest explicit
decision > rules checked against the accepted text > specific rules > general rules > the newer on the same tier;
what cannot be settled goes to the author". The text that shipped put "newer beats older" before "specific beats
general", and the continuity module, the gate card and the registry followed it. That changes answers: an old
specific exception (one character may keep a form of address) and a newer general rule (one form of address for the
whole book) that never mentions the exception: by the approved order the exception stays; by the shipped order the
date decided first.

Now: 1 the author's latest explicit decision (said now, or a rules file that explicitly replaces, revokes or settles
a rule; a new version of the same rule replaces it; a new rule about something else revokes nothing); 2 checked rules
over unchecked descriptions; 3 specific over general (a general rule that does not name an old exception leaves it);
4 the newer, between rules of the same scope that are not versions of each other; 5 not settled: neither side, the
author decides. The text gives the three cases of the review, which must not get the same answer.
"""

import json
import os
from pathlib import Path
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
STEPS = ("1. **作者最新的明确决定。**", "2. **核实过的规定胜过没核实的描述。**", "3. **专门的胜过通用的。**",
         "4. **同样具体的，日期新的胜过旧的。**", "5. **还定不了的，两条都不执行。**")


def read(relative):
    return (SKILL / relative).read_text(encoding="utf-8")


class SameTierOrder(unittest.TestCase):
    def setUp(self):
        self.text = read("CONSTITUTION.md")
        self.tier = self.text.split("### 同一层之内", 1)[1].split("\n## ", 1)[0]

    def test_five_steps_in_the_approved_order(self):
        positions = [self.tier.index(step) for step in STEPS]
        self.assertEqual(positions, sorted(positions))
        self.assertLess(self.tier.index("专门的胜过通用的"), self.tier.index("日期新的胜过旧的"))
        registry = json.loads(read("assets/constitution-rules.json"))
        self.assertEqual(registry["same_tier_order"], ["author_latest_explicit_decision", "verified_prescription_over_description",
                                                       "specific_over_general", "newer_over_older_same_scope",
                                                       "undecided_goes_to_author"])
        # NWC-1.3 (2026-10-22, CON-011), NWC-1.4 (2026-10-23, CON-012) and NWC-1.5 (2026-10-23, r5.34, CON-011 amended)
        # did not touch the same-tier order.
        self.assertEqual(registry["version"], "NWC-1.7")  # r5.49: NWC-1.7 amends CON-011; the same-tier order is unchanged

    def test_step_one_is_only_what_the_author_said_explicitly(self):
        step = self.tier.split(STEPS[0], 1)[1].split("\n2. ", 1)[0]
        for phrase in ("当前消息里明说的", "明说取代、撤销、改定了哪一条", "同一条规则出了新版本，就是取代了旧版本",
                       "只是新写了一条别的规则，没有点到旧的那条，不算撤销旧的", "描述正文的话不是决定，归第 2 步"):
            self.assertIn(phrase, step)

    def test_a_general_rule_does_not_revoke_a_specific_exception_it_does_not_name(self):
        step = self.tier.split(STEPS[2], 1)[1].split("\n4. ", 1)[0]
        self.assertIn("新定的全书通则没有明说撤销旧的具体例外，例外照旧有效", step)
        step = self.tier.split(STEPS[3], 1)[1].split("\n5. ", 1)[0]
        self.assertIn("谁也不是谁的新版本", step)

    def test_the_three_cases_get_three_answers(self):
        example = next(line for line in self.tier.splitlines() if line.startswith("同一件事三种情形"))
        for phrase in ("却没有提这个例外——例外照旧（第 3 步）", "把同一条口径改了写法——按新版（第 1 步）",
                       "“那个例外不要了”——撤销（第 1 步）"):
            self.assertIn(phrase, example)

    def test_the_correction_is_recorded_with_the_approved_order(self):
        head = self.text.split("## 一、优先顺序", 1)[0]
        for phrase in ("NWC-1.2.1", "P2-C521-01", "作者最新的明确决定 > 对已采纳正文核实过的规则 > 具体规则 > 通用规则 > 同层里日期新的"):
            self.assertIn(phrase, head)


class EveryPlaceFollows(unittest.TestCase):
    def test_card_module_and_template(self):
        card = read("assets/delivery-gate-card.md")
        item = card.split("0. **优先顺序。**", 1)[1].split("\n1. ", 1)[0]
        order = ["作者明说取代、撤销的为准", "规定照办", "专门的胜通用的", "新通则不废旧例外", "同样具体才看新旧", "两条都不照办"]
        self.assertEqual([item.index(p) for p in order], sorted(item.index(p) for p in order))
        section = read("references/continuity.md").split("## 规则打架时", 1)[1].split("\n## ", 1)[0]
        for phrase in ("**裁决按五步走", "1. 作者明说了没有。", "2. 规定还是描述。", "3. 专门的还是通用的。", "4. 同样具体的，看新旧。",
                       "5. 还定不了，两条都不执行。", "不算撤销", "这个称呼留着", "第 5 步不能由工坊定"):
            self.assertIn(phrase, section)
        # P3 of the review: "only optional" on finalized chapters is limited to what the author's own limit allows.
        for phrase in ("只是语感、措辞上可改可不改的只记可选", "限定里仍要求改的那类", "照样改"):
            self.assertIn(phrase, section)
        template = json.loads(read("assets/rule-conflicts-template.json"))
        self.assertIn("rule_applied 1 至 4，第 5 步只能作者定", template["note"])


if __name__ == "__main__":
    unittest.main()

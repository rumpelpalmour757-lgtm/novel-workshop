#!/usr/bin/env python3
"""Record actual writing/feedback events with project-scoped conditional saves.

This local ledger does not call models, write fiction, train parameters, certify
external sources, human identity, reviewer independence or literary quality.
The host executes the writing/review and continues to obey workflow_guard.
"""
import argparse
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile

if __name__ == "__main__":
    sys.dont_write_bytecode = True  # the sibling modules load by path; keep the skill folder free of __pycache__


def _sibling(name):
    spec = importlib.util.spec_from_file_location("_learning_loop_" + name,
                                                 Path(__file__).with_name(name + ".py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


memory = _sibling("demonstration_memory")
state = _sibling("project_state")
chapter_gate = _sibling("chapter_gate")
NAMESPACES = ("demonstration_learning", "demonstrations", "learning_runs", "learning_events", "chapter_confirmations",
              "chapter_workflow_policy")
OPS = {"configure", "start", "plan", "draft", "review", "decide", "revise",
       "finish", "stop", "author_accept", "learn", "case_status", "case_accept", "chapter_gate"}
CLOSED_CASE = {"rejected", "retired"}
SWITCH_OFF = ("data.demonstration_learning.enabled is false: example recording is the author's switch; "
              "turn it on with configure enabled:true and the author's own words")


class LoopError(ValueError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def _need(condition, message, code="invalid_event"):
    if not condition:
        raise LoopError(code, message)


def _text(value, name):
    _need(isinstance(value, str) and bool(value.strip()), name + " must be non-empty text")
    return value


def _strings(value, name, nonempty=False):
    _need(isinstance(value, list) and all(isinstance(x, str) and x.strip() for x in value),
          name + " must be an array of non-empty strings")
    _need(not nonempty or bool(value), name + " must not be empty")
    _need(len(value) == len(set(value)), name + " must not contain duplicates")
    return value


def _encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def _hash(value):
    return hashlib.sha256(value if isinstance(value, bytes) else value.encode("utf-8")).hexdigest()


def _stub(text):
    return {"sha256": _hash(text), "chars": len(text)}


def _validate(payload):
    _need(isinstance(payload, dict) and isinstance(payload.get("data"), dict),
          "Store must contain a data object", "invalid_store")
    _need(isinstance(payload.get("project_id"), str) and payload["project_id"].strip(),
          "Store must declare its project_id", "invalid_store")
    errors, _, config = memory.validate(payload)
    _need(not errors, "; ".join(errors), "invalid_store")
    for key in NAMESPACES:
        _need(isinstance(payload["data"].get(key, {}), dict), key + " must be an object", "invalid_store")
    if "chapter_workflow_policy" in payload["data"]:
        try:
            chapter_gate.validate_policy(payload["data"]["chapter_workflow_policy"])
        except chapter_gate.GateError as exc:
            raise LoopError(exc.code, str(exc)) from exc
    _need(type(config.get("loop_enabled", False)) is bool,
          "loop_enabled must be boolean", "invalid_store")
    maximum = config.get("max_revisions", 2)
    _need(type(maximum) is int and 1 <= maximum <= 5,
          "max_revisions must be an integer from 1 to 5", "invalid_store")
    return payload


def _decode(raw, path):
    text = raw.decode("utf-8")
    marked = (Path(path).suffix.lower() in {".md", ".markdown"}
              or not text.lstrip().startswith("{"))
    if marked:
        payload, start, end = memory.markdown_payload(text)
        _need(isinstance(payload, dict) and type(payload.get("schema_version")) is int
              and payload["schema_version"] == 1 and type(payload.get("revision")) is int
              and payload["revision"] >= 0, "Invalid Markdown learning schema", "invalid_store")
        return _validate(payload), "sha256:" + _hash(raw), (text, start, end)
    payload = state._validate(memory._loads(text))
    return _validate(payload), payload["version"], None


def read_store(path):
    """Read existing authority; versions are strict JSON CAS or whole-file SHA."""
    try:
        with state._locked(path, exclusive=False) as resolved:
            payload, version, _ = _decode(resolved.read_bytes(), resolved)
            return payload, version
    except state.StateError as exc:
        raise LoopError(exc.code, str(exc)) from exc
    except (OSError, UnicodeError, TypeError, ValueError) as exc:
        if isinstance(exc, LoopError):
            raise
        raise LoopError("invalid_store", str(exc)) from exc


def _enabled(payload):
    config = payload["data"].get("demonstration_learning", {})
    return config.get("enabled", False) and config.get("loop_enabled", False)


def _missing_switches(payload):
    config = payload["data"].get("demonstration_learning", {})
    return [key for key in ("enabled", "loop_enabled") if not config.get(key, False)]


def _author_words(value, label):
    """A declared record that the author said this in person; never authenticated."""
    _need(isinstance(value, dict) and value.get("actor_role") == "author" and value.get("mode") == "human",
          label + " must be the author's own words: actor_role:author, mode:human, quote, source_ref",
          "author_evidence")
    return {"quote": _text(value.get("quote"), label + " quote"),
            "ref": _text(value.get("source_ref"), label + " source_ref")}


def _accepting(quote):
    """Apply the chapter gate's own final-acceptance wording check to this quote.

    That check is deliberately small and conservative; whatever it leaves
    pending ("继续", refusals, vague replies) is not recorded as acceptance here.
    """
    check = getattr(chapter_gate, "_final_decision", None)
    _need(check is not None, "The chapter gate's acceptance check is unavailable", "not_an_acceptance")
    try:
        outcome = check({"event_id": "acceptance-wording", "op": "chapter_gate", "action": "confirm",
                         "stage": "final", "decision": "accept_final_version", "author_quote": quote,
                         "actor_role": "author", "mode": "human"})
    except chapter_gate.GateError:
        outcome = False
    _need(outcome is not False,
          "Author acceptance needs the author's unqualified, explicit acceptance of this text; "
          "words that only move on, refuse or stay vague are not recorded. Ask the author.",
          "not_an_acceptance")


def _chapter_record(payload, chapter_id):
    chapters = payload["data"].get("chapter_confirmations", {})
    record = chapters.get(chapter_id) if isinstance(chapters, dict) and isinstance(chapter_id, str) else None
    return record if isinstance(record, dict) else None


def _chapter_linked(payload, run):
    """The run names a chapter, and this project runs the chapter gate for it."""
    chapter_id = run.get("chapter_id")
    return bool(chapter_id) and ("chapter_workflow_policy" in payload["data"]
                                 or _chapter_record(payload, chapter_id) is not None)


def _chapter_summary(payload, chapter_id):
    try:
        return chapter_gate.status(payload, chapter_id)
    except chapter_gate.GateError as exc:
        raise LoopError(exc.code, str(exc)) from exc


def _author_handoff(payload, run):
    """True only where this chapter's draft goes to the teacher through the author.

    The chapter gate decides which policy a chapter follows (its default, the
    project's choice, or the author's word on this chapter); its status says so.
    """
    if not _chapter_linked(payload, run):
        return False
    policy = _chapter_summary(payload, run["chapter_id"]).get("workflow_policy")
    if not isinstance(policy, dict):  # a gate that does not report it: read the record as it does
        record = _chapter_record(payload, run["chapter_id"])
        try:
            policy = (chapter_gate._policy(record) if record is not None
                      else payload["data"].get("chapter_workflow_policy") or chapter_gate.DEFAULT_POLICY)
        except chapter_gate.GateError as exc:
            raise LoopError(exc.code, str(exc)) from exc
    return policy.get("teacher_handoff") == "user_return"


def _confirmed_stage(payload, chapter_id, stage):
    """The presentation of this stage that the chapter gate counts as confirmed, or None.

    The gate reads its own record: a stage it does not count as confirmed
    (still pending, reopened, or lacking the author's evidence) does not count here.
    """
    finder = getattr(chapter_gate, "confirmed_presentation", None)
    try:
        if finder is not None:
            return finder(payload, chapter_id, stage)
        current = chapter_gate.status(payload, chapter_id).get("current_stage")
    except chapter_gate.GateError as exc:
        raise LoopError(exc.code, str(exc)) from exc
    stages = chapter_gate.STAGES
    if current is not None and (current not in stages or stages.index(current) <= stages.index(stage)):
        return None
    record = _chapter_record(payload, chapter_id) or {}
    return next((item for item in record.get("history", []) if isinstance(item, dict)
                 and item.get("action") == "present" and item.get("stage") == stage
                 and item.get("status") == "confirmed"), None)


def _lineage(run):
    """The confirmed chapter draft a run started from; older runs: their first draft."""
    if "chapter_draft_sha256" in run:
        return run["chapter_draft_sha256"]
    drafts = run.get("drafts")
    first = drafts[0] if isinstance(drafts, list) and drafts else None
    return first.get("sha256") if isinstance(first, dict) else None


def _confirmed_plan(payload, run):
    """The author-confirmed review-stage plan that binds one of this run's drafts."""
    item = _confirmed_stage(payload, run["chapter_id"], "review")
    # The drafts of this run, and the confirmed draft a later round descends from.
    known = {draft["sha256"] for draft in run["drafts"]} | {run.get("chapter_draft_sha256")}
    if item is None or item.get("artifact_sha256") not in known - {None}:
        return None
    return {"chapter_id": run["chapter_id"], "presentation_id": item["presentation_id"],
            "presentation_version": item["version"],
            "confirmation_event_id": (item.get("confirmation") or {}).get("event_id")}


def _final_confirmed(payload, chapter_id, sha256):
    summary = _chapter_summary(payload, chapter_id)
    last = summary.get("last_valid_confirmation") or {}
    return (summary.get("status") == "final_confirmation_recorded" and last.get("stage") == "final"
            and last.get("artifact_sha256") == sha256)


PLAN_FIRST = ("This run revises a chapter whose draft goes to the teacher through the author: decide and "
              "revise wait until the author has confirmed the chapter gate's review stage for this run's "
              "draft (bind the gate to the draft_sha256 that draft returned). If the chapter was reopened, "
              "stop this run and start another from the newly confirmed draft.")
FINAL_FIRST = ("This text belongs to a chapter under the chapter gate: record the author's final acceptance "
               "there first (chapter_gate confirm, stage final) for this same SHA256, then repeat this event.")
DRAFT_FIRST = ("A run with chapter_id revises that chapter's author-confirmed draft: start it after the chapter "
               "gate has the author's confirmation of the draft stage, with input_text exactly that draft "
               "(the SHA256 of input_text must equal the confirmed draft's artifact_sha256), or exactly the "
               "final text of an earlier finished run of this chapter that came from that same draft.")
DRAFT_IS_INPUT = ("In a run with chapter_id the first draft is the confirmed draft it started from: "
                  "register input_text again, word for word.")
FINISHED = "Run is already finished"


def _reviews(run):
    current = run.get("current_draft", {}).get("sha256")
    index = len(run["drafts"]) - 1
    return [run["reviews"][key] for key in run.get("review_order", [])
            if run["reviews"][key]["draft_sha256"] == current
            and run["reviews"][key].get("draft_index", index) == index]


_withdrawn = memory.withdrawn


def _author_objections(run):
    """Author reviews that reject the present text and that the author has not taken back
    (decide with withdrawal); see demonstration_memory.open_author_objections."""
    return memory.open_author_objections(run, (run.get("current_draft") or {}).get("sha256"))


def _earlier_objections(payload, run):
    """The author's objections to an earlier text of this run, left unanswered on
    the current one; see demonstration_memory.earlier_author_objections."""
    return memory.earlier_author_objections(run, payload["data"].get("learning_runs") if payload else None)


def _late_author_word(run, op, event):
    """What a finished run still takes: the author's later objection to its text,
    and the author's own words taking such an objection back."""
    if op == "review":
        reviewer = event.get("reviewer")
        return isinstance(reviewer, dict) and reviewer.get("role") == "author" and event.get("verdict") != "pass"
    if op == "decide":
        return event.get("review_id") in _author_objections(run)
    return False


def _actionable(run):
    return {r["review_id"] for r in _reviews(run)} | set(_author_objections(run))


def _deferred(run):
    return [{"review_id": key, "finding_id": item["finding_id"]}
            for key in run.get("review_order", []) for item in run["decisions"].get(key, [])
            if item["decision"] == "defer"]


def _pass(run):
    reviews = _reviews(run)
    if not reviews or reviews[-1]["verdict"] != "pass":
        return None
    latest = reviews[-1]
    if not set(run["pending_rechecks"]).issubset(latest["rechecks"]):
        return None
    # A pass cannot erase another review's findings without an explicit decision.
    for review in reviews[:-1]:
        if review["findings"] and review["review_id"] not in run["decisions"]:
            return None
        if review["review_id"] in latest["rechecks"]:
            continue
        # A blocked review that lists nothing cannot be decided item by item:
        # only a pass that names it as rechecked may stand after it.
        if review["verdict"] != "pass" and not review["findings"] and not _withdrawn(run, review):
            return None
        if any(x["decision"] in {"adopt", "defer"}
               for x in run["decisions"].get(review["review_id"], [])):
            return None
    return latest


def _teacher_pass(run):
    reviews = [r for r in _reviews(run) if r["reviewer"]["role"] == "teacher"]
    if reviews and reviews[-1]["verdict"] == "pass" and set(run["pending_rechecks"]).issubset(reviews[-1]["rechecks"]):
        return reviews[-1]
    return None


def _live_cases(run, cases):
    return [key for key in run.get("learned_case_ids", [])
            if key in cases and cases[key].get("status") not in CLOSED_CASE]


def _next(run, payload=None):
    if run["status"] == "stopped":
        return "resume_original_workflow"
    if run["status"] == "finished":
        if _author_objections(run):
            # The author objected to the finished text: ask for the author's own words
            # taking it back, or leave this run here and change the text in a new one.
            return "ask_author_or_stop"
        cases = payload["data"].get("demonstrations", {}) if payload else {}
        live = _live_cases(run, cases)
        if not live:
            return "learn"
        # A recorded case waits for the author's own explicit acceptance (case_accept),
        # also when an acceptance it had no longer covers its text.
        data = payload["data"] if payload else {}
        return "complete" if any(cases[key]["status"] == "author_accepted"
                                 and not memory.approval_problems(cases[key], data) for key in live) \
            else "await_author_acceptance"
    if run["status"] == "started":
        return "plan"
    if not run.get("current_draft"):
        return "draft"
    current = _reviews(run)
    if not current:
        return "review"
    waiting = payload is not None and _author_handoff(payload, run) and _confirmed_plan(payload, run) is None
    if any(r["findings"] and r["review_id"] not in run["decisions"] for r in current):
        return "await_author_plan_confirmation" if waiting else "decide"
    objections = _author_objections(run)
    if _pass(run) and not objections:
        return "finish"
    if any(x["decision"] == "adopt" for key in _actionable(run) for x in run["decisions"].get(key, [])):
        return "await_author_plan_confirmation" if waiting else "revise_or_stop"
    return "ask_author_or_stop" if objections else "review_or_stop"


def status(path):
    payload, version = read_store(path)
    data = payload["data"]
    active = [key for key, run in data.get("learning_runs", {}).items()
              if run.get("status") not in {"finished", "stopped"}]
    result = {"status": "enabled" if _enabled(payload) else "disabled",
              "enabled": data.get("demonstration_learning", {}).get("enabled", False),
              "loop_enabled": data.get("demonstration_learning", {}).get("loop_enabled", False),
              "project_id": payload["project_id"], "version": version,
              "case_count": len(data.get("demonstrations", {})),
              "run_count": len(data.get("learning_runs", {})), "active_runs": active,
              "next_action": "context" if _enabled(payload) else "resume_original_workflow"}
    if not _enabled(payload):
        result["missing_switches"] = _missing_switches(payload)
    stale = [key for key, case in data.get("demonstrations", {}).items()
             if memory.approval_problems(case, data)]
    if stale:
        result["stale_approval_case_ids"] = stale
    return result


def _context(payload, project_id, task, tags, excluded, evaluation, limit, case_ids=None):
    _need(payload["project_id"] == project_id, "Requested project differs from store", "project_mismatch")
    _text(task, "task")
    _strings(list(tags), "tags")
    _strings(list(excluded), "excluded groups")
    _need(type(limit) is int and 1 <= limit <= 3, "limit must be 1–3")
    _need(type(evaluation) is bool, "evaluation must be boolean")
    _need(not evaluation or bool(excluded), "Evaluation requires the current group to be excluded")
    cases, rest, stale = [], [], {}
    if _enabled(payload):
        try:
            cases, rest, stale = memory.choose(payload["data"].get("demonstrations", {}), project_id, task,
                                               tags, excluded, limit, case_ids, payload["data"])
        except ValueError as exc:
            raise LoopError("invalid_event", "case_ids: " + str(exc)) from exc
    return {"status": "selected" if _enabled(payload) else "disabled",
            "cases": copy.deepcopy(cases), **memory.describe(cases, rest, stale, tags),
            "scope": "examples_for_context_not_story_facts"}


def context(path, project_id, task, tags=(), excluded=(), evaluation=False, limit=3, case_ids=None):
    payload, version = read_store(path)
    return {**_context(payload, project_id, task, tags, excluded, evaluation, limit, case_ids),
            "version": version}


def _actor(value):
    _need(isinstance(value, dict), "actor must be an object")
    return {key: _text(value.get(key), "actor." + key) for key in ("name", "context_id")}


def _case_available(case_id, cases, frozen, data):
    return (case_id in cases and cases[case_id]["status"] in memory.ELIGIBLE
            and _hash(_encode(cases[case_id])) == frozen["case_sha256"]
            and not memory.approval_problems(cases[case_id], data))


def _checked(value, required, name, default):
    """Maps are canonical; string arrays explicitly confirm the named checks."""
    if isinstance(value, list):
        _strings(value, name)
        value = {item: default for item in value}
    _need(isinstance(value, dict) and all(isinstance(k, str) and type(v) is bool for k, v in value.items()),
          name + " must map each condition/exception to a boolean (or list its checked text)")
    _need(set(required).issubset(value), name + " must cover every frozen condition/exception")
    return copy.deepcopy(value)


def _case_accept(payload, event, project_id):
    """Add the author's later explicit acceptance to a case that already exists."""
    data = payload["data"]
    cases = data["demonstrations"]
    case_id = _text(event.get("case_id"), "case_id")
    _need(case_id in cases, "Unknown case_id")
    case = cases[case_id]
    _need(case["project_id"] == project_id, "Case belongs to another project", "project_mismatch")
    # An author-accepted case takes a new acceptance only when the old one no longer covers its text.
    _need(case["status"] in {"candidate", "teacher_approved"}
          or (case["status"] == "author_accepted" and memory.approval_problems(case, data)),
          "Only a candidate or teacher-approved case, or one whose acceptance no longer covers its text, "
          "can receive the author's acceptance", "invalid_transition")
    _need(event.get("case_sha256") == case["hashes"]["after"],
          "case_sha256 must be the SHA256 of this case's after text (its hashes.after)")
    words = _author_words(event, "case_accept")
    _accepting(words["quote"])
    run = data.get("learning_runs", {}).get(case["source"].get("run_id"))
    objections = memory.open_author_objections(run, case["hashes"]["after"]) if isinstance(run, dict) else []
    _need(not objections, "The author's objection to this text is still open (" + ", ".join(objections or [""]) +
          "): record the author's own later words with decide and withdrawal first", "author_objection")
    if isinstance(run, dict) and _chapter_linked(payload, run):
        _need(_final_confirmed(payload, run["chapter_id"], case["hashes"]["after"]), FINAL_FIRST,
              "chapter_gate_first")
    earlier = {"status": case["status"], "replaced_by": event["event_id"]}
    if isinstance(case.get("author_acceptance"), dict):
        earlier["author_acceptance"] = copy.deepcopy(case["author_acceptance"])
    case.setdefault("status_history", []).append(earlier)
    case["status"] = "author_accepted"
    case["author_acceptance"] = {**words, "draft_sha256": case["hashes"]["after"], "event_id": event["event_id"]}
    if isinstance(run, dict):
        # Reviews the run held when the author accepted; a later objection voids this acceptance.
        case["author_acceptance"]["run_review_count"] = len(run.get("review_order", []))
    return {"case_id": case_id, "case_status": "author_accepted", "next_action": "complete"}


def _decide(payload, run, event):
    review_id = _text(event.get("review_id"), "review_id")
    review = run["reviews"].get(review_id)
    _need(review and review_id in _actionable(run), "decide requires current review")
    decisions = copy.deepcopy(event.get("decisions"))
    _need(isinstance(decisions, list) and all(isinstance(x, dict) for x in decisions), "decisions must be an array")
    ids = [x.get("finding_id") for x in decisions]
    _need(len(ids) == len(set(ids)) and set(ids) == {x["id"] for x in review["findings"]},
          "decide must cover every finding exactly once")
    # The author's own objection is not the host's to dismiss.
    objection = review["reviewer"]["role"] == "author" and review["verdict"] != "pass"
    refusal = ("The author's own objection can only be adopted, or taken back in the author's later words: "
               "withdrawal:{actor_role:author,mode:human,quote,source_ref}")
    finished = run["status"] == "finished"
    for decision in decisions:
        _need(decision.get("decision") in {"adopt", "decline", "defer"}, "Invalid finding decision")
        _text(decision.get("reason"), "decision reason")
        # A finished text is not revised in its run; it only takes the author's own withdrawal.
        _need(not finished or decision["decision"] != "adopt",
              FINISHED + ": to change this text, start another run from it", "invalid_transition")
        if objection and decision["decision"] != "adopt":
            _need("withdrawal" in decision, refusal, "author_objection")
        if "withdrawal" in decision:
            _need(objection and decision["decision"] != "adopt",
                  "withdrawal only belongs to an author's objection that is not adopted")
            decision["withdrawal"] = _author_words(decision["withdrawal"], "withdrawal")
    whole = None
    if objection and not review["findings"]:
        _need("withdrawal" in event, refusal, "author_objection")
    if "withdrawal" in event:
        _need(objection and not review["findings"],
              "An event-level withdrawal only belongs to an author's objection that lists no findings")
        whole = {**_author_words(event["withdrawal"], "withdrawal"), "event_id": event["event_id"]}
    plan = None
    # The author's own withdrawal is not a host decision on the teacher's plan.
    by_host = any("withdrawal" not in decision for decision in decisions) or (not decisions and whole is None)
    if by_host and _author_handoff(payload, run):
        plan = _confirmed_plan(payload, run)
        _need(plan is not None, PLAN_FIRST, "chapter_gate_first")
        for key in ("presentation_id", "presentation_version"):
            _need(event.get("review_" + key, plan[key]) == plan[key],
                  "review_" + key + " is not the author-confirmed review plan of this chapter", "chapter_gate_first")
    if review_id in run["decisions"]:
        # Replaced before any revision is built on it; the earlier record stays readable.
        earlier = {"decisions": run["decisions"][review_id], "replaced_by": event["event_id"]}
        if review_id in run.get("decision_plans", {}):
            earlier["plan"] = run["decision_plans"][review_id]
        run.setdefault("decision_history", {}).setdefault(review_id, []).append(earlier)
    run["decisions"][review_id] = decisions
    if plan is not None:
        run.setdefault("decision_plans", {})[review_id] = plan
    if whole is not None:
        run.setdefault("review_withdrawals", {})[review_id] = whole
    if not finished:
        run["status"] = "decided"


def _apply(payload, event, project_id):
    if event["op"] == "chapter_gate":
        try:
            return chapter_gate.apply(payload, event, project_id)
        except chapter_gate.GateError as exc:
            raise LoopError(exc.code, str(exc)) from exc
    data = payload["data"]
    config = data.setdefault("demonstration_learning", {"enabled": False})
    cases = data.setdefault("demonstrations", {})
    runs = data.setdefault("learning_runs", {})
    op = event["op"]
    if op == "configure":
        _need(type(event.get("loop_enabled")) is bool, "loop_enabled must be boolean")
        if "enabled" in event:
            _need(type(event["enabled"]) is bool, "enabled must be boolean")
            if event["enabled"] and not config.get("enabled", False):
                config["enabled_by"] = {**_author_words(event, "configure enabled:true"),
                                        "event_id": event["event_id"]}
            config["enabled"] = event["enabled"]
        config["loop_enabled"] = event["loop_enabled"]
        if "max_revisions" in event:
            value = event["max_revisions"]
            _need(type(value) is int and 1 <= value <= 5, "max_revisions must be 1–5")
            config["max_revisions"] = value
        result = {"next_action": "context" if _enabled(payload) else "resume_original_workflow"}
        if config["loop_enabled"] and not config.get("enabled", False):
            result["blocked_by"] = SWITCH_OFF
        return result
    if op == "case_status":
        case_id = _text(event.get("case_id"), "case_id")
        _need(case_id in cases, "Unknown case_id")
        _need(cases[case_id]["project_id"] == project_id, "Case belongs to another project", "project_mismatch")
        _need(event.get("status") in {"rejected", "retired"}, "Only rejected/retired case status is permitted")
        cases[case_id]["status"] = event["status"]
        cases[case_id]["status_reason"] = _text(event.get("reason"), "reason")
        return {"case_id": case_id, "next_action": "context" if _enabled(payload) else "resume_original_workflow"}
    if op == "case_accept":
        return _case_accept(payload, event, project_id)
    _need(_enabled(payload), "Learning loop is disabled (" + (
        SWITCH_OFF if "enabled" in _missing_switches(payload)
        else "data.demonstration_learning.loop_enabled is false") + "); continue the original workflow", "disabled")
    run_id = _text(event.get("run_id"), "run_id")
    if op == "start":
        _need(run_id not in runs, "run_id already exists", "invalid_transition")
        fields = {key: _text(event.get(key), key) for key in
                  ("task", "group_id", "input_text", "source_ref")}
        fields["tags"] = _strings(event.get("tags"), "tags")
        fields["constraints"] = _strings(event.get("constraints"), "constraints")
        excluded = _strings(event.get("excluded_groups", []), "excluded_groups")
        excluded = list(dict.fromkeys(excluded + [fields["group_id"]]))
        # Named cases may be any approved case that passes the filter, three at most.
        wanted = _strings(event["case_ids"], "case_ids") if "case_ids" in event else None
        selected = _context(payload, project_id, fields["task"], fields["tags"], excluded,
                            event.get("evaluation", False), event.get("limit", 3), wanted)["cases"]
        # The case stays in the store; the run binds it by hash and keeps no second copy of its texts.
        frozen = [{**c, "before": _stub(c["before"]), "after": _stub(c["after"]), "case_sha256": _hash(_encode(c))}
                  for c in selected]
        run = {"run_id": run_id, "project_id": project_id, **fields,
               "selected_cases": frozen, "applications": [], "checks": [], "drafts": [],
               "reviews": {}, "review_order": [], "decisions": {}, "pending_rechecks": [],
               "revision_count": 0, "max_revisions": config.get("max_revisions", 2),
               "status": "started", "learned_case_ids": []}
        if "workflow_guard_ref" in event:
            run["workflow_guard_ref"] = _text(event["workflow_guard_ref"], "workflow_guard_ref")
        if "chapter_id" in event:
            # This run revises that chapter's author-confirmed draft under the chapter gate.
            run["chapter_id"] = _text(event["chapter_id"], "chapter_id")
            if _chapter_linked(payload, run):
                confirmed = (_confirmed_stage(payload, run["chapter_id"], "draft") or {}).get("artifact_sha256")
                # A later round may start from an earlier round's final text of this same confirmed draft.
                earlier = {item.get("final_sha256") for item in runs.values()
                           if isinstance(item, dict) and item.get("status") == "finished"
                           and item.get("project_id") == project_id and item.get("chapter_id") == run["chapter_id"]
                           and _lineage(item) == confirmed}
                _need(confirmed is not None and _hash(fields["input_text"]) in {confirmed} | earlier,
                      DRAFT_FIRST, "chapter_gate_first")
                run["chapter_draft_sha256"] = confirmed
        runs[run_id] = run
    else:
        _need(run_id in runs, "Unknown run_id", "invalid_transition")
        run = runs[run_id]
        _need(run["project_id"] == project_id, "Run belongs to another project", "project_mismatch")
        _need(run["status"] != "stopped", "Run is stopped", "invalid_transition")
        _need(run["status"] != "finished" or op in {"learn", "author_accept"} or _late_author_word(run, op, event),
              FINISHED, "invalid_transition")
        if op == "plan":
            _need(run["status"] == "started", "plan must follow start", "invalid_transition")
            applications = copy.deepcopy(event.get("applications"))
            _need(isinstance(applications, list) and all(isinstance(x, dict) for x in applications),
                  "applications must be an array of objects")
            by_id = {c["id"]: c for c in run["selected_cases"]}
            ids = [x.get("case_id") for x in applications]
            _need(len(ids) == len(set(ids)) and set(ids) == set(by_id), "plan must cover every frozen case exactly once")
            for item in applications:
                case = by_id[item["case_id"]]
                _need(item.get("decision") in {"apply", "adapt", "decline"}, "Invalid application decision")
                _text(item.get("reason"), "application reason")
                conditions = _checked(item.get("conditions_checked"), case["when"], "conditions_checked", True)
                exceptions = _checked(item.get("exceptions_checked"), case["except"], "exceptions_checked", False)
                applicable = all(conditions[c] for c in case["when"]) and not any(exceptions[e] for e in case["except"])
                _need(applicable or item["decision"] == "decline", "Unmet condition or matching exception requires decline")
                _need(_case_available(item["case_id"], cases, case, data) or item["decision"] == "decline",
                      "Frozen case changed or is no longer approved; its decision must be decline")
                item["conditions_checked"], item["exceptions_checked"] = conditions, exceptions
            run.update(applications=copy.deepcopy(applications), checks=_strings(event.get("checks"), "checks"), status="planned")
        elif op in {"draft", "revise"}:
            if op == "draft":
                _need(run["status"] == "planned" and not run["drafts"], "draft must follow plan once", "invalid_transition")
                frozen = {c["id"]: c for c in run["selected_cases"]}
                _need(all(item["decision"] == "decline"
                          or _case_available(item["case_id"], cases, frozen[item["case_id"]], data)
                          for item in run["applications"]),
                      "An applied case changed or was retired/rejected; stop and start again", "invalid_transition")
            else:
                _need(run.get("current_draft"), "No draft to revise", "invalid_transition")
                _need(event.get("parent_sha256") == run["current_draft"]["sha256"], "parent_sha256 is not current draft")
                review_id = _text(event.get("review_id"), "review_id")
                review = run["reviews"].get(review_id)
                _need(review and review_id in _actionable(run), "Revision requires current-draft review")
                adopted = [x["finding_id"] for x in run["decisions"].get(review_id, []) if x["decision"] == "adopt"]
                _need(adopted, "Revision requires at least one explicitly adopted finding")
                feedback = [r["review_id"] for r in _reviews(run) if r["findings"]]
                _need(all(key in run["decisions"] for key in feedback),
                      "Decide every current-draft review before revision")
                if _author_handoff(payload, run):
                    _need(_confirmed_plan(payload, run) is not None, PLAN_FIRST, "chapter_gate_first")
                rechecks = [r["review_id"] for r in _reviews(run) if r["verdict"] != "pass"] + _author_objections(run)
                cap = min(run["max_revisions"], config.get("max_revisions", 2))
                _need(run["revision_count"] < cap, "Revision limit reached; stop with a reason", "limit_reached")
                run["revision_count"] += 1
                run["pending_rechecks"] = list(dict.fromkeys(run["pending_rechecks"] + rechecks))
            text = _text(event.get("text"), "text")
            _need(op != "draft" or "chapter_id" not in run or text == run["input_text"], DRAFT_IS_INPUT)
            draft = {"text": text, "sha256": _hash(text),
                     "source_ref": _text(event.get("source_ref"), "source_ref"), "actor": _actor(event.get("actor"))}
            if op == "revise":
                draft.update(parent_sha256=event["parent_sha256"], review_id=event["review_id"], adopted_findings=adopted)
                if draft["sha256"] == event["parent_sha256"]:
                    draft["unchanged"] = True  # registered again word for word; nothing was changed
                run.pop("author_acceptance", None)
            run["drafts"].append(draft)
            # The text is kept once, in drafts; the current pointer binds it by hash.
            run.update(current_draft={key: copy.deepcopy(value) for key, value in draft.items() if key != "text"},
                       status="drafted")
        elif op == "review":
            _need(run.get("current_draft"), "No draft to review", "invalid_transition")
            review_id = _text(event.get("review_id"), "review_id")
            _need(review_id not in run["reviews"], "review_id already exists")
            _need(event.get("draft_sha256") == run["current_draft"]["sha256"], "Review must bind the current draft")
            reviewer = event.get("reviewer")
            _need(isinstance(reviewer, dict), "reviewer must be an object")
            for key in ("name", "context_id"):
                _text(reviewer.get(key), "reviewer." + key)
            _need(reviewer.get("role") in memory.REVIEWER_ROLES, "Invalid reviewer role")
            _need(reviewer.get("mode") in memory.REVIEWER_MODES, "Invalid reviewer mode")
            _need(reviewer["mode"] != "self_check" or reviewer["role"] == "writer", "self_check can only have writer role")
            _need(reviewer["mode"] != "independent_agent" or reviewer["context_id"] != run["current_draft"]["actor"]["context_id"],
                  "Independent agent must have a different context_id from writer")
            _need(reviewer["mode"] != "author_return" or reviewer["role"] == "teacher",
                  "author_return records a teacher's result that the author carried back")
            _need(event.get("verdict") in {"pass", "revise", "blocked"}, "Invalid verdict")
            findings = event.get("findings")
            _need(isinstance(findings, list) and all(isinstance(x, dict) for x in findings), "findings must be an array")
            for finding in findings:
                for key in ("id", "issue", "evidence", "scope"):
                    _text(finding.get(key), "finding." + key)
            ids = [x["id"] for x in findings]
            _need(len(ids) == len(set(ids)), "Duplicate finding id")
            _need(event["verdict"] != "pass" or not findings, "Pass cannot contain unresolved findings")
            _need(event["verdict"] != "revise" or bool(findings), "revise verdict requires findings")
            rechecks = _strings(event.get("rechecks", []), "rechecks")
            _need(set(rechecks).issubset(run["reviews"]), "rechecks contains an unknown review id")
            review = {"review_id": review_id, "draft_sha256": event["draft_sha256"],
                      "draft_index": len(run["drafts"]) - 1,
                      "reviewer": copy.deepcopy(reviewer), "verdict": event["verdict"],
                      "findings": copy.deepcopy(findings), "source_ref": _text(event.get("source_ref"), "source_ref"),
                      "rechecks": rechecks}
            if "teacher_return_id" in event:
                returned = _text(event["teacher_return_id"], "teacher_return_id")
                record = _chapter_record(payload, run.get("chapter_id")) or {}
                _need(reviewer["mode"] == "author_return" and any(
                    isinstance(item, dict) and item.get("event_id") == returned
                    and item.get("draft_sha256") == event["draft_sha256"]
                    for item in record.get("teacher_returns", [])),
                    "teacher_return_id must name a teacher return recorded in this run's chapter for this same "
                    "draft, on an author_return review")
                review["teacher_return_id"] = returned
            if reviewer["role"] == "author" and event["verdict"] != "pass":
                # The author's newer words stand; the earlier acceptance stays in the ledger only.
                run.pop("author_acceptance", None)
            run["reviews"][review_id] = review
            run["review_order"].append(review_id)
            if run["status"] != "finished":  # an author's later objection leaves a finished run finished
                run["status"] = "reviewed"
        elif op == "decide":
            _decide(payload, run, event)
        elif op in {"finish", "author_accept"}:
            _need(run.get("current_draft") and event.get("draft_sha256") == run["current_draft"]["sha256"], "Event must bind the current draft")
            objections = _author_objections(run)
            open_objection = ("The author's objection to this text is still open (" + ", ".join(objections) +
                              "): change the text, or record the author's own later words with decide and withdrawal")
            if op == "finish":
                passed = _pass(run)
                _need(passed is not None, "Current draft needs a passing review and all required rechecks", "invalid_transition")
                _need(not objections, open_objection, "author_objection")
                # The author rejected an earlier text of this one and has not seen it:
                # no teacher's pass makes it teacher-reviewed (the author decides).
                earlier = _earlier_objections(payload, run)
                run.update(status="finished", final_sha256=event["draft_sha256"],
                           completion="author_objection_open" if earlier
                           else "teacher_reviewed" if _teacher_pass(run) else "self_checked",
                           final_review_id=passed["review_id"])
            else:
                _need("author_acceptance" not in run, "Current draft acceptance already recorded")
                words = _author_words(event, "author_accept")
                _accepting(words["quote"])
                _need(not objections, open_objection, "author_objection")
                if _chapter_linked(payload, run):
                    _need(_final_confirmed(payload, run["chapter_id"], event["draft_sha256"]), FINAL_FIRST,
                          "chapter_gate_first")
                live = _live_cases(run, cases)
                _need(not live, "This draft is already recorded as case " + ", ".join(live) +
                      ": add the author's acceptance to the case with case_accept", "invalid_transition")
                run["author_acceptance"] = {**words, "draft_sha256": event["draft_sha256"]}
        elif op == "stop":
            run.update(status="stopped", stop_reason=_text(event.get("reason"), "reason"))
        elif op == "learn":
            _need(run["status"] == "finished", "learn requires a finished run", "invalid_transition")
            case_id = _text(event.get("case_id"), "case_id")
            _need(case_id not in cases, "case_id already exists; old cases are never overwritten")
            live = _live_cases(run, cases)
            _need(not live, "This run's final draft is already recorded as case " + ", ".join(live) +
                  "; one case per finished run. Use case_accept for the author's later acceptance",
                  "invalid_transition")
            # The pass the run finished on; an author's later objection does not move it.
            passed = run["reviews"].get(run.get("final_review_id")) or _pass(run)
            _need(passed is not None, "No current-draft passing review")
            draft = run["drafts"][-1]
            # An older finished run may still carry an author objection to this very text.
            objections = _author_objections(run)
            earlier = _earlier_objections(payload, run)
            acceptance = run.get("author_acceptance")
            accepted = bool(acceptance) and acceptance["draft_sha256"] == draft["sha256"] and not objections
            teacher = None if objections or earlier else _teacher_pass(run)
            supporting_review = teacher or passed
            reviewer = supporting_review["reviewer"]
            source = {"ref": draft["source_ref"], "version": draft["sha256"],
                      "reviewer": reviewer["name"], "reviewer_role": reviewer["role"],
                      "reviewer_mode": reviewer["mode"], "evidence": supporting_review["source_ref"],
                      "run_id": run_id, "input_ref": run["source_ref"], "draft_ref": draft["source_ref"],
                      "supporting_review_id": supporting_review["review_id"],
                      "draft_sha256": draft["sha256"], "review_ids": [r["review_id"] for r in _reviews(run)],
                      "run_review_ids": list(run["review_order"])}
            for key, value in (("teacher_return_id", supporting_review.get("teacher_return_id")),
                               ("chapter_id", run.get("chapter_id")),
                               ("open_author_objections", objections),
                               ("earlier_author_objections", earlier)):
                if value:
                    source[key] = copy.deepcopy(value)
            case = {"id": case_id, "project_id": project_id, "group_id": run["group_id"],
                    "task": run["task"], "tags": copy.deepcopy(run["tags"]), "before": run["input_text"],
                    "after": draft["text"], "why": _text(event.get("why"), "why"),
                    "when": _strings(event.get("when"), "when", True),
                    "except": _strings(event.get("except"), "except"),
                    "decisions": _strings(event.get("decisions"), "decisions", True),
                    "status": "author_accepted" if accepted else "teacher_approved" if teacher else "candidate",
                    "split": event.get("split", "development"),
                    "hashes": {"before": _hash(run["input_text"]), "after": draft["sha256"]},
                    "source": source,
                    "author_acceptance": copy.deepcopy(acceptance) if accepted else None}
            _need(case["split"] in memory.SPLITS, "Invalid split")
            cases[case_id] = case
            run["learned_case_ids"].append(case_id)
    result = {"run_id": run_id, "next_action": _next(run, payload), "run_status": run["status"]}
    if run.get("current_draft"):
        result["draft_sha256"] = run["current_draft"]["sha256"]
        objections = _author_objections(run)
        if objections:
            result["open_author_objections"] = objections
        earlier = _earlier_objections(payload, run)
        if earlier:
            result["earlier_author_objections"] = earlier
    if _deferred(run):
        result["deferred"] = _deferred(run)
    if op == "start":
        result["chapter_link"] = run["chapter_id"] if _chapter_linked(payload, run) else "not_linked"
    return result


def _atomic_bytes(path, raw):
    descriptor, name = tempfile.mkstemp(prefix="." + path.name + ".", suffix=".tmp", dir=path.parent)
    replaced = False
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(name, path)
        replaced = True
        descriptor = os.open(path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
        return []
    except OSError as exc:
        if replaced:
            return ["Replacement completed; directory durability unconfirmed. Re-read before retrying: " + str(exc)]
        raise
    finally:
        if not replaced:
            os.unlink(name)


def _ledger_copy(event, data):
    """Keep the event for the ledger without repeating a manuscript body.

    Quotes, references, decisions and findings stay word for word. One long
    body per event (a draft, the run input, a chapter stage's content, a
    teacher return) is replaced by its hash and length, and only after the run
    or chapter record is seen to hold that same text. Entries written by
    earlier versions keep their full text and read the same way.
    """
    kept = copy.deepcopy(event)
    field, held = None, False
    run = data.get("learning_runs", {}).get(event.get("run_id"), {})
    if event["op"] == "start":
        field, held = "input_text", run.get("input_text") == event.get("input_text")
    elif event["op"] in {"draft", "revise"}:
        field = "text"
        held = bool(run.get("drafts")) and run["drafts"][-1].get("text") == event.get("text")
    elif event["op"] == "chapter_gate":
        chapter = data.get("chapter_confirmations", {}).get(event.get("chapter_id"))
        chapter = chapter if isinstance(chapter, dict) else {}
        if event.get("action") == "present":
            field = "content"
            held = any(isinstance(item, dict) and item.get("presentation_id") == event["event_id"]
                       and item.get("content") == event.get("content") for item in chapter.get("history", []))
        elif event.get("action") == "teacher_return":
            field = "returned_text"
            held = any(isinstance(item, dict) and item.get("event_id") == event["event_id"]
                       and item.get("returned_text") == event.get("returned_text")
                       for item in chapter.get("teacher_returns", []))
    if field and held and isinstance(kept.get(field), str):
        kept[field] = _stub(kept[field])
    return kept


def _retry_result(payload, event_id, fingerprint, version):
    prior = payload["data"].get("learning_events", {}).get(event_id)
    if prior is None:
        return None
    _need(isinstance(prior, dict) and prior.get("payload_sha256") == fingerprint,
          "event_id was already used with different content", "duplicate_event")
    return {**prior["result"], "status": "unchanged", "version": version}


def apply_event(path, event, project_id, expected_version):
    """Apply one immutable event with strict CAS; identical retries are harmless."""
    try:
        _need(isinstance(event, dict), "Event must be an object")
        event = copy.deepcopy(event)
        fingerprint = _hash(_encode(event))
        event_id = _text(event.get("event_id"), "event_id")
        _need(isinstance(event.get("op"), str) and event["op"] in OPS, "Unknown op")
        _text(project_id, "project_id")
        _text(expected_version, "expected_version")
        # Markdown's stable lock covers read/transform/replace. JSON delegates its
        # final save to commit_state with no base, so no three-way merge is possible.
        with state._locked(path) as resolved:
            payload, version, markdown = _decode(resolved.read_bytes(), resolved)
            _need(payload["project_id"] == project_id, "Requested project differs from store", "project_mismatch")
            retried = _retry_result(payload, event_id, fingerprint, version)
            if retried:
                return retried
            _need(version == expected_version, "Store changed since your read; no write performed", "stale_version")
            updated = copy.deepcopy(payload)
            result = _apply(updated, event, project_id)
            # The fingerprint covers the whole original event, so a retry that
            # carries the full text again is still recognized.
            updated["data"].setdefault("learning_events", {})[event_id] = {
                "payload_sha256": fingerprint, "op": event["op"], "run_id": event.get("run_id"),
                "event": _ledger_copy(event, updated["data"]), "result": result}
            _validate(updated)
            if markdown is not None:
                updated["revision"] += 1
                text, start, end = markdown
                # Literal marker text in a manuscript remains round-trip equal,
                # while only the actual Markdown delimiters occur in the file.
                encoded = _encode(updated).decode("utf-8").replace("<", "\\u003c")
                raw = (text[:start] + encoded + text[end:]).encode("utf-8")
                warnings = _atomic_bytes(resolved, raw)
                return {**result, "status": "saved_durability_uncertain" if warnings else "saved",
                        "version": "sha256:" + _hash(raw), "warnings": warnings}
        # commit_state acquires the very same lock independently. A writer that
        # won this interval causes a CAS failure; it can never be overwritten.
        committed = state.commit_state(path, expected_version, updated["data"])
        return {**result, "status": committed["status"], "version": committed["state"]["version"],
                "warnings": committed.get("warnings", [])}
    except state.StateError as exc:
        if exc.code == "stale_version":
            current, version = read_store(path)
            retried = _retry_result(current, event_id, fingerprint, version)
            if retried:
                return retried
        raise LoopError(exc.code, str(exc)) from exc
    except (OSError, UnicodeError, TypeError, ValueError, KeyError) as exc:
        if isinstance(exc, LoopError):
            raise
        raise LoopError("invalid_event", str(exc)) from exc


def _brief(run):
    """A progress view of one run: manuscript bodies become hash and length."""
    run = copy.deepcopy(run)
    if isinstance(run.get("input_text"), str):
        run["input_text"] = _stub(run["input_text"])
    for draft in run.get("drafts", []) + [run.get("current_draft") or {}]:
        if isinstance(draft.get("text"), str):
            draft["text"] = _stub(draft["text"])
    for case in run.get("selected_cases", []):
        for key in ("before", "after"):
            if isinstance(case.get(key), str):
                case[key] = _stub(case[key])
    return run


HELP = """Events always have event_id/op; run operations also have run_id.
configure: loop_enabled:boolean; optional max_revisions:1..5. Optional
  enabled:boolean is the switch for recording examples at all; turning it on
  needs the author's own words: actor_role:author,mode:human,quote,source_ref.
start: task,tags:[text],group_id,input_text,source_ref,constraints:[text].
  Optional case_ids names up to three approved cases that pass the filter
  (context lists the rest under not_selected); excluded_groups/evaluation/limit
  further restrict selection. Current group is always excluded. The run keeps
  each selected case bound by hash, with its before/after as SHA256 and length;
  the texts stay in the case. Optional chapter_id says this run revises that
  chapter's author-confirmed draft: input_text and the first draft are then
  that draft's text. Where the project uses the chapter gate (a policy is
  recorded, or the chapter has a record), start waits until the gate holds the
  author's confirmation of the draft stage and SHA256(input_text) equals its
  artifact_sha256; a later round may instead start from the final text of an
  earlier finished run of this chapter that came from that same draft. start
  returns chapter_link: the chapter id, or not_linked.
  Optional workflow_guard_ref records an existing guard reference without
  reading it.
plan: applications:[{case_id,decision:apply|adapt|decline,reason,
  conditions_checked:{condition:bool},exceptions_checked:{exception:bool}}],
  checks:[text]. Cover every frozen case/condition/exception. A matching
  exception or false condition requires decline. String arrays may explicitly
  name satisfied conditions / checked non-matching exceptions. Zero cases: [].
draft: text,source_ref,actor:{name,context_id}.
review: review_id,draft_sha256,reviewer:{name,role:writer|teacher|author,
  mode:self_check|independent_agent|author_return|human,context_id},
  verdict:pass|revise|blocked,findings:[{id,issue,evidence,scope}],source_ref;
  optional rechecks:[review_id]. self_check only uses writer role;
  independent_agent needs another context_id; author_return is a teacher's
  result that the author carried back and may add teacher_return_id (the
  chapter gate's record of it). A blocked review that lists no findings must
  be named in the rechecks of a later pass before the run can finish. A
  finished run still takes the author's later objection (role author, verdict
  not pass) to its final text: cases learned from it are then not selected
  until the author takes it back.
decide: review_id,decisions:[{finding_id,decision:adopt|decline|defer,reason}].
  May be sent again while the draft is not yet revised; the earlier decisions
  move to decision_history. The author's own objection (role author, verdict
  not pass) can only be adopted, or taken back in the author's later words: add
  withdrawal:{actor_role:author,mode:human,quote,source_ref} to each finding
  that is not adopted, or to the event when that review lists no findings.
  On a finished run decide only takes such withdrawals; to change the text,
  start another run from it. In a run started with chapter_id, where that
  chapter's draft goes to the teacher through the author
  (teacher_handoff:user_return), decide and revise wait until the author has
  confirmed the chapter gate's review stage for this run's draft; a decide
  made only of the author's withdrawals does not wait. Other runs are not
  checked against the chapter gate here.
revise: parent_sha256,text,source_ref,actor,review_id; needs adopted finding(s).
finish: draft_sha256; current pass must cover pending rechecks. Refused while
  an author objection to this text is open. completion is teacher_reviewed,
  self_checked, or author_objection_open: the author rejected an earlier text of
  this one (in this run, or in the run this one started from) and has neither
  passed a later draft nor accepted this one. Results list such objections under
  earlier_author_objections; learn then makes only a candidate.
stop: reason.
author_accept: draft_sha256,quote,source_ref,actor_role:author,mode:human
  (actual evidence). The quote must be an explicit acceptance of this text; it
  goes through the same wording check as the chapter gate's final stage, so
  words that only move on, refuse or stay vague are not recorded. In a run
  started with chapter_id under the chapter gate, the chapter's final stage
  must already be confirmed for this same draft_sha256.
learn: case_id,why,when:[text],except:[text],decisions:[text]; optional split.
  Uses actual run input/final draft; self-check creates candidate only. One
  case per finished run; the case records the reviewer's role and mode.
case_accept: case_id,case_sha256 (the case's hashes.after),quote,source_ref,
  actor_role:author,mode:human. Adds the author's later explicit acceptance to
  an existing candidate or teacher-approved case; same wording, author
  objection and chapter checks as author_accept. The earlier status stays in
  status_history.
case_status: case_id,status:rejected|retired,reason; no evidence-free promotion.
chapter_gate: independent of loop. action:configure needs no chapter_id/stage:
  visual_required:boolean,teacher_handoff:user_return|host,actor_role:author,
  mode:human,author_quote,source_ref. Only chapters first presented afterward
  freeze this policy; existing chapters keep their policy or legacy behavior.
  action:present|confirm|reopen: chapter_id,stage.
  present: content,source_ref; draft/revision/final also artifact_sha256.
  Required visual preparation adds visual_evidence:{mode:pipeline_run|author_images|reuse,
  source_refs:[text],observation_ref,selection_ref}; pipeline_run also needs
  run_ref,verification_ref; reuse needs reuse_author_quote,reuse_source_ref.
  user_return waits after draft confirmation. action:teacher_return needs
  chapter_id,draft_presentation_id,draft_presentation_version,draft_sha256,
  returned_text,source_ref,teacher_name (use unknown explicitly if unknown).
  It keeps the original text and hash without confirming any stage. Then review
  present needs teacher_return_id bound to this confirmed draft instance.
  Review binds confirmed draft; final must match confirmed revision. confirm:
  presentation_id,presentation_version,actor_role:author,mode:human,author_quote,
  source_ref; final also decision:accept_final_version. reopen:
  reason,author_quote,source_ref. Store CAS remains the outer version field.
  chapter_gate.py --help describes the policy a chapter follows when nothing is
  recorded, action:chapter_policy (the author's word for one chapter) and what
  status prints.
The ledger (learning_events) keeps each event's quotes, references and
decisions; a manuscript body already held by the run or chapter record is kept
there once and appears in the ledger as its SHA256 and length.
No command executes event contents or calls a model. Visual evidence only checks
record structure; the host must actually inspect images. Recorded sources,
identities, independent contexts and literary quality cannot be authenticated
by this script. The host remains responsible for workflow_guard's smaller
budget, existing reservation protocol and delivery gate.
"""


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, epilog=HELP,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("status", "show", "context", "apply"):
        sub = commands.add_parser(name, epilog=HELP if name == "apply" else None,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
        sub.add_argument("store", type=Path)
        if name == "show":
            sub.add_argument("--run-id", required=True)
            sub.add_argument("--brief", action="store_true",
                             help="progress only: print each manuscript body as its SHA256 and length")
        if name in {"context", "apply"}:
            sub.add_argument("--project-id", required=True)
        if name == "context":
            sub.add_argument("--task", required=True)
            sub.add_argument("--tag", action="append", default=[])
            sub.add_argument("--exclude-group", action="append", default=[])
            sub.add_argument("--evaluation", action="store_true")
            sub.add_argument("--limit", type=int, choices=range(1, 4), default=3)
            sub.add_argument("--case-id", action="append", default=[],
                             help="name a case listed under not_selected; repeatable, at most --limit")
        if name == "apply":
            sub.add_argument("event", type=Path)
            sub.add_argument("--if-version", required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == "status":
            result = status(args.store)
        elif args.command == "context":
            result = context(args.store, args.project_id, args.task, args.tag,
                             args.exclude_group, args.evaluation, args.limit, args.case_id or None)
        elif args.command == "show":
            payload, version = read_store(args.store)
            run = payload["data"].get("learning_runs", {}).get(args.run_id)
            _need(run is not None, "Unknown run_id", "invalid_transition")
            result = {"status": "found", "version": version, "run": _brief(run) if args.brief else run,
                      "next_action": _next(run, payload)}
            if run.get("current_draft") and _author_objections(run):
                result["open_author_objections"] = _author_objections(run)
            if run.get("current_draft") and _earlier_objections(payload, run):
                result["earlier_author_objections"] = _earlier_objections(payload, run)
            if _deferred(run):
                result["deferred"] = _deferred(run)
        else:
            event = memory._loads(args.event.read_text(encoding="utf-8"))
            result = apply_event(args.store, event, args.project_id, args.if_version)
        print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
        return 4 if result.get("status") == "saved_durability_uncertain" else 0
    except (LoopError, OSError, ValueError, TypeError) as exc:
        print(json.dumps({"status": "error", "code": getattr(exc, "code", "invalid_event"),
                          "message": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 3 if getattr(exc, "code", "") == "stale_version" else 2


if __name__ == "__main__":
    raise SystemExit(main())

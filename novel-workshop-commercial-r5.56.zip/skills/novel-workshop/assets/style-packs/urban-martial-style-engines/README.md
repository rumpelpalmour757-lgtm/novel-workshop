# 都市高武风格引擎库 v2.0.2 · 使用说明

把都市高武的写法拆成143个可组合的风格引擎，外加常驻底座、总控和10个卷配方。核心规矩：每次写作只加载底座、总控和至多3个引擎——人物底色、战斗物理、副本规则各一个。

同一套文件三种用法：当 Claude 技能用；贴进任何AI用；放进你的小说项目里用。

## 包里有什么

```
urban-martial-style-engines/
├── ENGINE.md                    Claude 读的工作流程（别的AI也能读）
├── README.md                   本说明
├── references/
│   ├── L0_core.yaml            底座：每次必守
│   ├── router.yaml             总控：三槽、节奏、冲突裁决、配方、全局口径、术语、自检清单
│   ├── catalog.md              引擎目录：按层、按组，含配方表和禁配表
│   ├── engines/                143个引擎，一个引擎一个文件（编号_英文id.yaml）
│   └── library.json            整库单文件，给脚本和别的程序读
├── scripts/
│   ├── check_combo.py          查组合能不能一起用，排槽位
│   ├── lint_text.py            查正文：禁用词、限定词、转场套话、AI腔
│   ├── export_prompt.py        导出提示词，贴进任何AI
│   ├── build_library.py        改过yaml后重建派生文件
│   └── common.py               上面几个脚本共用
├── templates/
│   └── book_profile.yaml       本书设定档模板：复制到你的小说项目
├── prompts/                    现成提示词，不用装任何东西
│   ├── 00_底座与目录.md
│   └── 01–10_配方_*.md
└── docs/
    ├── 整理说明.md              这一版改了什么、为什么
    └── 改动明细.md              每个引擎相对你原稿的改动
```

## 用法一：当 Claude 技能用

随小说写作工坊分发的这一份，入口文件叫 `ENGINE.md`，不叫 `SKILL.md`：放在工坊里时由工坊按需读它，不单独当技能装。工坊包里也没有 `urban-martial-style-engines-v2.0.2.zip` 和 `.skill` 文件。要离开工坊单独当技能用，先把整个文件夹复制出来，再把复制出来的那一份里的 `ENGINE.md` 改名为 `SKILL.md`；不改名认不成技能，也不会报错。

- **Claude Code**：把改好名的文件夹放到 `~/.claude/skills/`（所有项目可用）或你小说项目的 `.claude/skills/`（只在这个项目可用）。见 [Skills 文档](https://code.claude.com/docs/en/skills)。
- **Claude 应用（网页、桌面、手机）**：照应用的说明把改好名的文件夹打包上传，再到 Customize > Skills 里打开它；需要开启代码执行。见 [How to create custom skills](https://support.claude.com/en/articles/12512198)。随工坊分发以后，这两种装法都没有再试过。
- **替换旧版**：之前装过 v1.1 的，建议先删掉旧版再装这一份，只留一个。

装好以后直接说「用寒门开局配方写第一章，大纲如下……」或「按06加05开书，帮我建本书设定档」。提到高武、武考、气血、宗师、兽潮、裂渊这类题材时，Claude 会自动用它。

## 用法二：贴进任何AI（不用装任何东西）

1. 打开 `prompts/` 里的一个文件，全文复制。
   - 已经知道这卷写什么：用 `01–10_配方_*.md`，比如 `01_配方_寒门开局.md`。
   - 还没想好用哪些引擎：用 `00_底座与目录.md`，让AI按目录帮你选。
2. 粘到对话最前面，或者那个AI的系统提示词、自定义指令里。
3. 接着发本章大纲、续写位置或要改的正文。

想换引擎：把 `00_底座与目录.md` 和选中引擎的文件（`references/engines/编号_*.yaml`）一起贴进去，最多3个。

有 Python 的话，用 `export_prompt.py` 按你的组合和本书设定精确导出（见下文），比通用版多一节「本书设定」：主角身份锁、人物、全书约定。

## 用法三：放进你的小说项目

推荐这样放：

```
我的小说/
├── 本书设定.yaml                 从 templates/book_profile.yaml 复制过来改
├── 正文/
│   ├── 第001章.txt
│   └── ……
└── urban-martial-style-engines/  本包
```

`本书设定.yaml` 开书时填一次：书名、主角模板（L1，1主+1副）、刻度改动、分卷配方、主要人物、额外禁用词和放行词、全书约定。之后每章三步（在「我的小说」目录下运行）：

```bash
# 1. 写之前：查组合，按第2卷的配方取引擎（也可以直接写编号：21 02 17）
python urban-martial-style-engines/scripts/check_combo.py --profile 本书设定.yaml --volume 2

# 2. 要在别的AI里写：导出这一章的规范
python urban-martial-style-engines/scripts/export_prompt.py --profile 本书设定.yaml --volume 2 -o 第二卷规范.md

# 3. 写完：查正文
python urban-martial-style-engines/scripts/lint_text.py 正文/第012章.txt --engines 21 02 17 --profile 本书设定.yaml
```

用 Claude 写这本书时（Claude Code 打开这个项目，或者在 Claude 应用里把设定档一起发过去），Claude 会先读 `本书设定.yaml`，再按设定选引擎、写、自检。

## 常用命令

以下命令在本包目录里运行；在别的目录运行时，把 `scripts/` 换成本包的完整路径。

| 要做什么 | 命令 |
| --- | --- |
| 看全部引擎 | `python scripts/check_combo.py --list`（只看一层：`--list L3`） |
| 查一组引擎能不能一起用 | `python scripts/check_combo.py 21 02 50 --book 06` |
| 按配方查 | `python scripts/check_combo.py --recipe 寒门开局` |
| 导出一章的提示词 | `python scripts/export_prompt.py 21 02 50 --book 06 -o 规范.md` |
| 导出目录版提示词 | `python scripts/export_prompt.py --catalog -o 选引擎.md` |
| 查正文 | `python scripts/lint_text.py 第012章.txt --engines 21 02 50 --book 06` |
| 查正文并列出叙述里的数字 | 上一条后面加 `--numbers` |
| 人名撞了禁用词 | 加 `--allow 林灵瞳`，或写进设定档的 `extra_allow` |
| 改过yaml后重建 | `python scripts/build_library.py` |

`--book` 填本书锁定的L1；有设定档就用 `--profile 本书设定.yaml` 代替。退出码：0 没问题，1 有问题，可以接进你自己的脚本。

## 环境要求

- Python 3.8 以上。`check_combo.py`、`lint_text.py`、`export_prompt.py` 只用标准库。
- `build_library.py` 和 `--profile` 要读 yaml，需要 PyYAML：`pip install pyyaml`。
- 不装 Python 也能用：`prompts/` 里的现成提示词和所有 yaml 文件都能直接读、直接贴。

## 改库

- **改刻度、禁用词、配方、自检清单**：只改 `references/router.yaml`，然后运行 `python scripts/build_library.py`。它会重建 `library.json`、`catalog.md`、`docs/改动明细.md` 和 `prompts/`。
- **改某个引擎**：直接改 `references/engines/` 里那个文件，再运行 build_library.py。
- **加新引擎**：复制一个同层引擎改写，文件名 `编号_英文id.yaml`，编号写成带引号的字符串（`num: '151'`），然后运行 build_library.py——它会检查必填字段、重复编号和引用了不存在的编号。

## 这一版改了什么

见 `docs/整理说明.md`。要点：你的150流派总控整体并入（三槽混音、节奏状态机、全局黑名单）；新引擎里修了科学硬伤、战力称谓、缺代价、知名作品原型痕迹和审核风险；新增导出提示词和本书设定档，方便迁移到别的AI和你的小说项目。

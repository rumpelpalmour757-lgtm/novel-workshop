"""doctor: for each of the five components, whether the adapter is here (implemented) and whether this machine has what
it needs (configured). With --probe it also makes one small real request or call per component and says what came
back. live_verified is not decided here: it comes from verify-run on a real run.

r5.37: for Crawl4AI, "configured" only means the package imports; whether its browser starts shows in --probe (which
opens a local page) or in a collect run (pages browser_failed), and is reported as such.

r5.59: the summary says so too: without --probe, Crawl4AI was only imported, its browser was not started. doctor also
says who would read the source pages in a collect (page_reader: crawl4ai or the builtin reader) and why; with --probe
the builtin reader reads a page made here (no request), and with page_reader.use auto a Crawl4AI browser that did not
start in the probe turns the answer to the builtin reader; with page_reader.use crawl4ai the summary says that collect
cannot read the source pages. The page reader is not one of the five components. The probe's page holds its image as a
data: address, so the browser has no website to ask for it (an image on a website, as before r5.59, would be loaded
by the browser outside the workshop's network checks): the probe shows whether the browser starts and reads the page,
and dropped_images says whether Crawl4AI listed that image at all.
"""
import importlib
import sys

from . import COMPONENTS, common
from . import static_reader
from .collect import choose_reader, crawl4ai_status
from .dedupe import imagehash_status
from .providers import openverse, searxng
from .rank import openclip_status

MODULES = {"searxng": "visual_materials.providers.searxng", "openverse": "visual_materials.providers.openverse",
           "crawl4ai": "visual_materials.collect", "imagehash": "visual_materials.dedupe",
           "openclip": "visual_materials.rank"}


def probe_search(module, config, fetch):
    record, found = module.search(config, ["test"], 1, fetch)
    return {"status": record["status"], "requests": [{k: r.get(k) for k in ("url", "http_status", "status", "error")}
                                                     for r in record.get("requests", [])], "results": len(found)}


PROBE_IMAGE = ("data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7")


def probe_crawl4ai(config):
    html = "raw:<html><body><img src='%s' alt='probe' width='400'></body></html>" % PROBE_IMAGE
    from .collect import crawl_pages
    # The one place robots.txt is not asked (r5.59): the probe's page is made here (raw:) and its one image is a data:
    # address, so there is no website, robots.txt or host to ask; Crawl4AI's own check is off for this call only and
    # the run's network checks are skipped (local_probe). load_config refuses check_robots_txt: false in a config.
    pages, version = crawl_pages([html], dict(config, crawl4ai=dict(config["crawl4ai"], check_robots_txt=False)),
                                 local_probe=True)
    status = pages[0].get("status")
    return {"status": status, "browser_started": status not in ("browser_failed", "not_installed"),
            "images": len(pages[0].get("images", [])), "dropped_images": pages[0].get("dropped_images", 0),
            "version": version, "error": pages[0].get("error"),
            "note": "a page made here, its image a data: address: no website was asked; the image is dropped as a "
                    "placeholder, dropped_images 1 means Crawl4AI listed it"}


def probe_imagehash():
    import imagehash
    from PIL import Image

    image = Image.new("RGB", (64, 64), (120, 80, 40))
    for x in range(32):
        image.putpixel((x, x), (250, 250, 250))
    return {"status": "ok", "phash": str(imagehash.phash(image)), "version": imagehash.__version__}


def probe_openclip(config):
    from .rank import OpenCLIPBackend
    backend = OpenCLIPBackend(config)
    vector = backend.text("a workshop")
    return {"status": "ok", "model": backend.info, "text_vector_length": len(vector)}


def run_doctor(config, config_path=None, probe=False, fetch=None):
    out = {}
    for name in COMPONENTS:
        try:
            importlib.import_module(MODULES[name])
            implemented = True
        except Exception as exc:  # noqa: BLE001
            implemented, why = False, str(exc)
        out[name] = {"implemented": implemented}
    ok, why = searxng.configured(config)
    out["searxng"].update(configured=ok, detail=why)
    ok, why = openverse.configured(config)
    out["openverse"].update(configured=ok, detail=why)
    ok, why, _ = crawl4ai_status()
    out["crawl4ai"].update(configured=ok, importable=ok, detail=why + ("; whether its browser starts shows with --probe "
                                                                     "or in a collect run" if ok else ""))
    ok, why, _ = imagehash_status()
    out["imagehash"].update(configured=ok, detail=why)
    status, why, versions = openclip_status(config)
    out["openclip"].update(configured=status == "ready", detail=why, state=status, versions=versions)
    try:
        import PIL
        pillow = "Pillow %s" % PIL.__version__
    except ImportError:
        pillow = "Pillow is not installed: images cannot be decoded (pip install Pillow)"
    if probe:
        for name in COMPONENTS:
            if not out[name]["configured"]:
                out[name]["probe"] = {"status": "skipped", "why": "not configured"}
                continue
            try:
                if name in ("searxng", "openverse"):
                    out[name]["probe"] = probe_search(searxng if name == "searxng" else openverse, config, fetch)
                elif name == "crawl4ai":
                    out[name]["probe"] = probe_crawl4ai(config)
                elif name == "imagehash":
                    out[name]["probe"] = probe_imagehash()
                else:
                    out[name]["probe"] = probe_openclip(config)
            except Exception as exc:  # noqa: BLE001 - the probe reports, it does not crash
                out[name]["probe"] = {"status": "error", "error": "%s: %s" % (type(exc).__name__, exc)}
    for name in COMPONENTS:
        out[name]["live_verified"] = "decided by verify-run on a real run, not by doctor"
    ready = [n for n in COMPONENTS if out[n]["configured"]]
    summary = "五项都配置好了" if len(ready) == len(COMPONENTS) else "还没配置好：%s" % "、".join(
        n for n in COMPONENTS if n not in ready)
    if out["crawl4ai"]["configured"] and "probe" not in out["crawl4ai"]:
        summary += "；crawl4ai 只查了能不能导入，浏览器没查（要查加 --probe）"
    reader = page_reader(config, out["crawl4ai"], probe)
    summary += "；" + reader.pop("summary")
    return {"schema": "visual-doctor/1", "python": "%d.%d.%d" % sys.version_info[:3], "config": str(config_path or ""),
            "pillow": pillow, "review": {"mode": config["review"].get("mode", "host"),
                                         "note": "看图靠宿主助手打开图片文件，或作者自己看；命令行自己看不到图"},
            "components": out, "configured": ready, "page_reader": reader, "summary": summary,
            "offline_writing": "写作、审稿和灵感库的 check/list/card 不需要这五项，照常能用"}


def page_reader(config, crawl4ai, probe=False):
    """Who would read the source pages in a collect here, and why ({use, reader, why, summary[, probe]})."""
    use = config["page_reader"].get("use", "auto")
    reader, why = choose_reader(config)
    started = (crawl4ai.get("probe") or {}).get("browser_started")
    if use == "auto" and reader == "crawl4ai" and started is False:
        reader, why = "builtin", "page_reader.use is auto and Crawl4AI's browser did not start in the probe (%s)" % (
            crawl4ai["probe"].get("error") or "no reason given")
    if reader == "builtin":
        words = ("page_reader.use 写的是 builtin" if use == "builtin" else
                 "page_reader.use 是 auto，Crawl4AI 的浏览器起不来" if started is False else
                 "page_reader.use 是 auto，这台机器上 Crawl4AI 用不了")
        summary = "读来源页用工坊自带的读页（%s；不跑页面脚本，靠脚本才显示的图读不到）" % words
    elif crawl4ai.get("configured") and started is False:
        summary = ("Crawl4AI 的浏览器在 probe 里起不来，collect 读不了来源页（page_reader.use 写的是 crawl4ai，不改用自带读页；"
                   "装浏览器：crawl4ai-setup）")
    elif crawl4ai.get("configured"):
        summary = ("读来源页用 crawl4ai（page_reader.use 写的是 crawl4ai，浏览器起不来也不改用自带读页）"
                   if use == "crawl4ai" else "读来源页用 crawl4ai（page_reader.use 是 auto；浏览器起不来时 collect 改用自带读页）")
    else:
        summary = "读来源页定的是 crawl4ai（page_reader.use 写的是 crawl4ai），可这台机器上它用不了：collect 不读来源页，也不改用自带读页"
    out = {"use": use, "reader": reader, "why": why, "summary": summary}
    if probe and use != "crawl4ai":  # the builtin reader reads (or stands by for) the pages
        try:
            out["probe"] = static_reader.probe()
        except Exception as exc:  # noqa: BLE001 - the probe reports, it does not crash
            out["probe"] = {"status": "error", "error": "%s: %s" % (type(exc).__name__, exc)}
    return out

#!/usr/bin/env python3
"""r5.20: smaller repairs from the second full self-review (2026-10-19, of r5.19).

- The optional chapter-index tool (oh-story) imports a module from its own folder. Run with `python -I`, as the
  workshop's own commands are, the script's folder is not on the import path and the tool stopped before doing
  anything (known since r5.x, listed as a known issue). It now puts its own folder on the path first.
- The language-sense table's row on translationese lacked three common marks: a "当……的时候" frame around a time
  phrase, a manner or look hung on the end ("……的样子", "似的"), and an adverbial moved after the verb or wedged
  after the subject. The author's grammar handbook (second edition) lists them among its seven marks; the row now
  names them with invented examples, and says what not to change (a passive that tells what was done to someone,
  the register of a character who reasons or talks business).
- The top-level README carried every version's notes since r5 (about 150 lines) before the sections a new user
  needs; the details are in the changelog. It now keeps the current version and one line per earlier version.
"""

import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
INDEX_TOOL = SKILL / "scripts" / "oh-story" / "build_chapter_index.py"


class ChapterIndexToolIsolated(unittest.TestCase):
    def test_help_works_under_isolated_mode(self):
        proc = subprocess.run([sys.executable, "-I", "-B", str(INDEX_TOOL), "--help"], capture_output=True, text=True,
                              encoding="utf-8")
        self.assertEqual(proc.returncode, 0, proc.stderr[-300:])
        self.assertIn("--source", proc.stdout)

    def test_builds_an_index_under_isolated_mode(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            (tmp / "src.txt").write_bytes(("第一章 雨夜\n阿禾把木箱放在门边。\n\n第二章 天亮\n老沈拿来报纸。\n").encode("utf-8"))
            proc = subprocess.run([sys.executable, "-I", "-B", str(INDEX_TOOL), "--source", "src.txt", "--output", "out.csv"],
                                  cwd=tmp, capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(proc.returncode, 0, proc.stderr[-300:])
            rows = (tmp / "out.csv").read_text(encoding="utf-8-sig").splitlines()
        self.assertEqual(len(rows), 3)
        self.assertIn("雨夜", rows[1])


class TranslationeseRow(unittest.TestCase):
    def setUp(self):
        text = (SKILL / "references" / "sentence-craft.md").read_text(encoding="utf-8")
        self.row = next(line for line in text.splitlines() if line.startswith("| 翻译腔、书面腔 |"))
        self.cells = [c.strip() for c in self.row.strip("|").split("|")]

    def test_the_row_names_the_three_marks(self):
        how = self.cells[1]
        for phrase in ("“当……的时候”", "“……的样子”", "“似的”", "状语挪到", "成对的“因为……所以……”"):
            self.assertIn(phrase, how)

    def test_the_row_keeps_what_should_stay(self):
        dont = self.cells[3]
        for phrase in ("讲道理", "“被”", "受了什么"):
            self.assertIn(phrase, dont)
        self.assertEqual(len(self.cells), 4)


class ReadmeKeepsToTheEntrance(unittest.TestCase):
    def setUp(self):
        self.text = (ROOT / "README.md").read_text(encoding="utf-8")
        self.heads = [line for line in self.text.splitlines() if line.startswith("## ")]

    def test_one_current_section_and_a_list_of_earlier_versions(self):
        self.assertEqual(len([h for h in self.heads if h.startswith("## 本版")]), 1)
        self.assertIn("## 历次版本", self.heads)
        history = self.text.split("## 历次版本", 1)[1].split("\n## ", 1)[0]
        for version in ["r5.%d" % n for n in range(1, 20)]:
            self.assertIn("- **%s**" % version, history, version)
        self.assertIn("(CHANGELOG.md)", history)
        self.assertFalse([h for h in self.heads if h.startswith("## r5.1")], self.heads)

    def test_user_sections_come_soon_after_the_start(self):
        position = {h: n for n, h in enumerate(self.heads)}
        for head in ("## 工坊已有的其他能力", "## 保存你的作品"):
            self.assertIn(head, position)
        self.assertLess(len(self.text.encode("utf-8")), 24000)


if __name__ == "__main__":
    unittest.main()

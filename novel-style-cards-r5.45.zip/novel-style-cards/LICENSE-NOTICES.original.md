# 来源与许可说明

本交付包包含整理后的小说写作方法、工坊维护适配与可选开发技能。以下记录区分组件来源与所附许可，不将整包统一声明为 MIT 或全部原创。

| 组件 | 来源与变更 | 许可与记录 |
| --- | --- | --- |
| 小说写作工坊 | 通用写作方法、模板和脚本；本版整理买家入口与扩展调用说明，不附具体小说项目 | [详细来源记录](skills/novel-workshop/assets/third-party/SOURCE-NOTES.md) |
| Oh Story 相关方法 | 工坊参考并改写的章节状态与写作流程方法 | [原有 MIT 许可与版权通知](skills/novel-workshop/assets/third-party/oh-story-LICENSE.txt) |
| Oh Story 0.8.4 新增模块与工具 | 完整拆文、市场观察等方法重写；工作台有适配，章节索引、材料检查与关系图保留原实现 | [0.8.4 MIT 许可](skills/novel-workshop/assets/third-party/oh-story-0.8.4-LICENSE.txt)及[接入范围](skills/novel-workshop/assets/third-party/INTEGRATION-NOTES.md) |
| Darwin 工坊维护适配 | 基于 [alchaincyf/darwin-skill](https://github.com/alchaincyf/darwin-skill) 的候选迭代和配对比较思路，面向小说工坊重写精简入口；未包含上游演示与截图功能 | [Darwin MIT 许可与版权通知](skills/darwin-novel-workshop/LICENSE) |
| TypeSafe 可选开发技能 | TypeSafe 技能源码，正文与所附许可证保持原样 | [TypeSafe MIT 许可](optional/typesafe-ai/LICENSE) |
| 风格卡（r5.45） | 作者提供的一组腔调卡（卡组 4.1.0），收成 `skills/novel-workshop/assets/style-cards/cards.json`；收进来时删掉了名作原句和某一部作品专属的名字、套语，私人作品里的用语和网络热梗。卡名和说明里提到的作家、作品只用来描述腔调，包内不含这些作品的原文 | 用户提供的材料，见[详细来源记录](skills/novel-workshop/assets/third-party/SOURCE-NOTES.md)；借风格不搬原作表达的用法见[风格卡](skills/novel-workshop/references/style-cards.md) |
| 视觉素材链路调用的外部项目（r5.35） | 工坊只带调用它们的适配器（`skills/novel-workshop/scripts/visual_materials/`，新写）；SearXNG 由使用者自己部署，Openverse 调它的公开接口，Crawl4AI、ImageHash、OpenCLIP（含 torch）由使用者自己安装，模型权重自己下载；它们的代码、权重、浏览器都不在本包里 | SearXNG：AGPL-3.0；Crawl4AI：Apache-2.0；ImageHash：BSD-2-Clause；OpenCLIP：MIT（权重的许可看所选模型的模型卡）；Openverse 返回的每张图按它来源页的授权。见 [视觉素材](skills/novel-workshop/references/visual-materials.md) |

部分工坊来源材料未附独立使用条款；具体项目已在详细来源记录中标注。整理、改写和打包本身不等于完成全部来源的商业授权核验。本说明不增加或替代第三方许可，也不替权利人授予未明确提供的权利。

包内不含课程截图、课程全文、私人小说正文、个人项目记录、账户或 API 密钥。AI 平台、模型或外部服务不随本包提供；它们的账户、费用和使用条款由相应提供方确定。

r4 起新增的标点模块、交付门卡、事实账模板、`punctuation_lint.py`、`fact_guard.py`、`darwin_eval.py` 与 `tests/`，以及 r5 新增的工坊宪法、规则登记表、`delivery_manifest.py`、`workflow_demo.py` 和几份模板，由制作方和作者委托的另一条开发线（r4.2、r4.3）编写，只用 Python 标准库，没有引入第三方代码。r5.35 新增的 `inspiration_write.py`、`visual_materials_cli.py` 和 `scripts/visual_materials/` 由制作方新写，本身只用 Python 标准库；解码图片要 Pillow，去重、排序、读网页分别调用使用者自己装的 ImageHash、OpenCLIP、Crawl4AI，没有把它们的代码拷进本包。r5.45 新增的 `style_cards.py` 由制作方新写，只用 Python 标准库。

附带的 MIT 版权与许可通知应随对应组件一同保留。工坊脚本导出的 sale 模式控制文件范围和资源完整性，不是权利认证。

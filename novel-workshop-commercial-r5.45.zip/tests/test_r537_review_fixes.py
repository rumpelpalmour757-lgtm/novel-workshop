#!/usr/bin/env python3
"""r5.37: the reproducible points of the r5.35 review (visual chain and inspiration library), as regression tests.

Every case below is one the review reproduced on r5.35, or one of the variations it asked for. They run offline with
stand-ins for the network, the crawler and the model: they show how the records behave, not that any real service or
model works (verify-run still refuses stand-ins as evidence). Pinned:

1. observations follow the image, not the number: a rebuilt bundle with other images under the numbers outdates the
   recorded observations and the choice; a choice for another bundle is refused; an observation is never moved to
   another image version (its sha256 is never rewritten); the very same image version can be reused only when asked
   (reuse: true); a thumbnail replaced by its original, a deleted and rebuilt bundle, a changed file, a selection
   copied back from outdated/ and a bundle made before r5.37 are each refused or treated as unseen;
2. library writes: two migrations to the same --out cannot overwrite each other (the check is under the lock); a
   migration to another folder that could not find its images from there is refused before writing; a write that
   stops before the library file is replaced is "nothing written", one that stops after it is COMMITTED_INCOMPLETE and
   is finished by the next write; restore refuses a broken copy and reports missing image files; base_revision must
   match --if-revision; a log with a cut-off last line is still readable; a library copied to another folder still
   reads, cards, lists its history and restores;
3. collect degrades when Crawl4AI's browser does not start or the page reader stops (the search images are still
   fetched, partial, nothing claims a page was read), blocked hosts are neither crawled nor fetched, and a failed new
   fetch keeps the old image only as stale_image; an unknown or empty imagehash.algorithms is refused; a model that
   fails to load or encode is MODEL_ERROR; reference images are kept in the run; verify-run reports ran and
   live_verified apart, a changed image or a missing reference makes the evidence not current, all_five_live needs
   the files unchanged, and the command exits 1 unless all five are live; sources keep each sighting with its own page
   and licence.
"""
import asyncio
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import types
import unittest
from unittest import mock

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
SCRIPTS = SKILL / "scripts"
CLI = SCRIPTS / "visual_materials_cli.py"
READ = SCRIPTS / "inspiration_library.py"
WRITE = SCRIPTS / "inspiration_write.py"

if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


pipeline = load(Path(__file__).resolve().parent / "test_visual_materials_pipeline.py", "r537_pipeline")
vm, picture, response, Stand, sx_results, ov_results, config = (pipeline.vm, pipeline.picture, pipeline.response,
                                                                 pipeline.Stand, pipeline.sx_results,
                                                                 pipeline.ov_results, pipeline.config)
SX, OV, REQUEST, FakeModel = pipeline.SX, pipeline.OV, pipeline.REQUEST, pipeline.FakeModel
HAS_PIL = pipeline.Image is not None


def run(script, *args, cwd=None):
    proc = subprocess.run([sys.executable, "-I", "-B", str(script), *map(str, args)], capture_output=True, text=True,
                          encoding="utf-8", cwd=cwd)
    return proc.returncode, proc.stdout, proc.stderr


def answer(result):
    code, stdout, stderr = result
    try:
        return code, json.loads(stdout)
    except ValueError:
        raise AssertionError(stdout + stderr)


def read(path):
    return json.loads(Path(path).read_bytes().decode("utf-8"))


def write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(json.dumps(data, ensure_ascii=False).encode("utf-8"))
    return path


def choice_for(bundle_id, n=1, part="布局：柜台在下方"):
    return {"schema": "visual-choice/1", "bundle_id": bundle_id,
            "decision": {"by": "作者", "date": "2026-10-24", "words": "%d 的布局" % n},
            "choose": [{"n": n, "take": [{"part": part, "scope": "stable", "subject": "旧铺子"}]}]}


def empty_library(path, revision=0):
    return write(path, {"schema": "inspiration-library/2", "book": "测试", "revision": revision, "entries": []})


def rejecting(path, sha):
    return write(path, {"schema": "inspiration-library/2", "book": "测试", "revision": 1, "entries": [
        {"id": "VM-old", "kind": "place", "title": "不要的", "status": "rejected",
         "source": {"type": "link", "url": "https://page.example.org/x", "license": "未核，只作写作参考"},
         "image": {"sha256": sha, "width": 1, "height": 1}, "observation": {"scope": "none"},
         "decision": {"by": "作者", "date": "2026-10-24"}}]})


@unittest.skipUnless(HAS_PIL, "Pillow is not installed")
class Base(pipeline.Base):
    def bundled(self, library=None):
        report, run_dir, stand, cfg = self.searched()
        vm("collect").run_collect(run_dir, cfg, fetch=stand, crawl=lambda p, c: ([], None))
        vm("rank").run_rank(run_dir, cfg, backend=FakeModel())
        vm("review").run_bundle(run_dir, cfg, library)
        return run_dir, cfg, stand, read(run_dir / "review" / "bundle.json")

    def template(self, run_dir):
        return read(run_dir / "review" / "observations.json")

    def record(self, run_dir, cfg, data):
        return vm("review").record_observations(run_dir, cfg, write(self.root / "obs.json", data))

    def observe(self, run_dir, cfg, changes):
        data = self.template(run_dir)
        for item in data["items"]:
            item.update(changes.get(item["n"], {}))
        return self.record(run_dir, cfg, data)

    def select(self, run_dir, cfg, choice):
        return vm("selection").run_select(run_dir, cfg, write(self.root / "choice.json", choice))


SEEN = {"scope": "original", "by": "工坊（测试）"}


class ObservationsFollowTheImage(Base):
    def test_rebuilt_bundle_after_rejecting_old_one(self):
        # The review's path: record old 1, the author turns old 1 down, the bundle is rebuilt and old 2 becomes new 1,
        # new 1 is chosen. r5.35 saved old 1's observation on new 1 (and rewrote its sha256).
        common = vm("common")
        run_dir, cfg, stand, bundle = self.bundled()
        old = bundle["items"][0]
        self.assertEqual(self.observe(run_dir, cfg, {1: dict(SEEN, seen="ONLY_OLD_IMAGE_HAS_THIS_FEATURE")})["status"],
                         "OK")
        result = vm("review").run_bundle(run_dir, cfg, rejecting(self.root / "declined.json", old["sha256"]))
        new = read(run_dir / "review" / "bundle.json")
        self.assertNotEqual(new["bundle_id"], bundle["bundle_id"])
        self.assertNotEqual(new["items"][0]["sha256"], old["sha256"])
        self.assertIn("review/observations.recorded.json", result["outdated"])
        self.assertFalse((run_dir / "review" / "observations.recorded.json").exists())
        moved = list((run_dir / "outdated").rglob("observations.recorded.json"))
        self.assertEqual(len(moved), 1)  # kept, not deleted
        # A choice made on the old bundle is refused: its numbers point at other images now.
        with self.assertRaises(common.VisualError) as caught:
            self.select(run_dir, cfg, choice_for(bundle["bundle_id"]))
        self.assertIn("numbers may point at other images", str(caught.exception))
        with self.assertRaises(common.VisualError):
            self.select(run_dir, cfg, dict(choice_for(None), bundle_id=None))
        # On the new bundle nothing seen in old 1 reaches new 1: it is unseen until someone looks.
        self.select(run_dir, cfg, choice_for(new["bundle_id"]))
        selection = read(run_dir / "selection.json")
        self.assertEqual(selection["bundle_id"], new["bundle_id"])
        self.assertEqual(selection["adopt"][0]["entry"]["observation"], {"scope": "none"})
        self.assertNotIn("ONLY_OLD_IMAGE", json.dumps(selection, ensure_ascii=False))
        library = empty_library(self.root / "library.json")
        self.assertEqual(vm("adopt").run_adopt(run_dir, library, 0)["status"], "OK")
        saved = read(library)["entries"][0]
        self.assertEqual((saved["image"]["sha256"], saved["observation"]), (new["items"][0]["sha256"], {"scope": "none"}))
        # Looking at new 1 and recording it gives new 1 its own observation, bound to its own version.
        self.assertEqual(self.observe(run_dir, cfg, {1: dict(SEEN, seen="新 1 号：一排货架")})["status"], "OK")
        self.assertFalse((run_dir / "selection.json").exists())  # recorded again: the old selection is outdated
        self.select(run_dir, cfg, choice_for(new["bundle_id"]))
        entry = read(run_dir / "selection.json")["adopt"][0]["entry"]
        self.assertEqual((entry["observation"]["seen"], entry["observation"]["image_sha256"]),
                         ("新 1 号：一排货架", new["items"][0]["sha256"]))

    def test_the_same_image_version_is_reused_only_when_asked(self):
        run_dir, cfg, stand, bundle = self.bundled()
        first, second = bundle["items"][0], bundle["items"][1]
        self.observe(run_dir, cfg, {1: dict(SEEN, seen="一号看到的"), 2: dict(SEEN, seen="二号看到的")})
        vm("review").run_bundle(run_dir, cfg, rejecting(self.root / "declined.json", first["sha256"]))
        new = read(run_dir / "review" / "bundle.json")
        self.assertEqual(new["items"][0]["sha256"], second["sha256"])  # old 2 is new 1
        template = self.template(run_dir)
        self.assertEqual(template["bundle_id"], new["bundle_id"])
        self.assertEqual(template["items"][0]["seen_before"]["seen"], "二号看到的")
        self.assertEqual(template["items"][0]["scope"], "none")  # shown, not taken: nothing is recorded by itself
        self.assertNotIn("seen_before", template["items"][1])
        self.assertIn("同一个文件以前看过", (run_dir / "review" / "review.md").read_text(encoding="utf-8"))
        # Reuse for an image nobody looked at, or reuse together with new words, is refused.
        never = json.loads(json.dumps(template))
        never["items"][1]["reuse"] = True
        self.assertIn("nothing was recorded for this image version", self.record(run_dir, cfg, never)["problems"][0])
        both = json.loads(json.dumps(template))
        both["items"][0].update(reuse=True, seen="又写了一遍", scope="original", by="x")
        self.assertIn("either reuse: true or write what was seen", self.record(run_dir, cfg, both)["problems"][0])
        template["items"][0]["reuse"] = True
        result = self.record(run_dir, cfg, template)
        self.assertEqual((result["status"], result["reused"], result["viewed"]), ("OK", 1, 0))
        recorded = read(run_dir / "review" / "observations.recorded.json")
        self.assertEqual((recorded["items"][0]["seen"], recorded["items"][0]["reused_from"]["bundle_id"]),
                         ("二号看到的", bundle["bundle_id"]))
        self.select(run_dir, cfg, choice_for(new["bundle_id"]))
        entry = read(run_dir / "selection.json")["adopt"][0]["entry"]
        self.assertEqual((entry["observation"]["seen"], entry["observation"]["image_sha256"]),
                         ("二号看到的", second["sha256"]))

    def test_a_thumbnail_replaced_by_its_original(self):
        common = vm("common")
        report, run_dir, stand, cfg = self.searched(sx=sx_results(), ov=ov_results(dict(OV, url="https://img.example.org/missing.png")))
        vm("collect").run_collect(run_dir, cfg, fetch=stand, crawl=lambda p, c: ([], None))
        vm("review").run_bundle(run_dir, cfg)
        old = read(run_dir / "review" / "bundle.json")
        self.assertEqual(old["items"][0]["what"], "thumbnail")
        self.observe(run_dir, cfg, {1: {"scope": "thumbnail", "seen": "缩略图里一盏灯", "by": "工坊（测试）"}})
        stand.routes["https://img.example.org/missing.png"] = response(200, picture("lamp"), "image/png")
        result = vm("collect").run_collect(run_dir, cfg, fetch=stand, crawl=lambda p, c: ([], None))
        self.assertIn("review", result["outdated"])
        vm("review").run_bundle(run_dir, cfg)
        new = read(run_dir / "review" / "bundle.json")
        self.assertEqual(new["items"][0]["what"], "original")
        self.assertNotEqual(new["items"][0]["sha256"], old["items"][0]["sha256"])
        self.assertNotIn("seen_before", self.template(run_dir)["items"][0])  # another version: look again
        with self.assertRaises(common.VisualError):
            self.select(run_dir, cfg, choice_for(old["bundle_id"]))
        reuse = self.template(run_dir)
        reuse["items"][0]["reuse"] = True
        self.assertEqual(self.record(run_dir, cfg, reuse)["status"], "PROBLEMS")

    def test_a_deleted_and_rebuilt_bundle(self):
        common = vm("common")
        run_dir, cfg, stand, bundle = self.bundled()
        self.observe(run_dir, cfg, {1: dict(SEEN, seen="一号看到的")})
        # The review folder deleted by hand: the same images under the same numbers make the same bundle, and what
        # was recorded is offered again from the run's archive, used only with reuse: true.
        shutil.rmtree(run_dir / "review")
        vm("review").run_bundle(run_dir, cfg)
        again = read(run_dir / "review" / "bundle.json")
        self.assertEqual(again["bundle_id"], bundle["bundle_id"])
        self.select(run_dir, cfg, choice_for(again["bundle_id"]))
        self.assertEqual(read(run_dir / "selection.json")["adopt"][0]["entry"]["observation"], {"scope": "none"})
        self.assertEqual(self.template(run_dir)["items"][0]["seen_before"]["seen"], "一号看到的")
        # Only bundle.json deleted, and a different bundle built: the record left behind belongs to another bundle.
        self.observe(run_dir, cfg, {1: dict(SEEN, seen="一号看到的")})
        (run_dir / "review" / "bundle.json").unlink()
        vm("review").run_bundle(run_dir, cfg, rejecting(self.root / "declined.json", bundle["items"][1]["sha256"]))
        rebuilt = read(run_dir / "review" / "bundle.json")
        self.assertNotEqual(rebuilt["bundle_id"], bundle["bundle_id"])
        with self.assertRaises(common.VisualError) as caught:
            self.select(run_dir, cfg, choice_for(rebuilt["bundle_id"]))
        self.assertIn("recorded observations are for bundle", str(caught.exception))

    def test_a_changed_file_old_observations_and_old_selections(self):
        common = vm("common")
        run_dir, cfg, stand, bundle = self.bundled()
        stale = self.template(run_dir)
        stale["bundle_id"] = "B-0000000000000000"
        result = self.record(run_dir, cfg, stale)
        self.assertEqual(result["status"], "PROBLEMS")
        self.assertIn("not the run's bundle", result["problems"][0])
        self.observe(run_dir, cfg, {1: dict(SEEN, seen="一号看到的")})
        self.select(run_dir, cfg, choice_for(bundle["bundle_id"]))
        kept = (run_dir / "selection.json").read_bytes()
        # The image file replaced on disk after the bundle was made: choosing it is refused.
        first = run_dir / bundle["items"][0]["file"]
        original = first.read_bytes()
        first.write_bytes(picture("door"))
        with self.assertRaises(common.VisualError) as caught:
            self.select(run_dir, cfg, choice_for(bundle["bundle_id"]))
        self.assertIn("not the version in the bundle", str(caught.exception))
        first.write_bytes(original)
        # A selection made before the bundle was rebuilt, copied back by hand: adopt refuses it.
        vm("review").run_bundle(run_dir, cfg, rejecting(self.root / "declined.json", bundle["items"][2]["sha256"]))
        (run_dir / "selection.json").write_bytes(kept)
        library = empty_library(self.root / "library.json")
        with self.assertRaises(common.VisualError) as caught:
            vm("adopt").run_adopt(run_dir, library, 0)
        self.assertIn("selection.json was made from bundle", str(caught.exception))
        self.assertEqual(read(library)["revision"], 0)

    def test_a_bundle_made_before_bundles_had_ids(self):
        common = vm("common")
        run_dir, cfg, stand, bundle = self.bundled()
        legacy = dict(bundle)
        legacy.pop("bundle_id")
        write(run_dir / "review" / "bundle.json", legacy)
        for step in (lambda: self.observe(run_dir, cfg, {1: dict(SEEN, seen="x")}),
                     lambda: self.select(run_dir, cfg, choice_for(bundle["bundle_id"]))):
            with self.assertRaises(common.VisualError) as caught:
                step()
            self.assertIn("made before r5.37", str(caught.exception))


def fake_crawl4ai(enter=None, leave=None, page_errors=None, calls=None):
    """A stand-in for the crawl4ai package: only the browser's start, its pages and its close are simulated; the
    workshop's own crawl_pages and asyncio code run unchanged."""
    module = types.ModuleType("crawl4ai")
    module.__version__ = "stand-in"

    class Options:
        def __init__(self, **kwargs):
            pass

    class Crawler:
        def __init__(self, **kwargs):
            pass

        async def __aenter__(self):
            if enter:
                raise enter
            return self

        async def __aexit__(self, *args):
            if leave:
                raise leave
            return False

        async def arun(self, url, config):
            if calls is not None:
                calls.append(url)
            if page_errors and url in page_errors:
                raise page_errors[url]
            return types.SimpleNamespace(status_code=200, success=True, media={"images": [
                {"src": "https://img.example.org/shop.png", "alt": "柜台", "desc": "", "score": 3, "width": 320}]})

    module.AsyncWebCrawler = Crawler
    module.BrowserConfig = module.CrawlerRunConfig = Options
    module.CacheMode = types.SimpleNamespace(BYPASS=0)
    return module


@unittest.skipIf(sys.version_info < (3, 10), "the workshop only runs Crawl4AI on Python 3.10 or newer")
class CollectDegrades(Base):
    def collect(self, module, cfg=None, **kw):
        report, run_dir, stand, cfg = self.searched(cfg=cfg, **kw)
        with mock.patch.dict(sys.modules, {"crawl4ai": module}):
            result = vm("collect").run_collect(run_dir, cfg, fetch=stand)
        return result, run_dir, stand

    def test_the_browser_does_not_start(self):
        result, run_dir, stand = self.collect(fake_crawl4ai(enter=RuntimeError("BrowserType.launch: executable doesn't exist")))
        record = read(run_dir / "collect.json")  # written, not lost with the step
        self.assertEqual({p["status"] for p in record["pages"]}, {"browser_failed"})
        self.assertIn("did not start", record["pages"][0]["error"])
        self.assertEqual((result["status"], result["decoded"], result["browser_started"]), ("partial", 3, False))
        self.assertEqual((record["crawl4ai"]["importable"], record["crawl4ai"]["browser_started"]), (True, False))
        self.assertIn("crawl4ai-setup", " ".join(record["next"]))

    def test_a_page_failing_and_the_browser_failing_to_close(self):
        pages = []
        result, run_dir, stand = self.collect(fake_crawl4ai(page_errors={"https://page.example.org/shop": asyncio.TimeoutError("page timeout")},
                                                            calls=pages))
        record = read(run_dir / "collect.json")
        by = {p["page_url"]: p for p in record["pages"]}
        self.assertEqual(by["https://page.example.org/shop"]["status"], "error")
        self.assertEqual(by["https://page.example.org/lamp"]["status"], "ok")
        self.assertEqual(result["decoded"], 3)
        self.tearDown()
        self.setUp()
        result, run_dir, stand = self.collect(fake_crawl4ai(leave=RuntimeError("close failed")))
        record = read(run_dir / "collect.json")
        self.assertEqual({p["status"] for p in record["pages"]}, {"ok"})  # the pages read are kept
        self.assertIn("close failed", record["pages"][0]["browser"])

    def test_the_page_reader_itself_stops(self):
        report, run_dir, stand, cfg = self.searched()

        def broken(pages, config):
            raise RuntimeError("asyncio.run() cannot be called from a running event loop")

        result = vm("collect").run_collect(run_dir, cfg, fetch=stand, crawl=broken)
        record = read(run_dir / "collect.json")
        self.assertEqual({p["status"] for p in record["pages"]}, {"error"})
        self.assertIn("the page reader stopped", record["pages"][0]["error"])
        self.assertEqual((result["status"], result["decoded"]), ("partial", 3))

    def test_blocked_hosts_are_neither_crawled_nor_fetched(self):
        calls = []
        cfg = config(network={"blocked_hosts": ["blocked.example.org", "blockedimg.example.org"]})
        sx = sx_results(dict(SX, url="https://blocked.example.org/page", img_src="https://img.example.org/shop.png"),
                        dict(SX, url="https://page.example.org/drain", img_src="https://blockedimg.example.org/x.png"))
        result, run_dir, stand = self.collect(fake_crawl4ai(calls=calls), cfg=cfg, sx=sx)
        self.assertNotIn("https://blocked.example.org/page", calls)
        record = read(run_dir / "collect.json")
        by = {p["page_url"]: p for p in record["pages"]}
        self.assertEqual(by["https://blocked.example.org/page"]["status"], "blocked")
        fetched = {f["url"]: f for f in record["fetched"] if "url" in f}
        self.assertEqual(fetched["https://blockedimg.example.org/x.png"]["status"], "blocked")
        self.assertNotIn("https://blockedimg.example.org/x.png", stand.asked)
        with mock.patch.dict(sys.modules, {"crawl4ai": fake_crawl4ai(calls=calls)}):
            pages, version = vm("collect").crawl_pages(["https://blocked.example.org/a", "https://page.example.org/b"], cfg)
        self.assertEqual([p["status"] for p in pages], ["blocked", "ok"])
        self.assertNotIn("https://blocked.example.org/a", calls)


class FetchingAgain(Base):
    def test_a_failed_new_fetch_keeps_the_old_image_aside(self):
        common = vm("common")
        report, run_dir, stand, cfg = self.searched()
        vm("collect").run_collect(run_dir, cfg, fetch=stand, crawl=lambda p, c: ([], None))
        vm("rank").run_rank(run_dir, cfg, backend=FakeModel())
        vm("review").run_bundle(run_dir, cfg)
        failing = Stand({})
        result = vm("collect").run_collect(run_dir, cfg, fetch=failing, crawl=lambda p, c: ([], None))
        self.assertEqual((result["status"], result["decoded"], result["stale"]), ("failed", 0, 3))
        candidates = read(run_dir / "candidates.json")["candidates"]
        self.assertFalse([c for c in candidates if "image" in c])
        self.assertTrue(all(c["stale_image"]["why"].startswith("this fetch failed") for c in candidates))
        self.assertEqual(vm("rank").images_of(common.Run(run_dir)), [])
        with self.assertRaises(common.VisualError):
            vm("review").run_bundle(run_dir, cfg)
        manifest = read(run_dir / "run.json")
        self.assertEqual(manifest["outdated"][-1]["by"], "collect")
        self.assertEqual(sorted(manifest["outdated"][-1]["files"]), ["rank.json", "review"])
        self.assertEqual((manifest["steps"]["rank"]["status"], manifest["steps"]["review_bundle"]["status"]),
                         ("outdated", "outdated"))
        # Fetching again successfully gives the candidates their image back and drops the stale one.
        vm("collect").run_collect(run_dir, cfg, fetch=stand, crawl=lambda p, c: ([], None))
        candidates = read(run_dir / "candidates.json")["candidates"]
        self.assertEqual(sum(1 for c in candidates if "image" in c and "stale_image" not in c), 3)


class ConfigAndModel(Base):
    def test_unknown_or_empty_hash_algorithms(self):
        common = vm("common")
        for hashing in ({"algorithms": ["pahs"]}, {"algorithms": []}, {"algorithms": "phash"}, {"hash_size": 0},
                        {"max_distance": -1}, {"max_distance": 2.5}):
            path = write(self.root / "c.json", {"schema": "visual-materials-config/1", "imagehash": hashing})
            with self.assertRaises(common.VisualError, msg=hashing):
                common.load_config(path)
        # A config changed after loading (by a script) is refused by the step too, instead of grouping everything.
        report, run_dir, stand, cfg = self.searched()
        vm("collect").run_collect(run_dir, cfg, fetch=stand, crawl=lambda p, c: ([], None))
        cfg["imagehash"]["algorithms"] = ["pahs"]
        with self.assertRaises(common.VisualError):
            vm("dedupe").run_dedupe(run_dir, cfg)

    def test_a_model_that_fails_while_ranking(self):
        report, run_dir, stand, cfg = self.searched()
        vm("collect").run_collect(run_dir, cfg, fetch=stand, crawl=lambda p, c: ([], None))

        class Broken(FakeModel):
            def images(self, paths):
                raise RuntimeError("out of memory while encoding")

        result = vm("rank").run_rank(run_dir, cfg, backend=Broken())
        record = read(run_dir / "rank.json")
        self.assertEqual((result["status"], record["status"], record["clip_used"]), ("MODEL_ERROR", "MODEL_ERROR", False))
        self.assertIn("out of memory", record["error"])
        self.assertEqual(record["fallback"]["by"], "search_order")
        self.assertNotIn("scores", record)

    def test_reference_images_are_kept_in_the_run(self):
        common = vm("common")
        report, run_dir, stand, cfg = self.searched()
        vm("collect").run_collect(run_dir, cfg, fetch=stand, crawl=lambda p, c: ([], None))
        reference = self.root / "mine.png"
        reference.write_bytes(picture("lamp"))
        vm("rank").run_rank(run_dir, cfg, reference_images=[str(reference)], backend=FakeModel())
        kept = read(run_dir / "rank.json")["reference_images"][0]
        self.assertEqual(kept["sha256"], common.sha256_file(reference))
        self.assertEqual(common.sha256_file(run_dir / kept["file"]), kept["sha256"])
        self.assertTrue(kept["file"].startswith("references/"))


class VerifyCurrentEvidence(Base):
    def live_run(self):
        """Records written by hand as if the real services and models had answered (the review's offline contract
        probe). Nothing here is a live run; it checks verify-run's rules."""
        common = vm("common")
        folder = self.root / "run"
        run = common.Run(folder)
        (folder / "images").mkdir(parents=True)
        items = []
        for n, kind in enumerate(("shop", "lamp"), 1):
            data = picture(kind)
            sha = common.sha256_bytes(data)
            (folder / "images" / (sha + ".png")).write_bytes(data)
            items.append({"cid": "C0%d" % n, "image_url": "https://upload.wikimedia.org/%s.png" % kind,
                          "page_url": "https://commons.wikimedia.org/%s" % kind, "license": "CC BY 2.0",
                          "license_url": "https://creativecommons.org/licenses/by/2.0/",
                          "found_by": [{"provider": "searxng"}, {"provider": "openverse"}], "on_page": {"alt": kind},
                          "image": {"sha256": sha, "file": "images/%s.png" % sha, "width": 320, "height": 240,
                                    "format": "PNG", "what": "original"}})
        run.save("run.json", {"schema": common.RUN_SCHEMA, "request": REQUEST, "steps": {}})
        run.save_candidates(items)
        run.save("search.json", {"transport": "http", "providers": {"searxng": {"status": "ok"}, "openverse": {"status": "ok"}}})
        run.save("collect.json", {"transport": {"fetch": "http", "crawl": "crawl4ai"},
                                  "pages": [{"page_url": c["page_url"], "status": "ok"} for c in items]})
        run.save("dedupe.json", {"status": "ok", "algorithms": ["phash"],
                                 "images": [{"sha256": c["image"]["sha256"], "hashes": {"phash": h}}
                                            for c, h in zip(items, ("00", "ff"))]})
        reference = picture("drain")
        (folder / "references").mkdir()
        (folder / "references" / "r.png").write_bytes(reference)
        run.save("rank.json", {"status": "ok", "clip_used": True, "backend": "open_clip", "text_query": "shop",
                               "reference_images": [{"name": "r.png", "sha256": common.sha256_bytes(reference),
                                                     "file": "references/r.png"}],
                               "scores": [{"sha256": c["image"]["sha256"]} for c in items]})
        return folder, items

    def test_a_changed_image_is_not_five_live(self):
        folder, items = self.live_run()
        before = vm("verify").run_verify(folder)
        self.assertEqual((before["status"], before["all_five_live"]), ("ALL_FIVE_LIVE", True))
        (folder / items[1]["image"]["file"]).write_bytes(picture("door"))
        after = vm("verify").run_verify(folder)
        self.assertEqual(after["files"], ["C02: the image file is missing or changed"])
        self.assertEqual((after["status"], after["all_five_live"], after["all_five_ran"]), ("NOT_ALL_LIVE", False, True))
        self.assertEqual({n: (c["ran"], c["live_verified"]) for n, c in after["components"].items()},
                         {"searxng": (True, True), "openverse": (True, True), "crawl4ai": (True, True),
                          "imagehash": (True, False), "openclip": (True, False)})
        self.assertIn("only 1 of the 2 hashed images", after["components"]["imagehash"]["missing"])
        self.assertNotEqual(after["summary"], "五项在这次运行里都实际跑通")
        self.assertIn("跑过，但现在的证据核不上", after["summary"])

    def test_a_changed_file_outside_the_evidence(self):
        # All five components keep their evidence, but another image of the run changed: still not "all five".
        common = vm("common")
        folder, items = self.live_run()
        run = common.Run(folder)
        data = picture("drain")
        sha = common.sha256_bytes(data)
        (folder / "images" / (sha + ".png")).write_bytes(data)
        run.save_candidates(items + [{"cid": "C03", "image_url": "https://upload.wikimedia.org/drain.png",
                                      "page_url": "https://commons.wikimedia.org/drain", "found_by": [{"provider": "searxng"}],
                                      "image": {"sha256": sha, "file": "images/%s.png" % sha, "width": 320, "height": 240,
                                                "format": "PNG", "what": "original"}}])
        self.assertEqual(vm("verify").run_verify(folder)["status"], "ALL_FIVE_LIVE")
        (folder / "images" / (sha + ".png")).write_bytes(picture("door"))
        report = vm("verify").run_verify(folder)
        self.assertTrue(all(c["live_verified"] for c in report["components"].values()))
        self.assertEqual((report["status"], report["all_five_live"], report["files"]),
                         ("NOT_ALL_LIVE", False, ["C03: the image file is missing or changed"]))
        self.assertIn("1 张图的文件缺了或变了", report["summary"])

    def test_a_missing_reference_and_the_exit_code(self):
        folder, items = self.live_run()
        code, report = answer(run(CLI, "verify-run", "--run", folder))
        self.assertEqual((code, report["status"]), (0, "ALL_FIVE_LIVE"))
        (folder / "references" / "r.png").unlink()
        code, report = answer(run(CLI, "verify-run", "--run", folder))
        self.assertEqual((code, report["status"]), (1, "NOT_ALL_LIVE"))
        self.assertIn("reference image", report["components"]["openclip"]["missing"])
        # The author's chain is reported apart and does not count toward the five.
        self.assertEqual((report["chain"]["complete"], report["chain"]["adopt"]), (False, "not_run"))

    def test_a_new_fetch_outdates_the_old_evidence(self):
        folder, items = self.live_run()
        common = vm("common")
        run = common.Run(folder)
        run.save("run.json", dict(run.manifest(), steps={"dedupe": {"status": "ok"}, "rank": {"status": "ok"}}))
        moved = run.outdate("collect")
        self.assertEqual(sorted(moved), ["dedupe.json", "rank.json"])
        report = vm("verify").run_verify(folder)
        self.assertEqual((report["components"]["imagehash"]["ran"], report["components"]["openclip"]["ran"]),
                         (False, False))


class Sources(Base):
    def test_one_search_finding_the_same_image_twice(self):
        searxng = vm("providers.searxng")
        calls = []

        def answer_twice(url, *args, **kwargs):
            calls.append(url)
            item = {"img_src": "https://img.example.org/shared.png", "url": "https://page.example.org/%d" % len(calls),
                    "title": "Page %d" % len(calls), "engine": "test", "content": "description"}
            return response(200, json.dumps({"results": [item]}).encode())

        record, items = searxng.search(config(), ["first query", "second query"], 40, answer_twice)
        self.assertEqual(len(items), 1)
        self.assertEqual([(f["query"], f["page_url"]) for f in items[0]["found_by"]],
                         [("first query", "https://page.example.org/1"), ("second query", "https://page.example.org/2")])

    def test_a_licence_stays_with_its_page(self):
        searxng, openverse, search = vm("providers.searxng"), vm("providers.openverse"), vm("search")
        shared, plain, licensed = ("https://img.example.org/shared.png", "https://page.example.org/unlicensed",
                                   "https://page.example.org/licensed")
        a = searxng.candidate({"img_src": shared, "url": plain, "title": "first"}, "shop", 1)
        b = openverse.candidate({"url": shared, "foreign_landing_url": licensed, "creator": "Second creator",
                                 "license": "by", "license_version": "4.0", "title": "second",
                                 "license_url": "https://creativecommons.org/licenses/by/4.0/"}, "shop", 1)
        merged = search.merge([[a], [b]], 40)[0]
        self.assertEqual((merged["page_url"], merged["license"], merged["creator"], merged["found_by"][0]["provider"]),
                         (licensed, "CC BY 4.0", "Second creator", "openverse"))
        self.assertEqual([f["page_url"] for f in merged["found_by"]], [licensed, plain])
        # A sighting written without its own page (as the review's probe built it) takes its item's page.
        hand = dict(a, page_url=licensed, license="CC BY 4.0", creator="Second creator",
                    license_url="https://creativecommons.org/licenses/by/4.0/",
                    found_by=[{"provider": "openverse", "query": "shop", "openverse_id": "id"}])
        merged = search.merge([[a], [hand]], 40)[0]
        self.assertEqual((merged["page_url"], merged["license"]), (licensed, "CC BY 4.0"))
        self.assertIn(plain, json.dumps(merged))
        entry = vm("selection").entry_for(dict(merged, n=1, sha256="0" * 64, width=1, height=1), None, REQUEST,
                                          {}, "2026-10-24")
        self.assertEqual((entry["source"]["url"], entry["source"]["license"], entry["source"]["provider"]),
                         (licensed, "CC BY 4.0", "openverse"))


# --- the inspiration library -----------------------------------------------------------------------------------------

IMAGE = b"\x89PNG made-up bytes for the r5.37 library tests"
SHA = hashlib.sha256(IMAGE).hexdigest()


def writer():
    return load(WRITE, "r537_inspiration_write")


def v1_with_image():
    return {"schema": "inspiration-library/1", "book": "测试", "entries": [
        {"id": "A", "kind": "place", "title": "旧图", "status": "picked", "visible": "柜台在左", "take": ["柜台在左"],
         "source": {"type": "author_file", "file": "images/a.png", "sha256": SHA}, "conflicts": []}]}


def v2_candidate():
    return {"schema": "inspiration-library/2", "book": "测试", "revision": 0, "entries": [
        {"id": "A", "kind": "place", "title": "测试", "status": "candidate", "source": {"type": "text", "ref": "作者文字"},
         "observation": {"scope": "author_text", "seen": "柜台在左", "by": "作者"}, "conflicts": [],
         "use": [{"chapter": 1, "scene": "S1"}]}]}


def take_a(**fields):
    data = {"schema": "inspiration-selection/1", "decision": {"by": "作者", "date": "2026-10-24"},
            "adopt": [{"id": "A", "take": [{"part": "柜台在左", "scope": "stable"}]}]}
    data.update(fields)
    return data


class LibraryCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.w = writer()

    def tearDown(self):
        self.tmp.cleanup()


class MigrationTargets(LibraryCase):
    def test_two_migrations_to_the_same_out(self):
        # A is paused before it takes the lock; B migrates to the same --out and finishes. r5.35 let A overwrite B.
        w = self.w
        a = write(self.root / "a.json", {"schema": "inspiration-library/1", "book": "A", "entries": []})
        b = write(self.root / "b.json", {"schema": "inspiration-library/1", "book": "B", "entries": []})
        target = self.root / "shared.json"
        real = w.Lock
        done = []

        class OtherWriterFirst:
            def __init__(self, path):
                self.lock = real(path)

            def __enter__(self):
                with mock.patch.object(w, "Lock", real):
                    done.append(w.migrate(b, out=target))
                return self.lock.__enter__()

            def __exit__(self, *args):
                return self.lock.__exit__(*args)

        with mock.patch.object(w, "Lock", OtherWriterFirst):
            with self.assertRaises(w.LibraryError) as caught:
                w.migrate(a, out=target)
        self.assertIn("already exists", str(caught.exception))
        self.assertEqual((done[0]["status"], read(target)["book"]), ("OK", "B"))
        self.assertEqual([r["source"] for r in w.history(target)], ["b.json"])
        # Something else creating the file just before the lock: its bytes survive.
        other = self.root / "new.json"

        class CreateBeforeLock:
            def __init__(self, path):
                self.lock = real(path)
                self.path = Path(path)

            def __enter__(self):
                self.path.write_bytes(b"made by someone else")
                return self.lock.__enter__()

            def __exit__(self, *args):
                return self.lock.__exit__(*args)

        with mock.patch.object(w, "Lock", CreateBeforeLock):
            with self.assertRaises(w.LibraryError):
                w.migrate(a, out=other)
        self.assertEqual(other.read_bytes(), b"made by someone else")

    def test_a_migration_into_another_folder(self):
        w = self.w
        old = self.root / "old"
        (old / "images").mkdir(parents=True)
        (old / "images" / "a.png").write_bytes(IMAGE)
        source = write(old / "library.json", v1_with_image())
        target = self.root / "new" / "library.json"
        target.parent.mkdir()
        with self.assertRaises(w.LibraryError) as caught:
            w.migrate(source, out=target)
        self.assertIn("nothing written", str(caught.exception))
        self.assertIn("copy the image files next to the new library", str(caught.exception))
        self.assertEqual(sorted(p.name for p in target.parent.iterdir()), [])
        # Explicit --root: the result reads the images from there, and check needs the same --root.
        code, report = answer(run(WRITE, "migrate", source, "--out", target, "--root", old))
        self.assertEqual((code, report["status"]), (0, "OK"), report)
        code, report = answer(run(READ, "check", target, "--root", old))
        self.assertEqual(report["problems"], [])
        code, report = answer(run(READ, "check", target))
        self.assertEqual(report["problems"], ["A: file not found: images/a.png"])
        # Images copied next to the new library first: no --root needed.
        target.unlink()
        shutil.rmtree(w.history_dir(target))
        shutil.copytree(old / "images", target.parent / "images")
        self.assertEqual(w.migrate(source, out=target)["status"], "OK")
        code, report = answer(run(READ, "check", target))
        self.assertEqual(report["problems"], [])
        # The same folder (the default) as before.
        self.assertEqual(w.migrate(source)["status"], "OK")
        code, report = answer(run(READ, "check", old / "library.v2.json"))
        self.assertEqual(report["problems"], [])


class CommitOrder(LibraryCase):
    def test_a_failure_before_the_library_file_is_replaced(self):
        w = self.w
        library = write(self.root / "library.json", v2_candidate())
        before = library.read_bytes()
        real = w.keep

        def fail_new_snapshot(path, data, revision, only_if_missing=False):
            if revision == 1:
                raise OSError("simulated new-snapshot failure")
            return real(path, data, revision, only_if_missing)

        with mock.patch.object(w, "keep", side_effect=fail_new_snapshot):
            with self.assertRaises(w.NotCommitted) as caught:
                w.adopt(library, take_a(), 0)
        self.assertIn("nothing written", str(caught.exception))
        self.assertEqual(library.read_bytes(), before)
        history = w.history_dir(library)
        self.assertEqual(sorted(p.name for p in history.iterdir()), [])
        self.assertFalse(Path(str(library) + ".lock").exists())
        self.assertEqual(w.adopt(library, take_a(), 0)["revision"], 1)  # nothing stands in the way of trying again

    def test_a_failure_after_the_library_file_is_replaced(self):
        w = self.w
        library = write(self.root / "library.json", v2_candidate())
        with mock.patch.object(w, "log", side_effect=OSError("simulated log failure")):
            with self.assertRaises(w.CommittedIncomplete) as caught:
                w.adopt(library, take_a(), 0)
        self.assertEqual(caught.exception.revision, 1)
        self.assertIn("Do not repeat this write", str(caught.exception))
        self.assertEqual(read(library)["revision"], 1)
        self.assertEqual(caught.exception.sha256, hashlib.sha256(library.read_bytes()).hexdigest())
        listed = w.history(library)
        self.assertEqual((listed[-1]["committed"], listed[-1]["pending"]["to_revision"]), (True, 1))
        # The next write finishes the log first, then does its own work.
        report = w.adopt(library, {"schema": "inspiration-selection/1", "decision": {"by": "作者", "date": "2026-10-24"},
                                   "establish": [{"id": "A", "part": "柜台在左", "where": "项目档案", "chapter": 1}]}, 1)
        self.assertEqual((report["revision"], report["finished_pending"]["pending"]), (2, "finished"))
        self.assertEqual([(r["action"], r["to_revision"], r.get("finished_later", False)) for r in w.history(library)],
                         [("adopt", 1, True), ("adopt", 2, False)])
        self.assertFalse((w.history_dir(library) / "pending.json").exists())
        # Repeating the first write from the revision it started at is a conflict, not a second copy.
        with self.assertRaises(w.Conflict):
            w.adopt(library, take_a(), 0)

    def test_the_command_line_says_committed_incomplete(self):
        w = self.w
        library = write(self.root / "library.json", v2_candidate())
        selection = write(self.root / "selection.json", take_a())
        printed = io.StringIO()
        with mock.patch.object(w, "log", side_effect=OSError("simulated log failure")), \
                mock.patch.object(sys, "argv", ["inspiration_write.py", "adopt", str(library), "--selection",
                                                str(selection), "--if-revision", "0"]), \
                contextlib.redirect_stdout(printed):
            code = w.main()
        report = json.loads(printed.getvalue())
        self.assertEqual((code, report["status"], report["revision"]), (4, "COMMITTED_INCOMPLETE", 1))

    def test_a_cut_off_log_line(self):
        w = self.w
        library = write(self.root / "library.json", v2_candidate())
        w.adopt(library, take_a(), 0)
        with (w.history_dir(library) / "log.jsonl").open("ab") as handle:
            handle.write(b'{"action":')
        listed = w.history(library)
        self.assertEqual((listed[0]["action"], listed[1]["unreadable_line"]), ("adopt", 2))
        w.adopt(library, {"schema": "inspiration-selection/1", "decision": {"by": "作者", "date": "2026-10-24"},
                          "establish": [{"id": "A", "part": "柜台在左", "where": "项目档案", "chapter": 1}]}, 1)
        listed = w.history(library)
        self.assertEqual([r.get("action", "unreadable") for r in listed], ["adopt", "unreadable", "adopt"])
        code, report = answer(run(WRITE, "history", library))
        self.assertEqual(code, 0)


class RestoreAndBase(LibraryCase):
    def test_restore_checks_the_copy(self):
        w = self.w
        library = write(self.root / "library.json", v2_candidate())
        bad = v2_candidate()
        bad["entries"][0]["status"] = "picked"  # no take, no decision
        backup = write(self.root / "bad-backup.json", bad)
        before = library.read_bytes()
        with self.assertRaises(w.LibraryError) as caught:
            w.restore(library, 0, backup=backup)
        self.assertIn("would not pass check, nothing written", str(caught.exception))
        self.assertEqual(library.read_bytes(), before)
        # An image file that is only missing now is reported, and the restore goes ahead.
        offline = v2_candidate()
        offline["entries"].append({"id": "B", "kind": "place", "title": "作者的图", "status": "candidate",
                                   "source": {"type": "author_file", "file": "images/b.png", "sha256": SHA},
                                   "observation": {"scope": "none"}, "conflicts": [], "use": []})
        report = w.restore(library, 0, backup=write(self.root / "offline.json", offline))
        self.assertEqual((report["status"], report["revision"]), ("OK", 1))
        self.assertEqual(report["files_now"], ["B: file not found: images/b.png"])

    def test_restore_of_the_format_one_original(self):
        w = self.w
        (self.root / "images").mkdir()
        (self.root / "images" / "a.png").write_bytes(IMAGE)
        library = write(self.root / "library.json", v1_with_image())
        original = library.read_bytes()
        report = w.migrate(library, replace=True)
        backup = w.history_dir(library) / Path(report["rollback"].split("--from ")[1]).name
        self.assertEqual(w.restore(library, 1, backup=backup)["schema"], "inspiration-library/1")
        self.assertEqual(library.read_bytes(), original)

    def test_base_revision_must_match(self):
        w = self.w
        library = write(self.root / "library.json", dict(v2_candidate(), revision=5))
        with self.assertRaises(w.LibraryError) as caught:
            w.adopt(library, take_a(base_revision=0), 5)
        self.assertIn("made on revision 0", str(caught.exception))
        self.assertEqual(read(library)["revision"], 5)
        self.assertEqual(w.adopt(library, take_a(base_revision=5), 5)["revision"], 6)


class Portability(LibraryCase):
    def test_a_library_copied_to_another_folder(self):
        w = self.w
        here = self.root / "here"
        (here / "images").mkdir(parents=True)
        (here / "images" / "a.png").write_bytes(IMAGE)
        library = write(here / "library.json", v1_with_image())
        w.migrate(library, replace=True)
        # r5.38: A is already picked (format 1 picked it with this part, scope not said), so the choice says that it
        # replaces what was taken; without a mode an already picked entry is refused (the r5.37 review, point 1.1).
        w.adopt(library, {"schema": "inspiration-selection/1", "decision": {"by": "作者", "date": "2026-10-24"},
                          "adopt": [{"id": "A", "mode": "replace", "take": [{"part": "柜台在左", "scope": "stable"}],
                                     "use": [{"chapter": 3}]}]}, 1)
        there = self.root / "elsewhere" / "book"
        shutil.copytree(here, there)
        moved = there / "library.json"
        code, report = answer(run(READ, "check", moved))
        self.assertEqual((code, report["problems"]), (0, []))
        code, card, err = run(READ, "card", moved, "--chapter", "3")
        self.assertIn("柜台在左", card)
        code, report = answer(run(WRITE, "history", moved))
        self.assertEqual([r["action"] for r in report["log"]], ["migrate", "adopt"])
        code, report = answer(run(WRITE, "restore", moved, "--if-revision", 2, "--revision", 1))
        self.assertEqual((code, report["revision"]), (0, 3), report)
        self.assertEqual(read(library)["revision"], 2)  # the original folder is untouched


if __name__ == "__main__":
    unittest.main()

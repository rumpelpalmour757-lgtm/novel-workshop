# 对白声纹与反模式：可选试用入口

当前扩展：dialogue-lint 1.2.0，2026-11-14。作者要求测试对白声纹、伪口语或反模式检测时使用。先读本轮原文和相关人物配置，运行只读扫描，再逐处回读；只安装、跑通程序不代表文笔改善。

## 在当前作品上测试

从当前技能根目录运行（需要 Python 3.9 或更新版本，只用标准库；加不加 `-I -B` 都能运行，运行后不在技能目录里留缓存）：

```bash
python3 scripts/dialogue_lint/run_lint.py scan 章稿.txt --config 本书配置.json --output 对白复核.json
```

按作品入口读取本书的配置文件；其他书从[空配置模板](../assets/dialogue-lint-config.example.json)建立自己的配置，不借用其他作品人物。`profiles` 的键是角色名，值可以是空对象 `{}`，也可以写 `archetype`（作者给这个人物起的类型名）和 `voice_prompt`（作者对他说话方式的说明，连续短句提示里会原样带上）；这两项都不改变任何检查。旧配置里的 `min_avg_len`、`min_colloquial_rate` 仍可保留，扫描不再拿它们比较，报告的 `config_notes` 会写明。名字写在 `profiles`、`cold_protagonist_names`、`stress_speakers` 任何一处都算登记；没有登记的名字，台词的说话人一律记“未知”。

- 认的引号：`“”`、`「」`、`『』`，和 [dialogue_lines.py](../scripts/dialogue_lines.py) 认的一样。`“”` 里再引用用 `‘’`，`「」` 里再引用用 `『』`，里面那一层不另算一条台词。一行里开了引号到行末还没收的（跨段接着说，或漏了后引号），按读到行末算一条台词，报告里这条的 `closed` 是 `false`，不进候选改句。直引号（`"`）、全角直引号和配不上对的引号不当作台词扫描；报告的 `quote_coverage` 按行列出这些地方，命令行也会打印一行“提示”。一句台词都没认出来时，报告会写明“没有认出台词”，这个 0 不说明稿子里没有台词。
- 按引语分别定位，段号按输入物理行计，空行占一行，引语号从1开始。可用 `speaker_overrides` 明确指定某行某条引语的说话人；示例结构：`{"para_index": 2, "quote_index": 1, "speaker": "角色名"}`。只填核对过的位置，不把一章的覆盖表套到另一章。
- `explicit` 为明确发言提示，`manual` 为作者指定，`inferred` 为动作主语推测，`unknown` 为未知。只将前两种计入角色数字和候选补丁请求；逐条查看推测与未知，不能为了提高统计覆盖率乱认人。“某某对某某没有说”“跟某某一起说”这类写法不认成前一个人在说。
- 不加 `--style-hints` 时，扫描只做说话人归属和角色数字，另外只查本书配置 `suspicious_expressions` 里列出的词组（逐字匹配，比如作者点过名、想在全书里找出来再读一遍的说法）；不列就不查措辞。报告的 `checks_run` 写明这一次实际查了哪些。作者要看全部文风提示时，加 `--style-hints`。
- 所有文风命中只标 `REVIEW`。可保留作者有意的短句、祈使、省略、书面术语和无语气词回答；不按命中添“呢”“嘶”、改句号或补动作，不凭命中判定英文来源或机器创作。
- 生理压力由 `stress_speakers` 显式声明，仅对本次输入有效；不从“血”“歪”等字推定状态，也不强制喘息或痛呼。
- 目前不解析同一引语跨物理行的软换行；这种稿件继续按[中文标点](chinese-punctuation.md)的软换行方式核对，不为工具擅改版式。
- 稿子和配置可以带 UTF-8 的 BOM；带 BOM 的稿子，写出的候选稿也带 BOM。

## 角色那一栏：只给数字

`voice_report` 里每个说话人一行，只有数字：台词数、待确认台词数、分句数、平均分句长、口语标记命中台词数和命中率（选了题材时另写所用的口语标记）。只算 `explicit` 和 `manual` 的台词；推测和未知的只计入“待确认台词数”。这一栏不和任何线比较，不给人物下“需要回读”“没问题”一类的结论。摘要 `summary` 里的计数和正文对得上：确认台词数等于各行台词数之和，复核条数等于两组命中条数之和，可进候选改句的引语数等于请求里的条数。

[对白专项](dialogue-craft.md)写的是“不立句数和字数的线；台词写多了还是写少了，工坊不判”，语气词“惜字的人可以一个不用”。这组数字和这两句不冲突，用法只有回读一种：

- 拿一个人的数字和作者认可过的他的样本对一对，差得远的，回去读那几句是不是他此刻会说的话；
- 几个人在同一场里数字很接近，回去读一遍，看读下来分不分得出谁是谁（对白专项“回头看的是读下来分不出谁是谁”）；
- 改过一稿以后某个人的数字变化很大，回去看是哪几句变了、为什么变。

不把数字当目标：不为了提高命中率加语气词，不为了拉长平均分句长并句子，也不凭数字说一个人的口吻好或不好。数字低、数字高都不是毛病，读了以后由作者定。

## 惜字、常下令的人物

说话本来就短、不带语气词的人（惜字的、下令的、报数的），把名字写进本书配置的 `cold_protagonist_names`。这个字段名沿用旧版，不限主角，任何人物都可以登记。登记以后，这个人确认过的台词不做短句和语气词提示：省略式祈使句、连续短句节奏、简短状态并列、简短方位回答（COMP_01 到 COMP_04）和连续短句提示（VOICE_SHORT_CLAUSES）都不报。他的数字照样列出，那一行的“不做短句提示”是 `true`；本书词组、句式提示和受压复核照常执行。推测和未知的台词不在其内，要先确认说话人或用 `speaker_overrides` 指定。只在某几场惜字的，不登记人物，按下面的“场景提示与定点豁免”逐句声明。

## 和“只有 AI 才会这样说吗”的关系

对白专项“只有 AI 才会这样说吗”一节是改稿时由人问的问法，不计数，不做成扫描。这里的扫描只列位置，列出来的句子仍照那一节由人回读、由人问；扫描命中多少不代表稿子像不像人写的。规则编号（如 `COMP_04_COORDINATE_REPLY`）只是在配置里点名用的，编号里的英文词不是结论；报告里每条命中另有中文名和说明。交给模型的候选请求只带中文名、说明和命中的字，不带规则编号和改法。

## 显式选择题材参数

三种预设是可调整的起点，不是全题材标准，也不按书名或关键词自动选择。用 `--genre modern_gritty`、`--genre classical_xianxia` 或 `--genre western_fantasy`；也可在本书配置填写 `genre_id`，命令行选择优先。没选题材时保持原中性行为。

| 配置 | 连续短句平均长度参考线 | 差异 |
| --- | --- | --- |
| modern_gritty | 9.5 | 13项候选规则可选 |
| classical_xianxia | 7.5 | 关闭 COMP_02、COMP_03、COMP_04，容许凝练短句 |
| western_fantasy | 10.5 | 关闭 COMP_04、TRANS_03、TRANS_06，保留译制口吻选择 |

`genre_overrides` 可覆盖 `enabled_rules`、`max_avg_clause_len`、`colloquial_markers`（正则字符串）、`enable_system_bracket_anchor` 和 `tactical_scene_keywords`（正则字符串）。未知ID、非法正则、非正或非有限阈值会报错；预设不可被原地改动。`enabled_rules: []` 关闭13项规则和连续短句提示；独立显式声明的压力复核和本书格式检查仍照配置执行。选择题材不会自动开启 `--style-hints`，三种预设也都不开系统【】的锚点检查。

题材词库实际用于口语标记统计和连续短句提示；平均长度参考线只用于连续短句提示，不替代13条各自的匹配结构，也不是人物的线。标记命中率不是“人味分”。

## 场景提示与定点豁免

`通讯器/耳麦/公堂/宣读` 等命中只出现在 `scene_keyword_hints`，不会自动免检。作者已确认场景时，才在当次配置的 `scene_overrides` 声明精确引语及需要暂免的规则，例如：

```json
{"para_index": 2, "quote_index": 1, "quote": "在门后头。", "mode": "tactical", "reason": "作者确认这是通话中的方位答复。", "exempt_rule_ids": ["COMP_04_COORDINATE_REPLY"]}
```

`mode` 可为 `tactical`、`formal_reading` 或 `normal`；前两种须显式列出非空 `exempt_rule_ids`，normal须为空数组。豁免仅限本条引语中列出的规则，同句其他规则和其他人物的台词照常检查。只允许 SYN_02、SYN_03、COMP_02、COMP_03、COMP_04、TRANS_05、TRANS_06 这组文风线索，不允许借场景关闭本书词组、压力或系统格式检查。记录原句与当前文本不符时拒绝运行，不能把旧覆盖表套到新稿。

## 系统【】与锚点独立配置

必须在本书配置显式设置 `system_brackets.enabled: true` 并声明 `active_tags` 或 `panel_prefixes`，才检查已声明的独行项目。普通 `【注意安全】` 不自动当系统项。

`system_brackets` 接受 `enabled`、`check_anchors`、`active_tags`、`panel_prefixes`、`anchor_pattern`、`forbid_outer_punctuation`。`forbid_outer_punctuation` 只有明确设为true才检查括号外标点；只对已声明主动名称检查末尾标点，不删除面板完整句标点。

锚点指系统项出现之前紧挨着的那一段里，交代它为什么在这时出现的文字，比如人物按下了什么、身上有了什么感觉。锚点检查只在本书配置写 `check_anchors: true` 时才做，题材预设不替作者打开。没有 `anchor_pattern` 时，只给人工复核提示，请人看一眼前一段有没有这样的交代；提供正则时按前一非空段 `fullmatch` 核对已配置的形式，可报格式ERROR，不能证明动作或体感在语义上成立，也不自动补动作。报告的 `effective_system_policy` 写明本次实际开启了哪种检查。系统项不会进入对白候选补丁。扫描退出码0表示无格式ERROR（可能有REVIEW），1表示声明的格式ERROR，2表示输入/配置无效。

标签句末带标点（如 `【检修。】`）在这里和[标点检查](chinese-punctuation.md)里都判 ERROR，但两边读的是不同的配置：这里读本书对白配置的 `system_brackets.active_tags`，标点检查读项目规则里的 `ability_tags`。同一个标签要在两处都登记，否则两边结论会不一样；交付门看的是标点检查，不看这里。

## 只在作者要候选改句时生成补丁

```bash
python3 scripts/dialogue_lint/run_lint.py scan 章稿.txt --config 本书配置.json --style-hints --request-output 请求.json --prompt-output 请求提示.txt
```

请求按同一引语合并各条问题，只收说话人已确认、引号在本行收好的台词。把请求提示交给模型得到纯JSON候选。应用之前，把每一条原句和候选改句并排列给作者，写明多了什么、少了什么；作者同意了的才写进候选文件，模型不替作者确认。然后应用到新文件，`--config`、`--style-hints`、`--genre` 要和扫描时一样：

```bash
python3 scripts/dialogue_lint/run_lint.py apply 章稿.txt 请求.json 模型候选.json --output 候选稿.txt --config 本书配置.json --style-hints
```

应用时按同一份原稿、配置和选项重新扫描一遍，请求文件必须和重新扫描得出的请求一字不差：哪几条能改、原句、说话人都以重新扫描为准，请求文件被改过、原稿或配置在扫描后改过、选项和扫描时不同，都拒绝运行，不写任何文件，要重新扫描。1.1.0 生成的旧请求也要重新扫描。另外校验候选的源版本、引语位置、原文字面和重复ID/字段：替换文字不能换行，不能带进原句没有的引号或【】，也不能挪动引号的位置；`‘’` 这样的内层引号可以用。成功时命令行列出这次替换了哪几条。所有输出使用新文件名，不覆盖原文。校验保护的是结构范围，不能证明事实与文学效果没变；改完仍按[编辑](editing.md)的修订前后对照回读。作者只要扫描时，不自行生成或应用补丁。

## 工具资源

- [命令行入口](../scripts/dialogue_lint/run_lint.py)
- [逐引语归属、引号识别与原文位置](../scripts/dialogue_lint/dialogue_core.py)
- [角色数字与连续短句提示](../scripts/dialogue_lint/voice_lint.py)
- [本书词组与13项可选规则](../scripts/dialogue_lint/dialogue_antipatterns.py)
- [候选请求、重新扫描核对及范围校验](../scripts/dialogue_lint/patch_guard.py)
- [题材参数与精确场景豁免](../scripts/dialogue_lint/genre_profiles.py)
- [本书声明的系统格式与锚点](../scripts/dialogue_lint/system_brackets.py)

作者测试期间作为辅助入口，保留现有按人物回读与 `dialogue_lines.py`；不新增交付门必过条件，不把检查清零作为目标。正式宣称写法优于旧版前，另按[技能维护的新旧对照](skill-evaluation.md)做文学验证并取得作者评价。

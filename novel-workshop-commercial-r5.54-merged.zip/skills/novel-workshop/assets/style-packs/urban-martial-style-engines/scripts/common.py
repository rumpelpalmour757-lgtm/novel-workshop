"""check_combo.py、lint_text.py、export_prompt.py 共用的部分，只用标准库。

读 references/library.json（由 build_library.py 生成），规范编号，读本书设定档，展开配方，检查组合。
"""
import json
import sys
from pathlib import Path

for _s in (sys.stdout, sys.stderr):   # Windows 下重定向到文件时，个别符号编码不了也不报错
    try:
        _s.reconfigure(errors="replace")
    except AttributeError:
        pass

ROOT = Path(__file__).resolve().parent.parent
_LIB_FILE = ROOT / "references" / "library.json"
if not _LIB_FILE.exists():
    sys.exit("找不到 references/library.json：先运行 python scripts/build_library.py")
LIB = json.loads(_LIB_FILE.read_text(encoding="utf-8"))
E, R, G, CORE = LIB["engines"], LIB["router"], LIB["global_rules"], LIB["core"]
CHECKLIST = LIB.get("checklist", [])
SLOTS = R["slots"]
SLOT_KEYS = ("slot_1", "slot_2", "slot_3")


def norm(n):
    """'6'、6、'06' 都规范成 '06'；三位数原样。"""
    return str(n).strip().zfill(2)


def label(n):
    return f"{n}{E[n]['name']}" if n in E else n


def read_text(path):
    """读正文或设定档：先按 UTF-8（带不带BOM都行），不行再按 GB18030（Windows 记事本的老格式）。- 表示标准输入。"""
    data = sys.stdin.buffer.read() if path == "-" else Path(path).read_bytes()
    for enc in ("utf-8-sig", "gb18030"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def as_list(v):
    """设定档里只写一项时（L1: '06'、extra_ban: 冷笑）也当一项，不拆成单字。"""
    if v is None or v == "":
        return []
    return v if isinstance(v, list) else [v]


def load_profile(path):
    """读本书设定档（YAML）。L1 规范成编号列表，列表字段缺省为空。"""
    try:
        import yaml
    except ImportError:
        sys.exit("读本书设定档需要 PyYAML：pip install pyyaml。不装也行：改用 --book、--ban、--allow 参数")
    p = Path(path)
    if not p.exists():
        sys.exit(f"找不到设定档：{path}")
    d = yaml.safe_load(read_text(p)) or {}
    d["L1"] = [norm(x) for x in as_list(d.get("L1"))]
    for k in ("extra_ban", "extra_allow", "scale_overrides", "notes"):
        d[k] = [str(x) for x in as_list(d.get(k))]
    d["characters"] = d.get("characters") or []
    d["volumes"] = d.get("volumes") or []
    return d


def expand_recipe(name):
    """返回 (每槽第一个候选, 配方建议的本书L1, {槽: 其余候选}, 说明)。"""
    rec = R["recipes"].get(name)
    if not rec:
        sys.exit(f"没有这个配方：{name}。可选：{'、'.join(R['recipes'])}")
    nums, alts = [], {}
    for s in SLOT_KEYS:
        if rec.get(s):
            nums.append(rec[s][0])
            alts[s] = rec[s][1:]
    return nums, list(rec.get("L1", [])), alts, rec.get("note", "")


def expand_volume(prof, idx):
    """按设定档 volumes 的第 idx 卷（从1数）取引擎：先套 recipe，再用卷里写的 slot_1–slot_3 覆盖。

    返回 (每槽第一个候选, {槽: 其余候选}, 说明, 卷名)。
    """
    vols = prof.get("volumes") or []
    if not 1 <= idx <= len(vols):
        sys.exit(f"设定档里没有第{idx}卷（共{len(vols)}卷）")
    v = vols[idx - 1] or {}
    cands, notes = {}, []
    if v.get("recipe"):
        rec = R["recipes"].get(v["recipe"])
        if not rec:
            sys.exit(f"第{idx}卷的配方不存在：{v['recipe']}。可选：{'、'.join(R['recipes'])}")
        cands = {s: list(rec[s]) for s in SLOT_KEYS if rec.get(s)}
        if rec.get("note"):
            notes.append(rec["note"])
    for s in SLOT_KEYS:
        if v.get(s):
            cands[s] = [norm(x) for x in v[s]]
    if v.get("notes"):
        notes.append(str(v["notes"]))
    nums = [c[0] for c in cands.values()]
    alts = {s: c[1:] for s, c in cands.items()}
    return nums, alts, "；".join(notes), v.get("name") or f"第{idx}卷"


def _assign(nums, problems):
    """L1→槽1，L3→槽2，L2→槽3，L4→槽1或槽3里空着的那个。"""
    slots = dict.fromkeys(SLOT_KEYS)
    order = {"L1": 0, "L3": 1, "L2": 2, "L4": 3}
    for n in sorted(nums, key=lambda x: order[E[x]["layer"]]):
        cands = [s for s in SLOT_KEYS if E[n]["layer"] in SLOTS[s]["layers"]]
        free = [s for s in cands if slots[s] is None]
        if free:
            slots[free[0]] = n
        else:
            taken = "、".join(f"{SLOTS[s]['name']}（{slots[s]}）" for s in cands)
            problems.append(f"{label(n)}（{E[n]['layer']}）没有空槽：{taken}已被占")
    return slots


def check(nums, book):
    """检查一次写作的组合。

    nums：本次加载全文的引擎；book：本书锁定的L1。
    返回 (nums, book, slots, problems, notes)，nums 与 book 已去重、去掉不存在的编号。
    """
    problems, notes = [], []
    for n in dict.fromkeys(nums + book):
        if n not in E:
            problems.append(f"{n}：{R['merged'].get(n, '没有这个编号')}")
    nums = [n for n in dict.fromkeys(nums) if n in E]
    book = [n for n in dict.fromkeys(book) if n in E]
    for n in book:
        if E[n]["layer"] != "L1":
            problems.append(f"本书锁定只填L1引擎：{label(n)}是{E[n]['layer']}")
    if len(book) > 2:
        problems.append(f"本书L1最多1主+1副，现在{len(book)}个")
    cap = SLOTS["max_engines_per_call"]
    if len(nums) > cap:
        problems.append(f"一次最多{cap}个引擎全文，现在{len(nums)}个")
    slots = _assign(nums, problems)

    chosen, seen = set(nums) | set(book), set()

    def flag(a, b, msg):
        if frozenset((a, b)) not in seen:
            seen.add(frozenset((a, b)))
            problems.append(msg)

    for p in R["forbidden_pairs"]:
        for a in sorted(chosen & set(p["a"]), key=int):
            for b in sorted(chosen & set(p["b"]), key=int):
                flag(a, b, f"禁配（{p['level']}）：{label(a)} × {label(b)}——{p['why']}")
    for t in R.get("tag_clash", []):
        a = sorted((n for n in chosen if t["a"] in E[n].get("tags", [])), key=int)
        b = sorted((n for n in chosen if t["b"] in E[n].get("tags", [])), key=int)
        if a and b:
            problems.append(f"调性冲突（{t['level']}）：{t['a']}{'、'.join(a)} × {t['b']}{'、'.join(b)}——{t['why']}")
            seen.update(frozenset((x, y)) for x in a for y in b)
    for a in sorted(chosen, key=int):
        for b in E[a]["conflicts"]:
            if b in chosen:
                flag(a, b, f"冲突：{label(a)} × {label(b)}（见两个引擎文件的 conflicts 与 load_when）")
    for g in R.get("exclusive_groups", []):
        hit = sorted(chosen & set(g["members"]), key=int)
        if len(hit) > 1:
            problems.append(f"互斥组「{g['name']}」只能选一个（{g['level']}）：{'、'.join(map(label, hit))}——{g['why']}")
    for m in R.get("mode_pairs", []):
        if m["num"] in chosen:
            hit = sorted((n for n in chosen if m.get("b_tag") in E[n].get("tags", []) or n in m.get("b", [])), key=int)
            if hit:
                notes.append(f"{label(m['num'])}这一章别用「{m['mode']}」模式：与{'、'.join(hit)}{m['level']}禁配")

    if not book:
        notes.append("没给本书L1（--book 或 --profile）：身份锁只按本次槽里的L1算")
    for n in nums:
        if E[n]["layer"] == "L1" and book and n not in book:
            notes.append(f"{label(n)}不在本书锁定的L1里：只当本场视角人物或配角的模板，它的身份锁不扩展到全书")
    for n in dict.fromkeys(book + [x for x in nums if E[x]["layer"] == "L1"]):
        if E[n].get("lock"):
            notes.append(f"身份锁 {label(n)}：{'；'.join(E[n]['lock'])}")
    return nums, book, slots, problems, notes

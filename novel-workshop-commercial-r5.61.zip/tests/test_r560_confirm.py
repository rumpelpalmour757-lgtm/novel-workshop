#!/usr/bin/env python3
"""r5.60: the rare cases of "the author hands back his own changed text" that r5.59 shipped as known.

r5.59's last reading of the locked line (chapter-confirmation.md "确认是什么意思") found one case with two readings
(a chapter that goes to the teacher; stage 5 confirmed, the workshop's revision waiting at stage 6; the author brings a
late batch of teacher notes together with his own changed revision and says it passes) and a few notes. The author
decided that r5.60 adds the clause for that rare case, and that a locked sentence is shown to him before it is touched.
Which of the two readings the clause takes was the maker's proposal, as r5.59's notes already said; it was written
first and shown to the author, who has approved that reading. The other changes listed below (the note on "通过", the
gate's limits, the restatements on the learning-loop page) are the maker's follow-ups to r5.59's last reading, not
changes the author asked for: each was shown to the author with the old and the new sentence before it was written,
the author approved them, and each has its switch below. The locked section itself the author left as it is in this
release.

What r5.60 changes here sits OUTSIDE the locked section, and the locked lines are byte for byte r5.59's:

- chapter-confirmation.md "完整初稿以后", the bullet "方案交出以后又来了一批": a late batch after the plan is confirmed
  reopens the review stage too; brought back together with the author's changed revision, it is registered first, and
  what follows is the first time of the exception; what the author changed is compared with the workshop's revision.
- chapter-confirmation.md "记录怎么写", confirm: the author's "通过" said with his changed text is not a confirmation
  of the earlier presentation. This note was shown to the author first and approved (PASS_NOTE_APPROVED below).
- chapter-confirmation.md "脚本核得了什么，核不了什么": the gate cannot tell whose text a teacher return is
  (shown to the author first and approved, GATE_NOTE_APPROVED).
- learning-loop.md "在章节流程里怎么起一轮": a new paragraph says how the late batch is recorded. Shown to the author
  first and approved: the opening sentence carries the conditions (OPENING_APPROVED); the sentence on a teacher
  chapter no longer reads as covering a chapter the workshop reviews and says what the gate refuses and what it
  takes (TEACHER_PARAGRAPH_APPROVED); stage 6 is still confirmed after it is presented again (STAGE_SIX_APPROVED).

The walk-throughs use synthetic text. They show what the scripts store, not that the workshop handles these cases
better in real chapters. No script is changed in r5.60 for this.
"""
import hashlib
import importlib.util
import os
from pathlib import Path
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
AUTHOR = {"actor_role": "author", "mode": "human"}
# Lines 53-60 of chapter-confirmation.md, each with its line break: the hash the registry records for r5.59.
# The author left the locked line as it is in r5.60. If a change to it is approved, this constant, the registry entry
# and the pins in test_r559_maintenance.py / test_r559_self_correction.py / test_r554_dialogue.py change together,
# with the approval.
LOCKED_R559 = "e73b02c0181c6f18221885f9c5f9a0aee2008745a4850269919272d4f9a8de72"
ABSOLUTES = ("永远", "绝不", "必须", "严禁")
# The note under "记录怎么写" (the author's "通过" said with his changed text) sits on the page of the locked section
# and is about what a confirmation counts for, so the author sees the sentence before it is written. False while
# that is open: the page then has no such note. True once the author has said yes and the note is in.
PASS_NOTE_APPROVED = True
# The same for the four follow-ups to r5.59's last reading, each shown to the author first. False: the line is as
# r5.59 has it. True: the author has said yes and the new sentence is in.
GATE_NOTE_APPROVED = True          # chapter-confirmation.md, "脚本核得了什么，核不了什么"
OPENING_APPROVED = True            # learning-loop.md, the opening sentence of the item
TEACHER_PARAGRAPH_APPROVED = True  # learning-loop.md, the paragraph on a chapter that goes to the teacher
STAGE_SIX_APPROVED = True          # learning-loop.md, the stage 6 paragraph


def _helpers():
    spec = importlib.util.spec_from_file_location("r559_store_helpers", ROOT / "tests" / "test_r559_learning_loop.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


H = _helpers()


def read(rel):
    return (SKILL / rel).read_text(encoding="utf-8")


def section(text, heading):
    start = text.find("\n## " + heading)
    end = text.find("\n## ", start + 4)
    return text[start:end if end != -1 else len(text)] if start != -1 else ""


def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


DRAFT = "阿梅把一摞饭盒放在柜台上。\n\n“老板，麻烦您帮我热一下这几个饭盒。”阿梅说。\n\n周伯放下报纸：“好的，没问题，请你稍等一下。”"
WORKSHOPS = "阿梅把一摞饭盒放在柜台上。\n\n“周伯，热一下。”\n\n周伯放下报纸：“几个？”"
SECOND = "阿梅把一摞饭盒放在柜台上。\n\n“周伯。”\n\n周伯放下报纸：“几个？”"
MINE = "阿梅把一摞饭盒放在柜台上。\n\n“周伯，老规矩。”\n\n周伯没抬眼，把报纸折了一道：“又是七个？”"
BATCH1 = "教师意见（第一批）：第三段周伯那句像店员背话术。"
BATCH2 = "教师意见（晚到的一批）：第二段阿梅报来意太全，熟客不这样说。"
SAID = "合成对话#12：老师又回了一批；修订稿我自己也改了，这版通过。"
AT_SIX = [{"id": "A1", "issue": "作者没说理由", "evidence": "“周伯，热一下。”", "scope": "第2段", "replacement": "“周伯，老规矩。”"},
          {"id": "A2", "issue": "他不放下报纸。", "evidence": "周伯放下报纸：“几个？”", "scope": "第3段",
           "replacement": "周伯没抬眼，把报纸折了一道：“又是七个？”"}]


class TheLockedSectionIsR559s(unittest.TestCase):
    def test_lines_53_to_60(self):
        lines = read("references/chapter-confirmation.md").split("\n")
        self.assertEqual(lines[51], "## 确认是什么意思")
        self.assertTrue(lines[61].startswith("## "))
        self.assertEqual(sha("".join(lines[n - 1] + "\n" for n in range(53, 61))), LOCKED_R559)


class TheLateBatchOnThePages(unittest.TestCase):
    R559 = ("- **方案交出以后又来了一批。** 审稿方案已经交给作者、作者又带回教师的第二批意见的，先带作者原话 `reopen` 审稿这一阶段，"
            "再登记这一份回传，出一份把两批合在一起的方案重新展示。展示时 `teacher_return_id` 只能填一个，填后到的那一份，"
            "先到的那一份的编号写进方案里。")

    def bullet(self):
        after = section(read("references/chapter-confirmation.md"), "完整初稿以后（第 4 至 6 阶段，`teacher_handoff: \"user_return\"`）")
        return next(line for line in after.splitlines() if line.startswith("- **方案交出以后又来了一批。**"))

    def test_the_bullet_keeps_r559s_words_and_adds_the_late_batch(self):
        bullet = self.bullet()
        self.assertTrue(bullet.startswith(self.R559))
        added = bullet[len(self.R559):]
        for phrase in ("方案已经确认、第 6 阶段还没确认的时候才带回的，也照这样办（r5.60）",
                       "登记以前照旧先问清教师看的是哪一版（上面第 3、4 条）；修订稿已经交出、还在等确认的，那一次展示随重开作废。",
                       "作者把这一批和自己改过的修订稿一起带回的，照“确认是什么意思”里“一起带回”那一句，也是先这样重开、登记，作者的稿子不登记成教师回传",
                       "重开、登记以后第 5 阶段还没确认，是那一条例外的头一种时候，不是第二种",
                       "把两批合在一起的方案连同“作者改了哪几处”的对照重新展示第 5 阶段，等作者确认，再在第 6 阶段交作者的稿子和复查",
                       "没说通过的，先问一句。",
                       "这时候“作者改了哪几处”拿作者的稿子和工坊交出的那一版修订稿比，学习记录里作者那条评审也绑那一版修订稿",
                       "[学习循环](learning-loop.md)“在章节流程里怎么起一轮”"):
            self.assertIn(phrase, added)
        for word in ABSOLUTES:
            self.assertNotIn(word, added)

    def test_the_round_says_how_it_is_recorded(self):
        start = section(read("references/learning-loop.md"), "在章节流程里怎么起一轮")
        late = next(line for line in start.splitlines() if line.startswith("  修订稿在等确认的时候，作者把晚到的一批教师意见和自己改过的修订稿一起带回"))
        for phrase in ("“完整初稿以后”里“方案交出以后又来了一批”先重开审稿阶段、登记这一批",
                       "下面几步等这一次确认以后再记，取舍和改稿脚本也要等它确认了才收",
                       "绑这一轮当前的稿子，也就是工坊交出的那一版修订稿：脚本只收绑当前这一稿的评审",
                       "`teacher_return_id` 这时候带不上，带了会被拒，回传的编号和“教师看的是初稿”写进 `source_ref`",
                       "作者那条评审绑工坊交出的那一版修订稿，“作者改了哪几处”也拿这一版比",
                       "作者的通过在 `rechecks` 里把两批教师意见和作者那条评审都列上，凭它 `finish`，`completion` 记 `author_reviewed`",
                       "这样登记的案例，改前仍是初稿，改后是作者的稿子。",
                       "这一段在合成材料上走过一遍章节门和学习循环（r5.60），没有在真实章节上走过。"):
            self.assertIn(phrase, late)
        for word in ABSOLUTES:
            self.assertNotIn(word, late)
        # the paragraph sits inside the bullet on the author's own text, before the next bullet of the section
        lines = start.splitlines()
        self.assertLess(lines.index(late), next(i for i, l in enumerate(lines) if l.startswith("- **不走章节流程的改稿任务**")))


class TheLateBatchWalkedThrough(unittest.TestCase):
    """The chapter gate and the learning loop on synthetic text; no script is changed for it."""

    def to_stage_six(self, tmp):
        path = H.new_store(Path(tmp) / "学习记录.md")
        rec = H.Recorder(path, H.load_loop(ROOT))
        rec.gate("chapter_policy", "ch01", author_quote="这一章不看图。", source_ref="合成对话#policy", visual_required=False, **AUTHOR)
        for stage, words in (("scope", "好"), ("outline", "继续"), ("preparation", "写吧")):
            rec.stage("ch01", stage, words)
        draft = rec.stage("ch01", "draft", "可以交老师", artifact=sha(DRAFT))["last_valid_confirmation"]
        first = self.register(rec, draft, BATCH1, "合成对话#回传1")
        rec.op("start", "R", task="chapter_revision", tags=["对白"], group_id="ch01", input_text=DRAFT, source_ref="ch01 已确认初稿",
               constraints=[], chapter_id="ch01")
        rec.op("plan", "R", applications=[], checks=["合成"])
        rec.op("draft", "R", text=DRAFT, source_ref="ch01 初稿", actor={"name": "工坊写作者", "context_id": "w1"})
        rec.op("review", "R", review_id="teacher-1", draft_sha256=sha(DRAFT), reviewer=rec.reviewer("teacher", "author_return", "t"),
               verdict="revise", findings=[{"id": "T1", "issue": "像店员背话术", "evidence": "请你稍等一下", "scope": "第3段"}],
               source_ref="合成对话#回传1", teacher_return_id=first["teacher_return_id"])
        self.plan(rec, first, "照这个方案改", "合成对话#5")
        rec.op("decide", "R", review_id="teacher-1", decisions=[{"finding_id": "T1", "decision": "adopt", "reason": "作者确认了方案"}])
        rec.op("revise", "R", parent_sha256=sha(DRAFT), review_id="teacher-1", text=WORKSHOPS, source_ref="工坊修订稿",
               actor={"name": "工坊写作者", "context_id": "w1", "role": "writer"})
        rec.gate("present", "ch01", "revision", content="工坊的修订稿和复查", source_ref="合成工作记录#revision",
                 artifact_sha256=sha(WORKSHOPS))
        return path, rec, draft

    def register(self, rec, draft, text, source, refused=False):
        send = rec.refused_gate if refused else rec.gate
        return send("teacher_return", "ch01", draft_presentation_id=draft["presentation_id"],
                    draft_presentation_version=draft["presentation_version"], draft_sha256=sha(DRAFT), returned_text=text,
                    source_ref=source, teacher_name="未知")

    def plan(self, rec, returned, quote, source):
        shown = rec.gate("present", "ch01", "review", content="教师意见的定位和方案", source_ref="合成工作记录#review",
                         teacher_return_id=returned["teacher_return_id"])
        return rec.gate("confirm", "ch01", "review", presentation_id=shown["presentation_id"],
                        presentation_version=shown["presentation_version"], author_quote=quote, source_ref=source, **AUTHOR)

    def reopen_and_register(self, rec, draft):
        # the gate does not take a teacher return while the revision is waiting; the review stage is reopened first
        self.assertEqual(self.register(rec, draft, BATCH2, "合成对话#12", refused=True).code, "invalid_transition")
        rec.gate("reopen", "ch01", "review", reason="修订稿等确认时作者又带回一批教师意见", author_quote=SAID,
                 source_ref="合成对话#12", **AUTHOR)
        return self.register(rec, draft, BATCH2, "合成对话#12")

    def late_review(self, rec, returned, **more):
        return dict(review_id="teacher-2", draft_sha256=sha(WORKSHOPS), reviewer=rec.reviewer("teacher", "author_return", "t"),
                    verdict="revise", findings=[{"id": "T2", "issue": "报来意太全", "evidence": "“周伯，热一下。”", "scope": "第2段"}],
                    source_ref="合成对话#12；章节门回传 " + returned["teacher_return_id"] + "（教师看的是初稿）", **more)

    def test_the_late_batch_with_the_authors_revision(self):
        with tempfile.TemporaryDirectory() as tmp:
            path, rec, draft = self.to_stage_six(tmp)
            second = self.reopen_and_register(rec, draft)
            # the round takes reviews of its current text only, and a return bound to the draft cannot be named on it
            fields = self.late_review(rec, second)
            self.assertIn("Review must bind the current draft", str(rec.refused("review", "R", **{**fields, "draft_sha256": sha(DRAFT)})))
            self.assertIn("teacher_return_id must name a teacher return", str(rec.refused(
                "review", "R", **self.late_review(rec, second, teacher_return_id=second["teacher_return_id"]))))
            self.plan(rec, second, "好，就这样", "合成对话#13")  # two batches and what the author changed, confirmed again
            rec.op("review", "R", **fields)
            rec.op("review", "R", review_id="author-own", draft_sha256=sha(WORKSHOPS), reviewer=rec.reviewer("author", "human", "a"),
                   verdict="revise", findings=AT_SIX, source_ref=SAID)
            rec.op("decide", "R", review_id="teacher-2",
                   decisions=[{"finding_id": "T2", "decision": "adopt", "reason": "作者的稿子已经照这个方向改了"}])
            rec.op("decide", "R", review_id="author-own",
                   decisions=[{"finding_id": c["id"], "decision": "adopt", "reason": "作者亲改"} for c in AT_SIX])
            rec.op("revise", "R", parent_sha256=sha(WORKSHOPS), review_id="author-own", text=MINE, source_ref="作者交回的修订稿",
                   actor={"name": "作者", "context_id": "a", "role": "author"})
            # the author's pass lists both teacher batches and his own review, or the round cannot finish
            rec.op("review", "R", review_id="author-pass-short", draft_sha256=sha(MINE), reviewer=rec.reviewer("author", "human", "a"),
                   verdict="pass", findings=[], rechecks=["author-own"], source_ref=SAID)
            self.assertIn("needs a passing review and all required rechecks", str(rec.refused("finish", "R", draft_sha256=sha(MINE))))
            rec.op("review", "R", review_id="author-pass", draft_sha256=sha(MINE), reviewer=rec.reviewer("author", "human", "a"),
                   verdict="pass", findings=[], rechecks=["author-own", "teacher-2", "teacher-1"], source_ref=SAID)
            rec.stage("ch01", "revision", "好", artifact=sha(MINE))
            rec.op("finish", "R", draft_sha256=sha(MINE))
            rec.stage("ch01", "final", "定稿。", artifact=sha(MINE), final=True)
            rec.op("author_accept", "R", draft_sha256=sha(MINE), quote="定稿。", source_ref="合成对话#15", **AUTHOR)
            rec.op("learn", "R", case_id="case-late", why="熟客之间不报来意。", when=["熟客来办常办的事"], decisions=["照作者亲改稿"],
                   **{"except": ["对方是头一回来的生客"]})
            data = H.payload_of(path)["data"]
            run, case, chapter = data["learning_runs"]["R"], data["demonstrations"]["case-late"], data["chapter_confirmations"]["ch01"]
            self.assertEqual((run["completion"], case["status"], case["source"]["after_by"], case["before"], case["after"]),
                             ("author_reviewed", "author_accepted", "author", DRAFT, MINE))
            self.assertEqual([item["stage"] for item in chapter["history"] if item["action"] == "reopen"], ["review"])
            self.assertEqual([(i["status"], i["artifact_sha256"]) for i in chapter["history"]
                              if i["action"] == "present" and i["stage"] == "revision"],
                             [("invalidated", sha(WORKSHOPS)), ("confirmed", sha(MINE))])
            self.assertEqual([r["returned_text"] for r in chapter["teacher_returns"]], [BATCH1, BATCH2])
            self.assertNotIn(MINE, [r["returned_text"] for r in chapter["teacher_returns"]])

    def test_the_decision_waits_for_the_plan_to_be_confirmed_again(self):
        with tempfile.TemporaryDirectory() as tmp:
            path, rec, draft = self.to_stage_six(tmp)
            second = self.reopen_and_register(rec, draft)
            rec.op("review", "R", **self.late_review(rec, second))
            self.assertEqual(rec.refused("decide", "R", review_id="teacher-2", decisions=[
                {"finding_id": "T2", "decision": "adopt", "reason": "合成"}]).code, "chapter_gate_first")

    def test_only_the_late_batch_comes_back(self):
        # no text of the author's: the same reopening, then the workshop revises again on the merged plan
        with tempfile.TemporaryDirectory() as tmp:
            path, rec, draft = self.to_stage_six(tmp)
            second = self.reopen_and_register(rec, draft)
            self.plan(rec, second, "好，两批一起改", "合成对话#13")
            rec.op("review", "R", **self.late_review(rec, second))
            rec.op("decide", "R", review_id="teacher-2", decisions=[{"finding_id": "T2", "decision": "adopt", "reason": "作者确认了方案"}])
            rec.op("revise", "R", parent_sha256=sha(WORKSHOPS), review_id="teacher-2", text=SECOND, source_ref="工坊第二版修订稿",
                   actor={"name": "工坊写作者", "context_id": "w1", "role": "writer"})
            shown = rec.gate("present", "ch01", "revision", content="第二版修订稿和复查", source_ref="合成", artifact_sha256=sha(SECOND))
            self.assertEqual((shown["current_stage"], shown["chapter_status"]), ("revision", "awaiting_confirmation"))

    def test_what_the_page_rules_out_the_gate_takes(self):
        # only presenting stage 6 again: the gate takes it and the late batch is never registered; the page stops it
        with tempfile.TemporaryDirectory() as tmp:
            path, rec, draft = self.to_stage_six(tmp)
            rec.gate("present", "ch01", "revision", content="作者的稿子和复查", source_ref="合成", artifact_sha256=sha(MINE))
            self.assertEqual(self.register(rec, draft, BATCH2, "合成对话#12", refused=True).code, "invalid_transition")
            self.assertEqual(len(H.payload_of(path)["data"]["chapter_confirmations"]["ch01"]["teacher_returns"]), 1)


class ThePassSaidWithAChangedText(unittest.TestCase):
    def test_the_confirm_notes_say_it(self):
        records = section(read("references/chapter-confirmation.md"), "记录怎么写")
        lines = records.splitlines()
        if not PASS_NOTE_APPROVED:
            self.assertFalse([line for line in lines if "随改稿说的“通过”" in line and line.startswith("- 作者交回")])
            return
        note = next(line for line in lines if line.startswith("- 作者交回自己改过的稿子时随改稿说的“通过”"))
        for phrase in ("说的是他交回的那一版，不算对原来那一版的确认，不拿它给原来那一次展示记 `confirm`（r5.60）",
                       "初稿还在等确认、作者只交回改稿的，照“确认是什么意思”从第 4 阶段重开，把作者的稿子当新的一版初稿重新展示，等作者对这一次展示另回话",
                       "记初稿的确认凭的是把结果带回来这件事（“完整初稿以后”末段），也不是这句“通过”",
                       "脚本照收，工坊自己审的章接着会被错当成例外办，这一处靠条文拦"):
            self.assertIn(phrase, note)
        for word in ABSOLUTES:
            self.assertNotIn(word, note)
        # among the notes on confirm, right after the one on source_ref
        self.assertEqual(lines.index(note), next(i for i, l in enumerate(lines) if l.startswith("- `source_ref` 写到具体哪一条消息")) + 1)

    def test_the_gate_takes_the_wrong_record_so_the_page_has_to_say_it(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = H.new_store(Path(tmp) / "学习记录.md")
            rec = H.Recorder(path, H.load_loop(ROOT))
            rec.gate("chapter_policy", "ch01", author_quote="这一章不看图，也不交老师。", source_ref="合成对话#policy",
                     visual_required=False, teacher_handoff="host", **AUTHOR)
            for stage, words in (("scope", "好"), ("outline", "继续"), ("preparation", "写吧")):
                rec.stage("ch01", stage, words)
            shown = rec.gate("present", "ch01", "draft", content="初稿", source_ref="合成", artifact_sha256=sha(DRAFT))
            # what the page says: reopen stage 4 with the author's words; his text is the new draft, confirmed anew
            rec.gate("reopen", "ch01", "draft", reason="作者交回自己改过的稿子，当新的一版初稿", author_quote="这版我自己改好了，通过。",
                     source_ref="合成对话#作者交回改稿", **AUTHOR)
            again = rec.gate("present", "ch01", "draft", content="作者交回的那一版，改了两处", source_ref="合成", artifact_sha256=sha(MINE))
            self.assertEqual((again["current_stage"], again["chapter_status"]), ("draft", "awaiting_confirmation"))
            history = H.payload_of(path)["data"]["chapter_confirmations"]["ch01"]["history"]
            old = next(item for item in history if item.get("presentation_id") == shown["presentation_id"])
            self.assertEqual(old["status"], "invalidated")
        with tempfile.TemporaryDirectory() as tmp:
            # the wrong record: the same words confirm the OLD draft; the gate takes it and stage 5 after it
            path = H.new_store(Path(tmp) / "学习记录.md")
            rec = H.Recorder(path, H.load_loop(ROOT))
            rec.gate("chapter_policy", "ch01", author_quote="这一章不看图，也不交老师。", source_ref="合成对话#policy",
                     visual_required=False, teacher_handoff="host", **AUTHOR)
            for stage, words in (("scope", "好"), ("outline", "继续"), ("preparation", "写吧")):
                rec.stage("ch01", stage, words)
            shown = rec.gate("present", "ch01", "draft", content="初稿", source_ref="合成", artifact_sha256=sha(DRAFT))
            rec.gate("confirm", "ch01", "draft", presentation_id=shown["presentation_id"],
                     presentation_version=shown["presentation_version"], author_quote="这版我自己改好了，通过。",
                     source_ref="合成对话#作者交回改稿", **AUTHOR)
            taken = rec.gate("present", "ch01", "review", content="作者改了两处", source_ref="合成")
            self.assertEqual((taken["current_stage"], taken["last_valid_confirmation"]["artifact_sha256"]), ("review", sha(DRAFT)))


class WhatTheGateCannotTell(unittest.TestCase):
    def test_the_page_says_it(self):
        records = section(read("references/chapter-confirmation.md"), "记录怎么写")
        limits = next(line for line in records.splitlines() if line.startswith("**脚本核得了什么，核不了什么。**"))
        if not GATE_NOTE_APPROVED:
            self.assertIn("脚本目前不拿确认记录去对照事件台账。所以写入只走 `learning_loop.py apply`", limits)
            self.assertNotIn("登记的回传是不是教师的东西", limits)
            return
        for phrase in ("登记的回传是不是教师的东西，脚本也分不出：把作者自己的稿子登记成 `teacher_return`，它照收，接着带这份回传展示审稿阶段也收",
                       "`reopen` 只要是已经到过的阶段都收",
                       "条文不让走的路脚本大多也收，要靠照条文做、照实记（r5.60 补记，只在合成材料上试过）"):
            self.assertIn(phrase, limits)
        # the new sentence comes after "所以写入只走……", so "所以" still follows the sentences it draws on
        self.assertIn("脚本目前不拿确认记录去对照事件台账。所以写入只走 `learning_loop.py apply`，不手改，也不由手工整库覆盖。"
                      "登记的回传是不是教师的东西", limits)
        self.assertIn("（r5.60 补记，只在合成材料上试过）。没有真实确认就保留等待", limits)

    def test_the_authors_own_text_registered_as_a_teacher_return_is_taken(self):
        # pinned so that the sentence above is changed together with the script if a later version stops this
        with tempfile.TemporaryDirectory() as tmp:
            path = H.new_store(Path(tmp) / "学习记录.md")
            rec = H.Recorder(path, H.load_loop(ROOT))
            rec.gate("chapter_policy", "ch01", author_quote="这一章不看图。", source_ref="合成对话#policy", visual_required=False, **AUTHOR)
            for stage, words in (("scope", "好"), ("outline", "继续"), ("preparation", "写吧")):
                rec.stage("ch01", stage, words)
            draft = rec.stage("ch01", "draft", "可以交老师", artifact=sha(DRAFT))["last_valid_confirmation"]
            # with no return at all the gate refuses stage 5
            self.assertEqual(rec.refused_gate("present", "ch01", "review", content="作者改了两处", source_ref="合成").code,
                             "invalid_transition")
            wrong = rec.gate("teacher_return", "ch01", draft_presentation_id=draft["presentation_id"],
                             draft_presentation_version=draft["presentation_version"], draft_sha256=sha(DRAFT),
                             returned_text=MINE, source_ref="合成对话#作者交回改稿", teacher_name="未知")
            taken = rec.gate("present", "ch01", "review", content="作者改了两处", source_ref="合成",
                             teacher_return_id=wrong["teacher_return_id"])
            self.assertEqual((taken["current_stage"], taken["chapter_status"]), ("review", "awaiting_confirmation"))


class TheRestatementsCarryTheConditions(unittest.TestCase):
    def setUp(self):
        self.start = section(read("references/learning-loop.md"), "在章节流程里怎么起一轮")

    def test_the_opening_sentence(self):
        line = next(l for l in self.start.splitlines() if l.startswith("- **作者在审稿阶段交回自己改过的稿子（r5.59）。**"))
        if not OPENING_APPROVED:
            self.assertIn("作者在第 5 阶段交回自己改过的整份稿子、并且说了通过的，初稿不重开（[每章七阶段与作者确认](chapter-confirmation.md)"
                          "“确认是什么意思”里的例外），这一轮照下面记：", line)
            return
        self.assertIn("第 4 阶段已经确认、第 5 阶段还没确认的时候（初稿由作者交教师的章节，还要已经登记了教师回传），作者交回自己改过的整份稿子、并且说了通过的，"
                      "初稿不重开（[每章七阶段与作者确认](chapter-confirmation.md)“确认是什么意思”里例外的头一种时候；算不算例外以那一条为准），这一轮照下面记：", line)
        # r5.59 wrote "作者在第 5 阶段交回……初稿不重开" without the conditions of the locked line
        self.assertNotIn("作者在第 5 阶段交回自己改过的整份稿子", line)

    def test_the_teacher_chapter_paragraph(self):
        para = next(l for l in self.start.splitlines() if l.startswith("  初稿由作者交教师的章节，第 1、2 步要等"))
        if not TEACHER_PARAGRAPH_APPROVED:
            self.assertIn("这一章还没登记教师回传、作者只带回自己的稿子的，不算例外，这一轮不起，章节门也不收第 5 阶段的展示：", para)
            self.assertNotIn("工坊自己审的章节没有教师回传要登记", para)
            return
        for phrase in ("这样的章节，教师回传还没登记、作者只带回自己的稿子的，不算例外，这一轮不起；没有登记回传，章节门不收第 5 阶段的展示，"
                       "作者的稿子也不登记成教师回传（登记了脚本分不出，照收，靠条文拦）：照“确认是什么意思”从第 4 阶段重开，"
                       "作者的稿子当新的一版初稿交作者确认，作者要交教师的，交的就是这一版。",
                       # the r5.59 sentence on teacher results, then the new one, then r5.59's last sentence
                       "作者同时带回了教师结果的，教师结果照上文另记一条 `role` 为 `teacher` 的评审，作者的稿子不登记成教师回传。"
                       "工坊自己审的章节没有教师回传要登记，不归上面那一句管，照“确认是什么意思”例外的两种时候办（r5.60）。"
                       "这一段在合成材料上实际走过一遍章节门和学习循环（r5.59），没有在真实章节上走过。"):
            self.assertIn(phrase, para)
        # r5.59 said the gate "也不收第 5 阶段的展示"; that holds only while no return is registered
        self.assertNotIn("章节门也不收第 5 阶段的展示", self.start)
        self.assertNotIn("这一章还没登记教师回传、作者只带回自己的稿子的", self.start)

    def test_stage_six_is_still_confirmed(self):
        para = next(l for l in self.start.splitlines() if l.startswith("  作者在第 6 阶段交回自己改过的修订稿"))
        if not STAGE_SIX_APPROVED:
            self.assertIn("章节门重新展示第 6 阶段，绑作者的稿子，旧的展示记成被取代（`superseded`），前面的阶段不重开。"
                          "这一段也只在合成材料上走过（r5.59）。", para)
            return
        self.assertIn("章节门重新展示第 6 阶段，绑作者的稿子，旧的展示记成被取代（`superseded`），前面的阶段不重开。"
                      "重新展示以后照旧停下等作者对这一次展示确认，随改稿说的“通过”不记成第 6 阶段的确认（r5.60）。"
                      "这一段也只在合成材料上走过（r5.59）。", para)


if __name__ == "__main__":
    unittest.main()

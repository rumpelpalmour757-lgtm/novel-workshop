"""Visual materials for a chapter: two searches, page images, near-duplicate groups, similarity ranking, a review bundle
for looking at the images, the author's choice and a guarded write into the book's inspiration library (r5.35).

The five upstream projects are called through adapters and are installed separately (see
references/visual-materials.md): SearXNG (an instance you run or are allowed to use), Openverse (its public API),
Crawl4AI, ImageHash and OpenCLIP. Nothing here downloads model weights or starts services on its own, and nothing here
claims a component works without a run that shows it.
"""

VERSION = "visual-materials/1"
COMPONENTS = ("searxng", "openverse", "crawl4ai", "imagehash", "openclip")

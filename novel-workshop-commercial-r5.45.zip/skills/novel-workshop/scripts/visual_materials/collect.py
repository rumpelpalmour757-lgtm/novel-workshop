"""Step 2a: read the source pages that matter with Crawl4AI, then fetch and decode the images.

Crawl4AI renders each page in a headless browser and lists its images (src, alt, desc, score, width). Only the pages
of this run's candidates (and pages the request names) are read, at most budgets.max_pages, robots.txt respected by
default. Images are fetched up to budgets.max_images, at most network.max_image_bytes each, and kept only if Pillow
can decode them: an HTML page, a broken file or something that is not an image is recorded as such, never as an
image. When the original cannot be fetched, the thumbnail is tried and the record says it is only the thumbnail.

r5.37 (the r5.35 review, point 3): Crawl4AI being importable, its browser starting and a page being read are three
different things, and the record says which happened. When the browser does not start (or the page reader stops), the
pages are recorded as browser_failed or error and the images the searches found are still fetched (partial); nothing
claims a page was read. A host in network.blocked_hosts is neither opened as a page nor fetched as an image. Fetching
again replaces each candidate's image: an image not fetched this time is kept only as stale_image (with why), so later
steps never take an old file for this fetch, and the files the later steps made from the old fetch move to outdated/.

r5.38 (the r5.37 review, point 3): the page's own words are this read's too. A candidate's on_page comes only from a
page read now (collect.json has when); when its page was not read this time, what an earlier read said is kept as stale_on_page
(with since when and why), shown in the review as earlier page text and never taken into the library as page text.
When a page read now also shows a candidate's image and is not yet among its sightings, the page is added to found_by
(as a crawl4ai sighting of its own, without taking the candidate's licence or author).
"""
import asyncio
import io
import sys
import urllib.parse

from . import common

IMAGE_TYPES = {"JPEG": "jpg", "PNG": "png", "WEBP": "webp", "GIF": "gif", "BMP": "bmp", "TIFF": "tif"}


def crawl4ai_status():
    if sys.version_info < (3, 10):
        return False, "Crawl4AI needs Python 3.10 or newer (this is %d.%d)" % sys.version_info[:2], None
    try:
        import crawl4ai  # noqa: F401
    except Exception as exc:  # noqa: BLE001 - any import failure means it cannot run here
        return False, "Crawl4AI is not installed (pip install crawl4ai, then crawl4ai-setup): %s" % exc, None
    return True, "crawl4ai %s" % getattr(crawl4ai, "__version__", "?"), getattr(crawl4ai, "__version__", "?")


BLOCKED = "the host is blocked in the config (network.blocked_hosts)"


def crawl_pages(pages, config):
    """Each page with Crawl4AI: [{page_url, status, http_status, error, images: [...]}]. A blocked host is not opened
    (status blocked). When the browser does not start, every page is browser_failed; when the reader stops later, the
    pages not reached are not_read; when the browser fails to close after reading, the pages read are kept and say so."""
    ok, why, version = crawl4ai_status()
    if not ok:
        return [{"page_url": p, "status": "not_installed", "error": why, "images": []} for p in pages], None
    from crawl4ai import AsyncWebCrawler, BrowserConfig, CacheMode, CrawlerRunConfig

    options = config["crawl4ai"]
    allowed = [p for p in pages if not common.blocked(p, config)]

    async def main():
        out = []
        browser = BrowserConfig(headless=bool(options.get("headless", True)), verbose=False)
        run = CrawlerRunConfig(cache_mode=CacheMode.BYPASS, wait_for_images=bool(options.get("wait_for_images", True)),
                               scan_full_page=bool(options.get("scan_full_page", True)),
                               page_timeout=int(options.get("page_timeout_ms", 30000)),
                               check_robots_txt=bool(options.get("check_robots_txt", True)),
                               exclude_external_images=False, verbose=False)
        started = False
        try:
            async with AsyncWebCrawler(config=browser) as crawler:
                started = True
                for page in allowed:
                    record = {"page_url": page, "time": common.now(), "images": []}
                    try:
                        result = await crawler.arun(url=page, config=run)
                    except Exception as exc:  # noqa: BLE001 - one page failing is that page's record
                        record.update(status="error", error="%s: %s" % (type(exc).__name__, exc))
                        out.append(record)
                        continue
                    record["http_status"] = getattr(result, "status_code", None)
                    if not getattr(result, "success", False):
                        record.update(status="failed", error=getattr(result, "error_message", "") or "not successful")
                        out.append(record)
                        continue
                    media = getattr(result, "media", None) or {}
                    for item in media.get("images", []) or []:
                        item = item if isinstance(item, dict) else getattr(item, "__dict__", {})
                        src = (item.get("src") or "").strip()
                        if not src or src.startswith("data:"):
                            continue
                        record["images"].append({"src": urllib.parse.urljoin(page, src), "alt": item.get("alt") or "",
                                                 "desc": item.get("desc") or "", "score": item.get("score"),
                                                 "width": item.get("width")})
                    record["status"] = "ok" if record["images"] else "no_images"
                    out.append(record)
        except Exception as exc:  # noqa: BLE001 - the browser not starting or closing is recorded, not raised
            note = "%s: %s" % (type(exc).__name__, exc)
            done = {r["page_url"] for r in out}
            if not started:
                status, error = "browser_failed", "the browser did not start: " + note
            else:
                status, error = "not_read", "the page reader stopped: " + note
                for record in out:
                    record["browser"] = "stopped with an error after this page: " + note
            out += [{"page_url": p, "status": status, "error": error, "images": []} for p in allowed if p not in done]
        return out

    records = {r["page_url"]: r for r in (asyncio.run(main()) if allowed else [])}
    for page in pages:
        if page not in records:
            records[page] = {"page_url": page, "status": "blocked", "error": BLOCKED, "images": []}
    return [records[p] for p in pages], version


def decode(data):
    """(format, width, height) when Pillow can read the bytes as an image; raises ValueError otherwise."""
    try:
        from PIL import Image
    except ImportError as exc:
        raise RuntimeError("Pillow is not installed (pip install Pillow)") from exc
    try:
        with Image.open(io.BytesIO(data)) as probe:
            probe.verify()
        with Image.open(io.BytesIO(data)) as image:
            image.load()
            return image.format or "", image.size[0], image.size[1]
    except Exception as exc:  # noqa: BLE001 - Pillow raises many kinds for a broken file
        raise ValueError("%s: %s" % (type(exc).__name__, exc)) from exc


def fetch_image(url, config, fetch):
    """{status, sha256, format, width, height, bytes, data} for one address."""
    if common.blocked(url, config):
        return {"status": "blocked", "error": BLOCKED}
    try:
        response = fetch(url, config, headers={"Accept": "image/*"}, max_bytes=config["network"]["max_image_bytes"])
    except common.Timeout as exc:
        return {"status": "timeout", "error": str(exc)}
    except common.TooLarge as exc:
        return {"status": "too_large", "error": str(exc)}
    except common.NetworkError as exc:
        return {"status": "error", "error": str(exc)}
    if response.status != 200:
        return {"status": "http_error", "http_status": response.status}
    kind = (response.headers.get("Content-Type") or response.headers.get("content-type") or "").lower()
    if kind.startswith(("text/", "application/json")):
        return {"status": "not_image", "error": "the address answered %s" % kind.split(";")[0]}
    try:
        fmt, width, height = decode(response.body)
    except ValueError as exc:
        return {"status": "undecodable", "error": str(exc), "bytes": len(response.body)}
    return {"status": "ok", "sha256": common.sha256_bytes(response.body), "format": fmt, "width": width,
            "height": height, "bytes": len(response.body), "data": response.body}


def run_collect(folder, config, fetch=None, crawl=None):
    transport = {"fetch": "injected" if fetch else "http", "crawl": "injected" if crawl else "crawl4ai"}
    fetch = fetch or common.http
    run = common.Run(folder)
    manifest = run.manifest()
    candidates = run.candidates()
    budgets = config["budgets"]
    pages = []
    for page in manifest["request"].get("pages", []) + [c["page_url"] for c in candidates]:
        if page not in pages:
            pages.append(page)
    pages = pages[:budgets["max_pages"]]
    to_read = [p for p in pages if not common.blocked(p, config)]
    importable = crawl4ai_status()[0] if crawl is None else None
    try:
        crawled, version = (crawl or crawl_pages)(to_read, config) if to_read else ([], None)
    except Exception as exc:  # noqa: BLE001 - the page reader failing is a failure of the pages, not of the run
        reason = "%s: %s" % (type(exc).__name__, exc)
        crawled, version = [{"page_url": p, "status": "error", "error": "the page reader stopped: " + reason,
                             "images": []} for p in to_read], None
    by_page = {r["page_url"]: r for r in crawled}
    crawled = [by_page.get(p) or {"page_url": p, "status": "blocked", "error": BLOCKED, "images": []}
               for p in pages if p in by_page or p not in to_read]
    by_url = {c["image_url"]: c for c in candidates}
    added = 0
    read_now, when = {}, common.now()
    for record in crawled:
        on_page = {i["src"]: i for i in record.get("images", [])}
        for c in candidates:
            hit = on_page.get(c["image_url"]) or on_page.get(c.get("thumbnail_url") or "")
            if not hit or record.get("status") != "ok":
                continue
            if c["page_url"] == record["page_url"]:
                read_now[c["cid"]] = {"alt": hit["alt"], "desc": hit["desc"], "score": hit["score"]}
            known = {f.get("page_url") or f.get("page") for f in c.get("found_by", [])} | {c["page_url"]}
            if record["page_url"] not in known:  # the same image on another page read now: that page is a source too
                c.setdefault("found_by", []).append({"provider": "crawl4ai", "page": record["page_url"],
                                                     "page_url": record["page_url"], "score": hit.get("score")})
        extra = sorted((i for i in record.get("images", []) if i["src"] not in by_url
                        and i["src"].startswith(("http://", "https://")) and not common.blocked(i["src"], config)
                        and not (isinstance(i.get("width"), int) and i["width"] < 200)),
                       key=lambda i: -(i.get("score") or 0))[:int(config["crawl4ai"].get("images_per_page", 3))]
        for image in extra:
            if len(candidates) >= budgets["max_candidates"]:
                break
            item = {"cid": "C%02d" % (len(candidates) + 1), "image_url": image["src"], "thumbnail_url": "",
                    "page_url": record["page_url"], "title": image["alt"], "page_text": image["desc"], "creator": "",
                    "license": "", "license_url": "", "width": image.get("width"), "height": None,
                    "found_by": [{"provider": "crawl4ai", "page": record["page_url"], "page_url": record["page_url"],
                                  "score": image.get("score")}]}
            candidates.append(item)
            by_url[item["image_url"]] = item
            added += 1
    statuses_by_page = {r["page_url"]: r.get("status") for r in crawled}
    for c in candidates:
        earlier = c.pop("on_page", None)
        if c["cid"] in read_now:
            c["on_page"] = read_now[c["cid"]]
            c.pop("stale_on_page", None)
        elif earlier:
            status = statuses_by_page.get(c["page_url"], "not read this time (max_pages)")
            c["stale_on_page"] = dict(earlier, stale_since=when, why=(
                "the page was read this time, but this image is not on it now" if status == "ok" else
                "this collect did not read the page (%s)" % status))
    images_dir = run.path("images")
    fetched, kept, stale = [], 0, []
    for c in candidates:
        # This fetch decides the candidate's image: what an earlier fetch got is kept aside, never as this one's.
        old = c.pop("image", None)
        if old:
            old.pop("gid", None)
        if kept >= budgets["max_images"]:
            fetched.append({"cid": c["cid"], "status": "skipped_budget"})
            if old:
                c["stale_image"] = dict(old, stale_since=common.now(), why="not fetched again (skipped_budget)")
                stale.append(c["cid"])
            continue
        result = fetch_image(c["image_url"], config, fetch)
        what = "original"
        if result["status"] != "ok" and c.get("thumbnail_url"):
            first = {k: v for k, v in result.items() if k != "data"}
            result = fetch_image(c["thumbnail_url"], config, fetch)
            what = "thumbnail"
            result["original_attempt"] = first
        record = {"cid": c["cid"], "what": what, "url": c["image_url"] if what == "original" else c["thumbnail_url"]}
        record.update({k: v for k, v in result.items() if k != "data"})
        if result["status"] == "ok":
            images_dir.mkdir(exist_ok=True)
            name = "%s.%s" % (result["sha256"], IMAGE_TYPES.get(result["format"], "img"))
            (images_dir / name).write_bytes(result["data"])
            record["file"] = "images/" + name
            c["image"] = {"sha256": result["sha256"], "width": result["width"], "height": result["height"],
                          "format": result["format"], "bytes": result["bytes"], "what": what, "file": record["file"]}
            c.pop("stale_image", None)
            kept += 1
        elif old:
            c["stale_image"] = dict(old, stale_since=common.now(), why="this fetch failed (%s)" % result["status"])
            stale.append(c["cid"])
        fetched.append(record)
    page_ok = sum(1 for r in crawled if r.get("status") == "ok")
    statuses = {r.get("status") for r in crawled}
    browser = (False if "browser_failed" in statuses else
               True if statuses & {"ok", "no_images", "failed"} and transport["crawl"] == "crawl4ai" else None)
    status = "ok" if kept and page_ok else ("partial" if kept or page_ok else "failed")
    advice = []
    if "browser_failed" in statuses:
        advice.append("the browser did not start: install it (crawl4ai-setup), then run collect again; the images the "
                      "searches found were fetched")
    if "not_installed" in statuses:
        advice.append("Crawl4AI is not installed: no page was read; the images the searches found were fetched")
    if "blocked" in statuses:
        advice.append("pages on blocked hosts were not opened (network.blocked_hosts)")
    if stale:
        advice.append("%d candidate(s) kept only an earlier fetch's image (stale_image): fetch again to use them" %
                      len(stale))
    outdated = run.outdate("collect")
    run.save_candidates(candidates)
    run.save("collect.json", {"schema": "visual-collect/1", "crawl4ai_version": version, "pages": crawled,
                              "crawl4ai": {"importable": importable, "browser_started": browser, "pages_ok": page_ok},
                              "fetched": fetched, "added_from_pages": added, "decoded": kept, "stale": stale,
                              "status": status, "transport": transport, "next": advice, "outdated": outdated})
    run.step("collect", {"status": status, "pages_ok": page_ok, "pages": len(crawled), "decoded": kept,
                         "added_from_pages": added, "stale": len(stale)})
    return {"status": status, "pages": len(crawled), "pages_ok": page_ok, "decoded": kept, "added_from_pages": added,
            "browser_started": browser, "stale": len(stale), "next": advice, "outdated": outdated}

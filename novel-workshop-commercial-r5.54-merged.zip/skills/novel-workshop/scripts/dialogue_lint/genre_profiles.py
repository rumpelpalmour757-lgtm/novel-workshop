"""Explicit genre presets: configurable reading hints, not language standards."""
from dataclasses import dataclass, field, replace
from collections.abc import Mapping
import math
import re
from types import MappingProxyType
from typing import FrozenSet, Pattern

KNOWN_RULE_IDS = frozenset({
    'SYN_01_DEGREE_ACT_VERB', 'SYN_02_BA_GEI_FORMAL_VERB', 'SYN_03_SLANG_FORMAL_PREDICATE',
    'COMP_01_BARE_MONOSYLLABIC_VERB', 'COMP_02_IMPERATIVE_TRIPLE_CHOP',
    'COMP_03_SUBJECTLESS_STATUS_PAIR', 'COMP_04_COORDINATE_REPLY',
    'TRANS_01_ROBOTIC_CONCESSION', 'TRANS_02_BODY_POSSESSIVE_REDUNDANCY',
    'TRANS_03_ENGLISH_IMPERATIVE_CALQUE', 'TRANS_04_EXPLICIT_MENTAL_VERB',
    'TRANS_05_FORMAL_CONNECTIVES_IN_SPEECH', 'TRANS_06_SHI_DE_JUDGMENT_ABUSE',
})
# Only these style hints may be waived by an author-confirmed scene record.
SCENE_STYLE_RULE_IDS = frozenset({
    'SYN_02_BA_GEI_FORMAL_VERB', 'SYN_03_SLANG_FORMAL_PREDICATE',
    'COMP_02_IMPERATIVE_TRIPLE_CHOP', 'COMP_03_SUBJECTLESS_STATUS_PAIR',
    'COMP_04_COORDINATE_REPLY', 'TRANS_05_FORMAL_CONNECTIVES_IN_SPEECH',
    'TRANS_06_SHI_DE_JUDGMENT_ABUSE',
})


def _validate_pattern(pattern, label):
    if not isinstance(pattern, re.Pattern) or not isinstance(pattern.pattern, str):
        raise ValueError(f'{label}必须是作用于字符串的已编译正则')
    if pattern.search('') is not None:
        raise ValueError(f'{label}不可匹配空串')


def _compile_pattern(value, label):
    if not isinstance(value, str) or not value:
        raise ValueError(f'{label}必须是非空正则字符串')
    try:
        pattern = re.compile(value)
    except re.error as error:
        raise ValueError(f'{label}正则无效：{error}') from error
    _validate_pattern(pattern, label)
    return pattern


@dataclass(frozen=True)
class GenreLintProfile:
    genre_id: str
    enabled_rules: FrozenSet[str]
    max_avg_clause_len: float
    colloquial_markers: Pattern[str]
    # Compatibility default only; never proves a book has system panels.
    enable_system_bracket_anchor: bool = False
    tactical_scene_keywords: Pattern[str] = field(default_factory=lambda: re.compile(
        r'(?:通讯器|耳麦|频道|指挥部|塔台|公堂|宣读)'))

    def __post_init__(self):
        if not isinstance(self.genre_id, str) or not re.fullmatch(r'[a-z][a-z0-9_-]*', self.genre_id):
            raise ValueError('genre_id必须是非空的小写标识')
        if not isinstance(self.enabled_rules, (set, frozenset, list, tuple)):
            raise ValueError('enabled_rules必须是规则ID集合/数组，空集合表示全部关闭')
        if any(not isinstance(rule, str) for rule in self.enabled_rules):
            raise ValueError('enabled_rules只能包含字符串ID')
        rules = frozenset(self.enabled_rules)
        if not rules <= KNOWN_RULE_IDS:
            raise ValueError('未知规则ID：' + ', '.join(sorted(rules - KNOWN_RULE_IDS)))
        object.__setattr__(self, 'enabled_rules', rules)
        if (isinstance(self.max_avg_clause_len, bool) or not isinstance(self.max_avg_clause_len, (int, float))
                or not math.isfinite(self.max_avg_clause_len) or self.max_avg_clause_len <= 0):
            raise ValueError('max_avg_clause_len必须是有限正数')
        if type(self.enable_system_bracket_anchor) is not bool:
            raise ValueError('enable_system_bracket_anchor必须是bool')
        _validate_pattern(self.colloquial_markers, 'colloquial_markers')
        _validate_pattern(self.tactical_scene_keywords, 'tactical_scene_keywords')

    def has_colloquial_marker(self, text):
        return any(m.end() > m.start() for m in self.colloquial_markers.finditer(text))

    def to_report(self):
        return {'genre_id': self.genre_id, 'enabled_rules': sorted(self.enabled_rules),
            'max_avg_clause_len': self.max_avg_clause_len,
            'colloquial_markers': self.colloquial_markers.pattern,
            'enable_system_bracket_anchor': self.enable_system_bracket_anchor,
            'tactical_scene_keywords': self.tactical_scene_keywords.pattern,
            'notice': '显式选择的参考参数，不是题材定律；关键词只提示上下文，不自动免检。'}


PROFILE_MODERN_GRITTY = GenreLintProfile(
    'modern_gritty', KNOWN_RULE_IDS, 9.5,
    re.compile(r'(?:不用|就行|就能|不就|可别|先别|老实|胡乱|使劲|玩意儿?|家伙|哪能|总算|行了|得嘞|瞧瞧|先[^。！？；]{0,20}再)|[吧呢啊嘛哟喽呗哈呐](?=[，。！？；、\s]|$)'),
    True,
)
PROFILE_CLASSICAL_XIANXIA = GenreLintProfile(
    'classical_xianxia', KNOWN_RULE_IDS - {
        'COMP_02_IMPERATIVE_TRIPLE_CHOP', 'COMP_03_SUBJECTLESS_STATUS_PAIR', 'COMP_04_COORDINATE_REPLY'},
    7.5, re.compile(r'(?:且慢|莫要|休要|何苦|不妨|倒也|罢了|劳驾|物件|斯文|造化|掌柜|小二)|[吧呢啊嘛罢哩咧哉](?=[，。！？；、\s]|$)'),
    False,
)
PROFILE_WESTERN_FANTASY = GenreLintProfile(
    'western_fantasy', KNOWN_RULE_IDS - {
        'COMP_04_COORDINATE_REPLY', 'TRANS_03_ENGLISH_IMPERATIVE_CALQUE', 'TRANS_06_SHI_DE_JUDGMENT_ABUSE'},
    10.5, re.compile(r'(?:伙计|老兄|女神在上|见鬼|该死|得了吧|瞧瞧|算了吧|老实说)|[吧呢啊嘛哟呗](?=[，。！？；、\s]|$)'),
    True,
)
GENRE_PROFILES = MappingProxyType({p.genre_id: p for p in (
    PROFILE_MODERN_GRITTY, PROFILE_CLASSICAL_XIANXIA, PROFILE_WESTERN_FANTASY)})


def get_genre_profile(genre_id):
    if not isinstance(genre_id, str) or genre_id not in GENRE_PROFILES:
        raise ValueError(f'未知题材配置：{genre_id!r}')
    return GENRE_PROFILES[genre_id]


def resolve_genre_profile(genre_id=None, overrides=None):
    if overrides is None:
        overrides = {}
    if not isinstance(overrides, dict):
        raise ValueError('genre_overrides必须是JSON对象')
    if genre_id is None:
        if overrides:
            raise ValueError('使用genre_overrides前需明确选择genre_id')
        return None
    base = get_genre_profile(genre_id)
    allowed = {'enabled_rules', 'max_avg_clause_len', 'colloquial_markers',
        'enable_system_bracket_anchor', 'tactical_scene_keywords'}
    if set(overrides) - allowed:
        raise ValueError('genre_overrides包含未知字段')
    values = dict(overrides)
    for name in ('colloquial_markers', 'tactical_scene_keywords'):
        if name in values:
            values[name] = _compile_pattern(values[name], name)
    return replace(base, **values)


def scene_keyword_hints(paragraphs, profile):
    if profile is None:
        return []
    return [{'para_index': index + 1, 'matched_keywords': sorted({m.group() for m in profile.tactical_scene_keywords.finditer(p) if m.end() > m.start()}),
             'automatic_exemption': False}
            for index, p in enumerate(paragraphs)
            if any(m.end() > m.start() for m in profile.tactical_scene_keywords.finditer(p))]


def normalize_scene_exemptions(values):
    if values is None or values == ():
        return {}
    if not isinstance(values, Mapping):
        raise ValueError('场景豁免必须是quote_id到规则ID集合的映射')
    normalized = {}
    for quote_id, rules in values.items():
        if not isinstance(quote_id, str) or not re.fullmatch(r'p[1-9]\d*:q[1-9]\d*', quote_id):
            raise ValueError('场景豁免包含无效quote_id')
        if not isinstance(rules, (set, frozenset, list, tuple)) or any(not isinstance(r, str) for r in rules):
            raise ValueError('每条引语的场景豁免须明确列出规则ID')
        selected = frozenset(rules)
        if not selected <= SCENE_STYLE_RULE_IDS:
            raise ValueError('场景不能豁免构词、压力或未知规则')
        normalized[quote_id] = selected
    return normalized


def resolve_scene_overrides(dialogues, records=None):
    """Only exact, author-declared quotation records can waive selected hints."""
    if records is None:
        records = []
    if not isinstance(records, list):
        raise ValueError('scene_overrides必须是数组')
    indexed = {(d.para_index, d.quote_index): d for d in dialogues}
    seen, exempt, applied = set(), {}, []
    for record in records:
        fields = {'para_index', 'quote_index', 'quote', 'mode', 'reason', 'exempt_rule_ids'}
        if not isinstance(record, dict) or set(record) != fields:
            raise ValueError('场景记录必须含para_index/quote_index/quote/mode/reason/exempt_rule_ids')
        p, q = record['para_index'], record['quote_index']
        if type(p) is not int or type(q) is not int or (p, q) not in indexed or (p, q) in seen:
            raise ValueError('场景记录位置无效或重复')
        dialogue = indexed[(p, q)]
        if record['quote'] != dialogue.text:
            raise ValueError('场景记录原句与当前引语不一致')
        if record['mode'] not in ('normal', 'tactical', 'formal_reading'):
            raise ValueError('未知场景mode')
        if not isinstance(record['reason'], str) or not record['reason'].strip():
            raise ValueError('场景记录必须写明人工确认依据')
        selected = normalize_scene_exemptions({dialogue.quote_id: record['exempt_rule_ids']})[dialogue.quote_id]
        if record['mode'] == 'normal' and selected:
            raise ValueError('normal场景不能声明豁免')
        if record['mode'] != 'normal' and not selected:
            raise ValueError('场景豁免须至少指定一条可豁免规则')
        seen.add((p, q))
        if record['mode'] != 'normal':
            exempt[dialogue.quote_id] = selected
        applied.append({'quote_id': dialogue.quote_id, 'mode': record['mode'],
            'reason': record['reason'], 'exempt_rule_ids': sorted(selected)})
    return exempt, applied

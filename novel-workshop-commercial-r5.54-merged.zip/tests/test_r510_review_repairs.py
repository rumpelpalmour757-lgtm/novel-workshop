#!/usr/bin/env python3
"""r5.10: repairs for the 2026-10-17 review of the r5.9 candidate (two speakers on one line; the line split or merged).

The review's example: 岳宁 and 方澈 speak on one line ("岳宁说：“走吧？”方澈说：“走吧。”"). The revision splits the
line in two and trades their places ("方澈说：“走吧？”" / "岳宁说：“走吧。”"), so both marks changed: r5.4 to r5.9
reported nothing, and the strict gate passed with nothing to decide. With the marks moving along (a pure move) they
reported two certain changes that did not happen; merging two lines into one and trading places did the same.

Every quote of the original line got one narration -- all letters outside the quotes on the line, "岳宁说方澈说" --
so the fallback could not tell the two apart, a tie fell back to the order, and the order paired 岳宁's words with
方澈's. Each quote now gets the narration that belongs to it: the text in front of the first quote and after the last;
between two quotes, a part ending with a colon introduces the next quote, a speech tag right after a quote closes it
("“…”岳宁低声说。"), and what is left over cannot be told apart and goes with both.
Uncertain items are acceptable here; passing a real change unreported, or reporting one that did not happen, is not.
All material is invented for these tests; reviews are labelled test data.
"""

import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SCRIPTS = ROOT / "skills" / "novel-workshop" / "scripts"
DIMENSIONS = ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function", "continuity",
              "revision_comparison")


def whole_text(text):
    """r5.11: a strict-mode PASS needs the expression record. These short test texts are read as one segment; the
    record is test data that only lets the gate get to what this file tests."""
    body = text.strip()
    begin = next(body[:k] for k in range(4, len(body) + 1) if len("".join(body[:k].split())) >= 4)
    end = next(body[-k:] for k in range(4, len(body) + 1)
               if len("".join(body[-k:].split())) >= 4 and body.count(body[-k:]) == 1)
    return {"scope": "chapter", "decisions": [],
            "segments": [{"from": begin, "to": end, "note": "测试数据：只验证结构，从“%s”连读到“%s”" % (begin, end)}]}


# The review's own texts, with the two neutral narration lines of its gate fixture.
TAIL = "\n门外有人经过，脚步声渐渐远去。\n窗边那盏旧灯还亮着。\n"
ORIGINAL = "岳宁说：“走吧？”方澈说：“走吧。”\n" + TAIL
CHANGED = "方澈说：“走吧？”\n\n岳宁说：“走吧。”\n" + TAIL
PURE_MOVE = "方澈说：“走吧。”\n\n岳宁说：“走吧？”\n" + TAIL
SPLIT_ONLY = "岳宁说：“走吧？”\n\n方澈说：“走吧。”\n" + TAIL
MERGED_CHANGED = "方澈说：“走吧？”岳宁说：“走吧。”\n" + TAIL
MERGED_PURE = "方澈说：“走吧。”岳宁说：“走吧？”\n" + TAIL

# One person's speech as it stands on a line, alone or with someone else's: {n} the name, {w} the words.
FORMS = {
    "front": "{n}说：“{w}”",
    "front_low": "{n}低声说：“{w}”",
    "back": "“{w}”{n}低声说。",
    "back_short": "“{w}”{n}说。",
    "beat": "{n}点了点头。“{w}”",
}
OTHER = {"！": "。", "。": "？", "？": "！"}


_MODULE = []


def checker():
    if not _MODULE:  # loaded once: the matrices below compare thousands of pairs
        spec = importlib.util.spec_from_file_location("r510_punctuation", SCRIPTS / "punctuation_lint.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _MODULE.append(module)
    return _MODULE[0]


def compare(original, revised):
    return checker().compare_texts(original, revised)


def flagged(report):
    return {(t["line"], t["column"]) for t in report["tone_changes"]}


def certain(report):
    return [(t["line"], t["column"], t["before"] + "→" + t["after"]) for t in report["tone_changes"]
            if t["match"] != "uncertain"]


def render(rows, blank=True, before=None):
    """rows: physical lines, each a list of (name, form, mark) said on that line in reading order. A blank line between
    rows when `blank`; `before` is an unchanged line put first. Returns the text and each name's (line, column)."""
    out, where = ([before] + ([""] if blank else [])) if before else [], {}
    for k, people in enumerate(rows):
        text = ""
        for name, form, mark in people:
            piece = FORMS[form].format(n=name, w="走吧" + mark)
            where[name] = (len(out) + 1, len(text) + piece.index("“") + 1)
            text += piece
        out.append(text)
        if blank and k < len(rows) - 1:
            out.append("")
    return "\n".join(out) + "\n" + TAIL, where


class Checks:
    def check(self, original_rows, revised_rows, blank=True, before=None):
        original, _ = render(original_rows, blank, before)
        revised, where = render(revised_rows, blank, before)
        report = compare(original, revised)
        old = {name: mark for row in original_rows for name, _, mark in row}
        truth = {where[name]: (old[name], mark) for row in revised_rows for name, _, mark in row}
        seen = flagged(report)
        for place, (before_mark, after_mark) in truth.items():
            if before_mark != after_mark:
                self.assertIn(place, seen, (original, revised, report["tone_changes"]))
        for item in report["tone_changes"]:
            if item["match"] != "uncertain":
                self.assertEqual((item["before"], item["after"]), truth.get((item["line"], item["column"])),
                                 (original, revised, report["tone_changes"]))


class TheReportsRegrouping(unittest.TestCase):
    """The review's seven cases, word for word."""

    def test_split_and_traded_both_changes_are_flagged(self):
        report = compare(ORIGINAL, CHANGED)
        # 方澈 (now line 1) went from 。 to ？; 岳宁 (now line 3) went from ？ to 。.
        self.assertTrue({(1, 5), (3, 5)} <= flagged(report), report["tone_changes"])
        for item in certain(report):
            self.assertIn(item, [(1, 5, "。→？"), (3, 5, "？→。")], report["tone_changes"])

    def test_split_and_traded_alone_is_never_a_certain_change(self):
        # r5.4 to r5.9 reported line 1 ？→。 and line 3 。→？ (changed_line); neither happened.
        self.assertEqual(certain(compare(ORIGINAL, PURE_MOVE)), [])

    def test_merged_and_traded_both_changes_are_flagged(self):
        report = compare(SPLIT_ONLY, MERGED_CHANGED)
        # 方澈 (now first on line 1) went from 。 to ？; 岳宁 (now second) went from ？ to 。.
        self.assertTrue({(1, 5), (1, 14)} <= flagged(report), report["tone_changes"])
        for item in certain(report):
            self.assertIn(item, [(1, 5, "。→？"), (1, 14, "？→。")], report["tone_changes"])

    def test_merged_and_traded_alone_is_never_a_certain_change(self):
        self.assertEqual(certain(compare(SPLIT_ONLY, MERGED_PURE)), [])

    def test_splitting_or_merging_alone_changes_nothing(self):
        self.assertEqual(compare(ORIGINAL, SPLIT_ONLY)["tone_changes"], [])
        self.assertEqual(compare(SPLIT_ONLY, ORIGINAL)["tone_changes"], [])

    def test_an_ordinary_mark_edit_stays_certain(self):
        report = compare(ORIGINAL, "岳宁说：“走吧。”方澈说：“走吧。”\n" + TAIL)
        self.assertEqual([(t["line"], t["before"] + "→" + t["after"], t["match"]) for t in report["tone_changes"]],
                         [(1, "？→。", "same_line")])

    def test_the_gate_needs_decisions(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            (work / "original.md").write_bytes((ORIGINAL).encode("utf-8"))
            (work / "draft.md").write_bytes((CHANGED).encode("utf-8"))
            (work / "checks.json").write_bytes((json.dumps({"candidate": "draft.md", "mode": "strict", "checks": [
                {"id": "rev", "type": "revision", "source": "original.md"}]})).encode("utf-8"))

            def run(*args):
                proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPTS / "workflow_guard.py"), *args], cwd=work,
                                      capture_output=True, text=True, encoding="utf-8")
                return proc.returncode, json.loads(proc.stdout)

            def review(name, dispositions):
                # The review's own fixture: three quotes from the draft, all six dimensions, labelled test data.
                (work / name).write_bytes((json.dumps({
                    "schema": "editorial-review/2", "verdict": "PASS",
                    "candidate_sha256": hashlib.sha256((work / "draft.md").read_bytes()).hexdigest(),
                    "reviewer": {"mode": "self_check", "label": "测试数据：只验证结构"},
                    "checked_against": ["测试数据：original.md"], "inputs_read": ["original.md"],
                    "evidence": [{"in": "candidate", "quote": q} for q in ("方澈说：“走吧？”", "门外有人经过", "窗边那盏旧灯")],
                    "issues": [], "counter_evidence": "测试数据，不是真实文学审稿。", "machine_dispositions": dispositions,
                    "dimensions": [{"id": key, "status": "met", "note": "测试数据：只验证结构"} for key in DIMENSIONS],
                    "expression": whole_text((work / "draft.md").read_text(encoding="utf-8"))},
                    ensure_ascii=False)).encode("utf-8"))
                return name

            self.assertEqual(run("start", "state.json", "--task-id", "r510", "--spec", "checks.json")[0], 0)
            items = [x["id"] for x in run("check", "checks.json")[1]["review_items"]]
            self.assertTrue({"rev:TONE-L1-C5", "rev:TONE-L3-C5"} <= set(items), items)
            code, out = run("record", "state.json", "--event-id", "v1", "--review", review("none.json", []))
            self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"))
            code, _ = run("record", "state.json", "--event-id", "v2", "--review", review("all.json", [
                {"id": key, "decision": "keep", "reason": "测试数据：逐句对照过原稿（%s）" % key} for key in items]))
            self.assertEqual(code, 0)
            gate = run("status", "state.json")[1]["gate"]
            self.assertEqual((gate["mechanical"], gate["editorial"], gate["review_items_open"]),
                             ("GREEN", "PASS[self_check]", 0))


class TwoPeopleRegrouped(Checks, unittest.TestCase):
    """Two people say the same words, each in one of five forms that stand on a line alone or with another person's:
    the speaker in front with a colon (two verbs), after the words (two verbs), or an action in front. The line holding
    both is split in two, two lines are merged into one, or the two trade places on the line; with or without blank
    lines, with or without an unchanged line of a third person saying the same words in front. The people trade places
    or not; each keeps the form or the place keeps it; marks kept, traded, or changed for one of them."""

    BASES = [("？", "。"), ("。", "！")]
    BEFORE = (None, "莫川说：“走吧！”")

    def marks(self, m1, m2):
        return {"kept": (m1, m2), "traded": (m2, m1), "first": (OTHER[m1], m2), "second": (m1, OTHER[m2])}

    def run_cases(self, shape):
        for f1, f2 in itertools.product(FORMS, repeat=2):
            for (m1, m2), blank, before, swap, follow in itertools.product(
                    self.BASES, (True, False), self.BEFORE, (False, True), ("person", "place")):
                if follow == "place" and (not swap or f1 == f2):
                    continue  # the same case as follow == "person"
                for scenario, (n1, n2) in self.marks(m1, m2).items():
                    a, b = ("岳宁", f1, n1), ("方澈", f2, n2)
                    if swap:
                        a, b = (("方澈", f1 if follow == "place" else f2, n2),
                                ("岳宁", f2 if follow == "place" else f1, n1))
                    original, revised = shape((("岳宁", f1, m1), ("方澈", f2, m2)), (a, b))
                    if original == revised:
                        continue
                    with self.subTest(forms=(f1, f2), marks=m1 + m2, blank=blank, before=bool(before), swap=swap,
                                      follow=follow, scenario=scenario):
                        self.check(original, revised, blank, before)

    def test_one_line_split_in_two(self):
        self.run_cases(lambda o, r: ([list(o)], [[r[0]], [r[1]]]))

    def test_two_lines_merged_into_one(self):
        self.run_cases(lambda o, r: ([[o[0]], [o[1]]], [list(r)]))

    def test_one_line_kept_people_traded_on_it(self):
        self.run_cases(lambda o, r: ([list(o)], [list(r)]))

    def test_the_reviews_examples_are_in_this_matrix(self):
        self.assertEqual(render([[("岳宁", "front", "？"), ("方澈", "front", "。")]])[0], ORIGINAL)
        self.assertEqual(render([[("方澈", "front", "？")], [("岳宁", "front", "。")]])[0], CHANGED)
        self.assertEqual(render([[("方澈", "front", "？"), ("岳宁", "front", "。")]])[0], MERGED_CHANGED)


class ThreePeopleRegrouped(Checks, unittest.TestCase):
    """Three people: two on one line and one on a line of their own; the revision regroups them (the lone one joins
    another, the pair splits), in another order; marks kept or changed for some."""

    def test_regrouped_in_another_order(self):
        forms = ("front", "back", "beat")
        names = ("岳宁", "方澈", "莫川")
        base = ("？", "。", "！")
        groupings = [((0, 1), (2,)), ((0,), (1, 2)), ((0,), (1,), (2,)), ((0, 1, 2),)]
        for order, keep_forms, changed, blank in itertools.product(
                itertools.permutations(range(3)), (True, False), ((), (1,), (0, 2)), (True, False)):
            original = [[(names[k], forms[k], base[k]) for k in (0, 1)], [(names[2], forms[2], base[2])]]
            for grouping in groupings:
                people = []
                for slot, k in enumerate(order):
                    mark = OTHER[base[k]] if k in changed else base[k]
                    people.append((names[k], forms[k] if keep_forms else forms[slot], mark))
                revised = [[people[slot] for slot in group] for group in grouping]
                if revised == original:
                    continue
                with self.subTest(order=order, keep_forms=keep_forms, changed=changed, blank=blank, grouping=grouping):
                    self.check(original, revised, blank)


class EachQuoteGetsItsOwnNarration(unittest.TestCase):
    """How the narration of a line is shared out among its quotes (attributions): in front of the first quote and after
    the last one; between two quotes, by the colon, by a speech tag closing the quote before, by narration that the
    quote before already has in front of it; what cannot be told goes with both; a quote with nothing of its own gets
    the whole line."""

    LINES = [
        ("岳宁说：“走吧？”方澈说：“走吧。”", ["岳宁说", "方澈说"]),
        ("“走吧？”岳宁低声说。“走吧。”方澈低声说。", ["岳宁低声说", "方澈低声说"]),
        ("“走吧？”岳宁压低嗓子说。“走吧。”方澈说。", ["岳宁压低嗓子说", "方澈说"]),
        ("“走吧？”岳宁低声说。方澈说：“走吧。”", ["岳宁低声说", "方澈说"]),
        ("门开了。“走吧？”岳宁低声说。“走吧。”方澈低声说。", ["门开了岳宁低声说", "方澈低声说"]),
        ("岳宁说：“走吧？”方澈点了点头。“走吧。”", ["岳宁说", "方澈点了点头"]),
        ("岳宁说：“走吧？”方澈低声说。“走吧。”", ["岳宁说", "方澈低声说"]),
        ("岳宁说：“走吧？”方澈想了想，“走吧。”", ["岳宁说", "方澈想了想"]),
        ("岳宁点了点头。“走吧？”方澈点了点头。“走吧。”", ["岳宁点了点头", "方澈点了点头"]),
        ("“走吧？”岳宁笑了笑。“走吧。”方澈低声说。", ["岳宁笑了笑", "岳宁笑了笑方澈低声说"]),
        ("岳宁说：“走吧？”“走吧。”方澈低声说。", ["岳宁说", "方澈低声说"]),
        ("“走吧，”岳宁说，“我们走。”", ["岳宁说", "岳宁说"]),
        ("门开了。“走吧，”岳宁说，“我们走。”", ["门开了岳宁说", "岳宁说"]),
        ("岳宁说：“走吧？”“走吧。”", ["岳宁说", "岳宁说"]),
    ]

    def test_each_line(self):
        for line, expected in self.LINES:
            spans = [(k, line.index("”", k) + 1) for k, char in enumerate(line) if char == "“"]
            with self.subTest(line=line):
                self.assertEqual(checker().attributions(line, spans), expected)


class SpeakersPairByTheirOwnNarration(unittest.TestCase):
    """When every quote of the same words has a narration of its own, found once on each side, the words pair by it
    (by_narration): the review's changes are reported as certain with the right marks, and a pure move or regrouping
    reports nothing. Lines of bare words that another such line repeats are left out of the elimination."""

    def items(self, report):
        return [(t["line"], t["column"], t["before"] + "→" + t["after"], t["match"]) for t in report["tone_changes"]]

    def test_split_and_traded(self):
        self.assertEqual(self.items(compare(ORIGINAL, CHANGED)),
                         [(1, 5, "。→？", "changed_line"), (3, 5, "？→。", "changed_line")])
        self.assertEqual(self.items(compare(ORIGINAL, PURE_MOVE)), [])

    def test_merged_and_traded(self):
        self.assertEqual(self.items(compare(SPLIT_ONLY, MERGED_CHANGED)),
                         [(1, 5, "。→？", "changed_line"), (1, 14, "？→。", "changed_line")])
        self.assertEqual(self.items(compare(SPLIT_ONLY, MERGED_PURE)), [])

    def test_the_last_one_pairs_by_elimination(self):
        # 莫川's speaker line is reworded, so only 岳宁 and 方澈 pair by narration; 莫川's words are the ones left.
        original = "岳宁说：“走吧？”方澈说：“走吧。”\n\n莫川说：“走吧！”\n" + TAIL
        revised = "方澈说：“走吧。”\n\n莫川低声说：“走吧？”岳宁说：“走吧？”\n" + TAIL
        self.assertEqual(self.items(compare(original, revised)), [(3, 7, "！→？", "changed_line")])

    def test_bare_words_said_on_another_bare_line_are_not_eliminated(self):
        # Two lines say “走吧” with nobody named: which is which is not in the text, so line 2 stays uncertain.
        original = "岳宁点了点头。“走吧。”方澈说：“别动？”\n“走吧？”\n\n第二段的叙述照旧。\n“走吧。”\n"
        revised = "岳宁点了点头。“走吧。”\n“走吧。”\n方澈说：“别动？”\n\n第二段的叙述照旧。\n“走吧？”\n"
        line2 = [item for item in self.items(compare(original, revised)) if item[0] == 2]
        self.assertEqual([item[3] for item in line2], ["uncertain"], line2)


class NarrationStillWeighsWhenNoneMatchExactly(unittest.TestCase):
    """With every speaker line reworded, no narration is found again as it was, and the order is weighed by how alike
    the narrations are (r5.9). The revision trades 罗峻 and 许平 and calls one of them "他", so the trade shows in one
    name only; the narrations still tell the order apart, the whole lines would not."""

    ORIGINAL = "罗峻低声说：“走吧？”\n\n“走吧。”许平低声说。\n" + TAIL

    def test_traded_with_changed_marks(self):
        report = compare(self.ORIGINAL, "许平轻声说：“走吧？”\n\n“走吧。”他轻声说。\n" + TAIL)
        self.assertTrue({1, 3} <= {t["line"] for t in report["tone_changes"]}, report["tone_changes"])
        for item in certain(report):
            self.assertIn(item, [(1, 7, "。→？"), (3, 1, "？→。")], report["tone_changes"])

    def test_traded_with_marks_moving_along(self):
        report = compare(self.ORIGINAL, "许平轻声说：“走吧。”\n\n“走吧？”他轻声说。\n" + TAIL)
        self.assertEqual(certain(report), [], report["tone_changes"])


class ANarrationThatCannotTellTwoQuotesApart(unittest.TestCase):
    """Two quotes of one line that get no narration of their own share the whole line's; when the narration differs
    elsewhere, the order of the two is not trusted ("same_narration"). One person throughout pairs in order."""

    def test_two_people_behind_one_narration(self):
        original = "“走吧？”岳宁说完，方澈接着说：“走吧。”\n" + TAIL
        report = compare(original, "“走吧？”方澈问。\n\n岳宁答：“走吧。”\n" + TAIL)
        self.assertEqual([(t["line"], t["match"], t.get("uncertain_reason")) for t in report["tone_changes"]],
                         [(1, "uncertain", "same_narration"), (3, "uncertain", "same_narration")])

    def test_one_person_throughout(self):
        original = "岳宁说：“走吧？”“走吧。”\n" + TAIL
        self.assertEqual(compare(original, "岳宁说：“走吧？”\n\n岳宁说：“走吧。”\n" + TAIL)["tone_changes"], [])


class RegroupingThatStaysCertain(unittest.TestCase):
    """Guards against over-correcting: splitting or merging without anyone trading places, with one mark changed or
    the speaker reworded, still reports the real change as certain and nothing else."""

    def test_split_one_mark_changed(self):
        report = compare(ORIGINAL, "岳宁说：“走吧？”\n\n方澈说：“走吧！”\n" + TAIL)
        self.assertEqual(certain(report), [(3, 5, "。→！")], report["tone_changes"])
        self.assertEqual(len(report["tone_changes"]), 1, report["tone_changes"])

    def test_merge_one_mark_changed(self):
        report = compare(SPLIT_ONLY, "岳宁说：“走吧。”方澈说：“走吧。”\n" + TAIL)
        self.assertEqual(certain(report), [(1, 5, "？→。")], report["tone_changes"])
        self.assertEqual(len(report["tone_changes"]), 1, report["tone_changes"])

    def test_split_with_a_reworded_speaker(self):
        report = compare(ORIGINAL, "岳宁低声说：“走吧？”\n\n方澈说：“走吧！”\n" + TAIL)
        self.assertEqual(certain(report), [(3, 5, "。→！")], report["tone_changes"])
        self.assertEqual(len(report["tone_changes"]), 1, report["tone_changes"])

    def test_split_with_tags_after_the_words(self):
        original = "“走吧？”岳宁低声说。“走吧。”方澈低声说。\n" + TAIL
        report = compare(original, "“走吧？”岳宁低声说。\n\n“走吧！”方澈低声说。\n" + TAIL)
        self.assertEqual(certain(report), [(3, 1, "。→！")], report["tone_changes"])
        self.assertEqual(len(report["tone_changes"]), 1, report["tone_changes"])


if __name__ == "__main__":
    unittest.main()

"""Step 3: order the images with OpenCLIP, by the scene's text and by the author's reference images, and pick a few
that differ from each other (one per near-copy group).

The model, its weights and the preprocessing are fixed by the config: openclip.model (ViT-B-32 by default),
openclip.pretrained (the weights' tag) and either openclip.weights_path (a weights file you downloaded; its sha256 is
checked against openclip.weights_sha256 when given) or openclip.allow_download (open_clip fetches the tag into its
cache). Without torch and open_clip, or without weights, the step stops with DEPENDENCY_MISSING or MODEL_MISSING. Then
the run may still be reviewed in search order, and every record says that no CLIP ranking was done: no keyword score
or random number stands in for it. A similarity score only says how close the model finds two things; it is not how
well an image fits the novel.

r5.37 (the r5.35 review, point 3): when the model passes the check but fails to load or to encode, the step records
MODEL_ERROR and orders by the searches, as when the model is missing. The reference images are copied into the run
(references/, named by sha256), so verify-run can tell whether the reference a score was made with is still there.
A new order makes the bundle built on the old one outdated.

r5.38 (the r5.37 review, point 3): the vector cache is bound to the bytes that were encoded. Before encoding and
before a cached vector is used, each image file is checked against the sha256 the run recorded for it: a missing or
changed file is not encoded, not scored and not recommended (not_ranked says why; collect fetches it again). An image
is encoded from a copy of the bytes that were checked, and its vector is stored under their sha256, so a vector can
never sit under another version's name. The cache format is new (openclip-v2-…); a cache from before r5.38 is not
read, because it may hold a vector made from a changed file.
"""
import math
from pathlib import Path
import shutil
import tempfile

from . import common


def openclip_status(config):
    try:
        import open_clip
        import torch
    except Exception as exc:  # noqa: BLE001
        return "DEPENDENCY_MISSING", "torch and open_clip are not installed (pip install open_clip_torch): %s" % exc, {}
    versions = {"open_clip": getattr(open_clip, "__version__", "?"), "torch": getattr(torch, "__version__", "?")}
    options = config["openclip"]
    path = options.get("weights_path") or ""
    if path:
        weights = Path(path).expanduser()
        if not weights.is_file():
            return "MODEL_MISSING", "openclip.weights_path %s does not exist" % path, versions
        if options.get("weights_sha256"):
            digest = common.sha256_file(weights)
            if digest != options["weights_sha256"]:
                return "MODEL_MISSING", "the weights file's sha256 is %s, not openclip.weights_sha256" % digest, versions
        return "ready", "weights file %s" % weights.name, versions
    if options.get("allow_download"):
        return "ready", "open_clip may download %s/%s into its cache" % (options["model"], options["pretrained"]), versions
    return "MODEL_MISSING", ("no weights: set openclip.weights_path to a downloaded weights file (and weights_sha256), "
                             "or set openclip.allow_download"), versions


class OpenCLIPBackend:
    """The real model: open_clip.create_model_and_transforms with the configured weights."""

    def __init__(self, config):
        import open_clip
        import torch

        options = config["openclip"]
        self.torch = torch
        self.device = options.get("device") or "cpu"
        path = options.get("weights_path") or ""
        pretrained = str(Path(path).expanduser()) if path else options["pretrained"]
        model, _, preprocess = open_clip.create_model_and_transforms(options["model"], pretrained=pretrained,
                                                                     device=self.device,
                                                                     cache_dir=options.get("cache_dir") or None)
        model.eval()
        self.model, self.preprocess = model, preprocess
        self.tokenizer = open_clip.get_tokenizer(options["model"])
        self.info = {"model": options["model"], "pretrained": options["pretrained"] if not path else "",
                     "weights_path": Path(path).name if path else "", "device": self.device,
                     "weights_sha256": common.sha256_file(Path(path).expanduser()) if path else "",
                     "open_clip": getattr(open_clip, "__version__", "?"), "torch": getattr(torch, "__version__", "?")}

    def identity(self):
        return "%s|%s|%s" % (self.info["model"], self.info["weights_sha256"] or self.info["pretrained"],
                             self.info["open_clip"])

    def _normal(self, features):
        return (features / features.norm(dim=-1, keepdim=True)).cpu().tolist()

    def images(self, paths):
        from PIL import Image

        with self.torch.no_grad():
            batch = self.torch.stack([self.preprocess(Image.open(p).convert("RGB")) for p in paths]).to(self.device)
            return self._normal(self.model.encode_image(batch))

    def text(self, words):
        with self.torch.no_grad():
            return self._normal(self.model.encode_text(self.tokenizer([words]).to(self.device)))[0]


def cosine(a, b):
    top = sum(x * y for x, y in zip(a, b))
    norm = math.sqrt(sum(x * x for x in a)) * math.sqrt(sum(y * y for y in b))
    return top / norm if norm else 0.0


def recommend(order, groups, budgets):
    """Up to recommend_max images, one per near-copy group, in the given order; fewer when there are fewer groups."""
    picked, used = [], set()
    for sha in order:
        gid = groups.get(sha)
        if gid in used:
            continue
        used.add(gid)
        picked.append(sha)
        if len(picked) >= budgets["recommend_max"]:
            break
    return picked


def images_of(run):
    """Distinct decoded images of the run in candidate order, with their group (from dedupe, or their own)."""
    seen, out = set(), []
    for c in run.candidates():
        image = c.get("image")
        if image and image["sha256"] not in seen:
            seen.add(image["sha256"])
            out.append({"sha256": image["sha256"], "file": image["file"], "cid": c["cid"],
                        "gid": image.get("gid") or "solo-" + image["sha256"][:8]})
    return out


def fallback(run, images, groups, budgets, status, why, extra=None):
    """No CLIP ranking: the searches' order, one image per near-copy group, and a record that says so."""
    order = [i["sha256"] for i in images]
    record = dict({"schema": "visual-rank/1", "status": status, "error": why, "clip_used": False,
                   "fallback": {"by": "search_order", "note": "没有用 OpenCLIP 排序：按两路搜索交替返回的顺序，每组近似图只取一张"},
                   "order": order, "recommend": recommend(order, groups, budgets)}, **(extra or {}))
    record["outdated"] = run.outdate("rank")
    run.save("rank.json", record)
    run.step("rank", {"status": status, "clip_used": False})
    return {"status": status, "error": why, "clip_used": False, "recommend": len(record["recommend"]),
            "outdated": record["outdated"]}


def keep_references(run, paths):
    """Copy each reference image into the run (references/SHA256.ext) and say which file and version it was."""
    out = []
    for path in paths:
        digest = common.sha256_file(path)
        name = "references/%s%s" % (digest, path.suffix.lower() if len(path.suffix) <= 6 else "")
        target = run.path(name)
        if not (target.is_file() and common.sha256_file(target) == digest):
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(str(path), str(target))
        out.append({"name": path.name, "sha256": digest, "file": name})
    return out


CACHE_FORMAT = "openclip-v2"


def checked_files(run, images):
    """{sha256: why} for the images whose file is missing or is not the version the run recorded."""
    bad = {}
    for item in images:
        path = run.path(item["file"])
        if not path.is_file():
            bad[item["sha256"]] = "the image file is missing: fetch again (collect)"
        elif common.sha256_file(path) != item["sha256"]:
            bad[item["sha256"]] = "the image file is not the version the run recorded: fetch again (collect)"
    return bad


def encode_checked(run, backend, items):
    """{sha256: vector} for items, each encoded from a copy of the bytes checked against its sha256; an item whose
    bytes changed meanwhile is left out (and not cached)."""
    vectors = {}
    with tempfile.TemporaryDirectory(prefix="nw-rank-") as folder:
        copies = []
        for item in items:
            data = run.path(item["file"]).read_bytes()
            if common.sha256_bytes(data) != item["sha256"]:
                continue
            copy = Path(folder) / ("%s%s" % (item["sha256"], Path(item["file"]).suffix))
            copy.write_bytes(data)
            copies.append((item["sha256"], copy))
        if copies:
            for (digest, _), vector in zip(copies, backend.images([c for _, c in copies])):
                vectors[digest] = vector
    return vectors


def run_rank(folder, config, text_query=None, reference_images=(), backend=None):
    run = common.Run(folder)
    manifest = run.manifest()
    request = manifest["request"]
    text_query = text_query if text_query is not None else request.get("text_query")
    references = list(reference_images) or request.get("reference_images", [])
    if text_query is not None and (len(text_query) > common.MAX_TEXT_QUERY_CHARS or "\n" in text_query):
        raise common.VisualError("the text query is one line of at most %d characters" % common.MAX_TEXT_QUERY_CHARS)
    paths = [Path(p).expanduser() for p in references]
    budgets = config["budgets"]
    images = images_of(run)
    groups = {i["sha256"]: i["gid"] for i in images}
    if not images:
        record = {"schema": "visual-rank/1", "status": "no_images", "recommend": [], "outdated": run.outdate("rank")}
        run.save("rank.json", record)
        run.step("rank", {"status": "no_images"})
        return {"status": "no_images"}
    injected = backend is not None
    if backend is None:
        status, why, versions = openclip_status(config)
        if status != "ready":
            return fallback(run, images, groups, budgets, status, why, {"versions": versions})
    for p in paths:
        if not p.is_file():
            raise common.VisualError("reference image %s does not exist" % p)
    if not text_query and not paths:
        raise common.VisualError("give a text query or a reference image: there is nothing to rank by")
    bad = checked_files(run, images)
    usable = [i for i in images if i["sha256"] not in bad]
    not_ranked = [{"cid": i["cid"], "sha256": i["sha256"], "why": bad[i["sha256"]]} for i in images if i["sha256"] in bad]
    if not usable:
        record = {"schema": "visual-rank/1", "status": "files_changed", "clip_used": False, "order": [], "recommend": [],
                  "not_ranked": not_ranked, "error": "no image file is the version the run recorded: fetch again (collect)"}
        record["outdated"] = run.outdate("rank")
        run.save("rank.json", record)
        run.step("rank", {"status": "files_changed", "clip_used": False})
        return {"status": "files_changed", "clip_used": False, "not_ranked": len(not_ranked)}
    try:
        if backend is None:
            backend = OpenCLIPBackend(config)
        cache_name = "cache/%s-%s.json" % (CACHE_FORMAT, common.sha256_bytes(backend.identity().encode("utf-8"))[:16])
        cache = run.load(cache_name) if run.exists(cache_name) else {"format": CACHE_FORMAT,
                                                                       "identity": backend.identity(), "images": {}}
        missing = [i for i in usable if i["sha256"] not in cache["images"]]
        if missing:
            fresh = encode_checked(run, backend, missing)
            cache["images"].update(fresh)
            for item in missing:
                if item["sha256"] not in fresh:  # the file changed while it was being read
                    not_ranked.append({"cid": item["cid"], "sha256": item["sha256"],
                                       "why": "the image file changed while it was read: fetch again (collect)"})
            usable = [i for i in usable if i["sha256"] in cache["images"]]
            run.path("cache").mkdir(exist_ok=True)
            run.save(cache_name, cache)
        text_vector = backend.text(text_query) if text_query else None
        reference_info, reference_vectors = [], []
        if paths:
            reference_vectors = backend.images(paths)
            reference_info = keep_references(run, paths)
    except common.VisualError:
        raise
    except Exception as exc:  # noqa: BLE001 - the model failing to load or run is recorded, not a crash of the step
        return fallback(run, images, groups, budgets, "MODEL_ERROR", "%s: %s" % (type(exc).__name__, exc),
                        {"backend": "injected" if injected else "open_clip"})
    weights = config["openclip"]
    scores = []
    for item in usable:
        vector = cache["images"][item["sha256"]]
        text = cosine(vector, text_vector) if text_vector is not None else None
        ref = max(cosine(vector, r) for r in reference_vectors) if reference_vectors else None
        parts = [(float(weights.get("text_weight", 0.5)), text), (float(weights.get("reference_weight", 0.5)), ref)]
        used = [(w, s) for w, s in parts if s is not None and w > 0]
        combined = sum(w * s for w, s in used) / sum(w for w, _ in used) if used else None
        scores.append({"sha256": item["sha256"], "cid": item["cid"], "gid": item["gid"], "text": text, "reference": ref,
                       "combined": combined})
    if all(s["combined"] is None for s in scores):
        raise common.VisualError("give a text query or a reference image: there is nothing to rank by")
    order = [s["sha256"] for s in sorted(scores, key=lambda s: -(s["combined"] if s["combined"] is not None else -9))]
    info = getattr(backend, "info", {"identity": backend.identity()})
    record = {"schema": "visual-rank/1", "status": "ok", "clip_used": True, "model": info,
              "backend": "injected" if injected else "open_clip",
              "text_query": text_query or "", "reference_images": reference_info, "scores": scores, "order": order,
              "recommend": recommend(order, groups, budgets), "cache": cache_name,
              "note": "相似度分数只表示这个模型下两样东西有多接近，不是这张图适合小说的概率"}
    if not_ranked:
        record["not_ranked"] = not_ranked
    older = sorted(p.name for p in run.path("cache").glob("openclip-*.json") if not p.name.startswith(CACHE_FORMAT)) \
        if run.path("cache").is_dir() else []
    if older:
        record["older_cache_not_used"] = older
    if len(record["recommend"]) < budgets["recommend_min"]:
        record["short"] = "只有 %d 组彼此不同的图，少于 %d 张；照实给，不拿近似图凑数" % (len(record["recommend"]),
                                                                       budgets["recommend_min"])
    record["outdated"] = run.outdate("rank")
    run.save("rank.json", record)
    run.step("rank", {"status": "ok", "clip_used": True, "text": bool(text_query), "references": len(reference_info),
                      "not_ranked": len(not_ranked)})
    return {"status": "ok", "clip_used": True, "recommend": len(record["recommend"]), "scored": len(scores),
            "not_ranked": len(not_ranked)}

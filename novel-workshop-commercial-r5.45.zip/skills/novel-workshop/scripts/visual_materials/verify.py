"""verify-run: what one run actually shows, component by component.

A component counts as live_verified only when this run holds its own evidence: SearXNG and Openverse each returned
candidates whose image was fetched and decoded (Openverse with licence metadata); Crawl4AI read a real source page and
an image from that page was fetched and decoded; ImageHash hashed the decoded images and recorded its groups; OpenCLIP
loaded the configured weights and scored the images by a text query and by a reference image. Files are checked
against the hashes the run recorded. All five are "接通" only when all five are live_verified in the same environment.

r5.37 (the r5.35 review, point 3): "ran" and "live_verified" are reported apart. ran says the step's record shows the
real component doing its job in this run; live_verified says the evidence can still be checked now: the images it
was about are the run's current image files (same sha256), the hashes and scores are of those versions, the reference
image a score was made with is still in the run, and the step was not outdated by a later fetch. A changed or missing
image file makes all_five_live false, whatever the components say. status is ALL_FIVE_LIVE or NOT_ALL_LIVE (the
command exits 0 only for ALL_FIVE_LIVE); the author's chain (bundle, what was seen, choice, adoption) is reported on
its own and does not count toward the five.

r5.38 (the r5.37 review, point 1.2): the chain is complete only when the adoption receipt (adopt.json) names the
current selection.json and bundle; a choice made after the last adoption is reported as waiting to be written, and the
earlier adoptions are listed as history.
"""
import ipaddress
import urllib.parse

from . import COMPONENTS, common


def external(url):
    """An address on the open web: not this machine, not a private network. Evidence from a local stand-in service or
    a test fixture never counts as a live run."""
    host = (urllib.parse.urlsplit(url or "").hostname or "").lower()
    if not host or host == "localhost" or host.endswith((".localhost", ".local", ".internal", ".lan", ".test",
                                                         ".invalid", ".example")):
        return False
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        return True
    return not (address.is_private or address.is_loopback or address.is_link_local or address.is_reserved
                or address.is_unspecified)


def sightings(c, provider):
    """Where provider found candidate c: each sighting with its own page and licence (r5.37); a sighting recorded
    before r5.37 has none of its own and uses the candidate's."""
    out = []
    for f in c.get("found_by", []):
        if f.get("provider") != provider:
            continue
        own = "page_url" in f
        out.append({"page_url": f.get("page_url") if own else c.get("page_url"),
                    "license": f.get("license", "") if own else c.get("license", ""),
                    "license_url": f.get("license_url", "") if own else c.get("license_url", "")})
    return out


WRITTEN = ("OK", "UNCHANGED")


def author_chain(run, steps, manifest):
    """The author's chain (r5.38, the r5.37 review, point 1.2): bundle, what was seen, choice, adoption. It is complete
    only when the adoption receipt is for the current selection.json of the current bundle; an earlier adoption is
    history, and a choice made since then waits to be written."""
    chain = {k: steps.get(k, {}).get("status", "not_run") for k in ("review_bundle", "review_record", "select", "adopt")}
    bundle = run.load("review/bundle.json") if run.exists("review/bundle.json") else {}
    chain["bundle_id"] = bundle.get("bundle_id")
    if run.exists("review/observations.recorded.json"):
        recorded = run.load("review/observations.recorded.json")
        chain["viewed"] = sum(1 for o in recorded["items"] if o["scope"] != "none")
        chain["observations_for_this_bundle"] = bool(bundle) and recorded.get("bundle_id") == bundle.get("bundle_id")
    selection = common.sha256_file(run.path("selection.json")) if run.exists("selection.json") else None
    if selection:
        chain["selection_for_this_bundle"] = bool(bundle) and run.load("selection.json").get("bundle_id") == \
            bundle.get("bundle_id")
    receipt = run.load("adopt.json") if run.exists("adopt.json") else None
    current = bool(receipt and selection and receipt.get("selection_sha256") == selection
                   and receipt.get("bundle_id") == bundle.get("bundle_id"))
    chain["selection_sha256"] = selection
    chain["adopted_selection_sha256"] = (receipt or {}).get("selection_sha256")
    chain["current_selection_adopted"] = current and receipt.get("status") in WRITTEN
    if not selection:
        state = "no choice yet" if not receipt else "no current choice (it was made again or moved to outdated/)"
    elif not receipt:
        state = "the current choice is not written yet: run adopt"
    elif not current:
        state = ("the current choice is not written yet (the last adoption was of an earlier choice): run adopt"
                 if receipt.get("selection_sha256") else
                 "the adoption record is from before r5.38 and does not say which choice it wrote: run adopt again "
                 "(it answers UNCHANGED when the library already holds this choice)")
    elif receipt.get("status") in WRITTEN:
        state = "written: library %s, revision %s" % (receipt.get("library"), receipt.get("library_revision"))
    elif receipt.get("status") == "COMMITTED_INCOMPLETE":
        state = "written, but the library's history is pending (the next write finishes it)"
    else:
        state = "not written (%s)" % receipt.get("status")
    chain["state"] = state
    chain["complete"] = chain["current_selection_adopted"]
    earlier = [a for a in manifest.get("adoptions", []) if a.get("selection_sha256") != selection]
    if earlier:
        chain["earlier_adoptions"] = earlier
    return chain


def run_verify(folder):
    run = common.Run(folder)
    manifest = run.manifest()
    steps = manifest.get("steps", {})
    candidates = run.candidates()
    problems = []
    fetched = {}
    for c in candidates:
        image = c.get("image")
        if not image:
            continue
        path = run.path(image["file"])
        if not path.is_file() or common.sha256_file(path) != image["sha256"]:
            problems.append("%s: the image file is missing or changed" % c["cid"])
            continue
        fetched[c["cid"]] = c
    current = {c["image"]["sha256"] for c in fetched.values()}
    out = {}
    search = run.load("search.json") if run.exists("search.json") else {"providers": {}}
    collect = run.load("collect.json") if run.exists("collect.json") else {"pages": []}
    fetch_real = (collect.get("transport") or {}).get("fetch", "http") == "http"
    for name in ("searxng", "openverse"):
        record = search["providers"].get(name, {})
        real = search.get("transport", "http") == "http" and fetch_real
        ran = record.get("status") in ("ok", "partial") and real
        def found(pool):
            hits = []
            for c in pool:
                for s in sightings(c, name):
                    if external(s["page_url"]) and external(c["image_url"]) and (
                            name != "openverse" or (s["license"] and s["license_url"])):
                        hits.append((c, s))
                        break
            return hits

        mine = found(fetched.values())
        recorded = found(c for c in candidates if c.get("image"))
        live = ran and bool(mine)
        out[name] = {"ran": ran, "live_verified": live, "status": record.get("status", "not_run"),
                     "requests": [{k: r.get(k) for k in ("query", "url", "http_status", "status", "results", "kept",
                                                          "time") if k in r} for r in record.get("requests", [])],
                     "evidence": [{"cid": c["cid"], "page_url": s["page_url"], "image_url": c["image_url"],
                                   "sha256": c["image"]["sha256"], "license": s["license"],
                                   "license_url": s["license_url"]} for c, s in mine[:3]]}
        if not live:
            if not record:
                why = "no request ran"
            elif not real:
                why = "the run used a stand-in transport (a test), not the real service"
            elif not recorded or not ran:
                why = "no candidate from %s on the open web was fetched and decoded%s (status %s)" % (
                    name, " with licence metadata" if name == "openverse" else "", record.get("status"))
            else:
                why = "the images from %s that were fetched are not the run's current files any more (missing or " \
                      "changed): fetch again" % name
            out[name]["missing"] = why
    pages_ok = {p["page_url"] for p in collect.get("pages", []) if p.get("status") == "ok" and external(p.get("page_url"))}
    crawl_real = (collect.get("transport") or {}).get("crawl", "crawl4ai") == "crawl4ai" and fetch_real
    ran = bool(pages_ok) and crawl_real
    def read_from_pages(pool):
        return [c for c in pool
                if ({c["page_url"]} | {f.get("page_url") or f.get("page") for f in c["found_by"]}) & pages_ok
                and (c.get("on_page") or any(f["provider"] == "crawl4ai" for f in c["found_by"]))]

    from_pages = read_from_pages(fetched.values())
    from_pages_recorded = read_from_pages(c for c in candidates if c.get("image"))
    live = ran and bool(from_pages)
    out["crawl4ai"] = {"ran": ran, "live_verified": live, "version": collect.get("crawl4ai_version"),
                       "browser_started": (collect.get("crawl4ai") or {}).get("browser_started"),
                       "pages": [{k: p.get(k) for k in ("page_url", "status", "http_status", "error", "time")}
                                 for p in collect.get("pages", [])],
                       "evidence": [{"cid": c["cid"], "page_url": c["page_url"], "image_url": c["image_url"],
                                     "sha256": c["image"]["sha256"]} for c in from_pages[:3]]}
    if not live:
        out["crawl4ai"]["missing"] = ("the run used a stand-in crawler or fetch (a test)" if not crawl_real else
                                      "no source page on the open web was read with images that were then fetched and "
                                      "decoded" if not ran or not from_pages_recorded else
                                      "the images from the pages read are not the run's current files any more "
                                      "(missing or changed): fetch again")
    dedupe = run.load("dedupe.json") if run.exists("dedupe.json") else {}
    algorithms = dedupe.get("algorithms") or []
    known = bool(algorithms) and all(a in common.HASH_ALGORITHMS for a in algorithms)
    hashed = [i for i in dedupe.get("images", []) if i.get("hashes") and known and set(algorithms) <= set(i["hashes"])]
    ran = dedupe.get("status") == "ok" and len(hashed) >= 2
    valid = [i for i in hashed if i.get("sha256") in current]
    live = ran and len(valid) >= 2
    out["imagehash"] = {"ran": ran, "live_verified": live, "version": dedupe.get("imagehash_version"),
                        "algorithms": algorithms, "max_distance": dedupe.get("max_distance"),
                        "images": len(hashed), "images_current": len(valid), "groups": len(dedupe.get("groups", [])),
                        "near_copy_groups": sum(1 for g in dedupe.get("groups", []) if len(g["images"]) > 1)}
    if not live:
        out["imagehash"]["missing"] = (
            "ImageHash did not hash two or more decoded images in this run (status %s)" % dedupe.get("status", "not_run")
            if not ran else "only %d of the %d hashed images are still the run's current image files: the hashes are "
            "of other versions now (fetch again, then dedupe again)" % (len(valid), len(hashed)))
    rank = run.load("rank.json") if run.exists("rank.json") else {}
    text = bool(rank.get("text_query"))
    references = rank.get("reference_images") or []
    kept = [r for r in references if r.get("file") and run.path(r["file"]).is_file()
            and common.sha256_file(run.path(r["file"])) == r.get("sha256")]
    scores = rank.get("scores", [])
    ran = rank.get("status") == "ok" and rank.get("clip_used") is True and text and bool(references) and \
        len(scores) >= 2 and rank.get("backend") == "open_clip"
    scored_now = [s for s in scores if s.get("sha256") in current]
    live = ran and len(kept) == len(references) and len(scored_now) >= 2
    out["openclip"] = {"ran": ran, "live_verified": live, "status": rank.get("status", "not_run"),
                       "model": rank.get("model"), "text_query_run": text, "reference_query_run": bool(references),
                       "references_kept": len(kept), "scored": len(scores), "scored_current": len(scored_now)}
    if not live and rank.get("backend") == "injected":
        out["openclip"]["missing"] = "the run used a stand-in model (a test), not open_clip"
    elif not live and not ran:
        out["openclip"]["missing"] = (rank.get("error") or ("ranked without a reference image" if rank.get("clip_used")
                                                             and not references else "ranked without a text query"
                                                             if rank.get("clip_used") else "no CLIP ranking in this run"))
    elif not live:
        out["openclip"]["missing"] = (
            "the reference image a score was made with is not in the run any more, or changed (references/); rank "
            "again" if len(kept) != len(references) else
            "only %d of the %d scored images are still the run's current image files; rank again" % (
                len(scored_now), len(scores)))
    chain = author_chain(run, steps, manifest)
    live_all = all(out[n]["live_verified"] for n in COMPONENTS) and not problems
    not_ran = [n for n in COMPONENTS if not out[n]["ran"]]
    not_now = [n for n in COMPONENTS if out[n]["ran"] and not out[n]["live_verified"]]
    gaps = []
    if not_ran:
        gaps.append("%s 没有在这次运行里实际跑通" % "、".join(not_ran))
    if not_now:
        gaps.append("%s 跑过，但现在的证据核不上（图、参考图换了或删了，或步骤重跑后旧记录作废）" % "、".join(not_now))
    if problems:
        gaps.append("运行里有 %d 张图的文件缺了或变了" % len(problems))
    report = {"schema": "visual-verify/1", "run": run.folder.name, "checked": common.now(),
              "status": "ALL_FIVE_LIVE" if live_all else "NOT_ALL_LIVE", "components": out, "chain": chain,
              "files": "ok" if not problems else problems, "all_five_live": live_all,
              "all_five_ran": not not_ran,
              "summary": "五项在这次运行里都实际跑通" if live_all else "未全部接通：%s" % "；".join(gaps)}
    run.save("verify.json", report)
    return report

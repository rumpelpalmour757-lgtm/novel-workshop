#!/usr/bin/env python3
"""查正文的AI味：80条词汇与句法禁令、语域防火墙、节奏硬指标（句长、段长、感叹号、每千字的连词叠词成语拟声等）。

用法：
  python scripts/lint_text.py 第012章.txt --register 现代
  python scripts/lint_text.py 正文/*.txt --pack urban-martial
  python scripts/lint_text.py 草稿.txt --register 古风 --skip RULE_45 RULE_51 --allow 观察
  cat 草稿.txt | python scripts/lint_text.py - --register modern
--register 现代/古风/废土：开对应的语域防火墙（现代禁片刻、良久……；古风禁重心、概率……）。
--pack urban-martial：和都市高武风格引擎库同用（语域按现代，「重心」「角度」降为提示）。
--skip 跳过某些禁令（写编号前缀即可，如 RULE_45）；--allow 放行某些词（人名、专有名词撞了禁词时用）。
--profile 读本书设定档的 realism 段（需要 PyYAML）。--strict 警告也算问题。--max 每个文件最多列多少条（默认40，0 表示全列）。
退出码：0 没有错误（可能有警告）；1 有错误或指标超标（加 --strict 时警告也算）。只用标准库。
"""
import argparse
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import COUNTERS, K, METRICS, PACKS, RULES, load_profile, read_text, register_of  # noqa: E402

QUOTED = re.compile(r"“[^”\n]*(?:”|$)|「[^」\n]*(?:」|$)|『[^』\n]*(?:』|$)|【[^】\n]*(?:】|$)")
DIALOGUE = re.compile(r"“[^”\n]*(?:”|$)|「[^」\n]*(?:」|$)|『[^』\n]*(?:』|$)")
SENT_SPLIT = re.compile(r"[。！？!?…]+")
CLAUSE_SPLIT = re.compile(r"[，,。！？!?；;：:…]+")
OPENERS = "“”「」『』‘’\"'（）()—　 \t"
INDENT = " \t　"
LEVEL = {"error": "错误", "warning": "警告", "hint": "提示"}
PER_1K = [   # (显示名, 指标键, 计数方式)
    ("对话感叹号", "dialogue_exclamation_max_per_1k", "dialogue_bang"),
    ("逻辑连词", "max_conjunctions_per_1k", "conjunctions"),
    ("软绵叠词", "max_reduplicated_verbs_per_1k", "reduplication"),
    ("现成四字成语", "max_four_char_idioms_per_1k", "idioms"),
    ("漫画拟声词", "max_cartoon_onomatopoeia_per_1k", "onomatopoeia"),
    ("「把……给……」", "max_ba_constructions_per_1k", "ba"),
    ("第一人称滤镜", "max_first_person_filters_per_1k", "first_person"),
]
MIN_CHARS_FOR_DENSITY = 500


def mask(text, words):
    for w in sorted(words, key=len, reverse=True):
        text = text.replace(w, "□" * len(w))
    return text


def short(s):
    s = s.strip()
    return s if len(s) <= 24 else f"{s[:16]}……（{len(s)}字）"


def count(kind, body):
    if kind == "dialogue_bang":
        return sum(m.group(0).count("！") + m.group(0).count("!") for m in DIALOGUE.finditer(body))
    spec = COUNTERS[kind]
    if isinstance(spec, str):
        return len(re.findall(spec, body))
    return sum(body.count(w) for w in spec)


def lint(text, register, skip, allow, downgrade):
    rules = [(r, re.compile(r["pattern"])) for r in RULES if not any(r["id"].startswith(s) for s in skip)]
    reg_words = K["registers"][register]["ban"] if register else []
    hits, notes = [], {"long_sentence": [], "de_chain": [], "pronoun_run": []}
    clause_total = clause_ok = 0
    lo, hi = METRICS["optimal_clause_chars"]
    pron = tuple(COUNTERS["pronouns"])
    for i, raw in enumerate(text.splitlines(), 1):
        line = mask(raw.lstrip(INDENT), allow)
        if not line.strip():
            continue
        narration = QUOTED.sub("", line)
        caught = []
        for r, pat in rules:
            target = narration if r["scope"] == "narration" else line
            for m in pat.finditer(target):
                level = "hint" if r["id"] in downgrade else r["severity"]
                hits.append((i, level, r["name"], short(m.group(0)), r["fix"]))
                caught.append(m.group(0))
                if r["scope"] == "line_start":
                    break
        for w in reg_words:
            if w in line and not any(w in c for c in caught):
                hits.append((i, "error", f"语域防火墙（{K['registers'][register]['name']}）", w,
                             "换成本语域的说法；度量用" + "、".join(K["registers"][register].get("measures", []))))
        for s in SENT_SPLIT.split(line):
            if len(re.sub(r"\s", "", s)) > METRICS["max_sentence_chars"]:
                notes["long_sentence"].append(i)
                break
        run = 0
        for c in CLAUSE_SPLIT.split(line):
            c = c.strip(OPENERS)
            if not c:
                continue
            clause_total += 1
            clause_ok += lo <= len(c) <= hi
            if max(seg.count("的") for seg in c.split("、")) > METRICS["max_de_particles_per_clause"]:
                notes["de_chain"].append(i)
            run = run + 1 if c.startswith(pron) and c[1:2] != "们" else 0
            if run == METRICS["max_consecutive_pronoun_starts"] + 1:
                notes["pronoun_run"].append(i)
    body = mask(text, allow)
    chars = len(re.sub(r"\s", "", body))
    density = []
    for name, key, kind in PER_1K:
        n = count(kind, body)
        rate = n * 1000 / chars if chars else 0.0
        over = chars >= MIN_CHARS_FOR_DENSITY and rate > METRICS[key]
        density.append((name, n, rate, METRICS[key], over))
    share = clause_ok * 100 // clause_total if clause_total else 100
    return sorted(hits), notes, density, chars, share


def lines_of(nums, limit=12):
    nums = sorted(set(nums))
    s = "、".join(map(str, nums[:limit]))
    return s + ("……" if len(nums) > limit else "")


def main():
    ap = argparse.ArgumentParser(description="查正文的AI味")
    ap.add_argument("files", nargs="+", help="正文文件（txt/md），- 表示从标准输入读")
    ap.add_argument("--register", help="语域：现代、古风、废土")
    ap.add_argument("--pack", help="同时使用的题材包，如 urban-martial")
    ap.add_argument("--skip", nargs="*", default=[], help="跳过的禁令编号前缀，如 RULE_45")
    ap.add_argument("--allow", nargs="*", default=[], help="放行的词")
    ap.add_argument("--profile", help="本书设定档（读其中的 realism 段）")
    ap.add_argument("--strict", action="store_true", help="警告也算问题")
    ap.add_argument("--max", type=int, default=40, help="每个文件最多列多少条，0 表示全列")
    args = ap.parse_args()

    prof = load_profile(args.profile) if args.profile else {"register": None, "pack": None, "skip": [], "allow": []}
    pack_name = args.pack or prof["pack"]
    pack = PACKS.get(pack_name) if pack_name else None
    if pack_name and not pack:
        sys.exit(f"没有这个题材包：{pack_name}。可选：{'、'.join(PACKS)}")
    register = register_of(args.register or prof["register"] or (pack or {}).get("register"))
    skip = args.skip + prof["skip"]
    allow = args.allow + prof["allow"]
    downgrade = set((pack or {}).get("downgrade", []))
    if not register:
        print("提示：没给语域（--register 现代/古风/废土），语域防火墙没开")

    failed = False
    for f in args.files:
        text = read_text(f)
        hits, notes, density, chars, share = lint(text, register, skip, allow, downgrade)
        print(f"== {f}（{chars}字）")
        shown = hits if args.max == 0 else hits[:args.max]
        for i, level, name, hit, fix in shown:
            print(f"第{i}行 [{LEVEL[level]}] {name}「{hit}」→ {fix}")
        if len(shown) < len(hits):
            print(f"……另有{len(hits) - len(shown)}处（加 --max 0 全部列出）")
        warn = sum(1 for h in hits if h[1] == "warning")
        if notes["long_sentence"]:
            print(f"句长：超过{METRICS['max_sentence_chars']}字的句子在第{lines_of(notes['long_sentence'])}行")
        if notes["de_chain"]:
            print(f"「的」字：一个分句里超过{METRICS['max_de_particles_per_clause']}个「的」，在第{lines_of(notes['de_chain'])}行")
        if notes["pronoun_run"]:
            print(f"代词起句：连续以他/她/我开头的分句，在第{lines_of(notes['pronoun_run'])}行")
        warn += sum(len(set(v)) for v in notes.values())
        lo, hi = METRICS["optimal_clause_chars"]
        print(f"分句长度：{lo}到{hi}字的占{share}%")
        judged = chars >= MIN_CHARS_FOR_DENSITY
        print("每千字" + ("：" if judged else f"（不足{MIN_CHARS_FOR_DENSITY}字，只列数，不判超标）："))
        over = 0
        for name, n, rate, cap, is_over in density:
            over += is_over
            print(f"  {name} {n}个，{rate:.1f}/千字（上限{cap}）" + ("  超标" if is_over else ""))
        err = sum(1 for h in hits if h[1] == "error") + over
        hint = sum(1 for h in hits if h[1] == "hint")
        print(f"结论：错误{err}（含指标超标{over}项）、警告{warn}、提示{hint}。")
        failed |= bool(err) or (args.strict and bool(warn))
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""CLI regressions for changing plans, claims and author acceptance."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

PACKAGE_ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SCRIPT = PACKAGE_ROOT / "skills" / "novel-workshop" / "scripts" / "workflow_guard.py"
BODY = "雨停了。林舟把铜匣放回柜子，锁上门才离开。\n"


class WorkflowContextRepair(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.write("draft.md", BODY)
        self.write("original.md", BODY)
        self.spec = {"candidate": "draft.md", "checks": [
            {"id": "keep", "type": "contains", "text": "锁上门才离开"},
            {"id": "source", "type": "file_hash", "source": "original.md", "sha256": self.sha("original.md")}]}

    def tearDown(self):
        self.temp.cleanup()

    def write(self, name, value):
        (self.root / name).write_text(value if isinstance(value, str) else json.dumps(value, ensure_ascii=False), encoding="utf-8")

    def sha(self, name):
        return hashlib.sha256((self.root / name).read_bytes()).hexdigest()

    def call(self, *args, code=0):
        proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT), *map(str, args)],
                              cwd=self.root, capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(proc.returncode, code, proc.stdout + proc.stderr)
        return json.loads(proc.stdout)

    def start(self):
        self.write("checks.json", self.spec)
        self.call("start", "run.json", "--task-id", "fixture", "--spec", "checks.json")

    def record(self, event="v0", **overrides):
        review = {"schema": "editorial-review/2", "verdict": "PASS",
                  "candidate_sha256": self.sha(self.spec["candidate"]),
                  "reviewer": {"mode": "self_check", "label": "回归用例自查"},
                  "checked_against": ["保留锁门动作"], "inputs_read": ["original.md"],
                  "evidence": [{"quote": "林舟把铜匣放回柜子", "in": "candidate"}], "issues": [],
                  "machine_dispositions": [], "counter_evidence": "核对匣子仍留在柜内，人物离开未携走。"}
        review.update(overrides)
        self.write("review.json", review)
        return self.call("record", "run.json", "--event-id", event, "--review", "review.json")

    def gate(self):
        return self.call("status", "run.json")["gate"]

    def replan(self, event="p1", code=0):
        self.write("checks.json", self.spec)
        self.write("decision.json", {"author_decision": "更换本轮依据", "source": "测试中的模拟决定",
                                     "affected_scope": "本轮候选稿"})
        return self.call("replan", "run.json", "--event-id", event, "--spec", "checks.json",
                         "--decision", "decision.json", code=code)

    def assert_stale(self):
        gate = self.gate()
        self.assertEqual((gate["mechanical"], gate["editorial"]), ("STALE", "STALE"))
        return gate

    def test_replan_new_constraint_invalidates_pass_even_with_unchanged_body(self):
        self.start()
        self.record()
        self.spec["checks"].append({"id": "new", "type": "contains", "text": "不存在的句子"})
        self.replan()
        self.assert_stale()
        self.call("reserve", "run.json", "--event-id", "r1")
        state = self.record("v1")
        self.assertEqual(state["current_node"], "repair")
        self.assertEqual(self.gate()["mechanical"], "RED")

    def test_replan_identical_inputs_still_starts_a_new_review_generation(self):
        self.start()
        self.record()
        self.replan()
        self.assert_stale()
        self.call("reserve", "run.json", "--event-id", "r1")
        self.record("v1")
        self.assertEqual(self.gate()["mechanical"], "GREEN")

    def test_replan_candidate_path_uses_new_file_not_old_recorded_path(self):
        self.start()
        self.record()
        self.write("replacement.md", BODY + "他在门口等了一会儿。\n")
        self.spec["candidate"] = "replacement.md"
        self.replan()
        gate = self.assert_stale()
        self.assertEqual(gate["candidate"], "replacement.md")
        self.assertEqual(gate["candidate_sha256"], self.sha("replacement.md"))
        self.write("draft.md", "旧文件已改掉。")
        self.assertEqual(self.gate()["candidate_sha256"], self.sha("replacement.md"))

    def test_same_bytes_in_different_candidate_path_are_not_the_same_review(self):
        self.start()
        self.record()
        self.write("replacement.md", BODY)
        self.spec["candidate"] = "replacement.md"
        self.replan()
        self.assert_stale()

    def add_facts(self):
        self.write("ledger.json", {"schema": "fact-ledger/1",
            "entities": {"box": {"name": "铜匣", "aliases": ["铜匣"]}},
            "chapters": {"1": {"status": "accepted", "file": "original.md", "sha256": self.sha("original.md")},
                         "2": {"status": "candidate", "file": "draft.md"}},
            "facts": [{"id": "f1", "entity": "box", "attribute": "location", "value": "柜内", "chapter": 1,
                       "layer": "accepted", "basis": "text_statement", "source": "第1章正文"}]})
        self.claims = {"schema": "fact-claims/1", "chapter": 2, "candidate": "draft.md",
                       "candidate_sha256": self.sha("draft.md"), "extracted_by": "test_fixture",
                       "claims": [{"id": "c1", "entity": "box", "attribute": "location", "value": "柜内",
                                   "basis": "text_statement", "quote": "林舟把铜匣放回柜子"}]}
        self.write("claims.json", self.claims)
        self.spec["checks"].append({"id": "facts", "type": "facts", "ledger": "ledger.json", "claims": "claims.json"})

    def test_claim_edit_invalidates_both_gates_without_freezing_claims(self):
        self.add_facts()
        self.start()
        self.record(inputs_read=["original.md", "ledger.json"])
        self.assertEqual(self.gate()["mechanical"], "GREEN")
        self.claims["claims"][0]["value"] = "门外"
        self.write("claims.json", self.claims)
        gate = self.assert_stale()
        self.assertEqual(gate["input_ready"], "READY")
        report = self.call("check", "checks.json", code=1)
        self.assertEqual(report["status"], "RED")
        self.assertEqual(report["mutable_inputs"][0]["sha256"], self.sha("claims.json"))

    def test_deleted_claims_are_blocked_instead_of_reusing_green(self):
        self.add_facts()
        self.start()
        self.record(inputs_read=["original.md", "ledger.json"])
        (self.root / "claims.json").unlink()
        self.assertEqual(self.assert_stale()["input_ready"], "BLOCKED")

    def test_frozen_source_changes_invalidate_both_gates(self):
        self.start()
        self.record()
        self.write("original.md", BODY + "新的要求。")
        self.assertEqual(self.assert_stale()["input_ready"], "BLOCKED")

    def test_missing_candidate_cannot_be_ready(self):
        self.start()
        self.record()
        (self.root / "draft.md").unlink()
        self.assertEqual(self.assert_stale()["input_ready"], "BLOCKED")

    def test_legacy_result_without_context_requires_review_again(self):
        self.start()
        self.record()
        state = json.loads((self.root / "run.json").read_text(encoding="utf-8"))
        del state["evidence"][-1]["context"]
        self.write("run.json", state)
        self.assert_stale()

    def test_uppercase_author_hash_is_normalized_and_idempotent(self):
        self.start()
        self.record()
        value = self.sha("draft.md")
        self.write("accept.json", {"candidate_sha256": value.upper(), "source": "模拟作者：采用此版", "scope": "第2章全文"})
        state = self.call("accept", "run.json", "--event-id", "a1", "--decision", "accept.json")
        self.assertEqual(state["human_approvals"][-1]["decision"]["candidate_sha256"], value)
        self.assertEqual(self.gate()["author"], "ACCEPTED")
        self.write("accept.json", {"candidate_sha256": value, "source": "模拟作者：采用此版", "scope": "第2章全文"})
        repeated = self.call("accept", "run.json", "--event-id", "a1", "--decision", "accept.json")
        self.assertEqual(len(repeated["human_approvals"]), 1)

    def test_acceptance_rejects_nonhex_hash(self):
        self.start()
        self.record()
        self.write("accept.json", {"candidate_sha256": "z" * 64, "source": "模拟作者", "scope": "全文"})
        report = self.call("accept", "run.json", "--event-id", "a1", "--decision", "accept.json", code=2)
        self.assertEqual(report["failure"], "ACCEPT_INVALID")

    def test_strict_empty_replan_is_refused_without_overwriting_state(self):
        self.start()
        self.record()
        before = (self.root / "run.json").read_bytes()
        self.spec.update(mode="strict", checks=[])
        report = self.replan(code=2)
        self.assertIn("strict mode requires", report["message"])
        self.assertEqual((self.root / "run.json").read_bytes(), before)

    def test_disposed_review_items_are_not_counted_as_open(self):
        self.write("draft.md", "他伸手。握住刀柄。拔。没拔动。\n")
        self.spec["checks"] = [{"id": "p", "type": "punctuation"}]
        self.start()
        report = self.call("check", "checks.json")
        self.assertTrue(report["review_items"])
        self.record(inputs_read=[], evidence=[{"quote": "握住刀柄。拔。没拔动", "in": "candidate"}],
                    machine_dispositions=[{"id": x["id"], "decision": "keep", "reason": "模拟作者指定的顿挫"}
                                          for x in report["review_items"]])
        self.assertEqual(self.gate()["review_items_open"], 0)


if __name__ == "__main__":
    unittest.main()

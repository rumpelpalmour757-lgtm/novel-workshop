@echo off
where node >nul 2>nul || (echo Node.js was not found. Install Node.js 18 or newer from https://nodejs.org and try again. & pause & exit /b 1)
node "%~dp0workbench.mjs" --demo %*
if errorlevel 1 pause

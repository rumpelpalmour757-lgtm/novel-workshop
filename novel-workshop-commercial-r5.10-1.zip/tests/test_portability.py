"""Portability: the scripts must start and report correctly on Windows as well as on POSIX.

Windows itself is simulated here, not used:
- child processes in which ``import fcntl`` fails (as on Windows) and, on Linux, a stand-in
  ``msvcrt`` module provides the lock; the stand-in emulates ``msvcrt.locking`` with an
  exclusive side file and records its calls;
- a child process whose standard streams default to GBK, as a pipe on a Chinese Windows does;
- a static scan that every text file the packaged code opens names its encoding.
Passing here does not prove the package was run on a real Windows machine. On Windows the
existing lock tests (test_r42) exercise the real msvcrt.
"""
import ast
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import textwrap
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SCRIPTS = ROOT / "skills" / "novel-workshop" / "scripts"
TESTS = Path(__file__).resolve().parent

FAKE_MSVCRT = '''
"""Test stand-in for Windows msvcrt.locking (Linux only: finds the file behind a descriptor via /proc)."""
import errno
import os

LK_UNLCK, LK_LOCK, LK_NBLCK, LK_RLCK, LK_NBRLCK = 0, 1, 2, 3, 4
calls = []


def _side(fd):
    return os.readlink("/proc/self/fd/%d" % fd) + ".held-by-test-msvcrt"


def locking(fd, mode, nbytes):
    calls.append([mode, nbytes])
    if mode == LK_NBLCK:
        try:
            os.close(os.open(_side(fd), os.O_CREAT | os.O_EXCL | os.O_WRONLY))
        except FileExistsError:
            raise OSError(errno.EACCES, "Permission denied")  # what msvcrt raises for a held region
    elif mode == LK_UNLCK:
        try:
            os.unlink(_side(fd))
        except FileNotFoundError:
            pass
    else:
        raise AssertionError("unexpected msvcrt.locking mode %r" % mode)
'''

# Runs inside the child: hide fcntl, offer the stand-in msvcrt, then run one packaged script as __main__.
WINDOWS_LIKE = textwrap.dedent('''
    import runpy, sys
    fake_dir, script = sys.argv[1], sys.argv[2]
    sys.modules["fcntl"] = None  # "import fcntl" now raises ImportError, as on Windows
    sys.path.insert(0, fake_dir)
    import msvcrt
    sys.argv = [script] + sys.argv[3:]
    try:
        runpy.run_path(script, run_name="__main__")
    finally:
        sys.stderr.write("\\nMSVCRT_CALLS=%r\\n" % (msvcrt.calls,))
''')


@unittest.skipUnless(sys.platform.startswith("linux"), "the msvcrt stand-in needs Linux /proc")
class WindowsLikeLock(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.fake = self.tmp / "fake"
        self.fake.mkdir()
        (self.fake / "msvcrt.py").write_text(FAKE_MSVCRT, encoding="utf-8")
        self.work = self.tmp / "work"
        self.work.mkdir()

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmp)

    def run_windows_like(self, script, *args):
        proc = subprocess.run([sys.executable, "-I", "-B", "-c", WINDOWS_LIKE, str(self.fake), str(script), *map(str, args)],
                              cwd=self.work, capture_output=True, text=True, encoding="utf-8")
        return proc.returncode, proc.stdout, proc.stderr

    def test_delivery_gate_starts_and_locks_without_fcntl(self):
        (self.work / "draft.md").write_text("雨停了。\n林舟推开门。\n", encoding="utf-8")
        (self.work / "checks.json").write_text(json.dumps(
            {"candidate": "draft.md", "checks": [{"id": "keep", "type": "contains", "text": "林舟推开门。"}]},
            ensure_ascii=False), encoding="utf-8")
        guard = SCRIPTS / "workflow_guard.py"
        code, out, err = self.run_windows_like(guard, "start", "run.json", "--task-id", "t", "--spec", "checks.json")
        self.assertEqual(code, 0, out + err)
        self.assertNotIn("No module named 'fcntl'", err)
        self.assertIn("MSVCRT_CALLS=[[2, 1], [0, 1]]", err)  # locked one byte, then unlocked it
        code, out, err = self.run_windows_like(guard, "status", "run.json", "--summary")
        self.assertEqual(code, 0, out + err)
        self.assertIn("MECHANICAL=", out)
        self.assertFalse(list(self.work.glob("*.held-by-test-msvcrt")))  # nothing left locked

    def test_second_lock_in_the_same_process_gets_state_busy(self):
        loader = textwrap.dedent('''
            import importlib.util, json, sys
            from pathlib import Path
            sys.modules["fcntl"] = None
            sys.path.insert(0, sys.argv[1])
            spec = importlib.util.spec_from_file_location("wg", sys.argv[2])
            wg = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(wg)
            state = Path(sys.argv[3])
            with wg.locked(state):
                try:
                    with wg.locked(state):
                        inner = "acquired"
                except wg.GuardError as exc:
                    inner = exc.code
            with wg.locked(state):
                again = "acquired"
            print(json.dumps({"fcntl": wg.fcntl is None, "inner": inner, "again": again}))
        ''')
        proc = subprocess.run([sys.executable, "-I", "-B", "-c", loader, str(self.fake), str(SCRIPTS / "workflow_guard.py"),
                               str(self.work / "run.json")], capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        self.assertEqual(json.loads(proc.stdout), {"fcntl": True, "inner": "STATE_BUSY", "again": "acquired"})

    def test_second_process_gets_state_busy_while_the_first_holds_the_lock(self):
        # Two real processes share the stand-in. It shows the refusal path; it cannot show that Windows frees the
        # lock when a holder is killed (the stand-in's side file would survive), which needs a real Windows machine.
        holder = textwrap.dedent('''
            import importlib.util, sys
            from pathlib import Path
            sys.modules["fcntl"] = None
            sys.path.insert(0, sys.argv[1])
            spec = importlib.util.spec_from_file_location("wg", sys.argv[2])
            wg = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(wg)
            with wg.locked(Path(sys.argv[3])):
                print("held", flush=True)
                sys.stdin.readline()
        ''')
        tryer = textwrap.dedent('''
            import importlib.util, sys
            from pathlib import Path
            sys.modules["fcntl"] = None
            sys.path.insert(0, sys.argv[1])
            spec = importlib.util.spec_from_file_location("wg", sys.argv[2])
            wg = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(wg)
            try:
                with wg.locked(Path(sys.argv[3])):
                    print("acquired")
            except wg.GuardError as exc:
                print(exc.code)
        ''')
        args = [str(self.fake), str(SCRIPTS / "workflow_guard.py"), str(self.work / "run.json")]
        first = subprocess.Popen([sys.executable, "-I", "-B", "-c", holder, *args], stdin=subprocess.PIPE,
                                 stdout=subprocess.PIPE, text=True, encoding="utf-8")
        try:
            self.assertEqual(first.stdout.readline().strip(), "held")
            second = subprocess.run([sys.executable, "-I", "-B", "-c", tryer, *args], capture_output=True,
                                    text=True, encoding="utf-8")
            self.assertEqual(second.stdout.strip(), "STATE_BUSY", second.stderr)
        finally:
            first.communicate("\n", timeout=30)
        third = subprocess.run([sys.executable, "-I", "-B", "-c", tryer, *args], capture_output=True, text=True,
                               encoding="utf-8")
        self.assertEqual(third.stdout.strip(), "acquired", third.stderr)  # released when the holder left the lock

    def test_batch_manifest_loads_without_fcntl(self):
        # delivery_manifest.py loads workflow_guard.py at import time; --help proves both load.
        code, out, err = self.run_windows_like(SCRIPTS / "delivery_manifest.py", "--help")
        self.assertEqual(code, 0, out + err)
        self.assertNotIn("No module named 'fcntl'", err)

    def test_demo_refuses_cleanly_where_project_state_is_unsupported(self):
        # The demo keeps its fictional project in project_state.py, which is POSIX-only by design
        # (references/state-storage.md). Without fcntl it must refuse with a reason, not crash on import.
        code, out, err = self.run_windows_like(SCRIPTS / "workflow_demo.py", self.work / "demo")
        self.assertEqual(code, 2, out + err)
        self.assertNotIn("No module named 'fcntl'", err)
        self.assertNotIn("Traceback", err)
        self.assertEqual(json.loads(out)["failure"], "unsupported_platform")

    def test_demo_reruns_in_its_own_directory(self):
        # The second run re-reads the demo's UTF-8 marker file; it must not depend on the platform encoding.
        demo = SCRIPTS / "workflow_demo.py"
        for _ in range(2):
            proc = subprocess.run([sys.executable, "-I", "-B", str(demo), str(self.work / "demo")],
                                  capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)


class NoFileLock(unittest.TestCase):
    def test_platform_without_any_file_lock_is_reported_as_unsupported(self):
        probe = textwrap.dedent('''
            import importlib.util, sys
            from pathlib import Path
            sys.modules["fcntl"] = None
            sys.modules["msvcrt"] = None
            spec = importlib.util.spec_from_file_location("wg", sys.argv[1])
            wg = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(wg)
            try:
                with wg.locked(Path(sys.argv[2])):
                    print("acquired")
            except wg.GuardError as exc:
                print(exc.code)
        ''')
        with tempfile.TemporaryDirectory() as tmp:
            proc = subprocess.run([sys.executable, "-I", "-B", "-c", probe, str(SCRIPTS / "workflow_guard.py"),
                                   str(Path(tmp) / "run.json")], capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(proc.stdout.strip(), "UNSUPPORTED_PLATFORM", proc.stderr)


class Utf8Reports(unittest.TestCase):
    def test_reports_are_utf8_when_the_console_code_page_is_gbk(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "chapter.md"
            # An unclosed quote whose context holds a character GBK cannot encode.
            path.write_text("他说：“我还在说😀\n", encoding="utf-8")
            env = {k: v for k, v in os.environ.items() if not k.startswith("PYTHON")}
            env["PYTHONIOENCODING"] = "gbk"  # what a pipe on a Chinese-language Windows would default to
            proc = subprocess.run([sys.executable, "-B", str(SCRIPTS / "punctuation_lint.py"), str(path)],
                                  capture_output=True, env=env, cwd=tmp)
            self.assertNotIn(b"UnicodeEncodeError", proc.stderr)
            report = json.loads(proc.stdout.decode("utf-8"))
            self.assertTrue(any("😀" in json.dumps(f, ensure_ascii=False) for f in report["findings"]))


    def gbk_env(self):
        env = {k: v for k, v in os.environ.items() if not k.startswith("PYTHON")}
        env["PYTHONIOENCODING"] = "gbk"
        return env

    def test_delivery_gate_report_is_utf8_when_the_console_code_page_is_gbk(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / "draft.md").write_text("雨停了。\n", encoding="utf-8")
            (Path(tmp) / "checks.json").write_text(json.dumps({"candidate": "draft.md", "checks": [
                {"id": "keep", "type": "contains", "text": "他笑了😀"}]}, ensure_ascii=False), encoding="utf-8")
            proc = subprocess.run([sys.executable, "-B", str(SCRIPTS / "workflow_guard.py"), "check", "checks.json"],
                                  capture_output=True, env=self.gbk_env(), cwd=tmp)
            self.assertNotIn(b"UnicodeEncodeError", proc.stderr)
            self.assertIn("他笑了😀", proc.stdout.decode("utf-8"))

    def test_export_message_is_utf8_for_a_path_gbk_cannot_hold(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "导出😀" / "sale.zip"
            target.parent.mkdir()
            proc = subprocess.run([sys.executable, "-B", str(SCRIPTS / "export_portable.py"), str(target), "--mode", "sale"],
                                  capture_output=True, env=self.gbk_env(), cwd=tmp)
            self.assertEqual(proc.returncode, 0, proc.stderr.decode("utf-8", "replace"))
            self.assertIn("导出😀", proc.stdout.decode("utf-8"))

    @unittest.skipUnless((ROOT / "PACKAGE-MANIFEST.json").is_file(), "not an assembled release")
    def test_installer_message_is_utf8_for_a_path_gbk_cannot_hold(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp) / "技能😀"
            proc = subprocess.run([sys.executable, "-B", str(ROOT / "install.py"), "--dest", str(dest), "--dry-run"],
                                  capture_output=True, env=self.gbk_env(), cwd=tmp)
            self.assertEqual(proc.returncode, 0, proc.stderr.decode("utf-8", "replace"))
            self.assertIn("技能😀", proc.stdout.decode("utf-8"))


class NoPlatformDefaultEncoding(unittest.TestCase):
    """Every text file the package opens names its encoding; Windows would otherwise read UTF-8 as GBK."""

    # Linux-only font discovery in a third-party-derived chart tool; the output is never parsed as text.
    ALLOWED = {("skills/novel-workshop/scripts/oh-story/render_relation_chart.py", "run")}

    def offenders(self, path):
        found = []
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            keywords = {k.arg for k in node.keywords}
            if "encoding" in keywords:
                continue
            if isinstance(func, ast.Attribute) and func.attr in ("run", "Popen", "check_output"):
                if keywords & {"text", "universal_newlines"}:
                    found.append((func.attr, node.lineno))
                continue
            if isinstance(func, ast.Attribute) and func.attr in ("read_text", "write_text"):
                found.append((func.attr, node.lineno))
                continue
            is_builtin_open = isinstance(func, ast.Name) and func.id == "open"
            is_path_open = isinstance(func, ast.Attribute) and func.attr == "open" and not (
                isinstance(func.value, ast.Name) and func.value.id in ("os", "zipfile", "tarfile", "gzip"))
            if is_builtin_open or is_path_open:
                mode = None
                position = 1 if is_builtin_open else 0
                if len(node.args) > position and isinstance(node.args[position], ast.Constant):
                    mode = node.args[position].value
                for k in node.keywords:
                    if k.arg == "mode" and isinstance(k.value, ast.Constant):
                        mode = k.value.value
                if isinstance(mode, str) and "b" in mode:
                    continue
                found.append(("open", node.lineno))
        return found

    def test_packaged_python_names_its_text_encoding(self):
        files = [p for p in (ROOT / "skills").rglob("*.py") if "__pycache__" not in p.parts]
        files += [ROOT / "install.py"] + sorted(TESTS.glob("*.py"))
        problems = []
        for path in files:
            if not path.is_file():
                continue
            relative = path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else path.name
            for call, line in self.offenders(path):
                if (relative, call) not in self.ALLOWED:
                    problems.append("%s:%d %s" % (relative, line, call))
        self.assertEqual(problems, [])


if __name__ == "__main__":
    unittest.main()

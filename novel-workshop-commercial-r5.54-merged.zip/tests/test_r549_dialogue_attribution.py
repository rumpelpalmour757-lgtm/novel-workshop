#!/usr/bin/env python3
"""r5.49: who is speaking. The author's feedback in a handoff of 11-05: "对白不知道谁是谁说的".

dialogue_lines.py already sorts a line only on clear evidence (r5.35, r5.37); r5.49 adds a section of places where a
reader may lose who is speaking: runs of lines with no stated speaker, a line that starts again after a stretch of
narration with no stated speaker, and lines given to the person who acts right before them. These are places to re-read,
not verdicts, and the script never guesses a speaker from the order of turns. The rule side (dialogue-craft.md "谁在说")
says a "某某说／问" tag is enough and no action is made up to mark a speaker.

Every passage below is newly written for this test.
"""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
SCRIPT = SKILL / "scripts" / "dialogue_lines.py"


def load():
    spec = importlib.util.spec_from_file_location("dialogue_lines_r549", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def paragraphs(*items):
    return "\n\n".join(items) + "\n"


LONG_NARRATION = ("码头上的吊车停了，工人们三三两两蹲在集装箱的阴影里抽烟，有人把安全帽倒扣在地上当凳子，"
                  "远处的货轮拉了一声长笛，海鸥跟着叫起来。")


class Review(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.dl = load()

    def review(self, text, names):
        return self.dl.inspect(text, "blank", names)["attribution_review"]

    def test_a_clear_back_and_forth_is_listed_only_as_a_place_and_says_it_can_stay(self):
        text = paragraphs("梁茵问鲍舟：“船几点到？”", "“四点。”", "“晚了。”", "“那就五点开。”", "“行。”")
        review = self.review(text, ["梁茵", "鲍舟"])
        self.assertEqual([(r["first_line"], r["last_line"], r["count"]) for r in review["runs"]], [(3, 9, 4)])
        self.assertEqual(review["runs"][0]["last_named_before"], {"speaker": "梁茵", "line": 1})
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "第三章.txt"
            path.write_bytes(text.encode("utf-8"))
            out = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT), str(path), "--names", "梁茵,鲍舟"],
                                 capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(out.returncode, 0, out.stderr)
        for phrase in ("谁在说：要回头读的地方（只是位置，不是判定）", "第 3—9 行：连着 4 句没写明是谁说的（前面最后写明的是第 1 行梁茵）",
                       "两个人一来一回、读者跟得上的，可以不动", "补“某某说／问”就够，不必加动作", "不按单双行猜是谁"):
            self.assertIn(phrase, out.stdout)

    def test_a_line_given_by_the_action_before_it_is_marked(self):
        # The author's case: one person's action, then a line that was meant to be the other person's.
        text = paragraphs("梁茵把缆绳甩上桩子。“谁让你松手的？”")
        report = self.dl.inspect(text, "blank", ["梁茵", "鲍舟"])
        self.assertEqual(report["speakers"]["梁茵"][0]["basis"], "beat")
        self.assertEqual(report["attribution_review"]["by_action_before"], [{"line": 1, "speaker": "梁茵"}])
        self.assertIn("（按前面梁茵的动作认的）", self.dl.text_report(report))

    def test_a_stated_speaker_after_someone_elses_action_is_not_marked(self):
        text = paragraphs("梁茵把缆绳甩上桩子。鲍舟问：“谁让你松手的？”")
        report = self.dl.inspect(text, "blank", ["梁茵", "鲍舟"])
        self.assertEqual(report["speakers"]["鲍舟"][0]["basis"], "tag")
        self.assertEqual(report["attribution_review"]["by_action_before"], [])

    def test_the_person_spoken_to_is_not_taken_for_the_speaker(self):
        report = self.dl.inspect(paragraphs("梁茵对鲍舟说：“别回头。”"), "blank", ["梁茵", "鲍舟"])
        self.assertEqual(list(report["speakers"]), ["梁茵"])

    def test_a_line_after_a_stretch_of_narration_is_listed(self):
        text = paragraphs("梁茵问鲍舟：“船几点到？”", "鲍舟说：“四点。”", LONG_NARRATION, "“这一箱是谁的？”")
        review = self.review(text, ["梁茵", "鲍舟", "老戚"])
        self.assertEqual([x["line"] for x in review["after_narration"]], [7])
        self.assertGreaterEqual(review["after_narration"][0]["narration_han"], self.dl.NARRATION_BREAK)
        self.assertEqual(review["runs"], [])

    def test_a_short_stretch_of_narration_does_not_break_a_run(self):
        text = paragraphs("梁茵问鲍舟：“船几点到？”", "“四点。”", "风小了些。", "“晚了。”", "“那就五点开。”")
        review = self.review(text, ["梁茵", "鲍舟"])
        self.assertEqual([(r["first_line"], r["count"]) for r in review["runs"]], [(3, 3)])
        self.assertEqual(review["after_narration"], [])

    def test_a_long_stretch_breaks_a_run_and_drops_the_speaker_named_before(self):
        text = paragraphs("梁茵问鲍舟：“船几点到？”", "“四点。”", "“晚了。”", "“那就五点开。”", LONG_NARRATION,
                          "“灯！”", "“左边！”", "“低头！”")
        runs = self.review(text, ["梁茵", "鲍舟"])["runs"]
        self.assertEqual([(r["first_line"], r["count"]) for r in runs], [(3, 3), (11, 3)])
        self.assertIsNone(runs[1]["last_named_before"])

    def test_stated_lines_with_a_silent_third_person_list_nothing(self):
        text = paragraphs("老戚蹲在船头补网，一直没出声。", "梁茵问鲍舟：“船几点到？”", "鲍舟说：“四点。”", "梁茵说：“晚了。”")
        review = self.review(text, ["梁茵", "鲍舟", "老戚"])
        self.assertEqual((review["runs"], review["after_narration"], review["by_action_before"]), ([], [], []))

    def test_json_carries_the_review_and_its_settings(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "第三章.txt"
            path.write_bytes(paragraphs("“走。”", "“去哪？”", "“码头。”").encode("utf-8"))
            out = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT), str(path), "--format", "json"],
                                 capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(out.returncode, 0, out.stderr)
        review = json.loads(out.stdout)["attribution_review"]
        self.assertEqual(review["settings"], {"run_min": 3, "narration_break_han": 40})
        self.assertEqual(review["runs"][0]["count"], 3)


class Rules(unittest.TestCase):
    def read(self, rel):
        return (SKILL / rel).read_text(encoding="utf-8")

    def test_the_dialogue_module_says_a_tag_is_enough_and_unknown_stays_unknown(self):
        text = self.read("references/dialogue-craft.md")
        start = text.index("## 谁在说：读者认不认得出（r5.49）")
        section = text[start:text.index("\n## ", start + 4)]
        for phrase in ("对白不知道谁是谁说的", "“某某说：”“某某问”就行，不是低级写法", "不为标明谁在说编新动作",
                       "不按比例给台词配动作", "称呼里叫到的多半是受话人", "不按轮流顺序猜", "作者有意不点名的",
                       "“说话人清不清楚”和“对白是不是脱离了现场”是两件事"):
            self.assertIn(phrase, section)

    def test_the_sentence_table_no_longer_leads_with_an_action_beat(self):
        row = next(line for line in self.read("references/sentence-craft.md").splitlines() if line.startswith("| 指代与说话人 |"))
        self.assertNotIn("补半拍动作", row)
        self.assertIn("“某某说／问”就够", row)

    def test_the_routes_and_the_checklists_point_at_the_section(self):
        self.assertIn("| 对白分不清谁在说（作者说“不知道谁是谁说的”） |", self.read("SKILL.md"))
        self.assertIn("对白专项“谁在说”", self.read("assets/sentence-dialogue-checklist.md"))
        self.assertIn("谁在说：要回头读的地方", self.read("references/revision-passes.md"))
        self.assertIn("它管的是对白脱离了现场，不管说话人清不清楚", self.read("references/prose-audit.md"))


if __name__ == "__main__":
    unittest.main()

"""Search adapters: SearXNG (wide image search) and Openverse (openly licensed images with licence metadata)."""

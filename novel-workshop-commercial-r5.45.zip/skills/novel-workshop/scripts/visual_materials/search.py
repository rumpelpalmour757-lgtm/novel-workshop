"""Step 1: the two searches, side by side. One failing does not stop the other; the run says partial."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from . import common
from .providers import openverse, searxng

PROVIDERS = {"searxng": searxng, "openverse": openverse}


SOURCE_KEYS = ("page_url", "title", "page_text", "creator", "license", "license_url")


def sightings_of(item):
    """The item's sightings, each with its own page: one recorded without a page (before r5.37, or written by hand)
    takes the page, words, creator and licence the item came with."""
    out = []
    for sighting in item.get("found_by") or []:
        sighting = dict(sighting)
        if "page_url" not in sighting:
            for key in SOURCE_KEYS:
                sighting[key] = item.get(key, "")
        out.append(sighting)
    return out


def use_primary(item):
    """The candidate's page, title, page text, creator and licence come together from one sighting: the first that
    has a licence with its link, else the first one; it goes first in found_by. A licence is never shown with another
    page's address (the r5.35 review: the second search's licence was kept with the first search's page)."""
    sightings = item["found_by"]
    first = next((f for f in sightings if f.get("license") and f.get("license_url")), sightings[0])
    if first is not sightings[0]:
        sightings.remove(first)
        sightings.insert(0, first)
    for key in SOURCE_KEYS:
        item[key] = first.get(key, "")
    return item


def merge(groups, limit):
    """Candidates from both searches, the same image address once (with every sighting: which search, query and
    page), numbered."""
    out, by_url = [], {}
    # Interleave so that neither search fills the budget alone.
    longest = max([len(g) for g in groups] or [0])
    for i in range(longest):
        for group in groups:
            if i >= len(group):
                continue
            item = group[i]
            if item["image_url"] in by_url:
                known = by_url[item["image_url"]]
                for sighting in sightings_of(item):
                    if sighting not in known["found_by"]:
                        known["found_by"].append(sighting)
                if not known.get("thumbnail_url") and item.get("thumbnail_url"):
                    known["thumbnail_url"] = item["thumbnail_url"]
                use_primary(known)
                continue
            if len(out) >= limit:
                continue
            item = dict(item, found_by=sightings_of(item))
            item["cid"] = "C%02d" % (len(out) + 1)
            by_url[item["image_url"]] = use_primary(item)
            out.append(item)
    return out


def run_search(request, config, folder, fetch=None):
    request = common.check_request(request)
    folder = Path(folder)
    if folder.exists() and any(folder.iterdir()):
        raise common.VisualError("%s is not empty: give a new folder for each run" % folder)
    run = common.Run(folder)
    run.save("run.json", {"schema": common.RUN_SCHEMA, "created": common.now(), "request": request,
                          "config": common.sanitized_config(config), "steps": {}})
    budgets = config["budgets"]
    jobs = {name: request["queries"].get(name, []) for name in PROVIDERS}
    results = {}
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = {name: pool.submit(PROVIDERS[name].search, config, words, budgets["max_candidates"], fetch)
                   for name, words in jobs.items() if words}
        for name, future in futures.items():
            try:
                results[name] = future.result()
            except Exception as exc:  # noqa: BLE001 - a broken adapter is one failed search, not a failed run
                results[name] = ({"provider": name, "status": "error", "error": "%s: %s" % (type(exc).__name__, exc),
                                  "requests": [], "results": 0}, [])
    for name in PROVIDERS:
        if name not in results:
            results[name] = ({"provider": name, "status": "not_asked", "requests": [], "results": 0}, [])
    candidates = merge([results[n][1] for n in PROVIDERS], budgets["max_candidates"])
    records = {n: results[n][0] for n in PROVIDERS}
    good = [n for n, r in records.items() if r["status"] in ("ok", "partial")]
    asked = [n for n, r in records.items() if r["status"] != "not_asked"]
    overall = "failed" if not good else ("ok" if len(good) == len(asked) and all(
        records[n]["status"] == "ok" for n in good) else "partial")
    run.save("search.json", {"schema": "visual-search/1", "overall": overall, "providers": records,
                             "candidates": len(candidates), "transport": "injected" if fetch else "http"})
    run.save_candidates(candidates)
    run.step("search", {"status": overall, "candidates": len(candidates),
                        "providers": {n: r["status"] for n, r in records.items()}})
    return {"status": overall, "candidates": len(candidates), "providers": {n: r["status"] for n, r in records.items()},
            "run": str(folder)}

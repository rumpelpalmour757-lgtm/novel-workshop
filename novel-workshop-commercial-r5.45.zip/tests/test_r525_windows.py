#!/usr/bin/env python3
"""r5.25: what the author's run of r5.24 on Windows found, and the repairs.

The author ran the personal build's 579 tests on Windows (Codex, 2026-10-20): 474 passed, 87 failed, 12 errors,
6 skipped. Nothing was wrong with the delivery gate; the failures came from the tests and one tool:
- 84 review tests wrote their fixtures with Path.write_text, which on Windows stores "\\n" as "\\r\\n", and then
  hashed the LF string: the gate rightly judged every review stale (the hash names the bytes on disk);
- rule_register.py looked for the "<!-- 原文开始 -->" marker with LF only, so a rule file stored with CRLF read as a
  changed version (1 test);
- an installer test searched the JSON report for the raw backup path; JSON escapes a Windows path's backslashes
  (1 test);
- project_state.py needs POSIX flock and refuses on native Windows by design; the package test expected it to work
  (1 failure) and twelve tests built on the three-chapter demo, which keeps its project in it, errored.

The maintainer reproduced the same 84 + 1 + 1 + 12 on Linux with a simulation (text-mode writes store CRLF, fcntl
cannot be imported, a stand-in msvcrt); the installer path cannot be simulated there. These tests pin the repairs:
- the marker is read in text the way the gate reads text: a CRLF or BOM copy of the author's file has the same hash,
  and a changed text is still caught;
- no test writes a fixture through text mode: write_text, or open() for writing without a binary mode (a static scan
  of tests/ and of the project packs' tests in a personal build);
- where project_state.py is unsupported it refuses with its reason and writes nothing (run here with fcntl hidden);
  every test in test_r42 that runs the demo carries the skip marker, and the refusal test runs where it is unsupported.
A real Windows rerun is still needed: paths, drive letters and the real msvcrt are not simulated.
"""
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import textwrap
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
SCRIPTS = SKILL / "scripts"
TESTS = Path(__file__).resolve().parent


def load(name):
    spec = importlib.util.spec_from_file_location("r525_" + name, SCRIPTS / (name + ".py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class RuleMarkerReadsWindowsFiles(unittest.TestCase):
    NOTE = "> 工坊的加注：怎样用这份条例。\n\n"
    BODY = "# 条例\n\n第二版。挎在身上的那只叫“行囊”。\n叙述统一，对话可按人物分层。\n"

    def setUp(self):
        self.tool = load("rule_register")
        self.dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        import shutil
        shutil.rmtree(self.dir)

    def put(self, name, text, crlf=False, bom=False):
        data = (text.replace("\n", "\r\n") if crlf else text).encode("utf-8")
        path = self.dir / name
        path.write_bytes((b"\xef\xbb\xbf" if bom else b"") + data)
        return path

    def test_a_crlf_or_bom_copy_is_the_same_text(self):
        pinned = hashlib.sha256(self.BODY.encode("utf-8")).hexdigest()
        lf = self.put("lf.md", self.NOTE + "<!-- 原文开始 -->\n" + self.BODY)
        crlf = self.put("crlf.md", self.NOTE + "<!-- 原文开始 -->\n" + self.BODY, crlf=True)
        both = self.put("both.md", self.NOTE + "<!-- 原文开始 -->\n" + self.BODY, crlf=True, bom=True)
        for path in (lf, crlf, both):
            self.assertEqual(self.tool.original_sha256(path), pinned, path.name)
        # Without the marker the whole file is the author's text; LF without a mark stays the plain bytes.
        plain = self.put("plain.md", self.BODY)
        self.assertEqual(self.tool.original_sha256(plain), hashlib.sha256(plain.read_bytes()).hexdigest())
        self.assertEqual(self.tool.original_sha256(self.put("plain-crlf.md", self.BODY, crlf=True)), pinned)

    def test_a_changed_text_is_still_a_new_version(self):
        pinned = hashlib.sha256(self.BODY.encode("utf-8")).hexdigest()
        changed = self.put("changed.md", self.NOTE + "<!-- 原文开始 -->\n" + self.BODY.replace("第二版", "第三版"), crlf=True)
        self.assertNotEqual(self.tool.original_sha256(changed), pinned)
        # A file that is not UTF-8 is hashed as its bytes, without an error.
        odd = self.dir / "gbk.md"
        odd.write_bytes("条例".encode("gbk"))
        self.assertEqual(self.tool.original_sha256(odd), hashlib.sha256(odd.read_bytes()).hexdigest())

    def test_the_register_checks_clean_against_a_windows_copy(self):
        # r5.27 (review H525-02): the register here used to be invalid itself ("book" for "project", a source without
        # a title), so the check as a whole was FAIL while this test only looked for "has changed". Now the register is
        # valid and the whole check has to pass, through the function and through the command line (exit 0).
        self.put("rules.md", self.NOTE + "<!-- 原文开始 -->\n" + self.BODY, crlf=True, bom=True)
        register = {"schema": "rule-conflicts/1", "project": "测试", "updated": "2026-10-20",
                    "sources": [{"id": "rules-v2", "file": "rules.md", "title": "补充条例", "version": "第二版",
                                 "date": "2026-10-19", "status": "in_force",
                                 "sha256": hashlib.sha256(self.BODY.encode("utf-8")).hexdigest()}],
                    "texts": {}, "items": []}
        path = self.dir / "rule-conflicts.json"
        path.write_bytes(json.dumps(register, ensure_ascii=False).encode("utf-8"))
        result = self.tool.check(path)
        self.assertEqual((result["status"], result["problems"]), ("OK", []), result)
        self.assertEqual(result["sources"]["stale"], [], result)
        proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPTS / "rule_register.py"), "check", str(path)],
                              capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        self.assertEqual(json.loads(proc.stdout)["status"], "OK")


def test_files():
    files = sorted(TESTS.glob("*.py"))
    packs = SKILL / "assets" / "project-packs"
    if packs.is_dir():  # a personal build carries the private regression tests of its project packs
        files += sorted(packs.glob("*/tests/*.py"))
    return files


def text_mode_writes(path):
    """Calls that would store "\\n" as "\\r\\n" on Windows: write_text, or open() for writing without "b"."""
    found = []
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = node.func.attr if isinstance(node.func, ast.Attribute) else getattr(node.func, "id", None)
        if name == "write_text":
            found.append((node.lineno, "write_text"))
        elif name in ("open", "fdopen"):
            mode = None
            positional = 0 if isinstance(node.func, ast.Attribute) and name == "open" and not (
                isinstance(node.func.value, ast.Name) and node.func.value.id in ("io", "os")) else 1
            if len(node.args) > positional and isinstance(node.args[positional], ast.Constant):
                mode = node.args[positional].value
            for keyword in node.keywords:
                if keyword.arg == "mode" and isinstance(keyword.value, ast.Constant):
                    mode = keyword.value.value
            newline = any(keyword.arg == "newline" for keyword in node.keywords)
            mode_like = isinstance(mode, str) and bool(re.fullmatch(r"[rwxabt+]{1,3}", mode))
            if mode_like and "b" not in mode and any(flag in mode for flag in "wax+") and not newline:
                found.append((node.lineno, "open(%r)" % mode))
    return found


class TestsWriteBytes(unittest.TestCase):
    def test_no_test_writes_a_fixture_in_text_mode(self):
        offenders = ["%s:%d %s" % (path.name, line, what) for path in test_files() for line, what in text_mode_writes(path)]
        self.assertEqual(offenders, [], "write fixtures as UTF-8 bytes: path.write_bytes(text.encode(\"utf-8\"))")

    def test_the_scan_sees_what_it_should(self):
        sample = self.id().replace(".", "_") + ".py"
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / sample
            path.write_bytes(textwrap.dedent('''
                from pathlib import Path
                Path("a").write_text("x\\n", encoding="utf-8")
                with Path("b").open("a", encoding="utf-8") as f: f.write("y")
                with open("c", "w", encoding="utf-8") as f: f.write("z")
                with open("d", "w", encoding="utf-8", newline="\\n") as f: f.write("ok")
                with open("e", "wb") as f: f.write(b"ok")
                with Path("f").open("ab") as f: f.write(b"ok")
                Path("g").write_bytes("ok".encode("utf-8"))
                with open("h", encoding="utf-8") as f: f.read()
            ''').encode("utf-8"))
            self.assertEqual([line for line, _ in text_mode_writes(path)], [3, 4, 5])


def project_state_supported():
    try:
        import fcntl  # noqa: F401
    except ImportError:
        return False
    return os.name == "posix"


# Runs one packaged script in a child where "import fcntl" fails, as on native Windows (no msvcrt stand-in needed).
NO_FCNTL = textwrap.dedent('''
    import runpy, sys
    sys.modules["fcntl"] = None
    script = sys.argv[1]
    sys.argv = [script] + sys.argv[2:]
    runpy.run_path(script, run_name="__main__")
''')


class ProjectStateWhereUnsupported(unittest.TestCase):
    def test_it_refuses_with_its_reason_and_writes_nothing(self):
        with tempfile.TemporaryDirectory() as tmp:
            state = Path(tmp) / "story-state.json"
            proc = subprocess.run([sys.executable, "-I", "-B", "-c", NO_FCNTL, str(SCRIPTS / "project_state.py"), "init",
                                   str(state), "--project-id", "t"], capture_output=True, text=True, encoding="utf-8")
            self.assertNotEqual(proc.returncode, 0)
            self.assertIn("unsupported_platform", proc.stdout + proc.stderr)
            self.assertNotIn("Traceback", proc.stderr)
            self.assertFalse(state.exists())

    def test_every_demo_test_carries_the_skip_marker(self):
        source = (TESTS / "test_r42.py").read_text(encoding="utf-8")
        tree = ast.parse(source)
        unmarked, marked = [], []
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"):
                body = ast.get_source_segment(source, node)
                uses_demo = "self.fixture()" in body or "self.demo.run(" in body
                refusal = "Refusing" in body or "POSIX flock is required" in body
                decorated = any(isinstance(d, ast.Name) and d.id == "NEEDS_PROJECT_STATE" for d in node.decorator_list)
                if uses_demo and not refusal:
                    (marked if decorated else unmarked).append(node.name)
        self.assertEqual(unmarked, [])
        self.assertEqual(len(marked), 12)
        self.assertIn("test_refuses_cleanly_where_project_state_is_unsupported", source)

    def test_the_package_test_checks_the_refusal_where_unsupported(self):
        source = (TESTS / "run_tests.py").read_text(encoding="utf-8")
        part = source.split("def test_existing_tools_still_run", 1)[1].split("\n    def ", 1)[0]
        self.assertIn("if project_state_supported():", part)
        self.assertIn('"unsupported_platform"', part)


class WindowsNotes(unittest.TestCase):
    def test_the_hash_is_taken_from_the_file(self):
        execution = (SKILL / "references" / "execution.md").read_text(encoding="utf-8")
        self.assertIn("照抄 `workflow_guard.py status` 输出里的 `candidate_sha256`", execution)
        self.assertIn("Windows 存文件时换行是 CRLF", execution)
        template = json.loads((SKILL / "assets" / "editorial-review-template.json").read_text(encoding="utf-8"))
        self.assertIn("status 输出里的 candidate_sha256", template["note"])
        usage = (ROOT / "USAGE.md").read_text(encoding="utf-8")
        for phrase in ("在作者的 Windows 电脑上跑过一次全部测试", "还没有在 Windows 上重跑", "照抄 `workflow_guard.py status` 输出里的"):
            self.assertIn(phrase, usage)
        self.assertNotIn("没有在真实的 Windows 电脑上跑过", usage)

    def test_the_marker_note_says_crlf_and_bom_do_not_count(self):
        continuity = (SKILL / "references" / "continuity.md").read_text(encoding="utf-8")
        self.assertIn("CRLF 换行当 LF", continuity)


if __name__ == "__main__":
    unittest.main()

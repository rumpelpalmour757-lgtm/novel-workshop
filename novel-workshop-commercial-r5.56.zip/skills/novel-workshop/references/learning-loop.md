# 学习与自我纠错执行

## 范围与入口

本模块默认关着，作者要求才开，谁开、记在哪见 [SKILL.md](../SKILL.md)“可选模块：默认关着”。作者已启用本模块时，在写作或改稿中执行“选示范、判断适用、交稿、自检或教师反馈、取舍、返工、复查、留经验”。宿主代理实际调用写作者和教师；[执行脚本](../scripts/learning_loop.py)只负责条件保存、版本绑定与下一步提示，不伪装成模型、后台调度器或参数训练。无外部教师配置时使用当前宿主可用模型，注明角色与上下文；不要借用别家模型名称。

保留既有创作模块、作者规则、事实记录及[交付门](execution.md)。此模块不另设定稿门，不改宪法，不自动写回作者定稿，不将简短取舍说明当作可读取的内部思维链。只有正文的请求，过程记录留在项目，不插进小说。

作者已开启[每章七阶段与作者确认](chapter-confirmation.md)时，先服从章节阶段推进：教师审查及反馈整理在已获准的相应阶段执行，下一阶段须等作者确认。学习循环的 `finish/learn` 不代替章节确认或作者定稿。章节确认事件独立于本学习开关，进度同存项目的 `data.chapter_confirmations`，不另立 AUTHOR 状态。

作者采用手动教师交接时，完整初稿先交作者，再等待作者返回教师意见或改稿。原始回传先作为教师材料保存，不自行认定其全部正确或已获作者采纳。工坊核对原稿和回传版本，逐条判采纳/拒绝/暂缓与理由，形成整份修订计划交作者确认；实际修订、复查与示范条件由工坊整理，不要求作者逐条手工标注。原稿、回传、取舍和过程及时保存；可调用示范按实际复查与作者接受证据登记，没有教师对当前最终稿的复查就不伪造该认可。下一章仍先检索、判断条件和例外，再应用。

## 在章节流程里怎么起一轮

走[每章七阶段与作者确认](chapter-confirmation.md)的章节，学习循环记的是“已确认的初稿怎样改成终稿”这一段。

- **什么时候开始。** 作者确认初稿以后再起这一轮；作者把初稿带去给教师的，等教师结果带回、章节门的 `teacher_return` 记完以后再起。写前准备和写初稿的过程不记在这一轮里。
- **输入填什么。** `start` 带上 `chapter_id`，和章节门里用的是同一个章节 ID；`input_text` 填作者已确认的那份初稿全文，`source_ref` 写这份初稿的出处和版本。`plan` 照选中的示范逐条写，没有示范时 `applications` 填 `[]`。`draft` 原样登记同一份初稿。这样登记出来的案例，改前是初稿，改后是终稿，不会把任务说明当成改前。
- **脚本核对什么。** 项目登记了章节策略，或者这一章在章节门里已有记录时，带 `chapter_id` 的 `start` 要求章节门里这一章的初稿已经由作者确认，并且 `input_text` 的哈希等于那份初稿的 `artifact_sha256`；对不上就拒绝，提示先走章节门。带 `chapter_id` 的一轮，`draft` 必须和 `input_text` 一字不差。作者在终稿上又提了意见、要再改一轮的，下一轮可以从上一轮的终稿起，前提是上一轮也是从这份已确认的初稿来的。
- **哈希用哪一个。** 章节门初稿、修订稿、最终三个阶段的 `artifact_sha256`，用 `draft`、`revise` 返回的 `draft_sha256`（事件里 `text` 的 UTF-8 哈希）。按文件算和按事件里的文字算，差一个末尾换行就是两个值；两边对不上时，取舍、作者采纳和补记都会被拒绝。
- **教师结果怎么记。** 作者带回的教师结果用 `review` 记：`role` 填 `teacher`，`mode` 填 `author_return`，可以带上章节门那条回传的 `teacher_return_id`。宿主自己调用的教师填 `independent_agent`，写作者自查填 `self_check`。
- **初稿阶段交过自审单的。** 作者开了[从改稿记录里学编辑判断](editorial-judgment.md)的，这一轮 `draft` 以后先记自审：一条 `review`，`role` 填 `writer`，`mode` 填 `self_check`，绑同一份初稿，记在教师那条 `review` 前面；自审单一处都没标的不记。两条评审都取舍完了才能 `revise`；改后的复查要在 `rechecks` 里把自审那条也列上，不然不能 `finish`。
- **章节重开以后。** 章节门重开了初稿或更早的阶段，绑旧初稿的这一轮用 `stop` 结束，原因写重开；新初稿确认以后另起一轮。初稿由作者交教师的章节里，脚本会拒绝旧一轮上的取舍和改稿；别的情形脚本不拦，也照这样做。
- **不走章节流程的改稿任务**不带 `chapter_id`，这一轮不和章节门核对。

`start` 的返回里有 `chapter_link`，写着这一轮关联的章节 ID；没有关联时是 `not_linked`。

## 取舍由谁定

1. **教师的意见，每一处归谁定照教师审稿页。** 反馈来自教师时，不管是作者带回的还是宿主调用的，分类和谁来定都照[教师回传怎么审](teacher-review.md)第 2 节的表：结构、情节、人物做了什么和知道什么、设定，以及台词里添的话、删的话，只有作者能定；措辞、口气、详略由作者定，工坊拟处置并写看法；错别字、硬性的标点错、明确的语病和有依据的事实，工坊核对后拟处置，作者只点例外。
2. **整份方案作者确认了才改。** 逐项拟处置先写进修订方案交给作者，作者确认以后才记 `decide`、才 `revise`。作者可以整份确认并点出例外，不用逐条签字。
3. **脚本核对到哪一步。** 带 `chapter_id` 起的一轮，而且这一章是初稿由作者交教师（`teacher_handoff:"user_return"`）时，`decide` 和 `revise` 要求章节门的审稿阶段已经由作者确认，并且绑的是这一轮的初稿；对不上就拒绝，`next_action` 是 `await_author_plan_confirmation`，先去走章节门。其余情形脚本不核对，第 1、2 条靠宿主照做，记录里不会替它作证。
4. **作者本人的否定意见不能由工坊驳回。** `role` 为 `author`、`verdict` 不是 `pass` 的评审，每一条问题只能记 `adopt`。不采纳的，必须带作者后来的原话撤回：在那一条取舍里加 `withdrawal:{actor_role:"author",mode:"human",quote,source_ref}`；作者只说了“这版不行”、没有逐条列问题的，把 `withdrawal` 写在 `decide` 事件上。沉默和“继续”一类的话不是撤回，这一点脚本判断不了，由宿主照实记。
5. **作者的否定意见还在，这一稿就不能收尾。** 当前这段文字上还有作者没撤回的否定意见时，`finish` 和 `author_accept` 都被拒绝，`next_action` 是 `ask_author_or_stop`（已有采纳项时是 `revise_or_stop`）。把同一段文字原样再登记一次不算改过，记录里会标 `unchanged`。作者接受以后又提出否定意见的，先前那条接受记录随即作废，原事件仍留在账本里。
6. **作者否定过的稿子改出来的新稿，作者没看过以前不算教师认可。** 作者对某一稿说了不行、又没有撤回，从这一稿改出来的新稿（在这一轮里改的，或者另起一轮从这一稿开始改的），作者还没有对后来的稿子给过通过（`role` 为 `author`、`verdict` 为 `pass` 的评审），也没有采纳这一稿以前，教师或宿主的通过照样可以 `finish`，但 `completion` 记 `author_objection_open`，不记 `teacher_reviewed`；`learn` 只出 `candidate`，案例的 `source.earlier_author_objections` 和事件返回里列着那几条否定意见。改了以后要不要再给作者看，由作者定；作者用 `case_accept` 采纳以后，案例照常进检索。
7. **收尾以后作者才提的否定意见也照实记。** 这一轮已经 `finish`，作者对这一稿又说了不行的，照样用 `review` 记在这一轮上（`role` 为 `author`）。已经收尾的一轮只收这一种评审，以及作者撤回它的原话。记下以后，这一轮登记过的案例不再被检索，`case_accept` 和 `author_accept` 都被拒绝，`next_action` 是 `ask_author_or_stop`。这一轮里不能再改稿；要改这段文字，另起一轮从这一稿开始。作者撤回以后，被那条否定意见作废的采纳不会自己恢复，要作者重新明确采纳，用 `case_accept` 补记。
8. **取舍可以在改稿以前更正。** 记错了，或者作者看过方案改了主意，改稿以前对同一条评审再记一次 `decide`，新的取代旧的，旧的留在这一轮的 `decision_history`。改稿以后那条评审已成历史，不能再改；当时暂缓、后来才定下来的，写进下一条评审的问题里再取舍。归作者定的暂缓项，等作者说了再动。还挂着的暂缓项列在事件返回和 `show` 的 `deferred` 里。
9. **教师说卡住但没有逐条列问题**（`verdict:"blocked"`、`findings` 为空）时，之后的通过评审必须在 `rechecks` 里点名这一条，否则不能 `finish`。

## 唯一记录

已有项目 JSON 权威时使用原文件，仅增改学习命名空间 `data.demonstration_learning`、`data.demonstrations`、`data.learning_runs`、`data.learning_events`，以及章节协作的 `data.chapter_confirmations`、`data.chapter_workflow_policy`；用 `project_state.commit_state` 严格 CAS，不做自动三向合并。人物、设定、章节和其他字段完整保留。

仅有 Markdown 档案的项目，保留其故事权威，在该项目内使用一个由 PROJECT 明确链接的 Markdown 学习记录。它只保存本模块记录，不含人物、设定或章节权威，不初始化空 `story-state.json`。这个块在作者开了示范记忆、学习循环或新章全流程以后才建。唯一数据块使用以下固定标记；块外文字写入时原样保留。模板里两个开关都是 `true`，照作者开了的写：作者没开学习循环的（只开了示范记忆或新章全流程），`loop_enabled` 写 `false`；没开示范记忆的，`enabled` 也写 `false`：

````text
<!-- NOVEL_WORKSHOP_LEARNING_START -->
```json
{"schema_version":1,"project_id":"本书分支","revision":0,"data":{"demonstration_learning":{"enabled":true,"loop_enabled":true,"max_revisions":2},"demonstrations":{},"learning_runs":{},"learning_events":{}}}
```
<!-- NOVEL_WORKSHOP_LEARNING_END -->
````

Markdown 写入需全文 SHA256 条件检查、稳定 POSIX 文件锁和同目录原子替换；冲突时重读，不强制覆盖。读取（`status`、`context`、`show`）和写入走同一把锁，所以 Windows 原生环境没有受支持的锁时，这几个读取命令同样不能用，只有 `demonstration_memory.py` 的 `check`、`index`、`select` 可以直接读；写入使用宿主提供的受保护保存或交付待应用补丁，不降级成无锁覆盖，其余命令在 WSL、macOS 或 Linux 下运行。每次读写会在记录旁边留下一个 `.<记录文件名>.lock` 的空文件，它是锁的一部分，留着不用管，也不要删。记录成功不认证外部来源、评审独立性或文学质量。

**稿件正文在记录里存几份。** 一轮的输入全文存在这一轮的 `input_text`，每一版稿子的全文存在 `drafts`，登记成案例时再各存一份改前和改后。`current_draft` 和事件账本 `learning_events` 只记哈希和字数，不再重复正文；一轮选中的示范按哈希冻结，改前改后只记哈希和字数，正文留在案例里；章节门各阶段展示的内容和教师回传原文同样只在章节记录里存一份。早先版本写下的记录里这些位置还留着全文，照常能读，不用迁移。学习记录和人物设定共用一个 `story-state.json` 时，`project_state.py read` 会把这些稿件一并打印出来；只看进度用 `status`，或者 `show --brief`。

## 每次执行

1. 协调者运行 `status` 读取状态和版本，运行 `context` 取最多三条当前项目、任务和标签相符的认可示范；沿用[示范隔离](demonstration-learning.md)。符合筛选但没排进前三条的案例，编号列在返回的 `not_selected` 里，它们的适用条件和例外用 `demonstration_memory.py index` 看（只给元数据，全部列出），要用哪一条就用 `--case-id` 点名，一次仍不超过三条。脚本只按作品、任务和标签筛选，适用条件和例外不参与筛选，适用不适用由取用的人在下一步逐条判断。匿名评测必须排除当前场景组；写作者仅拿过滤材料，不拿原库路径。
2. `start` 保存本轮实际输入、来源、任务、场景组及不可改动要求；冻结被选案例的版本。`plan` 逐条记录 `apply/adapt/decline`、适用条件检查、例外检查和短理由，并给出本轮核查项。拒绝应用不阻塞写作，没有适用示范时正常执行。章节流程里这一步填什么见上文“在章节流程里怎么起一轮”。
3. 宿主写作者交出真实候选后用 `draft` 记录文字、来源和执行上下文。可原样保留，不要求制造差异。
4. 宿主自检或调用教师，`review` 保存实际判断、问题、证据、范围，绑定本轮 `run_id`、稿件 SHA256 和评审身份。`self_check` 不算独立审稿；独立代理须记录与写作者不同的上下文标识；作者带回的教师结果记 `author_return`。没有真实评审输出就保持待审。
5. 有问题时用 `decide` 逐条记 `adopt/decline/defer` 和理由，谁来定、什么时候才能记，照上文“取舍由谁定”。不得凭教师身份盲从；事实、当前任务及作者锁定内容优先。`revise` 只处理已采纳问题，保存父稿到新稿的关联，并计入返工次数。修改一字也需要对新哈希重新评审；旧反馈不能替代新复查。
6. 新复查明确关联要复查的旧反馈，确认当前稿通过后 `finish`。只有自查时标自查完成；教师复查通过才标教师已审。问题未解、达到本轮返工额度或无法判断时用 `stop` 留下原因，不循环到自评分通过。既有 `workflow_guard` 有更小预算时服从它，本模块次数上限只是附加保护。
7. `learn` 仅从这次真实输入、实际最终稿、取舍和当前稿评审提炼案例。条件、例外、简短依据及来源必填。自查材料保持 `candidate`；教师实际复查通过可记 `teacher_approved`；作者接受必须另记指向当前哈希的原话和出处。一轮的终稿只登记一条案例，案例里记下支撑评审的角色和方式。新案例不因保存而自动变全局规则，也不声称迁移已验证。
8. **作者采纳和登记的先后。** 作者对这一稿的明确采纳先到的，先记 `author_accept` 再 `learn`，案例直接是 `author_accepted`。先登记、作者后来才采纳的，用 `case_accept` 给已有案例补记，带作者原话、出处和案例改后文字的哈希；补记以前案例停在 `candidate` 或 `teacher_approved`，`next_action` 是 `await_author_acceptance`。案例原有的作者采纳已经对不上它的文字的（文字换过，或者被作者后来的否定意见作废），也用 `case_accept` 重新补记，旧的那条留在案例的 `status_history` 里。两个操作都要求 `actor_role:"author"`、`mode:"human"`，原话要明确采纳这一稿：用的是章节门最终采纳的同一个措辞检查，“继续”一类推进用语、否定和含糊的话不记。带 `chapter_id` 的一轮，还要求那一章的最终采纳已经在章节门确认，并且绑的是同一份稿子；对不上就先去走章节门。

正常写作无需向作者逐条提问。作者负责方向、审美校准与抽查；只有当前任务无法自行解决的事实或方向冲突才交作者裁决。教师反馈的取舍不在此列：归作者定的项目和整份修订方案先交作者确认，见上文“取舍由谁定”。教师反馈可以由作者贴入，或由已配置且已授权的模型接口取得；本模块不新增外发服务或费用授权。

## 命令与事件契约

```bash
python3 scripts/learning_loop.py status /项目/学习记录.md
python3 scripts/learning_loop.py context /项目/学习记录.md --project-id 本书分支 --task dialogue_revision --tag 回应 --exclude-group 当前场景
python3 scripts/learning_loop.py apply /项目/学习记录.md /项目/本轮事件.json --project-id 本书分支 --if-version 'status返回的version'
python3 scripts/learning_loop.py show /项目/学习记录.md --run-id 本轮ID --brief
```

`--project-id` 必须和记录里的 `project_id` 一字不差，对不上就拒绝。`show` 不加 `--brief` 会打印这一轮每一版稿子的全文。

事件总有 `event_id`、`op`；涉及任务时有 `run_id`。同 ID 同载荷重试返回 `unchanged`，同 ID 不同载荷拒绝。成功后核对返回状态或 `status`；返回丢失先回读，不能盲目再生成新 ID 重做。具体字段见脚本 `apply --help`；JSON 输入不能执行任意命令。

`learning_events` 保留每个事件的原话、出处、取舍及其载荷哈希，历史接受证据不因当前稿换版而丢失；稿件正文在账本里只留哈希和字数，正文本身在这一轮或章节记录里。稿件除文字哈希外还有登记实例编号；同一文字重新登记也不能直接借用旧实例的评审。`pending_rechecks` 保存累计必须覆盖的旧反馈 ID，是否还有未解复查应看当前实例的通过评审是否覆盖这些 ID，不能仅凭该列表非空判未完成。

替换已完成而目录持久化确认失败时，返回 `saved_durability_uncertain`（退出码 4）和警告。先回读核实，不能声称完全未写入，也不能换新事件 ID 盲目重试；相同事件重试仍按幂等处理。

| 操作 | 最小内容 |
| --- | --- |
| `configure` | `loop_enabled` 布尔值，可选 `max_revisions`（1–5）；可选 `enabled`，打开时带 `actor_role:"author"`、`mode:"human"`、`quote`、`source_ref` |
| `start` | `task`、`tags`、`group_id`、`input_text`、`source_ref`、`constraints`；可选 `case_ids`（点名示范，最多三条）、`chapter_id`（章节流程里的一轮） |
| `plan` | `applications`（每项含 `case_id, decision, reason, conditions_checked, exceptions_checked`）、`checks` |
| `draft` | `text`、`source_ref`、`actor:{name,context_id}` |
| `review` | `review_id`、`draft_sha256`、`reviewer:{name,role,mode,context_id}`、`verdict`、`findings`、`source_ref`；复查加 `rechecks`；作者带回的教师结果可加 `teacher_return_id` |
| `decide` | `review_id`、`decisions`（每项含 `finding_id,decision,reason`）；作者本人的否定意见不采纳时加 `withdrawal` |
| `revise` | `parent_sha256`、`text`、`source_ref`、`actor`、`review_id` |
| `finish` | 当前 `draft_sha256` |
| `stop` | `reason` |
| `author_accept` | 当前 `draft_sha256`、`quote`、`source_ref`、`actor_role:"author"`、`mode:"human"`；只记录接受证据，不改正文 |
| `learn` | `case_id`、`why`、`when`、`except`、`decisions`；可选 `split`（默认 development） |
| `case_accept` | `case_id`、`case_sha256`（案例 `hashes.after`）、`quote`、`source_ref`、`actor_role:"author"`、`mode:"human"`；给已有案例补记作者采纳，原有采纳对不上文字时重新补记 |
| `case_status` | `case_id`、`status`（rejected/retired）、`reason` |

**开关。** 学习循环要两个开关都开着才运行：`enabled` 管这个项目记不记示范，`loop_enabled` 管学习循环。上面 Markdown 数据块的模板里两个都是 `true`，建块时照作者开了的改。已有的 JSON 状态文件里 `enabled` 默认是关的，只把 `loop_enabled` 设成 `true` 不够，`configure` 的返回里会有 `blocked_by`，`status` 会在 `missing_switches` 里写出还差哪一个。打开 `enabled` 是作者的决定：`configure` 带 `enabled:true` 和作者原话、出处；也可以照[示范记忆](demonstration-learning.md)用 `project_state.py` 读出、改好、带版本提交，这样提交的不留作者原话，原话另记在作品档案里。打开 `loop_enabled` 脚本不要原话，开不开同样照作者的要求。

**返工次数。** `max_revisions` 没配置时是 2，一轮开始时定下来，中途调高对正在进行的这一轮不生效。作品档案约定的返修轮数不是 2 的，起这一轮以前先用 `configure` 配成一致；作品档案没定轮数的，工坊默认三轮，起这一轮以前配 `max_revisions:3`；作者中途同意多改一轮时，`stop` 这一轮、调高以后另起一轮，并在停止原因里写明已经用掉几轮。

评审 `role` 是 writer/teacher/author；`mode` 是 self_check/independent_agent/author_return/human；`verdict` 是 pass/revise/blocked。问题含 `id,issue,evidence,scope`。通过不能同时列未解决问题。`findings` 的每一项和 `decide` 的每条取舍可以多带别的键，脚本原样留着、不核对（上面写到的 `withdrawal` 除外）；自审和对账约定的几个键见[从改稿记录里学编辑判断](editorial-judgment.md)“用现有的记录怎么记”。自查 mode 不能用 teacher/author 角色冒充外部认可；`author_return` 只用于作者带回的教师结果；human 记录也只是对真实来源的声明，不是脚本验证了人类身份。`actor_role`、`mode` 和原话同样是宿主照实填写的声明，脚本只检查填没填、措辞是不是明确采纳，认证不了是谁说的。

`conditions_checked` 用“条件原文→是否满足”的布尔映射，`exceptions_checked` 用“例外原文→是否命中”的映射，覆盖所选案例的每条条件和例外；也可用列出已检查原文的字符串数组，分别表示条件满足、例外未命中。条件不满足或例外命中时只能 `decline`。案例冻结后若被退役、换版或补记了作者采纳，不能继续采用旧快照；说明原因并拒用，或停止后重开任务。改稿前须先取舍当前稿的每条问题，复查须覆盖这次修改涉及的全部评审，不能只覆盖其中一条而漏掉其他反馈。

`next_action` 是脚本给的下一步提示：

| 提示 | 意思 |
| --- | --- |
| `plan`、`draft`、`review`、`decide`、`finish`、`learn` | 下一步记这个操作 |
| `revise_or_stop` | 有已采纳的问题：改稿，或说明原因停下 |
| `review_or_stop` | 当前稿还没有可以收尾的通过评审：再评审，或停下 |
| `await_author_plan_confirmation` | 等作者在章节门确认审稿阶段的修订方案 |
| `ask_author_or_stop` | 作者对这一稿的否定意见还在：问作者要具体意见或撤回的原话，或停下；已经收尾的一轮就停在这里，要改另起一轮 |
| `await_author_acceptance` | 案例已登记，等作者明确采纳以后用 `case_accept` 补记（原有采纳已作废的也一样）；作者不采纳就停在这里 |
| `complete` | 这一轮和它的案例都记完了 |
| `resume_original_workflow` | 已停止或未开启，回到原写作流程 |

## 停用与结果回流

`configure loop_enabled:false` 立即停用新循环，恢复原写作入口，保留历史和既有示范；`case_status` 拒绝或退役后示范立即不再检索。回退只撤回本模块的明确改动，不恢复整份旧故事状态。不要用失败试验覆盖原流程，也不要删除不利结果。

功能验证至少覆盖：旧 JSON 兼容、Markdown 非学习文字保留、错误项目/旧版本零写入、事件幂等、例外拒用、反馈与新稿绑定、返工上限、教师与作者状态分离、作者的否定意见不被驳回、停用后正常原流程，以及一次宿主实际执行。写作质量是否改善另作同题对照，不能由功能测试推导。

#!/usr/bin/env python3
"""r5.60: corrections to the pages and templates of the four records (judgment cards, demonstration memory, the
author's correction records, the fact ledger).

The author agreed to parts one, two and four of the checked list for these records. Only pages and templates change:
no gate script changes (fact_guard.py is left as it is), and these corrections change no locked section. One sentence
the author approved for step 2 of the locked section of the author-preferences page went in when r5.60 was closed
(see CorrectionRegister); the steps the registry records are as they were.

What is pinned here:
- the task name in the examples and in the case template is the one the chapter flow stores (`chapter_revision`);
- the keys the scripts write into a case are in the contract table (`event_id`, `run_review_count`, `status_history`,
  `status_reason`);
- "after an example was misapplied": look first, retire after, and what status the narrower case really gets;
- the judgment-card page says the stored shape, explains the three other kinds, and gives one table for recording a
  self-audit item; a revision record is kept in one place;
- the blank register has a place for the cooperation settings and the entry format has a scope line; the locked
  section of that page is word for word what the registry locks;
- commands on the pages carry `scripts/`;
- the two fact templates, filled in together, no longer land in "pending" by themselves; the example of a persistent
  state is an injury, and the page says what a persistent who-knows-what costs;
- a flashback chapter: the states before the main line are kept out of the ledger and one sentence is recorded; the
  program does not check the flashback part, and the page says so;
- the long item on how known_by is compared is a table of four results, with every clause it had;
- the upgrade and rollback details are on QUICKSTART.md only; the page keeps three things the workshop does;
- plain version notes are gone from the four pages and the two fact templates (the one inside the locked section stays).

The behaviour tests run the package's own scripts on newly written neutral text in a temporary folder. They show what
the scripts do today; they do not show that the records help the writing, and nothing here was tried on a real book.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
REFS = SKILL / "references"
ASSETS = SKILL / "assets"
AUTHOR = {"actor_role": "author", "mode": "human"}
PAGES = ("editorial-judgment.md", "demonstration-learning.md", "author-preferences.md", "continuity.md")


def _helpers():
    spec = importlib.util.spec_from_file_location("r560_store_helpers", Path(__file__).with_name("test_r559_learning_loop.py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


H = _helpers()


def page(name):
    return (REFS / name).read_text(encoding="utf-8")


def asset(name):
    return json.loads((ASSETS / name).read_text(encoding="utf-8"))


def put(path, text):
    Path(path).write_bytes(text.encode("utf-8"))


def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def run(script, *args, cwd=None):
    proc = subprocess.run([sys.executable, "-I", "-B", str(SKILL / "scripts" / script), *map(str, args)],
                          capture_output=True, text=True, encoding="utf-8", cwd=cwd)
    return proc.returncode, proc.stdout, proc.stderr


def section(text, heading, level="## "):
    lines, fenced, start = text.split("\n"), False, None
    for i, line in enumerate(lines):
        if line.startswith("```"):
            fenced = not fenced
            continue
        if fenced or not line.startswith("#"):
            continue
        marks = len(line) - len(line.lstrip("#"))
        if start is None and line.startswith(level + heading):
            start = i
        elif start is not None and marks <= len(level) - 1:
            return "\n".join(lines[start:i])
    if start is None:
        raise AssertionError("missing section: " + heading)
    return "\n".join(lines[start:])


def rows(text, indent=""):
    return [[c.strip() for c in line.strip().split("|")[1:-1]] for line in text.splitlines()
            if line.startswith(indent + "| ") and not line.startswith(indent + "| ---")]


def finished_run(rec, run_id, text, teacher):
    rec.op("start", run_id, task="chapter_revision", tags=[run_id], group_id=run_id, input_text="原稿。" + run_id,
           source_ref="合成", constraints=[])
    rec.op("plan", run_id, applications=[], checks=["合成"])
    rec.op("draft", run_id, text=text, source_ref="合成", actor={"name": "合成", "context_id": "w"})
    reviewer = rec.reviewer("teacher", "independent_agent", "t") if teacher else rec.reviewer("writer", "self_check", "w")
    rec.op("review", run_id, review_id="p", draft_sha256=sha(text), reviewer=reviewer, verdict="pass", findings=[],
           source_ref="合成")
    rec.op("finish", run_id, draft_sha256=sha(text))


class TaskName(unittest.TestCase):
    def test_the_examples_and_the_template_use_the_chapter_flow_name(self):
        demo, loop = page("demonstration-learning.md"), page("learning-loop.md")
        commands = [l for l in demo.splitlines() if l.startswith("python3 scripts/demonstration_memory.py ") and "--task" in l]
        self.assertEqual(len(commands), 4)
        for line in commands:
            self.assertIn("--task chapter_revision", line)
        self.assertNotIn("--task dialogue_revision", demo)
        context = next(l for l in loop.splitlines() if l.startswith("python3 scripts/learning_loop.py context "))
        self.assertIn("--task chapter_revision", context)
        self.assertEqual(asset("demonstration-case-template.json")["task"], "chapter_revision")
        # the page still says why: names are compared letter for letter
        self.assertIn("脚本按任务名逐字匹配", loop)
        self.assertIn("# --task 写案例里存的任务名，逐字相同才取得到", demo)

    def test_a_chapter_round_is_found_with_the_name_on_the_page(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = H.new_store(Path(tmp) / "学习记录.md")
            rec = H.Recorder(path, H.load_loop(ROOT))
            finished_run(rec, "R", "终稿。R", teacher=True)
            rec.op("learn", "R", case_id="C", why="合成。", when=["熟客"], decisions=["合成"], **{"except": []})
            found = {}
            for task in ("chapter_revision", "dialogue_revision"):
                code, out, err = run("demonstration_memory.py", "index", path, "--project-id", "book", "--task", task)
                self.assertEqual(code, 0, err)
                found[task] = [c["id"] for c in json.loads(out)["cases"]]
            self.assertEqual(found, {"chapter_revision": ["C"], "dialogue_revision": []})


class KeysTheScriptWrites(unittest.TestCase):
    def setUp(self):
        self.contract = section(page("demonstration-learning.md"), "最小案例契约")

    def test_the_table_names_them(self):
        acceptance = next(l for l in self.contract.splitlines() if l.startswith("| `author_acceptance` |"))
        for phrase in ("`event_id` 指回那条补记事件", "删掉它 `check` 报 `invalid`，案例不再被检索", "`run_review_count`",
                       "这两个键不用手填，整理或迁移案例时不要手工删改"):
            self.assertIn(phrase, acceptance)
        history = next(l for l in self.contract.splitlines() if l.startswith("| `status_history`、`status_reason` |"))
        for phrase in ("脚本写的，不用手填，也不要手工删", "每条是 `{status, replaced_by}`", "理由写进 `status_reason`，不往 `status_history` 里加",
                       "模板是候选占位，不带这两个键", "形状不同，不是这一个"):
            self.assertIn(phrase, history)
        self.assertNotIn("status_history", asset("demonstration-case-template.json"))

    def test_the_script_writes_them_and_needs_the_event_id(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = H.new_store(Path(tmp) / "学习记录.md")
            rec = H.Recorder(path, H.load_loop(ROOT))
            finished_run(rec, "R", "终稿。R", teacher=True)
            rec.op("learn", "R", case_id="C", why="合成。", when=["熟客"], decisions=["合成"], **{"except": []})
            rec.op("case_accept", case_id="C", case_sha256=sha("终稿。R"), quote="采纳当前稿。", source_ref="合成对话", **AUTHOR)
            case = H.payload_of(path)["data"]["demonstrations"]["C"]
            self.assertEqual(sorted(case["author_acceptance"]), ["draft_sha256", "event_id", "quote", "ref", "run_review_count"])
            self.assertEqual([sorted(item) for item in case["status_history"]], [["replaced_by", "status"]])
            self.assertEqual(case["status_history"][0]["status"], "teacher_approved")
            code, out, err = run("demonstration_memory.py", "check", path)
            self.assertEqual((code, json.loads(out)["status"]), (0, "valid"))
            # cut down to the two keys the table used to list: the acceptance no longer counts
            text = path.read_text(encoding="utf-8")
            payload = H.payload_of(path)
            del payload["data"]["demonstrations"]["C"]["author_acceptance"]["event_id"]
            put(path, text[:text.index("```json") + 7] + "\n" + json.dumps(payload, ensure_ascii=False) + "\n"
                + text[text.rindex("```"):])
            code, out, err = run("demonstration_memory.py", "check", path)
            self.assertEqual(code, 2)
            self.assertIn("its run records no author acceptance of this text", out)
            rec.op("case_status", case_id="C", status="retired", reason="合成理由")
            retired = H.payload_of(path)["data"]["demonstrations"]["C"]
            self.assertEqual(retired["status_reason"], "合成理由")
            self.assertEqual(len(retired["status_history"]), 1)


class AfterAnExampleWasMisapplied(unittest.TestCase):
    def test_look_first_retire_after(self):
        after = section(page("demonstration-learning.md"), "写后登记与纠正")
        start = after.index("- **示范被用错以后。**")
        steps = [l for l in after[start:].splitlines()[1:6]]
        self.assertEqual([s[:5] for s in steps], ["  1. ", "  2. ", "  3. ", "  4. ", "  5. "])
        self.assertTrue(steps[1].startswith("  2. 先分清是哪一种：条件和例外本来写着、是取用时漏看了的，案例不动；条件或例外里确实缺了一条的，才收窄。"))
        self.assertTrue(steps[1].endswith("不因为一次用错就自动退役。"))
        self.assertTrue(steps[2].startswith("  3. 要收窄的，先用 `case_status` 退役"))
        self.assertIn("那一轮有教师通过的，新案例是教师认可，照样进检索；那一轮只有自查的，新案例停在候选。", steps[4])
        self.assertIn("这两种都等作者对新案例说了话，再用 `case_accept` 补记。", steps[4])

    def test_the_narrower_case_after_a_teacher_passed_round_is_teacher_approved(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = H.new_store(Path(tmp) / "学习记录.md")
            rec = H.Recorder(path, H.load_loop(ROOT))
            for run_id, teacher in (("with-teacher", True), ("self-only", False)):
                text = "终稿。" + run_id
                finished_run(rec, run_id, text, teacher)
                rec.op("learn", run_id, case_id=run_id + "-1", why="合成。", when=["熟客"], decisions=["合成"], **{"except": []})
                rec.op("case_accept", case_id=run_id + "-1", case_sha256=sha(text), quote="采纳当前稿。", source_ref="合成对话",
                       **AUTHOR)
                rec.op("case_status", case_id=run_id + "-1", status="retired", reason="作者在后一章说别照搬")
                rec.op("learn", run_id, case_id=run_id + "-2", why="合成。", when=["熟客", "对方提过自己几点要用"],
                       decisions=["合成"], **{"except": []})
            cases = H.payload_of(path)["data"]["demonstrations"]
            self.assertEqual({key: case["status"] for key, case in cases.items()},
                             {"with-teacher-1": "retired", "with-teacher-2": "teacher_approved",
                              "self-only-1": "retired", "self-only-2": "candidate"})
            self.assertIsNone(cases["with-teacher-2"]["author_acceptance"])
            code, out, err = run("demonstration_memory.py", "index", path, "--project-id", "book", "--task", "chapter_revision")
            self.assertEqual([c["id"] for c in json.loads(out)["cases"]], ["with-teacher-2"])


class JudgmentCardFile(unittest.TestCase):
    def setUp(self):
        self.text = page("editorial-judgment.md")
        self.template = asset("editorial-judgment-template.json")

    def test_the_page_says_the_stored_shape(self):
        where = section(self.text, "谁来开、记在哪")
        for phrase in ("模板顶层就是这份文件存档的样子", "都按编号放，键就是那一条自己的 `id`",
                       "模板里的 `note`、`values` 和 `self_audit` 是给填的人看的", "不是存档的内容，建档时可以删掉",
                       "它和 `final.status`（落稿那一版是作者定稿、候选还是待定）是两回事",
                       "- **自审单放在哪**：每一章的自审单另存一份文件，放在判断卡文件旁边。",
                       "它是给作者看的单子（Markdown），栏目和分段照下文“交教师以前的自审”，不是一组 `finding`",
                       "学习记录里只存它的哈希和自审那条评审"):
            self.assertIn(phrase, where)
        self.assertNotIn("内容是一组照模板 `self_audit` 的 `finding` 填的项", self.text)
        self.assertEqual(list(self.template)[3:5], ["cases", "cards"])

    def test_the_other_three_kinds_are_explained(self):
        case = section(self.text, "一条改稿案例记什么")
        for phrase in ("`adopted_change`（提的改法作者采纳了，全部或一部分）", "`rejected_change`（作者拒绝了）",
                       "`undecided`（作者说了暂缓，或者看了还没定）"):
            self.assertIn(phrase, case)
        self.assertEqual(self.template["values"]["revision.kind"][3:], ["adopted_change", "rejected_change", "undecided"])

    def test_one_table_for_recording_a_self_audit_item(self):
        records = section(self.text, "用现有的记录怎么记")
        ledger = rows(section(self.text, "命中账"))
        outcome = [r for r in ledger if len(r) == 4][1:9]                       # the first eight rows of the ledger table
        table = [r for r in rows(records, "  ") if len(r) == 6]
        self.assertEqual(table[0], ["自审的拟处置", "教师", "作者最后", "`decision`", "`ledger`", "`matched`"])
        self.assertEqual([r[:3] for r in table[1:]], [r[:3] for r in outcome])
        words = {"对上": "`agreed`", "对不上": "`disagreed`", "没人动": "`untouched`"}
        self.assertEqual([r[4] for r in table[1:]], [words[r[3]] for r in outcome])
        moved = {"采纳了改动", "自己改了", "采纳了（教师的、工坊的，或者自己另写）", "看了说要改"}
        for r in table[1:]:
            self.assertEqual(r[3], "`adopt`" if r[2] in moved else "`decline`", r)
            self.assertEqual(r[5], "`null`" if r[1] == "没动" else "教师那条意见的编号", r)
        for phrase in ("对拟保留的项，`decline` 说的是这一处最后没动，和自审的看法一致，不是不认这一项",
                       "作者还没定的记 `defer`；定了以后的结果，照上面说的记进判断卡文件的命中账。",
                       "只表示单子上有标出来的项，拟保留的也算，不表示要改稿",
                       "单子上标出来的每一处是一条问题（拟保留的也算；写“没有”的行不是）",
                       "自审单文件的哈希照上面“自审单封口”写进初稿阶段展示的 `content`"):
            self.assertIn(phrase, records)

    def test_a_sheet_with_kept_items_only_is_recorded_as_revise(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = H.new_store(Path(tmp) / "学习记录.md")
            rec = H.Recorder(path, H.load_loop(ROOT))
            text = "掌柜把算盘推到一边。“先记着。”"
            rec.op("start", "R", task="chapter_revision", tags=[], group_id="g", input_text=text, source_ref="合成", constraints=[])
            rec.op("plan", "R", applications=[], checks=["自审"])
            rec.op("draft", "R", text=text, source_ref="合成", actor={"name": "合成", "context_id": "w"})
            kept = dict(self.template["self_audit"]["finding"], id="a1", issue="合成自审项", evidence="“先记着。”", scope="第 1 行",
                        disposition="keep")
            review = dict(review_id="audit", draft_sha256=sha(text), reviewer=rec.reviewer("writer", "self_check", "w"),
                          findings=[kept], source_ref="合成")
            self.assertEqual(rec.refused("review", "R", verdict="pass", **review).code, "invalid_event")
            self.assertEqual(rec.op("review", "R", verdict="revise", **review)["status"], "saved")

    def test_the_revision_record_is_kept_in_one_place(self):
        records = section(self.text, "用现有的记录怎么记")
        for phrase in ("改稿案例只放判断卡文件这一份，以这一份为准", "手工建档的示范案例也不嵌整段，只在 `revision` 里写改稿案例的编号",
                       "`select` 会把嵌着的整段（提过的改法、作者的原话）一起交给写作者"):
            self.assertIn(phrase, records)
        self.assertNotIn("手工建档的示范案例可以直接带 `revision` 段", self.text)
        row = next(l for l in page("demonstration-learning.md").splitlines() if l.startswith("| `revision`"))
        for phrase in ("只放判断卡文件那一份，以那一份为准", "`{\"case_ids\": [\"改稿案例的编号\"]}`", "没有这一段的案例照常有效",
                       "编号只记在判断卡文件那一头"):
            self.assertIn(phrase, row)
        self.assertIn("示范案例那边只留编号，不嵌整段", self.template["note"])

    def test_a_case_that_only_points_passes_and_hands_over_no_record(self):
        case = asset("demonstration-case-template.json")
        text = "掌柜把算盘推到一边。“先记着。”"
        case.update(id="c1", project_id="book", group_id="g1", before=text, after=text, status="teacher_approved",
                    revision={"case_ids": ["rc-1"]})
        case["source"].update(reviewer="合成教师", reviewer_role="teacher", reviewer_mode="human", evidence="合成")
        case["hashes"] = {"before": sha(text), "after": sha(text)}
        with tempfile.TemporaryDirectory() as tmp:
            state = Path(tmp) / "state.json"
            put(state, json.dumps({"schema_version": 1, "project_id": "book", "revision": 0, "data": {
                "demonstration_learning": {"enabled": True}, "demonstrations": {"c1": case}}}, ensure_ascii=False))
            code, out, err = run("demonstration_memory.py", "check", state)
            self.assertEqual((code, json.loads(out)["status"]), (0, "valid"), out + err)
            code, out, err = run("demonstration_memory.py", "select", state, "--project-id", "book", "--task", "chapter_revision")
            self.assertEqual(json.loads(out)["cases"][0]["revision"], {"case_ids": ["rc-1"]})


class CorrectionRegister(unittest.TestCase):
    def setUp(self):
        self.text = page("author-preferences.md")
        self.blank = section(self.text, "开启时建的两份文件", "### ")

    def test_the_blank_register_has_the_two_things(self):
        self.assertLess(self.blank.index("## 协作策略\n\n（还没有条目）"), self.blank.index("## 已确认"))
        self.assertIn("“协作策略”下面记作者说过的跨作品协作策略（新章全流程开没开、两项策略、交教师的默认设置），每条带作者原话和日期。", self.blank)
        self.assertIn("以前建的这一份没有这个小标题的，第一次要记时加上，不用重建。", self.blank)
        self.assertIn("### 编号\n问题与原则：\n适用范围：作品／题材／流程／跨作品\n触发条件：\n", self.blank)

    def test_the_locked_section_is_word_for_word_what_the_registry_locks(self):
        registry = asset("constitution-rules.json")
        entry = next(e for e in registry["protected_sections"] if e["file"].endswith("author-preferences.md"))
        locked = section(self.text, entry["section"], "### ")
        lines = locked.split("\n")
        steps = [l for l in lines if l.startswith(("1. **取证。**", "3. **进入有效摘要。**"))]
        self.assertEqual(len(steps), 2)
        self.assertEqual(sha("".join(line + "\n" for line in steps)), entry["sha256"])  # each with its line break
        numbers = [int(n) for n in entry["r5.59_lines"].split(", ")]
        self.assertEqual([self.text.split("\n")[n - 1] for n in numbers], steps)  # still on the recorded lines
        # the list of fields in the locked section is as it was: the scope line was added to the blank format only
        self.assertIn("每条有效摘要至少包含：编号、问题与原则、触发条件、例外或不适用范围、来源证据编号、确认依据和日期、状态、替代关系。", locked)
        # the whole section, heading to last line (what darwin_eval compares). r5.60: step 2 gained one sentence (in a
        # book with judgment cards, a single-place change the author did not make a standing one is kept as a revision
        # case of this book first); the author approved the whole sentence on 2026-11-26, and the approval is on record
        # in the maintenance notes, outside the package. The section was a52e4b10... in r5.59; steps 1 and 3, which
        # the registry records, are checked above and did not change.
        self.assertEqual(sha(locked.rstrip()), "50869a0ca162c548a058e902d29bba12e45d83eed1236e7bbc8d1f6413a78302")


class CommandsCarryTheFolder(unittest.TestCase):
    def test_no_script_is_called_without_scripts(self):
        bare = {}
        for path in sorted(REFS.glob("*.md")):
            hits = re.findall(r"python3? (?!scripts/)[A-Za-z_]+\.py", path.read_text(encoding="utf-8"))
            if hits:
                bare[path.name] = hits
        self.assertEqual(bare, {})
        execution = page("execution.md")
        self.assertEqual(execution.count("python3 scripts/workflow_guard.py "), 17)
        self.assertIn("在技能根目录使用下列命令；不在技能根目录运行的，把 `scripts/workflow_guard.py` 换成实际脚本路径：", execution)
        self.assertIn("`python3 scripts/rule_register.py check rule-conflicts.json --texts-root <正文所在目录>`", page("continuity.md"))
        code, out, err = run("rule_register.py", "--help")
        self.assertEqual(code, 0, err)


class FactTemplates(unittest.TestCase):
    def build(self, tmp, claims_extra=(), story_time=None):
        tmp = Path(tmp)
        (tmp / "正文").mkdir()
        put((tmp / "正文" / "第01章.md"), "第一章\n示例物件放在柜台上。\n某人物还不知道这件事。\n示例人物左手骨裂。\n")
        put(tmp / "正文" / "第02章-候选.md", "第二章\n下午，示例物件换了人拿。\n某人物仍旧不知道。\n示例人物用右手接过去。\n")
        ledger = asset("fact-ledger-template.json")
        ledger["chapters"]["1"]["sha256"] = hashlib.sha256((tmp / "正文" / "第01章.md").read_bytes()).hexdigest()
        claims = asset("fact-claims-template.json")
        claims["candidate_sha256"] = hashlib.sha256((tmp / "正文" / "第02章-候选.md").read_bytes()).hexdigest()
        claims["claims"][0]["quote"] = "示例物件换了人拿"
        claims["claims"] += list(claims_extra)
        if story_time:
            claims["story_time"] = story_time
        put((tmp / "facts.json"), json.dumps(ledger, ensure_ascii=False))
        put((tmp / "claims.json"), json.dumps(claims, ensure_ascii=False))
        code, out, err = run("fact_guard.py", "check", "facts.json", "claims.json", "--chapters-dir", "正文", cwd=str(tmp))
        return code, json.loads(out)

    KNOW = {"id": "C-02-02", "entity": "item:example", "attribute": "known_by.某人物", "value": False,
            "basis": "text_statement", "quote": "某人物仍旧不知道"}

    def test_filled_in_together_they_do_not_land_in_pending(self):
        with tempfile.TemporaryDirectory() as tmp:
            code, report = self.build(tmp, [self.KNOW])
            self.assertEqual(code, 0)
            self.assertEqual({r["claim"]: r["status"] for r in report["results"]},
                             {"C-02-01": "CHANGE_PROPOSED", "C-02-02": "CONSISTENT"})
        # what the note warns about: a whole day against a time on that day cannot be put in order
        with tempfile.TemporaryDirectory() as tmp:
            code, report = self.build(tmp, [self.KNOW], story_time="D1")
            self.assertEqual({r["claim"]: r["status"] for r in report["results"]}["C-02-02"], "KNOWLEDGE_PENDING")
        note = asset("fact-claims-template.json")["note"]
        self.assertIn("只写 D1 是第一天一整天，会和账本里第一天上午的事实重叠，知情的主张排不出先后，判待核", note)
        self.assertEqual(asset("fact-claims-template.json")["story_time"], {"from": "D1 13:00", "to": "D1 18:00"})

    def test_the_persistent_example_is_an_injury(self):
        ledger = asset("fact-ledger-template.json")
        marked = [f["attribute"] for f in ledger["facts"] if f.get("persist")]
        self.assertEqual(marked, ["injury.左手"])
        self.assertIn("下面的示例标在伤势上", ledger["note"])
        self.assertIn("只在这个人不知情是后面几场戏成立的前提时才标", ledger["note"])
        with tempfile.TemporaryDirectory() as tmp:
            code, report = self.build(tmp)
            self.assertEqual([w["attribute"] for w in report["watch"]], ["injury.左手"])

    def test_the_page_says_what_a_persistent_who_knows_what_costs(self):
        states = section(page("continuity.md"), "持续状态")
        for phrase in ("“谁知道某件事”标 `persist` 以前，先看这几样代价（都是程序现在的做法）：",
                       "正文一提到这样东西就弹一条要裁决的复核项，那个人物没出场也弹",
                       "别的词里带着它也算提到（别名“信”，“相信”也命中）",
                       "提了别的主张（比如谁拿着它）不算，提示照弹",
                       "后来再记一条不带 `persist` 的知情事实（比如他已经知道了），提示也不停",
                       "所以“谁知道”只在这个人不知情是后面几场戏成立的前提时才标 `persist`"):
            self.assertIn(phrase, states)

    def test_the_costs_are_what_the_script_does(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            put((tmp / "ch1.md"), "甲不知道密信的事。\n")
            put((tmp / "ch2.md"), "甲看了密信。\n")
            put((tmp / "ch3.md"), "丙说她相信明天会下雨。\n")
            digest = lambda name: hashlib.sha256((tmp / name).read_bytes()).hexdigest()
            fact = {"entity": "item:letter", "attribute": "known_by.甲", "layer": "accepted", "basis": "text_statement"}
            ledger = {"schema": "fact-ledger/1", "entities": {"item:letter": {"name": "密信", "aliases": ["密信", "信"]}},
                      "chapters": {"1": {"status": "accepted", "file": "ch1.md", "sha256": digest("ch1.md")},
                                   "2": {"status": "accepted", "file": "ch2.md", "sha256": digest("ch2.md")}},
                      "facts": [dict(fact, id="F1", value=False, chapter=1, persist=True, source="第1章"),
                                dict(fact, id="F2", value=True, chapter=2, change=True, basis="witnessed_action", source="第2章")]}
            claims = {"schema": "fact-claims/1", "chapter": 3, "candidate": "ch3.md", "candidate_sha256": digest("ch3.md"),
                      "extracted_by": "self_check", "claims": []}
            put((tmp / "facts.json"), json.dumps(ledger, ensure_ascii=False))
            put((tmp / "claims.json"), json.dumps(claims, ensure_ascii=False))
            code, out, err = run("fact_guard.py", "check", "facts.json", "claims.json", cwd=str(tmp))
            # the person is absent, the later fact carries no persist, and the only hit is inside another word
            self.assertEqual([w["id"] for w in json.loads(out)["watch"]], ["W-F2"], out + err)


class FlashbackChapter(unittest.TestCase):
    def test_the_page_says_how_to_record_it_and_that_the_program_does_not_check_it(self):
        text = page("continuity.md")
        item = text[text.index("- 按故事时间核的只有知情。"):text.index("\n事实标成 `accepted`")]
        self.assertNotIn("这一版只改了知情", text)
        for phrase in ("给它们写 `time` 程序也不看，倒叙里的同类问题还查不出来。倒叙章先这样记：",
                       "1. 倒叙部分里早于主线的持有、伤势、地点，不入主线的账：不提成这一章的主张；这一章采纳以后，也不写成这一章的事实，"
                       "不为了过检查标 `change: true`。",
                       "2. 在那一章记一句“倒叙，早于第几章，主线状态没变”",
                       "加一栏 `note`，程序不读这一栏",
                       "3. 冲突照这一句人工裁定。",
                       "已经提了主张、报了冲突的，不改正文，把倒叙部分那几条主张拿掉重跑，裁定照样写这一句",
                       "4. 程序这时候不核倒叙部分。",
                       "没读的，照实写没核",
                       "事实核对这一项是 `UNTESTED`（没比），照实这样记，不写成通过",
                       "5. 倒叙里人物知不知道某件事不在此列，照上面按故事时间核。"):
            self.assertIn(phrase, item)
        for name in ("fact-ledger-template.json", "fact-claims-template.json"):
            self.assertIn("倒叙，早于第几章，主线状态没变", asset(name)["note"])

    def test_what_the_program_does_with_a_flashback_chapter(self):
        """Chapter 7: the hand is broken and the box changes hands. Chapter 8 goes back to before both. Recorded as
        the page says (no claims for those states, one sentence on the chapter), the main line stays right in chapter 9;
        recorded as changes, chapter 9 is reported as a conflict although it is right."""
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            texts = {"ch6.md": "甲把铜匣抱在怀里。\n主角两条胳膊甩得很开。\n", "ch7.md": "主角左手骨裂，吊着绷带。\n甲把铜匣交给乙。\n",
                     "ch8.md": "五年前。\n那时铜匣还在甲手里。\n主角两只手都好好的。\n", "ch9.md": "乙把铜匣从包袱里拿出来。\n主角左手还吊着。\n"}
            for name, text in texts.items():
                put((tmp / name), text)
            digest = lambda name: hashlib.sha256((tmp / name).read_bytes()).hexdigest()
            base = {"layer": "accepted", "basis": "witnessed_action"}
            facts = [dict(base, id="F-06-01", entity="item:box", attribute="holder", value="甲", chapter=6, source="第6章"),
                     dict(base, id="F-06-02", entity="person:hero", attribute="injury.左手", value="完好", chapter=6, source="第6章"),
                     dict(base, id="F-07-01", entity="person:hero", attribute="injury.左手", value="骨裂", chapter=7, change=True,
                          persist=True, source="第7章"),
                     dict(base, id="F-07-02", entity="item:box", attribute="holder", value="乙", chapter=7, change=True, source="第7章")]
            chapters = {n: {"status": "accepted", "file": "ch%s.md" % n, "sha256": digest("ch%s.md" % n)} for n in ("6", "7")}
            entities = {"person:hero": {"name": "主角"}, "item:box": {"name": "铜匣"}}

            def check(ledger_facts, ledger_chapters, chapter, items):
                ledger = {"schema": "fact-ledger/1", "entities": entities, "chapters": ledger_chapters, "facts": ledger_facts}
                claims = {"schema": "fact-claims/1", "chapter": chapter, "candidate": "ch%d.md" % chapter,
                          "candidate_sha256": digest("ch%d.md" % chapter), "extracted_by": "self_check", "claims": items}
                put((tmp / "facts.json"), json.dumps(ledger, ensure_ascii=False))
                put((tmp / "claims.json"), json.dumps(claims, ensure_ascii=False))
                code, out, err = run("fact_guard.py", "check", "facts.json", "claims.json", "--chapters-dir", ".", cwd=str(tmp))
                return code, json.loads(out)

            box8 = {"id": "C-08-01", "entity": "item:box", "attribute": "holder", "value": "甲", "basis": "witnessed_action",
                    "quote": "那时铜匣还在甲手里", "time": "D0 10:00"}
            arm8 = {"id": "C-08-02", "entity": "person:hero", "attribute": "injury.左手", "value": "完好",
                    "basis": "witnessed_action", "quote": "主角两只手都好好的", "time": "D0 10:00"}
            box9 = {"id": "C-09-01", "entity": "item:box", "attribute": "holder", "value": "乙", "basis": "witnessed_action",
                    "quote": "乙把铜匣从包袱里拿出来"}
            arm9 = {"id": "C-09-02", "entity": "person:hero", "attribute": "injury.左手", "value": "骨裂", "basis": "text_statement",
                    "quote": "主角左手还吊着"}
            # claimed as they stand: two conflicts, although nothing is wrong (a time on them is not looked at)
            code, report = check(facts, chapters, 8, [box8, arm8])
            self.assertEqual((code, [r["status"] for r in report["results"]]), (1, ["CONFLICT", "CONFLICT"]))
            # as the page says: no claims for those states; the persistent injury is listed for a ruling, nothing is compared
            code, report = check(facts, chapters, 8, [])
            self.assertEqual((code, report["status"], [w["id"] for w in report["watch"]]), (0, "UNTESTED", ["W-F-07-01"]))
            # chapter 8 accepted with one sentence on it and no facts for those states: chapter 9 on the main line is consistent
            noted = dict(chapters, **{"8": {"status": "accepted", "file": "ch8.md", "sha256": digest("ch8.md"),
                                           "story_time": "D0", "note": "倒叙，早于第 7 章，主线状态没变"}})
            code, report = check(facts, noted, 9, [box9, arm9])
            self.assertEqual((code, [r["status"] for r in report["results"]]), (0, ["CONSISTENT", "CONSISTENT"]))
            # entered as changes instead: chapter 9, which is right, is reported as two conflicts
            entered = facts + [dict(base, id="F-08-01", entity="item:box", attribute="holder", value="甲", chapter=8, change=True,
                                    source="第8章"),
                               dict(base, id="F-08-02", entity="person:hero", attribute="injury.左手", value="完好", chapter=8,
                                    change=True, source="第8章")]
            code, report = check(entered, noted, 9, [box9, arm9])
            self.assertEqual((code, [r["status"] for r in report["results"]]), (1, ["CONFLICT", "CONFLICT"]))


class KnownByTable(unittest.TestCase):
    def test_four_results_and_every_clause_it_had(self):
        text = page("continuity.md")
        start = text.index("- `check` 怎样比 `known_by.人物`：")
        item = text[start:text.index("\n- 同一章里：", start)]
        table = [r for r in rows(item, "  ") if len(r) == 3]
        self.assertEqual(table[0], ["结果", "什么时候", "怎么办"])
        self.assertEqual([r[0] for r in table[1:]], ["冲突", "一致", "待核（`KNOWLEDGE_PENDING`）", "账本问题（`UNEXPLAINED_CHANGE`）"])
        for phrase in ("证据仍只用当前章之前、已采纳、来源有效的事实；再按故事时间挑出这一场之前已经生效的那一条来比。",
                       "按写下的时间试所有排得出的先后（值只在写了变化的地方变；“这才知道”表示那之前还不知道，除非是同一刻讲了两遍；变成“未知”的不算变化）",
                       "结论和账本、主张的书写顺序无关。", "怎么排都对不上", "这一场又早于它，判 `TIME_CONFLICT`",
                       "连写两次“忘了”，或者“还不知道”之后又写“忘了”", "两种读法都对不上才判冲突",
                       "要改这一场，或者写出更早的获知、请作者改那一章",
                       "有一种排法对得上，并且它依据的那条事实到这一场之间，排不进任何一次变成别的值的变化",
                       "这一场之后才生效的证据，不能支持“一致”",
                       "只知道章节先后；一边写了第几天、一边没写，或时间只写钟点、第几天不明；两段时间重叠，或同一时刻讲了两遍、分不清是不是同一次；"
                       "这一场之前生效的几条谁在后排不出来、值又不同；证据只有晚于这一场的。",
                       "有一种排法对得上、又够不上一致的", "只有那次没记下的变化讲得通的", "事实太多、排序算不完的",
                       "补写或改准 `time`、`story_time` 后可以重跑；证据只有晚于这一场的，补了时间也还是待核，要编辑按正文判断。",
                       "最好请作者在账本里补上那次变化",
                       "怎么排先后都有一处值变了却没写变化（例如同一时刻写了知道又写不知道）",
                       "要让倒叙里更早的一场写他已经知道被报成冲突，账上要记得知的那一刻（`change: true`），或者记那之前他还不知道（值 `false`，写 `time`）；"
                       "都没有，只能判待核。",
                       "- 账本自查的事实链（`status`，以及 `check` 用的基线）对知情也按故事时间排：",
                       "不算没标的改动；没写时间的事实仍按章节先后看。"):
            self.assertIn(phrase, item)
        self.assertLess(max(len(line) for line in item.splitlines()), 520)


class UpgradeDetailsLiveOnTheQuickstart(unittest.TestCase):
    def test_the_page_keeps_three_things_and_a_pointer(self):
        part = section(page("author-preferences.md"), "升级、退回、换包和导出", "### ")
        items = [l for l in part.splitlines() if l.startswith("- ")]
        self.assertEqual(len(items), 3)
        for phrase in ("写在包根目录的 `QUICKSTART.md`“可选：使用本地安装脚本”，这一页不重复。工坊照做的三条：",
                       "把两份摆给作者看，照作者定的合，合完照“从一次纠错提炼规则”第 5 步保存、回读。",
                       "升级成功以后以技能目录里的这份为准，备份里那份只是升级那一刻的快照。",
                       "换账户、换环境时，不把不带记录的包说成含作者记忆。"):
            self.assertIn(phrase, part)
        for gone in ("--keep", "novel-workshop-backups", "Existing skill differs", "--include-projects", "--dry-run"):
            self.assertNotIn(gone, part)
        self.assertIn("## 可选：使用本地安装脚本", (ROOT / "QUICKSTART.md").read_text(encoding="utf-8"))
        # what the workshop does when it finds a record kept where r5.55 said stays on the page, all five steps
        back = section(page("author-preferences.md"), "从 r5.55 的位置挪回", "### ")
        self.assertEqual([l[:3] for l in back.splitlines() if re.match(r"\d\. ", l)], ["1. ", "2. ", "3. ", "4. ", "5. "])


class PlainVersionNotes(unittest.TestCase):
    NOTE = re.compile(r"（r5\.\d+）|；r5\.\d+）")

    def test_gone_from_the_four_pages_except_the_locked_one(self):
        left = {name: self.NOTE.findall(page(name)) for name in PAGES}
        self.assertEqual(left, {"editorial-judgment.md": [], "demonstration-learning.md": [], "author-preferences.md": ["（r5.59）"],
                                "continuity.md": []})
        locked = section(page("author-preferences.md"), "从一次纠错提炼规则", "### ")
        self.assertEqual(self.NOTE.findall(locked), ["（r5.59）"])

    def test_gone_from_the_two_fact_templates(self):
        for name in ("fact-ledger-template.json", "fact-claims-template.json"):
            self.assertIsNone(re.search(r"r5\.\d+", asset(name)["note"]), name)

    def test_what_tells_older_releases_apart_stays(self):
        self.assertIn("r5.24 及以前记的摘要是按字节算的", page("continuity.md"))
        self.assertIn("### 从 r5.55 的位置挪回", page("author-preferences.md"))


if __name__ == "__main__":
    unittest.main()

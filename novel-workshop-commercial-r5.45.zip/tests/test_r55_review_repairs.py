#!/usr/bin/env python3
"""r5.5: repairs for the 2026-10-17 review of the r5.4 candidate (the rest of finding N04).

The speaker line and the words are separated by a blank line ("陈青低声说：", blank line, "“知道了！”"), the same words
are said by three people, the paragraphs move and two people's marks change. r5.4 reported nothing and the strict gate
passed with nothing to decide, in two layouts: blank lines everywhere, and blank lines only after the speaker line
(the words then sit directly above the next speaker's line). In the second layout a pure move was even reported as two
certain changes.

What was wrong, and the rules now:
- A line that ends with a colon introduces what follows it. It names the speaker of the words below it, across blank
  lines too, and never of the words above it: there it is the next speaker's line.
- The line below the words alone names nobody (it can be the next speaker's "孟迟点了点头。" just as well as the
  speaker's "陈青低声说。"); words nobody is named for are told apart by where they stand, never by position alone.
- A replaced line counts as "rewritten in place" only when nothing else explains it. A speaker line that stands
  elsewhere in the other version moved; the line now in its slot is somebody else's.
- Marks that read the same in order prove nothing, and a run of repeated lines that lines up one paragraph off is not
  "in place": only lines fenced in by lines that occur once are.
- What the program still cannot tell apart is flagged as uncertain, never passed as unchanged.
All material is invented for these tests; reviews are labelled test data.
"""

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SCRIPTS = ROOT / "skills" / "novel-workshop" / "scripts"
DIMENSIONS = ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function", "continuity",
              "revision_comparison")


def whole_text(text):
    """r5.11: a strict-mode PASS needs the expression record. These short test texts are read as one segment; the
    record is test data that only lets the gate get to what this file tests."""
    body = text.strip()
    begin = next(body[:k] for k in range(4, len(body) + 1) if len("".join(body[:k].split())) >= 4)
    end = next(body[-k:] for k in range(4, len(body) + 1)
               if len("".join(body[-k:].split())) >= 4 and body.count(body[-k:]) == 1)
    return {"scope": "chapter", "decisions": [],
            "segments": [{"from": begin, "to": end, "note": "测试数据：只验证结构，全文连读过"}]}


# The review's two layouts, word for word: 陈青 and 卢石 trade places and marks, 孟迟 stays as he was.
SEPARATED = "陈青低声说：\n\n“知道了！”\n\n孟迟低声说：\n\n“知道了！”\n\n卢石低声说：\n\n“知道了。”\n\n"
SEPARATED_MOVED = "卢石低声说：\n\n“知道了。”\n\n孟迟低声说：\n\n“知道了！”\n\n陈青低声说：\n\n“知道了！”\n\n"
SEPARATED_CHANGED = "卢石低声说：\n\n“知道了！”\n\n孟迟低声说：\n\n“知道了！”\n\n陈青低声说：\n\n“知道了。”\n\n"
# Blank line only after the speaker line: each speech sits directly above the next speaker's line. 卢石 and 孟迟 swap.
MIXED = "陈青低声说：\n\n“知道了！”\n孟迟低声说：\n\n“知道了！”\n卢石低声说：\n\n“知道了。”\n"
MIXED_MOVED = "陈青低声说：\n\n“知道了！”\n卢石低声说：\n\n“知道了。”\n孟迟低声说：\n\n“知道了！”\n"
MIXED_CHANGED = "陈青低声说：\n\n“知道了！”\n卢石低声说：\n\n“知道了！”\n孟迟低声说：\n\n“知道了。”\n"


def compare(original, revised):
    spec = importlib.util.spec_from_file_location("r55_punctuation", SCRIPTS / "punctuation_lint.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.compare_texts(original, revised)


def certain(report):
    return sorted((t["line"], t["before"] + "→" + t["after"]) for t in report["tone_changes"] if t["match"] != "uncertain")


def flagged_lines(report):
    return sorted(t["line"] for t in report["tone_changes"])


class SpeakerLineAcrossABlankLine(unittest.TestCase):
    """The review's layouts: pure move, move plus changed marks, and the strict gate."""

    def test_blank_lines_everywhere_pure_move_is_not_reported(self):
        self.assertEqual(compare(SEPARATED, SEPARATED_MOVED)["tone_changes"], [])

    def test_blank_lines_everywhere_both_changes_are_reported(self):
        report = compare(SEPARATED, SEPARATED_CHANGED)
        # 卢石 (now line 3) went from 。 to ！; 陈青 (now line 11) went from ！ to 。; 孟迟 is unchanged.
        self.assertEqual(certain(report), [(3, "。→！"), (11, "！→。")])
        self.assertEqual(flagged_lines(report), [3, 11])

    def test_mixed_layout_pure_move_is_never_a_certain_change(self):
        # r5.4 reported two certain changes here although nobody's mark changed.
        self.assertEqual(compare(MIXED, MIXED_MOVED)["tone_changes"], [])

    def test_mixed_layout_both_changes_are_reported(self):
        report = compare(MIXED, MIXED_CHANGED)
        # 卢石 (now line 6) went from 。 to ！; 孟迟 (now line 9) went from ！ to 。; 陈青 is unchanged.
        self.assertEqual(certain(report), [(6, "。→！"), (9, "！→。")])
        self.assertEqual(flagged_lines(report), [6, 9])

    def gate(self, original, revised, quotes):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            (work / "original.md").write_bytes((original).encode("utf-8"))
            (work / "draft.md").write_bytes((revised).encode("utf-8"))
            (work / "checks.json").write_bytes((json.dumps({"candidate": "draft.md", "mode": "strict", "checks": [
                {"id": "rev", "type": "revision", "source": "original.md"}]})).encode("utf-8"))

            def run(*args):
                proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPTS / "workflow_guard.py"), *args], cwd=work,
                                      capture_output=True, text=True, encoding="utf-8")
                return proc.returncode, json.loads(proc.stdout)

            def review(name, dispositions):
                # The review's own fixture: the three speaker lines as quotes, all six dimensions as test data.
                (work / name).write_bytes((json.dumps({
                    "schema": "editorial-review/2", "verdict": "PASS",
                    "candidate_sha256": hashlib.sha256((work / "draft.md").read_bytes()).hexdigest(),
                    "reviewer": {"mode": "self_check", "label": "测试数据：只验证结构"},
                    "checked_against": ["测试数据：original.md"], "inputs_read": ["original.md"],
                    "evidence": [{"in": "candidate", "quote": q} for q in quotes],
                    "issues": [], "counter_evidence": "测试数据，不是真实文学审稿。", "machine_dispositions": dispositions,
                    "dimensions": [{"id": key, "status": "met", "note": "测试数据：只验证结构"} for key in DIMENSIONS],
                    "expression": whole_text((work / "draft.md").read_text(encoding="utf-8"))},
                    ensure_ascii=False)).encode("utf-8"))
                return name

            self.assertEqual(run("start", "state.json", "--task-id", "r55", "--spec", "checks.json")[0], 0)
            items = [x["id"] for x in run("check", "checks.json")[1]["review_items"]]
            code, out = run("record", "state.json", "--event-id", "v1", "--review", review("none.json", []))
            self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"))
            code, _ = run("record", "state.json", "--event-id", "v2", "--review", review("all.json", [
                {"id": key, "decision": "keep", "reason": "测试数据：两处语气都是有意改的"} for key in items]))
            self.assertEqual(code, 0)
            gate = run("status", "state.json")[1]["gate"]
            self.assertEqual((gate["mechanical"], gate["editorial"], gate["review_items_open"]), ("GREEN", "PASS[self_check]", 0))
            return items

    def test_blank_lines_everywhere_the_gate_needs_both_decisions(self):
        items = self.gate(SEPARATED, SEPARATED_CHANGED, ("陈青低声说：", "卢石低声说：", "孟迟低声说："))
        self.assertEqual(items, ["rev:TONE-L3-C1", "rev:TONE-L11-C1"])

    def test_mixed_layout_the_gate_needs_both_decisions(self):
        items = self.gate(MIXED, MIXED_CHANGED, ("陈青低声说：", "卢石低声说：", "孟迟低声说："))
        self.assertEqual(items, ["rev:TONE-L6-C1", "rev:TONE-L9-C1"])


class ALineEndingInAColon(unittest.TestCase):
    """A colon line belongs to the words after it, wherever the blank lines are."""

    def test_without_blank_lines_the_speakers_are_told_apart(self):
        # Each speech has its own speaker line above and the next one below; the one below is not its speaker.
        before = "陈青低声说：\n“知道了！”\n孟迟低声说：\n“知道了！”\n卢石低声说：\n“知道了。”\n"
        moved = "陈青低声说：\n“知道了！”\n卢石低声说：\n“知道了。”\n孟迟低声说：\n“知道了！”\n"
        changed = "陈青低声说：\n“知道了。”\n卢石低声说：\n“知道了！”\n孟迟低声说：\n“知道了！”\n"
        self.assertEqual(compare(before, moved)["tone_changes"], [])
        report = compare(before, changed)
        self.assertEqual(certain(report), [(2, "！→。"), (4, "。→！")])
        self.assertEqual(flagged_lines(report), [2, 4])

    def test_a_blank_line_can_be_added_or_removed_after_the_speaker_line(self):
        before = "陈青低声说：\n“知道了！”\n\n孟迟低声说：\n“知道了。”\n"
        after = "陈青低声说：\n\n“知道了。”\n\n孟迟低声说：\n\n“知道了。”\n"
        self.assertEqual(certain(compare(before, after)), [(3, "！→。")])

    def test_the_next_speakers_colon_line_does_not_tie_the_words_above_it(self):
        # 陈青 and 甲 nod, then speak; the colon lines below their words open the next speeches. 孟迟's and 卢石's
        # paragraphs swap, so other colon lines now follow 陈青's and 甲's words: nothing of theirs moved or changed.
        before = "陈青点了点头。\n“知道了！”\n孟迟低声说：\n“好。”\n甲点了点头。\n“知道了。”\n卢石低声说：\n“走吧。”\n"
        after = "陈青点了点头。\n“知道了！”\n卢石低声说：\n“走吧。”\n甲点了点头。\n“知道了。”\n孟迟低声说：\n“好。”\n"
        self.assertEqual(compare(before, after)["tone_changes"], [])


class TheLineBelowAloneNamesNobody(unittest.TestCase):
    """The review's mixed layout with action lines instead of colon lines. The line directly below the words is the
    next speaker's ("孟迟点了点头。"), not theirs; nothing in the text says so. r5.4 took it as the speaker: a pure move
    became two certain changes, a real change went unreported. Read the other way round the same lines would be the
    speaker below the words ("“知道了！”" then "陈青低声说。"), so that reading is given up for both (see
    test_r53_review_repairs.test_speaker_on_the_line_below)."""

    BEFORE = "陈青点了点头。\n\n“知道了！”\n孟迟点了点头。\n\n“知道了！”\n卢石点了点头。\n\n“知道了。”\n"

    def test_pure_move_is_never_a_certain_change(self):
        moved = "陈青点了点头。\n\n“知道了！”\n卢石点了点头。\n\n“知道了。”\n孟迟点了点头。\n\n“知道了！”\n"
        self.assertEqual(certain(compare(self.BEFORE, moved)), [])

    def test_both_changes_are_flagged(self):
        changed = "陈青点了点头。\n\n“知道了！”\n卢石点了点头。\n\n“知道了！”\n孟迟点了点头。\n\n“知道了。”\n"
        report = compare(self.BEFORE, changed)
        # 卢石 (now line 6) went from 。 to ！; 孟迟 (now line 9) went from ！ to 。. r5.4 reported nothing.
        self.assertTrue({6, 9} <= set(flagged_lines(report)), report["tone_changes"])
        for item in report["tone_changes"]:
            if item["match"] != "uncertain":
                self.assertIn((item["line"], item["before"] + "→" + item["after"]), [(6, "。→！"), (9, "！→。")])

    def test_speakers_below_without_blank_lines_swapped(self):
        # Two paragraphs, each the words with the speaker below, swapped as they are. The first words now stand at the
        # very top as the others did; that is no sign they are the same words.
        before = "“知道了？”\n甲低声说。\n“知道了。”\n戊低声说。\n"
        after = "“知道了。”\n戊低声说。\n“知道了？”\n甲低声说。\n"
        self.assertEqual(certain(compare(before, after)), [])


class ALineBetweenTwoSpeeches(unittest.TestCase):
    """A line of narration directly between two speeches may close the first or open the second."""

    BEFORE = "“走吧。”\n他转身出了门。\n“知道了！”\n\n“等等。”\n她回头看了一眼。\n“知道了。”\n"

    def test_replies_left_in_place(self):
        # Read as whole paragraphs that swapped, both replies changed their marks; read as the first two lines
        # swapped and the replies left in place, nothing changed. r5.4 asserted the first reading.
        after = "“等等。”\n她回头看了一眼。\n“知道了！”\n\n“走吧。”\n他转身出了门。\n“知道了。”\n"
        report = compare(self.BEFORE, after)
        self.assertEqual(certain(report), [])
        self.assertTrue({3, 7} <= set(flagged_lines(report)), report["tone_changes"])

    def test_whole_paragraphs_swapped(self):
        # The same two readings the other way round: r5.4 passed this as unchanged, which is wrong if the replies stayed.
        after = "“等等。”\n她回头看了一眼。\n“知道了。”\n\n“走吧。”\n他转身出了门。\n“知道了！”\n"
        report = compare(self.BEFORE, after)
        self.assertEqual(certain(report), [])
        self.assertTrue({3, 7} <= set(flagged_lines(report)), report["tone_changes"])


class OneSpeakerLineForTwoPeople(unittest.TestCase):
    """"他低声说：" names nobody in particular when it opens two people's words."""

    def test_two_he_said_paragraphs_that_moved_are_not_paired_by_order(self):
        before = "他低声说：\n“知道了！”\n\n她低声说：\n“走。”\n\n他低声说：\n“知道了。”\n\n她低声说：\n“好。”\n"
        after = "她低声说：\n“走。”\n\n她低声说：\n“好。”\n\n他低声说：\n“知道了。”\n\n他低声说：\n“知道了！”\n"
        report = compare(before, after)
        self.assertEqual(certain(report), [])
        self.assertEqual(flagged_lines(report), [8, 11])


class RepliesWithoutASpeakerLine(unittest.TestCase):
    """Replies nobody is named for are told apart only by where they stand."""

    def test_a_run_that_slid_is_not_paired_by_position(self):
        # One reply moved up. The unchanged run of “知道了” lines up one paragraph off just as well as in place; r5.4
        # paired it that way and reported three certain changes, none of which happened. Only a line fenced in by
        # lines that occur once (or by the start or end of both texts) is paired in place now.
        before = "“知道了？”\n\n“知道了。”\n\n“好？”\n\n“知道了？”\n\n“知道了？”\n\n“知道了！”\n"
        after = "“知道了？”\n\n“知道了。”\n\n“知道了！”\n\n“好？”\n\n“知道了。”\n\n“知道了！”\n"
        report = compare(before, after)
        self.assertEqual(certain(report), [])
        self.assertTrue(report["tone_changes"])  # what it cannot pair is flagged, not passed

    def test_a_reply_changed_between_two_fixed_lines_is_certain(self):
        before = "陈青问：\n\n“走吗？”\n\n孟迟看了看天。\n\n“走。”\n\n门开了。\n\n“走。”\n"
        after = before.replace("看了看天。\n\n“走。”", "看了看天。\n\n“走！”")
        report = compare(before, after)
        self.assertEqual([(t["line"], t["before"] + "→" + t["after"], t["match"]) for t in report["tone_changes"]],
                         [(7, "。→！", "same_line")])


class MovedLinesAreNotRewrittenInPlace(unittest.TestCase):
    """A speaker line that moved does not make the line now in its slot an edited copy of it."""

    PARAGRAPH = "陈青点了点头。\n\n“知道了！”\n\n孟迟点了点头。\n\n“知道了！”\n\n卢石点了点头。\n\n“知道了。”\n"

    def test_first_and_last_speakers_swap_and_change_marks(self):
        # Without a colon the program cannot tell whose words these are: it must flag them, not pass them.
        changed = "卢石点了点头。\n\n“知道了！”\n\n孟迟点了点头。\n\n“知道了！”\n\n陈青点了点头。\n\n“知道了。”\n"
        report = compare(self.PARAGRAPH, changed)
        self.assertTrue({3, 11} <= set(flagged_lines(report)), report["tone_changes"])
        for item in report["tone_changes"]:
            if item["match"] != "uncertain":
                self.assertIn((item["line"], item["before"] + "→" + item["after"]), [(3, "。→！"), (11, "！→。")])

    def test_moved_and_reworded_speaker_lines_are_not_rewrites_in_place(self):
        # The two lines that swapped were also reworded, so neither text is found again; they are still more like each
        # other's old line than the line now in their slot.
        changed = "卢石慢慢点了点头。\n\n“知道了！”\n\n孟迟点了点头。\n\n“知道了！”\n\n陈青慢慢点了点头。\n\n“知道了。”\n"
        report = compare(self.PARAGRAPH, changed)
        self.assertTrue({3, 11} <= set(flagged_lines(report)), report["tone_changes"])
        for item in report["tone_changes"]:
            if item["match"] != "uncertain":
                self.assertIn((item["line"], item["before"] + "→" + item["after"]), [(3, "。→！"), (11, "！→。")])

    def test_first_and_last_speakers_swap_without_change_is_never_certain(self):
        moved = "卢石点了点头。\n\n“知道了。”\n\n孟迟点了点头。\n\n“知道了！”\n\n陈青点了点头。\n\n“知道了！”\n"
        self.assertEqual(certain(compare(self.PARAGRAPH, moved)), [])

    def test_a_speaker_line_reworded_in_place_still_pairs_its_words(self):
        after = self.PARAGRAPH.replace("孟迟点了点头。\n\n“知道了！”", "孟迟轻轻点了点头。\n\n“知道了？”")
        report = compare(self.PARAGRAPH, after)
        # Paired by place next to a line taken as rewritten in place: reported, and marked as resting on that guess.
        self.assertEqual([(t["line"], t["before"] + "→" + t["after"], t["match"]) for t in report["tone_changes"]],
                         [(7, "！→？", "in_place")])
        self.assertIn("假定", report["tone_changes"][0]["message"])


if __name__ == "__main__":
    unittest.main()

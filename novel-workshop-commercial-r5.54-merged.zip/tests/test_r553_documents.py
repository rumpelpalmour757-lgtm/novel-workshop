"""r5.53: the package's documents carry no unfilled placeholders.

r5.52 shipped a README whose verification line still read <<CORPUS_N>> and the like: the fill step covered the changelog,
the verification notes and the letter, not the README. Every document of the package is checked now, for the <<NAME>>
form and for the word the fill tool writes into a trial build (试打包), and the six documents at the root must be there.
"""
import os
import re
import unittest
from pathlib import Path

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
ROOT_DOCUMENTS = ("README.md", "USAGE.md", "QUICKSTART.md", "EXAMPLES.md", "CHANGELOG.md", "VERIFICATION.md")


class NoPlaceholdersLeft(unittest.TestCase):
    def test_documents(self):
        files = [ROOT / name for name in ROOT_DOCUMENTS]
        for path in files:
            self.assertTrue(path.is_file(), path.name)
        files += sorted((ROOT / "skills").rglob("*.md"))
        for path in files:
            text = path.read_text(encoding="utf-8")
            self.assertEqual(re.findall(r"<<[A-Z][A-Z0-9_]*>>", text), [], path.relative_to(ROOT))
            self.assertNotIn("试打包", text, path.relative_to(ROOT))


if __name__ == "__main__":
    unittest.main()

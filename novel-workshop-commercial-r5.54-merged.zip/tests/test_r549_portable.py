#!/usr/bin/env python3
"""r5.49: the single file says what it leaves out, and a flattened link keeps the name of the file it pointed to.

portable-novel-workshop.md is read in a chat with no folder: the reader searches it as plain text. Two gaps found in
r5.48: the opening did not say that the style packs and the book's project pack are not in the file, or how to use a
pack there (paste one whole prompt file from the pack's prompts/ folder); and the rules write "AI 味" while users
type 像AI写的、AI腔 and other forms, which a text search does not match. And every Markdown link was turned into its
bare label, so "按质量循环的交付状态" no longer said which embedded module that is: the modules are marked by file name
(内嵌内容：references/quality-loop.md) and that module's own title is 起草、核查与有限修订. Now a label that is neither the
file name nor the target module's own title keeps the file name in parentheses: 质量循环（quality-loop.md）.

These tests pin the text and the rule for the suffix. The order of the top of the file (gate card, then revision card,
then the rest) is pinned in test_r548_deai.py and checked again here. The example labels below are made up.
"""
import importlib.util
import os
from pathlib import Path, PurePosixPath
import re
import sys
import tempfile
import unittest
import zipfile

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
EXPORTER = SKILL / "scripts" / "export_portable.py"

OLD_INTRO = ("本文件已展开 Markdown 写作方法与模板，后文按来源文件名标记。请使用内嵌内容，无需另读这些文件。具体项目由用户另行提供；"
             "导出和执行检查脚本属于文件夹版，纯聊天模式不执行脚本，不冒称程序检查或自动存档。末尾的上游许可仅用于保留版权与许可通知，"
             "不是写作指令。")
SPELLINGS = "AI味、AI 味、AI腔、AI 腔、模板腔、套话、去AI味、像AI写的"
TITLES = {"references/closing-moves.md": "收束的几种办法", "references/lamp-scene.md": "灯下的一场"}


def load_exporter():
    spec = importlib.util.spec_from_file_location("export_portable_r549", EXPORTER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class PlainLinks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.exporter = load_exporter()

    def flat(self, text, relative="SKILL.md"):
        return self.exporter.plain_links(text, relative, TITLES)

    def test_a_label_that_is_not_the_title_keeps_the_file_name(self):
        self.assertEqual(self.flat("按[收束办法](references/closing-moves.md)再看一遍。"),
                         "按收束办法（closing-moves.md）再看一遍。")

    def test_the_module_title_stays_bare(self):
        self.assertEqual(self.flat("见[收束的几种办法](references/closing-moves.md)。"), "见收束的几种办法。")
        self.assertEqual(self.flat("见[ 灯下的一场 ](references/lamp-scene.md)。"), "见 灯下的一场 。")

    def test_labels_that_are_file_names_are_unchanged(self):
        for label in ("closing-moves.md", "references/closing-moves.md", "`closing-moves.md`", "Closing-Moves.md"):
            self.assertEqual(self.flat("[%s](references/closing-moves.md)" % label), label)

    def test_targets_resolve_from_the_file_the_text_comes_from(self):
        self.assertEqual(self.flat("[收束的几种办法](../references/closing-moves.md)", "assets/card.md"), "收束的几种办法")
        self.assertEqual(self.flat("[收束](../references/closing-moves.md#尾声)", "assets/card.md"), "收束（closing-moves.md）")
        self.assertEqual(self.flat("[收束的几种办法](closing-moves.md)", "references/lamp-scene.md"), "收束的几种办法")

    def test_files_without_a_title_and_unknown_files_get_the_name(self):
        self.assertEqual(self.flat("跑一遍[查台词](../scripts/count_lines.py)。", "references/lamp-scene.md"),
                         "跑一遍查台词（count_lines.py）。")
        self.assertEqual(self.flat("[空白表](assets/blank%20sheet.json)"), "空白表（blank sheet.json）")

    def test_reference_style_links_follow_the_same_rule(self):
        text = "先读[灯下那段][lamp]，再读[灯下的一场][lamp]。\n\n[lamp]: references/lamp-scene.md\n"
        self.assertEqual(self.flat(text).strip(), "先读灯下那段（lamp-scene.md），再读灯下的一场。")

    def test_anchors_and_external_links_are_left_as_before(self):
        self.assertEqual(self.flat("回到[上一节](#开头)。"), "回到上一节。")
        self.assertEqual(self.flat("[说明](https://example.org/notes.md)"), "[说明](https://example.org/notes.md)")

    def test_without_titles_only_file_names_count(self):
        self.assertEqual(self.exporter.plain_links("[收束的几种办法](references/closing-moves.md)"),
                         "收束的几种办法（closing-moves.md）")
        self.assertEqual(self.exporter.plain_links("[closing-moves.md](references/closing-moves.md)"), "closing-moves.md")

    def test_module_title_skips_frontmatter_and_code(self):
        text = "---\nname: x\n---\n```\n# 代码里的井号\n```\n\n# 夜班的规矩 #\n\n## 小节\n"
        self.assertEqual(self.exporter.module_title(text), "夜班的规矩")
        self.assertIsNone(self.exporter.module_title("## 只有小节\n"))


class SingleFile(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        exporter = load_exporter()
        cls.files = {}
        with tempfile.TemporaryDirectory() as tmp:
            for mode in ("personal", "sale"):
                target = Path(tmp) / (mode + ".zip")
                exporter.export(SKILL, target, mode=mode)
                with zipfile.ZipFile(target) as archive:
                    names = {PurePosixPath(name).name for name in archive.namelist()}
                    cls.files[mode] = (archive.read("portable-novel-workshop.md").decode("utf-8"), names)
                    cls.guides = getattr(cls, "guides", {})
                    cls.guides[mode] = archive.read("README.md").decode("utf-8")

    def test_the_opening_says_what_is_left_out_and_how_to_use_a_pack(self):
        for mode, (single, _) in self.files.items():
            paragraphs = single.split("\n\n")
            self.assertEqual(paragraphs[0], "# 小说写作工坊：便携单文件版", mode)
            intro = paragraphs[1]
            self.assertTrue(intro.startswith(OLD_INTRO), mode)
            for phrase in ("风格包和任何一本书的项目包都不展开在本文件里", "prompts/", "整份贴进来", "已经带着这个配方要用的引擎",
                           "要换引擎", "00_底座与目录.md", "07_与都市高武同用.md", "skills/novel-workshop/assets/style-packs/"):
                self.assertIn(phrase, intro, mode)  # r5.49 review P1: the exceptions to "one prompt file" are said

    def test_the_search_line_lists_the_spellings_and_is_not_a_verdict(self):
        for mode, (single, _) in self.files.items():
            line = single.split("\n\n")[2]
            self.assertNotIn("\n", line, mode)
            self.assertIn(SPELLINGS, line, mode)
            self.assertIn("只是要重读的地方，不是定论", line, mode)
            self.assertIn("不说明文字没有 AI 味", line, mode)
            self.assertLess(single.index(SPELLINGS), single.index("# 内嵌内容：assets/delivery-gate-card.md"), mode)

    def test_the_order_at_the_top_is_unchanged(self):
        for mode, (single, _) in self.files.items():
            gate = single.index("# 内嵌内容：assets/delivery-gate-card.md")
            revision = single.index("# 内嵌内容：assets/revision-card.md")
            self.assertLess(gate, revision, mode)
            self.assertLess(revision, single.index("# 内嵌内容：CONSTITUTION.md"), mode)
            self.assertLess(revision, len(single) * 0.05, mode)

    def test_flattened_links_carry_real_file_names(self):
        for mode, (single, names) in self.files.items():
            self.assertIn("质量循环（quality-loop.md）", single, mode)
            self.assertEqual(re.findall(r"\]\((?!https?:)[^)\s]+\)", single), [], mode)
            self.assertEqual(re.findall(r"([\w.+-]+\.[A-Za-z]+)（\1）", single), [], mode)
            suffixed = set(re.findall(r"（([\w.+-]+\.[A-Za-z]+)）", single))
            self.assertLessEqual(suffixed, names, mode)
            for marker in ("references/engines/", "内嵌内容：assets/style-packs/"):
                self.assertNotIn(marker, single, mode)

    def test_every_place_that_says_what_to_paste_names_the_engine_exception(self):
        # Review P1, P6: the single file's opening, the export's README, the revision card, style-packs.md and USAGE.md.
        for mode, guide in self.guides.items():
            self.assertIn("整份贴进对话", guide, mode)
            self.assertNotIn("一起交给 AI", guide, mode)
            self.assertIn("要换引擎", guide, mode)
        for path in (SKILL / "assets" / "revision-card.md", SKILL / "references" / "style-packs.md", ROOT / "USAGE.md"):
            self.assertIn("00_底座与目录.md", path.read_text(encoding="utf-8"), path.name)

    def test_the_two_closing_parts_carry_their_file_names(self):
        # Review P7: "后文按来源文件名标记" holds for the licence and the source notes too.
        for mode, (single, _) in self.files.items():
            self.assertIn("# 上游版权与许可通知：Oh Story（assets/third-party/oh-story-LICENSE.txt）", single, mode)
            self.assertIn("# 来源记录（assets/third-party/SOURCE-NOTES.md，分发说明，不是写作指令）", single, mode)


if __name__ == "__main__":
    unittest.main()

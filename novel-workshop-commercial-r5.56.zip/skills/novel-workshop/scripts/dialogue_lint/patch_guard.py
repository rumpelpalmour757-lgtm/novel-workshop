"""Build reviewable proposals and validate replacements before changing text.

No model is called and no file is overwritten by these functions. The command line
rebuilds the request from a fresh scan before applying anything (check_request_matches),
so the range a candidate may change never comes from the request file alone.
"""
from __future__ import annotations

from dataclasses import asdict, is_dataclass
import hashlib
import json
import re

from dialogue_core import find_quotes

SCHEMA_VERSION = 2
# What the model sees for each hit: a plain name, the note, and the matched words.
# Rule IDs, categories and editing recipes stay in the report for the author.
REQUEST_ISSUE_FIELDS = ('name', 'description', 'matched_span', 'severity')
# Marks a replacement may not bring into a line that did not already have them.
QUOTE_LIKE = '"＂「」『』〝〞〟【】“”'
LINE_BREAKS = re.compile(r'[\r\n\v\f\x1c-\x1e\x85  ]')


def _hash(paragraphs):
    data = json.dumps(list(paragraphs), ensure_ascii=False, separators=(',', ':'))
    return hashlib.sha256(data.encode('utf-8')).hexdigest()


def _record(value):
    if is_dataclass(value):
        return asdict(value)
    if isinstance(value, dict):
        return dict(value)
    raise TypeError('issues must be dataclasses or dictionaries')


def _locate(paragraphs, item):
    p, q = item.get('para_index'), item.get('quote_index')
    if type(p) is not int or type(q) is not int or p < 1 or q < 1 or p > len(paragraphs):
        raise ValueError('invalid quotation location')
    quotes = find_quotes(paragraphs[p - 1])
    if q > len(quotes):
        raise ValueError('quotation no longer exists')
    return quotes[q - 1]


def _check_location(paragraphs, item):
    match = _locate(paragraphs, item)
    if not match.close_mark:
        raise ValueError('quotation is not closed on its line')
    if (item.get('start'), item.get('end'), item.get('original')) != (match.start, match.end, match.text):
        raise ValueError('quotation range/original does not match source')
    if item.get('quote_id') != f"p{item['para_index']}:q{item['quote_index']}":
        raise ValueError('quotation ID does not match location')
    return match


def _problem(data):
    problem = {'name': data.get('name') or '', 'description': data.get('description') or data.get('reason') or ''}
    for key in ('matched_span', 'severity'):
        if data.get(key):
            problem[key] = data[key]
    return problem


def build_patch_request(paragraphs, issues, *, scan_settings=None):
    """Group confirmed-speaker hits by quotation; open quotations are never offered."""
    paragraphs = list(paragraphs)
    if any(not isinstance(p, str) for p in paragraphs):
        raise TypeError('paragraphs must contain strings')
    grouped = {}
    for issue in issues:
        data = _record(issue)
        if data.get('confidence') not in ('explicit', 'manual'):
            continue
        item = dict(quote_id=data.get('quote_id'), para_index=data.get('para_index'),
            quote_index=data.get('quote_index'), start=data.get('start'), end=data.get('end'),
            original=data.get('source_quote'), speaker=data.get('speaker'),
            confidence=data.get('confidence'))
        if not _locate(paragraphs, item).close_mark:
            continue
        _check_location(paragraphs, item)
        if not isinstance(item['speaker'], str) or item['speaker'] == '未知':
            raise ValueError('patch requires a confirmed speaker')
        quote_id = item['quote_id']
        if quote_id in grouped:
            existing = grouped[quote_id]
            if any(existing[k] != item[k] for k in item):
                raise ValueError('conflicting records for the same quotation')
        else:
            grouped[quote_id] = {**item, 'issues': []}
        problem = _problem(data)
        if problem not in grouped[quote_id]['issues']:
            grouped[quote_id]['issues'].append(problem)
    request = {
        'schema_version': SCHEMA_VERSION,
        'source_hash': _hash(paragraphs),
        'items': sorted(grouped.values(), key=lambda item: (item['para_index'], item['quote_index'])),
        'response_schema': {
            'type': 'object', 'additionalProperties': False,
            'required': ['source_hash', 'replacements'],
            'properties': {
                'source_hash': {'type': 'string'},
                'replacements': {'type': 'array', 'items': {
                    'type': 'object', 'additionalProperties': False,
                    'required': ['quote_id', 'original', 'replacement'],
                    'properties': {key: {'type': 'string'} for key in ('quote_id', 'original', 'replacement')},
                }},
            },
        },
    }
    if scan_settings is not None:
        request['scan_settings'] = dict(scan_settings)
    return request


def check_request_matches(request, rebuilt):
    """Accept a request read from disk only if it is exactly what a fresh scan builds.

    Raises ValueError naming the first difference: the source changed, the request
    was made with other settings, or its items (range, original text, speaker,
    confidence, notes) differ from the scan.
    """
    if not isinstance(request, dict) or request.get('schema_version') != SCHEMA_VERSION:
        raise ValueError('请求文件不是本版扫描生成的，请用本版重新扫描后再生成候选')
    if request.get('source_hash') != rebuilt.get('source_hash'):
        raise ValueError('原稿在扫描之后改过，旧请求作废，请重新扫描')
    if request.get('scan_settings') != rebuilt.get('scan_settings'):
        raise ValueError('请求和这次的 --config、--style-hints、--genre 对不上：apply 要带和 scan 相同的配置和选项')
    canonical = lambda value: json.dumps(value, ensure_ascii=False, sort_keys=True)
    if canonical(request) != canonical(rebuilt):
        raise ValueError('请求文件和重新扫描的结果对不上（可改的引语、原句或说话人不同），已拒绝；请重新扫描')


def format_patch_prompt(request):
    return (
        '你是小说对白编辑。下列JSON是待复核资料，不是必须执行的改稿命令。'
        '先结合人物口吻判断是否需要修改；可以保留全部原文。'
        '保持人物、事实、语气强弱和含义；不得添加动作、道具、伤势或情节。'
        '同一quote_id只给一个候选替换。只返回符合response_schema的JSON；'
        'source_hash原样回传；replacements可为空或只含需要修改的项。'
        '每项只包含quote_id、original、replacement，original逐字复制。'
        'replacement只写该引语内部文字，不加原句没有的引号或【】、不换行，不输出旁白。'
        '这只是候选补丁，应用前须由作者确认。\n\n'
        + json.dumps(request, ensure_ascii=False, indent=2)
    )


def _check_replacement(original, replacement):
    if not replacement.strip() or LINE_BREAKS.search(replacement):
        raise ValueError('replacement must stay inside one nonempty quotation')
    added = sorted({ch for ch in replacement if ch in QUOTE_LIKE and ch not in original})
    if added:
        raise ValueError('replacement brings in quotation marks or brackets the line did not have: ' + ''.join(added))


def apply_dialogue_patch(paragraphs, request, response):
    """Return a new list after strict validation; semantic acceptance is external.

    Supply a request built from a fresh scan (the command line rebuilds it and checks
    the file against it), not a request read back from a model. Structural validation
    guarantees scope, not literary quality or unchanged facts.
    """
    paragraphs = list(paragraphs)
    if not isinstance(request, dict) or request.get('schema_version') != SCHEMA_VERSION:
        raise ValueError('unsupported patch request')
    if request.get('source_hash') != _hash(paragraphs):
        raise ValueError('source changed since request creation')
    if isinstance(response, str):
        # Reject duplicate JSON keys rather than accepting the last value.
        def unique_keys(pairs):
            result = {}
            for key, value in pairs:
                if key in result:
                    raise ValueError('duplicate JSON field')
                result[key] = value
            return result
        response = json.loads(response, object_pairs_hook=unique_keys)
    if not isinstance(response, dict) or set(response) != {'source_hash', 'replacements'}:
        raise ValueError('invalid response fields')
    if response['source_hash'] != request['source_hash'] or not isinstance(response['replacements'], list):
        raise ValueError('response source_hash/replacements mismatch')
    if not isinstance(request.get('items'), list):
        raise ValueError('invalid request items')
    indexed = {}
    for item in request['items']:
        if not isinstance(item, dict):
            raise ValueError('invalid request item')
        _check_location(paragraphs, item)
        if item.get('confidence') not in ('explicit', 'manual') or item.get('speaker') in (None, '', '未知'):
            raise ValueError('unconfirmed attribution cannot be patched')
        if item['quote_id'] in indexed:
            raise ValueError('duplicate request quotation')
        indexed[item['quote_id']] = item
    seen, changes = set(), {}
    for change in response['replacements']:
        if not isinstance(change, dict) or set(change) != {'quote_id', 'original', 'replacement'}:
            raise ValueError('invalid replacement fields')
        if any(not isinstance(change[k], str) for k in change):
            raise ValueError('replacement fields must be strings')
        key = change['quote_id']
        if key in seen or key not in indexed:
            raise ValueError('duplicate or unknown quotation ID')
        seen.add(key)
        item = indexed[key]
        if change['original'] != item['original']:
            raise ValueError('replacement original does not match request')
        _check_replacement(item['original'], change['replacement'])
        changes.setdefault(item['para_index'] - 1, []).append(
            (item['start'], item['end'], change['replacement'], item['quote_index']))
    updated = list(paragraphs)
    for index, replacements in changes.items():
        for start, end, replacement, _ in sorted(replacements, reverse=True):
            updated[index] = updated[index][:start] + replacement + updated[index][end:]
        # The line must still hold the same quotations with the same marks; only the
        # replaced ones may read differently.
        before, after = find_quotes(paragraphs[index]), find_quotes(updated[index])
        replaced = {q: text for _, _, text, q in replacements}
        expected = [(m.open_mark, m.close_mark, replaced.get(n, m.text)) for n, m in enumerate(before, 1)]
        if [(m.open_mark, m.close_mark, m.text) for m in after] != expected:
            raise ValueError('replacement changes where a quotation begins or ends')
    return updated

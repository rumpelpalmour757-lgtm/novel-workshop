# 来源与许可说明

本包按 MIT 许可发布，全文见 [LICENSE](LICENSE)，版权人 Celeste（2026-11-13 定的）。三样第三方组件（Oh Story、darwin-skill、TypeSafe AI）各按自己的 MIT 许可，署各自的版权人，见 [第三方组件与许可范围](THIRD-PARTY-NOTICES.md)。下表记各组件从哪里来、改了什么。

| 组件 | 来源与变更 | 许可与记录 |
| --- | --- | --- |
| 小说写作工坊 | 通用写作方法、模板和脚本；本版整理买家入口与扩展调用说明，不附具体小说项目 | 本包的 MIT 许可；逐条来源见[详细来源记录](skills/novel-workshop/assets/third-party/SOURCE-NOTES.md)。技能目录里另放一份同样的 [LICENSE](skills/novel-workshop/LICENSE) |
| Oh Story 相关方法 | 工坊参考并改写的章节状态与写作流程方法 | [原有 MIT 许可与版权通知](skills/novel-workshop/assets/third-party/oh-story-LICENSE.txt) |
| Oh Story 0.8.4 新增模块与工具 | 完整拆文、市场观察等方法重写；工作台有适配，章节索引、材料检查与关系图保留原实现 | [0.8.4 MIT 许可](skills/novel-workshop/assets/third-party/oh-story-0.8.4-LICENSE.txt)及[接入范围](skills/novel-workshop/assets/third-party/INTEGRATION-NOTES.md) |
| Darwin 工坊维护适配 | 基于 [alchaincyf/darwin-skill](https://github.com/alchaincyf/darwin-skill) 的候选迭代和配对比较思路，面向小说工坊重写精简入口；未包含上游演示与截图功能 | [Darwin MIT 许可与版权通知](skills/darwin-novel-workshop/LICENSE) |
| TypeSafe 可选开发技能 | TypeSafe 技能源码，正文与所附许可证保持原样 | [TypeSafe MIT 许可](optional/typesafe-ai/LICENSE) |
| 风格卡（r5.45） | 作者提供的一组腔调卡（卡组 4.1.0），收成 `skills/novel-workshop/assets/style-cards/cards.json`；收进来时删掉了名作原句和某一部作品专属的名字、套语，私人作品里的用语和网络热梗。卡名和说明里提到的作家、作品只用来描述腔调，包内不含这些作品的原文 | 版权人 2026-11-13 确认由本人所写或有权公开，按本包的 MIT 许可发布，见[详细来源记录](skills/novel-workshop/assets/third-party/SOURCE-NOTES.md)；借风格不搬原作表达的用法见[风格卡](skills/novel-workshop/references/style-cards.md) |
| 风格包（r5.47） | 作者提供的两套写法规范，都市高武风格引擎库 v2.0.2、小说实感与去 AI 味引擎 v17.1.2，收在 `skills/novel-workshop/assets/style-packs/`，作者点名或作品档案写明才启用；随商业版分发前删去或换掉了五处出自作者私人作品的词和例子。包里的脚本是作者材料的一部分（r5.46 改过其中几个函数），工坊不自动运行。合并候选把两包的入口 `SKILL.md` 改名为 `ENGINE.md`（内容没变），r5.55 改了两包 README 里讲怎样安装的几句 | 版权人 2026-11-13 确认由本人所写或有权公开，按本包的 MIT 许可发布；包里没有单独的许可文件，以本包的 LICENSE 为准。几项没有核过的来源细节照实留在[详细来源记录](skills/novel-workshop/assets/third-party/SOURCE-NOTES.md)“风格包”一行，另见[风格包](skills/novel-workshop/references/style-packs.md) |
| 章节门、学习循环、示范记忆（合并候选并进来） | `chapter_gate.py`、`learning_loop.py`、`demonstration_memory.py`，三页说明、一个案例模板和技能目录里的测试；原是版权人另一套工作环境里加的扩展，合并候选（`2026-11-14-r5.54-merged-candidate`）并进本包，r5.55 改了三个脚本的部分行为（见 [CHANGELOG.md](CHANGELOG.md)） | 由版权人提供，只用 Python 标准库和同目录的脚本；按本包的 MIT 许可 |
| 对白声纹与反模式检查、叙述“先”字复核（2026-11-09 起） | 作者提供的两段 Python 检测器和三类题材配置修成的 `scripts/dialogue_lint/`（r5.55 为 dialogue-lint 1.2.0），作者提供的两条正则修成的 `prose_lint.py --hint xian`（narrative-xian 0.1.0） | 由版权人提供，只用 Python 标准库和同目录的模块；按本包的 MIT 许可 |
| 视觉素材链路调用的外部项目（r5.35） | 工坊只带调用它们的适配器（`skills/novel-workshop/scripts/visual_materials/`，新写）；SearXNG 由使用者自己部署，Openverse 调它的公开接口，Crawl4AI、ImageHash、OpenCLIP（含 torch）由使用者自己安装，模型权重自己下载；它们的代码、权重、浏览器都不在本包里 | SearXNG：AGPL-3.0；Crawl4AI：Apache-2.0；ImageHash：BSD-2-Clause；OpenCLIP：MIT（权重的许可看所选模型的模型卡）；Openverse 返回的每张图按它来源页的授权。见 [视觉素材](skills/novel-workshop/references/visual-materials.md) |

版权人 2026-11-13 确认：83 张风格卡、两套风格包、分场模块和节拍卡里照录的规范文字、`prose_lint.py` 里照录的词表，以及依据课程和教程材料改写的方法，由版权人本人所写或有权公开，按 MIT 一并发布。[详细来源记录](skills/novel-workshop/assets/third-party/SOURCE-NOTES.md)逐条记着每样材料是怎样收进来的。本说明不增加或替代第三方许可，也不替第三方权利人授予他们没有给出的权利；MIT 许可不涉及风格卡、来源记录里提到的作家、作品和品牌本身的任何权利。

包内不含课程截图、课程全文、私人小说正文、个人项目记录、账户或 API 密钥。AI 平台、模型或外部服务不随本包提供；它们的账户、费用和使用条款由相应提供方确定。

r4 起新增的标点模块、交付门卡、事实账模板、`punctuation_lint.py`、`fact_guard.py`、`darwin_eval.py` 与 `tests/`，以及 r5 新增的工坊宪法、规则登记表、`delivery_manifest.py`、`workflow_demo.py` 和几份模板，由制作方和作者委托的另一条开发线（r4.2、r4.3）编写，只用 Python 标准库，没有引入第三方代码。r5.35 新增的 `inspiration_write.py`、`visual_materials_cli.py` 和 `scripts/visual_materials/` 由制作方新写，本身只用 Python 标准库；解码图片要 Pillow，去重、排序、读网页分别调用使用者自己装的 ImageHash、OpenCLIP、Crawl4AI，没有把它们的代码拷进本包。r5.45 新增的 `style_cards.py` 由制作方新写，只用 Python 标准库。r5.55 新增的“从改稿记录里学编辑判断”一页和它的模板由制作方新写，没有脚本。这些都按本包的 MIT 许可。

合并候选还把技能图标 `assets/icon.svg` 从铅笔换成了心形；合并候选没有记录换图的出处。

附带的 MIT 版权与许可通知应随对应组件一同保留。工坊脚本导出的 sale 模式控制文件范围和资源完整性，不是权利认证。

#!/usr/bin/env python3
"""r5.56: the author's correction records live in the skill folder again and travel with it.

The author decided on 2026-11-14 that the correction records stay where the personal build has always kept them,
in the skill folder under assets/project-packs/_author/, for the personal and the commercial build alike. The
commercial package itself ships nothing there; the workshop creates the two files in the user's own skill folder
once the author turns the records on. Two tools had to follow:

- install.py --upgrade moved the whole installed version into the backup folder and put the new one in its place,
  so the new version had no assets/project-packs/ and the user's records were left behind in the backup. Now the
  installed assets/project-packs/ is copied into the new version first, each file checked by its SHA-256. A file the
  new package also ships under the same name, with different content (a personal build does that), is never
  settled silently: by default the installer stops before it changes anything and lists those files, and
  --keep installed or --keep package chooses a side; --dry-run lists what would be carried and what differs. The
  check after installing and the "already this version" judgment count the user's files: extra records neither
  fail the check nor make the same version look like one to upgrade. A failure still puts the old version back
  whole. Someone who uploads the package folder by hand and has Python can let install.py do the copying by
  giving it the folder that holds the old skill folder as --dest (tested below); without Python the folder is
  copied by hand, as the pages say.
- export_portable.py --include-projects required assets/project-packs/index.md, so a user who had only turned the
  records on and kept no project files could not export them. The records now go with --include-projects without
  an index; other project files still need the index. Nothing under assets/project-packs/ is exported by default,
  a sale export never carries it, and the single file never expands it.

The review of r5.56 found more, each tested below before it was fixed: a package with the installed program files
(a personal build over the commercial one) never installed its own files under assets/project-packs/, and a
differing one was kept from the installed side without a word; a record written into the new version after it was
put in place was deleted when the run was undone; a removal that failed while undoing left half a new version in
place; a Windows junction was followed like a folder; names differing only in letter case were not a conflict; the
exporter ended with a traceback on a record that links out of the skill folder; and some messages did not say
enough.

Each fixture package here is built from scratch with its own manifest, so these tests do not depend on the
package's PACKAGE-MANIFEST.json or single file being current.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
import zipfile

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
PACKS = "assets/project-packs/"
REGISTER = PACKS + "_author/correction-register.md"
HISTORY = PACKS + "_author/correction-history.md"
BACKUPS = ".novel-workshop-backups"

# Neutral wording made up for the tests; no book, character or author's words.
REGISTER_TEXT = "# 作者改法累计\n\n- 已确认：同一段里不连用两个感叹号。\n- 待确认：对白后面少跟解释。\n"
HISTORY_TEXT = "# 改法证据与变更历史\n\n- 第一次：作者把“他非常生气”改成了动作。\n"
BOOK_TEXT = "# 一本新书\n\n人物表还没写。\n"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.encode("utf-8"))


def tree(folder):
    """Every file under folder (hidden folders included) with its bytes."""
    folder = Path(folder)
    if not folder.exists():
        return {}
    return {p.relative_to(folder).as_posix(): p.read_bytes() for p in sorted(folder.rglob("*")) if p.is_file()}


def load_installer():
    spec = importlib.util.spec_from_file_location("install_r556", ROOT / "install.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_exporter():
    spec = importlib.util.spec_from_file_location("export_portable_r556", SKILL / "scripts" / "export_portable.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class InstallerFixture(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        self.dest = self.dir / "skills"

    def tearDown(self):
        shutil.rmtree(self.dir)

    def package(self, name, workshop, packs=None, darwin="维护 同一版"):
        """A package with this release's install.py; packs are files the package itself ships under project-packs."""
        root = self.dir / name
        files = {"skills/novel-workshop/SKILL.md": "工坊 " + workshop,
                 "skills/novel-workshop/references/method.md": "方法 " + workshop,
                 "skills/darwin-novel-workshop/SKILL.md": darwin}
        for relative, text in (packs or {}).items():
            files["skills/novel-workshop/" + PACKS + relative] = text
        for relative, text in files.items():
            write(root / relative, text)
        shutil.copy2(ROOT / "install.py", root / "install.py")
        manifest = {"schema_version": 1, "version": name,
                    "files": {r: sha((root / r).read_bytes()) for r in sorted(files)},
                    "components": {"novel-workshop": {"path": "skills/novel-workshop"},
                                   "darwin-novel-workshop": {"path": "skills/darwin-novel-workshop"}}}
        (root / "PACKAGE-MANIFEST.json").write_bytes(json.dumps(manifest, ensure_ascii=False).encode("utf-8"))
        return root

    def run_installer(self, package, *args, dest=None):
        proc = subprocess.run([sys.executable, "-I", "-B", str(package / "install.py"), "--dest", str(dest or self.dest),
                               *args], capture_output=True, text=True, encoding="utf-8", cwd=str(self.dir))
        return proc.returncode, proc.stdout, proc.stderr

    def skill(self):
        return self.dest / "novel-workshop"

    def add_records(self, folder=None, register=REGISTER_TEXT):
        folder = folder or self.skill()
        write(folder / REGISTER, register)
        write(folder / HISTORY, HISTORY_TEXT)
        write(folder / (PACKS + "new-book/project.md"), BOOK_TEXT)

    def entries(self, out):
        return {s["name"]: s for s in json.loads(out)["skills"]}

    def leftovers(self):
        """Lock or staging folders an interrupted run would leave in the destination."""
        return sorted(p.name for p in self.dest.iterdir() if p.name.startswith(".novel-workshop-")
                      and p.name != BACKUPS)


class UpgradeCarriesTheUsersFiles(InstallerFixture):
    def test_the_installed_project_packs_go_into_the_new_version(self):
        old, new = self.package("old", "旧版"), self.package("new", "新版")
        self.assertEqual(self.run_installer(old)[0], 0)
        self.add_records()
        installed = tree(self.skill())
        code, out, err = self.run_installer(new, "--upgrade")
        self.assertEqual(code, 0, err)
        entry = self.entries(out)["novel-workshop"]
        self.assertEqual(entry["action"], "upgrade")
        self.assertEqual(entry["carried"], sorted([REGISTER, HISTORY, PACKS + "new-book/project.md"]))
        self.assertEqual(entry["conflicts"], [])
        now = tree(self.skill())
        self.assertEqual((now["SKILL.md"], now["references/method.md"]), ("工坊 新版".encode(), "方法 新版".encode()))
        for name in (REGISTER, HISTORY, PACKS + "new-book/project.md"):
            self.assertEqual(now[name], installed[name], name)
        self.assertEqual(set(now), set(installed))
        # The backup still holds the old version whole, records included.
        backup = Path(json.loads(out)["backup"])
        self.assertEqual(tree(backup / "novel-workshop"), installed)
        self.assertEqual(self.leftovers(), [])

    def test_the_same_version_with_records_is_unchanged_and_left_alone(self):
        new = self.package("new", "新版")
        self.assertEqual(self.run_installer(new)[0], 0)
        self.add_records()
        installed = tree(self.dest)
        for args in ((), ("--upgrade",)):
            code, out, err = self.run_installer(new, *args)
            self.assertEqual(code, 0, (args, err))
            self.assertEqual({n: s["action"] for n, s in self.entries(out).items()},
                             {"novel-workshop": "unchanged", "darwin-novel-workshop": "unchanged"}, args)
            self.assertNotIn("backup", json.loads(out), args)
            self.assertEqual(tree(self.dest), installed, args)

    def test_records_do_not_fail_the_check_when_only_another_skill_is_upgraded(self):
        # The check after installing ran over every skill; the unchanged workshop with records failed it.
        old = self.package("old", "新版", darwin="维护 旧版")
        new = self.package("new", "新版", darwin="维护 新版")
        self.assertEqual(self.run_installer(old)[0], 0)
        self.add_records()
        records = tree(self.skill())
        code, out, err = self.run_installer(new, "--upgrade")
        self.assertEqual(code, 0, err)
        self.assertEqual({n: s["action"] for n, s in self.entries(out).items()},
                         {"novel-workshop": "unchanged", "darwin-novel-workshop": "upgrade"})
        self.assertEqual(tree(self.skill()), records)
        self.assertEqual((self.dest / "darwin-novel-workshop" / "SKILL.md").read_bytes(), "维护 新版".encode())

    def test_a_package_file_with_the_same_content_is_not_a_conflict(self):
        old = self.package("old", "旧版")
        new = self.package("new", "新版", packs={"_author/correction-register.md": REGISTER_TEXT})
        self.assertEqual(self.run_installer(old)[0], 0)
        self.add_records()
        code, out, err = self.run_installer(new, "--upgrade")
        self.assertEqual(code, 0, err)
        entry = self.entries(out)["novel-workshop"]
        self.assertEqual(entry["conflicts"], [])
        self.assertEqual((self.skill() / REGISTER).read_bytes(), REGISTER_TEXT.encode())

    def test_files_only_the_new_package_ships_are_installed_beside_the_carried_ones(self):
        old = self.package("old", "旧版")
        new = self.package("new", "新版", packs={"index.md": "# 作品目录\n"})
        self.assertEqual(self.run_installer(old)[0], 0)
        self.add_records()
        code, out, err = self.run_installer(new, "--upgrade")
        self.assertEqual(code, 0, err)
        now = tree(self.skill())
        self.assertEqual(now[PACKS + "index.md"], "# 作品目录\n".encode())
        self.assertEqual(now[REGISTER], REGISTER_TEXT.encode())
        self.assertNotIn(PACKS + "index.md", self.entries(out)["novel-workshop"]["carried"])

    def test_records_copied_into_the_package_folder_are_named_not_installed(self):
        # The package folder must hold exactly the listed files; records copied into it by hand (as for a folder
        # uploaded by hand) are not installed, and the message says which files and what to do.
        new = self.package("new", "新版")
        self.add_records(new / "skills" / "novel-workshop")
        code, out, err = self.run_installer(new)
        self.assertEqual(code, 1, out + err)
        self.assertIn(REGISTER, err)
        self.assertIn("not part of the package", err)
        self.assertFalse(self.dest.exists())

    def test_a_long_list_of_copied_files_is_cut_short(self):
        # A book copied into the package folder can be hundreds of files; the message names the first 20.
        new = self.package("new", "新版")
        for n in range(25):
            write(new / "skills" / "novel-workshop" / (PACKS + "new-book/ch%02d.md" % n), BOOK_TEXT)
        code, out, err = self.run_installer(new)
        self.assertEqual(code, 1, out + err)
        self.assertIn(PACKS + "new-book/ch19.md", err)
        self.assertNotIn(PACKS + "new-book/ch20.md", err)
        self.assertIn("25 files", err)

    def test_a_package_file_under_project_packs_written_over_is_explained(self):
        # Copying an installed project-packs over a personal build's own one changes the package's files; the
        # message says what happened rather than only "missing or changed".
        new = self.package("new", "新版", packs={"_author/correction-register.md": "# 包里的那一份\n"})
        write(new / "skills" / "novel-workshop" / REGISTER, REGISTER_TEXT)
        code, out, err = self.run_installer(new)
        self.assertEqual(code, 1, out + err)
        self.assertIn("skills/novel-workshop/" + REGISTER, err)
        self.assertIn("as it was unpacked", err)
        self.assertIn("--upgrade", err)
        self.assertFalse(self.dest.exists())

    def test_a_fresh_install_of_a_package_with_project_files_still_installs_them(self):
        new = self.package("new", "新版", packs={"_author/correction-register.md": REGISTER_TEXT})
        code, out, err = self.run_installer(new)
        self.assertEqual(code, 0, err)
        self.assertEqual(self.entries(out)["novel-workshop"]["action"], "install")
        self.assertEqual((self.skill() / REGISTER).read_bytes(), REGISTER_TEXT.encode())


class ConflictsStopUntilASideIsChosen(InstallerFixture):
    def setUp(self):
        super().setUp()
        self.old = self.package("old", "旧版")
        self.new = self.package("new", "新版", packs={"_author/correction-register.md": "# 包里的那一份\n",
                                                      "index.md": "# 作品目录\n"})
        self.assertEqual(self.run_installer(self.old)[0], 0)
        self.add_records()
        self.before = tree(self.dest)

    def test_by_default_nothing_is_changed_and_the_files_are_listed(self):
        code, out, err = self.run_installer(self.new, "--upgrade")
        self.assertEqual(code, 1, out + err)
        self.assertIn(REGISTER, err)
        self.assertIn("--keep installed", err)
        self.assertIn("--keep package", err)
        self.assertEqual(tree(self.dest), self.before)
        self.assertFalse((self.dest / BACKUPS).exists())
        self.assertEqual(self.leftovers(), [])

    def test_a_dry_run_lists_what_would_be_carried_and_what_differs(self):
        code, out, err = self.run_installer(self.new, "--upgrade", "--dry-run")
        self.assertEqual(code, 1, out + err)  # a real run would stop
        report = json.loads(out)
        entry = {s["name"]: s for s in report["skills"]}["novel-workshop"]
        self.assertEqual(entry["conflicts"], [REGISTER])
        self.assertEqual(entry["carried"], sorted([HISTORY, PACKS + "new-book/project.md"]))
        self.assertIn("--keep", report["would_stop"])
        self.assertIn(REGISTER, err)
        self.assertEqual(tree(self.dest), self.before)
        for keep, carried in (("installed", [REGISTER, HISTORY, PACKS + "new-book/project.md"]),
                              ("package", [HISTORY, PACKS + "new-book/project.md"])):
            code, out, err = self.run_installer(self.new, "--upgrade", "--dry-run", "--keep", keep)
            self.assertEqual(code, 0, err)
            report = json.loads(out)
            entry = {s["name"]: s for s in report["skills"]}["novel-workshop"]
            self.assertEqual((entry["conflicts"], entry["carried"], entry["keep"]), ([REGISTER], sorted(carried), keep))
            self.assertNotIn("would_stop", report)
            self.assertEqual(tree(self.dest), self.before)

    def test_keep_installed_carries_the_users_copy(self):
        code, out, err = self.run_installer(self.new, "--upgrade", "--keep", "installed")
        self.assertEqual(code, 0, err)
        now = tree(self.skill())
        self.assertEqual(now[REGISTER], REGISTER_TEXT.encode())
        self.assertEqual(now[PACKS + "index.md"], "# 作品目录\n".encode())  # no conflict: installed from the package
        self.assertEqual(now["SKILL.md"], "工坊 新版".encode())
        self.assertEqual(self.entries(out)["novel-workshop"]["keep"], "installed")

    def test_keep_package_installs_the_packages_copy_and_the_users_stays_in_the_backup(self):
        code, out, err = self.run_installer(self.new, "--upgrade", "--keep", "package")
        self.assertEqual(code, 0, err)
        now = tree(self.skill())
        self.assertEqual(now[REGISTER], "# 包里的那一份\n".encode())
        self.assertEqual(now[HISTORY], HISTORY_TEXT.encode())  # no conflict: still carried
        backup = Path(json.loads(out)["backup"])
        self.assertEqual((backup / "novel-workshop" / REGISTER).read_bytes(), REGISTER_TEXT.encode())

    def test_a_file_where_the_other_side_has_a_folder_is_a_conflict(self):
        new = self.package("new2", "新版", packs={"new-book/project.md/notes.md": "# 另一份\n"})
        code, out, err = self.run_installer(new, "--upgrade")
        self.assertEqual(code, 1, out + err)
        self.assertIn(PACKS + "new-book/project.md", err)
        self.assertEqual(tree(self.dest), self.before)
        code, out, err = self.run_installer(new, "--upgrade", "--keep", "installed")
        self.assertEqual(code, 0, err)
        self.assertEqual((self.skill() / PACKS / "new-book/project.md").read_bytes(), BOOK_TEXT.encode())

    def test_the_same_version_with_a_different_record_stops_until_a_side_is_chosen(self):
        # Installing a personal build again after the records grew: the program files are this version. Until the
        # review of r5.56 the run ended with exit code 0 and kept the installed copy without a word on stderr (only
        # the JSON listed it under left_as_installed), and --upgrade --keep package was ignored. That settled a
        # differing file silently, which the 11-14 decision rules out, so the same version now stops as an upgrade
        # does, and --keep chooses: "installed" leaves everything as it is and says on stderr which of this
        # package's files were not installed; "package" backs up the installed version and installs this package's
        # copies, the way an upgrade does.
        self.assertEqual(self.run_installer(self.new, "--upgrade", "--keep", "installed")[0], 0)
        installed = tree(self.dest)
        for args in ((), ("--upgrade",), ("--upgrade", "--dry-run")):
            code, out, err = self.run_installer(self.new, *args)
            self.assertEqual(code, 1, (args, out + err))
            self.assertIn(REGISTER, err, args)
            self.assertIn("--keep installed", err, args)
            self.assertIn("--keep package", err, args)
            self.assertEqual(tree(self.dest), installed, args)
        code, out, err = self.run_installer(self.new, "--upgrade", "--keep", "installed")
        self.assertEqual(code, 0, err)
        entry = self.entries(out)["novel-workshop"]
        self.assertEqual(entry["action"], "unchanged")
        self.assertEqual(entry["left_as_installed"], [REGISTER])
        self.assertNotIn("added", entry)
        self.assertEqual(tree(self.dest), installed)
        self.assertIn(REGISTER, err)  # named on stderr too, with where this package's copy is
        self.assertIn(str(self.new / "skills" / "novel-workshop" / REGISTER), err)
        code, out, err = self.run_installer(self.new, "--upgrade", "--keep", "package")
        self.assertEqual(code, 0, err)
        entry = self.entries(out)["novel-workshop"]
        self.assertEqual((entry["action"], entry["conflicts"], entry["keep"]), ("upgrade", [REGISTER], "package"))
        self.assertEqual((self.skill() / REGISTER).read_bytes(), "# 包里的那一份\n".encode())
        self.assertEqual((self.skill() / HISTORY).read_bytes(), HISTORY_TEXT.encode())
        backup = Path(json.loads(out)["backup"])
        self.assertEqual((backup / "novel-workshop" / REGISTER).read_bytes(), REGISTER_TEXT.encode())

    def test_differing_kinds_are_told_apart(self):
        # A file on one side where the other has a folder is not "different content" (r5.56 review F8).
        new = self.package("new2", "新版", packs={"new-book/project.md/notes.md": "# 另一份\n"})
        code, out, err = self.run_installer(new, "--upgrade")
        self.assertEqual(code, 1, out + err)
        line = next(l for l in err.splitlines() if l.strip().startswith(PACKS + "new-book/project.md"))
        self.assertIn("folder", line)
        self.assertNotIn("different content", line)

    def test_the_help_explains_the_choice(self):
        proc = subprocess.run([sys.executable, "-I", "-B", str(ROOT / "install.py"), "--help"],
                              capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(proc.returncode, 0, proc.stderr)
        text = "".join(proc.stdout.split())  # the help is wrapped to the terminal's width, even inside a path
        for phrase in ("--keep{installed,package}", "assets/project-packs/", "backup", "--dry-run"):
            self.assertIn(phrase, text)


class TheSameProgramWithFilesTheInstalledCopyLacks(InstallerFixture):
    """r5.56 review F1: a personal build whose program files are those of the installed commercial build.

    The installed version counted as this version, so nothing was written: the personal build's own files under
    assets/project-packs/ were never installed, with or without --upgrade (and --keep package), exit code 0 and
    nothing on stderr. Files the installed copy does not have, and that clash with nothing there, are now installed
    beside the user's files, each checked by its hash; nothing else is touched and no backup is made."""

    PACKS_SHIPPED = {"_author/correction-register.md": REGISTER_TEXT, "_author/correction-history.md": HISTORY_TEXT}

    def setUp(self):
        super().setUp()
        self.commercial = self.package("commercial", "新版")
        self.personal = self.package("personal", "新版", packs=self.PACKS_SHIPPED)

    def test_they_are_installed_with_or_without_upgrade(self):
        for n, args in enumerate(((), ("--upgrade",), ("--upgrade", "--keep", "package"))):
            dest = self.dir / ("skills%d" % n)
            self.assertEqual(self.run_installer(self.commercial, dest=dest)[0], 0)
            write(dest / "novel-workshop" / (PACKS + "new-book/project.md"), BOOK_TEXT)  # the user's own file
            before = tree(dest)
            code, out, err = self.run_installer(self.personal, "--dry-run", *args, dest=dest)
            self.assertEqual(code, 0, (args, err))
            entry = self.entries(out)["novel-workshop"]
            self.assertEqual((entry["action"], entry["added"]), ("unchanged", [HISTORY, REGISTER]), args)
            self.assertEqual(tree(dest), before, args)  # a dry run writes nothing
            code, out, err = self.run_installer(self.personal, *args, dest=dest)
            self.assertEqual(code, 0, (args, err))
            entry = self.entries(out)["novel-workshop"]
            self.assertEqual((entry["action"], entry["added"]), ("unchanged", [HISTORY, REGISTER]), args)
            self.assertNotIn("backup", json.loads(out), args)
            now = tree(dest)
            self.assertEqual(now, {**before, "novel-workshop/" + REGISTER: REGISTER_TEXT.encode(),
                                   "novel-workshop/" + HISTORY: HISTORY_TEXT.encode()}, args)
            self.assertEqual(sorted(p.name for p in dest.iterdir()), ["darwin-novel-workshop", "novel-workshop"], args)
            # Installed now: running it again adds nothing.
            code, out, err = self.run_installer(self.personal, *args, dest=dest)
            self.assertEqual(code, 0, (args, err))
            self.assertNotIn("added", self.entries(out)["novel-workshop"], args)

    def test_a_missing_file_beside_a_differing_one(self):
        self.assertEqual(self.run_installer(self.commercial)[0], 0)
        write(self.skill() / REGISTER, "# 自己的一份\n")
        before = tree(self.dest)
        code, out, err = self.run_installer(self.personal)
        self.assertEqual(code, 1, out + err)
        self.assertIn(REGISTER, err)
        self.assertEqual(tree(self.dest), before)
        code, out, err = self.run_installer(self.personal, "--upgrade", "--keep", "installed")
        self.assertEqual(code, 0, err)
        entry = self.entries(out)["novel-workshop"]
        self.assertEqual((entry["added"], entry["left_as_installed"]), ([HISTORY], [REGISTER]))
        self.assertEqual((self.skill() / REGISTER).read_bytes(), "# 自己的一份\n".encode())
        self.assertEqual((self.skill() / HISTORY).read_bytes(), HISTORY_TEXT.encode())

    def test_a_failure_while_adding_removes_only_what_this_run_wrote(self):
        installer = load_installer()
        self.assertEqual(self.run_installer(self.commercial)[0], 0)
        before = tree(self.dest)
        real = installer.sha256

        def wrong_after_writing(path):
            if Path(path) == self.skill() / REGISTER:
                return "0" * 64  # the check after writing it sees the wrong content
            return real(path)

        with mock.patch.object(installer, "sha256", wrong_after_writing):
            with self.assertRaises(ValueError):
                installer.install(self.personal, self.dest)
        self.assertEqual(tree(self.dest), before)
        self.assertFalse((self.skill() / "assets").exists())  # the folders this run made are gone too
        self.assertEqual(self.leftovers(), [])


class FailuresPutTheOldVersionBackWhole(InstallerFixture):
    def setUp(self):
        super().setUp()
        self.installer = load_installer()
        self.old, self.new = self.package("old", "旧版"), self.package("new", "新版")
        self.assertEqual(self.run_installer(self.old)[0], 0)
        self.add_records()
        self.before = tree(self.skill())

    def test_a_failure_while_placing_the_new_version(self):
        real = os.rename

        def failing(source, target):
            if Path(source).parent.name.startswith(".novel-workshop-stage-"):
                raise OSError("simulated failure while placing the new version")
            return real(source, target)

        with mock.patch.object(self.installer.os, "rename", failing):
            with self.assertRaises(OSError):
                self.installer.install(self.new, self.dest, upgrade=True)
        self.assertEqual(tree(self.skill()), self.before)
        self.assertEqual(tree(self.dest / BACKUPS), {})
        self.assertEqual(self.leftovers(), [])

    def test_a_record_written_while_installing_stops_the_run(self):
        # Each carried file is checked against the hash taken when the plan was made.
        real = shutil.copytree
        skill = self.skill()

        def copy_then_the_record_changes(*args, **kwargs):
            result = real(*args, **kwargs)
            write(skill / REGISTER, REGISTER_TEXT + "- 待确认：新记下的一条。\n")
            return result

        with mock.patch.object(self.installer.shutil, "copytree", copy_then_the_record_changes):
            with self.assertRaises(ValueError) as caught:
                self.installer.install(self.new, self.dest, upgrade=True)
        self.assertIn("changed while installing", str(caught.exception))
        now = tree(skill)
        self.assertEqual(now["SKILL.md"], "工坊 旧版".encode())
        self.assertEqual(now[REGISTER], (REGISTER_TEXT + "- 待确认：新记下的一条。\n").encode())
        self.assertEqual(tree(self.dest / BACKUPS), {})
        self.assertEqual(self.leftovers(), [])

    def test_an_unknown_choice_is_refused_before_anything_is_written(self):
        with self.assertRaises(ValueError):
            self.installer.install(self.new, self.dest, upgrade=True, keep="both")
        self.assertEqual(tree(self.skill()), self.before)

    def test_a_program_file_changed_while_installing_stops_the_run(self):
        # The installed version must still be the one the plan was made from before it goes into the backup.
        real = shutil.copytree

        def copy_then_the_skill_changes(*args, **kwargs):
            result = real(*args, **kwargs)
            write(self.skill() / "references/method.md", "方法 自己改过")
            return result

        with mock.patch.object(self.installer.shutil, "copytree", copy_then_the_skill_changes):
            with self.assertRaises(ValueError) as caught:
                self.installer.install(self.new, self.dest, upgrade=True)
        self.assertIn("Installed skill changed while installing", str(caught.exception))
        self.assertEqual(tree(self.skill()), {**self.before, "references/method.md": "方法 自己改过".encode()})
        self.assertEqual(tree(self.dest / BACKUPS), {})
        self.assertEqual(self.leftovers(), [])

    def test_a_record_written_after_the_new_version_is_placed_is_kept(self):
        # r5.56 review F2: the new version was in place, the workshop wrote a record into it, the check after
        # installing failed, and undoing the run deleted the new version with that record in it. The new version is
        # now kept in the backup folder when it is not exactly what this run placed, and the message says where.
        line = "- 待确认：升级途中新记下的一条。\n"
        real = os.rename

        def place_then_write(source, target):
            result = real(source, target)
            if Path(source).parent.name.startswith(".novel-workshop-stage-") and Path(target) == self.skill():
                record = Path(target) / REGISTER
                record.write_bytes(record.read_bytes() + line.encode("utf-8"))
            return result

        with mock.patch.object(self.installer.os, "rename", place_then_write):
            with self.assertRaises(ValueError) as caught:
                self.installer.install(self.new, self.dest, upgrade=True)
        self.assertEqual(tree(self.skill()), self.before)  # the old version is back whole
        holders = [p for p in self.dest.rglob("correction-register.md") if line in p.read_text(encoding="utf-8")]
        self.assertEqual(len(holders), 1, holders)
        kept = holders[0].parents[3]
        self.assertEqual(kept.parent.parent, self.dest / BACKUPS)
        message = str(caught.exception)
        self.assertIn(str(kept), message)
        self.assertIn(PACKS, message)
        self.assertEqual(self.leftovers(), [])

    def test_a_removal_that_fails_while_undoing_leaves_no_half_version_in_place(self):
        # r5.56 review F3 (already so in r5.55): undoing the run, removing the new version failed half way (a file
        # held open on Windows), the error went straight out, and the old version stayed in the backup while half of
        # the new one stood in its place. Each step of undoing now goes on after a failure: what cannot be removed is
        # moved into the backup folder, the old version goes back, and the message says where everything is.
        real_rmtree, real_files = shutil.rmtree, self.installer.regular_files
        darwin = self.dest / "darwin-novel-workshop"

        def stubborn(path, *args, **kwargs):
            if Path(path) == self.skill():
                (Path(path) / "SKILL.md").unlink()
                raise PermissionError(13, "simulated: file in use", str(Path(path) / "references"))
            return real_rmtree(path, *args, **kwargs)

        def darwin_check_fails(root):
            files = real_files(root)
            return {} if Path(root) == darwin and (self.dest / BACKUPS).exists() else files

        with mock.patch.object(self.installer.shutil, "rmtree", stubborn), \
                mock.patch.object(self.installer, "regular_files", darwin_check_fails):
            with self.assertRaises(ValueError) as caught:
                self.installer.install(self.new, self.dest, upgrade=True)
        self.assertEqual(tree(self.skill()), self.before)  # the old version is back, records included
        message = str(caught.exception)
        backups = list((self.dest / BACKUPS).iterdir())
        self.assertEqual(len(backups), 1)
        self.assertIn(str(backups[0]), message)
        self.assertIn("simulated: file in use", message)
        self.assertIn("Installed content verification failed", message)
        self.assertEqual(self.leftovers(), [])

    def test_read_only_files_are_removed_when_undoing(self):
        # copy2 keeps a read-only attribute; on Windows rmtree cannot remove such a file without clearing it first.
        folder = self.dir / "read-only"
        write(folder / "inner" / "record.md", REGISTER_TEXT)
        os.chmod(folder / "inner" / "record.md", 0o444)
        os.chmod(folder / "inner", 0o555)
        try:
            self.installer.remove_tree(folder)
        finally:
            if folder.exists():
                os.chmod(folder / "inner", 0o755)
        self.assertFalse(folder.exists())

    def test_a_junction_is_refused_like_a_symbolic_link(self):
        # r5.56 review F4: on Windows is_symlink() is False for a directory junction, so a book folder joined into
        # project-packs was followed and copied into the new version as plain files. Python 3.12 has is_junction();
        # it is simulated here (on other systems and older versions the installer reads the reparse tag itself).
        linked = self.skill() / PACKS / "joined-book"
        write(linked / "chapter.md", BOOK_TEXT)
        before = tree(self.dest)

        def is_junction(path):
            return Path(path) == linked

        with mock.patch.object(Path, "is_junction", is_junction, create=True):
            with self.assertRaises(ValueError) as caught:
                self.installer.install(self.new, self.dest, upgrade=True, dry_run=True)
            with self.assertRaises(ValueError):
                self.installer.install(self.new, self.dest, upgrade=True)
        message = str(caught.exception)
        self.assertIn(str(linked), message)
        self.assertIn("junction", message)
        self.assertIn("Nothing was changed", message)
        self.assertEqual(tree(self.dest), before)

    @unittest.skipUnless(hasattr(os, "symlink") and os.name == "posix", "symbolic links are made on POSIX here")
    def test_a_symbolic_link_says_nothing_was_changed_and_what_to_do(self):
        os.symlink("../_author/correction-register.md", self.skill() / PACKS / "new-book" / "link.md")
        for args in (("--upgrade", "--dry-run"), ("--upgrade",), ()):
            code, out, err = self.run_installer(self.new, *args)
            self.assertEqual(code, 1, (args, out + err))
            self.assertIn(str(self.skill() / PACKS / "new-book" / "link.md"), err, args)
            self.assertIn("Nothing was changed", err, args)
            self.assertIn("replace the link", err, args)
        self.assertEqual(sorted(p.name for p in self.dest.iterdir()), ["darwin-novel-workshop", "novel-workshop"])

    def test_names_that_differ_only_in_letter_case_are_a_conflict(self):
        # r5.56 review F5: on Windows and macOS the two names are one file; copying the installed one into the new
        # version wrote over the package's copy and the run stopped at "Staging verification failed".
        new = self.package("new-case", "新版", packs={"_author/correction-register.md": "# 包里的那一份\n"})
        os.rename(self.skill() / REGISTER, self.skill() / (PACKS + "_author/Correction-Register.md"))
        before = tree(self.dest)
        code, out, err = self.run_installer(new, "--upgrade")
        self.assertEqual(code, 1, out + err)
        self.assertIn(PACKS + "_author/Correction-Register.md", err)
        self.assertIn(REGISTER, err)
        self.assertIn("letter case", err)
        self.assertEqual(tree(self.dest), before)
        code, out, err = self.run_installer(new, "--upgrade", "--keep", "installed")
        self.assertEqual(code, 0, err)
        names = {p.name for p in (self.skill() / PACKS / "_author").iterdir()}
        self.assertEqual(names, {"Correction-Register.md", "correction-history.md"})


class RollingBack(InstallerFixture):
    def test_this_installer_carries_the_records_back_into_an_older_version_too(self):
        # Rolling back with a package whose install.py is this release's (or later): the records come along, and the
        # newer version is kept whole in the backup. With r5.55 or an earlier installer they stay in the backup only,
        # under <time>/novel-workshop/assets/project-packs/ (that installer is not part of this package).
        old, new = self.package("old", "旧版"), self.package("new", "新版")
        self.assertEqual(self.run_installer(new)[0], 0)
        self.add_records()
        newer = tree(self.skill())
        code, out, err = self.run_installer(old, "--upgrade")
        self.assertEqual(code, 0, err)
        now = tree(self.skill())
        self.assertEqual(now["SKILL.md"], "工坊 旧版".encode())
        self.assertEqual(now[REGISTER], REGISTER_TEXT.encode())
        self.assertEqual(tree(Path(json.loads(out)["backup"]) / "novel-workshop"), newer)


class UploadingTheFolderByHand(InstallerFixture):
    def test_the_old_packages_skills_folder_can_be_the_destination(self):
        # Someone who uploads the skill folder by hand and has Python: point --dest at the folder that holds the old
        # novel-workshop folder (here the unpacked old package's skills/). The new version, with the records copied
        # over and checked, is then in that same place, ready to upload; the old version is in the backup folder.
        old, new = self.package("old", "旧版"), self.package("new", "新版")
        folder = old / "skills"
        self.add_records(folder / "novel-workshop")
        records = {k: v for k, v in tree(folder / "novel-workshop").items() if k.startswith(PACKS)}
        code, out, err = self.run_installer(new, "--upgrade", dest=folder)
        self.assertEqual(code, 0, err)
        now = tree(folder / "novel-workshop")
        self.assertEqual(now, {**tree(new / "skills" / "novel-workshop"), **records})
        backup = Path(json.loads(out)["backup"])
        self.assertEqual(backup.parent, folder / BACKUPS)
        self.assertEqual(sorted(p.name for p in folder.iterdir()), [BACKUPS, "darwin-novel-workshop", "novel-workshop"])


class Exports(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.exporter = load_exporter()

    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        self.skill = self.dir / "novel-workshop"
        shutil.copytree(SKILL, self.skill, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo", "project-packs"))
        # Only the records: the author turned them on and keeps no project files here (no index.md).
        write(self.skill / REGISTER, REGISTER_TEXT + "标记甲乙丙\n")
        write(self.skill / HISTORY, HISTORY_TEXT + "标记丁戊己\n")

    def tearDown(self):
        shutil.rmtree(self.dir)

    def export(self, name, **options):
        target = self.dir / "out" / name
        self.exporter.export(self.skill, target, **options)
        with zipfile.ZipFile(target) as archive:
            return {n: archive.read(n) for n in archive.namelist()}

    def test_a_personal_export_carries_the_records_without_a_project_index(self):
        for form in ("portable", "install"):
            names = self.export(form + ".zip", include_projects=True, mode="personal", format=form)
            for relative in (REGISTER, HISTORY):
                self.assertEqual(names["novel-workshop/" + relative], (self.skill / relative).read_bytes(), form)

    def test_nothing_under_project_packs_by_default_or_in_a_sale_export(self):
        for options in ({"mode": "personal", "format": "portable"}, {"mode": "personal", "format": "install"},
                        {"mode": "sale", "format": "portable"}, {"mode": "sale", "format": "install"}):
            names = self.export("%(mode)s-%(format)s.zip" % options, **options)
            self.assertEqual([n for n in names if "project-packs" in n], [], options)
        with self.assertRaises(ValueError):
            self.export("sale-projects.zip", include_projects=True, mode="sale")

    def test_the_single_file_does_not_expand_the_records(self):
        plain = self.export("plain.zip")["portable-novel-workshop.md"]
        carried = self.export("carried.zip", include_projects=True)
        single = carried["portable-novel-workshop.md"]
        self.assertEqual(single, plain)
        self.assertNotIn("标记甲乙丙".encode(), single)
        self.assertNotIn("标记丁戊己".encode(), single)
        guide = carried["README.md"].decode("utf-8")
        self.assertIn("_author/", guide)

    def test_other_project_files_still_need_the_project_index(self):
        write(self.skill / (PACKS + "new-book/project.md"), BOOK_TEXT)
        with self.assertRaises(FileNotFoundError):
            self.export("no-index.zip", include_projects=True)
        write(self.skill / (PACKS + "index.md"), "# 作品目录\n")
        names = self.export("with-index.zip", include_projects=True)
        for relative in (REGISTER, HISTORY, PACKS + "new-book/project.md", PACKS + "index.md"):
            self.assertIn("novel-workshop/" + relative, names)

    def test_the_records_go_as_they_are_whatever_they_link_to(self):
        # r5.56 review F7: the archive link check read the records too, so a record linking to a chapter outside the
        # skill folder, to a file that is not there, or a record not in UTF-8 ended the export with a traceback. The
        # records are the workshop's notes for the user, carried byte for byte; their links are not checked.
        for name, data in (("outside", "- 第一次，见[第3章](../../../../../book/ch03.md)。\n".encode("utf-8")),
                           ("missing", "- 第一次，见[笔记](../book/x.md)。\n".encode("utf-8")),
                           ("legacy", "- 第一次。\n".encode("gbk"))):
            (self.skill / HISTORY).write_bytes(data)
            for form in ("portable", "install"):
                names = self.export("%s-%s.zip" % (name, form), include_projects=True, format=form)
                self.assertEqual(names["novel-workshop/" + HISTORY], data, (name, form))

    def test_a_project_file_that_stops_the_export_is_named_without_a_traceback(self):
        # Project files are still checked, as before; the command line now says which file and what to do.
        write(self.skill / (PACKS + "index.md"), "# 作品目录\n")
        script = self.skill / "scripts" / "export_portable.py"
        for text, words in (("见[第一章](../../../../../book/ch01.md)。\n", "../../../../../book/ch01.md"),
                            ("见[笔记](notes.md)。\n", "notes.md")):
            write(self.skill / (PACKS + "new-book/project.md"), text)
            proc = subprocess.run([sys.executable, "-I", "-B", str(script), str(self.dir / "cli.zip"),
                                   "--include-projects"], capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(proc.returncode, 1, proc.stdout + proc.stderr)
            self.assertNotIn("Traceback", proc.stderr)
            self.assertIn(PACKS + "new-book/project.md", proc.stderr)
            self.assertIn(words, proc.stderr)
            self.assertIn("backticks", proc.stderr)
        (self.skill / (PACKS + "new-book/project.md")).write_bytes("见第一章。\n".encode("gbk"))
        proc = subprocess.run([sys.executable, "-I", "-B", str(script), str(self.dir / "cli.zip"), "--include-projects"],
                              capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(proc.returncode, 1, proc.stdout + proc.stderr)
        self.assertNotIn("Traceback", proc.stderr)
        self.assertIn(PACKS + "new-book/project.md", proc.stderr)
        self.assertIn("UTF-8", proc.stderr)
        self.assertFalse((self.dir / "cli.zip").exists())
        self.assertFalse(list(self.skill.rglob("__pycache__")))

    def test_an_empty_project_folder_is_refused(self):
        shutil.rmtree(self.skill / PACKS)
        with self.assertRaises(FileNotFoundError):
            self.export("nothing.zip", include_projects=True)

    def test_the_command_line_says_what_it_left_out(self):
        script = self.skill / "scripts" / "export_portable.py"
        for args, carried in (((), False), (("--include-projects",), True)):
            target = self.dir / "cli" / ("%s.zip" % carried)
            proc = subprocess.run([sys.executable, "-I", "-B", str(script), str(target), *args],
                                  capture_output=True, text=True, encoding="utf-8", cwd=str(self.dir))
            self.assertEqual(proc.returncode, 0, proc.stderr)
            with zipfile.ZipFile(target) as archive:
                self.assertEqual("novel-workshop/" + REGISTER in archive.namelist(), carried)
            if carried:
                self.assertNotIn("--include-projects", proc.stdout + proc.stderr)
            else:
                self.assertIn("assets/project-packs/", proc.stdout + proc.stderr)
                self.assertIn("--include-projects", proc.stdout + proc.stderr)
        self.assertFalse(list(self.skill.rglob("__pycache__")))


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""Validate and select project-scoped writing examples; never mutate the store."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys


STATUSES = {"candidate", "teacher_approved", "author_accepted", "rejected", "retired"}
SPLITS = {"development", "training", "regression", "holdout", "evaluation"}
ELIGIBLE = {"teacher_approved", "author_accepted"}
HELD_OUT = {"holdout", "evaluation"}
LEARNING_START = "<!-- NOVEL_WORKSHOP_LEARNING_START -->"
LEARNING_END = "<!-- NOVEL_WORKSHOP_LEARNING_END -->"


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key: " + key)
        result[key] = value
    return result


def _constant(value):
    raise ValueError("non-finite JSON value: " + value)


def _loads(text):
    return json.loads(text, object_pairs_hook=_pairs, parse_constant=_constant)


def markdown_payload(text):
    """Return the sole learning payload and JSON character span, or reject it.

    The fixed marker block is deliberately stricter than general Markdown. Its
    surrounding text is not parsed or rewritten by the learning-loop writer.
    """
    if text.count(LEARNING_START) != 1 or text.count(LEARNING_END) != 1:
        raise ValueError("Markdown requires exactly one complete learning marker pair")
    start = text.index(LEARNING_START) + len(LEARNING_START)
    end = text.index(LEARNING_END)
    if end < start:
        raise ValueError("Learning markers are reversed")
    block = text[start:end]
    match = re.fullmatch(r"\s*```json[^\S\r\n]*\r?\n(?P<json>.*?)\r?\n```\s*", block, re.DOTALL)
    if match is None:
        raise ValueError("Learning markers must contain one complete JSON fence only")
    payload = _loads(match.group("json"))
    return payload, start + match.start("json"), start + match.end("json")


def load_payload(path):
    """Read the original JSON format or the unique marked Markdown JSON block."""
    text = Path(path).read_bytes().decode("utf-8")
    if Path(path).suffix.lower() in {".md", ".markdown"} or not text.lstrip().startswith("{"):
        return markdown_payload(text)[0]
    return _loads(text)


def digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def validate(payload):
    errors = []
    if not isinstance(payload, dict) or not isinstance(payload.get("data"), dict):
        return ["Expected a project-state object containing data"], {}, {}
    data = payload["data"]
    config = data.get("demonstration_learning", {"enabled": False})
    if not isinstance(config, dict) or type(config.get("enabled")) is not bool:
        errors.append("data.demonstration_learning.enabled must be a boolean")
        config = {"enabled": False}
    cases = data.get("demonstrations", {})
    if not isinstance(cases, dict):
        return errors + ["data.demonstrations must be an object keyed by case id"], {}, config
    for key, case in cases.items():
        prefix = f"case {key}: "
        if not isinstance(case, dict):
            errors.append(prefix + "must be an object")
            continue
        for field in ("id", "project_id", "group_id", "task", "before", "after", "why"):
            if not isinstance(case.get(field), str) or not case[field].strip():
                errors.append(prefix + field + " must be non-empty text")
        if case.get("id") != key:
            errors.append(prefix + "id must match its object key")
        if case.get("status") not in STATUSES:
            errors.append(prefix + "invalid status")
        if case.get("split") not in SPLITS:
            errors.append(prefix + "invalid split")
        for field in ("tags", "decisions", "when", "except"):
            value = case.get(field)
            if not isinstance(value, list) or any(not isinstance(x, str) or not x.strip() for x in value):
                errors.append(prefix + field + " must be an array of non-empty strings")
            elif field in {"decisions", "when"} and not value:
                errors.append(prefix + field + " must not be empty")
        source = case.get("source")
        if not isinstance(source, dict):
            errors.append(prefix + "source must be an object")
        else:
            for field in ("ref", "version", "reviewer", "evidence"):
                if not isinstance(source.get(field), str) or not source[field].strip():
                    errors.append(prefix + "source." + field + " must be non-empty text")
        acceptance = case.get("author_acceptance")
        if case.get("status") == "author_accepted":
            if not isinstance(acceptance, dict) or any(
                not isinstance(acceptance.get(field), str) or not acceptance[field].strip()
                for field in ("quote", "ref")
            ):
                errors.append(prefix + "author_accepted requires an author quote and source ref")
        elif acceptance is not None and not isinstance(acceptance, dict):
            errors.append(prefix + "author_acceptance must be null or an object")
        hashes = case.get("hashes")
        for field in ("before", "after"):
            if isinstance(case.get(field), str):
                if not isinstance(hashes, dict) or hashes.get(field) != digest(case[field]):
                    errors.append(prefix + "hashes." + field + " does not match the text")
    return errors, cases, config


def select(cases, project_id, task, tags, excluded, limit):
    project_cases = [c for c in cases.values() if c["project_id"] == project_id]
    held = [c for c in project_cases if c["split"] in HELD_OUT or c["group_id"] in excluded]
    blocked_groups = set(excluded) | {c["group_id"] for c in held}
    blocked_text = {c["hashes"][field] for c in project_cases if c["group_id"] in blocked_groups for field in ("before", "after")}
    eligible = []
    for case in project_cases:
        if case["status"] not in ELIGIBLE or case["split"] in HELD_OUT:
            continue
        if case["group_id"] in blocked_groups or case["task"] != task:
            continue
        if any(case["hashes"][field] in blocked_text for field in ("before", "after")):
            continue
        overlap = len(set(case["tags"]) & set(tags))
        if tags and not overlap:
            continue
        eligible.append((case, overlap))
    eligible.sort(key=lambda item: (
        item[0]["status"] != "author_accepted", -item[1], item[0]["id"]
    ))
    return [case for case, _ in eligible[:limit]]


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    check = commands.add_parser("check")
    check.add_argument("store", type=Path)
    for name in ("index", "select"):
        pick = commands.add_parser(name)
        pick.add_argument("store", type=Path)
        pick.add_argument("--project-id", required=True)
        pick.add_argument("--task", required=True)
        pick.add_argument("--tag", action="append", default=[])
        pick.add_argument("--exclude-group", action="append", default=[])
        pick.add_argument("--evaluation", action="store_true")
        pick.add_argument("--limit", type=int, choices=range(1, 4), default=3)
    args = parser.parse_args(argv)
    if args.command in {"index", "select"} and args.evaluation and not args.exclude_group:
        parser.error("--evaluation requires --exclude-group for the current task group")
    try:
        payload = load_payload(args.store)
        errors, cases, config = validate(payload)
        if errors:
            print(json.dumps({"status": "invalid", "errors": errors}, ensure_ascii=False))
            return 2
        if args.command == "check":
            result = {"status": "valid", "case_count": len(cases), "enabled": config["enabled"],
                      "scope": "structure_and_hashes_only"}
        else:
            owner = payload.get("project_id")
            if owner is not None and owner != args.project_id:
                raise ValueError("Requested project_id differs from the authoritative store")
            selected = select(cases, args.project_id, args.task, args.tag,
                              args.exclude_group, args.limit) if config["enabled"] else []
            if args.command == "index":
                fields = ("id", "project_id", "group_id", "task", "tags", "status", "split")
                selected = [{key: c[key] for key in fields} for c in selected]
            result = {"status": "selected" if config["enabled"] else "disabled",
                      "cases": selected, "count": len(selected),
                      "scope": "metadata_only" if args.command == "index" else "examples_for_context_not_story_facts"}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, TypeError) as exc:
        print(json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    sys.exit(main())

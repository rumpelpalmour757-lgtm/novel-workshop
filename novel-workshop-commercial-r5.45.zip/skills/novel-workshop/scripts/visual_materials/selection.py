"""Step 5: the author's choice, turned into a selection for the inspiration library.

The author says it in their own words ("2 的布局、4 的灯光，1 和 3 不要"); the host assistant writes it as a choice
file: which numbered images, which parts of each (stable, or only this scene), what not to take, how the book changes
it, which numbers are rejected, and the author's words. Only the numbers chosen are adopted and only the parts named:
nothing else in an image goes into the book's records. The selection carries each chosen image's source, licence,
image version and what was seen (from review-record), so the library entry can be checked without the run.

r5.37 (the r5.35 review, point 1): the choice names the bundle the author looked at (bundle_id, at the top of
review.md); a choice for another bundle is refused, because its numbers may now point at other images. An observation
is joined to a number only when it was recorded for this bundle and names this image version (sha256); its sha256 is
never rewritten to fit. The chosen image files must still be the versions in the bundle.

r5.38 (the r5.37 review, point 1.1): the same image again. A chosen number may say mode: add (the author takes these
parts too, besides what the library already holds for this image), replace (only these parts instead) or use (only
use it in this chapter or scene; leave take out). The library writer refuses an image the library already picked when
the choice says no mode, before anything is written, so nobody decides for the author whether "灯光" is added to
"布局" or replaces it.
"""
import urllib.parse

from . import common
from .review import current_bundle

CHOICE_SCHEMA = "visual-choice/1"
SELECTION_SCHEMA = "inspiration-selection/1"


def entry_for(item, observation, request, choice, date):
    provider = item["found_by"][0]["provider"] if item.get("found_by") else ""
    host = urllib.parse.urlsplit(item["page_url"]).hostname or ""
    source = {"type": "link", "url": item["page_url"], "image_url": item["image_url"], "site": host,
              "license": item.get("license") or "未核，只作写作参考", "retrieved": date, "provider": provider}
    if item.get("creator"):
        source["creator"] = item["creator"]
    if item.get("license_url"):
        source["license_url"] = item["license_url"]
    entry = {"id": "VM-" + item["sha256"][:10], "kind": choice.get("kind") or request.get("kind") or "place",
             "title": item.get("title") or "第 %d 张候选" % item["n"], "status": "candidate", "source": source,
             "image": {"sha256": item["sha256"], "width": item["width"], "height": item["height"]}}
    subjects = choice.get("subjects") or request.get("subjects") or []
    if subjects:
        entry["subjects"] = list(subjects)
    if observation and observation.get("scope") in ("original", "thumbnail"):
        entry["observation"] = {"scope": observation["scope"], "image_sha256": observation["sha256"],
                                "seen": observation["seen"], "by": observation["by"],
                                "date": observation.get("date") or date}
        if observation.get("unclear"):
            entry["observation"]["unclear"] = observation["unclear"]
        if observation.get("suggest"):
            entry["suggest"] = observation["suggest"]
        if observation.get("conflicts"):
            entry["conflicts"] = observation["conflicts"]
    else:
        entry["observation"] = {"scope": "none"}
    words = " ".join(x for x in [item.get("page_text") or ""] + ([item["on_page"].get("alt", ""),
                                                                    item["on_page"].get("desc", "")]
                                                                   if item.get("on_page") else []) if x).strip()
    if words:
        entry["page_text"] = words[:500]
    entry.setdefault("conflicts", [])
    entry["use"] = choice.get("use") or ([{"chapter": request["chapter"], "scene": request["scene"]}]
                                         if request.get("chapter") and request.get("scene") else
                                         [{"chapter": request["chapter"]}] if request.get("chapter") else [])
    entry["note"] = "视觉素材运行 %s 的第 %d 张" % (choice.get("run_name", ""), item["n"])
    return entry


def run_select(folder, config, choice_path):
    run = common.Run(folder)
    request = run.manifest()["request"]
    bundle = current_bundle(run)
    bundle_id = bundle["bundle_id"]
    items = {i["n"]: i for i in bundle["items"]}
    choice = common.read_json(choice_path)
    if not isinstance(choice, dict) or choice.get("schema") != CHOICE_SCHEMA:
        raise common.VisualError("the choice is an object with schema %s" % CHOICE_SCHEMA)
    if "withdraw" in choice:
        raise common.VisualError(
            "a choice takes or turns down images of this bundle; taking back an image the library holds, or some of its "
            "parts, is done in the library: inspiration_write.py adopt with a selection whose withdraw lists {id, parts} "
            "(references/inspiration-library.md); nothing written")
    unknown = set(choice) - {"schema", "bundle_id", "decision", "kind", "subjects", "use", "choose", "reject", "note"}
    if unknown:
        raise common.VisualError("unknown choice field(s) %s" % ", ".join(sorted(unknown)))
    if choice.get("bundle_id") != bundle_id:
        raise common.VisualError(
            "the choice names bundle %s, but the run's review bundle is %s: its numbers may point at other images now. "
            "Show the author review/review.md again and write the choice with bundle_id %s" % (
                choice.get("bundle_id") or "(none)", bundle_id, bundle_id))
    observed = {}
    if run.exists("review/observations.recorded.json"):
        recorded = run.load("review/observations.recorded.json")
        if recorded.get("bundle_id") != bundle_id:
            raise common.VisualError("the recorded observations are for bundle %s, not %s: look at this bundle's images "
                                     "and run review-record again (or delete the old record to choose without it)"
                                     % (recorded.get("bundle_id") or "(none)", bundle_id))
        observed = {o["n"]: o for o in recorded["items"]}
    decision = choice.get("decision") or {}
    date = decision.get("date") or common.today()
    choose = choice.get("choose") or []
    reject = choice.get("reject") or []
    if not isinstance(choose, list) or not isinstance(reject, list) or not (choose or reject):
        raise common.VisualError("choose lists the numbers the author takes (with the parts), reject the ones not wanted")
    numbers = [c.get("n") for c in choose if isinstance(c, dict)] + list(reject)
    if len(numbers) != len(set(numbers)):
        raise common.VisualError("a number is both chosen and rejected, or appears twice")
    for n in numbers:
        if n not in items:
            raise common.VisualError("there is no image %r in this run's bundle" % (n,))
        item = items[n]
        if n in observed and observed[n].get("sha256") != item["sha256"]:
            raise common.VisualError("%d: the observation recorded under this number is of another image version; "
                                     "record what is seen in this one" % n)
        on_disk = run.path(item["file"])
        if not on_disk.is_file() or common.sha256_file(on_disk) != item["sha256"]:
            raise common.VisualError("%d: the image file is missing or not the version in the bundle; fetch again and "
                                     "rebuild the bundle" % n)
    run_name = run.folder.name
    adopt, rejected = [], []
    for c in choose:
        unknown = set(c) - {"n", "mode", "take", "skip", "adapt", "subjects", "use", "note"}
        if unknown:
            raise common.VisualError("%s: unknown field(s) %s" % (c.get("n"), ", ".join(sorted(unknown))))
        mode = c.get("mode")
        if mode not in (None, "add", "replace", "use"):
            raise common.VisualError("%s: mode is add (these parts too), replace (only these parts instead) or use (only "
                                     "this chapter or scene) for an image the library already holds" % c.get("n"))
        if mode == "use":
            if "take" in c:
                raise common.VisualError("%s: mode use only adds where the image is used; what is taken stays as the "
                                         "library has it, so leave take out" % c.get("n"))
        elif not (isinstance(c.get("take"), list) and c["take"]):
            raise common.VisualError("%s: take lists the parts the author named (each {part, scope}); nothing is taken "
                                     "that the author did not name" % c.get("n"))
        item = items[c["n"]]
        entry = entry_for(item, observed.get(c["n"]), request, dict(choice, run_name=run_name,
                                                                     subjects=c.get("subjects") or choice.get("subjects"),
                                                                     use=c.get("use") or choice.get("use")), date)
        if mode == "use" and not entry.get("use"):
            raise common.VisualError("%s: mode use needs where it is used: the request's chapter, or use in the choice"
                                     % c.get("n"))
        piece = {"id": entry["id"], "entry": entry}
        if mode:
            piece["mode"] = mode
        if mode != "use":
            piece["take"] = c.get("take")
        if entry.get("use"):
            piece["use"] = entry["use"]
        for key in ("skip", "adapt", "note"):
            if key in c:
                piece[key] = c[key]
        adopt.append(piece)
    for n in reject:
        entry = entry_for(items[n], observed.get(n), request, dict(choice, run_name=run_name), date)
        rejected.append({"id": entry["id"], "entry": entry})
    selection = {"schema": SELECTION_SCHEMA, "decision": decision, "run": run_name, "bundle_id": bundle_id,
                 "adopt": adopt, "reject": rejected}
    outdated = run.outdate("select")
    run.save("selection.json", selection)
    run.step("select", {"status": "ok", "bundle_id": bundle_id, "adopt": [a["id"] for a in adopt],
                        "reject": [r["id"] for r in rejected]})
    return {"status": "ok", "bundle_id": bundle_id, "adopt": [a["id"] for a in adopt],
            "reject": [r["id"] for r in rejected], "selection": str(run.path("selection.json")), "outdated": outdated}

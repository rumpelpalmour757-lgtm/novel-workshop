# 执行检查、范围与恢复

## 选择足够简单的流程

普通短段落走“处理—检查—交付”。整章返修或多章核查先确定单元及真实依赖；资料够用就执行，不为一次润色建立整张工作图。步骤可由单个AI执行，不要求特定产品或多个模型。

项目已开启[学习与自我纠错执行](learning-loop.md)时，用该模块关联本次示范选择、条件取舍、教师反馈、实际返工和当前稿复查；仍沿用本页的范围、预算与四项交付状态，不把学习记录当成新的定稿门。未开启或已停用时照本页原流程执行。

作者开启[每章完整流程与确认](chapter-confirmation.md)时，先读本章当前阶段及确认版本，只执行当前已授权阶段；完整章的材料、方案、写前准备、初稿、审稿修订计划、修订稿和定稿记录逐阶段呈现。恢复不从头重来、不用旧稿确认套新稿。该记录只控制推进，不替换本页四项状态和执行预算。

| 原语 | 在小说任务中的作用 |
| --- | --- |
| NODE | 一个有边界的任务，例如审第5章的衔接或只改一场对白 |
| EDGE | 真正要带过去的原稿、状态、证据或用户决定 |
| STATE | 项目、版本、当前单元、已完成部分、剩余轮次与待办 |
| ROUTER | 简短处理或完整核查；返修、继续、跳过可选项或停止的原因 |
| GATE | 明确条件的实际检查，加上有依据的编辑判断 |

同一章节的空间、人物信息与文风可以分别审，再合并发现；后章依赖前章结果时按顺序处理。独立审查仅在工具可用且已有授权时并行，不自行切换模型、扩大代理数量或安装日程。合并相同单元和位置的同一问题，保留证据与分歧，不能把重复报告当成多票支持。

## 可执行条件

工具见 [workflow_guard.py](../scripts/workflow_guard.py)，仅依赖 Python 3 标准库。它只读原稿、候选稿和声明的条件；状态命令只写指定的工作记录，不修改正文。

在项目根目录并排放 `ch01.checks.json`、`ch01.run.json`，正文可放 `manuscripts/`，资料可放 `sources/`。检查规格中的路径相对 checks 所在目录，状态中的路径相对 state 所在目录；两者都不允许跳出各自目录（含符号链接逃逸）。因此不要把 checks 或 state 放进较深的 `records/ch01/` 再用 `../../manuscripts/` 引用正文。新稿、来源与状态随项目一起迁移。支持的条件如下：

| `type` | 字段 | 实际检查及限制 |
| --- | --- | --- |
| `length` | `min`、`max`，至少一个；可选 `basis`（`non_whitespace` 默认，含标点；`han` 只数汉字）、`exclude_headings`（不数 `#` 标题和“第×章”行） | 按声明的口径计数，结果里写明口径；项目规定的字数口径写进项目配置，不能换口径凑数 |
| `title` | `min`、`max`，可选 `basis` | 章名长度：取第一个非空行，它必须是标题（`#` 开头或“第×章”开头）；去掉 `#` 和章节编号后计数。第一行不是标题就不通过。“楔子”“番外：……”这类不带编号的标题不认，这样的章不声明这一项，章名由人核对 |
| `literal_count` | `text`、`count` | 字面出现次数，按不重叠匹配计算；不判断同义表达 |
| `contains` | `text` | 指定原句或片段是否保留；不保证上下文含义未变 |
| `scope` | `source`、`editable_lines` | 用原稿行号限定可改区间；替换、删除只能触及可改行，插入可发生在可改行的前后间隙（含区间两端） |
| `quote` | `source`、`text`，可加 `line` | 短引能否在来源或指定起始行找到；仍需编辑判断引文是否支持结论 |
| `file_hash` | `source`、`sha256` | 指定文件是否保持原字节；用于作者冻结的章节 |
| `prose` | 可加 `rules`、`paragraph_mode`（blank／line） | 字面复核线索进入审稿裁决，不判定文笔或 AI 来源；默认跑三项分场检测和四项语感扫描（[修改的五道工序](revision-passes.md)第一遍），开关和判法见 [模板腔复核](prose-audit.md)“可选只读检查器” |
| `scene_beats` | `source`（这一章的节拍卡，[分场节拍卡](../assets/scene-beat-card.md)） | 卡上每场有 Scene ID 和 Scene Type；核心博弈戏、动作危机戏把卡填全（核心博弈戏另要道具），Polarity Shift 从一种处境翻到另一种；卡在任务开始时冻结，写完再改要 `replan`。声明了它，审稿记录要为卡上每个核心博弈戏、动作危机戏写 `scenes`，没翻转或低于 3 分不能 PASS，`prose` 检查里三项分场检测在叙述里的命中逐处改写或逐处写理由保留（NWC-1.5）；其他场（Other）填 POV 和 Change，不写 `scenes`。方法见 [分场戏剧张力与正文具象化](scene-dramaturgy.md) |
| `voice_material` | `source`（这一章的声音样本与现场素材卡，[声音样本与现场素材卡](../assets/voice-material-card.md)） | 宪法 CON-012：声音样本写了来源和原文，或者写了为什么没有样本；每个素材块有 Scene ID、看得见摸得到的东西和出处；同一任务声明了节拍卡的，卡上每个核心博弈戏、动作危机戏都有素材块。卡在任务开始时冻结。只核对填没填全，素材好不好、写的时候用没用上靠编辑 |
| `punctuation` | 可选 `rules`（作品标点规则文件） | 对最终候选稿重跑 [标点检查](../scripts/punctuation_lint.py)；没有 ERROR 才通过，REVIEW 提示进入待裁决清单。规则见 [中文标点](chinese-punctuation.md) |
| `facts` | `ledger`、`claims` | 用 [事实核对](../scripts/fact_guard.py) 把 claims 与已采纳事实账对比；claims 必须写明候选稿哈希。冲突（包括人物知情按故事时间比出的先后矛盾）、无依据或引文找不到都不通过；无前文可比、待作者确认的变化、人物知情和证据排不出故事时间的先后、或者证据只有晚于这一场的（待核，r5.51），以及本章提到却没有回应的持续状态（`persist`），进入待裁决清单。方法见 [continuity.md](continuity.md) |
| `revision` | `source`（修订前的原稿），可选 `rules` | 对照原稿和候选稿，只看修订带来的变化：新出现的标点 ERROR 不通过；新出现的复核提示（切碎、短段、段落负担、长段对白）和对白句末标点的改变进入待裁决清单，同一行的几句对白各算一项（编号带行号和列号）。同一句话出现几次时逐句一一对应（只有台词的那一行，按上方以冒号结尾的说话行认，隔着空行也算；没有这样的行时连同紧挨着的上一行认；只写在下一行的说话人不认）；对不上的标为 `uncertain`，同样要裁决。方法见 [编辑](editing.md)“修订前后对照” |

读正文和来源时，文件开头的 BOM 不算字，CRLF 换行和 LF 一样算一行，与标点、文字、事实检查的读法一致；`scope` 逐行比较时不计行尾的换行符。哈希仍按文件字节算：换了换行符或加了 BOM 的文件是另一版，要重新检查、记录（r5.13）。

原稿是截图或照片时，先把字转出来，请作者核对转写，再照常声明检查：这些检查只读文本文件，原稿还是图片的时候一项也跑不了，机器检查照实记 UNTESTED，不能说查过（r5.33）。作者给的场景、人物参考图是写作素材，用法见 [声音样本与现场素材卡](../assets/voice-material-card.md)。

事实账与本轮主张是两种文件。主张可从 [fact-claims-template.json](../assets/fact-claims-template.json) 复制；字段、正文哈希计算和路径区别见连续性模块“当前稿事实主张的文件结构”。模板占位值须按实际正文填写，不能把模板当作可直接通过的测试数据。`facts` 还可声明 `chapters_dir`，见下文。

示例格式（条件从实际请求生成，不照搬示例数值）：

```json
{
  "candidate": "draft.md",
  "checks": [
    {"id": "keep_last_line", "type": "contains", "text": "他把门关上。"},
    {"id": "edit_scope", "type": "scope", "source": "original.md", "editable_lines": [[3, 5]]}
  ]
}
```

`python3 workflow_guard.py check checks.json` 返回逐条期望、实际结果及证据。`GREEN` 是声明条件全通过；`RED` 有条件失败；空清单是 `NOT_APPLICABLE`；声明了检查却没有实际比对任何内容（例如事实检查一条主张都没声明）是 `UNTESTED`。这两种情况在交付状态里都记作 MECHANICAL=UNTESTED，不能说跑过测试。未知检查、无效范围或读不到必需文件返回错误，不能按通过处理。没有 Python 时按同一要求人工核查，并明确核查方式。

`checks.json` 加 `"mode": "strict"`，用于整章、多章或明确要求审稿的任务（SKILL.md 的 L1、L2 任务都用它）。严格模式在 `start`、`replan` 时都要求至少声明一项检查，而且声明的检查都必须实际运行；有一项是 UNTESTED，就不能记 PASS。审稿还要写全六个维度的结论（见下文“审稿的六个维度”）。审稿 PASS 需要引自候选稿的三处不同位置，覆盖候选稿的开头、中段和结尾。计数规则如下：

- 每条短引至少 6 个非空白字符。
- 短引不能重复凑数（去掉空白后相同的算重复），即使填了不同来源也不行。
- 只计在候选稿里只出现一次的短引；反复出现的句子（比如口头禅）位置不唯一，不计。确需引用重复短语时，写 `offset`（从 0 开始的字符位置），工具核对该处原文后计入。
- 互相重叠、互相包含或相距不到 6 个字符的短引算同一处，所以把一句话切成几段引用，只算一处。
- 引自原稿等来源的短引可以作为问题依据，但不计入。
- 候选稿短于 300 个字符时不检查分布。

`review_policy` 可以调整 `min_evidence`、`spread`、`require_independent`、`dimensions`（是否要求六个维度的结论；严格模式默认开，轻量模式默认关，也可以手动打开）。严格模式下只能调严，不能调松：`min_evidence` 不能低于 3，`spread`、`dimensions` 不能关闭。同一个运行里，`replan` 也不能放宽审稿策略：从 strict 改成 light、减少 `min_evidence`、关掉 `spread`、`require_independent` 或 `dimensions` 都会被拒；作者要放宽，就另起一个运行（新的状态文件），让记录从一开始就写明较轻的审稿。`require_independent` 设为 true 时，审稿记录标为 `self_check` 的不能记 PASS；但审稿方式是审稿记录自己填的，脚本无法核实，这一项只能拦住如实标为自查的记录。检查结果中的 `review_items` 是脚本给出的复核项，审稿必须逐条裁决，每个 ID 只能裁决一次。每个复核项的 ID 都不相同；万一两个复核项撞了同一个 ID（比如两条事实主张写了同一个 `id`），`check` 和 `record` 报错拒绝（事实主张报输入错误，其他情况报 `DUPLICATE_REVIEW_ITEM`），不会把它们合并成一项，免得一次裁决盖住两处。`rules`、`ledger` 与 `source` 一样在 `start` 时冻结；`claims` 可随修订更新，但必须绑定当前候选稿的哈希，而且它自身的哈希也进入本次检查记录。

作品有标点规则文件（登记了能力名、面板前缀）时，`punctuation` 检查要带上 `rules`。不带规则文件，`【定。】` 这类能力名错误只算复核项，审稿标“保留”就能放行；带上之后它是 ERROR，机器检查直接变红。脚本不知道作品有没有规则文件，这一点要靠写检查清单的人做到。

`scope` 的行号从 1 开始，区间两端都包含。原稿共 N 行时有 N+1 个插入间隙，编号 0 至 N：间隙 i 位于第 i 行之后、第 i+1 行之前。只要相邻原稿行至少有一行可改，该间隙就允许插入。例如 `[[3,5]]` 允许间隙 2、3、4、5，即第 3 行之前到第 5 行之后；区间两侧对称。文件开头插入要求第 1 行可改，文件末尾插入要求原末行可改；空可改清单不允许任何插入。结果用 `source_gap` 报告插入位置；插入的 `source_lines` 为空，删除的 `candidate_lines` 为空。范围检查逐行比较并保留换行符；其他原稿行必须保持原字节对应的文本，换行变化也算修改。重复相同行可能影响差异对齐；此检查不判断段落含义或授权来源。

## 外置修订状态

这里的 `run-state.json` 只记录执行进度、证据和修订额度。人物表、设定与章节记录的权威状态另按 [state-storage.md](state-storage.md) 读取版本并条件保存；执行日志的锁和事件去重不能替代项目状态的并发保护。

需要跨会话修订或对轮数作程序限制时，使用下列命令；`workflow_guard.py` 替换为实际脚本路径：

```bash
python3 workflow_guard.py start run-state.json --task-id book-ch05-edit --spec checks.json --max-revisions 3
python3 workflow_guard.py record run-state.json --event-id verify-0 --review review.json
python3 workflow_guard.py reserve run-state.json --event-id repair-1
python3 workflow_guard.py record run-state.json --event-id verify-1 --review review.json
python3 workflow_guard.py status run-state.json --summary
python3 workflow_guard.py accept run-state.json --event-id accept-1 --decision acceptance.json
```

先准备规格及全部来源。普通稿可 `start` 后形成初稿；若 `facts` 使用 `chapters_dir`，`start` 还要读取 claims 的 `chapter` 来确定原章范围，此时应先准备候选稿和绑定它的 claims，再 `start`。`record` 实际执行检查并记录裁决。需要返修时在改稿前 `reserve`，修后重新审稿并 `record`。已完成结果因稿件或工具更新变成 STALE 时，也可 `reserve` 申请复查；冻结来源变化则需要有依据的 `replan`；正文没变、作者要求再审的，见下文“同一正文再审”。初稿不占返修次数；复查和返修共用预算，不能靠重启清零。可在开始时加 `--max-seconds` 设置从创建任务起计算的时间上限。

`review.json` 使用 `editorial-review/2` 格式，可以从 [审稿记录模板](../assets/editorial-review-template.json) 复制。旧格式的审稿没有绑定版本，`record` 会拒收：

```json
{
  "schema": "editorial-review/2",
  "verdict": "PASS",
  "candidate_sha256": "被审候选稿的 SHA-256",
  "reviewer": {"mode": "self_check", "label": "同一模型在本对话中自查"},
  "checked_against": ["本轮要求：只润色第3至5行", "original.md 全文", "文风卡 v2 第1、3条"],
  "inputs_read": ["original.md"],
  "evidence": [{"quote": "候选稿中逐字存在的短引", "in": "candidate"}],
  "issues": [],
  "machine_dispositions": [{"id": "punct:P10-L12-C1", "decision": "keep", "reason": "追逐段的急促停顿，有节奏作用"}],
  "dimensions": [
    {"id": "paragraphing", "status": "met", "note": "第3至5行按动作主体分段，没有新的碎段"},
    {"id": "dialogue_punctuation", "status": "met", "note": "两句对白的问号、叹号与原稿一致"},
    {"id": "scene_reconstruction", "status": "met", "note": "推门、看见、停步的先后和位置清楚"},
    {"id": "narrative_function", "status": "met", "note": "删去的一句只重复前文，没有丢信息"},
    {"id": "continuity", "status": "not_reviewed", "note": "没有拿到第4章原文，跨章事实未核"},
    {"id": "revision_comparison", "status": "met", "note": "对照 original.md 第3至5行，语义和因果未变"}
  ],
  "counter_evidence": "核对了是否误读版本、是否把人物猜测当事实",
  "limits": "第6章以后未读"
}
```

（这个例子是轻量模式，可以带着一项“未看”记 PASS；严格模式不行，见下文。）

`record` 实际核对以下几点，任何一条不满足都报错，不写入状态：

- `candidate_sha256` 等于当前文件，否则报 `REVIEW_STALE`。改稿后必须重新审。哈希按文件的原始字节算：照抄 `workflow_guard.py status` 输出里的 `candidate_sha256` 即可；自己算时对文件本身算（Windows 上 PowerShell `(Get-FileHash 文件 -Algorithm SHA256).Hash.ToLower()`），不要拿聊天或内存里的文字算——Windows 存文件时换行是 CRLF，同样的文字字节不同，算出来就对不上（r5.25，作者在 Windows 上跑测试时碰到）。
- `evidence` 和每条 `issues` 的 `quote` 能在 `in` 指向的候选稿或冻结来源中逐字找到，否则报 `EVIDENCE_NOT_FOUND`。
- PASS 时：引文的位置数和分布符合审稿策略；`inputs_read` 列出了全部冻结来源；脚本的每个复核项都有裁决，理由至少 6 个字。只要有一项标 `issue`，就不能 PASS。严格模式下，有检查没运行也不能 PASS。
- `reviewer.mode` 只能是 `self_check`、`independent_agent`、`human_editor`。按规则，同一模型在同一对话里复查只能填 `self_check`；但这一条靠如实填写，脚本只检查取值是否合法。
- 审稿记录（以及 checks、claims、事实账等 JSON 文件）里，同一个对象不能把一个字段写两次；写了就报错，不会悄悄只取后一个。
- r5.48 起另有四种拒收（`REVIEW_INCOMPLETE`），每一种只说明记录写得不像样，不说明判断对不对：
  - 还留着模板“替换为……”的字段：只说明模板没填，不说明填了的就写对了。
  - 保留理由只说作用的种类（“余韵”“收束”“作者的口吻”“无需修改”）：只说明理由太空，不说明写具体了的理由站得住。
  - 同一条理由复制到几处：只说明没有一处一处地写，不说明各写各的就是读过。
  - 严格模式的 PASS 里，没有任何保留或修改记录的一段（零修改的一段），说明里要有这一段连续 4 个字以上的原文：只说明说明里有这一段的字，不说明审稿人读过、掂量过，也不说明不改是对的。只抄这一段首尾的锚点也能过；判断错了、说明里自认有问题照样交，程序都看不出来。零修改本身可以，原文成立的段落不为了过关去改。

**审稿的六个维度。** `dimensions` 对应质量循环“文学质量的六个维度”：`paragraphing`（段落密度与语义分段）、`dialogue_punctuation`（对白与标点）、`scene_reconstruction`（场景可还原性）、`narrative_function`（叙事功能）、`continuity`（跨章连续性）、`revision_comparison`（修订前后对照）。规则：

- 写了 `dimensions` 就要六项写全，每项一条，不能少、不能重复、不能用别的编号；没看的写 `not_reviewed`，不能省略。
- `status` 只能是 `met`、`issue`、`not_reviewed`、`not_applicable`；每项都要有 `note`（至少 6 个非空白字符），写看了什么、问题在哪或为什么没看。可以加 `where`（位置说明）和 `evidence`（`{quote, in}` 列表，引文要能在候选稿或冻结来源里逐字找到）。
- `issue` 至少附一条引文；有一项是 `issue`，就不能记 PASS。
- `not_applicable` 只能用于 `continuity` 和 `revision_comparison`，而且声明了 `facts` 检查时 `continuity` 不能用，声明了 `revision` 或 `scope` 检查时 `revision_comparison` 不能用。
- 审稿策略的 `dimensions` 打开时（严格模式默认打开，轻量模式可以在 `review_policy` 里打开），每次 `record` 都要有 `dimensions`；严格模式记 PASS 时还不能有 `not_reviewed`。轻量模式默认不要求，写了也按上面几条核对；轻量模式可以带着 `not_reviewed` 记 PASS，`status` 会在状态行、交付标签和“能不能说已审”的权限说明里列出没看的维度。
- `record` 把六项结论原样存进状态文件，同时存一份审稿记录的原始字节和它的 SHA-256。`status` 每次都核对两者是否一致；状态文件里的结论被改过、与存下的审稿原文对不上时，显示 STALE。工具从不替任何一项补写结论。

**表达检查记录（r5.11）。** 整章任务的逐句表达检查（做法见 [模板腔复核](prose-audit.md)“整章任务的表达检查与记录”）写进审稿记录的 `expression`。严格模式记 PASS 必须有它；复用旧稿、零修改、事实检查全过，都不能免：

```json
"expression": {
  "scope": "chapter",
  "segments": [
    {"from": "雨停了。林舟", "to": "他没有出声。", "note": "开头到进院：逐句看过，删去一句替读者总结的话，其余保留"},
    {"from": "院子里的人", "to": "关上了门。", "note": "对话段：两处复述都在回答对方的疑问，保留"}
  ],
  "decisions": [
    {"decision": "change", "before": "他终于明白了这一切。", "after": "", "judgment": "上一段已经写出他看见的东西，这句替读者下结论", "reason": "删去不丢动作和线索"},
    {"decision": "keep", "quote": "“你明天自己敲一遍。”", "judgment": "师傅不解释，只叫徒弟自己试", "reason": "人物的教法，不是作者在讲解"}
  ]
}
```

- `scope` 写 `chapter`（整篇）或 `local`。`local` 只用于规格里声明了 `scope` 检查的局部任务，覆盖授权修改的行和前后各一个非空行（交付门核对的最低范围；编辑回读时连着前后各一个自然段看衔接，一个自然段折成几行时整段读，见 [模板腔复核](prose-audit.md)“整章任务的表达检查与记录”）；整章任务写 `local` 会被拒。局部记录的状态行写明覆盖了候选稿哪几行，“能不能说已审”的权限说明里注明不能说整章已审。
- `segments` 按顺序列出读过的各段：`from` 是这一段开头的几个字，`to` 是结尾的几个字（各至少 4 个字），`note` 写这一段看了什么、改了或保留了什么（至少 6 个字，各段不能相同）。记 PASS 时各段要首尾相接、盖住整个范围（整章任务不算章名行），中间不能空着；一段超过 800 个非空白字符又跨了几个自然段，会被拒：那是一句话盖住一大片，不是记录。章名行只指以“第×章”或 `#` 开头的第一个非空行；“楔子”“番外：……”这类标题算正文，要盖住。不到 4 个字的行（两个字的标题、单独一行的“走。”），让在那里开始或结束的那一段的锚点连着换行写，例如 `"from": "楔子\n\n雨停了"`；换行一律写 `\n`，文件用 CRLF 也一样。严格模式的 PASS 里，零修改的一段，`note` 要引这一段至少 4 个字的原文（r5.48）。
- `decisions` 是有定位的处理记录，没有可以为空。`keep` 写 `quote`（候选稿里只出现一次的原句，出现几次时加 `offset`）、`judgment`、`reason`；`reason` 写这一句自己多出了什么、删掉以后具体少了什么（判法见 [模板腔复核](prose-audit.md)“总结、复述和章尾：分开问三件事”），交付门只核对写没写，不核对理由成不成立。`change` 写 `before`（原句）、`after`（改后的句子，删去写 `""`）、`judgment`、`reason`：`before` 必须出现在冻结来源或之前记录过的版本里，而且已经不在候选稿里，否则分别报 `EVIDENCE_NOT_FOUND`、`CHANGE_NOT_APPLIED`（说改了，正文其实没改）；`after` 要能在候选稿里找到。
- 之前的审稿提出过的问题，原句还在候选稿里，又没有一条 `keep` 记录说明为什么保留，记 PASS 时报 `ISSUE_UNRESOLVED`。
- 记录过一版以后又改了正文：新的审稿记录要在每处改动的位置有一条处理记录（`keep` 或 `change`），否则报错。同一行里改了几处、相邻几行一起改了，各要一条：一条记录只算它引到的那一处（r5.15 及以前，一条记录能顶住同一块里的几处改动，r5.16 改正）。同一句话在几处出现、几处都改了，也各要一条：`change` 按新句子所在的那一处算，新句子出现几次时用 `offset` 指明；整句删掉、没有替代的，旧句子在上一版里只出现一次才能单独引，出现几次时连着前后留下的字一起引（`before` 写删掉的句子连同它前面或后面留下的字，`after` 写留下的字），一处一条（r5.16—r5.19 里，旧句子出现几次，一条记录就顶住了每一处，r5.20 改正）。删掉的地方，只算它所引的旧文字原来所在的那一处：交付门把每条 `change` 记录照它自己从旧文字到新文字的改法，做在上一版里它原来的位置，一条记录只算它自己改掉的字，`before` 里留下来的字不算删过；做完以后和候选稿还对不上的地方，要在保留或改写记录给出的文字里面。留下的一段两边都删了同一句，两边各要一条，或者一条把两边都引进去；删掉一整句或整段，紧挨着的其他记录（保留或改写）不算记过它，同一句里被改写带掉的几个字才算；删掉的字里有句末标点、省略号、破折号、后引号或后括号（一句话结尾的标点）的，可能是一整句或一句话，也要单独记（只删掉说话人“他说：”这类不算）；一句删掉、紧接着的一句开头又改了，比对会把两处并成一处改写，删掉的那句照样要单独记，或者用一条 `change` 把两处都引进去（r5.23）。几条记录一起核对，结果和记录排列的先后无关：同一处改法引了几次只算一次，几条记录引的删除重叠时并成一处；两条记录把同一处改动说成两种改法（一条记改写加删除，另一条记删掉再把字放回后面），混着做对不上时，再按整条记录试一次，引得多的先做，有一种做法对得上就算（r5.23）。同样的文字连着重复时，删的是哪一份结果都一样，按同一处删除算（r5.20、r5.21 里，只引左边那次删除的记录也顶住了右边，r5.22 改正）。保留记录靠改动比对的对齐：改写出来的句子和旁边的句子一模一样时，比对可能看成挪动，只记保留会被拦，这时改记 `change`；引的旧文字在上一版出现几次、又找不回是哪一处时，报错会点名那条记录，多引一点前后文。为此 `record` 会把审过的那一版的字节存进状态文件。

**外部意见的记录（r5.14）。** 按条处理外部的审读意见时（做法见 [句式专项](sentence-craft.md)“语感：搭配、照应与叫法”第 3 条），可以先记一次 NEEDS_REVISION，把决定处理的每条意见写成 `issues` 的一项：`quote` 引手上这一版的原句，`expected` 写意见要求改成什么，`impact` 写意见来源、分类和打算怎样处置。引的原句在这一版里找不到，`record` 报 `EVIDENCE_NOT_FOUND`：那条意见针对的是旧版，在工作记录里标“所审旧版”，从这次的问题里拿掉，不重开，也不再改一遍。改完再记 PASS 时，交付门逐条核对这些问题：原句已经不在正文里的算处理过了；还在正文里的，要有一条 `keep` 写明为什么保留，否则报 `ISSUE_UNRESOLVED`；改过的地方照样要有处理记录。这项核对只按字面：原句里别的字改了、要处理的那几个字还在（“又一段”改成“又一根”，没有着落的“又”还在），也会算处理过，回读时照样要看。新章全流程里作者带回的教师意见或改稿（[每章七阶段与作者确认](chapter-confirmation.md)），照这一段记成问题清单，来源写进 `impact`；修订稿的审稿方式照实填（工坊自己看的填 `self_check`），不借教师的名义（r5.53）。

工具只核对这份记录全不全、范围对不对、引文找不找得到、版本对不对；它判断不了哪句该删、哪句该留。

这些核对的能力有限，使用时要知道：

- 审稿方式、读过的来源、保留理由和反证说明，都由审稿记录自己填写，脚本无法核实。
- 引文核对只能证明引用的文字在这一版里，不能证明审稿人读过、读懂或判断正确；不读稿件，照样能挑出开头、中段、结尾各一句来满足条件。
- 状态文件 `run-state.json` 没有防篡改，手工改写其中的哈希就能抹掉 STALE。
- 检查清单也由写稿的一方自己写：只声明无关痛痒的检查，同样能得到 GREEN。看交付状态时，要连同 `checks.json` 一起看。

所以语义审稿仍是编辑的责任；交付状态说明的是“记录了什么”，不是“已被证实”。

`evidence` 和 `issues` 的 `in` 省略或写 `"candidate"` 时指本轮候选稿。引用来源原文时写相对 `checks.json` 的实际文件路径，例如 `{"quote": "原稿中逐字存在的片段", "in": "original.md"}`；该文件必须是规格中通过 `source`、`rules` 或 `ledger` 声明并冻结的来源。`inputs_read` 也使用相对 checks 的路径，不使用状态文件 artifacts 中相对 state 的路径；章节名或资料说明不能代替路径。

`facts` 可声明 `"chapters_dir":"."`，核对冻结事实账中本章之前的已采纳正文文件与采纳哈希，并把这些文件纳入冻结来源；审稿的 `inputs_read` 也须列它们。`file` 相对这个目录且不得逃逸。没有原章时不声明此项，明确“原章字节未核验”，不能声称已完成原文回归。若用 `chapters_dir`，`start` 要读 claims 的 `chapter` 来确定原章范围，所以先准备候选稿和绑定它的 claims，再 `start`。

`record` 把本次结果绑定到执行上下文（`workflow-context/2`）：当前规划代次、规格与冻结来源的路径和哈希、候选稿路径和哈希、可更新的 claims 路径和哈希，以及各检查脚本（本脚本、标点、文字、事实、项目状态脚本）的哈希。检查期间输入变动会拒绝记录。之后这些任一项改变，机器检查和编辑裁决都显示 STALE：改了稿、改了 claims、`replan` 进入新代次（即使正文不变）、检查工具升级，都要重新检查并审稿，不要手改旧记录让它重新变绿。候选稿始终从当前规划读取，不沿用上一轮记录的旧路径。旧版状态没有上下文绑定时按 STALE 处理。缺失候选稿或 claims 时 INPUT_READY 为 BLOCKED。

状态更新使用操作系统文件锁，进程中断会释放锁；`.flock` 文件留在原处不删除。旧版 `.lock` 会阻止写入，确认旧进程结束后将旧锁归档再重试。锁不能替代跨文件事务。Linux、macOS 用 `fcntl`，Windows 用 `msvcrt`；两者都没有时报 `UNSUPPORTED_PLATFORM`，不写状态文件。Windows 这一支在作者的 Windows 电脑上跑过一次：2026-10-20 作者用 r5.24 跑全部测试，“进程被杀以后锁会放开”那一项照常执行、不在失败和错误里（记录里没过的 99 项分别归在测试的写法、冲突登记表工具和按设计不支持 Windows 的 `project_state.py` 上）；交付门脚本此后没有改，r5.25 以后的版本还没有在 Windows 上重跑。`project_state.py` 仍只支持 POSIX，见 [state-storage.md](state-storage.md)。

`status` 不写入任何内容，它重新计算交付门的四项：INPUT_READY、MECHANICAL、EDITORIAL、AUTHOR（含义见 [quality-loop.md](quality-loop.md)），再从四项推算 `stage`（阶段）和 `permissions`（能不能说已审、能不能说是定本等的裁决），对应关系见 [quality-loop.md](quality-loop.md)“阶段与权限”。

`start` 还会记下当时的宪法版本和宪法文件的哈希。之后宪法有变化，`status` 在 `governance_warnings` 里提示，按现行宪法复核受影响的判断；旧版工具建立的任务没有这项记录，也会提示。（检查工具的变化不只是提示：它在执行上下文里，会直接让旧结果 STALE。）

`--summary` 只输出一行状态，按用户指定的输出格式呈现，或保存到独立工作记录。这一行包括：候选稿文件名和哈希前 12 位；四项状态；阶段；没运行的检查名；审稿策略（模式、最少引文位置数、是否检查分布）；被审稿人标为“保留”的复核项数量；表达检查记录的范围、段数和处理记录数（没有就写 `expression: not recorded`）；有治理提示时注明条数。审稿方式不是自查时，句尾会注明“审稿方式由审稿记录自报，脚本无法核实”。

交付前用 `--deliverable` 核对要交出去的文件就是检查过的那一版：

```bash
python3 workflow_guard.py status run-state.json --deliverable 第5章_交付.txt
```

结果在 `gate.deliverable.matches`：`exact` 是同一版；`final_newline_only` 是正文相同、只差末尾换行（贴进聊天框常见），照实说明；`line_endings_or_bom_only` 是正文相同、只差换行符（CRLF／LF）或文件开头的 BOM（换了编辑器保存常见），同样照实说明；`no` 是另一版，或者还没有任何检查记录。是 `no` 时退出码为 1，状态行加 `DELIVERABLE=MISMATCH`，对这份文件“说机器检查通过”“说已审”“说是定本”都是 BLOCK：先交检查过的版本，或者对要交的文件重新检查、重新审读。

`accept` 记录作者采纳。`acceptance.json` 需要 `candidate_sha256`、`source`（作者原话或消息位置）、`scope`。哈希接受大小写，保存时统一为小写。只能采纳曾经 `record` 过、并且仍是当前文件内容的版本。采纳不要求先 PASS，作者有权采纳带问题的稿子，但会记下采纳时机器检查和编辑裁决的状态。工具不能核实消息确实来自作者；不要用推测或模型自评来写 `source`。

作者决定跳过审稿、直接采纳时（宪法第一节第 2 条），加 `--skip-review`：

```bash
python3 workflow_guard.py accept run-state.json --event-id accept-1 --decision acceptance.json --skip-review
```

`source` 写作者跳过审稿、采纳这一版的原话。工具照样核对哈希就是当前文件，把这一版的哈希记进 `artifacts`（标 `review: skipped_by_author`），在 `human_approvals` 里记下 `review_skipped: true` 和采纳时的状态。MECHANICAL、EDITORIAL 不变（没做过就是 UNTESTED），AUTHOR 记 ACCEPTED，`status` 带警告“作者决定跳过审稿”，权限里“说已审”“说机器检查通过”仍是 BLOCK。已经 `record` 过审稿的版本不用这个参数，直接 `accept`，采纳时的审稿状态会照记。同一个事件标识不能先跳审、再改成普通采纳，反过来也不行。不要为了能采纳而补写一份 PASS 或 FAIL。

跳审以后，同一版的几种后续（同一个哈希）：

- 作者再确认一次、仍然不审：用新的事件标识再加 `--skip-review`。记录里多一条跳审采纳，“作者决定跳过审稿”的标记保留。
- 不加参数的普通 `accept` 会被拒：跳审时冻结的那条记录不是审稿，不能拿来当“已经 `record` 过”。报错会说明这一版没有审稿记录。
- 之后对这一版补做了检查和审稿（`record`）：四项状态按补做的结果显示（比如 GREEN、PASS），`status` 写“采纳时作者决定跳过审稿，之后补做了审稿”，`reviewed_since_skip` 为 true；跳审的历史留在 `human_approvals` 里。这时再加 `--skip-review` 会被拒；作者要按审过的稿子再采纳一次，就用普通 `accept`。

状态保留九类交接信息：`task_id`、`current_node`、`completed_nodes`、`artifacts`、`decisions`、`evidence`、`budgets`、`retry_counts`、`human_approvals`，另有程序用的 `events` 事件索引；r5 起新建的任务还有 `governance`（宪法版本和文件哈希）。其中人类授权只存实际已有的记录，空列表不表示缺少普通改稿许可；工具不会据此授予发布权限。完成节点是本轮工作进度，不表示作者采纳草稿；`current_node` 为 `complete` 时，候选稿仍是 `author_status: draft`，直到 `accept` 记录了作者对这一哈希的采纳。

事件标识在同一任务内唯一，同一次动作重试沿用原标识；重复提交不再次计数，标识相同但内容改变会报冲突。修订额度由程序保存；恢复先读 `status` 和原稿，不重新 `start` 清空额度。规格或已冻结来源变化时报告 `INPUT_CHANGED`，先确认作者的新决定和受影响范围，不偷偷换文件、改预算或另起任务绕过旧限制。

## 作者改变要求或补足决定后继续

`FAIL` 将任务路由到 `blocked`，表示缺少决定或关键上下文，不能直接 `reserve`。作者已有新决定、补足材料或明确更正冻结来源时，用 `replan` 记录依据并冻结新版本；已有明确指示就直接记录，无需重复向作者确认。

先按作者的新要求准备 `checks.json` 与来源，再写 `decision.json`。以下三个非空字段必填；`source` 是实际作者消息、批注或决定的可追溯位置，不能把编辑自行推测写成作者授权：

```json
{
  "author_decision": "采用作者修订的第5章原稿，保留新结尾。",
  "source": "作者本轮消息：采用新上传的原稿版本。",
  "affected_scope": "第5章第3至5行；原范围检查与编辑裁决重新核查。"
}
```

```bash
python3 workflow_guard.py replan run-state.json --event-id replan-1 --spec checks.json --decision decision.json
python3 workflow_guard.py reserve run-state.json --event-id repair-after-replan-1
# 在预留成功后，依据新要求修改 draft.md，并更新 review.json。
python3 workflow_guard.py record run-state.json --event-id verify-after-replan-1 --review review.json
python3 workflow_guard.py status run-state.json
```

`replan` 接受 `draft`、`repair`、`blocked` 或 `complete`，统一回到 `repair`；旧检查结果保留为历史，不能继续当作新版本已通过。之后必须先 `reserve` 再改稿、再 `record`。重规划本身不增加计数，也不送出免费改稿次数：它保留原 `max_revisions`、`revisions_used`、`max_seconds`、`started_at`、重试计数和所有既有事件。即使旧稿已经预留了一轮，该轮也不退还；重规划后的改稿仍须另有剩余额度。额度或时间用尽时返回 `BUDGET_EXHAUSTED`，不写入新状态；`stopped` 不可重新打开。

作者决定写入 `human_approvals` 和路由记录；工具仅验证字段，不认证消息身份。规格与各来源在 `artifacts` 中保留路径、SHA-256 和 Base64 原始字节快照。重规划用 `superseded_by` 标记旧输入，追加新冻结输入；后续核查只读当前版本，旧来源即使改名也不必伪造回旧文件。旧版状态原先只有哈希时，能匹配的原字节才补存快照，否则明确标记 `snapshot_unavailable`，不会声称恢复了已丢失内容。候选稿仍只记路径和哈希，需另按项目约定保存正文版本。

同一次 `replan` 使用同一事件标识、相同决定内容和相同输入字节重试，返回当前状态，不重复追加决定或快照；决定或输入改变时必须用新事件标识，否则返回 `EVENT_CONFLICT`。恢复沿用原状态；不得通过另起任务或编辑状态文件绕过额度。对现有状态改用另一任务名或预算执行 `start` 会返回 `STATE_CONFLICT`。

这些程序限制只约束通过此工具执行的步骤；它没有接管模型调用、外部写入或完整运行环境。纯聊天版仍能用文本记录九字段，但不能声称有代码强制停止或自动永久存档。

### 同一正文再审：旧 PASS 之后又发现语义问题

情形：任务已经 `complete`，这一版记过 PASS；之后读出了语义问题（比如压短的句子丢了动作的承受者，台词里的判断没落到事情上），正文一个字没改。这时直接 `record` 新的审稿被拒（`INVALID_ROUTE`：任务已完成，`record` 要先 `reserve`）；直接 `reserve` 也被拒（旧审稿对这一版仍然有效，`reserve` 只开给要返修的，或者旧结果已经 STALE 的）。两条报错都会指到这里。这不是死路：作者要求再审，就 `replan` 记下作者的决定，再 `reserve`、`record`。自己复读时发现的问题，先报给作者；作者要求再审或修订（或者作者已有的指示本来就覆盖这种情况），才走这条路，`source` 写作者的原话或指示所在，不写编辑的推测。

1. 写 `decision.json`：

```json
{
  "author_decision": "作者要求按新发现的语义问题重审这一章，旧 PASS 不再作为这一版的结论。",
  "source": "作者 10 月 24 日的消息：（引原话，或批注的位置）",
  "affected_scope": "整章表达检查；动作承受者、台词判断两类问题所在的段落。"
}
```

2. 规格和来源没变，就用原来的 `checks.json`；作者给了要冻结进来的新依据（比如一份问题清单），先加进规格的来源。然后：

```bash
python3 workflow_guard.py replan run-state.json --event-id replan-reread-1 --spec checks.json --decision decision.json
python3 workflow_guard.py reserve run-state.json --event-id reserve-reread-1
python3 workflow_guard.py record run-state.json --event-id verify-reread-1 --review review-reread.json
python3 workflow_guard.py status run-state.json --summary
```

`review-reread.json` 绑定同一个 `candidate_sha256`，`verdict` 写 `NEEDS_REVISION`，`issues` 逐条引这一版里的原句，写清应该是什么、读者会怎样读错；表达记录照常盖住约定范围。记下以后任务回到 `repair`，`status` 显示 `EDITORIAL=NEEDS_REVISION`。

3. 改稿照常：再 `reserve` 一轮，改正文，审稿记录对改过的地方逐处裁决，再 `record`。上一轮记下的问题要么从正文里消失，要么写明保留的理由（`record` 会核对）。

结果：`evidence` 里旧的 PASS 原样留着，后面跟着这次的 NEEDS_REVISION 和改稿后的结论，`status` 按最新的一条算。额度不退还、不重置：再审用一轮，改稿再用一轮，用完就停（再 `reserve` 报 `BUDGET_EXHAUSTED`；用最后一轮审出 NEEDS_REVISION 的，任务直接 `stopped`）；`replan` 也不能放宽审稿策略（见“可执行条件”）。改一个无关的标点让旧结果变 STALE、另起一个任务、手改状态文件，都不是这条路：旧记录和额度都是交接的一部分。作者的决定里已经写明怎样改的，也可以 `reserve` 以后直接改稿、`record` 改过的版本，少用一轮；那样记录里没有“这一版被判 NEEDS_REVISION”这一条，问题只记在作者的决定里。要留下“旧 PASS 之后同一版又查出问题”的记录，按上面三步走。

升级以后旧结论显示 STALE，和上面是两回事（r5.40 补这一段）：换了检查脚本的版本，旧的检查结果和审稿就绑不上新脚本，这是结论和脚本的版本绑定，不是死锁。`reserve` 一轮再 `record` 同一份旧审稿，只是把旧结论重新绑到新脚本上，`status` 回到原来的结论，不说明已经按新版本的方法读过正文。要按新方法审，`reserve` 以后 `record` 一份按新方法重新读出来的审稿记录，不要原样再交旧的那一份。交付说明里写清是哪一种：“旧审稿重新绑定到新脚本”，还是“按新方法重审过”。

## 失败先分类

| 命名失败 | 动作 | 小说任务的处理 |
| --- | --- | --- |
| `TRANSIENT_IO` | RETRY | 确认是短暂读取故障后重试一次；写入结果不明先检查原事件是否完成 |
| `OPTIONAL_SOURCE_UNAVAILABLE` | FALLBACK／SKIP | 使用已提供的合适样本，或跳过可选比较并说明覆盖范围 |
| `CHECK_FAILED`、`SCOPE_VIOLATION` | REPAIR | 按证据和修改范围返修，再核查；不盲目重跑同样输入 |
| `MISSING_REQUIRED_SOURCE`、无法裁定的版本冲突 | ESCALATE | 完成可确定部分，再问影响继续工作的关键材料或选择 |
| `INPUT_CHANGED`、编辑裁决 `FAIL` | 核对后重规划 | 作者决定或材料已补足时执行 `replan`，再 `reserve`、改稿及 `record`；保留原修订账目 |
| `INVALID_ROUTE` | 按报错走 | 命令和任务所在的节点对不上；报错写明这个节点能走的路（r5.39）。已完成、正文没变、作者要求再审的，见“同一正文再审” |
| `BUDGET_EXHAUSTED`、明确授权边界 | STOP | 保留最好稿和未解决项，交接后停止该分支 |

可选文风样本缺失不能阻塞全部写作；缺少用户要求核对的某章则不能宣称全章检查完毕。复用写入标识避免重复保存同一次结果；已经获得的普通修订授权无需再次申请。

## 多单元任务收尾

检查单元边界是否清楚、每个依赖是否有实际材料、重要发现是否复核、修改是否超范围；确认可从记录恢复，失败没有被静默丢弃，修订有上限，下一步的选择有简短依据。复杂度应与任务相称，不为满足十二项检查的形式再造十二个步骤。


## 批量交付与可运行演练

在项目根目录创建 `delivery.json`，把约定的全部单元先列入 `expected_units`，不能只列已经写完的章。示例：

```json
{
  "schema": "delivery-manifest/1",
  "stage": "candidate",
  "expected_units": ["ch1", "ch2"],
  "records": [
    {"unit": "ch1", "candidate": "manuscripts/ch1.md", "state": "ch1.run.json"},
    {"unit": "ch2", "candidate": "manuscripts/ch2.md", "state": "ch2.run.json"}
  ]
}
```

运行 `python3 scripts/delivery_manifest.py /项目/delivery.json`。它逐章重跑当前检查并核对审稿状态，检测漏列、重复单元、同一路径重用、空稿、候选路径不匹配和过期记录。候选阶段不要求作者采纳；`stage=accepted` 则逐章要求当前版本已采纳。可设 `require_independent=true` 拒绝同一模型自查。作者跳过审稿采纳的章：之后还没有补审（或者补审的结果已经过期）时，问题里列 `GATE_INCOMPLETE` 和 `AUTHOR_SKIPPED_REVIEW`；补审过了，跳审的经过只在这一章的 `notes` 里留一条 `AUTHOR_SKIPPED_REVIEW_AT_ACCEPTANCE`，这一章算不算完整看补审的结果——通过了就不算缺项，没通过照样列 `GATE_INCOMPLETE`。退出码 0 为清单内条件通过，1 为缺项，2 为输入无效；不证明清单本身完整、不证明真的发送给作者，也不验证作者身份。每章篇幅仍由各自的 `length` 规格限定，不能用总字数抵消缺章。

需要按章分条消息交付时，以实际发出的章号和正文为交付记录；平台无法分条时明确限制，不把“文件已生成”写成“消息已发送”。

新目录中运行真实工具的三章虚构演练：

```bash
python3 scripts/workflow_demo.py /临时目录/新演练 --stop-after failed-review
python3 scripts/workflow_demo.py /临时目录/新演练
python3 scripts/delivery_manifest.py /临时目录/新演练/delivery.json
```

第一步留下失败记录；第二步恢复、保留返修预算，完成三章衔接和条件更新；重复第二步不会重复追加已完成的采纳或事实。演练用固定的模拟审稿与明确标注的模拟采纳验证工具协作，不代替新上下文使用测试、文学评审或真实作者采纳。原章、候选、基线快照、检查、评审、清单和项目状态均可打开核对。

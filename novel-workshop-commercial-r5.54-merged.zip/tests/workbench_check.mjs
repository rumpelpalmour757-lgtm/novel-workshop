// r5.46 写作台检查：只读边界、保存先备份与版本核对、改稿建议（Gemini）的请求范围、成功与失败、密钥不外泄。
// r5.47 加：查可用模型、合成示例试接通、“已真实接通”只认官方地址的成功调用、按 Google 错误表的几种失败、接通检查脚本。
// 用法：node workbench_check.mjs <技能目录>。Gemini 用本机模拟服务代替，不联网；模拟服务只证明这一侧的请求和错误处理，不算真实接通。
import assert from "node:assert/strict";
import { createServer } from "node:http";
import { mkdtemp, mkdir, readFile, readdir, rm, stat, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { pathToFileURL } from "node:url";

const skill = process.argv[2];
const { createDashboardServer } = await import(pathToFileURL(join(skill, "scripts", "oh-story", "dashboard-server.mjs")).href);
const { parseLauncherArguments, createDemoWorkspace, nodeTooOld } = await import(pathToFileURL(join(skill, "scripts", "oh-story", "workbench.mjs")).href);
const { buildRequestBody, configDirectory, SELFTEST_SAMPLE, OFFICIAL_BASE } = await import(pathToFileURL(join(skill, "scripts", "oh-story", "gemini-assist.mjs")).href);
const { runCheck } = await import(pathToFileURL(join(skill, "scripts", "oh-story", "gemini-check.mjs")).href);

const KEY = "AIzaTEST-not-a-real-key-0123456789";
const results = [];
async function check(name, fn) {
  try {
    await fn();
    results.push(["ok", name]);
  } catch (error) {
    results.push(["FAIL", name, error?.stack || String(error)]);
  }
}

function listen(server) {
  return new Promise((accept) => server.listen(0, "127.0.0.1", () => accept(server.address().port)));
}

async function api(port, method, path, body, headers = {}) {
  const response = await fetch(`http://127.0.0.1:${port}${path}`, {
    method,
    headers: { "Content-Type": "application/json", ...headers },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await response.text();
  let json = null;
  try {
    json = JSON.parse(text);
  } catch {}
  return { status: response.status, json, text };
}

const base = await mkdtemp(join(tmpdir(), "nw-wb-"));
const root = join(base, "作品");
const configDir = join(base, "config");
await mkdir(join(root, "正文"), { recursive: true });
const chapter = "第一章\n\n苏棠扣上头盔，从气闸里出来。\n\n这一段不该发出去。\n";
await writeFile(join(root, "正文", "第001章.md"), chapter, "utf8");

// 模拟 Gemini：记下收到的请求，按 mode 回不同结果
const seen = [];
let mode = "ok";
const mock = createServer(async (request, response) => {
  const chunks = [];
  for await (const chunk of request) chunks.push(chunk);
  seen.push({ url: request.url, method: request.method, headers: request.headers, body: Buffer.concat(chunks).toString("utf8") });
  const send = (status, payload) => {
    response.writeHead(status, { "Content-Type": "application/json" });
    response.end(JSON.stringify(payload));
  };
  if (request.method === "GET" && request.url.startsWith("/v1beta/models?")) {
    if (mode === "list403") return send(403, { error: { message: "denied", status: "PERMISSION_DENIED" } });
    const page = new URL(request.url, "http://x").searchParams.get("pageToken");
    if (!page) {
      return send(200, { models: [
        { name: "models/gemini-4-argon", baseModelId: "gemini-4-argon", displayName: "Gemini 4 Argon", supportedGenerationMethods: ["generateContent", "countTokens"] },
        { name: "models/text-embedding-9", supportedGenerationMethods: ["embedContent"] },
      ], nextPageToken: "p2" });
    }
    return send(200, { models: [{ name: "models/gemini-3.8-flash", displayName: "Gemini 3.8 Flash", supportedGenerationMethods: ["generateContent"] }] });
  }
  if (mode === "ok") send(200, { candidates: [{ content: { parts: [{ text: "改好的一段。", thought: false }] }, finishReason: "STOP" }], modelVersion: "mock-model" });
  else if (mode === "same") {
    const asked = JSON.parse(Buffer.concat(chunks).toString("utf8")).contents[0].parts[0].text.split("要改的正文：\n")[1];
    send(200, { candidates: [{ content: { parts: [{ text: asked }] }, finishReason: "STOP" }], modelVersion: "mock-model" });
  }
  else if (mode === "403") send(403, { error: { message: "Permission denied", status: "PERMISSION_DENIED" } });
  else if (mode === "402") send(402, { error: { message: "Prepay credits depleted" } });
  else if (mode === "precondition") send(400, { error: { message: "Billing not enabled", status: "FAILED_PRECONDITION" } });
  else if (mode === "recitation") send(200, { candidates: [{ content: { parts: [{ text: "像别处的话" }] }, finishReason: "RECITATION" }] });
  else if (mode === "safety") send(200, { candidates: [{ content: { parts: [] }, finishReason: "SAFETY" }] });
  else if (mode === "thought") send(200, { candidates: [{ content: { parts: [{ text: "想法", thought: true }, { text: "正文。" }] }, finishReason: "STOP" }] });
  else if (mode === "401") send(401, { error: { message: `API key ${KEY} not valid` } });
  else if (mode === "429") send(429, { error: { message: "Resource exhausted" } });
  else if (mode === "500") send(500, { error: { message: "internal" } });
  else if (mode === "404") send(404, { error: { message: "model not found" } });
  else if (mode === "blocked") send(200, { promptFeedback: { blockReason: "SAFETY" } });
  else if (mode === "maxtokens") send(200, { candidates: [{ content: { parts: [{ text: "半截" }] }, finishReason: "MAX_TOKENS" }] });
  else send(200, {});
});
const mockPort = await listen(mock);

const env = { NOVEL_WORKSHOP_CONFIG_DIR: configDir, NOVEL_WORKSHOP_GEMINI_BASE: `http://127.0.0.1:${mockPort}/v1beta` };
const readOnlyServer = createDashboardServer({ root, assist: { env } });
const editServer = createDashboardServer({ root, allowEdit: true, assist: { env } });
const roPort = await listen(readOnlyServer);
const port = await listen(editServer);

await check("默认只读：workspace 报 readOnly，PUT 被拒（403），文件不变", async () => {
  const ws = await api(roPort, "GET", "/api/workspace");
  assert.equal(ws.json.readOnly, true);
  const file = await api(roPort, "GET", `/api/file?path=${encodeURIComponent("正文/第001章.md")}`);
  const put = await api(roPort, "PUT", "/api/file", { path: "正文/第001章.md", content: "改了", expectedVersion: file.json.version });
  assert.equal(put.status, 403);
  assert.equal(await readFile(join(root, "正文", "第001章.md"), "utf8"), chapter);
});

await check("可编辑：保存先备份；拿旧版本号保存报 409 冲突、不覆盖；没有删除接口", async () => {
  const file = await api(port, "GET", `/api/file?path=${encodeURIComponent("正文/第001章.md")}`);
  const saved = await api(port, "PUT", "/api/file", { path: "正文/第001章.md", content: `${chapter}加一行。\n`, expectedVersion: file.json.version });
  assert.equal(saved.status, 200);
  const backupRoot = join(root, ".novel-workshop-backups");
  const records = await readdir(backupRoot);
  assert.equal(records.length, 1, `备份数不对：${records.join(", ")}`);
  assert.equal(await readFile(join(backupRoot, records[0], "original.bin"), "utf8"), chapter);
  assert.ok((await readFile(join(backupRoot, records[0], "record.json"), "utf8")).includes("第001章.md"));
  const stale = await api(port, "PUT", "/api/file", { path: "正文/第001章.md", content: "旧版本上的修改", expectedVersion: file.json.version });
  assert.equal(stale.status, 409);
  assert.equal(await readFile(join(root, "正文", "第001章.md"), "utf8"), `${chapter}加一行。\n`);
  const del = await api(port, "DELETE", `/api/file?path=${encodeURIComponent("正文/第001章.md")}`);
  assert.equal(del.status, 405);
});

await check("改稿建议未配置：状态是未配置，请求被拒且不联网", async () => {
  const status = await api(port, "GET", "/api/assist/status");
  assert.equal(status.json.state, "unconfigured");
  const before = seen.length;
  const revise = await api(port, "POST", "/api/assist/revise", { text: "一段", instruction: "改" });
  assert.equal(revise.status, 400);
  assert.equal(revise.json.error.code, "assist_unconfigured");
  assert.equal(seen.length, before);
});

await check("配置密钥：存进用户配置目录（不在作品目录），状态里不回传密钥", async () => {
  const saved = await api(port, "POST", "/api/assist/config", { apiKey: KEY, model: "gemini-4-argon" });
  assert.equal(saved.status, 200);
  assert.equal(saved.json.state, "configured");
  assert.ok(!saved.text.includes(KEY));
  const stored = JSON.parse(await readFile(join(configDir, "gemini.json"), "utf8"));
  assert.equal(stored.apiKey, KEY);
  if (process.platform !== "win32") assert.equal((await stat(join(configDir, "gemini.json"))).mode & 0o777, 0o600);
  const status = await api(port, "GET", "/api/assist/status");
  assert.ok(!status.text.includes(KEY));
  const inWorkspace = await readdir(root, { recursive: true });
  assert.ok(!inWorkspace.some((name) => name.includes("gemini")));
});

await check("发送范围：只发选中的文字和要求，密钥走请求头；模型名进路径；文稿不变", async () => {
  mode = "ok";
  const before = await readFile(join(root, "正文", "第001章.md"), "utf8");
  seen.length = 0;
  const result = await api(port, "POST", "/api/assist/revise", { text: "苏棠扣上头盔，从气闸里出来。", instruction: "改得像小说" });
  assert.equal(result.status, 200, result.text);
  assert.equal(result.json.candidate, "改好的一段。");
  assert.equal(seen.length, 1);
  const sent = seen[0];
  assert.equal(sent.method, "POST");
  assert.equal(sent.url, "/v1beta/models/gemini-4-argon:generateContent");
  assert.equal(sent.headers["x-goog-api-key"], KEY);
  assert.ok(!sent.url.includes(KEY));
  const body = JSON.parse(sent.body);
  const text = JSON.stringify(body);
  assert.ok(text.includes("苏棠扣上头盔，从气闸里出来。") && text.includes("改得像小说"));
  assert.ok(!text.includes("这一段不该发出去") && !text.includes("第001章") && !text.includes(root));
  assert.deepEqual(Object.keys(body).sort(), ["contents", "systemInstruction"]);
  assert.deepEqual(body, buildRequestBody("苏棠扣上头盔，从气闸里出来。", "改得像小说"));
  assert.equal(await readFile(join(root, "正文", "第001章.md"), "utf8"), before);
});

await check("思考片段不当正文：只取非 thought 的文字", async () => {
  mode = "thought";
  const result = await api(port, "POST", "/api/assist/revise", { text: "一段", instruction: "" });
  assert.equal(result.json.candidate, "正文。");
});

const failures = [
  ["401", 401, "assist_key_rejected"],
  ["429", 429, "assist_quota"],
  ["500", 502, "assist_upstream"],
  ["404", 404, "assist_model_missing"],
  ["blocked", 422, "assist_blocked"],
  ["maxtokens", 502, "assist_incomplete"],
  ["empty", 502, "assist_empty"],
  ["403", 401, "assist_key_rejected"],
  ["402", 402, "assist_payment"],
  ["precondition", 403, "assist_account"],
  ["recitation", 422, "assist_blocked"],
  ["safety", 422, "assist_blocked"],
];
for (const [failMode, status, code] of failures) {
  await check(`失败如实报：${failMode} → ${status} ${code}，不报成功，状态变“连接失败”，错误里没有密钥`, async () => {
    mode = failMode;
    const result = await api(port, "POST", "/api/assist/revise", { text: "一段", instruction: "" });
    assert.equal(result.status, status, result.text);
    assert.equal(result.json.error.code, code);
    assert.ok(!result.text.includes(KEY));
    const state = await api(port, "GET", "/api/assist/status");
    assert.equal(state.json.state, "failed");
    assert.ok(!state.text.includes(KEY));
  });
}

await check("连不上服务：502 assist_network", async () => {
  const deadEnv = { ...env, NOVEL_WORKSHOP_GEMINI_BASE: "http://127.0.0.1:9/v1beta" };
  const dead = createDashboardServer({ root, assist: { env: deadEnv } });
  const deadPort = await listen(dead);
  const result = await api(deadPort, "POST", "/api/assist/revise", { text: "一段" });
  assert.equal(result.status, 502);
  assert.equal(result.json.error.code, "assist_network");
  dead.close();
});

await check("成功一次以后回到“已配置”：模拟服务不是 Google 官方地址，不算真实接通", async () => {
  mode = "ok";
  const result = await api(port, "POST", "/api/assist/revise", { text: "一段" });
  assert.equal(result.status, 200);
  assert.equal(result.json.endpoint, "custom");
  const status = (await api(port, "GET", "/api/assist/status")).json;
  assert.equal(status.state, "configured");
  assert.equal(status.lastCall.ok, true);
  assert.equal(status.lastCall.endpoint, "custom");
  assert.notEqual(status.label, "已真实接通");
  const record = JSON.parse(await readFile(join(configDir, "gemini-status.json"), "utf8"));
  assert.ok(!JSON.stringify(record).includes(KEY) && !JSON.stringify(record).includes("一段"));
});

await check("原样交回的候选标出来", async () => {
  mode = "same";
  const result = await api(port, "POST", "/api/assist/revise", { text: "灯丝好好的。", instruction: "" });
  assert.equal(result.status, 200, result.text);
  assert.equal(result.json.candidate, "灯丝好好的。");
  assert.equal(result.json.unchanged, true);
});

await check("查可用模型：只发 GET models、密钥在请求头、不带文字；翻页；只列能生成文字的；报当前模型在不在清单", async () => {
  seen.length = 0;
  const listed = await api(port, "POST", "/api/assist/models");
  assert.equal(listed.status, 200, listed.text);
  assert.deepEqual(listed.json.models.map((m) => m.id), ["gemini-3.8-flash", "gemini-4-argon"]);
  assert.equal(listed.json.configured, "gemini-4-argon");
  assert.equal(listed.json.configuredListed, true);
  assert.equal(seen.length, 2);
  for (const request of seen) {
    assert.equal(request.method, "GET");
    assert.ok(request.url.startsWith("/v1beta/models?pageSize=1000"));
    assert.equal(request.headers["x-goog-api-key"], KEY);
    assert.ok(!request.url.includes(KEY));
    assert.equal(request.body, "");
  }
  assert.ok(seen[1].url.includes("pageToken=p2"));
  assert.ok(!listed.text.includes(KEY));
  mode = "list403";
  const denied = await api(port, "POST", "/api/assist/models");
  assert.equal(denied.json.error.code, "assist_key_rejected");
  const evil = await api(port, "POST", "/api/assist/models", undefined, { Origin: "http://evil.example" });
  assert.equal(evil.status, 403);
});

await check("合成示例试一次：发的只有合成示例，不碰文稿；模拟服务上 real 为 false", async () => {
  mode = "ok";
  seen.length = 0;
  const before = await readFile(join(root, "正文", "第001章.md"), "utf8");
  const result = await api(port, "POST", "/api/assist/selftest");
  assert.equal(result.status, 200, result.text);
  assert.equal(result.json.real, false);
  assert.equal(seen.length, 1);
  assert.deepEqual(JSON.parse(seen[0].body), buildRequestBody(SELFTEST_SAMPLE.text, SELFTEST_SAMPLE.instruction));
  assert.ok(!seen[0].body.includes("苏棠"));
  assert.equal(await readFile(join(root, "正文", "第001章.md"), "utf8"), before);
  assert.equal((await api(port, "GET", "/api/assist/status")).json.state, "configured");
});

await check("模型名前面的 models/ 可以不写；换模型清掉上次的调用记录", async () => {
  const saved = await api(port, "POST", "/api/assist/config", { model: "models/gemini-3.8-flash" });
  assert.equal(saved.status, 200, saved.text);
  assert.equal(saved.json.model, "gemini-3.8-flash");
  assert.equal(saved.json.lastCall, null);
  await api(port, "POST", "/api/assist/config", { model: "gemini-4-argon" });
});

await check("“已真实接通”的判断：官方地址上的成功调用才算（这里用替身 fetch，不联网，只测判断逻辑）", async () => {
  const officialDir = join(base, "config-official");
  const officialEnv = { NOVEL_WORKSHOP_CONFIG_DIR: officialDir, GEMINI_API_KEY: KEY };
  const urls = [];
  const fakeFetch = async (url, init) => {
    urls.push(url);
    return new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: "改好了。" }] }, finishReason: "STOP" }], modelVersion: "fake" }), { status: 200, headers: { "Content-Type": "application/json" } });
  };
  const official = createDashboardServer({ root, assist: { env: officialEnv, fetchImpl: fakeFetch } });
  const officialPort = await listen(official);
  const before = (await api(officialPort, "GET", "/api/assist/status")).json;
  assert.equal(before.state, "configured");
  assert.equal(before.keyLocation, "环境变量 GEMINI_API_KEY");
  const result = await api(officialPort, "POST", "/api/assist/selftest");
  assert.equal(result.json.real, true);
  assert.equal(urls[0], `${OFFICIAL_BASE}/models/gemini-4-argon:generateContent`);
  const after = (await api(officialPort, "GET", "/api/assist/status")).json;
  assert.equal(after.state, "connected");
  assert.equal(after.label, "已真实接通");
  const switched = await api(officialPort, "POST", "/api/assist/config", { model: "gemini-3.8-flash" });
  assert.equal(switched.json.state, "configured");
  official.close();
});

await check("接通检查脚本：模拟地址报 3（不算真实接通），报告不含密钥；没配置报 2；官方地址加替身 fetch 报 0", async () => {
  mode = "ok";
  const quiet = () => {};
  const mocked = await runCheck({ env, print: quiet });
  assert.equal(mocked.code, 3, mocked.lines.join("\n"));
  const report = await readFile(mocked.report, "utf8");
  assert.ok(report.includes("自定义") && !report.includes(KEY) && !report.includes("苏棠"));
  assert.ok(report.includes(SELFTEST_SAMPLE.text));
  const listOnly = await runCheck({ argv: ["--list"], env, print: quiet });
  assert.equal(listOnly.code, 0);
  assert.ok(!listOnly.lines.join("\n").includes(SELFTEST_SAMPLE.text));
  const none = await runCheck({ env: { NOVEL_WORKSHOP_CONFIG_DIR: join(base, "config-none") }, print: quiet });
  assert.equal(none.code, 2);
  const bad = await runCheck({ argv: ["--model"], env, print: quiet });
  assert.equal(bad.code, 2);
  const fakeFetch = async (url) => new Response(JSON.stringify(String(url).includes(":generateContent")
    ? { candidates: [{ content: { parts: [{ text: "改好了。" }] }, finishReason: "STOP" }], modelVersion: "fake" }
    : { models: [{ name: "models/gemini-4-argon", supportedGenerationMethods: ["generateContent"] }] }), { status: 200 });
  const real = await runCheck({ env: { NOVEL_WORKSHOP_CONFIG_DIR: join(base, "config-cli"), GEMINI_API_KEY: KEY }, fetchImpl: fakeFetch, print: quiet });
  assert.equal(real.code, 0, real.lines.join("\n"));
  assert.ok(!(await readFile(real.report, "utf8")).includes(KEY));
});

await check("非本机页面发来的 POST 被拒", async () => {
  const result = await api(port, "POST", "/api/assist/revise", { text: "一段" }, { Origin: "http://evil.example" });
  assert.equal(result.status, 403);
});

await check("太长的选段被拒，不发出去", async () => {
  seen.length = 0;
  const result = await api(port, "POST", "/api/assist/revise", { text: "字".repeat(6001) });
  assert.equal(result.status, 413);
  assert.equal(seen.length, 0);
});

await check("清除配置：文件删掉，状态回到未配置", async () => {
  const cleared = await api(port, "POST", "/api/assist/config", { clear: true });
  assert.equal(cleared.json.state, "unconfigured");
  await assert.rejects(stat(join(configDir, "gemini.json")));
});

await check("配置目录按系统放在用户目录下，可用环境变量改", async () => {
  assert.equal(configDirectory({ NOVEL_WORKSHOP_CONFIG_DIR: "/x/y" }, "linux", "/home/a"), "/x/y");
  assert.equal(configDirectory({}, "linux", "/home/a"), "/home/a/.config/novel-workshop");
  assert.equal(configDirectory({ APPDATA: "C:\\Users\\a\\AppData\\Roaming" }, "win32", "C:\\Users\\a").replaceAll("\\", "/"), "C:/Users/a/AppData/Roaming/novel-workshop");
  assert.equal(configDirectory({}, "darwin", "/Users/a"), "/Users/a/Library/Application Support/novel-workshop");
});

await check("启动器参数：只读、可编辑、作品目录、演示", async () => {
  assert.deepEqual(parseLauncherArguments(["--edit"]), { root: null, edit: true, demo: false });
  assert.deepEqual(parseLauncherArguments(["--read-only", "--root", "D:/作品"]), { root: "D:/作品", edit: false, demo: false });
  assert.deepEqual(parseLauncherArguments(["D:/作品"]), { root: "D:/作品", edit: null, demo: false });
  assert.equal(parseLauncherArguments(["--demo"]).demo, true);
});

await check("演示作品：合成示例写在临时目录，标明是合成的；Node 版本检查", async () => {
  const demoRoot = await createDemoWorkspace(base);
  const names = await readdir(demoRoot, { recursive: true });
  assert.ok(names.includes(join("正文", "第001章.md")));
  assert.ok((await readFile(join(demoRoot, "README.md"), "utf8")).includes("合成示例"));
  assert.ok((await readFile(join(demoRoot, "正文", "第001章.md"), "utf8")).includes("合成示例"));
  assert.equal(nodeTooOld("16.20.0"), true);
  assert.equal(nodeTooOld("18.0.0"), false);
  assert.equal(nodeTooOld("22.22.0"), false);
});

readOnlyServer.close();
editServer.close();
mock.close();
await rm(base, { recursive: true, force: true });
for (const [status, name, detail] of results) console.log(`${status} ${name}${detail ? `\n${detail}` : ""}`);
const failed = results.filter(([status]) => status !== "ok").length;
console.log(`${results.length - failed}/${results.length} passed`);
process.exit(failed ? 1 : 0);

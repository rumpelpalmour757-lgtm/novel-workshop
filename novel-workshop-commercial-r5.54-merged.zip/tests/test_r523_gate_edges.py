#!/usr/bin/env python3
"""r5.23: two edges of the r5.22 change coverage, from the 10-20 review of r5.22.

P2-G522-01 (in r5.19-r5.22): a whole line of dialogue that ends in an ellipsis ("他低声说：“我不去了……”") was cut
beside a sentence the review keeps, and the keep alone passed. The edge rule (a cut on the edge of a decision's words
counts when it is part of the same sentence) judged "same sentence" by line breaks and 。！？ only, so an utterance
that ends in an ellipsis, a dash or a closing quote counted as a few words of the kept sentence. Now words taken out
on the edge count only when they stay in the same sentence: no line break and, when they hold words, no more sentence
ends (。！？!?, an ellipsis or dash, a closing quotation mark or bracket) than the words put in their place. A cut puts
nothing in its place, so a cut of words with one such end needs a decision of its own; a cut of punctuation only (the
ellipsis alone), a few words of the same sentence, a speaker taken off ("她说：“") still count. The diff also ends a
sentence after an ellipsis or dash that a closing quote follows. Found on the way (in r5.16-r5.22 too): a sentence cut
right before a sentence whose first words were rewritten is joined by the diff into one rewrite on the edge of a keep
of that sentence, and the keep covered it; the old words of a rewrite on the edge now count the same way (a sentence
rewritten into another keeps its number of ends and still passes with a keep).

P2-G522-02 (new in r5.22): the order of the decisions in the review decided the result. With R / A / S cut down to
A, a decision "R+A -> A" listed before "R+A+S -> A" made the gate drop the whole second decision (its first cut was
already taken), so the cut of S was reported as unrecorded; listed the other way round, it passed. Now the
decisions are taken in an order of their own (where their edits stand, not the order of the list), and a decision
whose edits partly fall on edits already taken keeps the rest: the same edit is done once, cuts that overlap cuts are
one cut. Found by the random check: two decisions that tell one change two ways mixed into a text with neither
reading; when the first try leaves a change unexplained, the decisions are tried once more, each whole or not at
all, the one that quotes the most first.
Material is invented test data, not literary judgment.
"""

import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
GUARD = ROOT / "skills" / "novel-workshop" / "scripts" / "workflow_guard.py"
DIMENSIONS = ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function", "continuity",
              "revision_comparison")
P1 = "雨停以后，阿禾把木箱放在门边，解开麻绳，取出几只旧瓷碗。"
P2 = "老沈拿来报纸，把桌上的碗一只只包好，码进竹筐，又在筐底垫了一层稻草。"
P3 = "天黑以后，两人抬着竹筐回屋，灯芯剪过一次，屋里亮了些。"
A = "阿禾关好木窗，把灯芯拨亮了些。"
EVIDENCE = ("雨停以后，阿禾把木箱", "把桌上的碗一只只包好", "灯芯剪过一次，屋里亮了些")
NOTE = "测试数据：只验证记录结构"


def body(*paragraphs):
    return "\n\n".join(paragraphs) + "\n"


def change(before, after, **extra):
    return dict({"decision": "change", "before": before, "after": after, "judgment": NOTE, "reason": NOTE}, **extra)


def keep(quote, **extra):
    return dict({"decision": "keep", "quote": quote, "judgment": NOTE, "reason": NOTE}, **extra)


class Steps(unittest.TestCase):
    """Start a strict run, record a PASS on the old text, edit it, record reviews of the edit."""

    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.dir)

    def write(self, name, text):
        (self.dir / name).write_bytes((text).encode("utf-8"))

    def guard(self, *args):
        proc = subprocess.run([sys.executable, "-I", "-B", str(GUARD), *args], cwd=self.dir, capture_output=True,
                              text=True, encoding="utf-8")
        try:
            return proc.returncode, json.loads(proc.stdout)
        except ValueError:
            return proc.returncode, {"raw": proc.stdout[-400:], "stderr": proc.stderr[-400:]}

    def review(self, name, text, decisions):
        value = {"schema": "editorial-review/2", "verdict": "PASS",
                 "candidate_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                 "reviewer": {"mode": "self_check", "label": NOTE}, "checked_against": ["测试数据"], "inputs_read": [],
                 "evidence": [{"quote": q, "in": "candidate"} for q in EVIDENCE], "issues": [], "machine_dispositions": [],
                 "counter_evidence": "测试数据，不是真实文学审稿。",
                 "dimensions": [{"id": key, "status": "met", "note": NOTE} for key in DIMENSIONS],
                 "expression": {"scope": "chapter", "decisions": decisions, "segments": [
                     {"from": text[:8], "to": text.rstrip()[-8:],
                      "note": "测试数据：从“%s”连读到“%s”，逐句看过改动和前后句" % (text[:8], text.rstrip()[-8:])}]}}
        self.write(name, json.dumps(value, ensure_ascii=False))
        return name

    def edit_after_pass(self, old, new):
        self.write("draft.md", old)
        self.write("checks.json", json.dumps({"candidate": "draft.md", "mode": "strict", "checks": [
            {"id": "ending", "type": "contains", "text": "灯芯剪过一次"}]}, ensure_ascii=False))
        self.assertEqual(self.guard("start", "run.json", "--task-id", "t", "--spec", "checks.json")[0], 0)
        code, out = self.guard("record", "run.json", "--event-id", "v1", "--review", self.review("v1.json", old, []))
        self.assertEqual(code, 0, out)
        self.write("draft.md", new)
        self.assertEqual(self.guard("reserve", "run.json", "--event-id", "r1")[0], 0)

    def record(self, event, text, decisions):
        return self.guard("record", "run.json", "--event-id", event, "--review", self.review(event + ".json", text, decisions))

    def refused(self, out, low, high=None):
        """Refused, and the change it names stands on a line between low and high."""
        self.assertEqual(out.get("failure"), "REVIEW_INCOMPLETE", out.get("message", out))
        line = int(re.search(r"Candidate line (\d+) changed", out["message"]).group(1))
        self.assertTrue(low <= line <= (high or low), out["message"])

    def edge_cut(self, kept, cut, decisions, after=True):
        """The old line holds the kept words and the cut words side by side (cut after them, or before); the new
        line holds the kept words only. Returns the result of recording the given decisions."""
        line = kept + cut if after else cut + kept
        old, new = body(P1, line, P2, P3), body(P1, kept, P2, P3)
        self.edit_after_pass(old, new)
        return self.record("v2", new, decisions)


class AWholeUtteranceBesideKeptWordsNeedsItsOwnDecision(Steps):
    def test_an_utterance_that_ends_in_an_ellipsis(self):
        # The case of the review: only the sentence before it is kept.
        cut = "他低声说：“我不去了……”"
        code, out = self.edge_cut(A, cut, [keep(A)])
        self.refused(out, 3)

    def test_the_same_with_its_own_decision_passes(self):
        cut = "他低声说：“我不去了……”"
        code, out = self.edge_cut(A, cut, [keep(A), change(cut, "")])
        self.assertEqual(code, 0, out)

    def test_an_utterance_that_ends_in_a_dash(self):
        code, out = self.edge_cut(A, "他低声说：“我不去了——”", [keep(A)])
        self.refused(out, 3)

    def test_an_utterance_that_ends_in_a_closing_quote_only(self):
        code, out = self.edge_cut(A, "他问：“你们去哪”", [keep(A)])
        self.refused(out, 3)

    def test_narration_that_ends_in_an_ellipsis(self):
        code, out = self.edge_cut(A, "他看着窗外的雨……", [keep(A)])
        self.refused(out, 3)

    def test_an_utterance_cut_before_the_kept_words(self):
        code, out = self.edge_cut(A, "她问：“灯油够吗……”", [keep(A)], after=False)
        self.refused(out, 3)

    def test_a_cut_and_a_rewrite_in_a_run_of_utterances_stay_two_changes(self):
        # As r5.22's test with full stops (test_r522_deletion_places): three copies of an utterance that ends in an
        # ellipsis and a closing quote, one cut and the next rewritten. The diff ends a sentence after "……”", so the
        # copy that stays keeps the cut and the rewrite apart; read as one sentence, the cut fell inside the rewritten
        # words and a keep of them covered it.
        utterance = "他低声说：“我不去了……”"
        rewritten = utterance.replace("低声", "小声")
        old, new = body(P1, utterance * 3 + "门口。", P2, P3), body(P1, utterance + rewritten + "门口。", P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [keep(rewritten)])
        self.refused(out, 3)
        code, out = self.record("v3", new, [keep(rewritten), change(utterance * 2, utterance, offset=new.index(utterance))])
        self.assertEqual(code, 0, out)

    def test_two_utterances_on_one_line_are_two_sentences(self):
        # The first ends in an ellipsis and a closing quote; the diff now ends a sentence there.
        first, second = "他低声说：“我不去了……”", "她问：“为什么？”"
        old, new = body(P1, first + second, P2, P3), body(P1, second, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [keep(second)])
        self.refused(out, 3)
        code, out = self.record("v3", new, [keep(second), change(first, "")])
        self.assertEqual(code, 0, out)


class TheSameSentenceStillCounts(Steps):
    def test_a_few_words_of_the_same_sentence_on_the_edge_of_kept_words(self):
        # "了" goes; the kept words end right where it stood, inside the same utterance.
        code, out = self.edge_cut("他低声说：“我不去", "了", [keep("他低声说：“我不去")])
        self.assertEqual(code, 0, out)

    def test_an_ellipsis_alone_on_the_edge_of_kept_words(self):
        # Punctuation only: no words of a sentence of its own.
        old, new = body(P1, "他低声说：“我不去了……”", P2, P3), body(P1, "他低声说：“我不去了”", P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [keep("他低声说：“我不去了")])
        self.assertEqual(code, 0, out)


class ACutJoinedToARewriteOfTheNextSentence(Steps):
    # Found while repairing P2-G522-01 (in r5.16-r5.22 as well): a sentence cut right before a sentence whose first
    # words were rewritten. The diff joins the two into one change ("R。阿禾" became "她") on the edge of a keep of the
    # rewritten sentence, and the keep covered both. Now the old words of a rewrite on the edge of a decision's words
    # count as a cut there does: a few words of the same sentence only.
    A2 = "她关好木窗，把灯芯拨亮了些。"

    def joined(self, cut, decisions):
        old, new = body(P1, cut + A, P2, P3), body(P1, self.A2, P2, P3)
        self.edit_after_pass(old, new)
        return self.record("v2", new, decisions)

    def test_a_sentence_cut_before_a_rewritten_start(self):
        code, out = self.joined("他把木箱搬到门口。", [keep(self.A2)])
        self.refused(out, 3)

    def test_an_utterance_cut_before_a_rewritten_start(self):
        code, out = self.joined("他低声说：“我不去了……”", [keep(self.A2)])
        self.refused(out, 3)

    def test_narration_ending_in_an_ellipsis_cut_before_a_rewritten_start(self):
        code, out = self.joined("他看着窗外的雨……", [keep(self.A2)])
        self.refused(out, 3)

    def test_the_cut_with_its_own_decision_passes(self):
        code, out = self.joined("他把木箱搬到门口。", [keep(self.A2), change("他把木箱搬到门口。", "")])
        self.assertEqual(code, 0, out)

    def test_one_change_of_both_passes(self):
        code, out = self.joined("他把木箱搬到门口。", [change("他把木箱搬到门口。阿禾", "她")])
        self.assertEqual(code, 0, out)

    def test_a_rewrite_of_the_first_words_alone_still_passes_with_a_keep(self):
        old, new = body(P1, A, P2, P3), body(P1, self.A2, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [keep(self.A2)])
        self.assertEqual(code, 0, out)

    def test_a_rewrite_inside_the_kept_words_still_passes_with_a_keep(self):
        rewritten = "阿禾关上木窗，又把灯芯剪短了些。"
        old, new = body(P1, A, P2, P3), body(P1, rewritten, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [keep(rewritten)])
        self.assertEqual(code, 0, out)

    def test_a_sentence_cut_before_words_put_in_front_of_the_next(self):
        # The cut sentence and the new first words of the next one are one change in the diff ("R。" became "然后").
        rewritten = "然后" + A
        old, new = body(P1, "他把木箱搬到门口。" + A, P2, P3), body(P1, rewritten, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [keep(rewritten)])
        self.refused(out, 3)

    def test_an_utterance_rewritten_into_another_sentence_passes_with_a_keep(self):
        # One sentence in its place, ending as a sentence: its old words on the edge of the keep take no sentence
        # end away (the colon and the opening quote do not end anything).
        old, new = body(P1, "他说：“好。”" + A, P2, P3), body(P1, "风停了。" + A, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [keep("风停了。" + A)])
        self.assertEqual(code, 0, out)

    def test_a_sentence_rewritten_with_another_end_passes_with_a_keep(self):
        # "好。" became "行！": the old words on the edge take a sentence end, and the new words give one back.
        old, new = body(P1, "好。" + A, P2, P3), body(P1, "行！" + A, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [keep("行！" + A)])
        self.assertEqual(code, 0, out)

    def test_a_speaker_taken_off_a_kept_utterance_passes_with_a_keep(self):
        # "她说：“好。”" became "好。": the cut of "她说：“" on the edge of the kept words ends nothing.
        old, new = body(P1, "她说：“好。”" + A, P2, P3), body(P1, "好。" + A, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [keep("好。" + A)])
        self.assertEqual(code, 0, out)


class TheOrderOfTheDecisionsDoesNotMatter(Steps):
    # The case of the review: R / A / S cut down to A.
    R, S = "他把木箱搬到门口。", "她把湿蓑衣挂在墙上。"

    def setUp(self):
        super().setUp()
        self.old, self.new = body(P1, self.R, A, self.S, P2, P3), body(P1, A, P2, P3)
        self.left = change(self.R + "\n\n" + A, A)
        self.whole = change(self.R + "\n\n" + A + "\n\n" + self.S, A)
        self.edit_after_pass(self.old, self.new)

    def test_the_partial_decision_first(self):
        code, out = self.record("v2", self.new, [self.left, self.whole])
        self.assertEqual(code, 0, out)

    def test_the_whole_decision_first(self):
        code, out = self.record("v2", self.new, [self.whole, self.left])
        self.assertEqual(code, 0, out)

    def test_the_whole_decision_alone(self):
        code, out = self.record("v2", self.new, [self.whole])
        self.assertEqual(code, 0, out)

    def test_the_partial_decision_alone_is_still_refused(self):
        code, out = self.record("v2", self.new, [self.left])
        self.refused(out, 3, 5)  # the cut of S: after A (line 3), where P2 now begins (line 5)


class WhatTheseRulesLeaveAsBefore(Steps):
    """A behaviour of r5.20-r5.22 that the r5.23 rule must not change, and that no other test would see change."""

    def test_new_words_that_run_into_kept_words_count_as_before(self):
        # New words only (nothing taken out): they count where they overlap words a decision keeps (r5.20), even when
        # the keep starts inside them.
        old, new = body(P1, A, P2, P3), body(P1, "天黑了，" + A, P2, P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [keep("了，" + A)])
        self.assertEqual(code, 0, out)


class OverlappingDecisionsGiveOneAnswerInEitherOrder(Steps):
    # Two decisions that overlap with different edits: one cuts two sentences, the other quotes the end of the second
    # and the first words of the next sentence, which were rewritten. Taken in the order of the list, the second
    # listed first would keep its rewrite and leave out the cut that overlaps it, and the first sentence's cut would
    # stand unrecorded; listed the other way round, the record passed. Taken in order of where their edits stand,
    # both orders give the same answer.
    R, S = "他把木箱搬到门口。", "她把湿蓑衣挂在墙上。"
    A2 = "她关好木窗，把灯芯拨亮了些。"

    def setUp(self):
        super().setUp()
        self.new = body(P1, self.A2, P2, P3)
        self.edit_after_pass(body(P1, self.R + self.S + A, P2, P3), self.new)
        self.cut, self.rewrite = change(self.R + self.S, ""), change("挂在墙上。阿禾", "她")

    def test_the_cut_listed_first(self):
        code, out = self.record("v2", self.new, [self.cut, self.rewrite])
        self.assertEqual(code, 0, out)

    def test_the_rewrite_listed_first(self):
        code, out = self.record("v2", self.new, [self.rewrite, self.cut])
        self.assertEqual(code, 0, out)


class TheSameBesideCutsThatMustBeJoined(OverlappingDecisionsGiveOneAnswerInEitherOrder):
    # As above, with two more decisions further on that both quote the line break they cut (r5.22's case): their cuts
    # are joined into one only when done edit by edit, so the second try (each decision whole) cannot pass this
    # record, and the first try alone must give the same answer in either order.
    W, B = "她说：“好。”", "老沈点了点头，把竹筐往里推了推。"

    def setUp(self):
        Steps.setUp(self)
        self.new = body(P1, self.A2, self.W, P2, P3)
        self.edit_after_pass(body(P1, self.R + self.S + A, self.W + self.W, self.B, P2, P3), self.new)
        self.cut, self.rewrite = change(self.R + self.S, ""), change("挂在墙上。阿禾", "她", offset=self.new.index(self.A2))
        self.joined = [change(self.W + self.W + "\n\n", self.W), change(self.W + "\n\n" + self.B, self.W)]

    def test_the_cut_listed_first(self):
        code, out = self.record("v2", self.new, [self.cut, self.rewrite] + self.joined)
        self.assertEqual(code, 0, out)

    def test_the_rewrite_listed_first(self):
        code, out = self.record("v2", self.new, [self.rewrite, self.cut] + self.joined)
        self.assertEqual(code, 0, out)


class ARedundantDecisionThatSaysItAnotherWay(Steps):
    # Found by the random check of r5.23 (fuzz_edit_marks.py): an utterance rewritten into a sentence that also stood
    # further on, and that later copy cut. Two decisions say so (the rewrite; the cut with the words before it); a
    # third quotes the whole passage, and its own edit reads it as the utterance and a sentence cut and the sentence
    # put back after the next. Done edit by edit, the three gave a text with neither reading. The decisions are now
    # tried once more, each done whole or not at all, the one that quotes the most first: the whole passage is done,
    # the rewrite falls on it and is left out, and the record passes.
    LINE = "他看着窗外的雨……她问：“你们去哪”他走了。他把竹筐放在门口。"
    NEW_LINE = "他看着窗外的雨……他把竹筐放在门口。他走了。"

    def setUp(self):
        super().setUp()
        self.new = body(P1, self.NEW_LINE, P2, P3)
        self.edit_after_pass(body(P1, self.LINE, P2, P3), self.new)
        moved = self.new.index("他把竹筐放在门口。")
        self.rewrite = change("她问：“你们去哪”", "他把竹筐放在门口。", offset=moved)
        self.cut = change("他走了。他把竹筐放在门口。\n\n", "他走了。\n\n", offset=self.new.index("他走了。\n\n"))
        self.whole = change("她问：“你们去哪”他走了。他把竹筐放在门口。", "他把竹筐放在门口。他走了。", offset=moved)

    def test_the_two_decisions(self):
        code, out = self.record("v2", self.new, [self.rewrite, self.cut])
        self.assertEqual(code, 0, out)

    def test_the_whole_decision_alone(self):
        code, out = self.record("v2", self.new, [self.whole])
        self.assertEqual(code, 0, out)

    def test_all_three(self):
        code, out = self.record("v2", self.new, [self.rewrite, self.cut, self.whole])
        self.assertEqual(code, 0, out)

    def test_the_rewrite_then_the_whole(self):
        code, out = self.record("v2", self.new, [self.rewrite, self.whole])
        self.assertEqual(code, 0, out)

    def test_the_whole_then_the_rewrite(self):
        code, out = self.record("v2", self.new, [self.whole, self.rewrite])
        self.assertEqual(code, 0, out)

    def test_the_rewrite_alone_is_still_refused(self):
        code, out = self.record("v2", self.new, [self.rewrite])
        self.refused(out, 3)


class TheNotesSaySo(unittest.TestCase):
    def test_execution_notes_name_the_marks_and_the_order(self):
        notes = (ROOT / "skills" / "novel-workshop" / "references" / "execution.md").read_text(encoding="utf-8")
        line = next(l for l in notes.splitlines() if "同一行里改了几处、相邻几行一起改了，各要一条" in l)
        for phrase in ("省略号、破折号、后引号或后括号", "比对会把两处并成一处改写", "和记录排列的先后无关", "再按整条记录试一次", "r5.23"):
            self.assertIn(phrase, line)


if __name__ == "__main__":
    unittest.main()

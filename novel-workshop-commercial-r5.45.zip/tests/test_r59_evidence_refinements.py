#!/usr/bin/env python3
"""r5.9: one refinement of the evidence checks, from the 2026-10-17 breakdown record of a reference work's opening
(version 22, segments 22-25). A character explains how he gets past an opponent's ability and then succeeds once; the
record notes that the ability, as stated earlier, alters the very thing the explanation relies on. The workshop had
"solve dangers with abilities already shown" but not this check: the explanation and one success do not prove the
counter holds under the ability's rules; the gap is listed for the author, not filled in, and not judged a hard
contradiction. The example is new and neutral (nothing from the reference work is in this package).

These tests only hold where the refinement is written and that it is written once. Whether reviews get better for it
is not tested and has not been evaluated.
"""
import os
from pathlib import Path
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
REFS = ROOT / "skills" / "novel-workshop" / "references"


def section(name, heading):
    text = (REFS / name).read_text(encoding="utf-8")
    start = text.index("\n## " + heading + "\n")
    end = text.find("\n## ", start + 1)
    return text[start:] if end == -1 else text[start:end]


class CounterExplanations(unittest.TestCase):
    def row(self):
        evidence = section("continuity.md", "动作状态与证据等级")
        return next(line for line in evidence.splitlines() if line.startswith("| 人物说明自己凭什么破解对方的能力"))

    def test_the_row_says_what_one_success_does_not_prove(self):
        cells = [cell.strip() for cell in self.row().strip("|").split("|")]
        self.assertEqual(len(cells), 3, cells)
        self.assertIn("随后一次得手", cells[0])
        self.assertEqual(cells[1], "这个办法在能力规则里站得住")
        for phrase in ("列待核", "能力改了什么、没改什么", "不替作者补", "不直接判成硬矛盾"):
            self.assertIn(phrase, cells[2])

    def test_the_example_is_new(self):
        row = self.row()
        self.assertIn("回声", row)
        self.assertNotIn("雨", row)

    def test_it_is_written_once(self):
        texts = {path.name: path.read_text(encoding="utf-8") for path in REFS.glob("*.md")}
        homes = sorted(name for name, text in texts.items() if "凭什么破解对方的能力" in text)
        self.assertEqual(homes, ["continuity.md"])


if __name__ == "__main__":
    unittest.main()

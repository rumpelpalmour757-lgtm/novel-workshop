#!/usr/bin/env python3
"""r5.55: the package carries its licence, and the packaging lists match the folder.

The copyright holder chose the MIT licence on 2026-11-13 (Copyright (c) 2026 Celeste); the three third-party
components keep their own MIT licences and copyright lines. These tests check that the licence text is in the
package root and in the skill folder (someone who installs only the skill folder sees it too), that both exports
and the single file carry it, that the notices name the third-party copyright lines exactly as their licence files
do, and that the pages no longer say the licence is undecided.

They also check two packaging gaps found in the review of the merged candidate: the sale list in
export_portable.py no longer matched the skill folder (twelve test files had been added to the folder only), and
the style packs' README still told people to install the folder as a skill although its entry file is ENGINE.md.
"""
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import unittest
import zipfile

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
VERSION = "2026-11-14-r5.55"

MIT_SENTENCES = (
    "Permission is hereby granted, free of charge, to any person obtaining a copy",
    "The above copyright notice and this permission notice shall be included in all",
    'THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR',
)
THIRD_PARTY = {
    "skills/novel-workshop/assets/third-party/oh-story-LICENSE.txt": "Copyright (c) 2025-2026 oh-story-claudecode",
    "skills/novel-workshop/assets/third-party/oh-story-0.8.4-LICENSE.txt": "Copyright (c) 2025-2026 oh-story-claudecode",
    "skills/darwin-novel-workshop/LICENSE": "Copyright (c) 2026 alchaincyf (花叔)",
    "optional/typesafe-ai/LICENSE": "Copyright (c) 2026 TypeSafe AI",
}
# Wording from before the licence was chosen; it must not come back in the pages that state the current terms.
UNDECIDED = ("不将整包统一声明为 MIT", "使用条件还没有确认", "包里没有许可文件", "使用条件仍待确认", "整体尚未指定许可",
             "使用条件沿用原许可说明", "使用条件见", "还没有写明")
# Files in the skill folder that are not yet on the sale list, each waiting for a content review (see CHANGELOG r5.55).
# r5.55 review: test_genre_config.py joined the list once its phrase and name were newly written.
NOT_YET_REVIEWED = set()


def read(path):
    return (ROOT / path).read_text(encoding="utf-8")


def load_exporter():
    spec = importlib.util.spec_from_file_location("export_portable_r555", SKILL / "scripts" / "export_portable.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def newest_entry(text):
    """The text of the first '## ' section of a changelog-like page."""
    parts = re.split(r"(?m)^## ", text)
    return parts[1] if len(parts) > 1 else ""


def entry_for(text, version):
    """The text of the '## ' section of a changelog-like page whose heading starts with version ("" if none)."""
    return next((part for part in re.split(r"(?m)^## ", text)[1:] if part.startswith(version)), "")


class Licence(unittest.TestCase):
    def test_the_licence_is_the_mit_text_in_the_root_and_in_the_skill(self):
        root = (ROOT / "LICENSE").read_bytes()
        text = root.decode("utf-8")
        self.assertTrue(text.startswith("MIT License\n\nCopyright (c) 2026 Celeste\n\n"), text[:80])
        for sentence in MIT_SENTENCES:
            self.assertIn(sentence, text)
        self.assertEqual((SKILL / "LICENSE").read_bytes(), root)

    def test_the_notices_carry_each_third_party_copyright_line_as_its_licence_file_does(self):
        notices = read("THIRD-PARTY-NOTICES.md")
        self.assertIn("[LICENSE](LICENSE)", notices)
        self.assertIn("Celeste", notices)
        for path, line in THIRD_PARTY.items():
            self.assertIn(line, read(path).splitlines(), path)
            self.assertIn(line.replace("Copyright (c) ", ""), notices, path)
            self.assertIn("`" + path + "`", notices, path)
        for sentence in MIT_SENTENCES:
            self.assertIn(sentence, notices)
        # Every package path the notices name in backticks is there.
        for name in re.findall(r"`((?:skills|optional)/[^`*]+)`", notices):
            self.assertTrue((ROOT / name.rstrip("/")).exists(), name)

    def test_the_pages_state_the_current_terms(self):
        for page in ("README.md", "USAGE.md", "QUICKSTART.md", "LICENSE-NOTICES.md", "MERGE-VERIFICATION.md",
                     "skills/novel-workshop/assets/third-party/SOURCE-NOTES.md",
                     "skills/novel-workshop/references/style-packs.md"):
            text = read(page)
            for phrase in UNDECIDED:
                self.assertNotIn(phrase, text, (page, phrase))
        for page in ("README.md", "LICENSE-NOTICES.md"):
            text = read(page)
            self.assertIn("MIT", text, page)
            self.assertIn("Celeste", text, page)
            self.assertIn("(THIRD-PARTY-NOTICES.md)", text, page)
        # r5.56: the r5.55 entry is no longer the newest one. It is looked up by its heading and must still state the
        # licence; the newest entry, whichever release it is, must not bring the undecided wording back.
        changelog = read("CHANGELOG.md")
        entry = entry_for(changelog, VERSION)
        self.assertTrue(entry.startswith(VERSION), entry[:60])
        self.assertIn("MIT", entry)
        for text in (entry, newest_entry(changelog)):
            for phrase in UNDECIDED:
                self.assertNotIn(phrase, text, phrase)

    def test_the_source_notes_record_the_merged_modules_and_the_quality_loop_source(self):
        notes = read("skills/novel-workshop/assets/third-party/SOURCE-NOTES.md")
        row = next((line for line in notes.splitlines() if "`scripts/chapter_gate.py`" in line), "")
        for phrase in ("`scripts/learning_loop.py`", "`scripts/demonstration_memory.py`", "由版权人提供", "标准库"):
            self.assertIn(phrase, row)
        row = next((line for line in notes.splitlines() if "Builder–Judge–Manager v2.7" in line), "")
        self.assertIn("版权人本人所写", row)
        self.assertIn("MIT", row)
        self.assertNotIn("不推定授权范围", row)


class Exports(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.exporter = load_exporter()

    def test_the_licence_is_on_both_lists_and_in_every_export(self):
        self.assertIn("LICENSE", self.exporter.SALE_FILES)
        self.assertIn("LICENSE", self.exporter.REQUIRED_METADATA)
        licence = (SKILL / "LICENSE").read_bytes()
        with tempfile.TemporaryDirectory() as tmp:
            for mode in ("personal", "sale"):
                for form in ("portable", "install"):
                    target = Path(tmp) / ("%s-%s.zip" % (mode, form))
                    self.exporter.export(SKILL, target, mode=mode, format=form)
                    with zipfile.ZipFile(target) as archive:
                        self.assertEqual(archive.read("novel-workshop/LICENSE"), licence, (mode, form))

    def test_the_export_guide_names_the_package_licence(self):
        # The README.md written into a portable export said only "MIT 许可见 oh-story-LICENSE.txt", which reads as if
        # Oh Story's licence covered the whole export.
        with tempfile.TemporaryDirectory() as tmp:
            for mode in ("personal", "sale"):
                target = Path(tmp) / (mode + ".zip")
                self.exporter.export(SKILL, target, mode=mode)
                with zipfile.ZipFile(target) as archive:
                    guide = archive.read("README.md").decode("utf-8")
                self.assertIn("本工坊按 MIT 许可发布，全文见 [LICENSE](novel-workshop/LICENSE)", guide, mode)
                self.assertIn("Oh Story 的 MIT 许可见", guide, mode)

    def test_the_single_file_opening_states_the_licence(self):
        with tempfile.TemporaryDirectory() as tmp:
            for mode in ("personal", "sale"):
                target = Path(tmp) / (mode + ".zip")
                self.exporter.export(SKILL, target, mode=mode)
                with zipfile.ZipFile(target) as archive:
                    single = archive.read("portable-novel-workshop.md").decode("utf-8")
                intro = single.split("\n\n")[1]
                for phrase in ("MIT", "Copyright (c) 2026 Celeste", "LICENSE", "第三方组件"):
                    self.assertIn(phrase, intro, mode)

    def test_the_sale_list_is_the_skill_folder(self):
        on_disk = set()
        for path in SKILL.rglob("*"):
            relative = path.relative_to(SKILL).as_posix()
            if path.is_file() and not self.exporter.excluded_path(relative) \
                    and not relative.startswith(self.exporter.PROJECT_PREFIX):
                on_disk.add(relative)
        sale = set(self.exporter.SALE_FILES)
        self.assertEqual(sale - on_disk, set())
        self.assertEqual(on_disk - sale, NOT_YET_REVIEWED)

    def test_the_style_pack_list_is_in_order(self):
        files = list(self.exporter.STYLE_PACK_FILES)
        self.assertEqual(files, sorted(files))


class Pages(unittest.TestCase):
    def test_the_r555_records_stay_as_history(self):
        # r5.56: this test pinned r5.55 as the current version on the five pages, in the manifest and at the top of
        # VERIFICATION.md. The current version is pinned in test_r556_package.py now, the same way; here the r5.55
        # entries are checked to stay where they were, below the newer ones, with what they said.
        changelog = entry_for(read("CHANGELOG.md"), VERSION)
        self.assertTrue(changelog.startswith(VERSION + "（小说写作工坊 r5.55）"), changelog[:60])
        self.assertIn("作者改法累计挪出技能目录", changelog)
        verification = entry_for(read("VERIFICATION.md"), VERSION)
        self.assertTrue(verification.startswith(VERSION + " 的验证"), verification[:60])
        self.assertIn("运行 1589 项", verification)
        manifest = json.loads(read("PACKAGE-MANIFEST.json"))
        self.assertNotEqual(manifest["version"], VERSION)  # a newer release carries this test
        self.assertIn("**r5.55**", read("README.md"))

    def test_the_merge_record_says_what_was_compared_and_what_reads_stale(self):
        text = read("MERGE-VERIFICATION.md")
        for phrase in ("2026-11-13-r5.54-candidate", "2026-11-11-r5.53-candidate", "STALE", "58a059ac", "88b39868",
                       "绑定值填错时拒绝"):
            self.assertIn(phrase, text)
        self.assertNotIn("错版拒绝", text)

    def test_the_style_pack_readmes_say_to_rename_the_entry_before_installing_it_alone(self):
        for pack in ("urban-martial-style-engines", "universal-novel-realism-engine"):
            text = read("skills/novel-workshop/assets/style-packs/%s/README.md" % pack)
            self.assertNotIn("把整个文件夹放到 `~/.claude/skills/`", text, pack)
            self.assertIn("ENGINE.md", text, pack)
            self.assertIn("SKILL.md", text, pack)
            self.assertIn("改名", text, pack)


if __name__ == "__main__":
    unittest.main()

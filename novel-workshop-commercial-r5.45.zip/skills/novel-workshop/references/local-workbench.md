# 本地工作台与拆文辅助工具

用于作者明确要求查看本地作品、搜索文件、编辑文稿或为长文建立定位时。普通聊天写作无需启动服务；安装技能不会自动开工作台、联网或处理私人文稿。

## 查看自己的作品

在技能根目录运行以下命令，把示例路径替换为实际选定的作品目录。需要 Node.js 18 或更新版本，仅使用内置模块，无需安装依赖。

```text
node scripts/oh-story/dashboard-server.mjs --root "D:/小说/我的作品"
```

打开终端实际显示的本机地址。默认端口为 43110；占用时尝试后续可用端口。按 Ctrl+C 停止。只允许本机回环地址，必须明确传入作品根目录，不自动扫描个人主目录。

工作台支持拆文库与写作项目分栏、按文件名搜索、目录分页、文本查看、Markdown 预览、行号、明暗模式和恢复上次视图。搜索不是全文搜索。识别 `正文`、`大纲`、`设定`、`追踪` 等常见结构；没有这些目录时展示指定根目录，原有作品无需重排。文件超过 2 MiB 时使用本地编辑器。

## 按需编辑与恢复

默认只读。作者需要在工作台编辑时，停止原服务并增加参数重新启动：

```text
node scripts/oh-story/dashboard-server.mjs --root "D:/小说/我的作品" --allow-edit
```

每次保存前，在作品根目录的 `.novel-workshop-backups/` 中保留原始字节与记录。每份备份包含 `original.bin` 和 `record.json`，后者注明原相对路径、保存时间和 SHA-256。备份失败时不保存。恢复时先对照记录定位原文，再另存或在作者要求下恢复；工作台不自动清理备份，不提供删除文件功能。

保存会核对打开时的文件版本。发现外部修改时拒绝覆盖，先重载或人工合并。此核对不能替代跨机器同步或所有外部编辑器的并发协议。项目权威状态仍按 [状态存储](state-storage.md) 更新；不要通过工作台直接编辑由 `project_state.py` 管理的状态文件。工作台用于正文和普通参考文本，不替代状态提交接口。

工作台不调用模型，不自动改写正文，不是云端服务。它没有图片搜索和选图界面：参考图按 [灵感库](inspiration-library.md) 在对话里推荐、由作者挑，挑中的记进本书的灵感库。AI 协助编辑仍由当前会话的任务与授权决定。

## 章节索引与既有拆文检查

可选 Python 工具需要 Python 3.9 或更新版本。只在用户要求建立索引或保存分析时运行。以下命令从技能根目录执行，路径均须换成实际项目路径。

```text
python scripts/oh-story/build_chapter_index.py --source "D:/拆文/原文/参考稿.txt" --output "D:/拆文/章节索引.csv"
python scripts/oh-story/inspect_existing_assets.py --root "D:/拆文" --compact
```

索引器读取 UTF-8 / UTF-8 BOM / GB18030 原文，生成章节范围、原文行号、字符数与内容哈希，不生成文学分析。先核查识别出的章标题和章数；没有标准章标题的文本可人工建立范围表。工具可发现源文件与已有索引不一致，先说明差异再决定是否在备份后 `--rebuild`，不要把该参数当作默认修复。

检查器面向 Oh Story 格式的拆文目录，只读输出已有材料与覆盖情况；现有工坊项目不满足它的目录约定，不等于稿件不合格。它不判定小说质量，也不应要求作者为检查器重建全部工程。长短篇实际分析使用 [完整拆文与技法库](deconstruction-library.md)，批次进度沿用 [执行与恢复](execution.md)。

## 生成人物关系图

在分析目录建立 `角色/角色关系.md`，按原文证据填写有方向的关系表，例如：

```text
| 主体 | 客体 | 关系动作 | 变化后状态 | 触发事件 |
| --- | --- | --- | --- | --- |
| 人物甲 | 人物乙 | 保护 | 有限信任 | 第二章共同逃脱 |
```

然后运行：

```text
python scripts/oh-story/render_relation_chart.py --root "D:/拆文"
```

输出 `人物关系图/人物关系图.md`，包括 Mermaid 关系图与文字清单。该目录是可重新生成的结果，重新运行会更新它；人工改动先另存。需要 PNG 时可加 `--png`，仅在环境已有 matplotlib 和能覆盖全部字符的中文字体时生成，缺依赖则保留 Markdown 结果；不自动安装软件。图表不自行推断人物关系。

## 随包资源与出处

工作台：[服务程序](../scripts/oh-story/dashboard-server.mjs)、[页面](../assets/dashboard/index.html)、[交互](../assets/dashboard/app.js)、[样式](../assets/dashboard/styles.css)、[主题](../assets/dashboard/tokens.css)。

拆文工具：[章节索引](../scripts/oh-story/build_chapter_index.py)、[既有材料检查器](../scripts/oh-story/inspect_existing_assets.py)、[人物关系图](../scripts/oh-story/render_relation_chart.py)。索引器依赖同目录检查器，分发时保持相对位置。

以上工具改编或取自 Oh Story 0.8.4。工作台增加只读默认、显式根目录、保存前备份、删除禁用、本机访问限制和工坊界面；三项 Python 工具保留原实现。具体范围见 [补全记录](../assets/third-party/INTEGRATION-NOTES.md) 与 [MIT 许可](../assets/third-party/oh-story-0.8.4-LICENSE.txt)。

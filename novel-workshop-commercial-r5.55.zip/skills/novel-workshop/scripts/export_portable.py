#!/usr/bin/env python3
"""Export a complete skill installer or portable package using only Python 3."""

import argparse
import os
from pathlib import Path, PurePosixPath
import posixpath
import re
import sys
import tempfile
from urllib.parse import unquote, urlsplit
import zipfile


PROJECT_PREFIX = "assets/project-packs/"
SOURCE_NOTES = "assets/third-party/SOURCE-NOTES.md"
GATE_CARD = "assets/delivery-gate-card.md"
# r5.48: the revision card follows the gate card at the top of the single file: in a chat with no scripts it is the
# whole procedure for a de-AI, tightening or immediacy revision, and a long upload is often read from the top.
REVISION_CARD = "assets/revision-card.md"
# r5.55: the package's MIT licence sits in the skill folder too, so every export carries it.
REQUIRED_METADATA = (
    "LICENSE",
    "agents/openai.yaml",
    "assets/icon.svg",
    SOURCE_NOTES,
    "assets/third-party/oh-story-LICENSE.txt",
)
# The visual-materials command line imports its package; the package files ship with it (r5.35).
VISUAL_PACKAGE = (
    "scripts/visual_materials/__init__.py",
    "scripts/visual_materials/adopt.py",
    "scripts/visual_materials/collect.py",
    "scripts/visual_materials/common.py",
    "scripts/visual_materials/dedupe.py",
    "scripts/visual_materials/doctor.py",
    "scripts/visual_materials/providers/__init__.py",
    "scripts/visual_materials/providers/openverse.py",
    "scripts/visual_materials/providers/searxng.py",
    "scripts/visual_materials/rank.py",
    "scripts/visual_materials/review.py",
    "scripts/visual_materials/search.py",
    "scripts/visual_materials/selection.py",
    "scripts/visual_materials/verify.py",
)
# The two style packs ship whole (r5.47): their own ENGINE.md (the packs' SKILL.md, renamed in the merged
# candidate) links only a few of these files, and the yaml, prompts and scripts are read by the packs themselves.
# Listed one by one like the sale profile, in sorted order (r5.55); a test compares this list with the folder,
# so a file added to a pack has to be added (and reviewed) here.
STYLE_PACK_GUIDE = "references/style-packs.md"
STYLE_PACK_PREFIX = "assets/style-packs/"
STYLE_PACK_FILES = (
    "assets/style-packs/universal-novel-realism-engine/ENGINE.md",
    "assets/style-packs/universal-novel-realism-engine/README.md",
    "assets/style-packs/universal-novel-realism-engine/docs/v17.1.1修订.md",
    "assets/style-packs/universal-novel-realism-engine/docs/v17.1.2修订.md",
    "assets/style-packs/universal-novel-realism-engine/docs/改动明细.md",
    "assets/style-packs/universal-novel-realism-engine/docs/整理说明.md",
    "assets/style-packs/universal-novel-realism-engine/prompts/00_内核.md",
    "assets/style-packs/universal-novel-realism-engine/prompts/01_内核+搏杀.md",
    "assets/style-packs/universal-novel-realism-engine/prompts/02_内核+手艺.md",
    "assets/style-packs/universal-novel-realism-engine/prompts/03_内核+查案.md",
    "assets/style-packs/universal-novel-realism-engine/prompts/04_内核+市井.md",
    "assets/style-packs/universal-novel-realism-engine/prompts/05_内核+情感.md",
    "assets/style-packs/universal-novel-realism-engine/prompts/06_内核+结构.md",
    "assets/style-packs/universal-novel-realism-engine/prompts/07_与都市高武同用.md",
    "assets/style-packs/universal-novel-realism-engine/references/cartridges/1_combat_survival.yaml",
    "assets/style-packs/universal-novel-realism-engine/references/cartridges/2_occupational_craft.yaml",
    "assets/style-packs/universal-novel-realism-engine/references/cartridges/3_investigation_espionage.yaml",
    "assets/style-packs/universal-novel-realism-engine/references/cartridges/4_economy_underworld.yaml",
    "assets/style-packs/universal-novel-realism-engine/references/cartridges/5_emotion_domestic.yaml",
    "assets/style-packs/universal-novel-realism-engine/references/cartridges/6_structure_closure.yaml",
    "assets/style-packs/universal-novel-realism-engine/references/interop.yaml",
    "assets/style-packs/universal-novel-realism-engine/references/kernel.yaml",
    "assets/style-packs/universal-novel-realism-engine/references/layers.md",
    "assets/style-packs/universal-novel-realism-engine/references/layers.yaml",
    "assets/style-packs/universal-novel-realism-engine/references/library.json",
    "assets/style-packs/universal-novel-realism-engine/references/rules.yaml",
    "assets/style-packs/universal-novel-realism-engine/references/state_schema.yaml",
    "assets/style-packs/universal-novel-realism-engine/references/与题材包同用.md",
    "assets/style-packs/universal-novel-realism-engine/scripts/build_library.py",
    "assets/style-packs/universal-novel-realism-engine/scripts/common.py",
    "assets/style-packs/universal-novel-realism-engine/scripts/export_prompt.py",
    "assets/style-packs/universal-novel-realism-engine/scripts/lint_text.py",
    "assets/style-packs/universal-novel-realism-engine/scripts/mount.py",
    "assets/style-packs/universal-novel-realism-engine/templates/状态追踪.yaml",
    "assets/style-packs/urban-martial-style-engines/ENGINE.md",
    "assets/style-packs/urban-martial-style-engines/README.md",
    "assets/style-packs/urban-martial-style-engines/docs/v2.0.1修订.md",
    "assets/style-packs/urban-martial-style-engines/docs/v2.0.2修订.md",
    "assets/style-packs/urban-martial-style-engines/docs/改动明细.md",
    "assets/style-packs/urban-martial-style-engines/docs/整理说明.md",
    "assets/style-packs/urban-martial-style-engines/prompts/00_底座与目录.md",
    "assets/style-packs/urban-martial-style-engines/prompts/01_配方_寒门开局.md",
    "assets/style-packs/urban-martial-style-engines/prompts/02_配方_防线战争卷.md",
    "assets/style-packs/urban-martial-style-engines/prompts/03_配方_都市缉凶卷.md",
    "assets/style-packs/urban-martial-style-engines/prompts/04_配方_诡异镇压卷.md",
    "assets/style-packs/urban-martial-style-engines/prompts/05_配方_门阀商战卷.md",
    "assets/style-packs/urban-martial-style-engines/prompts/06_配方_秘境拓荒卷.md",
    "assets/style-packs/urban-martial-style-engines/prompts/07_配方_隐藏大佬日常.md",
    "assets/style-packs/urban-martial-style-engines/prompts/08_配方_体制刑侦卷.md",
    "assets/style-packs/urban-martial-style-engines/prompts/09_配方_终局三章.md",
    "assets/style-packs/urban-martial-style-engines/prompts/10_配方_凶兽吃播.md",
    "assets/style-packs/urban-martial-style-engines/references/L0_core.yaml",
    "assets/style-packs/urban-martial-style-engines/references/catalog.md",
    "assets/style-packs/urban-martial-style-engines/references/engines/01_abyss_frontline_ironblood.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/02_kengan_anatomical_brutality.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/03_bio_cyber_zaibatsu.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/04_weird_flesh_martial.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/05_grandmaster_micro_control.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/06_grinder_proficiency_ascension.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/07_stratosphere_deity_cataclysm.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/08_tactical_ballistic_assassin.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/09_manic_deadpan_subversion.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/100_hundred_streams_return_to_one.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/101_karmic_sin_executioner.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/102_mirror_synapse_copycat.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/103_intoxicated_octane_berserker.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/104_vault_heist_armor_breaker.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/105_fortune_roulette_all_in_gambler.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/106_nanoswarm_apocalypse_hive.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/107_halo_drop_kinetic_meteor.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/108_hundred_eight_stars_great_wall.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/109_reactor_core_containment_martial.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/10_telekinetic_blade_matrix.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/110_crippled_meridian_reforging.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/111_catastrophe_actuary_adjuster.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/112_biological_hive_heart_surgical.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/114_hypersonic_courier_urban_parkour.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/115_abattoir_butcher_dissection.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/116_martial_blind_date_clash.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/117_war_photojournalist_shutter.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/118_bio_electric_hacker_martial.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/119_temporal_amber_stasis_scissors.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/11_alchemical_gastronomy_tempering.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/120_plastic_surgeon_facial_identity_thief.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/121_quantum_entanglement_assassination.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/122_fourth_wall_author_retcon.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/123_cyber_taoist_quantum_alchemy.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/124_memory_wipe_social_erasure.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/125_multiverse_simultaneous_slash.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/126_heat_death_entropy_zero.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/127_cosmic_string_slicing_martial.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/128_entropy_reversal_chronos_boxing.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/129_information_hazard_memetic_fist.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/12_twilight_valkyrie_legacy.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/130_probabilistic_cloud_superposition_claw.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/131_topological_manifold_folding_kick.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/132_the_final_observer_paradox.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/134_void_matter_genesis_forging.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/135_epoch_rollback_chronos_reversal.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/136_conceptual_anchor_eldritch_aberration.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/137_cognitive_collapse_iq_reduction_field.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/138_ultimate_narrative_closure_stamp.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/139_asylum_qi_deviation_ward.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/13_aristocratic_monopoly_politicking.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/140_power_grid_lightning_thief.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/141_stunt_double_cinema_martial.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/142_merit_medal_demolition_standoff.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/143_museum_relic_spirit_awakening.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/144_last_lecture_chalk_sword.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/145_core_defusal_bomb_squad.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/146_fossil_jade_gambling_eye.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/147_border_customs_contraband_inspector.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/148_quantum_divination_fate_hacker.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/149_legitimate_defense_legal_brawler.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/14_global_broadcast_shockwave.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/150_ancestral_hall_genealogy_ascension.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/15_myth_architect_puppeteer.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/16_heavy_forge_metallurgy.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/17_academy_apex_tourney.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/18_catacomb_expedition_frontier.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/19_combat_triage_reconstruction.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/20_noir_inquisitor_manhunt.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/21_hearth_and_aegis_slice.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/22_black_market_smuggler_bazaar.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/23_dojo_expansion_empire.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/24_relic_archaeology_decoding.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/25_abnormal_containment_sanitizer.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/26_panopticon_supermax_riot.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/27_mental_crucible_willpower.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/28_titan_exosuit_synchronization.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/29_geopolitical_martial_summit.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/30_martial_wallstreet_shorting.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/31_apex_beast_cavalry.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/32_vertical_skyscraper_chase.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/33_infrasonic_frequency_requiem.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/34_megacity_leyline_geomancy.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/35_laplace_causality_gambit.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/36_orbital_zero_gravity_cleave.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/37_clone_vessel_attrition.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/38_armored_shinkansen_convoy.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/39_ballistic_qi_artillery.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/40_biohazard_venom_apotheosis.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/41_vivisection_research_director.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/42_darkweb_bounty_broker.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/43_last_bastion_solo_stand.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/45_life_simulator_timeline_reset.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/46_wasteland_biker_gang_rampage.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/47_underground_beast_evolution.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/49_abyssal_trench_cavitation.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/50_gaokao_champion_bidding_war.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/51_hell_camp_drill_instructor.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/52_martial_intent_calligraphy.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/53_tachyon_synapse_stasis.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/54_primordial_genome_atavism.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/55_martyr_cemetery_gravekeeper.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/56_undercover_cult_infiltrator.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/57_imperial_inspector_purge.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/58_shadow_legion_burial.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/60_spiritual_ranch_agronomist.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/61_blind_auditory_zenith.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/62_cryo_awakened_progenitor.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/63_battle_royale_shrinking_zone.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/65_cybernetic_ascension_deus.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/66_battlefield_canteen_hash_slinger.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/67_affix_plunder_synthesizer.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/68_chrono_loop_groundhog_siege.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/69_avatar_descent_vessel_overload.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/70_bodyguard_tactical_escort.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/71_verbal_edict_scholar_martial.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/72_epoch_severance_lonely_cosmos.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/73_dreamscape_astral_incursion.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/74_qi_war_spirit_manifestation.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/75_nanowire_puppet_necrotech.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/76_colosseum_deathmatch_wagering.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/77_chronos_senescence_reversal.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/78_catastrophe_rescue_titan.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/79_avatar_multithread_overclock.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/80_harbor_colossus_brawl.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/81_humanity_spark_convergence.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/82_ring_wraith_grandmaster_coach.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/83_structural_fault_sight.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/84_haunted_property_exorcism.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/85_abyssal_parasite_limb_symbiosis.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/87_mantle_magma_crucible_tempering.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/88_citywide_acoustic_broker.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/89_doomsday_cargo_armed_escort.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/90_cyber_idol_faith_apotheosis.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/91_gravitational_singularity_tyrant.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/92_myriad_armory_blade_graveyard.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/93_masquerade_proxy_examiner.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/94_zero_chamber_neural_inquisitor.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/95_biopunk_scrapyard_artificer.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/96_bullet_train_supreme_marshal.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/97_effigy_scapegoat_occult_martial.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/98_charlatan_scripture_self_fulfilling.yaml",
    "assets/style-packs/urban-martial-style-engines/references/engines/99_gluttonous_singularity_stomach.yaml",
    "assets/style-packs/urban-martial-style-engines/references/library.json",
    "assets/style-packs/urban-martial-style-engines/references/router.yaml",
    "assets/style-packs/urban-martial-style-engines/scripts/build_library.py",
    "assets/style-packs/urban-martial-style-engines/scripts/check_combo.py",
    "assets/style-packs/urban-martial-style-engines/scripts/common.py",
    "assets/style-packs/urban-martial-style-engines/scripts/export_prompt.py",
    "assets/style-packs/urban-martial-style-engines/scripts/lint_text.py",
    "assets/style-packs/urban-martial-style-engines/templates/book_profile.yaml",
)
# This is an explicit content profile, not a glob or a claim about sale rights.
# Add a path only after reviewing that file for generic, non-project content.
# r5.55: the tests that came into the skill folder with the merged candidate are listed below after such a review;
# in scripts/dialogue_lint/tests/test_genre_config.py a phrase that might have come from a manuscript and the
# speaker's name were replaced with newly written ones first. tests/test_r555_package.py compares this list with
# the folder.
SALE_FILES = frozenset({
    "LICENSE",
    "tests/test_chapter_gate.py",
    "tests/test_demonstration_memory.py",
    "tests/test_learning_loop.py",
    "tests/test_r554_cross_paragraph_speaker.py",
    "scripts/dialogue_lint/tests/test_attribution_boundaries.py",
    "scripts/dialogue_lint/tests/test_core.py",
    "scripts/dialogue_lint/tests/test_genre_config.py",
    "scripts/dialogue_lint/tests/test_genre_detectors.py",
    "scripts/dialogue_lint/tests/test_installed_integration.py",
    "scripts/dialogue_lint/tests/test_lint_apply_scope.py",
    "scripts/dialogue_lint/tests/test_lint_quote_styles.py",
    "scripts/dialogue_lint/tests/test_lint_review_fixes.py",
    "scripts/dialogue_lint/tests/test_lint_startup.py",
    "scripts/dialogue_lint/tests/test_lint_voice_numbers.py",
    "scripts/dialogue_lint/tests/test_narrative_xian.py",
    "scripts/dialogue_lint/tests/test_patch_guard.py",
    "scripts/dialogue_lint/tests/test_system_brackets.py",
    "references/demonstration-learning.md",
    "scripts/demonstration_memory.py",
    "references/learning-loop.md",
    "scripts/learning_loop.py",
    "references/chapter-confirmation.md",
    "scripts/chapter_gate.py",
    "assets/demonstration-case-template.json",
    "references/editorial-judgment.md",
    "assets/editorial-judgment-template.json",
    "SKILL.md",
    "CONSTITUTION.md",
    "assets/constitution-rules.json",
    "agents/openai.yaml",
    "assets/dashboard/app.js",
    "assets/dashboard/index.html",
    "assets/dashboard/styles.css",
    "assets/dashboard/tokens.css",
    "assets/delivery-gate-card.md",
    "assets/revision-card.md",
    "assets/icon.svg",
    "assets/fact-ledger-template.json",
    "assets/fact-claims-template.json",
    "assets/investigation-table.md",  # r5.51: optional investigation table (CORE), not in the default flow
    "assets/editorial-review-template.json",
    "assets/project-template.md",
    "assets/punctuation-rules-template.json",
    "assets/rule-conflicts-template.json",
    "assets/story-state-template.md",
    "assets/serial-handoff-template.md",
    "assets/reference-source-template.md",
    "assets/sentence-dialogue-checklist.md",
    "assets/nonlinear-timeline-template.md",
    "assets/parallel-timelines-template.md",
    "assets/scene-beat-card.md",
    "assets/voice-material-card.md",
    "assets/inspiration-library-template.json",
    "assets/visual-materials-config.example.json",
    "assets/technique-card-template.md",
    "assets/third-party/INTEGRATION-NOTES.md",
    "assets/third-party/SOURCE-NOTES.md",
    "assets/third-party/oh-story-0.8.4-LICENSE.txt",
    "assets/third-party/oh-story-LICENSE.txt",
    "assets/voice-card-template.md",
    "assets/style-cards/cards.json",
    "references/adversarial-review.md",
    "references/author-preferences.md",
    "references/teacher-review.md",
    "references/characters.md",
    "references/chinese-punctuation.md",
    "references/coaching.md",
    "references/continuity.md",
    "references/cover-design.md",
    "references/deconstruction-library.md",
    "references/drafting.md",
    "references/dialogue-craft.md",
    "references/dialogue-lint.md",
    "assets/dialogue-lint-config.example.json",
    "scripts/dialogue_lint/run_lint.py",
    "scripts/dialogue_lint/dialogue_core.py",
    "scripts/dialogue_lint/voice_lint.py",
    "scripts/dialogue_lint/dialogue_antipatterns.py",
    "scripts/dialogue_lint/patch_guard.py",
    "scripts/dialogue_lint/genre_profiles.py",
    "scripts/dialogue_lint/system_brackets.py",
    "references/sentence-craft.md",
    "references/stakes.md",
    "references/style-cards.md",
    STYLE_PACK_GUIDE,
    "references/scene-dramaturgy.md",
    "references/revision-passes.md",
    "references/inspiration-library.md",
    "references/visual-materials.md",
    "references/nonlinear-timeline.md",
    "references/parallel-timelines.md",
    "references/editing.md",
    "references/execution.md",
    "references/file-delivery.md",
    "references/genre-library.md",
    "references/local-workbench.md",
    "references/manuscript-import.md",
    "references/market-research.md",
    "references/pacing.md",
    "references/planning.md",
    "references/progression.md",
    "references/project-bootstrap.md",
    "references/projects.md",
    "references/prose-audit.md",
    "references/quality-loop.md",
    "references/reference-study.md",
    "references/serial-production.md",
    "references/serial-example.md",
    "references/short-fiction.md",
    "references/short-production.md",
    "references/skill-evaluation.md",
    "references/state-storage.md",
    "references/voice.md",
    "scripts/export_portable.py",
    "scripts/fact_guard.py",
    "scripts/oh-story/acp-assist.mjs",
    "scripts/oh-story/acp-check.mjs",
    "scripts/oh-story/acp-client.mjs",
    "scripts/oh-story/acp-runtime.mjs",
    "scripts/oh-story/acp-store.mjs",
    "scripts/oh-story/build_chapter_index.py",
    "scripts/oh-story/check-acp.cmd",
    "scripts/oh-story/check-acp.command",
    "scripts/oh-story/dashboard-server.mjs",
    "scripts/oh-story/gemini-assist.mjs",
    "scripts/oh-story/gemini-check.mjs",
    "scripts/oh-story/check-gemini.cmd",
    "scripts/oh-story/check-gemini.command",
    "scripts/oh-story/inspect_existing_assets.py",
    "scripts/oh-story/open-workbench-demo.cmd",
    "scripts/oh-story/open-workbench-demo.command",
    "scripts/oh-story/open-workbench-edit.cmd",
    "scripts/oh-story/open-workbench-edit.command",
    "scripts/oh-story/open-workbench.cmd",
    "scripts/oh-story/open-workbench.command",
    "scripts/oh-story/render_relation_chart.py",
    "scripts/oh-story/workbench.mjs",
    "scripts/project_state.py",
    "scripts/state_precheck.py",
    "scripts/prose_lint.py",
    "scripts/dialogue_lines.py",
    "scripts/detail_check.py",
    "scripts/inspiration_library.py",
    "scripts/inspiration_write.py",
    "scripts/style_cards.py",
    "scripts/visual_materials_cli.py",
    *VISUAL_PACKAGE,
    *STYLE_PACK_FILES,
    "scripts/punctuation_lint.py",
    "scripts/rule_register.py",
    "scripts/workflow_guard.py",
    "scripts/delivery_manifest.py",
    "scripts/workflow_demo.py",
})
EXCLUDED_PARTS = frozenset({
    ".git", ".hg", ".svn", "__pycache__", ".pytest_cache", ".mypy_cache",
    ".ruff_cache", ".cache", ".tox", ".venv", "venv", "node_modules",
})
# Resource links use inline Markdown or reference definitions; paths containing
# spaces use <angle brackets>. Code examples do not declare file dependencies.
INLINE_LINK = re.compile(
    r'!?\[([^\]\n]+)\]\(\s*(?:<([^>\n]+)>|([^\s)]+))'
    r'(?:\s+(?:"[^"\n]*"|\'[^\'\n]*\'))?\s*\)'
)
REFERENCE_DEF = re.compile(
    r'^ {0,3}\[([^\]\n]+)\]:\s*(?:<([^>\n]+)>|(\S+)).*$', re.MULTILINE
)
FRONTMATTER = re.compile(r"\A---\r?\n.*?\r?\n---(?:\r?\n|\Z)", re.DOTALL)

# The opening of the single file. r5.49 adds the last two sentences (style packs and project packs stay out; how to
# use a pack in a chat) and the search line: the rules say "AI 味" and "AI 腔", users also type the other forms, and a plain text
# search only finds the spelling it is given.
PORTABLE_INTRO = (
    "本文件已展开 Markdown 写作方法与模板，后文按来源文件名标记。请使用内嵌内容，无需另读这些文件。"
    "具体项目由用户另行提供；导出和执行检查脚本属于文件夹版，纯聊天模式不执行脚本，不冒称程序检查或自动存档。"
    "末尾的上游许可仅用于保留版权与许可通知，不是写作指令。"
    "风格包和任何一本书的项目包都不展开在本文件里。"
    "要用风格包，把包里 prompts/ 文件夹中对应的提示词文件整份贴进来：都市高武引擎库照配方用，挑一份 01—10 号配方，它已经带着这个配方要用的引擎，不用另贴引擎文件；实感引擎按“内核＋弹药包”挑一份；两个包同用时，实感引擎那边改用 07_与都市高武同用.md，和引擎库那一份一起贴。本书的主角模板和配方里写的不一样、要换引擎时，不贴配方，改贴 00_底座与目录.md 和选中引擎的 yaml 文件（编号_*.yaml，最多三个）。两个包在交付包的 skills/novel-workshop/assets/style-packs/ 下。"
    # r5.55: the licence, at the top of a file that is often passed on by itself.
    "许可：本工坊按 MIT 许可发布，Copyright (c) 2026 Celeste，许可全文见技能目录和完整包根目录里的 LICENSE；"
    "第三方组件各按自己的 MIT 许可，见完整包根目录的 THIRD-PARTY-NOTICES.md，本文件末尾附 Oh Story 的版权与许可通知。"
    "单独转发本文件时，请把 LICENSE 一起带上。"
)
PORTABLE_SEARCH_LINE = (
    "同一件事有几种写法：AI味、AI 味、AI腔、AI 腔、模板腔、套话、去AI味、像AI写的。"
    "按文字搜改稿规则时，这几种都搜一遍；规则主要在后文的改稿卡（revision-card.md）和模板腔复核（prose-audit.md）。"
    "照规则找出的句子只是要重读的地方，不是定论；没找出来，也不说明文字没有 AI 味。"
    "改稿前先看改稿卡第 1 条：定范围，再分出逐字锁定的原句、要保住的事实和可以调整的表达；"
    "动作在哪儿断、对白谁在说，改稿卡第 4 条各有一句，和后文的编辑、句式、对白、模板腔复核是同一套说法。"
)


GUIDE = """# 小说写作工坊：迁移说明

这份包将通用方法与具体作品资料分开，可用于新作品或新的 AI 会话。

## 本次导出

- 内容模式：`{mode}`。
- 附带作品资料：{project_status}。
- 文件夹版包含 {core_count} 个通用文件，并保留安装界面、图标、方法、模板、脚本与来源许可资料。

`personal` 默认沿相对链接收集通用资源；作品资料仅在明确使用 `--include-projects` 时附带。`sale` 仅选择导出器中逐项列明的通用文件，禁止附带项目；新增依赖若不在白名单内会报错，需要人工审查后更新白名单。

此模式只控制打包内容，不是权利认证或可售承诺。本工坊按 MIT 许可发布，全文见 [LICENSE](novel-workshop/LICENSE)；Oh Story 的 MIT 许可见 [oh-story-LICENSE.txt](novel-workshop/assets/third-party/oh-story-LICENSE.txt)；各样材料的来源和几项没有核过的细节见 [SOURCE-NOTES.md](novel-workshop/assets/third-party/SOURCE-NOTES.md)。参考截图未附使用条款，不随包分发。导出命令只生成本地文件，不发布或上架。

## 选择用法

| 目标环境 | 使用方法 |
| --- | --- |
| 支持文件夹式 Skills | 使用 novel-workshop 文件夹，保留内部相对位置，按目标环境支持的方式导入。 |
| 只有聊天、项目指令或附件输入 | 提供 portable-novel-workshop.md，以及当前任务、项目资料与原稿。单文件已展开 Markdown 方法和模板，末尾保留上游许可；来源说明仅作包内参考。风格包（`novel-workshop/assets/style-packs/`）只在文件夹版里，单文件不展开；聊天时要用哪个配方，就把包里 `prompts/` 下对应的那一份提示词整份贴进对话（它已经带着这个配方的引擎，不用另贴引擎文件；要换引擎，改贴 00_底座与目录.md 和选中引擎的 yaml），见 novel-workshop/references/style-packs.md“纯聊天和单独使用”。 |
| 换一本小说 | 使用新作品的档案、文风卡和原稿，按题材选择相关方法。 |
| 换AI或会话继续同一作品 | 携带项目档案、文风卡（如有）、状态记录、最新及相关原文，从未完成处接续。 |

## 包含的内容

- `novel-workshop/`：完整文件夹式技能，内部相对位置保持一致。
- `portable-novel-workshop.md`：展开的写作指令，适合直接上传或复制；写作不依赖脚本、网络和特定账户。
- `README.md`：本说明及本次归档清单。

附带作品时，项目入口位于 `novel-workshop/assets/project-packs/index.md`。项目是可选资料，只有选定作品时才读取；它们不展开到通用单文件中。

## 开始与恢复

提供材料后可说：“按小说写作工坊处理。本轮润色，保留情节、人物动机和信息顺序，只交正文。”也可指定只分析、续写、设计卷纲或检查衔接。

需要长期跟踪时说：“为这部作品开启持续维护，草稿与已采纳状态分开记录。”只需开启一次；新会话仍需带上记录和相关原稿。

起草、核查和修订可由一个AI顺序完成。多代理不是使用条件；自查不能声称独立验证。检查过程默认留在内部，不附在小说正文后。

有 Python 时可按 references/execution.md 使用 workflow_guard.py 检查明确条件、保存修订额度和恢复点。程序只核对已声明的条件，文笔、张力和人物逻辑仍需审稿；纯聊天版保留相同方法与文本交接，不宣称程序检查已执行。恢复时携带原任务状态，避免重复计数。

prose_lint.py 只提示重复段落、遗留占位和项目指定表达；punctuation_lint.py 只定位标点格式错误和句子切碎等复核线索；fact_guard.py 只比对声明过的事实主张与已采纳事实账；rule_register.py 只核对规则文件的冲突登记表自己说的话对不对得上。结果都不是AI来源检测或文笔裁决。整章及以上的交付按 references/quality-loop.md 写四项状态，未执行的检查写 UNTESTED。作者偏好按范围携带，小说事实只随具体项目走。

多人或多代理维护项目状态时，按 references/state-storage.md 使用 project_state.py 的读版本、条件保存与冲突合并。仅在支持的本地文件环境且各写入方遵循同一协议时有效；纯聊天、绕过脚本或跨机器同步不具备该保证。升级方法按 references/skill-evaluation.md 做旧新同题匿名对照；导出文档按 references/file-delivery.md 检查实际最后版本。

## 更新后重新导出

文件夹版中，在 novel-workshop 目录运行：

```bash
python3 scripts/export_portable.py /目标目录/novel-workshop-portable.zip
python3 scripts/export_portable.py /目标目录/novel-workshop-sale.zip --mode sale
python3 scripts/export_portable.py /目标目录/novel-workshop-install.zip --format install
```

默认 `--mode personal --format portable`。需要附带项目时加 `--include-projects`，不可与 `--mode sale` 同用。`--format install` 只生成 `novel-workshop/` 技能目录；两种格式均保留完整界面与打包元数据。新增资源须以相对 Markdown 链接接入主文件或参考文件；个人模式沿链接收集，可售候选模式另受固定白名单约束。缺失引用或越界路径会报错并保留旧包；导出成功时更新指定 ZIP。纯聊天单文件不包含可执行脚本，重新导出请使用文件夹版。

安装入口取决于目标环境。迁移的是方法与资料，不是原对话记忆，也不保证不同模型产生相同文笔。

## 归档文件清单

{inventory}
"""


def outside_fences(text):
    """The lines of text that are not inside fenced code blocks."""
    lines = []
    fence = None
    for line in text.splitlines():
        marker = re.match(r"^ {0,3}(`{3,}|~{3,})", line)
        if marker:
            token = marker.group(1)
            if fence is None:
                fence = token
            elif token[0] == fence[0] and len(token) >= len(fence):
                fence = None
            continue
        if fence is None:
            lines.append(line)
    return lines


def prose_only(text):
    """Ignore fenced and inline code when discovering resource links."""
    return re.sub(r"(`+).*?\1", "", "\n".join(outside_fences(text)))


def module_title(text):
    """A Markdown module's own title: its first level-one heading outside code, or None."""
    frontmatter = FRONTMATTER.match(text)
    for line in outside_fences(text[frontmatter.end():] if frontmatter else text):
        heading = re.match(r"^ {0,3}#[ \t]+(.+?)(?:[ \t]+#+)?[ \t]*$", line)
        if heading:
            return heading.group(1)
    return None


def module_titles(core):
    """Title of every Markdown file in core, keyed by its path in the skill."""
    titles = {}
    for relative, data in core.items():
        if PurePosixPath(relative).suffix.lower() == ".md":
            title = module_title(data.decode("utf-8"))
            if title:
                titles[relative] = title
    return titles


def link_targets(text):
    text = prose_only(text)
    for pattern in (INLINE_LINK, REFERENCE_DEF):
        for match in pattern.finditer(text):
            yield match.group(2) or match.group(3)


def local_target(relative, target):
    """Resolve a local file link without allowing it to leave the package."""
    url = urlsplit(target)
    if url.scheme or url.netloc:
        if url.scheme == "file":
            raise ValueError(f"Use a relative resource link in {relative}: {target}")
        return None
    if not url.path:
        return None
    path = unquote(url.path)
    if "\\" in path or path.startswith("/"):
        raise ValueError(f"Resource path must be relative in {relative}: {target}")
    joined = posixpath.normpath(str(PurePosixPath(relative).parent / path))
    if joined == ".." or joined.startswith("../"):
        raise ValueError(f"Resource escapes package in {relative}: {target}")
    return joined


def excluded_path(relative):
    path = PurePosixPath(relative)
    return (bool(EXCLUDED_PARTS.intersection(path.parts))
            or path.suffix.lower() in {".pyc", ".pyo"}
            or path.name in {".DS_Store", "Thumbs.db"})


def read_resource(root, relative, mode="personal"):
    if excluded_path(relative):
        raise ValueError(f"Cache or environment file cannot be packaged: {relative}")
    source = root / relative
    try:
        resolved = source.resolve().relative_to(root.resolve()).as_posix()
    except ValueError as exc:
        raise ValueError(f"Resource escapes skill directory: {relative}") from exc
    if excluded_path(resolved):
        raise ValueError(f"Resource resolves to an excluded file: {relative}")
    if mode == "sale" and resolved not in SALE_FILES:
        raise ValueError(f"Sale resource resolves outside the whitelist: {relative}")
    if not source.is_file():
        raise FileNotFoundError(f"Missing linked resource: {relative}")
    return source.read_bytes()


def resource_dependencies(relative, data):
    if PurePosixPath(relative).suffix.lower() == ".md":
        for target in link_targets(data.decode("utf-8")):
            linked = local_target(relative, target)
            if linked is not None:
                yield linked
    if relative == "scripts/learning_loop.py":
        yield from (
            "scripts/chapter_gate.py",
            "scripts/demonstration_memory.py",
            "scripts/project_state.py",
        )
    if relative == "scripts/dialogue_lint/run_lint.py":
        yield from (
            "scripts/dialogue_lint/dialogue_core.py",
            "scripts/dialogue_lint/voice_lint.py",
            "scripts/dialogue_lint/dialogue_antipatterns.py",
            "scripts/dialogue_lint/patch_guard.py",
            "scripts/dialogue_lint/genre_profiles.py",
            "scripts/dialogue_lint/system_brackets.py",
        )
    if relative == STYLE_PACK_GUIDE:
        yield from STYLE_PACK_FILES
    if relative == "scripts/visual_materials_cli.py":
        yield from VISUAL_PACKAGE
    elif relative == "agents/openai.yaml":
        # The only file references in the agent interface are root-relative icons.
        for match in re.finditer(r"^\s*icon_(?:small|large):\s*(.+?)\s*$",
                                 data.decode("utf-8"), re.MULTILINE):
            target = match.group(1).strip()
            if target[:1] in {"'", '"'}:
                if len(target) < 2 or target[-1] != target[0]:
                    raise ValueError("Malformed icon path in agents/openai.yaml")
                target = target[1:-1]
            else:
                target = target.split(" #", 1)[0].rstrip()
            linked = local_target("SKILL.md", target)
            if linked is not None:
                yield linked


def collect_core(root, mode="personal"):
    """Follow personal dependencies or enforce the fixed sale content profile."""
    if mode not in {"personal", "sale"}:
        raise ValueError("mode must be personal or sale")
    resources = {}
    pending = sorted(SALE_FILES) if mode == "sale" else ["SKILL.md", *REQUIRED_METADATA]
    while pending:
        relative = pending.pop(0)
        if relative in resources:
            continue
        if relative.startswith(PROJECT_PREFIX):
            raise ValueError("Keep optional project links in the optional project index")
        if mode == "sale" and relative not in SALE_FILES:
            raise ValueError(f"Sale dependency is not in the whitelist: {relative}")
        data = read_resource(root, relative, mode)
        resources[relative] = data
        pending.extend(resource_dependencies(relative, data))
    return resources


def plain_links(text, relative="SKILL.md", titles=None):
    """Use labels for internal links whose Markdown is embedded below.

    r5.49: the single file marks each module by its file name, so a label that is neither the target's file name
    nor the target module's own title keeps the file name in parentheses: 质量循环（quality-loop.md）. relative is
    the file the text comes from (to resolve its links); titles maps skill paths to module titles (module_titles).
    """
    titles = titles or {}

    def is_external(target):
        url = urlsplit(target)
        return bool(url.scheme or url.netloc)

    def words(value):
        return " ".join(value.replace("`", "").split()).strip("*_ ").casefold()

    def named(label, target):
        path = unquote(urlsplit(target).path)
        name = PurePosixPath(path).name
        if not name or name in {".", ".."} or path.endswith("/") or name.casefold() in label.casefold():
            return label  # an anchor in the same file, a folder, or a label that already names the file
        try:
            resolved = local_target(relative, target)
        except ValueError:
            resolved = None
        title = titles.get(resolved)
        if title is not None and words(label) == words(title):
            return label  # the module's own title is searchable as it is
        return label + "（" + name + "）"

    def replace_inline(match):
        target = match.group(2) or match.group(3)
        return match.group(0) if is_external(target) else named(match.group(1), target)

    definitions = {
        m.group(1).casefold(): m.group(2) or m.group(3)
        for m in REFERENCE_DEF.finditer(text)
    }

    def replace_reference(match):
        label = match.group(1)
        identifier = (match.group(2) or label).casefold()
        target = definitions.get(identifier)
        return named(label, target) if target and not is_external(target) else match.group(0)

    text = REFERENCE_DEF.sub(
        lambda m: m.group(0) if is_external(m.group(2) or m.group(3)) else "", text
    )
    text = INLINE_LINK.sub(replace_inline, text)
    return re.sub(r"\[([^\]\n]+)\](?:\[([^\]\n]*)\])?", replace_reference, text)


def validate_links(entries):
    for relative, data in entries.items():
        if PurePosixPath(relative).suffix.lower() != ".md":
            continue
        for target in link_targets(data.decode("utf-8")):
            linked = local_target(relative, target)
            if linked is not None and linked not in entries:
                raise FileNotFoundError(f"Broken archive link: {relative} -> {target}")


def export(root, output, include_projects=False, mode="personal", format="portable"):
    if mode not in {"personal", "sale"}:
        raise ValueError("mode must be personal or sale")
    if format not in {"portable", "install"}:
        raise ValueError("format must be portable or install")
    if mode == "sale" and include_projects:
        raise ValueError("--include-projects cannot be combined with --mode sale")
    root, output = Path(root), Path(output)
    core = collect_core(root, mode)
    main = core["SKILL.md"].decode("utf-8")
    frontmatter = FRONTMATTER.match(main)
    if not frontmatter:
        raise ValueError("SKILL.md frontmatter is missing or incomplete")
    entries = {"novel-workshop/" + name: data for name, data in core.items()}
    if include_projects:
        projects = root / PROJECT_PREFIX
        if not (projects / "index.md").is_file():
            raise FileNotFoundError("--include-projects requires assets/project-packs/index.md")
        for source in sorted(projects.rglob("*")):
            if source.is_file():
                relative = source.relative_to(root).as_posix()
                if excluded_path(relative):
                    continue
                entries["novel-workshop/" + relative] = read_resource(root, relative)

    if format == "portable":
        titles = module_titles(core)
        single = [
            "# 小说写作工坊：便携单文件版",
            PORTABLE_INTRO,
            PORTABLE_SEARCH_LINE,
            plain_links(main[frontmatter.end():].strip(), "SKILL.md", titles),
        ]
        # The gate card is short and must stay near the top of a long upload.
        if GATE_CARD in core:
            single.append("-----\n\n# 内嵌内容：" + GATE_CARD + "\n\n"
                          + plain_links(core[GATE_CARD].decode("utf-8").strip(), GATE_CARD, titles))
        if REVISION_CARD in core:
            single.append("-----\n\n# 内嵌内容：" + REVISION_CARD + "\n\n"
                          + plain_links(core[REVISION_CARD].decode("utf-8").strip(), REVISION_CARD, titles))
        for relative, data in sorted(core.items()):
            suffix = PurePosixPath(relative).suffix.lower()
            if relative in {"SKILL.md", SOURCE_NOTES, GATE_CARD, REVISION_CARD, "assets/third-party/oh-story-LICENSE.txt"}:
                continue
            if relative.startswith(STYLE_PACK_PREFIX):
                continue  # the style packs stay in the folder version (see references/style-packs.md)
            if suffix in {".md", ".txt"}:
                single.append("-----\n\n# 内嵌内容：" + relative + "\n\n" + plain_links(data.decode("utf-8").strip(), relative, titles))
            elif suffix == ".json" and relative.startswith("assets/"):
                single.append("-----\n\n# 内嵌内容：" + relative + "\n\n```json\n" + data.decode("utf-8").strip() + "\n```")
        license_text = core["assets/third-party/oh-story-LICENSE.txt"].decode("utf-8").strip()
        single.append("-----\n\n# 上游版权与许可通知：Oh Story（assets/third-party/oh-story-LICENSE.txt）\n\n" + license_text)
        notes = plain_links(core[SOURCE_NOTES].decode("utf-8").strip(), SOURCE_NOTES, titles)
        single.append("-----\n\n# 来源记录（assets/third-party/SOURCE-NOTES.md，分发说明，不是写作指令）\n\n" + notes)
        entries["portable-novel-workshop.md"] = ("\n\n".join(single).rstrip() + "\n").encode("utf-8")
        inventory = "\n".join("- `" + name + "`" for name in sorted([*entries, "README.md"]))
        entries["README.md"] = GUIDE.format(
            mode=mode,
            project_status="是（仅文件夹版）" if include_projects else "否",
            core_count=len(core),
            inventory=inventory,
        ).encode("utf-8")

    validate_links(entries)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=output.parent, prefix=".novel-export-", suffix=".zip", delete=False) as stream:
            temporary = Path(stream.name)
        with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for name, data in sorted(entries.items()):
                archive.writestr(name, data)
        with zipfile.ZipFile(temporary) as archive:
            error = archive.testzip()
            if error:
                raise ValueError("Archive integrity check failed: " + error)
            for name, data in entries.items():
                if archive.read(name) != data:
                    raise ValueError("Archive content mismatch: " + name)
        os.replace(temporary, output)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()
    return len(entries)


def utf8_stdio():
    """Messages are UTF-8 on every platform; a Windows pipe would otherwise use the local code page."""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--include-projects", action="store_true", help="include optional project files (personal mode only)")
    parser.add_argument("--mode", choices=("personal", "sale"), default="personal", help="content selection profile (default: personal)")
    parser.add_argument("--format", choices=("portable", "install"), default="portable", help="portable ZIP or clean folder installer ZIP (default: portable)")
    args = parser.parse_args()
    if args.output.suffix.lower() != ".zip":
        parser.error("output must end in .zip")
    if args.mode == "sale" and args.include_projects:
        parser.error("--include-projects cannot be combined with --mode sale")
    root = Path(__file__).resolve().parents[1]
    count = export(root, args.output, args.include_projects, args.mode, args.format)
    print(f"Exported {count} files: {args.output}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""r5.11: the expression check of a whole-chapter task leaves a record, and the delivery gate reads it.

The 2026-10-18 maintenance request (chapter 5 of the author's project, processed with r5.9): the first whole-chapter
pass re-sent an existing revision with zero changes; the declared checks covered length, punctuation, literal
repetition, file hashes and nine literal facts, and the editorial review recorded PASS with six "met" dimensions and no
issues. Sentence-level expression problems (a summary sentence after facts already shown, a teaching recap, a repeated
settlement note) stayed in the text. The gate could not tell a review that did the expression pass from one that did
not: nothing in the record said which text the pass covered or what was decided where.

These tests pin the repair, through the real command line:
- a strict-mode PASS needs an `expression` record: segments that tile the agreed scope (the whole chapter, or the
  scope lines of a local task and the line on each side), each with its own note, and located keep / change decisions;
  reusing a text, changing little, or passing every fact check does not exempt it;
- a segment of more than SEGMENT_MAX non-space characters spanning several paragraphs is a blanket claim, not coverage;
- a change decision must have landed: its old wording is gone from the candidate and stood in an earlier version;
- after an edit, the regions that changed since the last record need a decision in the new review; an issue that an
  earlier review raised is either gone from the text or kept by a decision; an old record never passes for new bytes;
- a local task's record says so, and the gate does not let it be called a whole-chapter review;
- `status --deliverable FILE` tells whether the file to be delivered is the version that was checked.
All material is invented for these tests; reviews are labelled test data and are not literary judgments.
"""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
GUARD = ROOT / "skills" / "novel-workshop" / "scripts" / "workflow_guard.py"
DIMENSIONS = ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function", "continuity",
              "revision_comparison")

PARAGRAPHS = [
    "风停以后，渡口只剩下水拍木桩的声音。林舟提着马灯下到栈桥，先看缆绳，再看船帮。绳结还在，帮板却裂了一道缝，缝里塞着一团碎苇子。",
    "小满跟在后面，手里攥着一把木楔子。他昨天才来，连哪根缆是系锚的都分不清，只知道师傅下栈桥的时候不让人说话。",
    "林舟蹲下，用指节敲了敲裂缝两边。左边是实的，右边发空。他把马灯递给小满：“照着，别晃。”",
    "灯光一稳，缝里的苇子露出半截。苇子是新割的，叶尖还绿，不像是夜里被浪冲进去的。",
    "“有人塞的？”小满问。",
    "林舟没答。他拔出苇子，凑到鼻子底下闻了闻，又把它丢回水里。苇子上有桐油味，渡口这一带，只有对岸的修船铺用桐油。",
    "这一趟，他总算弄明白了船为什么会进水。",
    "他起身去拿刨子，小满追着问要不要去对岸找人。林舟说先把缝补上，天亮前还有一班货要过河，船不能等。",
    "补缝用了小半个时辰。林舟先把裂口两边削平，再一片一片嵌进木楔，嵌一片，敲三下，听声音发实了才换下一片。小满举灯举得手酸，换了只手，灯影在水面上晃了一下。",
    "“手别动。”林舟说，“木楔吃不准，补了也白补。”",
    "最后一片嵌进去时，东边的天已经发青。林舟把剩下的桐油抹在缝上，又往船舱里舀了两瓢水，蹲着看了一阵，缝里没有渗出水来。",
    "“所以刚才那一下，你是听声音才知道右边是空的。”小满说。",
    "林舟擦了擦手，把刨子收进工具箱。“你明天自己敲一遍，就知道了。”",
    "栈桥那头传来脚步声。运货的人到了，肩上扛着两只麻袋，问船能不能走。林舟解开缆绳，说能走。",
    "小满把马灯挂回船头。灯罩上沾了一点桐油，他用袖子擦了擦，没擦掉。",
    "船离岸的时候，雾还贴着水面。林舟撑了三篙，船头慢慢转过来，对准对岸那棵歪脖子柳树。",
    "运货的人蹲在麻袋旁边，问补过的缝牢不牢。林舟说牢，又说过了河让他别急着走，帮忙把船往岸上拖一拖。",
    "小满坐在船尾，一会儿看缝，一会儿看水。缝那里干着，他还是不放心，伸手摸了两回。",
    "到了河心，水流急起来。林舟换了个站法，左脚抵住船帮，篙子插下去，借着水劲把船往下游带了半丈，再斜着撑回来。",
    "对岸修船铺的门还关着。门口晾着几张刨花，油桶倒扣在台阶上，桶底朝外，印着铺子的字号。",
    "林舟把船系好，让小满看着货。他走到铺子门口，没有敲门，先蹲下看那只油桶。桶沿上有一圈新擦过的印子，旁边的泥里，压着半截绿苇叶。",
    "他看完，站起来，回头朝船上招了招手。小满跳下船，跑得太急，差点踩进水里。",
]
SUMMARY = PARAGRAPHS[6]   # 替读者总结：前一段已经交代了桐油和修船铺
RECAP = PARAGRAPHS[11]    # 小满复述刚看到的动作
ORIGINAL = "\n\n".join(PARAGRAPHS) + "\n"
DRAFT = "\n\n".join(p for p in PARAGRAPHS if p != SUMMARY) + "\n"   # the summary sentence deleted
GROUPS = (4, 4, 3, 4, 4, 3)       # paragraph groups of the original (22 paragraphs)
DRAFT_GROUPS = (4, 3, 3, 4, 4, 3)  # the draft has 21


class Brief(dict):
    """A command's JSON output that prints short in assertion messages (failure and message, or the node reached)."""

    def __repr__(self):
        if "failure" in self:
            return "%s: %s" % (self["failure"], self.get("message"))
        return "recorded, node=%s" % self.get("current_node", self.get("gate", {}).get("summary", "?"))


def sha_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def segments(text, groups, label="测试数据"):
    """Tile the text with paragraph groups: each segment is anchored by its first and last characters."""
    paras = [p for p in text.split("\n\n") if p.strip()]
    assert sum(groups) == len(paras), (sum(groups), len(paras))
    out, start = [], 0
    for number, size in enumerate(groups, 1):
        chunk = [p.strip() for p in paras[start:start + size]]
        start += size
        out.append({"from": chunk[0][:8], "to": chunk[-1][-8:],
                    "note": "%s：第%d组逐句连读过，记下了重复说明、总结句和教学式复述的判断" % (label, number)})
    return out


class ExpressionRecord(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        self.write("original.md", ORIGINAL)
        self.write("draft.md", DRAFT)

    def tearDown(self):
        shutil.rmtree(self.dir)

    def write(self, name, text):
        (self.dir / name).write_bytes((text).encode("utf-8"))

    def guard(self, *args):
        proc = subprocess.run([sys.executable, "-I", "-B", str(GUARD), *args], cwd=self.dir, capture_output=True,
                              text=True, encoding="utf-8")
        try:
            out = json.loads(proc.stdout)
        except ValueError:
            return proc.returncode, {"raw": proc.stdout[-400:], "stderr": proc.stderr[-400:]}
        return proc.returncode, Brief(out)

    def start(self, checks=None, mode="strict"):
        checks = checks if checks is not None else [
            {"id": "ending", "type": "contains", "text": "差点踩进水里。"},
            {"id": "freeze", "type": "file_hash", "source": "original.md", "sha256": sha_text(ORIGINAL)}]
        self.write("checks.json", json.dumps({"candidate": "draft.md", "mode": mode, "checks": checks},
                                             ensure_ascii=False))
        code, out = self.guard("start", "run.json", "--task-id", "t", "--spec", "checks.json")
        self.assertEqual(code, 0, out)

    def review(self, name, verdict="PASS", expression=None, issues=None, **extra):
        text = (self.dir / "draft.md").read_text(encoding="utf-8")
        value = {"schema": "editorial-review/2", "verdict": verdict, "candidate_sha256": sha_text(text),
                 "reviewer": {"mode": "self_check", "label": "测试数据：只验证记录结构"},
                 "checked_against": ["测试数据：original.md"], "inputs_read": ["original.md"],
                 "evidence": [{"quote": q, "in": "candidate"}
                              for q in ("林舟提着马灯下到栈桥", "补缝用了小半个时辰", "差点踩进水里")],
                 "issues": issues or [], "machine_dispositions": [],
                 "counter_evidence": "测试数据，不是真实文学审稿。",
                 "dimensions": [{"id": key, "status": "met", "note": "测试数据：只验证记录结构"} for key in DIMENSIONS]}
        if expression is not None:
            value["expression"] = expression
        value.update(extra)
        self.write(name, json.dumps(value, ensure_ascii=False))
        return name

    def record(self, event, name):
        return self.guard("record", "run.json", "--event-id", event, "--review", name)

    def gate(self, *extra):
        code, out = self.guard("status", "run.json", *extra)
        return code, out.get("gate", out)

    def whole(self, text=DRAFT, groups=DRAFT_GROUPS, decisions=None, label="测试数据"):
        return {"scope": "chapter", "segments": segments(text, groups, label), "decisions": decisions or []}


class WholeChapterTasks(ExpressionRecord):
    def test_first_whole_chapter_pass_needs_the_expression_record(self):
        # The r5.9 record shape: six dimensions met, evidence spread, no issues -- and no expression record.
        self.start()
        code, out = self.record("v1", self.review("six-only.json"))
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertIn("expression", out["message"])
        self.assertEqual(self.gate()[1]["editorial"], "UNTESTED")
        decision = {"decision": "change", "before": SUMMARY, "after": "",
                    "judgment": "前一段已交代苇子上的桐油只有对岸铺子用，这句替读者下结论", "reason": "删去不丢动作和线索"}
        code, out = self.record("v2", self.review("full.json", expression=self.whole(decisions=[decision])))
        self.assertEqual(code, 0, out)
        gate = self.gate()[1]
        self.assertEqual(gate["editorial"], "PASS[self_check]")
        self.assertIn("expression: chapter", gate["summary"])
        self.assertEqual(gate["expression"]["scope"], "chapter")

    def test_reusing_a_text_does_not_skip_the_expression_check(self):
        # The candidate is the frozen earlier text, byte for byte (the chapter 5 reuse); zero changes.
        self.write("draft.md", ORIGINAL)
        self.start()
        code, out = self.record("v1", self.review("reuse.json"))
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        keep = {"decision": "keep", "quote": RECAP, "judgment": "小满把刚看到的动作说出来，是新学徒在确认自己听懂了",
                "reason": "人物声音和学徒身份靠这句立住，删了下一句的回答就没有着落"}
        code, out = self.record("v2", self.review("zero-change.json",
                                                  expression=self.whole(ORIGINAL, GROUPS, [keep])))
        self.assertEqual(code, 0, out)  # a full read may end with zero changes, kept with reasons
        self.assertEqual(self.gate()[1]["editorial"], "PASS[self_check]")

    def test_a_blanket_segment_is_not_coverage(self):
        self.start()
        paras = [p for p in DRAFT.split("\n\n") if p.strip()]
        blanket = {"scope": "chapter", "decisions": [],
                   "segments": [{"from": paras[0][:8], "to": paras[-1].strip()[-8:], "note": "测试数据：整章通读"}]}
        code, out = self.record("v1", self.review("blanket.json", expression=blanket))
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertIn("800", out["message"])

    def test_samples_or_a_stop_halfway_are_not_coverage(self):
        self.start()
        partial = self.whole()
        partial["segments"] = partial["segments"][:3]  # the pass stopped (interrupted) after three groups
        code, out = self.record("v1", self.review("partial.json", expression=partial))
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertEqual(self.gate()[1]["editorial"], "UNTESTED")
        sampled = self.whole()
        del sampled["segments"][2]  # a gap in the middle: two samples around it
        code, out = self.record("v2", self.review("sampled.json", expression=sampled))
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        copied = self.whole()
        for item in copied["segments"]:
            item["note"] = "测试数据：逐句读过，没有问题"
        code, out = self.record("v3", self.review("copied.json", expression=copied))
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertEqual(self.gate()[1]["editorial"], "UNTESTED")

    def test_a_change_decision_must_have_landed(self):
        self.start()
        not_done = {"decision": "change", "before": "苇子上有桐油味", "after": "",
                    "judgment": "测试数据：说删了，正文里还在", "reason": "测试数据：建议没有落实"}
        code, out = self.record("v1", self.review("not-done.json", expression=self.whole(decisions=[not_done])))
        self.assertEqual((code, out.get("failure")), (2, "CHANGE_NOT_APPLIED"), out)
        invented = {"decision": "change", "before": "他心里一沉，知道事情不简单。", "after": "",
                    "judgment": "测试数据：哪一版里都没有这句", "reason": "测试数据：凭空的原句"}
        code, out = self.record("v2", self.review("invented.json", expression=self.whole(decisions=[invented])))
        self.assertEqual((code, out.get("failure")), (2, "EVIDENCE_NOT_FOUND"), out)
        missing_after = {"decision": "change", "before": SUMMARY, "after": "他总算明白了。",
                         "judgment": "测试数据：改后的句子不在候选稿里", "reason": "测试数据：说改成了这句"}
        code, out = self.record("v3", self.review("after.json", expression=self.whole(decisions=[missing_after])))
        self.assertEqual((code, out.get("failure")), (2, "EVIDENCE_NOT_FOUND"), out)

    def test_light_mode_pass_without_the_record_says_so(self):
        self.start(mode="light")
        code, out = self.record("v1", self.review("light.json"))
        self.assertEqual(code, 0, out)
        gate = self.gate()[1]
        self.assertIn("expression: not recorded", gate["summary"])
        self.assertIn("表达检查", gate["permissions"]["claim_reviewed"]["reason"])


class LocalTasks(ExpressionRecord):
    LOCAL = ORIGINAL.replace(RECAP, "“刚才那一下，你是听出来的？”小满问。")

    def start_local(self):
        self.write("draft.md", self.LOCAL)
        line = ORIGINAL.splitlines().index(RECAP) + 1
        self.start([{"id": "scope", "type": "scope", "source": "original.md", "editable_lines": [[line, line]]}])
        return line

    def local(self, first, last, decisions=None):
        return {"scope": "local", "decisions": decisions or [],
                "segments": [{"from": first[:8], "to": last[-8:], "note": "测试数据：授权的一句和前后各一段连读过"}]}

    def test_local_coverage_is_the_scope_and_its_neighbours(self):
        self.start_local()
        change = {"decision": "change", "before": RECAP, "after": "“刚才那一下，你是听出来的？”小满问。",
                  "judgment": "测试数据：复述换成提问，留给师傅回答", "reason": "测试数据：授权范围内的一句"}
        # The changed line alone: the line on each side (the transition) is not read.
        alone = self.local("“刚才那一下，你是听出来的？”小满问。", "“刚才那一下，你是听出来的？”小满问。", [change])
        code, out = self.record("v1", self.review("alone.json", expression=alone))
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        code, out = self.record("v2", self.review("local.json",
                                                  expression=self.local(PARAGRAPHS[10], PARAGRAPHS[12], [change])))
        self.assertEqual(code, 0, out)
        gate = self.gate()[1]
        self.assertIn("expression: local", gate["summary"])
        self.assertIn("局部", gate["deliverable_label"])
        self.assertIn("不能说整章", gate["permissions"]["claim_reviewed"]["reason"])

    def test_a_whole_chapter_task_cannot_record_local_coverage(self):
        self.start()
        code, out = self.record("v1", self.review("local.json",
                                                  expression=self.local(PARAGRAPHS[10], PARAGRAPHS[12])))
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertIn("scope", out["message"])


class AfterTheCheck(ExpressionRecord):
    def test_an_edit_after_pass_needs_a_new_record_for_the_changed_part(self):
        self.start()
        delete = {"decision": "change", "before": SUMMARY, "after": "", "judgment": "测试数据：替读者总结",
                  "reason": "测试数据：删去不丢信息"}
        self.assertEqual(self.record("v1", self.review("pass.json", expression=self.whole(decisions=[delete])))[0], 0)
        self.assertEqual(self.gate()[1]["editorial"], "PASS[self_check]")
        edited = DRAFT.replace("木楔吃不准，补了也白补。", "木楔吃不准，这缝就白补了。")
        self.write("draft.md", edited)
        gate = self.gate()[1]
        self.assertEqual((gate["mechanical"], gate["editorial"]), ("STALE", "STALE"))
        code, out = self.record("v2", "pass.json")  # the old review cannot be carried over
        self.assertEqual(out.get("failure"), "REVIEW_STALE", out)
        self.assertEqual(self.guard("reserve", "run.json", "--event-id", "r1")[0], 0)
        same_notes = self.review("same.json", expression=self.whole(edited, decisions=[delete]))
        code, out = self.record("v3", same_notes)
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertIn("changed since", out["message"])
        # A decision carried over from the old review that only sits in the same paragraph does not show that the
        # changed words were read again (found in the r5.11 held-out run on real material).
        nearby = {"decision": "keep", "quote": "“手别动。”林舟说", "judgment": "测试数据：旧审稿里就有的一条，挨着改动",
                  "reason": "测试数据：没有看改过的半句"}
        code, out = self.record("v4", self.review("nearby.json", expression=self.whole(edited, decisions=[delete, nearby])))
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        keep = {"decision": "keep", "quote": "这缝就白补了", "judgment": "测试数据：改后的半句仍是人物在催",
                "reason": "测试数据：重读了改动的这一段和前后衔接"}
        code, out = self.record("v5", self.review("again.json", expression=self.whole(edited, decisions=[delete, keep])))
        self.assertEqual(code, 0, out)
        self.assertEqual(self.gate()[1]["editorial"], "PASS[self_check]")

    def test_an_issue_raised_earlier_is_resolved_or_kept(self):
        self.write("draft.md", ORIGINAL)
        self.start()
        issue = {"quote": SUMMARY, "expected": "测试数据：不替读者总结", "impact": "测试数据：重复上一段的信息"}
        code, out = self.record("v1", self.review("needs.json", verdict="NEEDS_REVISION", issues=[issue],
                                                  expression=self.whole(ORIGINAL, GROUPS)))
        self.assertEqual(code, 0, out)
        self.assertEqual(self.gate()[1]["editorial"], "NEEDS_REVISION")
        self.assertEqual(self.guard("reserve", "run.json", "--event-id", "r1")[0], 0)
        # Nothing changed, and the next review simply says PASS: the issue is still in the text.
        code, out = self.record("v2", self.review("silent.json", expression=self.whole(ORIGINAL, GROUPS)))
        self.assertEqual((code, out.get("failure")), (2, "ISSUE_UNRESOLVED"), out)
        keep = {"decision": "keep", "quote": SUMMARY, "judgment": "测试数据：作者决定保留这一句",
                "reason": "测试数据：作者原话记在 replan 里"}
        code, out = self.record("v3", self.review("kept.json", expression=self.whole(ORIGINAL, GROUPS, [keep])))
        self.assertEqual(code, 0, out)

    def test_the_delivered_file_must_be_the_checked_version(self):
        self.start()
        delete = {"decision": "change", "before": SUMMARY, "after": "", "judgment": "测试数据：替读者总结",
                  "reason": "测试数据：删去不丢信息"}
        self.assertEqual(self.record("v1", self.review("pass.json", expression=self.whole(decisions=[delete])))[0], 0)
        code, gate = self.gate("--deliverable", "draft.md")
        self.assertEqual((code, gate["deliverable"]["matches"]), (0, "exact"))
        self.write("out-chat.txt", DRAFT.rstrip("\n"))  # pasted into a chat: the final line break is gone
        code, gate = self.gate("--deliverable", "out-chat.txt")
        self.assertEqual((code, gate["deliverable"]["matches"]), (0, "final_newline_only"))
        self.write("out-old.txt", ORIGINAL)  # the unrevised text went out instead
        code, gate = self.gate("--deliverable", "out-old.txt")
        self.assertEqual((code, gate["deliverable"]["matches"]), (1, "no"))
        for claim in ("claim_mechanical_pass", "claim_reviewed", "claim_final"):
            self.assertEqual(gate["permissions"][claim]["decision"], "BLOCK", claim)
        self.assertIn("DELIVERABLE=MISMATCH", gate["summary"])


if __name__ == "__main__":
    unittest.main()

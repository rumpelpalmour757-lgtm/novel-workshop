#!/usr/bin/env python3
"""Install the selected skill folders without overwriting existing content.

A different installed version is never replaced silently. With --upgrade the installed version is first moved, intact,
into <dest>/.novel-workshop-backups/<time>/ and only then replaced. The files you keep in the installed
novel-workshop/assets/project-packs/ (the author's correction records in _author/ and your project files) are copied
into the new version first, each one checked by its SHA-256. If this package ships a file there that cannot stand
beside yours (the same name with different content, a file where the other side has a folder, or a name that differs
only in letter case), the installer stops before changing anything and lists those files: run again with --upgrade
--keep installed or --upgrade --keep package. --dry-run lists the files that would be carried over and those that
differ.

The installed version counts as this version when every file outside assets/project-packs/ matches this package.
Then nothing is replaced and no backup is made. Files this package ships under assets/project-packs/ that the
installed copy does not have are added beside yours, each checked by its SHA-256; differing ones stop the run as
above (--keep installed leaves them as they are, --upgrade --keep package backs up the installed version and
installs this package's copies). Symbolic links and directory junctions are not followed: the installer stops at the
first one, before changing anything.

To roll back to a package that also has --upgrade (this release or later), run that package's install.py with
--upgrade; the newer version is backed up the same way, and from r5.56 on assets/project-packs/ comes along. The
installers of r5.55 and earlier leave it in the backup, under <time>/novel-workshop/assets/project-packs/. r5.55
reads the author's correction records from the author profile, outside the skill folder: to go on using them with
r5.55, put the two files where r5.55's pages say. With r5.54 and earlier, copy that project-packs folder into the
installed novel-workshop/assets/ folder, so that it is <dest>/novel-workshop/assets/project-packs/ again. Once it is
back, the older installer reports "Existing skill differs" (r5.55's does): do not run it again with --upgrade, as
that message suggests, for the same older package; that moves the whole folder, records included, into the backup
again. Older packages (r4.3 and earlier) have no --upgrade: move the two
installed skill folders out of <dest> first, or move the backed-up folders back from the backup folder.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import sys
import tempfile
import time


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


CACHE_DIRS = {'__pycache__', '.pytest_cache'}


def is_cache(path, root):
    # Running the bundled scripts may leave interpreter caches; they are never package content.
    return bool(CACHE_DIRS.intersection(path.relative_to(root).parts)) or path.suffix in ('.pyc', '.pyo')


def is_junction(path):
    """A Windows directory junction. is_symlink() is False for one; Python 3.12 and later have Path.is_junction(),
    earlier versions on Windows read the reparse tag (only a mount point is a junction, so OneDrive placeholders and
    other reparse points are not refused)."""
    if hasattr(path, 'is_junction'):
        return path.is_junction()
    if os.name != 'nt':
        return False
    try:
        status = os.lstat(path)
    except OSError:
        return False
    return (bool(getattr(status, 'st_file_attributes', 0) & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400))
            and getattr(status, 'st_reparse_tag', None) == getattr(stat, 'IO_REPARSE_TAG_MOUNT_POINT', 0xA0000003))


class LinkError(ValueError):
    pass


def regular_files(root):
    result = {}
    for path in root.rglob('*'):
        if is_cache(path, root):
            continue
        if path.is_symlink() or is_junction(path):
            raise LinkError('Symbolic links and directory junctions are not supported: %s. The installer does not '
                            'follow them; replace the link with the folder or file it points to, or move it out of '
                            'the skill folder, then run again.' % path)
        if path.is_file():
            result[path.relative_to(root).as_posix()] = sha256(path)
    return result


BACKUPS = '.novel-workshop-backups'
# r5.56: the user's own files in a skill folder. They are not package content: an upgrade copies them into the new
# version, and they never make an installed version look different from this one.
USER_FILES = {'novel-workshop': 'assets/project-packs/'}
KEEP = ('installed', 'package')
LISTED = 20  # a message names at most this many files


def validate_package(root):
    manifest = json.loads((root / 'PACKAGE-MANIFEST.json').read_text(encoding='utf-8'))
    if manifest.get('schema_version') != 1:
        raise ValueError('Unsupported package manifest.')
    components = manifest.get('components', {})
    shipped_user = tuple(components[name]['path'] + '/' + prefix for name, prefix in USER_FILES.items()
                         if name in components)
    for relative, expected in manifest['files'].items():
        parts = PurePosixPath(relative)
        if parts.is_absolute() or '..' in parts.parts or '\\' in relative or ':' in relative:
            raise ValueError('Unsafe manifest path: ' + relative)
        path = root / relative
        if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
            raise ValueError('Unsafe package file: ' + relative)
        if not path.is_file() or sha256(path) != expected:
            message = 'Package file is missing or changed: ' + relative
            if relative.startswith(shipped_user):
                message += ('. It is one of the files this package itself ships under assets/project-packs/, so the '
                            "package folder's assets/project-packs/ has been changed (for example an installed one "
                            'was copied over it). Use the package folder as it was unpacked; --upgrade carries your '
                            'records and project files over from the installed skill folder.')
            raise ValueError(message)
    return manifest


def split(files, prefix):
    """(program files, user files) of a {relative path: hash} map; user files are those under prefix."""
    user = {k: v for k, v in files.items() if prefix and k.startswith(prefix)}
    return {k: v for k, v in files.items() if k not in user}, user


def folders(paths):
    """Every folder that holds one of paths."""
    result = set()
    for path in paths:
        parts = path.split('/')
        result.update('/'.join(parts[:i]) for i in range(1, len(parts)))
    return result


def prefixes(path):
    """The folders that hold path, then path itself."""
    parts = path.split('/')
    return ['/'.join(parts[:i]) for i in range(1, len(parts) + 1)]


def differing(installed, shipped):
    """The installed and the shipped user files that cannot stand side by side, each with the reason: the same name
    with different content, a file where the other side has a folder, or a name (of the file or of a folder holding
    it) that differs from one on the other side only in letter case, which is one name on Windows and macOS."""
    def clash(files, other):
        names, holders, spelled = set(other), folders(other), {}
        for name in other:
            for prefix in prefixes(name):
                spelled.setdefault(prefix.casefold(), set()).add(prefix)
        result = {}
        for path, digest in files.items():
            if path in other:
                if other[path] != digest:
                    result[path] = 'different content'
            elif path in holders or folders([path]) & names:
                result[path] = 'a file on one side, a folder of the same name on the other'
            elif any(spelled.get(prefix.casefold(), {prefix}) - {prefix} for prefix in prefixes(path)):
                result[path] = 'differs from a name on the other side only in letter case'
        return result
    return clash(installed, shipped), clash(shipped, installed)


def listing(names):
    shown = ', '.join(names[:LISTED])
    return shown + (', ... (%d files in all)' % len(names) if len(names) > LISTED else '')


def conflict_message(plan):
    lines = []
    for p in plan:
        lines.append('%s: %d file(s) under %s, in the installed copy and in this package, cannot stand side by side:'
                     % (p['target'], len(p['conflicts']), USER_FILES[p['name']]))
        lines.extend('  %s (%s)' % (name, p['why'][name]) for name in p['conflicts'][:LISTED])
        if len(p['conflicts']) > LISTED:
            lines.append('  ... (%d files in all; --dry-run lists every one under "conflicts")' % len(p['conflicts']))
    return ('files you keep in the skill folder differ from files this package ships; nothing was changed.\n'
            + '\n'.join(lines) + '\nRun again with --upgrade --keep installed to keep the installed copies (they are '
            'carried into the new version, or left as they are when the installed version is this one; this '
            "package's copies of these files are then not installed), or with --upgrade --keep package to install "
            "this package's copies (the installed version is backed up first, and the installed copies then stay in "
            'the backup folder). Add --dry-run to see the plan first.')


def carry(p, staged):
    """Copy the user's files from the installed folder into the staged new version, checking each one's hash."""
    for relative in p['set_aside']:  # this package's copies that make way for the installed ones (--keep installed)
        path = staged / relative
        path.unlink()
        parent = path.parent
        while parent != staged and not any(parent.iterdir()):
            parent.rmdir()
            parent = parent.parent
    for relative in p['carried']:
        source, copy = p['target'] / relative, staged / relative
        if source.is_symlink() or not source.is_file():
            raise ValueError('Installed file changed while installing; nothing was replaced: ' + str(source))
        copy.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, copy)
        if sha256(copy) != p['installed'][relative]:
            raise ValueError('Installed file changed while installing; nothing was replaced: ' + str(source))


def add_files(p, written):
    """Write this package's user files that the installed version (this version) does not have, beside the user's
    own. Nothing is written over: a file that appeared meanwhile stops the run. Each file is checked after writing;
    written records what this run made, so that undoing removes only that."""
    target = p['target'].resolve()
    for relative in p['add']:
        data = (p['source'] / relative).read_bytes()
        if hashlib.sha256(data).hexdigest() != p['expected'][relative]:
            raise ValueError('Package file changed while installing: ' + str(p['source'] / relative))
        path, missing = p['target'] / relative, []
        parent = path.parent
        while not os.path.lexists(parent):
            missing.append(parent)
            parent = parent.parent
        if parent.is_symlink() or is_junction(parent) or not parent.is_dir() \
                or not parent.resolve().is_relative_to(target):
            raise ValueError('Installed skill changed while installing: ' + str(parent))
        for folder in reversed(missing):
            folder.mkdir()
            written['folders'].append(folder)
        with open(path, 'xb') as stream:  # never over a file that appeared meanwhile
            stream.write(data)
        written['files'].append((path, data))
        if sha256(path) != p['expected'][relative]:
            raise ValueError('Installed content verification failed: ' + str(path))


def remove_tree(path):
    """shutil.rmtree that clears a read-only attribute and tries once more (copy2 keeps the attribute of a record,
    and on Windows rmtree cannot remove such a file); a folder outside path is never touched."""
    top = os.path.abspath(path)

    def retry(function, name, info):
        if function not in (os.unlink, os.rmdir, os.remove):
            raise info if isinstance(info, BaseException) else info[1]
        for item in (name, os.path.dirname(name)):
            if os.path.commonpath([top, os.path.abspath(item)]) != top:
                continue
            try:
                extra = stat.S_IWRITE | (stat.S_IREAD | stat.S_IEXEC if os.path.isdir(item) else 0)
                os.chmod(item, stat.S_IMODE(os.lstat(item).st_mode) | extra)
            except OSError:
                pass
        function(name)

    if sys.version_info >= (3, 12):
        shutil.rmtree(path, onexc=retry)
    else:
        shutil.rmtree(path, onerror=retry)


def summary(p, keep):
    item = {'name': p['name'], 'action': p['action']}
    if p['action'] == 'upgrade' and p['prefix']:
        item['carried'] = p['carried']
        item['conflicts'] = p['conflicts']
        if p['conflicts']:
            item['keep'] = keep
    if p['action'] == 'unchanged' and p['prefix']:
        if p['add']:
            item['added'] = p['add']  # this package's files the installed copy did not have
        if p['conflicts']:
            item['conflicts'] = p['conflicts']
            if keep:
                item['keep'] = keep
    left = p['left'] or p['set_aside']
    if left:
        # this package's copies of differing files, not installed: the installed copies were kept (--keep installed)
        item['left_as_installed'] = left
        item['package_copies_in'] = str(p['source'])
    return item


def not_installed_note(report):
    """A line on stderr for every skill with files of this package that were not installed."""
    lines = []
    for item in report['skills']:
        left = item.get('left_as_installed')
        if not left:
            continue
        lines.append('%s: kept the installed copies of %d file(s) (--keep installed); this package\'s copies %s not '
                     'installed. To use one of them, copy it by hand from the package into %s, or run again with '
                     '--upgrade --keep package:' % (item['name'], len(left), 'would be' if report['dry_run'] else 'were',
                                                    Path(report['destination']) / item['name']))
        lines.extend('  %s: %s' % (name, Path(item['package_copies_in'], name)) for name in left[:LISTED])
        if len(left) > LISTED:
            lines.append('  ... (%d files in all, listed under "left_as_installed")' % len(left))
    return '\n'.join(lines)


def undo(error, plan, placed, moved, written, backup):
    """Undo this run after error and return the error to raise. Each step goes on after a failure: only what this
    run placed is removed, and only when it is exactly what was placed; otherwise it is moved into the backup folder,
    never deleted. Then every backed-up version goes back. Whatever cannot be done is said, with where things are."""
    notes, problems = [], []

    def put_aside(p, suffix):
        backup.mkdir(parents=True, exist_ok=True)
        aside, n = backup / (p['name'] + suffix), 1
        while os.path.lexists(aside):
            n += 1
            aside = backup / ('%s%s-%d' % (p['name'], suffix, n))
        os.rename(p['target'], aside)
        return aside

    for p in reversed(placed):
        if not os.path.lexists(p['target']):
            continue
        try:
            same = regular_files(p['target']) == p['final']
        except Exception:  # a link or an unreadable file appeared: keep it rather than remove what cannot be checked
            same = False
        failure = None
        if same:
            try:
                remove_tree(p['target'])
                continue
            except OSError as exc:
                failure = exc
            if not os.path.lexists(p['target']):
                continue
        try:
            aside = put_aside(p, '.failed' if same else '.incomplete')
        except OSError as exc:
            problems.append('the new version of %s could not be removed or moved aside (%s); it is still at %s'
                            % (p['name'], failure or exc, p['target']))
            continue
        if same:
            notes.append('the new version of %s could not be removed (%s); what is left of it was moved to %s'
                         % (p['name'], failure, aside))
        else:
            notes.append('the new version of %s was no longer exactly what this run put in place (a file in it, for '
                         'example a record under %s, may have been written while installing); it is kept whole in %s'
                         % (p['name'], p['prefix'] or 'the folder', aside))
    for p in moved:
        old = backup / p['name']
        if os.path.lexists(p['target']):
            problems.append('the previously installed version of %s is kept at %s (something else is at %s)'
                            % (p['name'], old, p['target']))
            continue
        try:
            os.rename(old, p['target'])
        except OSError as exc:
            problems.append('the previously installed version of %s could not be put back (%s); it is in %s'
                            % (p['name'], exc, old))
    for path, data in reversed(written['files']):
        try:
            if path.read_bytes() == data:
                path.unlink()
            else:
                notes.append('%s changed after this run wrote it and was left in place' % path)
        except FileNotFoundError:
            pass
        except OSError as exc:
            problems.append('%s, added by this run, could not be removed (%s)' % (path, exc))
    for folder in reversed(written['folders']):
        try:
            folder.rmdir()
        except OSError:
            pass  # not empty: someone wrote into it meanwhile
    for folder in (backup, backup.parent):
        try:
            folder.rmdir()  # only when empty: nothing of this run is left in it
        except OSError:
            break
    if not notes and not problems:
        return error
    state = []
    for p in plan:
        if p in moved:
            back = os.path.lexists(p['target']) and not os.path.lexists(backup / p['name'])
            state.append('%s: %s' % (p['name'], 'the previously installed version is back in place' if back
                                     else 'the previously installed version is in ' + str(backup / p['name'])))
        elif p in placed:
            state.append('%s: %s' % (p['name'], 'not installed' if not os.path.lexists(p['target'])
                                     else 'see above, at ' + str(p['target'])))
        else:
            state.append('%s: not changed' % p['name'])
    return ValueError('%s. Undoing the run: %s. Now %s. Backup folder of this run: %s'
                      % (error, '; '.join(problems + notes), '; '.join(state), backup))


def install(root, destination, include_dev=False, dry_run=False, upgrade=False, keep=None):
    if keep not in (None, *KEEP):
        raise ValueError('--keep must be installed or package')
    manifest = validate_package(root)
    destination = destination.expanduser().absolute()
    # Refuse a redirected target rather than following a link into another folder.
    for parent in [destination, *destination.parents]:
        if parent.is_symlink() or is_junction(parent):
            raise ValueError('Linked destination is not supported: ' + str(parent))
    selected = ['novel-workshop', 'darwin-novel-workshop']
    if include_dev:
        selected.append('typesafe-ai')
    plan = []
    for name in selected:
        relative = manifest['components'][name]['path']
        source = root / relative
        if not source.is_dir() or source.is_symlink():
            raise ValueError('Invalid source directory: ' + name)
        expected = {p[len(relative) + 1:]: h for p, h in manifest['files'].items() if p.startswith(relative + '/')}
        prefix = USER_FILES.get(name)
        try:
            actual = regular_files(source)
        except LinkError as error:
            raise ValueError(str(error) + ' Nothing was changed.') from error
        if actual != expected:
            extra = sorted(set(actual) - set(expected))
            if prefix and extra and all(f.startswith(prefix) for f in extra) \
                    and {f: h for f, h in actual.items() if f not in extra} == expected:
                # Someone copied their own files into the unpacked package, as is done for a folder uploaded by hand.
                raise ValueError('This package folder holds files under %s/%s that are not part of the package: %s. '
                                 "install.py installs only the package's own files; --upgrade carries those files "
                                 'over from the installed skill folder. Move them out of the package folder and run '
                                 'again.' % (relative, prefix, listing(extra)))
            raise ValueError('Unexpected or missing files in skill: ' + name)
        program, shipped = split(expected, prefix)
        p = {'name': name, 'source': source, 'target': destination / name, 'expected': expected, 'program': program,
             'prefix': prefix, 'final': expected, 'installed': {}, 'carried': [], 'conflicts': [], 'why': {},
             'set_aside': [], 'left': [], 'add': []}
        target = p['target']
        if target.exists():
            if not target.is_dir() or target.is_symlink() or is_junction(target):
                raise ValueError('Existing path is not a plain skill folder; nothing installed: ' + str(target))
            try:
                p['installed'] = regular_files(target)
            except LinkError as error:
                raise ValueError(str(error) + ' Nothing was changed.') from error
            installed_program, user = split(p['installed'], prefix)
            mine, theirs = differing(user, shipped)
            p.update(conflicts=sorted(set(mine) | set(theirs)), why={**theirs, **mine})
            if installed_program == program and not (p['conflicts'] and keep == 'package' and upgrade):
                # This version. Nothing is replaced: this package's user files the installed copy lacks are added
                # beside the user's own; differing ones stop the run below unless --keep installed leaves them.
                action = 'unchanged'
                p['add'] = sorted(f for f in shipped if f not in user and f not in theirs)
                if keep == 'installed':
                    p['left'] = sorted(theirs)
            elif upgrade:
                # A different version, or this version with --keep package for differing files: back up, replace.
                action = 'upgrade'
                if keep == 'installed':
                    carried = dict(user)
                    p['set_aside'] = sorted(theirs)
                    final_user = {**{f: h for f, h in shipped.items() if f not in theirs}, **carried}
                else:  # --keep package; with differing files and no choice the run stops below
                    carried = {f: h for f, h in user.items() if f not in mine}
                    final_user = {**carried, **shipped}
                p.update(carried=sorted(carried), final={**program, **final_user})
            else:
                carried = (' (the files under %s, your own records and project files, are carried into the new '
                           'version)' % prefix) if prefix else ''
                raise ValueError('Existing skill differs; nothing installed: ' + str(target) + '. Run again with '
                                 '--upgrade to back up the installed version and replace it' + carried
                                 + ', or choose --dest.')
        else:
            action = 'install'
        p['action'] = action
        plan.append(p)
    report = {'dry_run': dry_run, 'destination': str(destination), 'skills': [summary(p, keep) for p in plan]}
    # Never settle a differing file silently; stop before anything is written. --keep package replaces files, so it
    # needs --upgrade.
    unresolved = [p for p in plan if p['conflicts'] and not (keep == 'installed' or (keep == 'package' and upgrade))]
    if unresolved:
        if dry_run:
            report['would_stop'] = conflict_message(unresolved)
            return report
        raise ValueError(conflict_message(unresolved))
    if dry_run or all(p['action'] == 'unchanged' and not p['add'] for p in plan):
        return report
    stamp = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())
    backup, n = destination / BACKUPS / stamp, 1
    while backup.exists():
        n += 1
        backup = destination / BACKUPS / ('%s-%d' % (stamp, n))
    if any(p['action'] == 'upgrade' for p in plan):
        report['backup'] = str(backup)
    destination.mkdir(parents=True, exist_ok=True)
    lock = destination / '.novel-workshop-install.lock'
    lock.mkdir()  # A second copy of this installer must finish before proceeding.
    try:
        with tempfile.TemporaryDirectory(prefix='.novel-workshop-stage-', dir=destination) as tmp:
            temporary = Path(tmp)
            assert temporary.resolve().is_relative_to(destination.resolve())
            for p in plan:
                if p['action'] in ('install', 'upgrade'):
                    staged = temporary / p['name']
                    shutil.copytree(p['source'], staged, ignore=shutil.ignore_patterns(*CACHE_DIRS, '*.pyc', '*.pyo'))
                    if regular_files(staged) != p['expected']:
                        raise ValueError('Staging verification failed: ' + p['name'])
                    if p['action'] == 'upgrade':
                        carry(p, staged)
                        if regular_files(staged) != p['final']:
                            raise ValueError('Staging verification failed: ' + p['name'])
            moved = []   # upgrades whose installed version is already in the backup folder
            placed = []  # folders this run has put in place (new installs and upgrades)
            written = {'files': [], 'folders': []}  # what this run added to a folder left in place
            try:
                for p in plan:
                    if p['action'] == 'upgrade':
                        # Keep the installed version intact before anything replaces it; it must still be the one the
                        # user's files were copied from.
                        before = regular_files(p['target'])
                        if before != p['installed']:
                            raise ValueError('Installed skill changed while installing; nothing was replaced: '
                                             + str(p['target']))
                        backup.mkdir(parents=True, exist_ok=True)
                        os.rename(p['target'], backup / p['name'])
                        moved.append(p)
                        if regular_files(backup / p['name']) != before:
                            raise ValueError('Backup verification failed: ' + str(backup / p['name']))
                    if p['action'] in ('install', 'upgrade'):
                        if p['target'].exists():
                            raise ValueError('Destination changed while installing: ' + str(p['target']))
                        os.rename(temporary / p['name'], p['target'])
                        placed.append(p)
                    elif p['add']:
                        add_files(p, written)
                for p in plan:
                    installed = regular_files(p['target'])
                    if p['action'] == 'unchanged':
                        # Left in place: its program files are this version; the user's own files are not checked
                        # (files added above were checked as each was written).
                        same = split(installed, p['prefix'])[0] == p['program']
                    else:
                        same = installed == p['final']
                    if not same:
                        changed = sorted(f for f in set(installed) | set(p['final']) if installed.get(f) != p['final'].get(f))
                        detail = ''
                        if p['prefix'] and changed and all(f.startswith(p['prefix']) for f in changed):
                            detail = (' (files under %s changed after the new version was put in place: %s)'
                                      % (p['prefix'], listing(changed)))
                        raise ValueError('Installed content verification failed: ' + p['name'] + detail)
            except Exception as error:
                # Undo this run: never leave a mix of old and new skills, never delete a folder this run did not
                # create, and never delete one that holds anything this run did not put there.
                result = undo(error, plan, placed, moved, written, backup)
                if result is error:
                    raise
                raise result from error
    finally:
        lock.rmdir()
    return report


def utf8_stdio():
    """Messages are UTF-8 on every platform; a Windows pipe would otherwise use the local code page."""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(encoding='utf-8')


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dest', type=Path, default=Path.home() / '.codex' / 'skills')
    parser.add_argument('--include-dev', action='store_true', help='Also install the optional TypeSafe developer skill.')
    parser.add_argument('--dry-run', action='store_true',
                        help='Validate and show changes without writing anything, including the files under '
                             'assets/project-packs/ an upgrade would carry over, those that would be added and those '
                             'that differ.')
    parser.add_argument('--upgrade', action='store_true',
                        help='Replace a different installed version after moving it into ' + BACKUPS + '/<time>/. '
                             'The files under novel-workshop/assets/project-packs/ are copied into the new version '
                             'first.')
    parser.add_argument('--keep', choices=KEEP,
                        help='For files under novel-workshop/assets/project-packs/ that are in the installed copy '
                             'and in this package and cannot stand side by side: "installed" keeps the installed '
                             "copies (carried into the new version, or left as they are when the installed version "
                             "is this one) and leaves out this package's copies; \"package\" (with --upgrade) backs up "
                             "the installed version and installs this package's copies, and the installed copies "
                             'stay in the backup folder. Without it the installer stops before changing anything and '
                             'lists those files.')
    args = parser.parse_args()
    try:
        result = install(Path(__file__).resolve().parent, args.dest, args.include_dev, args.dry_run, args.upgrade,
                         args.keep)
    except (OSError, ValueError, KeyError) as error:
        print('Installation stopped: ' + str(error), file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    note = not_installed_note(result)
    if note:
        print(note, file=sys.stderr)
    if result.get('would_stop'):
        print('Dry run: a real run would stop here; ' + result['would_stop'], file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

#!/usr/bin/env python3
"""r5.60: how technique cards are used while writing.

What these tests pin (the decisions are in the maintenance records, outside the package; none of the author's words
are quoted here). Three points were written first on the maker's proposal, and the author was told of each: a whole
chapter is reported scene by scene; when the author wants the text only, the sentence about a narrowed card is still
said outside the text, and so is the sentence naming a card the author has not seen or has seen and not decided on.
The author has since approved the second; on the other two the author's answer was to go by the advice given, which
was to leave them as written. All three stay open to the author's change.
The two lists at the tidying-up step were worded by the maker and shown to the author before they were written; the
author approved the paragraph (TIDYING_APPROVED below). A sentence on those two exceptions for the locked section
"交付状态" of quality-loop.md was shown to the author as well; the author decided that the section stays as it is in
this release (TEXT_ONLY_SENTENCE_APPROVED below). The rest the author decided:
- a scene uses at most two technique cards, the best fitting; other cards that matched are only noted on the beat
  card and are not read while drafting;
- a card is read at three moments (choosing, drafting, checking after writing), each with its own fields;
- no upper limit on the number of cards; when lessons are tidied up, two lists go to the author, card by card
  (cards used several times and adopted: take into the rules? cards long unused: archive?); nothing is done
  automatically (the author has approved the paragraph, see TIDYING_APPROVED below);
- on delivery the workshop says outside the text which card each scene used;
- on the same point an adopted technique card of this book goes before a general style card, modules before both;
  a scene with a technique card loads at most one scene-layer style card.

The five gate scripts, the gate card, the revision card and the constitution are not changed. The beat card gains one
field the gate does not read. These tests check that the wording is there and that the gate reads the card as before;
they do not show that writing with cards gets better (nothing here was tried on a real chapter).
All material in the tests is invented.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
GUARD = SKILL / "scripts" / "workflow_guard.py"
DARWIN = ROOT / "skills" / "darwin-novel-workshop" / "scripts" / "darwin_eval.py"
FIELD = "这一场用的技法卡"
LEAD = "**用技法卡**"
# Set by whoever applies the plan: True once the author has seen the old and the new sentence of the stage 3 cell
# and said yes; False while that is open (then the cell stays as r5.59 has it).
STAGE3_APPROVED = True
# The same for the paragraph on the two lists at the tidying-up step of quality-loop.md: True once the author has
# seen it and said yes (and said which file "本书的写法约定" is); False while that is open (no such paragraph).
TIDYING_APPROVED = True
# Which file "本书的写法约定" is, as the author said: a key of TIDYING_READINGS (None while that is open). The page
# carries the half-sentence of that reading and not the other; if the author names another file, its half-sentence is
# added here when the paragraph is written.
TIDYING_READING = "rules"
TIDYING_READINGS = {
    "rules": "作者说收进规矩的，先收进本书的写法约定，也就是本书规则，写进哪一份由作者定，"
             "照上面“这本书的写进本书规则，并在冲突登记表登记”走；",
    "preference": "作者说收进规矩的，先收进本书的写法约定，也就是本书档案“作者选择”里的长期偏好"
                  "（[项目档案模板](../assets/project-template.md)），记来源原话、适用范围、完整限定与例外、确认或撤回状态；",
}
# The sentence on the two exceptions, after the "只要正文" sentence in the section "交付状态" of quality-loop.md: that
# section is compared whole and any change in it needs the author's recorded approval. True once the author has said
# yes and the sentence is written right after the r5.59 sentence, on the same line; False while that is open (then the
# section is r5.59's, byte for byte).
TEXT_ONLY_SENTENCE_APPROVED = False
TEXT_ONLY_AFTER = "用户只要正文时，正文中不附状态、过程或后记；将状态和证据保存到独立工作记录。"
TEXT_ONLY_SENTENCE = ("本书有技法库的，技法卡有两样例外，用户只要正文时也在正文外各另说一句，不插进正文："
                      "这一轮有只收窄改过的技法卡的（[技法卡模板](../assets/technique-card-template.md)“改卡分轻重”），"
                      "只说改了哪张卡的哪一句；这一次用的技法卡作者还没看过、或者看过没定的，只说用了哪张"
                      "（[正文与场景](drafting.md)“用技法卡”）。别的说明照旧记在工作记录里。")
TEXT_ONLY_NEXT = "新章全流程下，“只要正文”不取消别的阶段的成果"

# Not changed by r5.60 (the same values test_r554_dialogue.py pins for the gate; the revision card is pinned here).
UNCHANGED_SHA256 = {
    "scripts/workflow_guard.py": "f4d644de5235f49e382018b12447c5de596c2273edeb3b947f1119f710d87200",
    "assets/delivery-gate-card.md": "4569fe40f8f3f0a2e331d7f5cdb14be639b8a4d8b19f739664788dcb7a60991f",
    "assets/revision-card.md": "eb1182b64656c3dac3735d43a4cda6929605bdb196925de0bfdb942c4e6cf851",
    "CONSTITUTION.md": "618105fb7e7d0885773b03b0a15774c10574490d6cbe95a41ef2b9680dfa1573",
}
# The whole section "交付状态" of quality-loop.md as darwin_eval.py cuts it, r5.59 text. The two lists are added
# under another heading and do not touch it; with TEXT_ONLY_SENTENCE_APPROVED the section is this text plus that one
# sentence.
DELIVERY_STATE_SECTION_SHA256 ="3a06e0230eec622b638a1ebe9efb84625492ea3aaa60bfb161068bf68ad342da"  # sha256 of section_of(r5.59 page, title)
UNCONDITIONAL = ("永远", "绝不", "必须", "严禁")
FILLED = {
    "- **Scene ID / Chapter**": "S1 / 第七章",
    "- **Scene Type**": "Core Conflict (核心博弈戏)",
    "- **POV Character & Sensory Limit (视角人物与感知盲区)**": "阿梁，看不见柜台后面",
    "- **Polarity Shift (局势极性变化)**": "[有把握] -> [被拿住短处]",
    "- **Core Prop Anchor (核心交互道具)**": "一只修了一半的怀表",
    "1. **入场动作与诉求 (Goal - Late In)**": "他来取表，想再赊一回",
    "2. **对手反制与阻碍 (Obstacle & Escalation)**": "店主把欠条抽出来摆在柜台上",
    "3. **破局点/意外转折 (The Turn)**": "表里换上的零件不是他要的那种",
    "4. **出场悬念钩子 (Exit Hook - Early Out)**": "他没拿表就走了",
    "- **禁止直接概括的过程**": "两个人对着欠条算账那一段",
    "- **潜台词冰山 (Subtext)**": "嘴上算钱，争的是还认不认这个熟客",
    "- **情绪生理化映射 (Embodiment)**": "店主一直没抬头，手里的镊子停了两回",
}
VALUES = {
    "none": "无",
    "two": "T-03 第 2 版（上一场停在险事上，这一场开头用得上）；T-11 第 1 版（三个人同场换话头）。其余命中：T-07、T-15",
    "pipe": "T-03 第 2 版 | T-11 第 1 版",
    "arrow": "T-03 第 2 版 -> 换成 T-11",
    "english": "T-03 (the turn; change of topic; exit hook; goal)",
    "empty": "",
}


def read(rel):
    return (SKILL / rel).read_text(encoding="utf-8")


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def paragraph_with(text, phrase):
    found = [line for line in text.splitlines() if phrase in line]
    if len(found) != 1:
        raise AssertionError("expected one paragraph with %r, found %d" % (phrase, len(found)))
    return found[0]


def between(text, start, end):
    return text[text.index(start):text.index(end)]


def card(new):
    """The template with the old fields filled. new: 'gone' (the line removed), 'hint' (as the template has it),
    or a key of VALUES."""
    out = []
    for line in read("assets/scene-beat-card.md").splitlines():
        key = next((k for k in FILLED if line.startswith(k)), None)
        if key:
            out.append("%s: %s" % (key, FILLED[key]))
        elif line.startswith("- **%s**" % FIELD):
            if new == "gone":
                continue
            out.append(line if new == "hint" else "- **%s**: %s" % (FIELD, VALUES[new]))
        else:
            out.append(line)
    return "\n".join(out) + "\n"


class NothingBoundChanged(unittest.TestCase):
    def test_the_gate_the_cards_and_the_constitution_are_as_they_were(self):
        for rel, digest in UNCHANGED_SHA256.items():
            self.assertEqual(hashlib.sha256((SKILL / rel).read_bytes()).hexdigest(), digest, rel)


class BeatCard(unittest.TestCase):
    def test_the_field_sits_after_the_r554_fields_and_before_the_four_beats(self):
        text = read("assets/scene-beat-card.md")
        line = paragraph_with(text, "- **%s**" % FIELD)
        self.assertLess(text.index("- **接上一场**"), text.index(line))
        self.assertLess(text.index(line), text.index("## Four-Step Beat Map"))
        for phrase in ("本书有技法库时填", "落笔前挑定拿来写的，写编号、第几版、为什么，最多两张",
                       "其余命中的另写在后面，只记编号，不读进起草", "没有对得上的写“无”", "列给作者看不算作者采纳"):
            self.assertIn(phrase, line)
        hint = line[line.index("*(") + 2:line.rindex(")*")]
        for bracket in "()（）":  # the gate strips a hint up to the first closing bracket (see test_r554_dialogue.py)
            self.assertNotIn(bracket, hint)

    def test_the_opening_paragraph_says_what_the_gate_does_with_it(self):
        opening = paragraph_with(read("assets/scene-beat-card.md"), "落笔前填（")
        for phrase in ("（r5.60）本书有技法库的，“这一场用的技法卡”一栏记落笔前挑定的卡，过场以外各类场都可以填，没有技法库的书空着；交付门不核这一栏。",
                       "见[正文与场景](../references/drafting.md)“用技法卡”",
                       "这一栏记的是落笔前的打算：卡在任务开始时冻结，起草时停下没用的、写完自查作用链没走到的，都不回头改这一栏，交稿时照实说"):
            self.assertIn(phrase, opening)
        # the r5.54 sentences are as they were
        self.assertIn("“这一场谁在乎什么”“场上的人声”“接上一场”三栏，过场以外各类场都可以填；交付门不核这三栏。", opening)
        self.assertIn("这三栏可以空着，上面说的“每一栏都要填”指原有各栏", opening)

    def test_the_gate_reads_the_card_as_before(self):
        guard = load(GUARD, "workflow_guard_r560")
        gone = guard.read_beat_card(card("gone"))
        self.assertEqual(gone[1], [])
        self.assertEqual(gone[0], [{"id": "S1", "type": "core", "polarity": ["有把握", "被拿住短处"],
                                    "prop": "一只修了一半的怀表"}])
        for new in ["hint"] + list(VALUES):
            self.assertEqual(guard.read_beat_card(card(new)), gone, new)
        for field, words in guard.SCENE_FIELDS:  # the label holds none of the words the gate looks for
            for word in words:
                self.assertNotIn(word, FIELD.lower(), (field, word))
        self.assertNotIn(FIELD, GUARD.read_text(encoding="utf-8"))

    def test_the_field_is_frozen_with_the_rest_of_the_card(self):
        # `check` passes with the field filled; after `start`, changing only this field blocks the inputs: the card
        # is a frozen source, so the field records what was chosen before writing and is not edited afterwards.
        with tempfile.TemporaryDirectory(prefix="r560-") as tmp:
            run_dir = Path(tmp)
            (run_dir / "beats.md").write_bytes(card("two").encode("utf-8"))
            (run_dir / "chapter.md").write_bytes("柜台上的怀表还开着后盖。\n\n“取表。”阿梁说。\n".encode("utf-8"))
            (run_dir / "spec.json").write_bytes(json.dumps({"candidate": "chapter.md", "checks": [
                {"id": "beats", "type": "scene_beats", "source": "beats.md"}]}, ensure_ascii=False).encode("utf-8"))

            def run(*args):
                proc = subprocess.run([sys.executable, "-I", "-B", str(GUARD), *args], cwd=run_dir,
                                      capture_output=True, text=True, encoding="utf-8")
                return proc.returncode, proc.stdout

            code, out = run("check", "spec.json")
            self.assertEqual((code, json.loads(out)["status"]), (0, "GREEN"))
            self.assertEqual(run("start", "state.json", "--task-id", "r560", "--spec", "spec.json")[0], 0)
            self.assertIn("INPUT_READY=READY", run("status", "state.json", "--summary")[1])
            (run_dir / "beats.md").write_bytes(card("arrow").encode("utf-8"))
            self.assertIn("INPUT_READY=BLOCKED", run("status", "state.json", "--summary")[1])


class Drafting(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.text = read("references/drafting.md")
        cls.part = between(cls.text, LEAD, "**起草时看着卡、样本和素材写。**")

    def test_the_paragraph_sits_between_preparing_and_drafting(self):
        places = [self.text.find(s) for s in ("**落笔前备料。**", LEAD, "**起草时看着卡、样本和素材写。**",
                                              "**写完以后查改。**")]
        self.assertNotIn(-1, places)
        self.assertEqual(places, sorted(places))
        self.assertEqual(self.text.count(LEAD), 1)
        # only for a book that has a technique library; no library is built for it
        self.assertIn("（r5.60，本书有技法库时）：本书的项目资料里存着技法卡（[长短篇拆文与技法库](deconstruction-library.md)"
                      "“按需建立与维护技法库”）才读这一段；没有的照常写，不为这一段建库。", self.part)

    def test_three_moments(self):
        choose = paragraph_with(self.part, "- 挑卡的时候")
        draft = paragraph_with(self.part, "- 起草的时候")
        check = paragraph_with(self.part, "- 写完自查的时候")
        for phrase in ("读“什么时候拿出来用”“失效情境”两栏", "只挑工坊的判断是“可用”的卡；状态是“候选，没试写”、归档、收进了规矩的不挑。",
                       # the author's later decision: a card the author declined or withdrew is not picked
                       "也看卡最底下一块“作者采纳状态”一栏：作者说过不要、或者撤回过采纳的卡不挑，工坊的判断是“可用”也不挑，"
                       "作者以后又明说要用的，照作者新的话办；这一栏是“没给作者看”或“作者看过、没定”的，工坊的判断是“可用”的可以拿来写。",
                       "一场最多用两张，挑最对的；其余命中的只在节拍卡“这一场用的技法卡”一栏记一笔，不读进起草",
                       "没有对得上的照常原创，不为用上卡去凑。"):
            self.assertIn(phrase, choose)
        for phrase in ("只读卡上写明起草时读的那几栏（作用链、成立条件、在本书怎样重新实现这些），另读一句固定的话：“不搬原作的人物、台词和桥段。”",
                       "反面的三栏（“失效情境”“用过头的样子”“不可搬用的”）不读，原作的情形、反例和新写的演示也不读。",
                       "停下来先问作者，不硬用", "也记进下文的新增设定清单，不写成本书的设定"):
            self.assertIn(phrase, draft)
        for phrase in ("拿“用过头的样子”核一遍", "对着“不可搬用的”整栏看有没有搬原作的东西", "看作用链在这一场走到没有",
                       "不为了走到硬补；怎样记照卡上半开头“写完自查的时候”一条。", "这一步只核有没有照做，不判写得好不好。"):
            self.assertIn(phrase, check)
        self.assertIn("各读哪几栏以卡上半开头写的为准", self.part)  # one place holds the full list: the card
        self.assertNotIn("都是正面的", draft)  # one of the fields read while drafting asks whether a pattern forms
        self.assertIn("挂了技法卡的场，交稿以前另照上文“用技法卡”里写完自查那一条核一遍（r5.60）。",
                      paragraph_with(self.text, "**写完以后查改。**"))

    def test_order_with_modules_and_style_cards(self):
        order = paragraph_with(self.part, "先后：")
        for phrase in ("本书既有文风和作者这一轮的要求照旧在前", "工坊的模块（[对白专项](dialogue-craft.md)、[分场规范](scene-dramaturgy.md)这些）在卡前面，卡和模块说法不一样时，把两边的原句列给作者，作者定以前照模块办；",
                       "同一处做法上，作者采纳过的本书技法卡先于通用[风格卡](style-cards.md)。",
                       "一场已经挂了技法卡的，这一场的风格卡场景层最多一张。"):
            self.assertIn(phrase, order)

    def test_what_is_said_on_delivery(self):
        said = paragraph_with(self.part, "交稿时在正文外说明")
        for phrase in ("交稿时在正文外说明这一场用了哪张技法卡（编号、第几版）、为什么，整章逐场说，节拍卡上照记",
                       "冻结了的节拍卡不回头改", "作者只要正文的，这一句记在工作记录里，作者问起再说。",
                       "这一轮只收窄改过的卡（技法卡模板“改卡分轻重”），这一章用没用到它，都告诉作者改了哪张卡的哪一句，作者只要正文时也在正文外另说这一句；",
                       "例外有两样：",
                       "这一场用的卡，“作者采纳状态”一栏是“没给作者看”或“作者看过、没定”的，作者只要正文时也在正文外另说一句，只说用了哪张。",
                       "列给作者看不算作者采纳。"):
            self.assertIn(phrase, said)

    def test_what_is_not_verified_is_said(self):
        self.assertIn("这一点在工坊里没有验证过，这一段的用法也没有在真实章节上用过。", self.part)

    def test_no_unconditional_words_and_no_counts_beyond_the_two_the_author_set(self):
        for word in UNCONDITIONAL:
            self.assertNotIn(word, self.part, word)
        # the only limits are the author's: two technique cards a scene, one scene-layer style card beside them
        self.assertEqual(self.part.count("最多"), 2)


class SceneModule(unittest.TestCase):
    def test_section_four_has_the_item_and_the_source_says_so(self):
        text = read("references/scene-dramaturgy.md")
        item = paragraph_with(text, "- **这一场用的技法卡（r5.60）**")
        self.assertLess(text.index("- **作者改过的节拍卡（r5.59）**"), text.index(item))
        self.assertLess(text.index(item), text.index("- **写完后**"))
        for phrase in ("拿来写的写编号、第几版、为什么，一场最多两张；其余命中的只记编号，不读进起草；没有对得上的写“无”，照常原创。",
                       "照[正文与场景](drafting.md)“用技法卡”", "交付门不核这一栏", "起草时停下没用的不回头改，交稿时照实说",
                       "卡只是参考依据：卡和本页说法不一样时，把两边的原句列给作者，作者定以前照本页办。", "一场已经挂了技法卡的，[风格卡](style-cards.md)场景层最多一张。"):
            self.assertIn(phrase, item)
        source = paragraph_with(text, "来源：作者 2026-10-22 转来的实施规范")
        self.assertIn("r5.60（2026-11-20）：作者定了技法卡在写作流程里怎样用", source)
        self.assertIn("交付门的脚本没有改，不核这一栏。第 1—3 节的照录原文没有改，宪法没有改。这一条没有在真实章节上用过。", source)


class DeliveryNote(unittest.TestCase):
    def test_the_note_has_the_item_and_the_one_exception(self):
        text = read("references/editing.md")
        item = paragraph_with(text, "- **用了哪张技法卡、这一轮改过的卡**（r5.60）")
        self.assertLess(text.index("- **待判断的变化**（r5.49"), text.index(item))
        self.assertLess(text.index(item), text.index("   - **没验证的**"))
        for phrase in ("怎样挑、怎样读照[正文与场景](drafting.md)“用技法卡”，改写照起草的读法读卡",
                       "写哪一场用了哪张（编号、第几版）、为什么，整章逐场说。",
                       "这一轮只收窄改过的卡，这一次用没用到都列一句，写改了哪张卡的哪一句（照[技法卡模板](../assets/technique-card-template.md)“改卡分轻重”）。",
                       "列给作者看不算作者采纳。两样都没有的，不写这一项。"):
            self.assertIn(phrase, item)
        closing = paragraph_with(text, "作者说“只要正文”时，只交正文，这几行留在工作记录里，作者问起再给")
        self.assertIn("例外有两样（r5.60）：这一轮有只收窄改过的技法卡的，作者只要正文时也在正文外另说一句，只说改了哪张卡的哪一句；"
                      "这一次用的技法卡作者还没看过、或者看过没定的，也在正文外另说一句，只说用了哪张。"
                      "两句都不插进正文；别的卡用了哪张那一句照旧留在工作记录里。", closing)
        self.assertIn("说明本身不超过十行", closing)  # as before

    def test_the_entry_page_lists_it_and_points_to_the_exception(self):
        skill = read("SKILL.md")
        self.assertIn("改完写交稿说明（范围、改了和保住了什么、新增和拿掉的事实、待判断的变化、用了哪张技法卡和这一轮改过的卡、没验证的）", skill)
        only_text = paragraph_with(skill, "- 用户只要正文时，只交正文；")
        self.assertIn("例外有两样（r5.60）：本书有技法库的，这一轮有只收窄改过的技法卡，在正文外另说一句改了哪张卡的哪一句；"
                      "用了作者还没看过、或者看过没定的技法卡，在正文外另说一句用了哪张"
                      "（[正文与场景](references/drafting.md)“用技法卡”）。", only_text)


class TidyingUp(unittest.TestCase):
    def test_two_lists_for_the_author_card_by_card(self):
        text = read("references/quality-loop.md")
        part = text[text.index("### 整理一次：交作者定"):text.index("### 判断卡请认单（第 7 阶段）")]
        # the r5.59 paragraph is as it was, and still says when the tidying is done
        self.assertIn("不定时跑，不自己跑。", part)
        self.assertIn("技法库、参考书、教师材料里的说法只当参考，可以附在旁边给作者看，不算依据，不参与合并。", part)
        if not TIDYING_APPROVED:
            self.assertNotIn("技法卡的两张单", text)
            return
        lists = paragraph_with(part, "**技法卡的两张单（r5.60）。**")
        for phrase in ("本书有技法库的，每次做这一步，顺带列两张单交作者逐张定，和上面五类分开列。",
                       "工坊只列，不改卡的状态，不自己收、不自己归档。",
                       "一张列用过几回、作者都采纳了的卡，问要不要收进规矩；一张列很久没用过的卡，问要不要归档。",
                       "不定卡数上限；“几回”“很久”不折成回数、章数的线", "作者没回话的卡照原样，不当同意。",
                       "只记成维护任务，照[技能维护](skill-evaluation.md)走新旧对照，例子另写，原作的东西（人物、桥段、台词这些）不带。",
                       "改成“归档”或“收进了规矩”，写哪天、作者的原话，收进了规矩的另写收进哪一处；这两种卡以后挑卡时不挑，查旧章的依据时还查得到。",
                       "这两张单没有在真实记录上列过。"):
            self.assertIn(phrase, lists)
        # the reading the author chose, and not the other
        self.assertIn(TIDYING_READING, TIDYING_READINGS, "say which file the author chose")
        for key, half in TIDYING_READINGS.items():
            (self.assertIn if key == TIDYING_READING else self.assertNotIn)(half, lists, key)
        for word in UNCONDITIONAL:
            self.assertNotIn(word, lists, word)

    def test_the_locked_section_of_the_page_is_untouched(self):
        darwin = load(DARWIN, "darwin_r560")
        found = darwin.section_of(read("references/quality-loop.md"), "交付状态：四项分开，未测不算通过")
        if TEXT_ONLY_SENTENCE_APPROVED:
            # the one sentence the author approved, right after the r5.59 sentence and before the next one of the same
            # line; without it the section is r5.59's
            self.assertEqual(found.count(TEXT_ONLY_AFTER + TEXT_ONLY_SENTENCE + TEXT_ONLY_NEXT), 1)
            found = found.replace(TEXT_ONLY_SENTENCE, "", 1)
        else:
            self.assertNotIn("技法卡", found)
        self.assertEqual(hashlib.sha256(found.encode("utf-8")).hexdigest(), DELIVERY_STATE_SECTION_SHA256)


class StageThree(unittest.TestCase):
    def test_the_cell_follows_the_author_s_answer(self):
        page = read("references/chapter-confirmation.md")
        cell = paragraph_with(page, "| 3 `preparation` 写前准备 |")
        new = ("本书有技法库的，各场挑定拿来写的技法卡（编号、第几版、为什么，记在节拍卡上，其余命中的只记编号），列给作者看不算作者采纳，"
               "确认这一阶段的“继续”“好”也不算对卡的采纳；")
        if STAGE3_APPROVED:
            self.assertIn("风格选择；" + new + "视觉准备和具体采用范围；", cell)
        else:
            self.assertNotIn("技法卡", cell)
            self.assertIn("风格选择；视觉准备和具体采用范围；", cell)
        # either way the row stays one line, so the locked section below keeps its line numbers (53-60)
        lines = page.split("\n")
        self.assertEqual(lines[43], cell)
        self.assertEqual(lines[51], "## 确认是什么意思")


class OneName(unittest.TestCase):
    def test_the_field_and_the_paragraph_are_called_the_same_everywhere(self):
        for rel in ("assets/scene-beat-card.md", "references/drafting.md", "references/scene-dramaturgy.md"):
            self.assertIn("“%s”" % FIELD, read(rel), rel)
        for rel in ("assets/scene-beat-card.md", "references/scene-dramaturgy.md", "references/editing.md", "SKILL.md"):
            self.assertRegex(read(rel), r"\]\((?:\.\./)?(?:references/)?drafting\.md\)“用技法卡”", rel)
        template = read("assets/technique-card-template.md")
        self.assertIn("### 改卡分轻重", template)  # editing.md names this section of the card
        for label in ("**卡的状态**", "**本书试用**", "**作者采纳状态**", "**失效情境**", "**用过头的样子**", "**不可搬用的**"):
            self.assertIn(label, template, label)


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""r5.18: the semicolon, after the 2026-10-19 outside review of r5.16 (P3-NEW-01).

An author's grammar handbook said semicolons go only between coordinate clauses and "turn or cause: no semicolon".
GB/T 15834-2011 says more: 4.6.3.2 puts the semicolon between the first-level clauses of a multiple complex sentence
that is not coordinate, mainly choice and turn, and the standard's examples include a cause. Judged by the handbook,
semicolons the standard allows would be marked wrong and changed in finished chapters. The punctuation module said
nothing about the semicolon beyond one optional example, so it could not set the handbook right.

These tests pin a short section that gives the three uses with their clause numbers, says a turn or a cause is no
reason to call a semicolon wrong (look at whether it separates first-level clauses), keeps the semicolon optional,
and says how to read an author's handbook that is stricter than the standard: check the standard; what the standard
allows is not marked wrong; if the author wants the work to use less of it, that is the work's convention, recorded
once the author confirms, and the change is optional polish. The examples must really be multiple complex sentences:
each side of the semicolon has its own comma.
"""

import os
from pathlib import Path
import re
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
PUNCT = ROOT / "skills" / "novel-workshop" / "references" / "chinese-punctuation.md"


def section(text, heading):
    return text.split("\n" + heading + "\n", 1)[1].split("\n## ", 1)[0]


class Semicolon(unittest.TestCase):
    def setUp(self):
        self.text = PUNCT.read_text(encoding="utf-8")

    def test_section_sits_after_the_comma_clauses_and_before_the_ellipsis(self):
        headings = [line for line in self.text.splitlines() if line.startswith("## ")]
        self.assertIn("## 分号", headings)
        where = headings.index("## 分号")
        self.assertEqual(headings[where - 1], "## 顿号、问号与冒号")
        self.assertEqual(headings[where + 1], "## 省略号、破折号、连接号")

    def test_three_uses_with_their_clause_numbers(self):
        part = section(self.text, "## 分号")
        for phrase in ("GB/T 15834—2011", "4.6.3.1", "4.6.3.2", "4.6.3.3", "并列分句", "多重复句", "第一层分句",
                       "选择、转折", "因果", "分项列举"):
            self.assertIn(phrase, part)
        self.assertLess(part.index("4.6.3.1"), part.index("4.6.3.2"))
        self.assertLess(part.index("4.6.3.2"), part.index("4.6.3.3"))

    def test_a_turn_or_a_cause_is_no_reason_to_call_it_wrong(self):
        part = section(self.text, "## 分号")
        rule = [line for line in part.splitlines() if "不能因为" in line]
        self.assertEqual(len(rule), 1)
        rule = rule[0]
        for phrase in ("转折或因果", "判分号用错", "第一层分句", "都不算错"):
            self.assertIn(phrase, rule)
        self.assertNotIn("不用分号", part)

    def test_examples_are_multiple_complex_sentences(self):
        part = section(self.text, "## 分号")
        examples = [e for e in re.findall(r"`([^`]+)`", part) if "；" in e]
        self.assertGreaterEqual(len(examples), 2)
        for example in examples:
            sides = example.split("；")
            self.assertEqual(len(sides), 2, example)
            self.assertTrue(all("，" in side for side in sides), example)
        line = [l for l in part.splitlines() if "4.6.3.2" in l][0]
        self.assertIn("（转折）", line)
        self.assertIn("（因果）", line)

    def test_a_stricter_handbook_is_checked_against_the_standard(self):
        part = section(self.text, "## 分号")
        rule = [line for line in part.splitlines() if "语文手册" in line]
        self.assertEqual(len(rule), 1)
        rule = rule[0]
        for phrase in ("比标准原文严", "先对照标准", "不按手册判错", "作品约定", "作者确认", "可选", "不算病句"):
            self.assertIn(phrase, rule)
        self.assertLess(rule.index("先对照标准"), rule.index("不按手册判错"))


if __name__ == "__main__":
    unittest.main()

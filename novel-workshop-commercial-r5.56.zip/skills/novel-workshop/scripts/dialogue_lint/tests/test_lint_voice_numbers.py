"""The speaker column holds numbers only; the summary adds up to the report body.

No status is given per person (no REVIEW, no NO_THRESHOLD_ALERT): the numbers are for
the author to read back with, not a line a character has to reach. A character the
author lists in cold_protagonist_names (people of few words, people giving orders)
gets no short-sentence or particle hints. All names and text are synthetic.
"""
import contextlib
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from dialogue_antipatterns import scan_dialogue_antipatterns
from run_lint import main
from voice_lint import VoiceprintProfile, analyze_voice_and_idioms

SHORT_HINTS = {'COMP_01_BARE_MONOSYLLABIC_VERB', 'COMP_02_IMPERATIVE_TRIPLE_CHOP',
               'COMP_03_SUBJECTLESS_STATUS_PAIR', 'COMP_04_COORDINATE_REPLY', 'VOICE_SHORT_CLAUSES'}
TERSE = ['陈原说：“拉。”', '陈原说：“靠岸，停稳，抛缆。”', '陈原说：“在左边柜里。”',
         '陈原说：“电闸断了，门打不开。”', '陈原说：“先关门。再关窗。后关灯。”',
         '陈原说：“尽管下着雨但是还得走。”']


def run_cli(args):
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        try:
            code = main(args)
        except SystemExit as stop:
            code = stop.code
    return code, out.getvalue(), err.getvalue()


class SpeakerNumbersTests(unittest.TestCase):
    def test_rows_hold_numbers_and_no_verdict(self):
        text = ['陈原说：“先关门，再关窗。”', '陈原说：“好吧。”', '陈原说：“快走。”',
                '“谁？”', '', '陈原推门进来。', '“到了。”']
        report, _ = analyze_voice_and_idioms(text, registry={'陈原': VoiceprintProfile('陈原')})
        self.assertEqual({k: report['陈原'][k] for k in ('台词数', '待确认台词数', '分句数', '平均分句长',
                                                       '口语标记命中台词数', '口语标记命中率')},
                         {'台词数': 3, '待确认台词数': 1, '分句数': 4, '平均分句长': 2.5,
                          '口语标记命中台词数': 2, '口语标记命中率': '66.7%'})
        self.assertEqual((report['未知']['台词数'], report['未知']['待确认台词数'], report['未知']['平均分句长']),
                         (0, 1, None))
        for row in report.values():
            for key in ('诊断状态', '口语烟火气率', '角色参考线'):
                self.assertNotIn(key, row)
            self.assertFalse(any('REVIEW' in str(v) or 'ALERT' in str(v) for v in row.values()))

    def test_reference_numbers_in_a_profile_no_longer_change_anything(self):
        text = ['陈原说：“走。”'] * 4
        low = analyze_voice_and_idioms(text, registry={'陈原': VoiceprintProfile('陈原', 'plain', 99, 1.0, '')})
        none = analyze_voice_and_idioms(text, registry={'陈原': VoiceprintProfile('陈原')})
        self.assertEqual(low, none)

    def test_listed_terse_speaker_gets_no_short_sentence_or_particle_hints(self):
        registry = {'陈原': VoiceprintProfile('陈原', 'laconic')}
        def hits(cold):
            pattern = scan_dialogue_antipatterns(TERSE, cold, names=tuple(registry), include_style_hints=True)
            _, voice = analyze_voice_and_idioms(TERSE, registry=registry, include_style_hints=True,
                                                cold_protagonist_names=cold)
            return {i.rule_id for i in pattern + voice}
        self.assertTrue(SHORT_HINTS <= hits(()))
        listed = hits(('陈原',))
        self.assertFalse(SHORT_HINTS & listed)
        self.assertIn('TRANS_05_FORMAL_CONNECTIVES_IN_SPEECH', listed)

    def test_short_sentence_hint_does_not_depend_on_the_archetype_label(self):
        text = ['陈原说：“先关门。再关窗。后关灯。”'] * 3
        for archetype in ('laconic', 'folksy_warm', ''):
            with self.subTest(archetype=archetype):
                _, issues = analyze_voice_and_idioms(text, include_style_hints=True,
                    registry={'陈原': VoiceprintProfile('陈原', archetype)})
                self.assertEqual([i.rule_id for i in issues], ['VOICE_SHORT_CLAUSES'] * 3)


class SummaryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def scan(self, text, config, *extra):
        source, cfg = self.root / 'chapter.txt', self.root / 'book.json'
        report, request = self.root / 'report.json', self.root / 'request.json'
        for path in (report, request):
            if path.exists():
                path.unlink()
        source.write_text(text, encoding='utf-8')
        cfg.write_text(json.dumps(config, ensure_ascii=False), encoding='utf-8')
        code, out, err = run_cli(['scan', str(source), '--config', str(cfg), '--output', str(report),
                                  '--request-output', str(request), *extra])
        if code not in (0, 1):
            return code, None, None, err
        return (code, json.loads(report.read_text(encoding='utf-8')),
                json.loads(request.read_text(encoding='utf-8')), err)

    def test_summary_counts_match_the_report_body(self):
        text = '\n'.join(TERSE + ['方禾说：“先把窗边那张很沉的木桌挪开，再把门口那些椅子搬到墙边，最后关灯。”',
                                  '“谁？”', '方禾推门进来。', '“到了。”']) + '\n'
        config = {'profiles': {'陈原': {}, '方禾': {}}, 'stress_speakers': ['方禾']}
        code, report, request, err = self.scan(text, config, '--style-hints')
        self.assertEqual(code, 0, err)
        summary, rows = report['summary'], report['voice_report'].values()
        issues = report['voice_issues'] + report['antipattern_issues']
        self.assertEqual(summary['dialogue_quotes'], len(report['dialogues']))
        self.assertEqual(summary['confirmed_quotes'], sum(r['台词数'] for r in rows))
        self.assertEqual(summary['unconfirmed_quotes'], sum(r['待确认台词数'] for r in rows))
        self.assertEqual(summary['confirmed_quotes'] + summary['unconfirmed_quotes'], summary['dialogue_quotes'])
        self.assertEqual(summary['voice_issue_records'], len(report['voice_issues']))
        self.assertEqual(summary['antipattern_issue_records'], len(report['antipattern_issues']))
        self.assertEqual(summary['review_records'], len(issues))
        self.assertEqual(summary['candidate_quotes'], len({i['quote_id'] for i in issues}))
        self.assertEqual(summary['unconfirmed_issue_records'],
                         sum(i['confidence'] not in ('explicit', 'manual') for i in issues))
        self.assertEqual(summary['patch_candidate_quotes'], len(request['items']))
        self.assertIn('STRESS_SPEECH_REVIEW', [i['rule_id'] for i in report['voice_issues']])

    def test_profiles_may_be_empty_and_old_reference_numbers_are_noted(self):
        code, report, _, err = self.scan('陈原说：“好。”\n', {'profiles': {'陈原': {}}})
        self.assertEqual(code, 0, err)
        self.assertEqual(report['voice_report']['陈原']['台词数'], 1)
        code, report, _, err = self.scan('陈原说：“好。”\n', {'profiles': {
            '陈原': {'archetype': 'plain', 'min_avg_len': 5, 'min_colloquial_rate': 0.2, 'voice_prompt': '短。'}}})
        self.assertEqual(code, 0, err)
        self.assertTrue(any('min_avg_len' in note for note in report['config_notes']))
        for bad in ({'陈原': {'unknown_field': 1}}, {'陈原': []}, {'陈原': {'min_avg_len': -1}}):
            with self.subTest(profiles=bad):
                self.assertEqual(self.scan('陈原说：“好。”\n', {'profiles': bad})[0], 2)

    def test_names_listed_only_as_terse_or_stressed_are_registered_for_every_scanner(self):
        code, report, _, err = self.scan('陈原说：“在左边柜里。”\n方禾说：“好。”\n',
            {'cold_protagonist_names': ['陈原'], 'stress_speakers': ['方禾']}, '--style-hints')
        self.assertEqual(code, 0, err)
        self.assertEqual([(d['speaker'], d['confidence']) for d in report['dialogues']],
                         [('陈原', 'explicit'), ('方禾', 'explicit')])
        self.assertEqual(report['voice_report']['陈原']['台词数'], 1)
        self.assertEqual(report['antipattern_issues'], [])

    def test_wording_list_comes_from_the_book_and_each_place_is_recorded_once(self):
        text = '陈原说：“这件挺扛冻。”\n'
        code, report, request, err = self.scan(text, {'profiles': {'陈原': {}}})
        self.assertEqual(code, 0, err)
        self.assertEqual(report['checks_run']['suspicious_expressions'], [])
        self.assertEqual(report['summary']['review_records'], 0)
        code, report, request, err = self.scan(text, {'profiles': {'陈原': {}}, 'suspicious_expressions': ['挺扛冻']})
        self.assertEqual(code, 0, err)
        self.assertEqual(report['checks_run']['suspicious_expressions'], ['挺扛冻'])
        self.assertEqual([i['rule_id'] for i in report['antipattern_issues']], ['SYN_01_DEGREE_ACT_VERB'])
        self.assertEqual(report['voice_issues'], [])
        self.assertEqual(report['summary']['review_records'], 1)
        self.assertEqual(len(request['items'][0]['issues']), 1)
        for bad in ([''], 'x', ['挺扛冻', '挺扛冻'], [3]):
            with self.subTest(value=bad):
                self.assertEqual(self.scan(text, {'suspicious_expressions': bad})[0], 2)


if __name__ == '__main__':
    unittest.main()

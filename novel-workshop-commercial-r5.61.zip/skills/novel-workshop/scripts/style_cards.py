#!/usr/bin/env python3
"""Style cards: the index, literal hints for a scene, and the chosen cards loaded as directions (r5.45, references/style-cards.md).

python3 style_cards.py index [--layer L] [--project BOOK_CONFIG] [--format text|json]
python3 style_cards.py match [--text TEXT] [--file FILE ...] [--project BOOK_CONFIG] [--top N] [--format text|json]
python3 style_cards.py load CARD_ID [CARD_ID ...] [--examples] [--no-fixed-base] [--project BOOK_CONFIG]
python3 style_cards.py review CARD_ID [CARD_ID ...] [--no-fixed-base] [--project BOOK_CONFIG] [--format text|json]
python3 style_cards.py copied CARD_ID [CARD_ID ...] --file DRAFT [--file ...] [--no-fixed-base] [--project BOOK_CONFIG]
                              [--format text|json]
python3 style_cards.py check [--project BOOK_CONFIG]

All commands take --library FILE (default: assets/style-cards/cards.json next to this script's folder).

The cards ship with the workshop (card set 4.1.0, r5.45). They come in four layers: base (the world's ground tone),
voice (the overall prose voice), device (a point-of-view or form device) and scene (what one scene does). Which cards a
scene gets, or none, is the writer's judgment against the index: match only lists literal hits (a card's scene phrases,
the book's keywords) and never picks a card. The index prints each card's genre (domain). load prints the chosen cards
as directions, at most what the card set allows per layer (base 1, voice 1, device 1, scene 2) and never two cards
marked as conflicting; where they differ on sentences and rhythm the card set's order decides (device, voice, scene,
base). By default load prints the directions only (r5.60): the example tables and the model passage come with
--examples, and what a voice looks like when overdone (overuse) is not printed by load at all; review prints it after
writing, as a check to read the scene against, not a verdict. The examples show what the voice is like and are not text
to copy or a replacement table; the opposite phrasings (a card's and the set's global ones) are not a list of banned
words. An example that holds another loaded card's opposite phrasing, or the set's global one (minus the terms a loaded
card opens up), is marked for a second look; without --examples load only says how many there are. The author's own
text and the book's voice records come first. copied looks for the cards' own wording in a draft after writing: any
stretch of four or more Chinese characters taken over from an example (literal only; whether it is a problem is the
writer's call). A find that is only a common four-character phrase (COMMON_FOUR, a list the workshop keeps) is left
out of the list and counted; a three-character name from a loaded card's examples (SHORT_NAMES, also the workshop's
list) that stands in the draft is given as a hint, not as taken wording.

A book may keep a config next to its project files (--project): keywords per card (the author's routes), cards the book
does not use (exclude), a default card only when the author has decided one (default_card; without it a scene that
matches nothing gets no card), and a fixed base card only when the author has named one for the whole book and the book
has no sample of the author's own prose yet (fixed_base_card; load, review and copied add it when no base card is named,
--no-fixed-base leaves it out). check validates the library and the config. Read-only and offline; it calls no model.
"""
import argparse
import json
from pathlib import Path
import re
import sys

FORMAT = "novel-workshop-style-cards"
CONFIG_FORMAT = "novel-workshop-style-card-config"
CARD_FIELDS = ("id", "aliases", "name", "layer", "domain", "scene_triggers", "syntax_metrics", "lexical_shifts",
               "kinetic_verbs", "blacklist", "blacklist_patterns", "conflicts_with", "overrides", "sections")
SECTIONS = ("subtext_logic", "lexical_map", "kinetic_verbs_text", "somatosensory", "syntax_rhythm", "example_before",
            "example_after", "overuse")
SYNTAX_FIELDS = {"avg_clause_length", "sentence_final_particles", "punctuation"}
CONFIG_FIELDS = {"format", "format_version", "book", "keywords", "exclude", "default_card", "fixed_base_card", "note"}
BASE_LAYER = "base"
FREE_DOMAIN = "functional-modes"
ID = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
ALT = " / "
PUNCT = set("，。、；：？！…—（）《》「」『』【】“”‘’█·~～,.;:?!()[]")
SPLIT = re.compile(r"[与和或及、/／]")
QUOTED = re.compile(r"「([^」]+)」|“([^”]+)”")
HAN = re.compile(r"[一-鿿]")
DIRECTIONS = ("只加载方向：照这几张卡的叙述逻辑、句子节奏和取材的方向写这一场。例句和示范段只示意这种腔调大概什么样，"
              "不搬进正文，也不当替换表用，例句借的作家、作品的标志性台词和桥段也不搬；名词、动作、感官几栏是可挑的料，"
              "这一场用得上的挑一两样，落在人的动作和感知里，不逐项写；句子长短是方向，不是要凑的数；写过头是什么样这里"
              "不印，留到写完核对时看（review）。作者自己的原文、本书的文风卡和口吻表、已采纳的正文优先，跟卡对不上的地方按作者的。"
              "交稿时在正文外用一句话说明这一场加载了哪几张、为什么（作者只要正文时记在工作记录里）。")
ONLY_DIRECTIONS = "这一次只印方向：腔调示例、动作示例和示范段没有印，要看例子加 --examples。"
WITH_EXAMPLES = "这一次连例子一起印了：例子只示意腔调，不搬进正文，不是替换表。"
TOGETHER_HEAD = "几张同用：句长的大概数对不上时，照 %s 的先后取第一张写了的（下面也按这个先后排）；"
TOGETHER_MARKS = "一张卡的示例撞上另一张的“相反的写法”，那条示例后面标了待复核：只是要回头再看的地方，不是判定。"
TOGETHER_COUNTED = "示例这一次没有印；有示例撞上相反的写法的，末尾写有几条（待复核：只是要回头再看的地方，不是判定）。"
MARKS_COUNTED = "有 %d 条示例撞上了相反的写法（待复核：只是要回头再看的地方，不是判定）。这一次没印示例，要看是哪几条加 --examples。"
GLOBAL_PATTERNS = "（全卡组另有 %d 条句式写在卡片库 global 的 blacklist_patterns 里，同样只是心里有数）"
REVIEW_NOTE = ("写完核对：对着下面每张卡“写过头是什么样”把这一场看一遍。只是自查用的对照，不是判定，不按出现几回算；"
               "看出写过头的地方，照这一场的处境改，或者写明为什么保留。卡里示例的原话有没有照搬进正文，另跑 copied。")
REVIEW_EMPTY = "这张卡没有写。"
INDEX_DOMAIN = "每张卡印着题材：scene 层里题材是 %s 的不挑题材，其余的先看题材对不对得上这本书。" % FREE_DOMAIN
FIXED_HEAD = "本书固定的底色卡：%s（作者定的；只在本书还没有作者正文样本时用）"
FIXED_ADDED = ("本书固定的底色卡 %s 已经带上（作者定的）。它只在本书还没有作者正文样本时用：有了样本或本书文风卡，底色照样本，"
               "这一场不带它就加 --no-fixed-base。")
FIXED_PASSED = "这一次点名了底色卡 %s，本书固定的 %s 没有带。"
FIXED_CLASH = "%s 是本书固定的底色卡：这一场不带它就加 --no-fixed-base"
COPIED_HINTS = ("提示（三个字的专名，不算照搬）：%s。卡里的示例用过这几个名字：是这本书自己的东西就留着，"
                "是顺手从卡里带来的，换成这本书的。")
COPIED_EXEMPT = "另有 %d 处只是常用的四字说法（%s），不算照搬，没有列。"
# copied 用的两张表，都是工坊列的，只管照搬检查报不报，不是说这些词好或不好；每一条都在卡的示例料里（tests/test_r560_style_cards.py 核）。
# 常用的四字说法：成语和天天用的四字搭配，换到哪本书都会自己冒出来，不带哪张卡特有的东西。
COMMON_FOUR = frozenset("""
一声不吭 头也不回 不动声色 面无表情 一言不发 理所当然 似笑非笑 严丝合缝 空无一人 无声无息 密密麻麻 安安静静 一点一点
一圈一圈 一明一灭 毫不犹豫 一字一句 点了点头 叹了口气 看了一眼 瞥了一眼 看了很久 过了很久 站了很久 停下脚步 低下头去
坐了下来 喝了一口 抿了一口 喊了一声 咳了一声 没有回头 没有说话 没有抬头 顿了一下 那天晚上 每天早上 最后一个 一个钟头
一个礼拜 一把钥匙 走廊尽头 墙根底下 从来没有 不知为何 一张一张 一道一道 一层一层 未置可否 笑而不答 拂袖而去 仰天长叹
头也不抬 低下了头 喝了口水 说不出话 越来越小 推门进来 转身就跑 一时无声 二话不说 毫无征兆 毫无血色 眼角余光 字里行间
一瘸一拐 一张一合 一晃一晃 一跳一跳 滴滴答答 平平整整 规规矩矩 热热闹闹 恭恭敬敬 不声不响 不软不硬 不高不低 斤斤计较
骂骂咧咧 嬉皮笑脸 无懈可击 震耳欲聋 盘根错节 瘦骨嶙峋 一页一页 一颗一颗 一只一只 一笔一笔 一粒一粒 一条一条 一枚一枚
一字一字 小口小口
""".split())
TAIL_PARTICLES = "的地得了着"
# 三个字的专名，按卡记：品牌、人名、地名、卡里起的名字、带着这张卡年代或行当印记的器物名；同题材里天天用的普通名词不收。
SHORT_NAMES = {
    "beijing-hooligan-satire": ("北冰洋",),
    "borgesian-meta-labyrinth": ("论镜子",),
    "classical-wuxia-chivalry": ("烧刀子",),
    "classical-zhiguai-liaozhai": ("野史氏",),
    "court-intrigue-undercurrent": ("紫毫笔", "碧螺春"),
    "dnd-tactical-adventure": ("破魔箭",),
    "era-nostalgia-compound": ("大团结", "红双喜", "的确良"),
    "grimm-dark-fairytale": ("水晶鞋", "黑森林"),
    "hk-neon-triad-noir": ("万宝路",),
    "jinyong-orthodox-wuxia": ("回澜掌",),
    "ming-qing-vernacular": ("万字巾",),
    "murakami-urban-melancholy": ("埃文斯",),
    "tarantino-pulp-chatter": ("比利时",),
    "tomb-raiding-fengshui": ("洛阳铲",),
    "urban-power-slap": ("黑金卡",),
    "wang-zengqi-literati-daily": ("烧饼陈", "东大街"),
}
NOT_DECIDED = ("字面命中只是线索：命中了不等于对得上，没命中也不等于对不上。挑哪几张、或者不挑，由写的人对照索引判断"
               "（references/style-cards.md）。")
CLAUSE_LINE = "- 分句（逗号、句号隔开的一小段）大致 %s 字：这种腔调的大致样子，不是要求；连着的动作，几个分句可以连成一句。"
DIALOGUE_LINE = ("- 分句长短和常用语气词这两样说的是叙述（r5.53）：台词的长短、语气词和称呼跟着说话的人、对谁说和此刻的处境走（口吻表、"
                 "作者样本、references/dialogue-craft.md）；卡上没列语气词，不等于台词不带“了、呢、吧”；语气词跟着说话的人和这一刻走，"
                 "不为凑口语句句挂一个（对白专项“声口和语域”，r5.54）。下面卡上专讲对白的说法，"
                 "只管这张卡对得上的那类场面，不带到同一章别的场面；市井温情那张卡里的“全在不言中”只是一种写法：把关心说出口一样可以是温情的场面，"
                 "不因为加载了卡就把已经说出口的关心改成动作（工坊的读法，作者没有逐条看过）；和口吻表、作者样本对不上时按后者。")
CLASH_MARK = "（撞上同用的另一张卡的相反写法：待复核，看这一场的处境、人物和动作合不合，再定用不用）"
GLOBAL_MARK = "（撞上全卡组的相反写法：待复核，看这一场的处境、人物和动作合不合，再定用不用）"
TOGETHER = ("几张同用：先后只定句长的大概数；每张卡句子一节里随动作走的说法照样看。说明之间说法不一时（写不写过程、感官写不写主观"
            "感受），照这一场要读者看清什么来定，交代时说一句用了哪张的哪一条。")


class CardError(Exception):
    pass


def default_library():
    return Path(__file__).resolve().parents[1] / "assets" / "style-cards" / "cards.json"


def read_json(path, what):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise CardError(what + " not found: " + str(path)) from exc
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise CardError(what + " is not readable JSON: " + str(exc)) from exc


def is_phrases(value, empty_ok=True):
    return isinstance(value, list) and (empty_ok or value) and all(isinstance(x, str) and x.strip() for x in value)


def library_problems(data):
    if not isinstance(data, dict) or data.get("format") != FORMAT:
        return ["format must be " + FORMAT]
    problems = []
    if data.get("format_version") != 2:
        problems.append("format_version must be 2 (card set 4.x with layers)")
    layers, cards, comp, glob = data.get("layers"), data.get("cards"), data.get("composition"), data.get("global")
    if not isinstance(layers, dict) or not layers or not isinstance(cards, list) or not cards:
        return problems + ["layers must be an object and cards a non-empty list"]
    if not isinstance(comp, dict) or not isinstance(comp.get("max_per_layer"), dict) \
            or set(comp["max_per_layer"]) != set(layers) \
            or not all(isinstance(n, int) and n >= 1 for n in comp["max_per_layer"].values()) \
            or sorted(comp.get("precedence") or []) != sorted(layers):
        problems.append("composition must give max_per_layer for every layer and a precedence over the layers")
    if not isinstance(glob, dict) or not is_phrases(glob.get("blacklist")) or not is_phrases(glob.get("blacklist_patterns")) \
            or not isinstance(glob.get("example_policy"), str):
        problems.append("global must have blacklist, blacklist_patterns and example_policy")
    seen, names = set(), {}
    for index, card in enumerate(cards):
        where = "cards[%d]" % index
        if not isinstance(card, dict):
            problems.append(where + " is not an object")
            continue
        cid = card.get("id")
        where = cid if isinstance(cid, str) else where
        missing = [f for f in CARD_FIELDS if f not in card]
        extra = sorted(set(card) - set(CARD_FIELDS))
        if missing:
            problems.append(where + ": missing " + ", ".join(missing))
            continue
        if extra:
            problems.append(where + ": unknown fields " + ", ".join(extra))
        if not isinstance(cid, str) or not ID.match(cid):
            problems.append(where + ": id must be lowercase words joined by hyphens")
        for name in [cid] + (card["aliases"] if isinstance(card["aliases"], list) else []):
            if name in names:
                problems.append(where + ": id or alias %s is used twice" % name)
            names[name] = cid
        if card["layer"] not in layers:
            problems.append(where + ": layer must be one of " + ", ".join(layers))
        if not (isinstance(card["name"], str) and card["name"].strip()):
            problems.append(where + ": name must be text")
        if not is_phrases(card["scene_triggers"], empty_ok=False):
            problems.append(where + ": scene_triggers must be a non-empty list of phrases")
        for field in ("lexical_shifts", "kinetic_verbs"):
            table = card[field]
            if not isinstance(table, dict) or not all(isinstance(k, str) and k.strip() and isinstance(v, str) and v.strip()
                                                      for k, v in table.items()):
                problems.append(where + ": " + field + " must map a phrase to its example")
        syntax = card["syntax_metrics"]
        if not isinstance(syntax, dict) or not SYNTAX_FIELDS <= set(syntax) or not set(syntax) <= SYNTAX_FIELDS | {"register_markers"}:
            problems.append(where + ": syntax_metrics must have avg_clause_length, sentence_final_particles, punctuation")
        else:
            if not isinstance(syntax["avg_clause_length"], str):
                problems.append(where + ": avg_clause_length must be text such as 5-11")
            for field in ("sentence_final_particles", "punctuation", "register_markers"):
                if field in syntax and not is_phrases(syntax[field]):
                    problems.append(where + ": " + field + " must be a list of strings")
        for field in ("aliases", "blacklist", "blacklist_patterns", "conflicts_with"):
            if not is_phrases(card[field]):
                problems.append(where + ": " + field + " must be a list of strings")
        if not isinstance(card["overrides"], dict):
            problems.append(where + ": overrides must be an object")
        sections = card["sections"]
        if not isinstance(sections, dict) or set(sections) != set(SECTIONS) or not all(isinstance(v, str) for v in sections.values()):
            problems.append(where + ": sections must have " + ", ".join(SECTIONS))
        elif not sections["subtext_logic"].strip():
            problems.append(where + ": subtext_logic (how the scene is organised) is empty")
        seen.add(cid)
    for card in cards:
        if isinstance(card, dict) and is_phrases(card.get("conflicts_with")):
            for other in card["conflicts_with"]:
                if other not in seen:
                    problems.append("%s: conflicts_with names a card that is not in the library: %s" % (card.get("id"), other))
    return problems


def load_library(path):
    data = read_json(path, "card library")
    problems = library_problems(data)
    if problems:
        raise CardError("card library has problems: " + "; ".join(problems[:5]))
    return data


def resolve(data, name):
    for card in data["cards"]:
        if card["id"] == name or name in card["aliases"]:
            return card
    return None


def config_report(config, data):
    """Problems and notices of a book's config against the library."""
    problems, notices = [], []
    if not isinstance(config, dict) or config.get("format") != CONFIG_FORMAT:
        return ["format must be " + CONFIG_FORMAT], notices
    if config.get("format_version") != 1:
        problems.append("format_version must be 1")
    extra = sorted(set(config) - CONFIG_FIELDS)
    if extra:
        problems.append("unknown fields: " + ", ".join(extra))
    ids = {c["id"] for c in data["cards"]}
    keywords = config.get("keywords", {})
    exclude = config.get("exclude", [])
    default = config.get("default_card")
    if not isinstance(keywords, dict):
        problems.append("keywords must map a card id to a list of words")
        keywords = {}
    if not (isinstance(exclude, list) and all(isinstance(x, str) for x in exclude)):
        problems.append("exclude must be a list of card ids")
        exclude = []
    owners = {}
    for cid, words in keywords.items():
        if cid not in ids:
            card = resolve(data, cid)
            problems.append("keywords point to a card that is not in the library: " + cid
                            + (" (it is an alias of %s; write the card id)" % card["id"] if card else ""))
        if cid in exclude:
            problems.append("keywords point to a card the book excludes: " + cid)
        if not is_phrases(words, empty_ok=False):
            problems.append("keywords for " + cid + " must be a non-empty list of words")
            continue
        for word in words:
            owners.setdefault(word, []).append(cid)
    for word, cards in sorted(owners.items()):
        if len(cards) > 1:
            notices.append("the word %s points to %d cards: %s" % (word, len(cards), ", ".join(cards)))
    for cid in exclude:
        if cid not in ids:
            problems.append("exclude names a card that is not in the library: " + cid)
    if default is not None:
        if not isinstance(default, str) or default not in ids:
            problems.append("default_card is not a card in the library: " + str(default))
        elif default in exclude:
            problems.append("default_card is excluded by the same config: " + default)
    fixed = config.get("fixed_base_card")
    if fixed is not None:
        card = next((c for c in data["cards"] if c["id"] == fixed), None) if isinstance(fixed, str) else None
        if card is None:
            problems.append("fixed_base_card is not a card in the library: " + str(fixed))
        elif card["layer"] != BASE_LAYER:
            problems.append("fixed_base_card must be a base-layer card: %s is a %s card" % (fixed, card["layer"]))
        elif fixed in exclude:
            problems.append("fixed_base_card is excluded by the same config: " + fixed)
    return problems, notices


def load_config(path, data):
    if path is None:
        return None
    config = read_json(path, "book config")
    problems, _ = config_report(config, data)
    if problems:
        raise CardError("book config has problems: " + "; ".join(problems[:5]))
    return config


def usable_cards(data, config):
    excluded = set((config or {}).get("exclude", []))
    return [c for c in data["cards"] if c["id"] not in excluded]


def phrase_parts(card):
    parts = []
    for trigger in card["scene_triggers"]:
        for piece in [trigger] + SPLIT.split(trigger):
            piece = piece.strip()
            if len(piece) >= 2 and piece not in parts:
                parts.append(piece)
    return parts


def match(data, config, text, top=5):
    keywords = (config or {}).get("keywords", {})
    rows = []
    for card in usable_cards(data, config):
        words = [w for w in keywords.get(card["id"], []) if w in text]
        phrases = [p for p in phrase_parts(card) if p in text]
        if words or phrases:
            rows.append({"id": card["id"], "name": card["name"], "layer": card["layer"], "book_keywords": words,
                         "scene_phrases": phrases})
    rows.sort(key=lambda r: (-len(r["book_keywords"]), -len(r["scene_phrases"]), r["id"]))
    default = (config or {}).get("default_card")
    return {"hits": rows[:top], "more": max(0, len(rows) - top), "default_card": default if not rows else None,
            "fixed_base_card": (config or {}).get("fixed_base_card"), "note": NOT_DECIDED}


def index_rows(data, config, layer=None):
    keywords = (config or {}).get("keywords", {})
    rows = []
    for card in usable_cards(data, config):
        if layer and card["layer"] != layer:
            continue
        row = {"id": card["id"], "name": card["name"], "layer": card["layer"], "domain": card["domain"],
               "scene_triggers": card["scene_triggers"]}
        if card["aliases"]:
            row["aliases"] = card["aliases"]
        if card["conflicts_with"]:
            row["conflicts_with"] = card["conflicts_with"]
        if keywords.get(card["id"]):
            row["book_keywords"] = keywords[card["id"]]
        rows.append(row)
    return rows


def limits_text(data):
    m = data["composition"]["max_per_layer"]
    return "、".join("%s %d 张" % (key, m[key]) for key in data["layers"])


def index_text(data, config, layer=None):
    rows = index_rows(data, config, layer)
    head = ["风格卡索引（%d 张）。识别由写的人做：对照这一场要读者经历什么、这本书的题材和口吻，每一层挑一张或者不挑"
            "（最多 %s），对不上就不加载。办法见 references/style-cards.md。" % (len(rows), limits_text(data)), INDEX_DOMAIN]
    if config:
        excluded = config.get("exclude", [])
        if excluded:
            head.append("本书不用：" + "、".join(excluded))
        if config.get("default_card"):
            head.append("本书对不上时默认加载：%s（作者定的）" % config["default_card"])
        if config.get("fixed_base_card"):
            head.append(FIXED_HEAD % config["fixed_base_card"])
    lines = head
    for key, label in data["layers"].items():
        group = [r for r in rows if r["layer"] == key]
        if not group:
            continue
        lines.append("")
        lines.append("## %s · %s（%d）" % (key, label, len(group)))
        for r in group:
            extra = ""
            if r.get("aliases"):
                extra += "｜又名：" + "、".join(r["aliases"])
            if r.get("conflicts_with"):
                extra += "｜不和这几张同用：" + "、".join(r["conflicts_with"])
            if r.get("book_keywords"):
                extra += "｜本书关键词：" + "、".join(r["book_keywords"])
            lines.append("- %s｜%s｜题材：%s｜%s%s" % (r["id"], r["name"], r["domain"], "；".join(r["scene_triggers"]), extra))
    return "\n".join(lines) + "\n"


def clause_range(value):
    found = re.fullmatch(r"\s*(\d+)\s*[-–—~～]\s*(\d+)\s*", value)
    return "%s—%s" % found.groups() if found else value


def is_punct(item):
    return all(ch in PUNCT for ch in item)


def choose(data, config, names):
    """The cards to load, in the card set's precedence; refuses more than a layer allows and conflicting pairs."""
    if not names:
        raise CardError("name the cards to load")
    excluded = set((config or {}).get("exclude", []))
    cards = []
    for name in names:
        card = resolve(data, name)
        if card is None:
            close = [c["id"] for c in data["cards"] if name and (name in c["id"] or c["id"].split("-")[0] == name.split("-")[0])]
            raise CardError("no card " + name + (" (close: " + ", ".join(close[:5]) + ")" if close else ""))
        if card["id"] in excluded:
            raise CardError("the book config excludes this card: " + card["id"])
        if card in cards:
            raise CardError("the card is named twice: " + card["id"])
        cards.append(card)
    limits = data["composition"]["max_per_layer"]
    for layer, label in data["layers"].items():
        chosen = [c["id"] for c in cards if c["layer"] == layer]
        if len(chosen) > limits[layer]:
            raise CardError("at most %d %s card(s) at a time (%s): %s" % (limits[layer], layer, label, ", ".join(chosen)))
    ids = {c["id"] for c in cards}
    for card in cards:
        clash = [x for x in card["conflicts_with"] if x in ids]
        if clash:
            raise CardError("%s does not go together with %s (conflicts_with)" % (card["id"], ", ".join(clash)))
    order = {layer: i for i, layer in enumerate(data["composition"]["precedence"])}
    return sorted(cards, key=lambda c: (order[c["layer"]], names.index(c["id"]) if c["id"] in names else 0))


def with_fixed_base(data, config, names, use_fixed=True):
    """The names to hand to choose(): the book's fixed base card joins when none of the named cards is a base card.
    Returns (names, added, passed_over): the card added, or the named base card that stands in its place."""
    names = list(names)
    fixed = (config or {}).get("fixed_base_card") if use_fixed else None
    if not fixed:
        return names, None, None
    named_base = [c["id"] for c in (resolve(data, n) for n in names) if c is not None and c["layer"] == BASE_LAYER]
    if named_base:
        return names, None, (named_base[0] if fixed not in named_base else None)
    return names + [fixed], fixed, None


def pick(data, config, names, use_fixed=True):
    """choose() on the names with the fixed base card filled in; (cards, added, passed_over)."""
    names, added, passed_over = with_fixed_base(data, config, names, use_fixed)
    try:
        cards = choose(data, config, names)
    except CardError as exc:
        fixed = resolve(data, added) if added else None
        others = [resolve(data, n) for n in names[:-1]] if added else []
        if fixed and any(o is not None and (o["id"] in fixed["conflicts_with"] or fixed["id"] in o["conflicts_with"])
                         for o in others):
            raise CardError(str(exc) + "; " + FIXED_CLASH % added) from exc
        raise
    return cards, added, passed_over


def examples(card):
    """(where, text) of every example in a card: table values, quoted examples in its sections, the model passage."""
    out = []
    for field in ("lexical_shifts", "kinetic_verbs"):
        for plain, example in card[field].items():
            out += [(field + "：" + plain, way.strip()) for way in example.split(ALT) if way.strip()]
    for key in ("lexical_map", "kinetic_verbs_text", "somatosensory", "subtext_logic", "syntax_rhythm"):
        for m in QUOTED.finditer(card["sections"][key]):
            out.append((key, m.group(1) or m.group(2)))
    if card["sections"]["example_after"]:
        out.append(("example_after", card["sections"]["example_after"]))
    return out


def opposite_words(card):
    return list(card["blacklist"])


def opposite_patterns(card):
    """The card's blacklist_patterns that compile; a pattern that does not is skipped, not an error."""
    out = []
    for pattern in card["blacklist_patterns"]:
        try:
            out.append((pattern, re.compile(pattern)))
        except (re.error, OverflowError, RecursionError, TypeError, ValueError):
            continue
    return out


def clashes(way, own, opposite, patterns):
    """True when an example of card `own` holds another loaded card's opposite word or matches its pattern."""
    for word, owners in opposite.items():
        if word in way and any(o != own for o in owners):
            return True
    for compiled, owners in patterns.values():
        if any(o != own for o in owners):
            try:
                if compiled.search(way):
                    return True
            except (RecursionError, re.error):
                continue
    return False


def global_opposites(data, allowed):
    """The card set's global opposite words minus the terms the loaded cards open up, and its patterns that compile."""
    glob = data["global"]
    words = [w for w in glob["blacklist"] if w not in allowed]
    patterns = []
    for pattern in glob["blacklist_patterns"]:
        try:
            patterns.append(re.compile(pattern))
        except (re.error, OverflowError, RecursionError, TypeError, ValueError):
            continue
    return words, patterns


def global_clash(way, words, patterns, allowed):
    """True when an example holds a global opposite word, or a stretch a global pattern matches that is not one of the
    opened-up terms (or inside one, or around one)."""
    if any(word in way for word in words):
        return True
    for compiled in patterns:
        try:
            for found in compiled.finditer(way):
                piece = found.group(0)
                if piece and not any(piece in term or term in piece for term in allowed):
                    return True
        except (RecursionError, re.error):
            continue
    return False


def render(data, cards, examples=False, fixed_note=None):
    """The chosen cards as directions. examples=True also prints the example tables and the model passage; what a voice
    looks like when overdone is left to review()."""
    glob = data["global"]
    allowed = set()
    translationese = glob.get("forbid_translationese", False)
    adverbs = glob.get("forbid_consecutive_adverbs", False)
    for card in cards:
        over = card["overrides"]
        allowed.update(over.get("allow_global_terms") or [])
        if over.get("forbid_translationese") is False:
            translationese = False
        if over.get("forbid_consecutive_adverbs") is False:
            adverbs = False
    title = "、".join("%s（%s，%s）" % (c["name"], c["id"], c["layer"]) for c in cards)
    lines = ["# 风格卡：" + title, "", DIRECTIONS, WITH_EXAMPLES if examples else ONLY_DIRECTIONS, ""]
    if fixed_note:
        lines += [fixed_note, ""]
    if len(cards) > 1:
        lines += [TOGETHER_HEAD % " > ".join(data["composition"]["precedence"])
                  + (TOGETHER_MARKS if examples else TOGETHER_COUNTED), TOGETHER, ""]
    lines += ["卡组的示例规则：" + glob["example_policy"]]
    if translationese:
        lines.append("全卡组的方向：少用翻译腔。")
    if adverbs:
        lines.append("全卡组的方向：不连用副词。")
    words = [w for w in glob["blacklist"] if w not in allowed]
    if words:
        lines.append("全卡组相反的写法（心里有数，不是禁词表，人物台词里该有的照有）：" + "、".join(words))
    if glob["blacklist_patterns"]:
        lines.append(GLOBAL_PATTERNS % len(glob["blacklist_patterns"]))
    if allowed:
        lines.append("这几张卡放开的：" + "、".join(sorted(allowed)))
    g_words, g_patterns = global_opposites(data, allowed)
    marked = 0
    opposite, patterns = {}, {}
    for card in cards:
        for word in opposite_words(card):
            opposite.setdefault(word, []).append(card["id"])
        for pattern, compiled in opposite_patterns(card):
            patterns.setdefault(pattern, (compiled, []))[1].append(card["id"])
    for card in cards:
        s = card["sections"]
        lines += ["", "## %s（%s · %s）" % (card["name"], card["id"], data["layers"][card["layer"]]), "",
                  "适用场景：" + "；".join(card["scene_triggers"])]
        for key, title_ in (("subtext_logic", "叙述逻辑"), ("lexical_map", "名词"), ("kinetic_verbs_text", "动作"),
                            ("somatosensory", "感官（可挑的料）")):
            if s[key].strip():
                lines += ["", "### " + title_, "", s[key].strip()]
        syntax = card["syntax_metrics"]
        lines += ["", "### 句子", "", CLAUSE_LINE % clause_range(syntax["avg_clause_length"]), DIALOGUE_LINE]
        particles = [p for p in syntax["sentence_final_particles"] if not is_punct(p)]
        punctuation = list(syntax["punctuation"]) + [p for p in syntax["sentence_final_particles"]
                                                     if is_punct(p) and p not in syntax["punctuation"]]
        if particles:
            lines.append("- 常用语气词：" + "、".join(particles))
        if syntax.get("register_markers"):
            lines.append("- 常见的口头字眼：" + "、".join(syntax["register_markers"]))
        if punctuation:
            lines.append("- 常用标点：" + " ".join(punctuation))
        if s["syntax_rhythm"].strip():
            lines += [s["syntax_rhythm"].strip()]
        for field, title_ in (("lexical_shifts", "腔调示例（示意，不搬进正文，不是替换表）"),
                              ("kinetic_verbs", "动作示例（示意，不搬进正文，不是替换表）")):
            table = card[field]
            if not table:
                continue
            if examples:
                lines += ["", "### " + title_, ""]
            for plain, example in table.items():
                ways = [w.strip() for w in example.split(ALT) if w.strip()]
                note = CLASH_MARK if any(clashes(w, card["id"], opposite, patterns) for w in ways) else ""
                if any(global_clash(w, g_words, g_patterns, allowed) for w in ways):
                    note += GLOBAL_MARK
                if note:
                    marked += 1
                if examples:
                    lines.append("- 平常写“%s”的地方，这种腔调大概是：%s%s" % (plain, "；或者：".join(ways), note))
        if examples and s["example_before"] and s["example_after"]:
            lines += ["", "### 示范（只示意改的方向，不搬进正文）", "", "改写前：" + s["example_before"], "",
                      "改写后：" + s["example_after"]]
        if card["blacklist"]:
            lines += ["", "### 跟这种腔调相反的写法（心里有数，不是禁词表）", "", "、".join(card["blacklist"])]
        if card["blacklist_patterns"]:
            lines.append("（另有 %d 条句式写在卡片库的 blacklist_patterns 里，同样只是心里有数）" % len(card["blacklist_patterns"]))
    if marked and not examples:
        lines += ["", MARKS_COUNTED % marked]
    return "\n".join(lines) + "\n"


def review(data, cards):
    """What each chosen card says the voice looks like when overdone, to read the finished scene against."""
    return {"cards": [{"id": c["id"], "name": c["name"], "layer": c["layer"], "overuse": c["sections"]["overuse"]}
                      for c in cards], "note": REVIEW_NOTE}


def review_text(data, result, fixed_note=None):
    lines = ["# 风格卡写完核对：" + "、".join("%s（%s，%s）" % (r["name"], r["id"], r["layer"]) for r in result["cards"]), "",
             result["note"]]
    if fixed_note:
        lines += ["", fixed_note]
    for r in result["cards"]:
        lines += ["", "## %s（%s · %s）" % (r["name"], r["id"], data["layers"][r["layer"]]), "",
                  "写过头是什么样：" + (r["overuse"].strip() or REVIEW_EMPTY)]
    return "\n".join(lines) + "\n"


def copied(cards, text, least=4):
    """Stretches of the cards' examples that stand word for word in the text (four Chinese characters or more, the
    longest first; overlapping finds of one example are reported once)."""
    found = []
    for card in cards:
        for where, source in examples(card):
            taken = []
            n = len(source)
            for i in range(n):
                for j in range(n, i, -1):
                    piece = source[i:j]
                    if len(HAN.findall(piece)) < least:
                        break
                    if piece in text:
                        if not any(piece in t for t in taken):
                            taken.append(piece)
                        break
            for piece in taken:
                found.append({"card": card["id"], "where": where, "text": piece})
    return found


def common_phrase(piece):
    """The COMMON_FOUR entry a find is, once the punctuation and spaces at both ends are off (the entry alone, or the
    entry and one of 的地得了着 after it); None when the find holds anything more."""
    core = piece.strip("".join(PUNCT) + " \t\r\n　")
    if not core or len(HAN.findall(core)) != len(core):
        return None
    if core in COMMON_FOUR:
        return core
    if len(core) == 5 and core[:4] in COMMON_FOUR and core[4] in TAIL_PARTICLES:
        return core[:4]
    return None


def copied_report(cards, text):
    """copied() split three ways: found (taken wording), exempt (a common four-character phrase only) and hints (a
    three-character name from a loaded card's examples that stands in the text and no find of that card holds)."""
    found, exempt, hints = [], [], []
    for find in copied(cards, text):
        (exempt if common_phrase(find["text"]) else found).append(find)
    named = set()
    for card in cards:
        scope = "\n".join(source for _, source in examples(card))
        for name in SHORT_NAMES.get(card["id"], ()):
            if name in named or name not in scope or name not in text:
                continue
            if any(name in f["text"] for f in found if f["card"] == card["id"]):
                continue
            hints.append({"card": card["id"], "text": name})
            named.add(name)
    return {"found": found, "exempt": exempt, "hints": hints}


def copied_text(result, fixed_note=None):
    found, exempt, hints = result["found"], result["exempt"], result["hints"]
    if found:
        out = ("".join("- %s %s：%s\n" % (f["card"], f["where"], f["text"]) for f in found)
               + "这些是卡里示例的原话，照搬进了正文：改成这一场自己的说法，或者写明为什么保留。\n")
    else:
        out = "正文里没有照搬卡里示例的原话（四个汉字以上）。这只查字面，不说明腔调用得好不好。\n"
    if hints:
        out += COPIED_HINTS % "、".join("%s（%s）" % (h["text"], h["card"]) for h in hints) + "\n"
    if exempt:
        phrases = list(dict.fromkeys(common_phrase(f["text"]) for f in exempt))
        out += COPIED_EXEMPT % (len(exempt), "、".join(phrases)) + "\n"
    if fixed_note:
        out += fixed_note + "\n"
    return out


def read_text(args):
    parts = [args.text] if getattr(args, "text", None) else []
    for path in args.file or []:
        try:
            parts.append(Path(path).read_bytes().decode("utf-8-sig"))
        except (OSError, UnicodeDecodeError) as exc:
            raise CardError("cannot read " + str(path) + ": " + str(exc)) from exc
    if not "".join(parts).strip():
        raise CardError("give the scene task or the text with --text or --file")
    return "\n".join(parts)


def match_text(result):
    lines = []
    if not result["hits"]:
        lines.append("没有字面命中。")
        if result["default_card"]:
            lines.append("本书设定了对不上时默认加载 %s（作者定的）：对照索引判断还是对不上，就加载它。" % result["default_card"])
    for r in result["hits"]:
        bits = []
        if r["book_keywords"]:
            bits.append("本书关键词：" + "、".join(r["book_keywords"]))
        if r["scene_phrases"]:
            bits.append("适用场景里的说法：" + "、".join(r["scene_phrases"]))
        lines.append("- %s｜%s｜%s｜%s" % (r["id"], r["layer"], r["name"], "；".join(bits)))
    if result["more"]:
        lines.append("（另有 %d 张有零星命中，没列出）" % result["more"])
    if result.get("fixed_base_card"):
        lines.append(FIXED_HEAD % result["fixed_base_card"])
    lines.append(result["note"])
    return "\n".join(lines) + "\n"


def utf8_stdio():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = parser.add_subparsers(dest="command", required=True)
    commands = {}
    for name in ("index", "match", "load", "review", "copied", "check"):
        commands[name] = sub.add_parser(name)
        commands[name].add_argument("--library", type=Path, default=None, help="card library (default: assets/style-cards/cards.json)")
        commands[name].add_argument("--project", type=Path, default=None, help="the book's style-card config, if it has one")
    commands["index"].add_argument("--layer")
    commands["index"].add_argument("--format", choices=("text", "json"), default="text")
    commands["match"].add_argument("--text", help="the scene task, or text from the page")
    commands["match"].add_argument("--file", action="append", type=Path, help="text file to read (repeatable)")
    commands["match"].add_argument("--top", type=int, default=5)
    commands["match"].add_argument("--format", choices=("text", "json"), default="text")
    commands["load"].add_argument("card_ids", nargs="+")
    commands["load"].add_argument("--examples", action="store_true",
                                  help="also print the example tables and the model passage")
    commands["review"].add_argument("card_ids", nargs="+")
    commands["review"].add_argument("--format", choices=("text", "json"), default="text")
    commands["copied"].add_argument("card_ids", nargs="+")
    commands["copied"].add_argument("--file", action="append", type=Path, required=True, help="the draft (repeatable)")
    commands["copied"].add_argument("--format", choices=("text", "json"), default="text")
    for name in ("load", "review", "copied"):
        commands[name].add_argument("--no-fixed-base", action="store_true",
                                    help="leave out the book's fixed base card (fixed_base_card) for this scene")
    args = parser.parse_args()
    library = args.library or default_library()
    try:
        if args.command == "check":
            data = read_json(library, "card library")
            problems = library_problems(data)
            report = {"status": "PROBLEMS" if problems else "OK", "cards": len(data.get("cards", [])) if isinstance(data, dict) else 0,
                      "problems": problems}
            if args.project is not None and not problems:
                config_problems, notices = config_report(read_json(args.project, "book config"), data)
                report["config"] = {"problems": config_problems, "notices": notices}
                if config_problems:
                    report["status"] = "PROBLEMS"
            print(json.dumps(report, ensure_ascii=False, indent=1))
            return 1 if report["status"] != "OK" else 0
        data = load_library(library)
        config = load_config(args.project, data)
        if args.command == "index":
            if args.layer and args.layer not in data["layers"]:
                raise CardError("no layer " + args.layer + " (layers: " + ", ".join(data["layers"]) + ")")
            if args.format == "json":
                print(json.dumps(index_rows(data, config, args.layer), ensure_ascii=False, indent=1))
            else:
                print(index_text(data, config, args.layer), end="")
            return 0
        if args.command == "match":
            if args.top < 1:
                raise CardError("--top must be at least 1")
            result = match(data, config, read_text(args), args.top)
            print(json.dumps(result, ensure_ascii=False, indent=1) if args.format == "json" else match_text(result), end="")
            return 0
        cards, added, passed_over = pick(data, config, args.card_ids, use_fixed=not args.no_fixed_base)
        fixed_note = FIXED_ADDED % added if added else None
        if args.command == "review":
            result = review(data, cards)
            print(json.dumps(result, ensure_ascii=False, indent=1) if args.format == "json"
                  else review_text(data, result, fixed_note), end="")
            return 0
        if args.command == "copied":
            result = copied_report(cards, read_text(args))
            if args.format == "json":
                print(json.dumps(dict({"cards": [c["id"] for c in cards]}, **result), ensure_ascii=False, indent=1))
            else:
                print(copied_text(result, fixed_note), end="")
            return 0
        if passed_over:
            fixed_note = FIXED_PASSED % (passed_over, config["fixed_base_card"])
        print(render(data, cards, examples=args.examples, fixed_note=fixed_note), end="")
        return 0
    except CardError as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    sys.exit(main())

"""doctor: for each of the five components, whether the adapter is here (implemented) and whether this machine has what
it needs (configured). With --probe it also makes one small real request or call per component and says what came
back. live_verified is not decided here: it comes from verify-run on a real run.

r5.37: for Crawl4AI, "configured" only means the package imports; whether its browser starts shows in --probe (which
opens a local page) or in a collect run (pages browser_failed), and is reported as such.
"""
import importlib
import sys

from . import COMPONENTS, common
from .collect import crawl4ai_status
from .dedupe import imagehash_status
from .providers import openverse, searxng
from .rank import openclip_status

MODULES = {"searxng": "visual_materials.providers.searxng", "openverse": "visual_materials.providers.openverse",
           "crawl4ai": "visual_materials.collect", "imagehash": "visual_materials.dedupe",
           "openclip": "visual_materials.rank"}


def probe_search(module, config, fetch):
    record, found = module.search(config, ["test"], 1, fetch)
    return {"status": record["status"], "requests": [{k: r.get(k) for k in ("url", "http_status", "status", "error")}
                                                     for r in record.get("requests", [])], "results": len(found)}


def probe_crawl4ai(config):
    html = "raw:<html><body><img src='https://example.org/probe.png' alt='probe' width='400'></body></html>"
    from .collect import crawl_pages
    pages, version = crawl_pages([html], dict(config, crawl4ai=dict(config["crawl4ai"], check_robots_txt=False)))
    status = pages[0].get("status")
    return {"status": status, "browser_started": status != "browser_failed", "images": len(pages[0].get("images", [])),
            "version": version, "error": pages[0].get("error")}


def probe_imagehash():
    import imagehash
    from PIL import Image

    image = Image.new("RGB", (64, 64), (120, 80, 40))
    for x in range(32):
        image.putpixel((x, x), (250, 250, 250))
    return {"status": "ok", "phash": str(imagehash.phash(image)), "version": imagehash.__version__}


def probe_openclip(config):
    from .rank import OpenCLIPBackend
    backend = OpenCLIPBackend(config)
    vector = backend.text("a workshop")
    return {"status": "ok", "model": backend.info, "text_vector_length": len(vector)}


def run_doctor(config, config_path=None, probe=False, fetch=None):
    out = {}
    for name in COMPONENTS:
        try:
            importlib.import_module(MODULES[name])
            implemented = True
        except Exception as exc:  # noqa: BLE001
            implemented, why = False, str(exc)
        out[name] = {"implemented": implemented}
    ok, why = searxng.configured(config)
    out["searxng"].update(configured=ok, detail=why)
    ok, why = openverse.configured(config)
    out["openverse"].update(configured=ok, detail=why)
    ok, why, _ = crawl4ai_status()
    out["crawl4ai"].update(configured=ok, importable=ok, detail=why + ("; whether its browser starts shows with --probe "
                                                                     "or in a collect run" if ok else ""))
    ok, why, _ = imagehash_status()
    out["imagehash"].update(configured=ok, detail=why)
    status, why, versions = openclip_status(config)
    out["openclip"].update(configured=status == "ready", detail=why, state=status, versions=versions)
    try:
        import PIL
        pillow = "Pillow %s" % PIL.__version__
    except ImportError:
        pillow = "Pillow is not installed: images cannot be decoded (pip install Pillow)"
    if probe:
        for name in COMPONENTS:
            if not out[name]["configured"]:
                out[name]["probe"] = {"status": "skipped", "why": "not configured"}
                continue
            try:
                if name in ("searxng", "openverse"):
                    out[name]["probe"] = probe_search(searxng if name == "searxng" else openverse, config, fetch)
                elif name == "crawl4ai":
                    out[name]["probe"] = probe_crawl4ai(config)
                elif name == "imagehash":
                    out[name]["probe"] = probe_imagehash()
                else:
                    out[name]["probe"] = probe_openclip(config)
            except Exception as exc:  # noqa: BLE001 - the probe reports, it does not crash
                out[name]["probe"] = {"status": "error", "error": "%s: %s" % (type(exc).__name__, exc)}
    for name in COMPONENTS:
        out[name]["live_verified"] = "decided by verify-run on a real run, not by doctor"
    ready = [n for n in COMPONENTS if out[n]["configured"]]
    return {"schema": "visual-doctor/1", "python": "%d.%d.%d" % sys.version_info[:3], "config": str(config_path or ""),
            "pillow": pillow, "review": {"mode": config["review"].get("mode", "host"),
                                         "note": "看图靠宿主助手打开图片文件，或作者自己看；命令行自己看不到图"},
            "components": out, "configured": ready,
            "summary": "五项都配置好了" if len(ready) == len(COMPONENTS) else "还没配置好：%s" % "、".join(
                n for n in COMPONENTS if n not in ready),
            "offline_writing": "写作、审稿和灵感库的 check/list/card 不需要这五项，照常能用"}

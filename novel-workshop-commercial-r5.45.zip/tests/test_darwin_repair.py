#!/usr/bin/env python3
"""CLI regressions for sealed, complete and independent Darwin comparisons."""

import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
TOOL = ROOT / "skills" / "darwin-novel-workshop" / "scripts" / "darwin_eval.py"


class DarwinRepair(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.dir = Path(self.temp.name)
        self.work = self.dir / "evaluation"
        self.registry = {
            "tasks": [{"id": "dev1", "split": "dev"}, {"id": "hold1", "split": "holdout"}],
            "dimensions": [{"id": "facts", "hard": True}, {"id": "readability", "hard": False}],
        }
        self.write_registry()
        self.write(self.dir / "baseline" / "SKILL.md", "保留原稿事实。")
        self.write(self.dir / "candidate" / "SKILL.md", "保留原稿事实，逐条核对改动。")
        self.write(self.dir / "baseline-output.md", "雨停了。沈七把钥匙放回桌上。")
        self.write(self.dir / "candidate-output.md", "窗外雨停了。沈七把钥匙放回桌上。")
        self.cli("freeze", "--baseline", self.dir / "baseline", "--candidate", self.dir / "candidate")

    @staticmethod
    def write(path, text):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes((text).encode("utf-8"))

    def write_registry(self):
        self.write(self.work / "TASKS.json", json.dumps(self.registry, ensure_ascii=False, indent=2))

    def cli(self, command, *args, code=0):
        result = subprocess.run([sys.executable, "-I", "-B", str(TOOL), command, str(self.work),
                                 *map(str, args)], capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(result.returncode, code, result.stdout + result.stderr)
        self.assertEqual(result.stderr, "")
        return json.loads(result.stdout)

    def blind(self, task="hold1"):
        return self.cli("blind", "--task", task,
                        "--baseline-output", self.dir / "baseline-output.md",
                        "--candidate-output", self.dir / "candidate-output.md", "--seed", "7")

    def verdict_file(self, task, mode, dimensions):
        mapping = json.loads((self.work / "sealed" / (task + ".mapping.json")).read_text(encoding="utf-8"))["mapping"]
        labels = {arm: label for label, arm in mapping.items()}
        # This is a mechanical fixture, not a real literary blind evaluation.
        verdict = {"task": task, "judge": {"mode": mode, "label": "regression-fixture"},
                   "dimensions": {dimension: {"result": labels.get(result, result),
                                              "evidence": "沈七把钥匙放回桌上。"}
                                  for dimension, result in dimensions.items()}}
        path = self.dir / (task + ".verdict-input.json")
        self.write(path, json.dumps(verdict, ensure_ascii=False))
        return path

    def judge(self, task="hold1", mode="independent_agent", dimensions=None):
        self.blind(task)
        path = self.verdict_file(task, mode, dimensions if dimensions is not None else {
            "facts": "tie", "readability": "candidate"})
        self.cli("verdict", "--task", task, "--file", path)
        self.cli("unblind", "--task", task)

    def assert_insufficient(self):
        report = self.cli("summarize")
        self.assertTrue(report["decision"].startswith("INSUFFICIENT_EVIDENCE"), report)
        self.assertEqual(report["integrity"]["status"], "OK")
        return report

    def test_complete_independent_holdout_can_report_limited_improvement(self):
        self.judge()
        report = self.cli("summarize")
        # Merged decision name: only independent verdicts on held-out tasks are counted.
        self.assertTrue(report["decision"].startswith("CANDIDATE_BETTER_ON_HELD_OUT_TASKS"), report)
        self.assertEqual(report["holdout_hard_gaps"], [])
        self.assertEqual(report["holdout_tasks_independently_judged"], 1)
        self.assertEqual(report["author"]["verdict"], "pending")

    def test_omitted_holdout_hard_dimension_blocks_optimistic_summary(self):
        self.judge(dimensions={"readability": "candidate"})
        report = self.assert_insufficient()
        self.assertIn({"task": "hold1", "dimension": "facts", "reason": "untested"}, report["holdout_hard_gaps"])

    def test_untested_holdout_hard_dimension_blocks_optimistic_summary(self):
        self.judge(dimensions={"facts": "untested", "readability": "candidate"})
        self.assert_insufficient()

    def test_insufficient_holdout_hard_dimension_blocks_optimistic_summary(self):
        self.judge(dimensions={"facts": "insufficient", "readability": "candidate"})
        self.assert_insufficient()

    def test_every_registered_holdout_needs_its_hard_verdicts(self):
        self.registry["tasks"].append({"id": "hold2", "split": "holdout"})
        self.write_registry()
        self.judge("hold1")
        report = self.assert_insufficient()
        self.assertTrue(any(item["task"] == "hold2" for item in report["holdout_hard_gaps"]))

    def test_self_check_never_satisfies_independent_holdout_gate(self):
        self.judge(mode="self_check")
        report = self.assert_insufficient()
        self.assertEqual(report["holdout_tasks_independently_judged"], 0)
        self.assertEqual(report["improved"], 0)

    def test_self_check_improvements_are_excluded_from_comparison(self):
        self.judge("dev1", mode="self_check", dimensions={"facts": "candidate", "readability": "candidate"})
        self.judge("hold1", dimensions={"facts": "tie", "readability": "tie"})
        report = self.cli("summarize")
        self.assertEqual(report["improved"], 0)
        self.assertTrue(report["decision"].startswith("NO_CLEAR_IMPROVEMENT"), report)

    def test_hard_holdout_regression_cannot_be_outvoted(self):
        self.judge("dev1", dimensions={"facts": "candidate", "readability": "candidate"})
        self.judge("hold1", dimensions={"facts": "baseline", "readability": "candidate"})
        report = self.cli("summarize")
        # Across all judged dimensions improvements outnumber regressions (the merged summary reports
        # held-out and development tallies separately) -- and the held-out hard regression still decides.
        improved = report["holdout"]["improved"] + report["dev"]["improved"]
        regressed = report["holdout"]["regressed"] + report["dev"]["regressed"]
        self.assertGreater(improved, regressed)
        self.assertTrue(report["decision"].startswith("KEEP_BASELINE"), report)

    def test_no_revealed_holdout_is_insufficient(self):
        self.judge("dev1")
        self.assert_insufficient()

    def test_tasks_can_be_authored_after_skill_freeze_before_first_blind(self):
        self.registry["tasks"].append({"id": "hold_after_freeze", "split": "holdout"})
        self.write_registry()
        self.assertFalse((self.work / "TASKS.FROZEN.json").exists())
        self.blind("hold_after_freeze")
        frozen = json.loads((self.work / "TASKS.FROZEN.json").read_text(encoding="utf-8"))
        self.assertEqual(frozen["frozen_at_stage"], "first_blind")
        self.assertTrue(frozen["frozen_at"])
        self.assertEqual(frozen["registry"], self.registry)
        self.assertEqual(self.cli("verify")["status"], "OK")

    def test_tasks_registry_changes_after_first_blind_are_compromised(self):
        self.judge()
        self.registry["dimensions"][0]["hard"] = False
        self.registry["tasks"][1]["split"] = "dev"
        self.write_registry()
        self.assertEqual(self.cli("verify")["status"], "COMPROMISED")
        report = self.cli("summarize", code=2)
        self.assertTrue(report["decision"].startswith("BLOCKED_INTEGRITY"), report)
        self.assertEqual(report["integrity"]["status"], "COMPROMISED")

    def test_actual_packet_mutation_blocks_verdict_and_summary(self):
        self.blind()
        verdict = self.verdict_file("hold1", "independent_agent", {"facts": "tie", "readability": "candidate"})
        self.write(self.work / "packets" / "hold1" / "A.md", "评审者看到的正文已被替换。")
        self.assertEqual(self.cli("verify")["status"], "COMPROMISED")
        self.assertEqual(self.cli("verdict", "--task", "hold1", "--file", verdict, code=2)["status"], "BLOCKED")
        self.assertFalse((self.work / "verdicts" / "hold1.json").exists())
        self.assertEqual(self.cli("summarize", code=2)["status"], "BLOCKED")

    def test_actual_packet_deletion_is_compromised(self):
        self.judge()
        (self.work / "packets" / "hold1" / "B.md").unlink()
        self.assertEqual(self.cli("verify")["status"], "COMPROMISED")
        self.assertEqual(self.cli("summarize", code=2)["status"], "BLOCKED")

    def test_skill_tree_mutation_blocks_positive_summary(self):
        self.judge()
        self.write(self.dir / "candidate" / "SKILL.md", "完成评审后偷偷改了规则。")
        report = self.cli("summarize", code=2)
        self.assertEqual(report["integrity"]["candidate"], "CHANGED")
        self.assertTrue(report["decision"].startswith("BLOCKED_INTEGRITY"), report)

    def test_mapping_mutation_blocks_unblind(self):
        self.blind()
        verdict = self.verdict_file("hold1", "independent_agent", {"facts": "tie"})
        self.cli("verdict", "--task", "hold1", "--file", verdict)
        self.write(self.work / "sealed" / "hold1.mapping.json", "{}")
        self.assertEqual(self.cli("unblind", "--task", "hold1", code=2)["status"], "BLOCKED")
        self.assertFalse((self.work / "revealed" / "hold1.json").exists())

    def test_missing_seals_log_is_compromised(self):
        self.judge()
        (self.work / "SEALS.log").unlink()
        report = self.cli("verify")
        self.assertEqual(report["status"], "COMPROMISED")
        self.assertTrue(any(item["reason"] == "required seal is missing" for item in report["broken"]))
        self.assertEqual(self.cli("summarize", code=2)["status"], "BLOCKED")

    def test_task_freeze_deletion_is_compromised(self):
        self.judge()
        (self.work / "TASKS.FROZEN.json").unlink()
        self.assertEqual(self.cli("verify")["status"], "COMPROMISED")
        self.assertEqual(self.cli("summarize", code=2)["status"], "BLOCKED")

    def test_duplicate_task_ids_are_rejected_before_packet_creation(self):
        self.registry["tasks"].append({"id": "hold1", "split": "dev"})
        self.write_registry()
        report = self.cli("blind", "--task", "hold1", "--baseline-output", self.dir / "baseline-output.md",
                          "--candidate-output", self.dir / "candidate-output.md", code=2)
        self.assertEqual(report["status"], "ERROR")
        self.assertFalse((self.work / "TASKS.FROZEN.json").exists())
        self.assertFalse((self.work / "packets").exists())


if __name__ == "__main__":
    unittest.main()

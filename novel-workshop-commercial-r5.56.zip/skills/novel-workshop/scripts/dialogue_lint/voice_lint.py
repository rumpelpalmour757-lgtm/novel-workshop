"""角色台词的字面数字和少量回读位置；数字和命中都不构成文学质量判定。

角色那一栏只给数字（台词数、分句数、平均分句长、口语标记命中数和命中率），不和任何线
比较，不给人物下结论。连续短句提示须显式开启；登记在 cold_protagonist_names 里的人物
（惜字的、常下令的）不做这项提示。
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Dict, Iterable, List, Mapping, Optional, Tuple

from dialogue_core import DialogueSpan, extract_dialogues
from genre_profiles import GenreLintProfile, normalize_scene_exemptions


@dataclass(frozen=True)
class VoiceprintProfile:
    """One registered character. Only the name is needed.

    ``archetype`` and ``voice_prompt`` are the author's own labels and notes;
    ``min_avg_len`` and ``min_colloquial_rate`` are kept so older configs still load,
    but nothing is compared with them any more.
    """
    name: str
    archetype: str = ''
    min_avg_len: Optional[float] = None
    min_colloquial_rate: Optional[float] = None
    voice_prompt: str = ''

    def __post_init__(self):
        if not isinstance(self.name, str) or not self.name:
            raise ValueError('角色名必须是非空字符串')
        if not isinstance(self.archetype, str) or not isinstance(self.voice_prompt, str):
            raise ValueError('archetype 和 voice_prompt 必须是字符串')
        for label, value, upper in (('min_avg_len', self.min_avg_len, None),
                                    ('min_colloquial_rate', self.min_colloquial_rate, 1)):
            if value is None:
                continue
            if (isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value)
                    or value < 0 or (upper is not None and value > upper)):
                raise ValueError(f'{label} 必须是有限非负数' + ('，且不大于 1' if upper else ''))


# Book-specific profiles are supplied by the selected project config.
VOICEPRINT_REGISTRY: Dict[str, VoiceprintProfile] = {}

# 只统计这些明示的字面线索；命中率不称为“活人味”的测量结果。
RE_COLLOQUIAL_MARKERS = re.compile(
    r'(?:不用|就行|就能|就算|不就|可别|先别|老实|胡乱|使劲|玩意儿?|家伙|哪能|总算|行了|得嘞|瞧瞧)'
    r'|先[^。！？；]{0,20}再'
    r'|[吧呢啊嘛哟喽呗哈呐](?=[，。！？；、\s]|$)'
)
RE_CLAUSE_SPLIT = re.compile(r'[，。！？；、,!?;]|…+|—+')
CONFIRMED_CONFIDENCE = frozenset({'explicit', 'manual'})
SHORT_RULE_ID = 'VOICE_SHORT_CLAUSES'
GENRE_SHORT_RULE_ID = 'COMP_02_IMPERATIVE_TRIPLE_CHOP'
NUMBERS_NOTE = '只是字面数字，给作者回读时对照用；不和任何线比较，不给人物下结论。待确认台词没有算进来。'

# 旧名字保留为记录类型别名，构造字段按共享逐引语接口执行。
DialogueLine = DialogueSpan


@dataclass
class VoiceLintIssue:
    para_index: int
    speaker: str
    rule_id: str
    quote: str
    reason: str
    rewrite_instruction: str
    severity: str = 'REVIEW'
    quote_id: str = ''
    quote_index: int = 0
    start: int = 0
    end: int = 0
    source_quote: str = ''
    confidence: str = 'unknown'
    matched_span: str = ''
    category: str = 'VOICE'
    name: str = ''


def extract_dialogues_with_speaker(
    paragraphs: List[str], *, registry: Optional[Mapping[str, VoiceprintProfile]] = None,
    aliases=None, speaker_overrides=None,
) -> List[DialogueSpan]:
    """保守提取每个引语；说话人和置信依据由共享解析器返回。"""
    profiles = VOICEPRINT_REGISTRY if registry is None else registry
    return extract_dialogues(paragraphs, tuple(profiles), aliases=aliases, speaker_overrides=speaker_overrides)


def _clauses(text: str) -> List[str]:
    return [c.strip() for c in RE_CLAUSE_SPLIT.split(text) if c.strip()]


def _issue(d: DialogueSpan, rule_id: str, name: str, reason: str, instruction: str,
           matched_span: str = '') -> VoiceLintIssue:
    return VoiceLintIssue(
        para_index=d.para_index, speaker=d.speaker, rule_id=rule_id,
        quote=d.quote, reason=reason, rewrite_instruction=instruction,
        quote_id=d.quote_id, quote_index=d.quote_index, start=d.start, end=d.end,
        source_quote=d.text, confidence=d.confidence, matched_span=matched_span, name=name,
    )


def analyze_voice_and_idioms(
    paragraphs: List[str], *, registry: Optional[Mapping[str, VoiceprintProfile]] = None,
    aliases=None, speaker_overrides=None, stress_speakers: Iterable[str] = (),
    include_style_hints: bool = False, min_profile_quotes: int = 3,
    genre_profile: Optional[GenreLintProfile] = None,
    style_exempt_quotes=(), cold_protagonist_names: Iterable[str] = (),
) -> Tuple[Dict[str, dict], List[VoiceLintIssue]]:
    """返回每个说话人的字面数字和要回去读的位置。

    explicit/manual 引语才计入数字；动作推断和未知单独计数。数字不和线比较，也不
    产生按人的状态。`stress_speakers` 由调用者确认当前受压角色，不能从“血、歪”
    等字面词推断。`cold_protagonist_names` 里的人物不做连续短句提示。没有发言的
    角色不生成虚构的零分报告。题材规则是显式启用规则的上限，不会开启
    include_style_hints；场景豁免只作用于 {quote_id: rule_ids} 中逐句明确列出的
    文风项，不影响角色数字或压力复核。
    """
    if isinstance(min_profile_quotes, bool) or not isinstance(min_profile_quotes, int) or min_profile_quotes < 1:
        raise ValueError('min_profile_quotes 必须是正整数')
    for label, names in (('stress_speakers', stress_speakers), ('cold_protagonist_names', cold_protagonist_names)):
        if isinstance(names, str):
            raise ValueError(f'{label} 请传角色名集合，而不是字符串')
    if genre_profile is not None and not isinstance(genre_profile, GenreLintProfile):
        raise ValueError('genre_profile 必须是 GenreLintProfile 或 None')
    style_exempt = normalize_scene_exemptions(style_exempt_quotes)
    stressed = frozenset(stress_speakers)
    terse = frozenset(cold_protagonist_names)
    markers = RE_COLLOQUIAL_MARKERS if genre_profile is None else genre_profile.colloquial_markers
    has_marker = (lambda text: bool(markers.search(text))) if genre_profile is None else genre_profile.has_colloquial_marker
    short_enabled = genre_profile is None or GENRE_SHORT_RULE_ID in genre_profile.enabled_rules
    profiles = VOICEPRINT_REGISTRY if registry is None else registry
    dialogues = extract_dialogues_with_speaker(
        paragraphs, registry=profiles, aliases=aliases, speaker_overrides=speaker_overrides,
    )
    grouped: Dict[str, List[DialogueSpan]] = {}
    for line in dialogues:
        grouped.setdefault(line.speaker, []).append(line)
    report: Dict[str, dict] = {}
    for speaker, all_lines in grouped.items():
        confirmed = [d for d in all_lines if d.confidence in CONFIRMED_CONFIDENCE]
        clauses = [c for d in confirmed for c in _clauses(d.text)]
        hits = sum(has_marker(d.text) for d in confirmed)
        report[speaker] = {
            '台词数': len(confirmed),
            '待确认台词数': len(all_lines) - len(confirmed),
            '分句数': len(clauses),
            '平均分句长': round(sum(len(c) for c in clauses) / len(clauses), 1) if clauses else None,
            '口语标记命中台词数': hits,
            '口语标记命中率': f'{hits / len(confirmed) * 100:.1f}%' if confirmed else None,
            '不做短句提示': speaker in terse,
            '指标说明': NUMBERS_NOTE,
        }
        if genre_profile is not None:
            report[speaker].update({
                '题材配置': genre_profile.genre_id,
                '口语标记来源': 'genre_profile.colloquial_markers',
                '有效口语标记': markers.pattern,
            })

    issues: List[VoiceLintIssue] = []
    for d in dialogues:
        profile = profiles.get(d.speaker)
        confirmed = d.confidence in CONFIRMED_CONFIDENCE
        clauses = _clauses(d.text)
        # 显式压力状态下，只有较长且信息密集的发言才给回读线索；不要求“嘶”或省略号。
        if confirmed and d.speaker in stressed and len(d.text) >= 32 and len(clauses) >= 3:
            issues.append(_issue(
                d, 'STRESS_SPEECH_REVIEW', '受压时的长台词',
                '调用者声明该角色正处于生理压力；此段较长，请核对其说话能力与当时动作。',
                '核对当前伤势、说话时机和信息必要性；允许清晰讲话。没有原文依据不添加痛呼、喘息、停顿或动作。',
            ))
        if (not include_style_hints or not short_enabled or not confirmed or profile is None
                or d.speaker in terse or GENRE_SHORT_RULE_ID in style_exempt.get(d.quote_id, ())):
            continue
        enough_samples = report[d.speaker]['台词数'] >= min_profile_quotes
        short_enough = bool(clauses) and (
            max(map(len, clauses)) <= 8 if genre_profile is None
            else sum(map(len, clauses)) / len(clauses) <= genre_profile.max_avg_clause_len
        )
        if enough_samples and d.text.count('。') >= 3 and len(clauses) >= 3 and short_enough and not has_marker(d.text):
            note = f'作者对这个人物的说明：{profile.voice_prompt} ' if profile.voice_prompt else ''
            issues.append(_issue(
                d, SHORT_RULE_ID, '连续短句', '命中连续短句复核线；可能是有意的命令、停顿或人物口吻。',
                f'结合上下文和作者认可的声音样本判断是否保留。{note}不以添加语气词或合并句号作为达标要求。',
            ))
    return report, issues


def build_surgical_patch_prompt(issues: List[VoiceLintIssue], *, paragraphs=None) -> str:
    """构建可验证的逐引语补丁请求；应用模型答复必须另经 apply_dialogue_patch。"""
    if paragraphs is None:
        raise ValueError('构建补丁必须提供原始 paragraphs：build_surgical_patch_prompt(issues, paragraphs=paragraphs)')
    from patch_guard import build_patch_request, format_patch_prompt
    return format_patch_prompt(build_patch_request(paragraphs, issues))

"""Behavioral checks for conditional learning records; fixtures are synthetic."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
spec = importlib.util.spec_from_file_location("learning_loop", ROOT / "scripts/learning_loop.py")
loop = importlib.util.module_from_spec(spec)
spec.loader.exec_module(loop)
import project_state


START = "<!-- NOVEL_WORKSHOP_LEARNING_START -->"
END = "<!-- NOVEL_WORKSHOP_LEARNING_END -->"
PREFIX = "# 本书学习记录\r\n\r\n作者的原有说明：人物与正文另有权威。\n\n"
SUFFIX = "\n\n## 手写便笺\n保留空格  和换行。\n"


def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def case(case_id, *, status="teacher_approved", group=None,
         split="development", task="dialogue_revision", tags=None, project="book"):
    item = json.loads((ROOT / "assets/demonstration-case-template.json").read_text(encoding="utf-8"))
    item.update(id=case_id, project_id=project, group_id=group or case_id,
                status=status, split=split, task=task, tags=tags or ["dialogue"],
                before="合成原稿：" + case_id, after="合成改稿：" + case_id,
                why="让回应与对方当下的动作相接。", when=["双方正在对话"],
                **{"except": ["本段有意表现答非所问"]})
    item["source"] = {"ref": "fixture://teacher/" + case_id, "version": "1",
                      "reviewer": "synthetic-teacher", "evidence": "Synthetic test evidence only."}
    item["hashes"] = {key: sha(item[key]) for key in ("before", "after")}
    return item


class LearningLoopTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "学习记录.md"
        self.serial = 0
        self.write_record()

    def write_record(self, items=(), extra=None):
        data = {"demonstration_learning": {"enabled": True, "loop_enabled": True,
                                            "max_revisions": 2},
                "demonstrations": {c["id"]: c for c in items},
                "learning_runs": {}, "learning_events": {}}
        data.update(copy.deepcopy(extra or {}))
        payload = {"schema_version": 1, "project_id": "book", "revision": 0, "data": data}
        self.path.write_text(PREFIX + START + "\n```json\n" +
                             json.dumps(payload, ensure_ascii=False) + "\n```\n" + END + SUFFIX,
                             encoding="utf-8")

    def payload(self):
        return loop.read_store(self.path)[0]

    def event(self, op, run_id="run", **fields):
        self.serial += 1
        event = {"event_id": "event-" + str(self.serial), "op": op, **fields}
        if run_id is not None:
            event["run_id"] = run_id
        return event

    def apply(self, op, run_id="run", **fields):
        return self.send(self.event(op, run_id, **fields))

    def send(self, event, *, project_id="book", version=None):
        if version is None:
            version = loop.read_store(self.path)[1]
        return loop.apply_event(self.path, event, project_id, version)

    def rejected(self, event, **kwargs):
        before = self.path.read_bytes()
        with self.assertRaises(loop.LoopError) as caught:
            self.send(event, **kwargs)
        self.assertTrue(caught.exception.code)
        self.assertEqual(self.path.read_bytes(), before, "a rejected event must perform no write")
        return caught.exception

    def begin(self, *, text="她把杯子推回来。‘你先说。’", run_id="run", plan=True):
        self.apply("start", run_id, task="dialogue_revision", tags=["dialogue"],
                   group_id="current-scene", input_text="他把杯子递过去。她说，‘我知道。’",
                   source_ref="fixture://input/chapter-2", constraints=["保留杯子这个动作"])
        if plan:
            self.apply("plan", run_id, applications=[], checks=["回应接住对方动作"])
            self.apply("draft", run_id, text=text, source_ref="fixture://draft/v1",
                       actor={"name": "synthetic-writer", "context_id": "writer-context"})
        return text

    def review(self, review_id="review-1", *, text=None, verdict="pass", findings=None,
               role="writer", mode="self_check", context_id="writer-context", rechecks=None):
        if text is None:
            text = self.payload()["data"]["learning_runs"]["run"]["current_draft"]["text"]
        fields = dict(review_id=review_id, draft_sha256=sha(text),
                      reviewer={"name": "synthetic-" + role, "role": role,
                                "mode": mode, "context_id": context_id},
                      verdict=verdict, findings=findings or [],
                      source_ref="fixture://reviews/" + review_id)
        if rechecks is not None:
            fields["rechecks"] = rechecks
        return self.apply("review", **fields)

    def request_revision(self, review_id="needs-fix", *, rechecks=None):
        self.review(review_id, verdict="revise", findings=[{
            "id": "f1", "issue": "回应没有接住动作", "evidence": "她没有碰杯子", "scope": "第二句"}],
            role="teacher", mode="independent_agent", context_id="teacher-context",
            rechecks=rechecks)

    def adopt(self, review_id="needs-fix", decision="adopt"):
        self.apply("decide", review_id=review_id,
                   decisions=[{"finding_id": "f1", "decision": decision,
                               "reason": "与当前文本和保留动作的要求核对后取舍。"}])

    def revise(self, text="她按住杯子。‘你先说。’", review_id="needs-fix", parent=None):
        if parent is None:
            parent = self.payload()["data"]["learning_runs"]["run"]["current_draft"]["sha256"]
        return self.apply("revise", parent_sha256=parent, text=text,
                          source_ref="fixture://draft/v2", review_id=review_id,
                          actor={"name": "synthetic-writer", "context_id": "writer-context"})

    def finish(self, text):
        return self.apply("finish", draft_sha256=sha(text))

    def learn(self, case_id="learned"):
        return self.apply("learn", case_id=case_id, why="回应承接了杯子的动作。",
                          when=["需要让对白与动作互相承接"],
                          **{"except": ["刻意表现答非所问"]}, decisions=["保留杯子，改回应。"])

    def test_markdown_writes_preserve_all_outside_text_and_unrelated_data(self):
        unrelated = {"handwritten": {"keep": ["人物另存", 7], "literal": "普通资料里的```不结束JSON字符串"},
                     "characters": {"L": {"name": "林"}}}
        self.write_record(extra=unrelated)
        result = self.apply("configure", None, loop_enabled=True, max_revisions=3)
        saved = self.path.read_bytes()
        self.assertEqual(result["status"], "saved")
        self.assertEqual(saved.split(START.encode())[0], PREFIX.encode())
        self.assertEqual(saved.split(END.encode())[1], SUFFIX.encode())
        for key, value in unrelated.items():
            self.assertEqual(self.payload()["data"][key], value)

    def test_wrong_project_is_rejected_without_writing(self):
        self.rejected(self.event("configure", None, loop_enabled=False), project_id="another-book")

    def test_stale_version_rejects_even_an_unrelated_change(self):
        old_version = loop.read_store(self.path)[1]
        # A note outside the JSON block is still part of the read version.
        self.path.write_bytes(self.path.read_bytes() + "作者新补的块外便笺。\n".encode())
        self.assertNotEqual(loop.read_store(self.path)[1], old_version)
        self.rejected(self.event("configure", None, loop_enabled=False), version=old_version)

    def test_event_retry_is_idempotent_and_id_reuse_with_new_payload_is_rejected(self):
        event = self.event("configure", None, max_revisions=3, loop_enabled=True)
        original_version = loop.read_store(self.path)[1]
        first = self.send(event, version=original_version)
        saved = self.path.read_bytes()
        # A lost-response retry repeats both its event and original CAS token.
        again = self.send(copy.deepcopy(event), version=original_version)
        self.assertEqual(again["status"], "unchanged")
        self.assertEqual(again["version"], first["version"])
        self.assertEqual(self.path.read_bytes(), saved)
        changed = {**event, "max_revisions": 4}
        self.rejected(changed)

    def test_zero_examples_and_unchanged_draft_can_finish_as_self_checked_candidate(self):
        original = "他把杯子递过去。她说，‘我知道。’"
        text = self.begin(text=original)
        self.review()
        self.finish(text)
        self.learn()
        learned = self.payload()["data"]["demonstrations"]["learned"]
        self.assertEqual((learned["before"], learned["after"]), (original, original))
        self.assertEqual(learned["status"], "candidate")
        self.assertEqual(learned["hashes"], {"before": sha(original), "after": sha(original)})
        self.assertTrue(learned["source"]["ref"])
        self.assertIsNone(learned.get("author_acceptance"))

    def test_selected_example_may_be_declined_when_its_exception_applies(self):
        self.write_record([case("deliberate-nonanswer")])
        self.begin(plan=False)
        self.apply("plan", applications=[{
            "case_id": "deliberate-nonanswer", "decision": "decline",
            "reason": "本轮要表现她有意回避，不套用正常应答。",
            "conditions_checked": {"双方正在对话": True},
            "exceptions_checked": {"本段有意表现答非所问": True}}], checks=["回避是有意的"])
        text = "她没有接杯子。‘今天下雨了。’"
        self.apply("draft", text=text, source_ref="fixture://draft/nonanswer",
                   actor={"name": "synthetic-writer", "context_id": "writer-context"})
        self.review()
        self.assertEqual(self.finish(text)["status"], "saved")

    def test_context_excludes_unrelated_examples_entire_holdout_groups_and_text_duplicates(self):
        held = case("held", split="holdout", group="held-scene")
        duplicate = case("duplicate")
        duplicate["before"] = held["after"]
        duplicate["hashes"]["before"] = held["hashes"]["after"]
        self.write_record([held, case("sibling", group="held-scene"), duplicate,
                           case("other-task", task="combat_revision"),
                           case("other-tags", tags=["combat"]), case("other-book", project="elsewhere"),
                           case("safe")])
        result = loop.context(self.path, "book", "dialogue_revision", tags=["dialogue"])
        self.assertEqual([c["id"] for c in result["cases"]], ["safe"])

    def test_feedback_for_a_different_draft_hash_is_rejected(self):
        self.begin()
        self.rejected(self.event("review", review_id="wrong-draft", draft_sha256=sha("另一个稿件"),
            reviewer={"name": "teacher", "role": "teacher", "mode": "independent_agent",
                      "context_id": "teacher-context"}, verdict="pass", findings=[],
            source_ref="fixture://reviews/wrong-draft"))

    def test_same_writer_context_cannot_claim_an_independent_review(self):
        text = self.begin()
        self.rejected(self.event("review", review_id="same-context", draft_sha256=sha(text),
            reviewer={"name": "another-name", "role": "teacher", "mode": "independent_agent",
                      "context_id": "writer-context"}, verdict="pass", findings=[],
            source_ref="fixture://reviews/same-context"))

    def test_self_check_cannot_be_teacher_or_author_approval(self):
        text = self.begin()
        for role in ("teacher", "author"):
            with self.subTest(role=role):
                self.rejected(self.event("review", review_id="pretend-" + role, draft_sha256=sha(text),
                    reviewer={"name": role, "role": role, "mode": "self_check",
                              "context_id": "writer-context"}, verdict="pass", findings=[],
                    source_ref="fixture://reviews/pretend"))

    def test_revision_invalidates_old_pass_and_requires_explicit_recheck_binding(self):
        self.begin()
        self.review("old-pass")
        self.request_revision()
        self.adopt()
        revised = "她按住杯子。‘你先说。’"
        self.revise(revised)
        self.rejected(self.event("finish", draft_sha256=sha(revised)))
        # An unbound pass may be refused when recorded or when finishing, but
        # it must never complete the run or discharge the earlier feedback.
        unbound = self.event("review", review_id="unbound-pass", draft_sha256=sha(revised),
            reviewer={"name": "teacher", "role": "teacher", "mode": "independent_agent",
                      "context_id": "teacher-context"}, verdict="pass", findings=[],
            source_ref="fixture://reviews/unbound")
        before = self.path.read_bytes()
        try:
            self.send(unbound)
        except loop.LoopError:
            self.assertEqual(self.path.read_bytes(), before)
        else:
            self.rejected(self.event("finish", draft_sha256=sha(revised)))
        self.review("bound-pass", role="teacher", mode="independent_agent",
                    context_id="teacher-context", rechecks=["needs-fix"])
        self.assertEqual(self.finish(revised)["status"], "saved")

    def test_revision_requires_an_adopted_finding(self):
        self.begin()
        self.request_revision()
        for decision in (None, "decline"):
            with self.subTest(decision=decision):
                if decision:
                    self.adopt(decision=decision)
                parent = self.payload()["data"]["learning_runs"]["run"]["current_draft"]["sha256"]
                self.rejected(self.event("revise", parent_sha256=parent, text="未获采纳的改写",
                    source_ref="fixture://draft/unadopted", review_id="needs-fix",
                    actor={"name": "synthetic-writer", "context_id": "writer-context"}))

    def test_revision_must_name_the_current_parent_hash(self):
        self.begin()
        self.request_revision()
        self.adopt()
        self.rejected(self.event("revise", parent_sha256=sha("并非本轮稿件"), text="错误父稿的改写",
            source_ref="fixture://draft/wrong-parent", review_id="needs-fix",
            actor={"name": "synthetic-writer", "context_id": "writer-context"}))

    def test_revision_budget_stops_further_rewriting_without_forcing_a_pass(self):
        self.apply("configure", None, loop_enabled=True, max_revisions=1)
        self.begin()
        self.request_revision()
        self.adopt()
        self.revise()
        self.request_revision("still-needs-fix", rechecks=["needs-fix"])
        self.adopt("still-needs-fix")
        parent = self.payload()["data"]["learning_runs"]["run"]["current_draft"]["sha256"]
        self.rejected(self.event("revise", parent_sha256=parent, text="超出预算的第二次改写",
            source_ref="fixture://draft/over-budget", review_id="still-needs-fix",
            actor={"name": "synthetic-writer", "context_id": "writer-context"}))
        self.assertEqual(self.apply("stop", reason="本轮返工额度已用完，保留未解决问题。")["status"], "saved")

    def test_learn_uses_real_input_final_text_and_actual_teacher_review(self):
        original = "他把杯子递过去。她说，‘我知道。’"
        self.begin()
        self.request_revision()
        self.adopt()
        final = "她按住杯子。‘你先说。’"
        self.revise(final)
        self.review("teacher-final", role="teacher", mode="independent_agent",
                    context_id="teacher-context", rechecks=["needs-fix"])
        self.finish(final)
        self.learn()
        learned = self.payload()["data"]["demonstrations"]["learned"]
        self.assertEqual((learned["before"], learned["after"]), (original, final))
        self.assertEqual(learned["hashes"], {"before": sha(original), "after": sha(final)})
        self.assertEqual(learned["status"], "teacher_approved")
        self.assertIsNone(learned.get("author_acceptance"))
        source = learned["source"]
        self.assertEqual(source["run_id"], "run")
        self.assertEqual(source["input_ref"], "fixture://input/chapter-2")
        self.assertEqual(source["draft_ref"], "fixture://draft/v2")
        self.assertEqual(source["draft_sha256"], sha(final))
        self.assertIn("teacher-final", source["review_ids"])

    def test_author_acceptance_requires_a_quote_and_binds_current_text(self):
        text = self.begin()
        self.review()
        self.finish(text)
        self.rejected(self.event("author_accept", draft_sha256=sha(text), quote="",
                                 source_ref="fixture://author/comment"))
        self.rejected(self.event("author_accept", draft_sha256=sha("旧稿"), quote="保留这版。",
                                 source_ref="fixture://author/comment"))
        self.apply("author_accept", draft_sha256=sha(text), quote="保留这版。",
                   source_ref="fixture://author/comment")
        self.learn()
        learned = self.payload()["data"]["demonstrations"]["learned"]
        self.assertEqual(learned["status"], "author_accepted")
        self.assertEqual(learned["author_acceptance"]["quote"], "保留这版。")
        self.assertIn("fixture://author/comment", json.dumps(learned["author_acceptance"]))

    def test_rejected_or_retired_case_is_immediately_excluded(self):
        self.write_record([case("reject"), case("retire"), case("keep")])
        for case_id, status in (("reject", "rejected"), ("retire", "retired")):
            self.apply("case_status", None, case_id=case_id, status=status,
                       reason="合成测试：不继续作为示范。")
        result = loop.context(self.path, "book", "dialogue_revision", tags=["dialogue"])
        self.assertEqual([c["id"] for c in result["cases"]], ["keep"])

    def test_disabling_loop_preserves_history_and_returns_to_original_workflow(self):
        self.begin()
        history = copy.deepcopy(self.payload()["data"]["learning_runs"])
        self.apply("configure", None, loop_enabled=False)
        state = loop.status(self.path)
        self.assertEqual(state["status"], "disabled")
        self.assertFalse(state["loop_enabled"])
        self.assertEqual(state["next_action"], "resume_original_workflow")
        self.assertEqual(loop.context(self.path, "book", "dialogue_revision")["cases"], [])
        self.assertEqual(self.payload()["data"]["learning_runs"], history)
        self.rejected(self.event("start", "new-run", task="dialogue_revision", tags=[],
            group_id="next-scene", input_text="原写作流程仍可处理的文本", source_ref="fixture://next",
            constraints=[]))

    def test_existing_project_json_keeps_story_and_uses_its_conditional_version(self):
        self.path = Path(self.temp.name) / "story-state.json"
        marker_case = case("literal-markers")
        marker_case["before"] = "正文会谈到字面标记：" + START
        marker_case["after"] = "正文会谈到另一字面标记：" + END
        marker_case["hashes"] = {key: sha(marker_case[key]) for key in ("before", "after")}
        original = {"characters": {"L": {"name": "林", "locked": True}},
                    "settings": {"weather": "雨"}, "chapters": {"2": {"text": "作者定稿"}},
                    "workflow_guard": {"budget": 1}, "author_notes": ["不改正文"],
                    "demonstrations": {"literal-markers": marker_case}}
        project_state.init_state(self.path, "book", original)
        old_version = loop.read_store(self.path)[1]
        self.assertEqual(old_version, project_state.read_state(self.path)["version"])
        self.apply("configure", None, loop_enabled=True, max_revisions=2)
        saved = project_state.read_state(self.path)
        for key, value in original.items():
            self.assertEqual(saved["data"][key], value)
        self.assertLessEqual(set(saved["data"]) - set(original),
                             {"demonstration_learning", "demonstrations", "learning_runs", "learning_events"})
        self.rejected(self.event("configure", None, loop_enabled=False), version=old_version)
        self.assertEqual(loop.read_store(self.path)[1], saved["version"])

    def test_evaluation_requires_exclusion_and_context_queries_are_read_only(self):
        self.write_record([case("current", group="current-scene"), case("safe")])
        before = self.path.read_bytes()
        with self.assertRaises(loop.LoopError):
            loop.context(self.path, "book", "dialogue_revision", evaluation=True)
        selected = loop.context(self.path, "book", "dialogue_revision", tags=["dialogue"],
                                excluded=["current-scene"], evaluation=True)
        self.assertEqual([c["id"] for c in selected["cases"]], ["safe"])
        self.assertEqual(self.path.read_bytes(), before)

    def test_markdown_input_and_review_evidence_can_contain_literal_delimiters(self):
        literal = "原文字面内容：" + START + "，以及" + END + "，还有```。"
        self.apply("start", task="dialogue_revision", tags=["dialogue"],
                   group_id="current-scene", input_text=literal,
                   source_ref="fixture://input/literal-markers", constraints=[])
        self.assertEqual(self.payload()["data"]["learning_runs"]["run"]["input_text"], literal)
        self.apply("plan", applications=[], checks=["保持字面标记原文"])
        self.apply("draft", text=literal, source_ref="fixture://draft/literal-markers",
                   actor={"name": "synthetic-writer", "context_id": "writer-context"})
        self.review("literal-evidence", verdict="revise", findings=[{
            "id": "literal", "issue": "核对字面标记", "evidence": literal, "scope": "整句"}])
        run = self.payload()["data"]["learning_runs"]["run"]
        self.assertEqual(run["input_text"], literal)
        self.assertEqual(run["current_draft"]["text"], literal)
        self.assertEqual(run["reviews"]["literal-evidence"]["findings"][0]["evidence"], literal)

    def test_revision_cannot_drop_a_second_unresolved_or_empty_blocked_review(self):
        for second_verdict in ("revise", "blocked"):
            with self.subTest(second_verdict=second_verdict):
                self.write_record()
                self.begin()
                self.request_revision("A")
                if second_verdict == "revise":
                    self.request_revision("B")
                else:
                    self.review("B", verdict="blocked", findings=[])
                self.adopt("A")
                final = "她按住杯子。‘你先说。’"
                if second_verdict == "revise":
                    parent = self.payload()["data"]["learning_runs"]["run"]["current_draft"]["sha256"]
                    self.rejected(self.event("revise", parent_sha256=parent, text=final,
                        source_ref="fixture://draft/missing-B-decision", review_id="A",
                        actor={"name": "synthetic-writer", "context_id": "writer-context"}))
                    self.adopt("B", decision="defer")
                self.revise(final, review_id="A")
                self.review("partial-recheck", rechecks=["A"])
                self.rejected(self.event("finish", draft_sha256=sha(final)))
                self.review("complete-recheck", rechecks=["A", "B"])
                self.assertEqual(self.finish(final)["status"], "saved")

    def test_teacher_approval_after_a_writer_pass_keeps_the_teacher_source(self):
        text = self.begin()
        self.review("teacher-pass", role="teacher", mode="independent_agent",
                    context_id="teacher-context")
        self.review("writer-pass")
        self.finish(text)
        self.learn()
        learned = self.payload()["data"]["demonstrations"]["learned"]
        self.assertEqual(learned["status"], "teacher_approved")
        self.assertEqual(learned["source"]["supporting_review_id"], "teacher-pass")
        self.assertEqual(learned["source"]["reviewer"], "synthetic-teacher")
        self.assertEqual(learned["source"]["evidence"], "fixture://reviews/teacher-pass")

    def test_later_teacher_revise_cannot_reuse_an_earlier_teacher_pass(self):
        text = self.begin()
        self.review("teacher-old-pass", role="teacher", mode="independent_agent",
                    context_id="teacher-context")
        self.request_revision("teacher-latest-revise")
        self.adopt("teacher-latest-revise", decision="decline")
        self.review("writer-final-pass", rechecks=["teacher-latest-revise"])
        self.finish(text)
        self.learn()
        learned = self.payload()["data"]["demonstrations"]["learned"]
        self.assertEqual(learned["status"], "candidate")
        self.assertEqual(learned["source"]["supporting_review_id"], "writer-final-pass")
        self.assertEqual(learned["source"]["evidence"], "fixture://reviews/writer-final-pass")

    def test_frozen_cases_must_still_be_approved_and_unchanged_at_plan_and_draft(self):
        for phase in ("plan", "draft"):
            for mutation in ("retired", "rejected", "text", "metadata"):
                with self.subTest(phase=phase, mutation=mutation):
                    self.path = Path(self.temp.name) / (phase + "-" + mutation + ".json")
                    item = case("frozen")
                    project_state.init_state(self.path, "book", {
                        "characters": {}, "settings": {}, "chapters": {},
                        "demonstration_learning": {"enabled": True, "loop_enabled": True,
                                                   "max_revisions": 2},
                        "demonstrations": {"frozen": item}})
                    self.begin(plan=False)

                    def application(decision):
                        return {"case_id": "frozen", "decision": decision,
                                "reason": "合成测试：核对已冻结案例的适用性。",
                                "conditions_checked": {item["when"][0]: True},
                                "exceptions_checked": {item["except"][0]: False}}

                    if phase == "draft":
                        self.apply("plan", applications=[application("apply")], checks=["核对案例新鲜性"])
                    if mutation in ("retired", "rejected"):
                        self.apply("case_status", None, case_id="frozen", status=mutation,
                                   reason="合成测试：本案例已停止使用。")
                    else:
                        snapshot = project_state.read_state(self.path)
                        updated = copy.deepcopy(snapshot["data"])
                        changed = updated["demonstrations"]["frozen"]
                        if mutation == "text":
                            changed["after"] += "新版"
                            changed["hashes"]["after"] = sha(changed["after"])
                        else:
                            changed["why"] += "新补的适用依据。"
                        project_state.commit_state(self.path, snapshot["version"], updated)
                    if phase == "plan":
                        for decision in ("apply", "adapt"):
                            self.rejected(self.event("plan", applications=[application(decision)],
                                                     checks=["核对案例新鲜性"]))
                        self.assertEqual(self.apply("plan", applications=[application("decline")],
                                                    checks=["不再使用已变更案例"])["status"], "saved")
                    else:
                        self.rejected(self.event("draft", text="案例已失效时不能继续套用。",
                            source_ref="fixture://draft/stale-case",
                            actor={"name": "synthetic-writer", "context_id": "writer-context"}))
                        self.assertEqual(self.apply("stop", reason="案例已变更，停止并重开本轮。")["status"], "saved")

    def test_holdout_group_sibling_text_cannot_leak_through_another_group(self):
        for copied_field in ("before", "after"):
            with self.subTest(copied_field=copied_field):
                held = case("held", split="holdout", group="held-group")
                sibling = case("sibling", group="held-group")
                duplicate = case("cross-group-copy", group="different-group")
                duplicate["after"] = sibling[copied_field]
                duplicate["hashes"]["after"] = sibling["hashes"][copied_field]
                self.write_record([held, sibling, duplicate, case("safe")])
                selected = loop.context(self.path, "book", "dialogue_revision", tags=["dialogue"])
                self.assertEqual([c["id"] for c in selected["cases"]], ["safe"])

    def test_same_text_revision_requires_a_new_review_instance(self):
        text = self.begin()
        self.request_revision("needs-fix")
        self.adopt("needs-fix")
        self.review("prior-instance-pass", rechecks=["needs-fix"])
        self.revise(text, review_id="needs-fix")
        self.rejected(self.event("finish", draft_sha256=sha(text)))
        self.review("current-instance-pass", rechecks=["needs-fix"])
        self.assertEqual(self.finish(text)["status"], "saved")


if __name__ == "__main__":
    unittest.main()

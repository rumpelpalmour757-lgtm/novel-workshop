#!/usr/bin/env python3
"""Regression tests for the novel workshop package. Standard library only.

Usage:  python3 tests/run_tests.py [--package-root DIR] [-v]
The default package root is the folder that contains this tests directory.
Point --package-root at an older release to see which guarantees it lacks.
"""

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
import unittest.mock

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
FIXTURES = HERE / "fixtures"


def skill():
    return ROOT / "skills" / "novel-workshop"


def script(name):
    return skill() / "scripts" / name


def project_state_supported():
    """project_state.py needs POSIX flock (references/state-storage.md); the same test the script makes."""
    try:
        import fcntl  # noqa: F401
    except ImportError:
        return False
    return os.name == "posix"


def run(name, *args, cwd=None):
    """Run a packaged script the way a user would, in isolated mode."""
    path = name if isinstance(name, Path) else script(name)
    proc = subprocess.run([sys.executable, "-I", "-B", str(path), *map(str, args)], cwd=cwd,
                          capture_output=True, text=True, encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


def load_module(name):
    location = script(name + ".py")
    spec = importlib.util.spec_from_file_location("t_" + name, location)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, text):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_bytes((text).encode("utf-8"))
    return Path(path)


# ---------------------------------------------------------------- punctuation
class PunctuationLint(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.lint = staticmethod(load_module("punctuation_lint").lint_text)

    def rules_of(self, report, rule, severity=None):
        return [f for f in report["findings"] if f["rule"] == rule and (severity is None or f["severity"] == severity)]

    def test_registered_ability_tag_with_full_stop_is_error(self):
        report = self.lint("他闭上眼，【定。】水声退远了。", {"ability_tags": ["定"]})
        self.assertEqual(len(self.rules_of(report, "P03", "ERROR")), 1)

    def test_same_tag_written_both_ways_is_review_without_registry(self):
        # r4.2 decision, kept in the merge: an unregistered tag and a panel answer such as 【好。】 can coexist,
        # so the mixed spelling is a REVIEW; a registered tag with punctuation inside stays an ERROR (test below).
        report = self.lint("【定】在掌心沉下去。\n\n【定。】\n")
        self.assertEqual(len(self.rules_of(report, "P03", "REVIEW")), 1)
        self.assertEqual(len(self.rules_of(report, "P03", "ERROR")), 0)

    def test_system_panel_sentence_is_not_flagged(self):
        for rules in (None, {"panel_prefixes": ["任务"]}):
            report = self.lint("【任务已完成。】奖励已发放。", rules)
            self.assertEqual(self.rules_of(report, "P03"), [], rules)

    def test_unregistered_short_tag_is_review_not_error(self):
        report = self.lint("【叮。】系统提示音响起。")
        self.assertEqual([f["severity"] for f in self.rules_of(report, "P03")], ["REVIEW"])
        self.assertEqual(report["counts"]["ERROR"], 0)

    def test_chopped_action_chain_is_review_only(self):
        report = self.lint("他伸手。握住刀柄。拔。没拔动。")
        self.assertEqual(len(self.rules_of(report, "P10", "REVIEW")), 1)
        self.assertEqual(report["counts"]["ERROR"], 0)
        self.assertEqual(report["status"], "REVIEW")

    def test_ordinary_prose_is_not_flagged_as_chopped(self):
        report = self.lint("雨停了。林舟推开门。院子里站着一个人，背对着他。他没有出声。")
        self.assertEqual(self.rules_of(report, "P10"), [])

    def test_run_of_one_line_paragraphs_is_review(self):
        report = self.lint("他停下。\n\n风很冷。\n\n灯灭了。\n\n门响了。\n")
        self.assertEqual(len(self.rules_of(report, "P11", "REVIEW")), 1)

    def test_dialogue_exchange_is_not_counted_as_short_paragraph_run(self):
        report = self.lint("“走？”\n\n“走。”\n\n“现在？”\n\n“现在。”\n")
        self.assertEqual(self.rules_of(report, "P11"), [])

    def test_unclosed_quote_is_error_but_multi_paragraph_quote_is_not(self):
        bad = self.lint("“走吧。他说。\n\n门外没人应。\n")
        self.assertTrue(self.rules_of(bad, "P01", "ERROR"))
        good = self.lint("“这件事说来话长。\n“那年冬天，港口还没封。\n“后来的事，你都知道了。”\n")
        self.assertEqual(self.rules_of(good, "P01"), [])

    def test_half_width_marks_in_chinese_but_not_numbers(self):
        report = self.lint("他说,走吧.\n\n十点整是10:00，重3.5公斤，编号A-17。")
        hits = self.rules_of(report, "P06", "ERROR")
        self.assertEqual([h["match"] for h in hits], [",", "."])

    def test_ellipsis_dash_and_ranges(self):
        report = self.lint("他笑了一声...没说话。第1—4章，2011—2012年。她说——算了。")
        self.assertEqual([f["match"] for f in self.rules_of(report, "P05", "ERROR")], ["..."])
        self.assertEqual(len(report["findings"]), 1)

    def test_terminal_inside_quote_plus_full_stop_requires_context(self):
        # r4.2 decision, kept in the merge: an independent utterance and a quotation used as part of the
        # sentence are punctuated differently, so adjacent marks inside and outside a quote are a REVIEW.
        report = self.lint("他问：“你来了？”。")
        self.assertTrue(self.rules_of(report, "P04", "REVIEW"))

    def test_dialogue_without_punctuation_before_speaker_is_review(self):
        report = self.lint("“走吧”他说。\n\n他把“船票”收好，说今晚就走。")
        self.assertEqual(len(self.rules_of(report, "P09", "REVIEW")), 1)

    def test_exemption_is_exact_and_reported(self):
        text = "他伸手。握住刀柄。拔。没拔动。"
        rules = {"ignore": [{"rule": "P10", "line": 1, "text": text, "reason": "作者要的顿挫"},
                            {"rule": "P10", "line": 9, "text": "x", "reason": "过期豁免"}]}
        report = self.lint(text, rules)
        self.assertEqual(report["findings"], [])
        self.assertEqual(len(report["suppressed"]), 1)
        self.assertEqual(len(report["unused_ignores"]), 1)

    def test_statistics_have_a_basis_and_no_pass_mark(self):
        stats = self.lint("林舟走到井边，弯腰抓住绳子。绳子很沉。")["stats"]
        self.assertIn("basis", stats)
        self.assertEqual(stats["marks"]["。"], 2)
        self.assertNotIn("pass", json.dumps(stats).lower())

    # r5: reader-load hints (CON-009). Review only, thresholds come from the work's rules.
    def test_dense_narrative_paragraph_is_review_only(self):
        dense = ("天还没亮，码头上的灯一盏接一盏地灭了，搬运工从棚子底下钻出来，扛起昨夜卸在岸边的麻袋往仓库走，"
                 "账房先生站在门口点数，每进去一袋就在簿子上画一道，画到第三十道时笔尖断了，他骂了一声，"
                 "从耳朵后面摸出另一支笔接着画，旁边的学徒端着茶碗不敢吭声，只是把碗往他手边推了推，"
                 "船上的伙计这时又喊起来，说底舱还有两箱没卸完，问要不要等潮水退了再搬。")
        report = self.lint(dense + "\n\n他点点头。\n")
        hits = self.rules_of(report, "P12")
        self.assertEqual([h["severity"] for h in hits], ["REVIEW"])
        self.assertEqual(hits[0]["line"], 1)
        self.assertEqual(report["counts"]["ERROR"], 0)
        relaxed = self.lint(dense, {"dense_paragraph": {"max_chars": 400}})
        self.assertEqual(self.rules_of(relaxed, "P12"), [])

    def test_registered_names_crowding_one_paragraph_is_review(self):
        text = "老周把盆递过去，阿青接住了。小满蹲下去扣上扣子，老周又伸手去扶。阿青松了手。小满抬头看他。"
        self.assertEqual(self.rules_of(self.lint(text), "P12"), [])  # no names registered, nothing to count
        report = self.lint(text, {"characters": ["老周", ["阿青", "青姐"], "小满"]})
        self.assertEqual(len(self.rules_of(report, "P12", "REVIEW")), 1)
        self.assertIn("3", self.rules_of(report, "P12")[0]["message"])

    def test_long_unbroken_speech_is_review_but_broken_speech_is_not(self):
        speech = ("“我姓秦，在南城做了十年押运。这趟活儿给你三成，先付一半，剩下的到地方再结。"
                  "路上不许问货是什么，不许离开车队，夜里轮流守着，谁打盹扣谁的钱。"
                  "要是碰上关卡，你只管低头，话由我来说，出了事我担着，跟你没关系。"
                  "车上的水和干粮我备好了，你只带自己的刀。到了北岸，有人会来接货，你不用跟他说话。”")
        report = self.lint(speech + "\n")
        self.assertEqual([h["severity"] for h in self.rules_of(report, "P13")], ["REVIEW"])
        broken = ("“我姓秦，在南城做了十年押运。这趟活儿给你三成，先付一半。”她把茶碗推过来，"
                  "“剩下的到地方再结。路上不许问货是什么。”\n")
        self.assertEqual(self.rules_of(self.lint(broken), "P13"), [])

    # r5: revision comparison (CON-010) — what the edit introduced, not what was already there.
    def test_revision_compare_lists_only_introduced_problems(self):
        compare = load_module("punctuation_lint").compare_texts
        original = "他伸手。握住刀柄。拔。没拔动。\n\n门外传来脚步声，他回头看了一眼，又转回来，把刀按回鞘里。\n"
        revised = "他伸手。握住刀柄。拔。没拔动。\n\n门外传来脚步声。他回头。看了一眼。又转回来。把刀按回鞘里。\n"
        report = compare(original, revised)
        introduced = [f["rule"] for f in report["introduced"]]
        self.assertEqual(introduced, ["P10"])  # the old chain in paragraph 1 is not reported again
        self.assertEqual(report["status"], "REVIEW")
        fixed = compare(revised, original)
        self.assertEqual((fixed["introduced"], [f["rule"] for f in fixed["resolved"]]), ([], ["P10"]))

    def test_revision_compare_flags_changed_dialogue_tone(self):
        compare = load_module("punctuation_lint").compare_texts
        original = "“你走！”他说。\n\n“船还在吗？”\n\n“在。”\n"
        revised = "“你走。”他说。\n\n“船还在吗。”\n\n“在。”\n"
        report = compare(original, revised)
        changes = {c["before"] + "→" + c["after"] for c in report["tone_changes"]}
        self.assertEqual(changes, {"！→。", "？→。"})
        self.assertEqual(report["counts"]["ERROR"], 0)

    def test_cli_exit_codes(self):
        with tempfile.TemporaryDirectory() as tmp:
            error = write(Path(tmp) / "e.md", "他说,走吧。")
            review = write(Path(tmp) / "r.md", "他伸手。握住刀柄。拔。没拔动。")
            bad_rules = write(Path(tmp) / "rules.json", '{"unknown_field": 1}')
            self.assertEqual(run("punctuation_lint.py", error)[0], 1)
            self.assertEqual(run("punctuation_lint.py", review)[0], 0)
            code, out, _ = run("punctuation_lint.py", review, "--rules", bad_rules)
            self.assertEqual(code, 2)
            self.assertIn("INPUT_ERROR", out)


# ---------------------------------------------------------------------- facts
class FactGuard(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        shutil.copytree(FIXTURES / "facts", self.tmp / "facts")
        self.dir = self.tmp / "facts"

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def check(self):
        code, out, err = run("fact_guard.py", "check", self.dir / "ledger.json", self.dir / "claims-ch12.json")
        self.assertNotEqual(code, 2, out + err)
        report = json.loads(out)
        return code, report, {r["claim"]: r for r in report["results"]}

    def test_old_draft_errors_are_caught(self):
        code, report, by = self.check()
        self.assertEqual(code, 1)
        self.assertEqual(report["status"], "CONFLICTS")
        # record is not the physical handover; it also contradicts the accepted holder
        self.assertEqual(by["c1"]["status"], "UNSUPPORTED")
        self.assertTrue(any("F-08-02" in note for note in by["c1"]["also"]))
        # a later entry time is not the first appearance (seen at 09:20 already)
        self.assertEqual(by["c2"]["status"], "UNSUPPORTED")
        self.assertTrue(any("09:20" in note for note in by["c2"]["also"]))
        # new commission still awaiting acceptance cannot be settled silently
        self.assertEqual(by["c3"]["status"], "CONFLICT")
        # "no return record" is unknown, not "returned"
        self.assertEqual(by["c4"]["status"], "UNSUPPORTED")
        # matching mark is not proof the original seal was used
        self.assertEqual(by["c5"]["status"], "UNSUPPORTED")

    def test_correct_claims_are_not_blocked(self):
        _, report, by = self.check()
        self.assertEqual(by["c6"]["status"], "CONSISTENT")
        self.assertEqual(by["c7"]["status"], "CHANGE_PROPOSED")
        self.assertEqual(by["c8"]["status"], "NO_BASELINE")
        self.assertEqual({i["id"] for i in report["review_items"]}, {"F-c7", "F-c8"})

    def test_quote_must_exist_in_candidate(self):
        _, _, by = self.check()
        self.assertEqual(by["c9"]["status"], "QUOTE_NOT_FOUND")

    def test_candidate_layer_never_becomes_baseline(self):
        _, _, by = self.check()
        self.assertEqual(by["c1"]["baseline"]["id"], "F-08-02")

    def test_claims_bound_to_candidate_bytes(self):
        path = self.dir / "chapters" / "第12章.md"
        path.write_bytes((path.read_text(encoding="utf-8") + "\n多写一句。\n").encode("utf-8"))
        code, report, _ = self.check()
        self.assertEqual((code, report["status"]), (1, "STALE"))

    def test_progress_is_not_the_highest_chapter_number(self):
        code, out, _ = run("fact_guard.py", "status", self.dir / "ledger.json", "--chapters-dir", self.dir / "chapters")
        report = json.loads(out)
        # Chapters 6 and 7 are not in the ledger (status unknown), so progress stops at 5,
        # not at the highest accepted number (11) and not at the highest number on file (12).
        self.assertEqual(report["accepted_from_chapter"], 5)
        self.assertEqual(report["accepted_through_chapter"], 5)
        self.assertEqual(report["non_accepted_chapters"], [12])
        self.assertEqual(report["unlisted_chapters_in_range"], [6, 7])

    def test_edit_to_accepted_chapter_text_is_reported(self):
        path = self.dir / "chapters" / "第09章.md"
        path.write_bytes((path.read_text(encoding="utf-8").replace("三百", "五百")).encode("utf-8"))
        code, out, _ = run("fact_guard.py", "status", self.dir / "ledger.json", "--chapters-dir", self.dir / "chapters")
        self.assertEqual(code, 1)
        self.assertIn("TEXT_CHANGED_SINCE_ACCEPTED", out)

    def test_impact_lists_downstream_and_unavailable_chapters(self):
        (self.dir / "chapters" / "第12章.md").rename(self.dir / "第12章.md")
        ledger = json.loads((self.dir / "ledger.json").read_text(encoding="utf-8"))
        ledger["chapters"]["13"] = {"status": "candidate", "file": "第13章.md"}
        write(self.dir / "chapters" / "第13章.md", "沈七把封条锁进了柜子。\n")
        (self.dir / "ledger.json").write_bytes((json.dumps(ledger, ensure_ascii=False)).encode("utf-8"))
        _, out, _ = run("fact_guard.py", "impact", self.dir / "ledger.json", "--changed-chapter", 10,
                        "--chapters-dir", self.dir / "chapters")
        report = json.loads(out)
        self.assertEqual(report["status"], "REGRESSION_REQUIRED")
        self.assertIn(13, report["chapters_to_recheck"])
        self.assertIn(12, report["unavailable_chapters"])

    # r5: persistent states (CON-003) and knowledge boundaries (CON-002), neutral material.
    def persist_case(self, claims):
        ledger = {"schema": "fact-ledger/1",
                  "entities": {"person:aman": {"name": "阿蛮"}, "place:bridge": {"name": "吊桥", "aliases": ["吊桥", "绳桥"]},
                               "place:store": {"name": "库房"}, "item:key": {"name": "铜钥匙"}},
                  "chapters": {"1": {"status": "accepted"}, "2": {"status": "accepted"}},
                  "facts": [
                      {"id": "F1", "entity": "person:aman", "attribute": "injury.左臂", "value": "骨裂，吊着绷带", "chapter": 1,
                       "layer": "accepted", "basis": "witnessed_action", "source": "第1章末", "persist": True},
                      {"id": "F2", "entity": "place:bridge", "attribute": "通行", "value": "只容一人通过，桥板缺了几块", "chapter": 1,
                       "layer": "accepted", "basis": "text_statement", "source": "第1章", "persist": True},
                      {"id": "F3", "entity": "place:store", "attribute": "门锁", "value": "已撬开", "chapter": 2,
                       "layer": "accepted", "basis": "witnessed_action", "source": "第2章", "persist": True},
                      {"id": "F4", "entity": "person:aman", "attribute": "position", "value": "码头", "chapter": 2,
                       "layer": "accepted", "basis": "witnessed_action", "source": "第2章"},
                      {"id": "F5", "entity": "item:key", "attribute": "known_by.阿青", "value": False, "chapter": 2,
                       "layer": "accepted", "basis": "text_statement", "source": "第2章：钥匙的事只有阿蛮知道"}]}
        chapter = write(self.tmp / "ch3.md", "阿蛮和阿木抬着货箱跑过绳桥，桥板吱呀作响。\n阿青看着那把铜钥匙，说她早就知道。\n")
        write(self.tmp / "ledger3.json", json.dumps(ledger, ensure_ascii=False))
        write(self.tmp / "claims3.json", json.dumps({"schema": "fact-claims/1", "chapter": 3, "candidate": "ch3.md",
                                                       "candidate_sha256": sha(chapter), "extracted_by": "self_check",
                                                       "claims": claims}, ensure_ascii=False))
        code, out, err = run("fact_guard.py", "check", self.tmp / "ledger3.json", self.tmp / "claims3.json")
        self.assertNotEqual(code, 2, out + err)
        return json.loads(out)

    def test_persistent_states_surface_when_the_entity_reappears(self):
        moved = {"id": "c1", "entity": "person:aman", "attribute": "position", "value": "对岸", "basis": "witnessed_action",
                 "change": True, "quote": "阿蛮和阿木抬着货箱跑过绳桥"}
        report = self.persist_case([moved])
        # The injury and the narrow bridge persist and both are mentioned (one by alias); the store room is not.
        self.assertEqual(sorted(w["fact"] for w in report["watch"]), ["F1", "F2"])
        self.assertEqual({i["id"] for i in report["review_items"]}, {"F-c1", "W-F1", "W-F2"})
        self.assertIn("只容一人通过", next(w for w in report["watch"] if w["fact"] == "F2")["reason"])
        # A claim that answers the watched state replaces the watch item.
        injury = {"id": "c2", "entity": "person:aman", "attribute": "injury.左臂", "value": "骨裂，吊着绷带",
                  "basis": "text_statement", "quote": "阿蛮和阿木抬着货箱"}
        self.assertEqual(sorted(w["fact"] for w in self.persist_case([moved, injury])["watch"]), ["F2"])

    def test_knowledge_boundary_changes_need_direct_evidence(self):
        quote = "阿青看着那把铜钥匙，说她早就知道"
        claims = [{"id": "k1", "entity": "item:key", "attribute": "known_by.阿青", "value": True, "basis": "inference", "quote": quote},
                  {"id": "k2", "entity": "item:key", "attribute": "known_by.阿青", "value": True, "basis": "witnessed_action",
                   "change": True, "quote": quote},
                  {"id": "k3", "entity": "item:key", "attribute": "known_by.阿青", "value": True, "basis": "witnessed_action",
                   "quote": quote}]
        by = {r["claim"]: r["status"] for r in self.persist_case(claims)["results"]}
        self.assertEqual(by, {"k1": "UNSUPPORTED", "k2": "CHANGE_PROPOSED", "k3": "CONFLICT"})

    def test_ledger_that_accepts_a_record_as_fact_is_flagged(self):
        ledger = json.loads((self.dir / "ledger.json").read_text(encoding="utf-8"))
        ledger["facts"].append({"id": "F-12-01", "entity": "item:copper-box", "attribute": "holder", "value": "沈七",
                                "chapter": 12, "layer": "accepted", "basis": "record", "source": "签收记录"})
        (self.dir / "ledger.json").write_bytes((json.dumps(ledger, ensure_ascii=False)).encode("utf-8"))
        code, out, _ = run("fact_guard.py", "status", self.dir / "ledger.json")
        self.assertEqual(code, 1)
        self.assertIn("INDIRECT_BASIS_ACCEPTED", out)
        self.assertIn("UNEXPLAINED_CHANGE", out)


# ----------------------------------------------------------------------- gate
ORIGINAL = "雨停了。\n林舟推开门，看见院子里站着一个人。\n他没有出声。\n"
DRAFT = "雨停了。\n林舟推开门，院子里站着一个人。\n他没有出声。\n"


class DeliveryGate(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        write(self.dir / "original.md", ORIGINAL)
        write(self.dir / "draft.md", DRAFT)

    def tearDown(self):
        shutil.rmtree(self.dir)

    def guard(self, *args):
        code, out, err = run("workflow_guard.py", *args, cwd=self.dir)
        return code, out.strip(), err

    def spec(self, checks, **extra):
        value = {"candidate": "draft.md", "checks": checks}
        value.update(extra)
        write(self.dir / "checks.json", json.dumps(value, ensure_ascii=False))

    def review(self, name="review.json", **override):
        value = {"schema": "editorial-review/2", "verdict": "PASS", "candidate_sha256": sha(self.dir / "draft.md"),
                 "reviewer": {"mode": "self_check", "label": "同一模型自查"},
                 "checked_against": ["本轮要求：只删“看见”", "original.md 全文"], "inputs_read": ["original.md"],
                 "evidence": [{"quote": "林舟推开门，院子里站着一个人", "in": "candidate"}], "issues": [],
                 "machine_dispositions": [], "counter_evidence": "核对了感知主体与视角未变"}
        spec = self.dir / "checks.json"
        if spec.is_file():
            # r5.11: a strict-mode PASS needs the expression record. These short test texts are read as one segment;
            # the record is test data that only lets the gate get to what each test here checks.
            candidate = self.dir / json.loads(spec.read_text(encoding="utf-8"))["candidate"]
            if candidate.is_file():
                body = candidate.read_text(encoding="utf-8").strip()
                begin = next((body[:k] for k in range(4, len(body) + 1) if len("".join(body[:k].split())) >= 4), None)
                end = next((body[-k:] for k in range(4, len(body) + 1)
                            if len("".join(body[-k:].split())) >= 4 and body.count(body[-k:]) == 1), None)
                if begin and end:
                    value["expression"] = {"scope": "chapter", "decisions": [], "segments": [
                        {"from": begin, "to": end, "note": "测试数据：只验证结构，全文连读过"}]}
        value.update(override)
        write(self.dir / name, json.dumps(value, ensure_ascii=False))
        return name

    def start(self, checks=None, **extra):
        self.spec(checks if checks is not None else
                  [{"id": "keep", "type": "contains", "text": "他没有出声。"},
                   {"id": "scope", "type": "scope", "source": "original.md", "editable_lines": [[2, 2]]}], **extra)
        code, out, err = self.guard("start", "run.json", "--task-id", "t", "--spec", "checks.json")
        self.assertEqual(code, 0, out + err)

    def summary(self):
        return self.guard("status", "run.json", "--summary")[1]

    @staticmethod
    def dims(**status):
        """r5.1: strict mode needs the six review dimensions; all "met" with a note unless overridden."""
        return [{"id": key, "status": status.get(key, "met"), "note": "回归用例：本维度逐段核对过（测试数据）"}
                for key in ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function",
                            "continuity", "revision_comparison")]

    def test_legacy_unbound_review_is_refused(self):
        self.start()
        write(self.dir / "legacy.json", '{"verdict": "PASS", "checked_against": ["整章已逐段核验"], "issues": []}')
        code, out, _ = self.guard("record", "run.json", "--event-id", "v0", "--review", "legacy.json")
        self.assertEqual(code, 2)
        self.assertIn("REVIEW_INCOMPLETE", out)

    def test_fabricated_quote_is_refused(self):
        self.start()
        name = self.review(evidence=[{"quote": "他把刀插回鞘里，转身就走", "in": "candidate"}])
        code, out, _ = self.guard("record", "run.json", "--event-id", "v0", "--review", name)
        self.assertIn("EVIDENCE_NOT_FOUND", out)
        self.assertIn("EDITORIAL=UNTESTED", self.summary())

    def test_edit_after_pass_makes_results_stale_and_old_review_unusable(self):
        self.start()
        name = self.review()
        self.assertEqual(self.guard("record", "run.json", "--event-id", "v0", "--review", name)[0], 0)
        self.assertIn("MECHANICAL=GREEN | EDITORIAL=PASS[self_check] | AUTHOR=NOT_ACCEPTED", self.summary())
        write(self.dir / "draft.md", "雨停了。\n林舟推门。看见院子。站着一个人。\n他没有出声。\n")
        self.assertIn("MECHANICAL=STALE | EDITORIAL=STALE", self.summary())
        code, out, _ = self.guard("record", "run.json", "--event-id", "v1", "--review", name)
        self.assertIn("REVIEW_STALE", out)

    def test_untested_is_never_reported_as_pass(self):
        self.start(checks=[])
        name = self.review(inputs_read=[])
        self.assertEqual(self.guard("record", "run.json", "--event-id", "v0", "--review", name)[0], 0)
        line = self.summary()
        self.assertIn("MECHANICAL=UNTESTED", line)
        self.assertNotIn("MECHANICAL=GREEN", line)

    def test_strict_mode_refuses_an_empty_check_list(self):
        self.spec([], mode="strict")
        code, out, _ = self.guard("start", "run.json", "--task-id", "t", "--spec", "checks.json")
        self.assertEqual(code, 2)
        self.assertIn("strict mode requires", out)

    def test_candidate_is_not_author_accepted_until_the_author_accepts_those_bytes(self):
        self.start()
        self.guard("record", "run.json", "--event-id", "v0", "--review", self.review())
        state = json.loads((self.dir / "run.json").read_text(encoding="utf-8"))
        self.assertEqual(state["current_node"], "complete")
        self.assertEqual([a["author_status"] for a in state["artifacts"] if a["role"] == "candidate"], ["draft"])
        self.assertIn("AUTHOR=NOT_ACCEPTED", self.summary())
        good = sha(self.dir / "draft.md")
        write(self.dir / "acc-missing.json", json.dumps({"candidate_sha256": good, "scope": "全文"}))
        self.assertIn("ACCEPT_INVALID", self.guard("accept", "run.json", "--event-id", "a0", "--decision", "acc-missing.json")[1])
        write(self.dir / "acc.json", json.dumps({"candidate_sha256": good, "source": "作者：就用这版", "scope": "全文"}, ensure_ascii=False))
        self.assertEqual(self.guard("accept", "run.json", "--event-id", "a1", "--decision", "acc.json")[0], 0)
        self.assertIn("AUTHOR=ACCEPTED", self.summary())
        write(self.dir / "draft.md", DRAFT + "补一句。\n")
        self.assertIn("AUTHOR=NOT_ACCEPTED (an earlier version", self.summary())
        write(self.dir / "acc2.json", json.dumps({"candidate_sha256": sha(self.dir / "draft.md"), "source": "作者", "scope": "全文"}, ensure_ascii=False))
        self.assertIn("never recorded", self.guard("accept", "run.json", "--event-id", "a2", "--decision", "acc2.json")[1])

    def test_machine_review_items_need_an_editorial_decision(self):
        write(self.dir / "original.md", "他伸手去拔刀，没拔动。\n")
        write(self.dir / "draft.md", "他伸手。握住刀柄。拔。没拔动。\n")
        self.start(checks=[{"id": "punct", "type": "punctuation"}])
        no_decision = self.review(evidence=[{"quote": "握住刀柄。拔。没拔动", "in": "candidate"}])
        self.assertIn("must decide every machine review item",
                      self.guard("record", "run.json", "--event-id", "v0", "--review", no_decision)[1])
        state_items = json.loads(self.guard("check", "checks.json")[1])["review_items"]
        item_id = state_items[0]["id"]
        marked_issue = self.review("r2.json", evidence=[{"quote": "握住刀柄。拔。没拔动", "in": "candidate"}],
                                   machine_dispositions=[{"id": item_id, "decision": "issue", "reason": "切碎了连续动作"}])
        self.assertIn("cannot be PASS", self.guard("record", "run.json", "--event-id", "v0", "--review", marked_issue)[1])
        kept = self.review("r3.json", evidence=[{"quote": "握住刀柄。拔。没拔动", "in": "candidate"}],
                           machine_dispositions=[{"id": item_id, "decision": "keep", "reason": "作者指定的顿挫"}])
        self.assertEqual(self.guard("record", "run.json", "--event-id", "v0", "--review", kept)[0], 0)
        stale = self.review("r4.json", evidence=[{"quote": "握住刀柄。拔。没拔动", "in": "candidate"}],
                            machine_dispositions=[{"id": "punct:P10-L9-C1", "decision": "keep", "reason": "旧版留下的裁决"}])
        self.assertIn("REVIEW_STALE", self.guard("record", "run.json", "--event-id", "v9", "--review", stale)[1])

    def test_fact_conflicts_turn_the_machine_gate_red(self):
        shutil.copytree(FIXTURES / "facts", self.dir / "facts")
        self.spec([{"id": "facts", "type": "facts", "ledger": "facts/ledger.json", "claims": "facts/claims-ch12.json"}])
        value = json.loads((self.dir / "checks.json").read_text(encoding="utf-8"))
        value["candidate"] = "facts/chapters/第12章.md"
        write(self.dir / "checks.json", json.dumps(value, ensure_ascii=False))
        self.assertEqual(self.guard("start", "run.json", "--task-id", "t", "--spec", "checks.json")[0], 0)
        report = json.loads(self.guard("check", "checks.json")[1])
        self.assertEqual(report["status"], "RED")
        candidate = self.dir / "facts" / "chapters" / "第12章.md"
        name = self.review(candidate_sha256=sha(candidate), inputs_read=["facts/ledger.json"],
                           evidence=[{"quote": "林舟又翻开登记簿", "in": "candidate"}],
                           machine_dispositions=[{"id": i["id"], "decision": "keep", "reason": "待作者确认这项变化"} for i in report["review_items"]])
        self.assertEqual(self.guard("record", "run.json", "--event-id", "v0", "--review", name)[0], 0)
        self.assertIn("MECHANICAL=RED", self.summary())
        self.assertEqual(json.loads((self.dir / "run.json").read_text(encoding="utf-8"))["current_node"], "repair")

    def test_strict_pass_needs_spread_evidence_and_sources_read(self):
        body = "".join("第%d段，林舟沿着河岸往下走，数着桥墩上的刻痕，记下每一处水位。\n" % i for i in range(1, 16))
        write(self.dir / "original.md", body)
        write(self.dir / "draft.md", body)
        self.start(checks=[{"id": "same", "type": "file_hash", "source": "original.md", "sha256": sha(self.dir / "original.md")}],
                   mode="strict")
        early = [{"quote": "第1段，林舟沿着河岸", "in": "candidate"}, {"quote": "第2段，林舟沿着河岸", "in": "candidate"},
                 {"quote": "第3段，林舟沿着河岸", "in": "candidate"}]
        self.assertIn("beginning, middle and end",
                      self.guard("record", "run.json", "--event-id", "v0", "--review", self.review(evidence=early))[1])
        spread = [{"quote": "第1段，林舟沿着河岸", "in": "candidate"}, {"quote": "第8段，林舟沿着河岸", "in": "candidate"},
                  {"quote": "第15段，林舟沿着河岸", "in": "candidate"}]
        self.assertIn("not read: original.md",
                      self.guard("record", "run.json", "--event-id", "v0", "--review", self.review(evidence=spread, inputs_read=[]))[1])
        self.assertEqual(self.guard("record", "run.json", "--event-id", "v0", "--review",
                                    self.review(evidence=spread, dimensions=self.dims()))[0], 0)

    def test_strict_pass_cannot_be_faked_with_repeated_or_source_quotes(self):
        refrain = "雨还在下，檐下的水一滴一滴落进铁桶。"
        body = "".join("第%d段，林舟数着桥墩上的刻痕，记下第%d处水位。%s\n" % (i, i, refrain) for i in range(1, 13))
        write(self.dir / "original.md", body)
        write(self.dir / "draft.md", body)
        self.start(checks=[{"id": "same", "type": "file_hash", "source": "original.md", "sha256": sha(self.dir / "original.md")}],
                   mode="strict")
        same_quote = [{"quote": refrain, "in": "candidate"}] * 3
        self.assertIn("must be distinct",
                      self.guard("record", "run.json", "--event-id", "v0", "--review", self.review(evidence=same_quote))[1])
        repeated = [{"quote": refrain, "in": "candidate"}, {"quote": "檐下的水一滴一滴", "in": "candidate"},
                    {"quote": "落进铁桶。\n第", "in": "candidate"}]
        self.assertIn("occur exactly once",
                      self.guard("record", "run.json", "--event-id", "v0", "--review", self.review(evidence=repeated))[1])
        from_source = [{"quote": "第1段，林舟数着", "in": "original.md"}, {"quote": "第6段，林舟数着", "in": "original.md"},
                       {"quote": "第12段，林舟数着", "in": "original.md"}]
        self.assertIn("quotes from sources do not count",
                      self.guard("record", "run.json", "--event-id", "v0", "--review", self.review(evidence=from_source))[1])
        unique = [{"quote": "第1段，林舟数着", "in": "candidate"}, {"quote": "第6段，林舟数着", "in": "candidate"},
                  {"quote": "第12段，林舟数着", "in": "candidate"}]
        self.assertEqual(self.guard("record", "run.json", "--event-id", "v0", "--review",
                                    self.review(evidence=unique, dimensions=self.dims()))[0], 0)

    def test_strict_mode_cannot_be_loosened(self):
        checks = [{"id": "keep", "type": "contains", "text": "他没有出声。"}]
        for loosen in ({"min_evidence": 1}, {"spread": False}):
            self.spec(checks, mode="strict", review_policy=loosen)
            code, out, _ = self.guard("start", "run-%s.json" % len(loosen), "--task-id", "t", "--spec", "checks.json")
            self.assertEqual(code, 2)
            self.assertIn("cannot be loosened", out)
        self.spec(checks, mode="strict", review_policy={"min_evidence": 4})
        self.assertEqual(self.guard("check", "checks.json")[0], 0)

    def test_overlapping_or_adjacent_fragments_count_as_one_location(self):
        text = "雨还在下，檐下的水一滴一滴落进铁桶。林舟推开门，院子里站着一个人。那人背着一只竹篓，篓口压着湿草。\n"
        write(self.dir / "original.md", text)
        write(self.dir / "draft.md", text)
        self.start(checks=[{"id": "same", "type": "file_hash", "source": "original.md", "sha256": sha(self.dir / "original.md")}],
                   mode="strict")
        overlapping = [{"quote": q, "in": "candidate"} for q in ("雨还在下，檐下的", "还在下，檐下的水", "在下，檐下的水一")]
        adjacent = [{"quote": q, "in": "candidate"} for q in ("雨还在下，檐", "下的水一滴一", "滴落进铁桶。")]
        separate = [{"quote": q, "in": "candidate"} for q in ("雨还在下，檐下的水", "林舟推开门，院子里", "篓口压着湿草")]
        for name, evidence in (("r-overlap.json", overlapping), ("r-adjacent.json", adjacent)):
            out = self.guard("record", "run.json", "--event-id", "v0", "--review", self.review(name, evidence=evidence))[1]
            self.assertIn("separate locations", out)
            self.assertIn("found 1", out)
        self.assertEqual(self.guard("record", "run.json", "--event-id", "v0",
                                    "--review", self.review("r-ok.json", evidence=separate, dimensions=self.dims()))[0], 0)

    def test_zero_fact_claims_is_untested_not_green(self):
        shutil.copytree(FIXTURES / "facts", self.dir / "facts")
        claims = json.loads((self.dir / "facts" / "claims-ch12.json").read_text(encoding="utf-8"))
        claims["claims"] = []
        write(self.dir / "facts" / "claims-empty.json", json.dumps(claims, ensure_ascii=False))
        for mode in ("strict", "light"):
            self.spec([{"id": "facts", "type": "facts", "ledger": "facts/ledger.json", "claims": "facts/claims-empty.json"}],
                      mode=mode)
            value = json.loads((self.dir / "checks.json").read_text(encoding="utf-8"))
            value["candidate"] = "facts/chapters/第12章.md"
            write(self.dir / "checks.json", json.dumps(value, ensure_ascii=False))
            report = json.loads(self.guard("check", "checks.json")[1])
            self.assertEqual((report["status"], report["untested_checks"]), ("UNTESTED", ["facts"]))
            state = "run-%s.json" % mode
            self.assertEqual(self.guard("start", state, "--task-id", mode, "--spec", "checks.json")[0], 0)
            candidate = self.dir / "facts" / "chapters" / "第12章.md"
            evidence = [{"quote": q, "in": "candidate"} for q in ("林舟又翻开登记簿", "护送的三百银角提前验收", "沈七这几天都在东码头")]
            name = self.review("r-%s.json" % mode, candidate_sha256=sha(candidate), inputs_read=["facts/ledger.json"], evidence=evidence)
            code, out, _ = self.guard("record", state, "--event-id", "v0", "--review", name)
            if mode == "strict":
                self.assertIn("MECHANICAL_UNTESTED", out)
            else:
                self.assertEqual(code, 0, out)
                summary = self.guard("status", state, "--summary")[1]
                self.assertIn("MECHANICAL=UNTESTED(facts not run)", summary)
                self.assertNotIn("MECHANICAL=GREEN", summary)

    def test_summary_names_version_policy_and_kept_flags(self):
        write(self.dir / "original.md", "他伸手去拔刀，没拔动。\n")
        write(self.dir / "draft.md", "他伸手。握住刀柄。拔。没拔动。\n")
        self.start(checks=[{"id": "punct", "type": "punctuation"}])
        item_id = json.loads(self.guard("check", "checks.json")[1])["review_items"][0]["id"]
        short = self.review("r-short.json", evidence=[{"quote": "握住刀柄。拔。没拔动", "in": "candidate"}],
                            machine_dispositions=[{"id": item_id, "decision": "keep", "reason": "保留"}])
        self.assertIn("at least six", self.guard("record", "run.json", "--event-id", "v0", "--review", short)[1])
        kept = self.review("r-kept.json", evidence=[{"quote": "握住刀柄。拔。没拔动", "in": "candidate"}],
                           machine_dispositions=[{"id": item_id, "decision": "keep", "reason": "作者指定的顿挫节奏"}])
        self.assertEqual(self.guard("record", "run.json", "--event-id", "v0", "--review", kept)[0], 0)
        line = self.summary()
        self.assertIn("candidate=draft.md sha256:" + sha(self.dir / "draft.md")[:12], line)
        self.assertIn("policy=light(min_evidence=1,spread=off)", line)
        self.assertIn("1 machine flags kept by reviewer", line)

    def test_self_declared_reviewer_mode_is_labelled_as_unverified(self):
        self.start()
        name = self.review(reviewer={"mode": "human_editor", "label": "人工编辑"})
        self.assertEqual(self.guard("record", "run.json", "--event-id", "v0", "--review", name)[0], 0)
        self.assertIn("审稿方式由审稿记录自报，脚本无法核实", self.summary())

    def test_required_independent_review_rejects_self_check(self):
        self.start(review_policy={"require_independent": True})
        self.assertIn("independent reviewer", self.guard("record", "run.json", "--event-id", "v0", "--review", self.review())[1])
        ok = self.review("r2.json", reviewer={"mode": "independent_agent", "label": "新上下文审稿代理，未见起草过程"})
        self.assertEqual(self.guard("record", "run.json", "--event-id", "v0", "--review", ok)[0], 0)
        self.assertIn("EDITORIAL=PASS[independent_agent]", self.summary())

    # Behaviour carried over from sales-r3 must still hold.
    def test_scope_and_revision_budget_still_enforced(self):
        write(self.dir / "draft.md", "雨停了！\n林舟推开门，院子里站着一个人。\n他没有出声。\n")
        self.start()
        self.assertEqual(json.loads(self.guard("check", "checks.json")[1])["status"], "RED")
        revise = self.review(verdict="NEEDS_REVISION", evidence=[],
                             issues=[{"quote": "雨停了！", "in": "candidate", "expected": "第1行不在可改范围", "impact": "越权修改"}])
        self.assertEqual(self.guard("record", "run.json", "--event-id", "v0", "--review", revise)[0], 0)
        self.assertEqual(self.guard("reserve", "run.json", "--event-id", "r1")[0], 0)
        self.assertEqual(self.guard("reserve", "run.json", "--event-id", "r1")[0], 0)  # idempotent retry
        state = json.loads((self.dir / "run.json").read_text(encoding="utf-8"))
        self.assertEqual(state["budgets"]["revisions_used"], 1)
        self.assertIn("INVALID_ROUTE", self.guard("reserve", "run.json", "--event-id", "r2")[1])

    def test_spread_cannot_be_satisfied_by_repeated_phrases(self):
        # From the r4.2 branch (it adopted this test from an earlier Claude backup): one phrase that
        # recurs on every line, or three recurring phrases, cannot "cover" the text.
        body = "".join("第%d段，林舟沿着河岸往下走，数着桥墩上的刻痕，记下每一处水位。\n" % i for i in range(1, 16))
        write(self.dir / "original.md", body)
        write(self.dir / "draft.md", body)
        self.start(checks=[{"id": "same", "type": "file_hash", "source": "original.md", "sha256": sha(self.dir / "original.md")}],
                   mode="strict")
        same_quote = [{"quote": "林舟沿着河岸往下走", "in": "candidate"}] * 3
        self.assertIn("distinct", self.guard("record", "run.json", "--event-id", "v0", "--review",
                                             self.review(evidence=same_quote))[1])
        recurring = [{"quote": "林舟沿着河岸往下走", "in": "candidate"}, {"quote": "数着桥墩上的刻痕", "in": "candidate"},
                     {"quote": "记下每一处水位", "in": "candidate"}]
        self.assertIn("occur exactly once", self.guard("record", "run.json", "--event-id", "v0", "--review",
                                                       self.review(evidence=recurring))[1])
        self.assertIn("EDITORIAL=UNTESTED", self.summary())

    def test_replan_keeps_budget_and_supersedes_old_inputs(self):
        # Carried over from sales-r3: an author decision re-freezes the inputs without resetting the budget.
        write(self.dir / "draft.md", "雨停了。\n林舟推开门，院子里站着一个人。\n他没有出声，只是看着。\n")
        self.start()
        self.assertEqual(json.loads(self.guard("check", "checks.json")[1])["status"], "RED")
        blocked = self.review(verdict="FAIL", evidence=[],
                              issues=[{"expected": "第3行不在授权范围，需要作者决定", "impact": "无法继续"}])
        self.assertEqual(self.guard("record", "run.json", "--event-id", "v0", "--review", blocked)[0], 0)
        self.assertIn("INVALID_ROUTE", self.guard("reserve", "run.json", "--event-id", "r0")[1])  # blocked: no repair yet
        write(self.dir / "checks2.json", json.dumps({"candidate": "draft.md", "checks": [
            {"id": "scope", "type": "scope", "source": "original.md", "editable_lines": [[2, 3]]}]}, ensure_ascii=False))
        write(self.dir / "decision.json", json.dumps({"author_decision": "允许改第3行", "source": "作者本轮消息：第3行也可以改",
                                                      "affected_scope": "第2—3行"}, ensure_ascii=False))
        self.assertEqual(self.guard("replan", "run.json", "--event-id", "p1", "--spec", "checks2.json",
                                    "--decision", "decision.json")[0], 0)
        self.assertEqual(self.guard("reserve", "run.json", "--event-id", "r1")[0], 0)
        passed = self.review("r-pass.json", evidence=[{"quote": "他没有出声，只是看着", "in": "candidate"}])
        self.assertEqual(self.guard("record", "run.json", "--event-id", "v1", "--review", passed)[0], 0)
        state = json.loads((self.dir / "run.json").read_text(encoding="utf-8"))
        self.assertEqual((state["current_node"], state["budgets"]["revisions_used"], state["budgets"]["max_revisions"]),
                         ("complete", 1, 3))
        self.assertTrue(any(a.get("superseded_by") == "p1" for a in state["artifacts"] if a["role"] == "spec"))
        self.assertEqual([h["action"] for h in state["human_approvals"]], ["replan"])
        self.assertIn("MECHANICAL=GREEN | EDITORIAL=PASS[self_check] | AUTHOR=NOT_ACCEPTED", self.summary())

    def test_replan_cannot_loosen_the_review_policy(self):
        # Audit 2026-10-16: strict -> light through replan used to pass silently. Within one run the policy only tightens.
        checks = [{"id": "keep", "type": "contains", "text": "他没有出声。"}]
        self.start(checks=checks, mode="strict")
        write(self.dir / "decision.json", json.dumps({"author_decision": "改审稿要求", "source": "作者本轮消息",
                                                      "affected_scope": "全文"}, ensure_ascii=False))

        def replan(event, **spec):
            value = {"candidate": "draft.md", "checks": checks}
            value.update(spec)
            write(self.dir / ("spec-%s.json" % event), json.dumps(value, ensure_ascii=False))
            return self.guard("replan", "run.json", "--event-id", event, "--spec", "spec-%s.json" % event,
                              "--decision", "decision.json")

        code, out, _ = replan("p-light")
        self.assertEqual(code, 2)
        self.assertIn("cannot loosen the review policy", out)
        self.assertIn("mode strict -> light", out)
        self.assertEqual(replan("p-tighter", mode="strict", review_policy={"min_evidence": 4})[0], 0)
        code, out, _ = replan("p-back", mode="strict")
        self.assertEqual(code, 2)
        self.assertIn("min_evidence 4 -> 3", out)
        state = json.loads((self.dir / "run.json").read_text(encoding="utf-8"))
        self.assertEqual([h["event_id"] for h in state["human_approvals"]], ["p-tighter"])  # refused replans left no trace

    # r5: governance (CON-005, CON-008), stage summary and permission decisions.
    def gate(self):
        return json.loads(self.guard("status", "run.json")[1])["gate"]

    def test_stage_summary_follows_the_four_states(self):
        self.start()
        self.assertEqual(self.gate()["stage"], "DRAFT")
        self.assertEqual(self.guard("record", "run.json", "--event-id", "v0", "--review", self.review())[0], 0)
        self.assertEqual(self.gate()["stage"], "READY_FOR_AUTHOR")
        write(self.dir / "acc.json", json.dumps({"candidate_sha256": sha(self.dir / "draft.md"),
                                                 "source": "作者：就用这版", "scope": "全文"}, ensure_ascii=False))
        self.assertEqual(self.guard("accept", "run.json", "--event-id", "a1", "--decision", "acc.json")[0], 0)
        self.assertEqual(self.gate()["stage"], "AUTHOR_ACCEPTED")
        write(self.dir / "draft.md", DRAFT + "又加一句。\n")
        self.assertEqual(self.gate()["stage"], "STALE")

    def test_author_may_accept_a_version_the_review_did_not_pass(self):
        # CON-001 outranks the linear chain: acceptance is allowed, the record keeps a warning.
        self.start()
        revise = self.review(verdict="NEEDS_REVISION", evidence=[],
                             issues=[{"quote": "他没有出声。", "in": "candidate", "expected": "更紧", "impact": "节奏"}])
        self.guard("record", "run.json", "--event-id", "v0", "--review", revise)
        self.assertEqual(self.gate()["stage"], "NEEDS_REVISION")
        write(self.dir / "acc.json", json.dumps({"candidate_sha256": sha(self.dir / "draft.md"),
                                                 "source": "作者：不用改了，就这样", "scope": "全文"}, ensure_ascii=False))
        self.assertEqual(self.guard("accept", "run.json", "--event-id", "a1", "--decision", "acc.json")[0], 0)
        gate = self.gate()
        self.assertEqual(gate["stage"], "AUTHOR_ACCEPTED")
        self.assertTrue(any("NEEDS_REVISION" in w for w in gate["stage_warnings"]))

    def test_permissions_follow_the_recorded_state(self):
        self.start()
        perms = self.gate()["permissions"]
        self.assertEqual((perms["claim_reviewed"]["decision"], perms["claim_final"]["decision"]), ("BLOCK", "BLOCK"))
        self.assertEqual(perms["deliver_as_candidate"]["decision"], "ALLOW_WITH_WARNING")
        self.guard("record", "run.json", "--event-id", "v0", "--review", self.review())
        perms = self.gate()["permissions"]
        self.assertEqual(perms["claim_reviewed"]["decision"], "ALLOW_WITH_WARNING")  # self-check must be called a self-check
        self.assertEqual(perms["claim_independent_review"]["decision"], "BLOCK")
        self.assertEqual(perms["claim_final"]["decision"], "BLOCK")
        self.assertIn("CON-001", perms["claim_final"]["rules"])
        write(self.dir / "acc.json", json.dumps({"candidate_sha256": sha(self.dir / "draft.md"),
                                                 "source": "作者：定稿", "scope": "全文"}, ensure_ascii=False))
        self.guard("accept", "run.json", "--event-id", "a1", "--decision", "acc.json")
        perms = self.gate()["permissions"]
        self.assertEqual((perms["claim_final"]["decision"], perms["edit_accepted_text"]["decision"]),
                         ("ALLOW", "REVIEW_REQUIRED"))
        write(self.dir / "draft.md", DRAFT + "又加一句。\n")
        perms = self.gate()["permissions"]
        self.assertEqual((perms["claim_reviewed"]["decision"], perms["claim_final"]["decision"]), ("BLOCK", "BLOCK"))

    def test_constitution_and_checker_versions_are_recorded_and_watched(self):
        # Run a private copy of the scripts so that a checker can be "updated" without touching the package.
        copy = self.dir / "skill"
        shutil.copytree(skill() / "scripts", copy / "scripts")
        for name in ("CONSTITUTION.md", "assets/constitution-rules.json"):
            (copy / name).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(skill() / name, copy / name)
        guard = copy / "scripts" / "workflow_guard.py"
        self.spec([{"id": "punct", "type": "punctuation"}])
        self.assertEqual(run(guard, "start", "run.json", "--task-id", "t", "--spec", "checks.json", cwd=self.dir)[0], 0)
        self.assertEqual(run(guard, "record", "run.json", "--event-id", "v0", "--review", self.review(), cwd=self.dir)[0], 0)
        state = json.loads((self.dir / "run.json").read_text(encoding="utf-8"))
        registry = json.loads((copy / "assets" / "constitution-rules.json").read_text(encoding="utf-8"))
        self.assertEqual(state["governance"]["constitution"]["version"], registry["version"])
        self.assertIn("punctuation_lint", state["evidence"][-1]["machine"]["checkers"])
        gate = json.loads(run(guard, "status", "run.json", cwd=self.dir)[1])["gate"]
        self.assertEqual(gate["governance_warnings"], [])
        with (copy / "scripts" / "punctuation_lint.py").open("ab") as handle:
            handle.write("\n# updated rules\n".encode("utf-8"))
        gate = json.loads(run(guard, "status", "run.json", cwd=self.dir)[1])["gate"]
        # Merged with r4.2: the checker hashes are part of the execution context, so an updated checker
        # makes the old results STALE (stronger than the r5 warning), and nothing may be claimed from them.
        self.assertEqual((gate["mechanical"], gate["editorial"]), ("STALE", "STALE"))
        self.assertEqual(gate["permissions"]["claim_mechanical_pass"]["decision"], "BLOCK")
        self.assertEqual(gate["governance_warnings"], [])
        with (copy / "CONSTITUTION.md").open("ab") as handle:
            handle.write("\n（测试：条文有变）\n".encode("utf-8"))
        gate = json.loads(run(guard, "status", "run.json", cwd=self.dir)[1])["gate"]
        self.assertTrue(any("宪法" in w for w in gate["governance_warnings"]))

    # r5: persistent states, revision comparison, length basis and chapter titles.
    def test_persistent_states_must_be_dispositioned(self):
        ledger = {"schema": "fact-ledger/1", "entities": {"person:lin": {"name": "林舟"}},
                  "chapters": {"1": {"status": "accepted"}},
                  "facts": [{"id": "F1", "entity": "person:lin", "attribute": "injury.右腿", "value": "刀伤，走路拖着", "chapter": 1,
                             "layer": "accepted", "basis": "witnessed_action", "source": "第1章", "persist": True},
                            {"id": "F2", "entity": "person:lin", "attribute": "position", "value": "院外", "chapter": 1,
                             "layer": "accepted", "basis": "witnessed_action", "source": "第1章"}]}
        write(self.dir / "ledger.json", json.dumps(ledger, ensure_ascii=False))
        write(self.dir / "claims.json", json.dumps({"schema": "fact-claims/1", "chapter": 2, "candidate": "draft.md",
                                                     "candidate_sha256": sha(self.dir / "draft.md"), "extracted_by": "self_check",
                                                     "claims": [{"id": "c1", "entity": "person:lin", "attribute": "position",
                                                                 "value": "院外", "basis": "witnessed_action",
                                                                 "quote": "林舟推开门"}]}, ensure_ascii=False))
        self.start([{"id": "facts", "type": "facts", "ledger": "ledger.json", "claims": "claims.json"}])
        report = json.loads(self.guard("check", "checks.json")[1])
        self.assertEqual([i["id"] for i in report["review_items"]], ["facts:W-F1"])
        refused = self.guard("record", "run.json", "--event-id", "v0", "--review", self.review())
        self.assertEqual(refused[0], 2)
        ok = self.review("r2.json", inputs_read=["ledger.json"],
                         machine_dispositions=[{"id": "facts:W-F1", "decision": "keep",
                                                "reason": "本段只写推门和看见，没有走动"}])
        self.assertEqual(self.guard("record", "run.json", "--event-id", "v0", "--review", ok)[0], 0)

    def test_revision_check_reports_what_the_edit_introduced(self):
        write(self.dir / "original.md", "门外传来脚步声，他回头看了一眼，又转回来，把刀按回鞘里。\n“你走！”他说。\n")
        write(self.dir / "draft.md", "门外传来脚步声。他回头。看了一眼。又转回来。把刀按回鞘里。\n“你走。”他说。\n")
        self.start([{"id": "rev", "type": "revision", "source": "original.md"}])
        report = json.loads(self.guard("check", "checks.json")[1])
        self.assertEqual(report["status"], "GREEN")  # nothing objective broke, so it is not RED
        kinds = sorted(i["id"].split(":")[1].split("-")[0] for i in report["review_items"])
        self.assertEqual(kinds, ["P10", "TONE"])
        write(self.dir / "draft.md", "门外传来脚步声...他回头看了一眼。\n“你走！”他说。\n")
        self.assertEqual(json.loads(self.guard("check", "checks.json")[1])["status"], "RED")  # introduced ERROR

    def test_length_basis_and_chapter_title(self):
        write(self.dir / "draft.md", "# 第十二章 雨夜（上）\n\n雨下了一夜。林舟没睡，坐在窗边，听檐水一滴一滴落进铁桶。\n")
        body_han = 24
        self.spec([{"id": "len", "type": "length", "basis": "han", "exclude_headings": True, "min": body_han, "max": body_han},
                   {"id": "all", "type": "length", "min": 1},
                   {"id": "title", "type": "title", "min": 5, "max": 30}])
        report = json.loads(self.guard("check", "checks.json")[1])
        by = {c["id"]: c for c in report["checks"]}
        self.assertEqual((by["len"]["actual"], by["len"]["passed"]), (body_han, True))
        self.assertEqual(by["all"]["expected"]["basis"], "non_whitespace")
        self.assertEqual((by["title"]["actual"]["title"], by["title"]["actual"]["length"], by["title"]["passed"]),
                         ("雨夜（上）", 5, True))
        write(self.dir / "draft.md", "# 第十二章 雨\n\n雨下了一夜。\n")
        by = {c["id"]: c for c in json.loads(self.guard("check", "checks.json")[1])["checks"]}
        self.assertFalse(by["title"]["passed"])

    def test_frozen_source_change_is_detected(self):
        self.start()
        write(self.dir / "original.md", ORIGINAL + "偷偷加一行。\n")
        self.assertIn("INPUT_CHANGED", self.guard("record", "run.json", "--event-id", "v0", "--review", self.review())[1])
        self.assertIn("INPUT_READY=BLOCKED", self.summary())


# ---------------------------------------------------------------------- darwin
class DarwinHarness(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        self.tool = ROOT / "skills" / "darwin-novel-workshop" / "scripts" / "darwin_eval.py"
        for arm, text in (("base", "旧规则"), ("cand", "新规则")):
            write(self.dir / arm / "SKILL.md", text)
        write(self.dir / "work" / "TASKS.json", json.dumps({
            "tasks": [{"id": "dev1", "split": "dev"}, {"id": "hold1", "split": "holdout"}],
            "dimensions": [{"id": "facts", "hard": True}, {"id": "readability", "hard": False}]}))
        for task in ("dev1", "hold1"):
            write(self.dir / "out" / task / "base.md", "基线输出" + task)
            write(self.dir / "out" / task / "cand.md", "候选输出" + task)

    def tearDown(self):
        shutil.rmtree(self.dir)

    def call(self, *args):
        code, out, err = run(self.tool, *args)
        return code, json.loads(out)

    def judge(self, task, winner_arm, dimension_results=None, work=None):
        work = work or self.dir / "work"
        mapping = json.loads((work / "sealed" / (task + ".mapping.json")).read_text(encoding="utf-8"))["mapping"]
        label = {v: k for k, v in mapping.items()}
        dims = dimension_results or {"facts": winner_arm, "readability": winner_arm}
        verdict = {"task": task, "judge": {"mode": "independent_agent", "label": "测试"},
                   "dimensions": {d: {"result": label[a] if a in label else a, "evidence": "引文"} for d, a in dims.items()}}
        write(self.dir / "v.json", json.dumps(verdict, ensure_ascii=False))
        return self.call("verdict", work, "--task", task, "--file", self.dir / "v.json")

    def test_full_cycle_and_merge_rule(self):
        work = self.dir / "work"
        self.assertEqual(self.call("freeze", work, "--baseline", self.dir / "base", "--candidate", self.dir / "cand")[0], 0)
        for task in ("dev1", "hold1"):
            self.assertEqual(self.call("blind", work, "--task", task, "--baseline-output", self.dir / "out" / task / "base.md",
                                       "--candidate-output", self.dir / "out" / task / "cand.md")[0], 0)
        self.assertEqual(self.call("unblind", work, "--task", "dev1")[0], 2)  # no verdict yet
        self.judge("dev1", "candidate")
        self.call("unblind", work, "--task", "dev1")
        self.assertIn("INSUFFICIENT_EVIDENCE", self.call("summarize", work)[1]["decision"])
        self.judge("hold1", "baseline", {"facts": "baseline", "readability": "candidate"})
        self.call("unblind", work, "--task", "hold1")
        summary = self.call("summarize", work)[1]
        self.assertIn("KEEP_BASELINE", summary["decision"])
        self.assertEqual(summary["integrity"]["status"], "OK")
        self.assertEqual(self.judge("hold1", "candidate")[0], 2)  # verdict after reveal refused

    def test_task_dimension_subsets_are_judged_and_gated_on_their_own_dimensions(self):
        # A delivery-note check judged separately from the prose: each holdout task carries only the dimensions
        # it is judged on; the hard-dimension gate applies to those, and a verdict on another dimension is refused.
        work = self.dir / "work"
        write(work / "TASKS.json", json.dumps({
            "tasks": [{"id": "hold1", "split": "holdout", "dimensions": ["facts", "readability"]},
                      {"id": "notes1", "split": "holdout", "dimensions": ["honesty"]}],
            "dimensions": [{"id": "facts", "hard": True}, {"id": "readability", "hard": False},
                           {"id": "honesty", "hard": True}]}))
        write(self.dir / "out" / "notes1" / "base.md", "旧说明")
        write(self.dir / "out" / "notes1" / "cand.md", "新说明")
        self.call("freeze", work, "--baseline", self.dir / "base", "--candidate", self.dir / "cand")
        for task in ("hold1", "notes1"):
            self.assertEqual(self.call("blind", work, "--task", task, "--baseline-output", self.dir / "out" / task / "base.md",
                                       "--candidate-output", self.dir / "out" / task / "cand.md")[0], 0)
        self.assertEqual(self.judge("notes1", "candidate", {"facts": "candidate"})[0], 2)
        self.judge("hold1", "candidate", {"facts": "tie", "readability": "candidate"})
        self.call("unblind", work, "--task", "hold1")
        summary = self.call("summarize", work)[1]
        self.assertIn("INSUFFICIENT_EVIDENCE", summary["decision"])
        self.assertEqual(summary["holdout_hard_gaps"],
                         [{"task": "notes1", "dimension": "honesty", "reason": "not_independently_judged"}])
        self.judge("notes1", "candidate", {"honesty": "candidate"})
        self.call("unblind", work, "--task", "notes1")
        summary = self.call("summarize", work)[1]
        self.assertIn("CANDIDATE_BETTER_ON_HELD_OUT_TASKS", summary["decision"])
        self.assertEqual(summary["holdout"]["improved"], 2)
        self.assertNotIn("honesty", summary["rows"][0]["results"])

    def test_development_tasks_never_decide(self):
        work = self.dir / "work"
        self.call("freeze", work, "--baseline", self.dir / "base", "--candidate", self.dir / "cand")
        for task in ("dev1", "hold1"):
            self.call("blind", work, "--task", task, "--baseline-output", self.dir / "out" / task / "base.md",
                      "--candidate-output", self.dir / "out" / task / "cand.md")
        self.judge("dev1", "candidate")
        self.call("unblind", work, "--task", "dev1")
        self.judge("hold1", "tie", {"facts": "tie", "readability": "tie"})
        self.call("unblind", work, "--task", "hold1")
        summary = self.call("summarize", work)[1]
        self.assertIn("NO_CLEAR_IMPROVEMENT", summary["decision"])
        self.assertEqual((summary["dev"]["improved"], summary["holdout"]["improved"]), (2, 0))

    # r5: CON-007 — Darwin may not change the constitution without the author's approval; old versions stay restorable.
    def run_holdout_win(self, work, *freeze_extra):
        self.assertEqual(self.call("freeze", work, "--baseline", self.dir / "base", "--candidate", self.dir / "cand",
                                   *freeze_extra)[0], 0)
        self.call("blind", work, "--task", "hold1", "--baseline-output", self.dir / "out" / "hold1" / "base.md",
                  "--candidate-output", self.dir / "out" / "hold1" / "cand.md")
        self.judge("hold1", "candidate", {"facts": "tie", "readability": "candidate"}, work=work)
        self.call("unblind", work, "--task", "hold1")
        return self.call("summarize", work)[1]

    def test_constitution_change_needs_author_approval(self):
        write(self.dir / "base" / "novel-workshop" / "CONSTITUTION.md", "宪法 1.1：候选稿不能越权成为定本。")
        write(self.dir / "cand" / "novel-workshop" / "CONSTITUTION.md", "宪法 1.2：候选稿评分高时可以自动成为定本。")
        blocked = self.run_holdout_win(self.dir / "work")
        self.assertTrue(blocked["decision"].startswith("BLOCKED_CONSTITUTION_CHANGE"), blocked["decision"])
        self.assertEqual(blocked["governance"]["changed"], ["novel-workshop/CONSTITUTION.md"])
        write(self.dir / "approval.json", json.dumps({"author_decision": "同意按 1.2 试行", "source": "作者 10-14 消息",
                                                      "scope": "CON-001 的例外条款"}, ensure_ascii=False))
        write(self.dir / "work2" / "TASKS.json", (self.dir / "work" / "TASKS.json").read_text(encoding="utf-8"))
        approved = self.run_holdout_win(self.dir / "work2", "--constitution-approval", self.dir / "approval.json")
        self.assertTrue(approved["decision"].startswith("CANDIDATE_BETTER"), approved["decision"])
        self.assertTrue(approved["governance"]["approved"])

    def test_frozen_arms_are_kept_as_restorable_snapshots(self):
        work = self.dir / "work"
        frozen = self.call("freeze", work, "--baseline", self.dir / "base", "--candidate", self.dir / "cand")[1]
        self.assertIn("baseline", frozen["snapshots"])
        code, restored = self.call("restore", work, "--arm", "baseline", "--to", self.dir / "back")
        self.assertEqual((code, restored["tree_sha256"]), (0, frozen["baseline"]["tree_sha256"]))
        self.assertEqual((self.dir / "back" / "SKILL.md").read_text(encoding="utf-8"), "旧规则")
        self.assertEqual(self.call("restore", work, "--arm", "baseline", "--to", self.dir / "back")[0], 2)  # never overwrites
        with (work / frozen["snapshots"]["candidate"]["file"]).open("ab") as handle:
            handle.write(b"tamper")
        self.assertEqual(self.call("verify", work)[1]["status"], "COMPROMISED")

    def test_tampering_and_changed_arms_are_detected(self):
        work = self.dir / "work"
        self.call("freeze", work, "--baseline", self.dir / "base", "--candidate", self.dir / "cand")
        self.call("blind", work, "--task", "dev1", "--baseline-output", self.dir / "out" / "dev1" / "base.md",
                  "--candidate-output", self.dir / "out" / "dev1" / "cand.md")
        write(work / "sealed" / "dev1.mapping.json", "{}")
        write(self.dir / "cand" / "SKILL.md", "偷偷改了")
        report = self.call("verify", work)[1]
        self.assertEqual((report["status"], report["candidate"], report["seals"]), ("COMPROMISED", "CHANGED", "BROKEN"))


# ------------------------------------------------------------- installer (r5)
class Installer(unittest.TestCase):
    """CON-008: an upgrade keeps the previous version, and installing the old package again rolls back."""

    def setUp(self):
        self.base = Path(tempfile.mkdtemp())
        # On POSIX a backslash is an ordinary character in a folder name, and the installer's JSON report escapes it
        # just as it escapes the separators of a Windows path; so a raw-text search for the path fails here too, the
        # way it did on the author's Windows run of r5.24 (r5.25).
        self.dir = self.base / ("安装\\测试" if os.name == "posix" else "安装测试")
        self.dir.mkdir()

    def tearDown(self):
        shutil.rmtree(self.base)

    def package(self, name, marker):
        root = self.dir / name
        files = {"skills/novel-workshop/SKILL.md": "工坊 " + marker, "skills/darwin-novel-workshop/SKILL.md": "维护 " + marker}
        for relative, text in files.items():
            write(root / relative, text)
        shutil.copy2(ROOT / "install.py", root / "install.py")
        manifest = {"schema_version": 1, "files": {r: sha(root / r) for r in files},
                    "components": {"novel-workshop": {"path": "skills/novel-workshop"},
                                   "darwin-novel-workshop": {"path": "skills/darwin-novel-workshop"}}}
        write(root / "PACKAGE-MANIFEST.json", json.dumps(manifest))
        return root / "install.py"

    def test_upgrade_keeps_a_backup_and_old_package_rolls_back(self):
        old, new, dest = self.package("old", "旧版"), self.package("new", "新版"), self.dir / "skills"
        installed = dest / "novel-workshop" / "SKILL.md"
        self.assertEqual(run(old, "--dest", dest)[0], 0)
        code, _, err = run(new, "--dest", dest)
        self.assertEqual(code, 1)  # a different installed version is never overwritten silently
        self.assertIn("--upgrade", err)
        self.assertEqual(run(new, "--dest", dest, "--upgrade", "--dry-run")[0], 0)
        self.assertEqual(installed.read_text(encoding="utf-8"), "工坊 旧版")  # dry run wrote nothing
        code, out, err = run(new, "--dest", dest, "--upgrade")
        self.assertEqual(code, 0, err)
        self.assertEqual(installed.read_text(encoding="utf-8"), "工坊 新版")
        backups = sorted((dest / ".novel-workshop-backups").glob("*/novel-workshop/SKILL.md"))
        self.assertEqual([b.read_text(encoding="utf-8") for b in backups], ["工坊 旧版"])
        # The report is JSON: on Windows the path's backslashes are escaped there, so compare the parsed value (r5.25).
        self.assertTrue(os.path.samefile(json.loads(out)["backup"], backups[0].parent.parent), out)
        self.assertEqual(run(old, "--dest", dest, "--upgrade")[0], 0)  # rollback = install the old package again
        self.assertEqual(installed.read_text(encoding="utf-8"), "工坊 旧版")
        backups = sorted(b.read_text(encoding="utf-8") for b in (dest / ".novel-workshop-backups").glob("*/novel-workshop/SKILL.md"))
        self.assertEqual(backups, ["工坊 新版", "工坊 旧版"])

    # Fault injection (audit 2026-10-16): the rollback path must restore the old version and leave nothing new behind.
    def load_installer(self, script):
        spec = importlib.util.spec_from_file_location("installer_" + script.parent.name, script)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def test_failed_upgrade_puts_the_old_version_back(self):
        old, new, dest = self.package("old", "旧版"), self.package("new", "新版"), self.dir / "skills"
        self.assertEqual(run(old, "--dest", dest)[0], 0)
        module, real_rename, calls = self.load_installer(new), os.rename, []

        def failing_rename(src, dst):
            calls.append(dst)
            if len(calls) == 4:  # backup 1, place 1, backup 2, place 2: fail while placing the second skill
                raise OSError("simulated failure")
            return real_rename(src, dst)

        with unittest.mock.patch.object(module.os, "rename", failing_rename):
            with self.assertRaises(OSError):
                module.install(new.parent, dest, upgrade=True)
        for name, label in (("novel-workshop", "工坊"), ("darwin-novel-workshop", "维护")):
            self.assertEqual((dest / name / "SKILL.md").read_text(encoding="utf-8"), label + " 旧版")
        self.assertFalse((dest / ".novel-workshop-install.lock").exists())

    def test_failed_mixed_install_leaves_no_new_folder_behind(self):
        old, new, dest = self.package("old", "旧版"), self.package("new", "新版"), self.dir / "skills"
        self.assertEqual(run(old, "--dest", dest)[0], 0)
        shutil.rmtree(dest / "darwin-novel-workshop")  # only one of the two skills was installed before
        module = self.load_installer(new)
        real = module.regular_files

        def broken(path):
            if Path(path) == dest / "darwin-novel-workshop":
                return {}  # the final check after placing it sees the wrong content
            return real(path)

        with unittest.mock.patch.object(module, "regular_files", broken):
            with self.assertRaises(ValueError):
                module.install(new.parent, dest, upgrade=True)
        self.assertEqual((dest / "novel-workshop" / "SKILL.md").read_text(encoding="utf-8"), "工坊 旧版")
        self.assertFalse((dest / "darwin-novel-workshop").exists())


# ---------------------------------------------------------- constitution (r5)
class Constitution(unittest.TestCase):
    """CON-008: every rule points to places that exist, and every hard rule has an executable check."""

    @classmethod
    def setUpClass(cls):
        cls.text = (skill() / "CONSTITUTION.md").read_text(encoding="utf-8")
        cls.registry = json.loads((skill() / "assets" / "constitution-rules.json").read_text(encoding="utf-8"))
        cls.cases = json.loads((HERE / "regression-cases.json").read_text(encoding="utf-8"))

    def test_registry_and_text_agree(self):
        ids = [r["id"] for r in self.registry["rules"]]
        # NWC-1.3 (2026-10-22, approved by the author): CON-011 was added after the ten; NWC-1.4 (2026-10-23, r5.33,
        # approved by the author): CON-012.
        self.assertEqual(ids, ["CON-%03d" % n for n in range(1, 13)])
        self.assertIn(self.registry["version"], self.text)
        for rule in self.registry["rules"]:
            self.assertIn(rule["id"], self.text)
        self.assertIn("CONSTITUTION.md", (skill() / "SKILL.md").read_text(encoding="utf-8"))

    @staticmethod
    def reference_exists(name):
        """Class.method in this file, or module.Class.method in another tests/test_*.py module."""
        parts = name.split(".")
        if len(parts) == 2:
            cls = globals().get(parts[0])
        else:
            location = HERE / (parts[0] + ".py")
            if not location.is_file():
                return False
            spec = importlib.util.spec_from_file_location("registry_" + parts[0], location)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            cls = getattr(module, parts[1], None)
        return isinstance(cls, type) and parts[-1] in cls.__dict__

    def test_every_reference_exists_and_hard_rules_are_executable(self):
        for rule in self.registry["rules"]:
            kinds = set()
            for ref in rule["enforced_by"]:
                kinds.add(ref["type"])
                if ref["type"] == "doc":  # paths are relative to skills/
                    text = (ROOT / "skills" / ref["file"]).read_text(encoding="utf-8")
                    self.assertIn(ref["section"], text, (rule["id"], ref))
                elif ref["type"] == "script":
                    text = (ROOT / "skills" / ref["file"]).read_text(encoding="utf-8")
                    self.assertIn(ref["contains"], text, (rule["id"], ref))
                elif ref["type"] == "test":
                    self.assertTrue(self.reference_exists(ref["name"]), (rule["id"], ref))
                else:
                    self.fail("unknown reference type %s in %s" % (ref["type"], rule["id"]))
            self.assertIn("doc", kinds, rule["id"])
            if rule["kind"] == "hard":
                self.assertTrue(kinds & {"script", "test"}, rule["id"] + " is hard but nothing executes it")

    def test_darwin_protects_the_files_the_registry_names(self):
        darwin = (ROOT / "skills" / "darwin-novel-workshop" / "scripts" / "darwin_eval.py").read_text(encoding="utf-8")
        for path in self.registry["protected_files"]:
            self.assertIn(path, darwin)

    def test_regression_cases_point_to_tests_or_review_rules(self):
        self.assertEqual([c["id"] for c in self.cases["cases"]], list("ABCDEFGHIJKLMNOPQRS"))  # O-S: r5.24
        rule_ids = {r["id"] for r in self.registry["rules"]}
        for case in self.cases["cases"]:
            self.assertTrue(set(case["rules"]) <= rule_ids, case["id"])
            self.assertTrue(case["tests"] or case["editorial"], case["id"])
            for name in case["tests"]:
                self.assertTrue(self.reference_exists(name), (case["id"], name))
            for ref in case["editorial"]:
                text = (ROOT / "skills" / ref["file"]).read_text(encoding="utf-8")
                self.assertIn(ref["section"], text, (case["id"], ref))


# ------------------------------------------------------------------- package
class Package(unittest.TestCase):
    def test_existing_tools_still_run(self):
        with tempfile.TemporaryDirectory() as tmp:
            text = write(Path(tmp) / "a.md", "他走了。\n\n【待补：钥匙在哪】\n")
            code, out, _ = run("prose_lint.py", text)
            self.assertEqual((code, json.loads(out)["status"]), (0, "REVIEW"))
            state = Path(tmp) / "story-state.json"
            code, out, err = run("project_state.py", "init", state, "--project-id", "t")
            if project_state_supported():
                self.assertEqual(code, 0, out + err)
                self.assertEqual(json.loads(run("project_state.py", "read", state)[1])["revision"], 0)
            else:
                # Native Windows (no fcntl): refused with the documented reason, nothing written (r5.25).
                self.assertNotEqual(code, 0)
                self.assertIn("unsupported_platform", out + err)
                self.assertFalse(state.exists())

    def test_sale_export_contains_new_modules_and_no_project_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "sale.zip"
            code, out, err = run("export_portable.py", target, "--mode", "sale")
            self.assertEqual(code, 0, out + err)
            import zipfile
            names = zipfile.ZipFile(target).namelist()
            for required in ("novel-workshop/references/chinese-punctuation.md", "novel-workshop/scripts/punctuation_lint.py",
                             "novel-workshop/scripts/fact_guard.py", "novel-workshop/assets/fact-ledger-template.json",
                             "novel-workshop/CONSTITUTION.md", "novel-workshop/assets/constitution-rules.json"):
                self.assertIn(required, names)
            self.assertFalse([n for n in names if "project-packs" in n])
            portable = zipfile.ZipFile(target).read("portable-novel-workshop.md").decode("utf-8")
            self.assertEqual(re.findall(r"\]\((?!https?:)[^)\s]+\)", portable), [])
            # The constitution sits right after the skill entry and the gate card, near the top of the single file.
            self.assertLess(portable.index("# 小说写作工坊宪法"), portable.index("内嵌内容：assets/fact-ledger-template.json"))

    def test_manifest_and_internal_links(self):
        manifest_path = ROOT / "PACKAGE-MANIFEST.json"
        if not manifest_path.exists():
            self.skipTest("not an assembled release")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for relative, digest in manifest["files"].items():
            self.assertEqual(sha(ROOT / relative), digest, relative)
        listed = set(manifest["files"]) | {"PACKAGE-MANIFEST.json"}
        actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file() and "__pycache__" not in p.parts}
        self.assertEqual(actual - listed, set())
        link = re.compile(r"\]\(\s*<?([^)\s>]+)>?\s*\)")
        for md in ROOT.rglob("*.md"):
            if "__pycache__" in md.parts:
                continue
            text = re.sub(r"```.*?```", "", md.read_text(encoding="utf-8"), flags=re.S)
            text = re.sub(r"`[^`\n]*`", "", text)
            for target in link.findall(text):
                if re.match(r"^[a-z]+:", target) or target.startswith("#"):
                    continue
                self.assertTrue((md.parent / target.split("#")[0]).exists(), "%s -> %s" % (md.relative_to(ROOT), target))

    def test_installer_ignores_python_caches(self):
        if not (ROOT / "PACKAGE-MANIFEST.json").exists():
            self.skipTest("not an assembled release")
        with tempfile.TemporaryDirectory() as tmp:
            package = Path(tmp) / "pkg"
            shutil.copytree(ROOT, package)
            cache = package / "skills" / "novel-workshop" / "scripts" / "__pycache__"
            cache.mkdir(exist_ok=True)
            (cache / "punctuation_lint.cpython-3.pyc").write_bytes(b"cache")
            code, out, err = run(package / "install.py", "--dest", Path(tmp) / "skills")
            self.assertEqual(code, 0, out + err)
            self.assertFalse((Path(tmp) / "skills" / "novel-workshop" / "scripts" / "__pycache__").exists())

    def test_installer_dry_run(self):
        installer = ROOT / "install.py"
        if not (ROOT / "PACKAGE-MANIFEST.json").exists():
            self.skipTest("not an assembled release")
        with tempfile.TemporaryDirectory() as tmp:
            code, out, err = run(installer, "--dest", Path(tmp) / "skills", "--dry-run")
            self.assertEqual(code, 0, out + err)
            self.assertEqual({s["name"] for s in json.loads(out)["skills"]}, {"novel-workshop", "darwin-novel-workshop"})


def main():
    global ROOT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-root", type=Path, default=ROOT)
    parser.add_argument("-v", "--verbose", action="store_true")
    args, rest = parser.parse_known_args()
    ROOT = args.package_root.resolve()
    os.environ["NW_PACKAGE_ROOT"] = str(ROOT)
    suite = unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    # Every tests/test_*.py module is part of the same run; never count a module twice by also running it alone.
    suite.addTests(unittest.defaultTestLoader.discover(str(HERE), pattern="test_*.py", top_level_dir=str(HERE)))
    # A personal build also carries private regression tests inside its project packs (never in the commercial build).
    packs = ROOT / "skills" / "novel-workshop" / "assets" / "project-packs"
    for folder in sorted(packs.glob("*/tests")) if packs.is_dir() else []:
        suite.addTests(unittest.defaultTestLoader.discover(str(folder), pattern="test_*.py", top_level_dir=str(folder)))
    result = unittest.TextTestRunner(verbosity=2 if args.verbose else 1).run(suite)
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""写完一章跑一遍：查禁用词、限定词、转场套话、AI腔，以及身份锁里能按字面查的项（61视觉词、65血肉词）。

用法：
  python scripts/lint_text.py 第012章.txt --engines 21 02 50 --book 06
  python scripts/lint_text.py 第012章.txt --engines 21 02 50 --profile ../本书设定.yaml
  python scripts/lint_text.py 正文/*.txt --book 61 --numbers
  cat 草稿.txt | python scripts/lint_text.py - --engines 05
--engines 填本章加载的引擎，--book 填本书锁定的L1。两者合起来决定：限定词能不能用、要不要查61和65的身份锁。
--profile 读本书设定档（需要 PyYAML），取其中的 L1、extra_ban、extra_allow。
--ban / --allow 临时加禁用词、放行词（比如人名里带「灵瞳」）。
--numbers 另外列出叙述里带单位的数字，逐个核对是否出自仪器、面板或官方口径（只提示，不算问题）。
退出码：0 没有问题；1 有命中。只用标准库。
"""
import argparse
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import G, label, load_profile, norm, read_text  # noqa: E402

LEX = G["lexicon"]
CLAUSE = r"[^，。！？；：\n]"
AI_ESE = [
    (rf"被{CLAUSE}{{1,15}}所(?!在|有|以|谓|属|得|需|向|能|长|知)", "「被……所……」冗余结构：动词直接作用于宾语"),
    (rf"做出了?一个{CLAUSE}{{1,12}}的动作", "「做出了一个……的动作」：直接写动作"),
    (r"(这一刻|那一刻|此刻)[^。！？\n]{0,20}(终于|才|彻底)(明白|懂得|理解|领悟)", "总结升华：删掉，停在动作或画面上"),
    (r"(这就是|这便是|原来这就是)[^。！？\n]{0,12}(真谛|意义|力量|武道)", "总结升华：删掉，停在动作或画面上"),
    (r"不仅(仅)?是[^。！？\n]{1,20}更是", "「不仅是……更是……」式升华"),
    (r"快如闪电|眨眼之间", "L0：速度改写声画剥离、空气压缩、视觉抽帧"),
    (r"山崩地裂", "L0：破坏标尺改用玻璃幕墙、承重柱、车载警报"),
    (r"全场(一片)?(哗然|死寂|震惊)", "围观震惊：L0改用仪器失灵、器物形变侧写"),
    (r"空气(仿佛|似乎|好像)?都?凝固", "套话：换成可感的物理细节"),
    (r"眼中闪过一丝", "AI腔：直接写动作或生理反应"),
]
STRUCT_FIX = "转场套话：删掉，用动作或镜头直接切"
LOCK_WORDS = {
    "61": (["看见", "看到", "看清", "望去", "望着", "瞥见", "目光", "视线", "映入眼帘", "颜色", "红光", "金光", "白光", "蓝光", "脸色"],
           "61身份锁：主角视角不用视觉词，换成听、触、嗅（写配角视角可忽略）"),
    "65": (["流血", "汗", "喘", "心跳", "心脏", "肺", "呼吸"],
           "65身份锁：主角没有血肉，写成冷却液泄漏、液压排压、散热片发红（写别人可忽略）"),
}
NUM = r"[0-9０-９.．]+|[零一二两三四五六七八九十百千万亿点]+"
UNIT = r"吨|公斤|千克|斤|马赫|米每秒|米/秒|公里每小时|千米每小时|km/h|焦耳|千焦|兆焦|千卡|大卡|兆帕|千帕|千牛|万伏|千伏|伏特|赫兹|分贝|西弗|摄氏度|℃|%"
NUMBER = re.compile(rf"(?:{NUM})\s*(?:{UNIT})")
QUOTED = re.compile(r"【[^】]*】|「[^」]*」|“[^”]*”|『[^』]*』")


def mask(line, words):
    for w in sorted(words, key=len, reverse=True):
        line = line.replace(w, "□" * len(w))
    return line


def spans(line, words):
    """例外词（lexicon.ban_except）在这一行里占的位置。"""
    out = []
    for w in words:
        start = line.find(w)
        while start != -1:
            out.append((start, start + len(w)))
            start = line.find(w, start + 1)
    return out


def found(line, w, skip):
    """w 在这一行里至少有一处不落在例外词里（「不知道心里」里的「道心」不算）。"""
    start = line.find(w)
    while start != -1:
        if not any(a <= start and start + len(w) <= b for a, b in skip):
            return True
        start = line.find(w, start + 1)
    return False


def lint(text, loaded, extra_ban, extra_allow, numbers):
    scoped = {}
    for num, words in LEX["scoped"].items():
        for w in words:
            scoped.setdefault(w, set()).add(num)
    allowed = {w for w, nums in scoped.items() if nums & loaded} | set(extra_allow)
    ban = [w for w in dict.fromkeys(LEX["ban"] + extra_ban) if w not in scoped]
    issues, hints = [], []
    for i, raw in enumerate(text.splitlines(), 1):
        line = mask(raw, allowed)
        skip = spans(line, LEX.get("ban_except", []))
        for w in ban:
            if found(line, w, skip):
                rep = LEX["replace"].get(w)
                issues.append((i, "禁用词", w, f"换成「{rep}」" if rep else "删掉或改写"))
        for w, nums in scoped.items():
            if found(line, w, skip):
                issues.append((i, "限定词", w, f"只在{'、'.join(map(label, sorted(nums, key=int)))}加载时可用"))
        for w in G.get("structure_bans", []):
            pat = "只见(?!过|到|了)" if w == "只见" else re.escape(w)
            if re.search(pat, line):
                issues.append((i, "转场", w, STRUCT_FIX))
        for pat, why in AI_ESE:
            for m in re.finditer(pat, line):
                issues.append((i, "AI腔", m.group(0), why))
        for num, (words, why) in LOCK_WORDS.items():
            if num in loaded:
                for w in words:
                    if w in line:
                        issues.append((i, "身份锁", w, why))
        if numbers:
            for m in NUMBER.finditer(QUOTED.sub("", line)):
                hints.append((i, "数字", m.group(0), "核对出处：只能由仪器、面板、官方口径说出"))
    return issues, hints


def main():
    ap = argparse.ArgumentParser(description="检查正文")
    ap.add_argument("files", nargs="+", help="正文文件（txt/md），- 表示从标准输入读")
    ap.add_argument("--engines", nargs="*", default=[], help="本章加载的引擎编号")
    ap.add_argument("--book", nargs="*", default=[], help="本书锁定的L1")
    ap.add_argument("--profile", help="本书设定档")
    ap.add_argument("--ban", nargs="*", default=[], help="额外禁用词")
    ap.add_argument("--allow", nargs="*", default=[], help="放行词")
    ap.add_argument("--numbers", action="store_true", help="列出叙述里带单位的数字")
    args = ap.parse_args()

    loaded = {norm(n) for n in args.engines + args.book}
    extra_ban, extra_allow = list(args.ban), list(args.allow)
    if args.profile:
        prof = load_profile(args.profile)
        loaded |= set(prof["L1"])
        extra_ban += prof["extra_ban"]
        extra_allow += prof["extra_allow"]

    total = 0
    for f in args.files:
        text = read_text(f)
        issues, hints = lint(text, loaded, extra_ban, extra_allow, args.numbers)
        if len(args.files) > 1:
            print(f"== {f}")
        for i, kind, hit, fix in issues:
            print(f"第{i}行 [{kind}] {hit} → {fix}")
        for i, kind, hit, fix in hints:
            print(f"第{i}行 [{kind}·提示] {hit} → {fix}")
        if issues:
            kinds = {}
            for _, kind, _, _ in issues:
                kinds[kind] = kinds.get(kind, 0) + 1
            print(f"共{len(issues)}处：" + "，".join(f"{k}{v}" for k, v in kinds.items()))
        else:
            print("没有命中。")
        total += len(issues)
    sys.exit(1 if total else 0)


if __name__ == "__main__":
    main()

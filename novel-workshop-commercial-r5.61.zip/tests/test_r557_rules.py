#!/usr/bin/env python3
"""r5.57: two kinds of task the author decided on 11-14, written down once each, and one title fixed.

1. Fidelity conversion (保真转换): the author only wants the format changed -- a chapter title added, Markdown or plain
   text, line breaks and paragraph indents, another file format -- and no wording changed, punctuation included.
   Full-width and half-width forms and the use of punctuation are not part of it: they go by the punctuation page, and a
   platform's half-width forms the author asks for become a rule of the book. It is defined once, in editing.md under
   "先定范围"; SKILL.md, chapter-confirmation.md, author-preferences.md, file-delivery.md, quality-loop.md and (after
   the r5.57 review) the revision card point there. The delivery gate card does not: it has a byte budget and a pinned
   hash (test_r554_dialogue.py), so a pointer there is the maintainer's decision.
   The delivery says "格式检查通过，文学质量未审" and what was checked with what; the delivery gate has no "the words did
   not change" check, so a GREEN machine check is not a fidelity check.
2. The author takes an acceptance back (作者收回采纳): written once, in quality-loop.md under "交付状态", with the
   chapter gate's reopen of the final stage, the fact ledger set back to candidate and fact_guard.py impact, the learning
   pages' rule in their words, and what workflow_guard.py cannot do yet (it has no command for it; the program part is
   left for later, no script changes in r5.57). chapter-confirmation.md points there.
3. EXAMPLES.md's title says how many examples there are (it said 二十六 while the page had thirty).

What the pages say the scripts do was run on synthetic text while writing r5.57 and again in the review; the tests
below run part of it again (the cases a reviewer found the first wording got wrong or left out among them), so a change
in a script's behaviour shows up here and the page has to be read again. Some sentences are pinned word for word; a new
sentence that says the opposite somewhere else is not caught here and is left to the sentence-by-sentence check before
release. These tests check wording and tool behaviour only. They do not show that the workshop handles these tasks
well, or that anything writes better.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
SCRIPTS = SKILL / "scripts"
POINTER = "editing.md)“先定范围”里的“保真转换”"
POINTING_PAGES = ("SKILL.md", "references/chapter-confirmation.md", "references/author-preferences.md",
                  "references/file-delivery.md", "references/quality-loop.md", "assets/revision-card.md")
OLD_NAMES = ("逐字保真排版", "逐字保留排版")


def read(path):
    return path.read_text(encoding="utf-8")


def page(rel):
    return read(SKILL / rel)


def rule_pages():
    """The skill's own Markdown pages (style packs and project packs carry other people's text)."""
    for path in sorted(SKILL.rglob("*.md")):
        if "style-packs" not in path.parts and "project-packs" not in path.parts:
            yield path


def fidelity_block():
    text = page("references/editing.md")
    start = text.index("**保真转换：只换格式，不动字句（r5.57）。**")
    return text[start:text.index("**再分三样（r5.50）。**", start)]


def withdrawal_block():
    text = page("references/quality-loop.md")
    start = text.index("- **作者收回采纳（r5.57）。**")
    end = text.index("\n- EDITORIAL 要写明审稿方式。", start)
    return text[start:end]


def run(*args, cwd=None):
    return subprocess.run([sys.executable, "-I", "-B", *map(str, args)], capture_output=True, text=True,
                          encoding="utf-8", cwd=cwd)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, text):
    """Fixtures are written as UTF-8 bytes, so a Windows run sees the same line breaks (test_r525_windows.py)."""
    Path(path).write_bytes(text.encode("utf-8"))


def write_json(path, value):
    save(path, json.dumps(value, ensure_ascii=False))


ORIGINAL = ("　　雨停的时候，周岚把船绳绕上第三根桩子。码头上只剩一盏灯，灯罩裂了一道缝。\n"
            "　　“还有两箱。”老韩说，“天亮以前得搬完。”\n"
            "　　她没接话，弯腰去抬箱子。箱子比她想的轻，里面的东西\n"
            "晃了一下，像是半空。\n"
            "　　老韩看了她一眼，把烟掐了。\n")
CONVERTED = ("# 第三章 渡口\n\n"
             "雨停的时候，周岚把船绳绕上第三根桩子。码头上只剩一盏灯，灯罩裂了一道缝。\n\n"
             "“还有两箱。”老韩说，“天亮以前得搬完。”\n\n"
             "她没接话，弯腰去抬箱子。箱子比她想的轻，里面的东西晃了一下，像是半空。\n\n"
             "老韩看了她一眼，把烟掐了。\n")


def chinese_number(n):
    digits = "零一二三四五六七八九"
    if n < 10:
        return digits[n]
    tens, ones = divmod(n, 10)
    return ("" if tens == 1 else digits[tens]) + "十" + (digits[ones] if ones else "")


class FidelityConversionIsDefinedOnce(unittest.TestCase):
    def test_editing_defines_it_where_the_scope_is_set(self):
        text = page("references/editing.md")
        scope = text.index("**先定范围（r5.48）。**")
        block_at = text.index("**保真转换：只换格式，不动字句（r5.57）。**")
        self.assertLess(scope, block_at)
        self.assertLess(block_at, text.index("**再分三样（r5.50）。**"))
        self.assertIn("- “只换格式”“加个章标题”“转成 Markdown”“调一下换行”“导出成 Word”这类、字句不用改的，按下面的保真转换。",
                      text[scope:block_at])
        block = fidelity_block()
        for phrase in ("作者只要换格式、不要改字句的，算单独一类任务，叫保真转换。别的页说到这类任务，都指这里。",
                       "加章标题，转成 Markdown 或纯文本，调换行和段首缩进，换文件格式（比如导出成 Word、PDF）。",
                       "不动字句，也不动标点", "严格保义润色可以动措辞，保真转换不动",
                       "照[每章七阶段与作者确认](chapter-confirmation.md)“不扩大”办，不补走七个阶段"):
            self.assertIn(phrase, block)

    def test_no_other_page_has_its_own_wording(self):
        for path in rule_pages():
            text = read(path)
            rel = path.relative_to(SKILL).as_posix()
            for old in OLD_NAMES:
                self.assertNotIn(old, text, rel)
            if rel != "references/editing.md":
                for phrase in ("不动字句，也不动标点", "**保真转换", "单独一类任务，叫保真转换"):
                    self.assertNotIn(phrase, text, rel)

    def test_every_other_mention_points_to_the_definition(self):
        for rel in POINTING_PAGES:
            self.assertIn("保真转换", page(rel), rel)
        for path in rule_pages():
            rel = path.relative_to(SKILL).as_posix()
            if rel == "references/editing.md":
                continue
            for line in read(path).splitlines():
                if "保真转换" in line:
                    self.assertIn(POINTER, line, rel)

    def test_full_and_half_width_forms_are_not_part_of_it(self):
        block = fidelity_block()
        for phrase in ("**全角半角、标点用法不算在内**：要改这些的，照[中文标点](chinese-punctuation.md)办",
                       "作者为了某个发布平台明确要半角的，照作者当前的决定记成这本书的规则", "也不算保真转换"):
            self.assertIn(phrase, block)
        line = next(l for l in page("SKILL.md").splitlines() if "保真转换" in l)
        self.assertIn("全角半角和标点不算在内，照 [中文标点](references/chinese-punctuation.md)", line)

    def test_the_delivery_says_what_was_checked(self):
        block = fidelity_block()
        for phrase in ("写“格式检查通过，文学质量未审”，再写实际核了什么、用什么核的", "没核的写没核。",
                       # r5.57 review: the sentence said the gate had no check of this kind at all; its scope check
                       # compares whole lines, which is close but is no fidelity check, so the page now says both.
                       "交付门里没有专门核“去掉格式以后字句没变”的检查：MECHANICAL 是 GREEN，只说明声明的那几项检查过了，不说明保真核过",
                       "`scope` 检查只按整行逐字比，去掉缩进、调了换行，整篇都算改动",
                       "没有一样能单独证明逐字相同", "不能运行脚本的，写明是人工逐句对照。"):
            self.assertIn(phrase, block)
        self.assertIn("保真转换（只换格式、不动字句）也这样写，另写明核了什么、用什么核的", page("references/quality-loop.md"))


class ToolCase(unittest.TestCase):
    """Synthetic files in a temporary folder and the scripts run on them, the way the pages give the commands."""

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.dir = Path(self.temp.name)
        save(self.dir / "orig.txt", ORIGINAL)
        save(self.dir / "conv.md", CONVERTED)

    def changes(self, revised_text, original="orig.txt"):
        save(self.dir / "rev.md", revised_text)
        out = run(SCRIPTS / "detail_check.py", "changes", self.dir / original, self.dir / "rev.md", "--format", "json")
        self.assertEqual(out.returncode, 0, out.stderr)
        return json.loads(out.stdout)

    def guard(self, *args):
        return run(SCRIPTS / "workflow_guard.py", *args, cwd=self.dir)

    def accepted_chapter(self, *start_extra):
        """A chapter recorded with a light self-check and accepted by the (synthetic) author."""
        save(self.dir / "ch03.txt", CONVERTED.split("\n\n", 1)[1].replace("\n\n", "\n"))
        write_json(self.dir / "checks.json", {"candidate": "ch03.txt", "checks": [{"id": "len", "type": "length", "min": 20}]})
        digest = sha(self.dir / "ch03.txt")
        write_json(self.dir / "review.json", {
            "schema": "editorial-review/2", "verdict": "PASS", "candidate_sha256": digest,
            "reviewer": {"mode": "self_check", "label": "合成演练：同一模型自查"}, "checked_against": ["合成演练：本章全文"],
            "inputs_read": [], "evidence": [{"quote": "周岚把船绳绕上第三根桩子", "in": "candidate"}], "issues": [],
            "machine_dispositions": [], "counter_evidence": "合成演练，只核对工具行为"})
        write_json(self.dir / "accept.json", {"candidate_sha256": digest, "source": "合成：作者消息第 12 条“定稿。”",
                                              "scope": "第三章"})
        for args in (("start", "run.json", "--task-id", "ch03", "--spec", "checks.json") + start_extra,
                     ("record", "run.json", "--event-id", "verify-0", "--review", "review.json"),
                     ("accept", "run.json", "--event-id", "accept-1", "--decision", "accept.json")):
            out = self.guard(*args)
            self.assertEqual(out.returncode, 0, out.stdout + out.stderr)

    def gate(self, *extra):
        out = self.guard("status", "run.json", *extra)
        return json.loads(out.stdout)["gate"]

    def ledger(self):
        (self.dir / "正文").mkdir()
        texts = {3: "雨停的时候，周岚把铜匣交给老韩。\n", 4: "天亮以前，老韩把铜匣锁进了柜子。\n", 5: "周岚问起铜匣，老韩说在柜子里。\n"}
        chapters = {}
        for number, text in texts.items():
            name = "第%02d章.md" % number
            save(self.dir / "正文" / name, text)
            chapters[str(number)] = {"status": "accepted", "file": name, "sha256": hashlib.sha256(text.encode()).hexdigest()}
        write_json(self.dir / "facts.json", {
            "schema": "fact-ledger/1", "entities": {"box": {"name": "铜匣"}, "han": {"name": "老韩"}}, "chapters": chapters,
            "facts": [{"id": "f3", "entity": "box", "attribute": "holder", "value": "老韩", "chapter": 3, "layer": "accepted",
                       "basis": "witnessed_action", "source": "第03章", "change": True},
                      {"id": "f4", "entity": "box", "attribute": "location", "value": "柜子", "chapter": 4,
                       "layer": "accepted", "basis": "witnessed_action", "source": "第04章", "depends_on": ["f3"]},
                      {"id": "f5", "entity": "han", "attribute": "says_location", "value": "柜子", "chapter": 5,
                       "layer": "accepted", "basis": "text_statement", "source": "第05章"}]})
        return self.dir / "facts.json"


class WhatTheToolsCheck(ToolCase):
    """The page's claims about detail_check.py, punctuation_lint.py, workflow_guard.py and fact_guard.py, run again."""

    def test_detail_check_changes_as_the_page_says(self):
        block = fidelity_block()
        report = self.changes(CONVERTED)
        self.assertEqual([a["text"] for a in report["added"]], ["# 第三章 渡口"])
        self.assertEqual([n["text"] for n in report["numbers"]["new"]], ["第三章"])
        self.assertIn("（标题里的“第五章”这类也列在“数字和数量”里）", block)
        self.assertEqual((report["deleted"], report["changed"]), ([], []))
        self.assertEqual([u["label"] for u in report["unaligned"]], ["几句并成了一句"])
        self.assertIn("新加的章标题列在“新加的句子”里", block)
        self.assertIn("列在“对不上”的“几句并成了一句”里，这几句里的字和标点改没改，它不逐字比", block)
        # a half-width comma inside the joined sentence is not itemised
        report = self.changes(CONVERTED.replace("箱子比她想的轻，", "箱子比她想的轻,"))
        self.assertEqual(report["changed"], [])
        # against the converted text: a punctuation change is a changed sentence, spaces and a merged paragraph are not
        for old, new in (("雨停的时候，周岚", "雨停的时候,周岚"), ("雨停的时候，周岚", "雨停的时候周岚"),
                         ("把烟掐了。", "把烟掐了……")):
            report = self.changes(CONVERTED.replace(old, new), "conv.md")
            self.assertEqual(len(report["changed"]), 1, new)
        self.assertIn("逗号换成半角或分号、句号换成叹号或省略号、删掉一个逗号", block)
        report = self.changes(CONVERTED.replace("灯罩裂了", "灯罩 裂了"), "conv.md")
        self.assertEqual((report["changed"], report["added"], report["deleted"], report["unaligned"]), ([], [], [], []))
        report = self.changes(CONVERTED.replace("像是半空。\n\n老韩", "像是半空。老韩"), "conv.md")
        self.assertEqual((report["changed"], report["added"], report["deleted"], report["unaligned"]), ([], [], [], []))
        self.assertEqual(report["counts"]["revised"]["paragraphs"], report["counts"]["original"]["paragraphs"] - 1)
        # r5.57 review: "它不报的：……两段并成一段" became two sentences when the hard-wrap cases were written out
        self.assertIn("两段并成一段的也一样，只有段数少了。汉字之间多出来的空格它不报。", block)
        report = self.changes(CONVERTED.replace("一盏灯，灯罩", "一盏灯。灯罩"), "conv.md")
        self.assertEqual([u["label"] for u in report["unaligned"]], ["一句拆成了几句"])
        # r5.57 review: inside a quotation the same change is a changed sentence, so the page now says where
        self.assertIn("逗号改成句号的，在引号外列在“对不上”的“一句拆成了几句”里，在引号里列在“改了的句子”里", block)

    def test_punctuation_lint_baseline_as_the_page_says(self):
        def lint(text):
            save(self.dir / "rev.md", text)
            out = run(SCRIPTS / "punctuation_lint.py", self.dir / "rev.md", "--baseline", self.dir / "conv.md",
                      "--format", "json")
            return json.loads(out.stdout)
        self.assertEqual([i["rule"] for i in lint(CONVERTED.replace("时候，周岚", "时候,周岚"))["introduced"]], ["P06"])
        self.assertEqual([i["rule"] for i in lint(CONVERTED.replace("灯罩裂了", "灯罩 裂了"))["introduced"]], ["P08"])
        for old, new in (("一盏灯，灯罩", "一盏灯灯罩"), ("她没接话，弯腰", "她没接话；弯腰")):
            report = lint(CONVERTED.replace(old, new))
            self.assertEqual((report["status"], report["introduced"], report["tone_changes"]), ("NO_NEW_FLAGS", [], []))
        # r5.57 review: P06 is not only the comma, and "..." is P05
        self.assertIn("半角标点（逗号、句号、直引号这类是 P06，半角省略号 `...` 是 P05）、汉字之间多出来的空格（P08，半角、全角的都报）、"
                      "对白句末标点的改变。删掉一个标点、换成另一个全角标点，它不报。", fidelity_block())

    def test_workflow_guard_after_the_format_changes(self):
        block = fidelity_block()
        self.accepted_chapter()
        save(self.dir / "ch03.md", "# 第三章 渡口\n\n" + read(self.dir / "ch03.txt").replace("\n", "\n\n"))
        (self.dir / "ch03_crlf.txt").write_bytes(b"\xef\xbb\xbf" + read(self.dir / "ch03.txt").replace("\n", "\r\n").encode())
        # a converted copy beside the accepted file
        gate = self.gate("--deliverable", "ch03.md")
        self.assertEqual((gate["author"], gate["deliverable"]["matches"]), ("ACCEPTED", "no"))
        for claim in ("claim_mechanical_pass", "claim_reviewed", "claim_final"):
            self.assertEqual(gate["permissions"][claim]["decision"], "BLOCK", claim)
        self.assertEqual(gate["permissions"]["deliver_as_candidate"]["decision"], "ALLOW_WITH_WARNING")
        self.assertIn("交给作者看（`deliver_as_candidate`）是 ALLOW_WITH_WARNING，脚本提示要说明这份文件没有经过检查", block)
        self.assertEqual(self.gate("--deliverable", "ch03_crlf.txt")["deliverable"]["matches"], "line_endings_or_bom_only")
        self.assertIn("原文件不动、转换稿另存成新文件的：`status` 里 AUTHOR 仍是 ACCEPTED", block)
        self.assertIn("只认三种：同一版、只差末尾换行、只差换行符或 BOM。加了标题、转了 Markdown 的都是另一版（`no`）。", block)
        # a new path cannot be accepted before replan points the checks at it
        write_json(self.dir / "accept-md.json", {"candidate_sha256": sha(self.dir / "ch03.md"),
                                                 "source": "合成：作者“只是换了格式，不用再审，就用 ch03.md。”", "scope": "第三章"})
        out = self.guard("accept", "run.json", "--event-id", "accept-md", "--decision", "accept-md.json", "--skip-review")
        self.assertEqual(out.returncode, 2)
        self.assertIn("The candidate file no longer has the accepted bytes", out.stdout)
        self.assertIn("不先 `replan`，`accept` 报 “The candidate file no longer has the accepted bytes”", block)
        # the accepted file overwritten with the converted bytes
        (self.dir / "ch03.txt").write_bytes((self.dir / "ch03.md").read_bytes())
        gate = self.gate()
        self.assertTrue(gate["author"].startswith("NOT_ACCEPTED (an earlier version "), gate["author"])
        self.assertEqual((gate["mechanical"], gate["editorial"]), ("STALE", "STALE"))
        self.assertEqual(gate["permissions"]["edit_accepted_text"]["decision"], "REVIEW_REQUIRED")
        self.assertIn("`AUTHOR=NOT_ACCEPTED (an earlier version … was accepted)`，机器检查和审稿是 STALE", block)
        write_json(self.dir / "accept-2.json", {"candidate_sha256": sha(self.dir / "ch03.txt"),
                                                "source": "合成：作者“只是加了章标题，不用再审，就用这一版。”", "scope": "第三章"})
        out = self.guard("accept", "run.json", "--event-id", "accept-2", "--decision", "accept-2.json")
        self.assertEqual(json.loads(out.stdout)["failure"], "ACCEPT_INVALID")
        self.assertIn("不加 `--skip-review` 直接 `accept` 会被拒：这一版没有检查记录。", block)
        out = self.guard("accept", "run.json", "--event-id", "accept-2", "--decision", "accept-2.json", "--skip-review")
        self.assertEqual(out.returncode, 0, out.stdout)
        gate = self.gate("--deliverable", "ch03.txt")
        self.assertEqual((gate["author"], gate["review_skipped_by_author"], gate["deliverable"]["matches"]),
                         ("ACCEPTED", True, "no"))
        self.assertNotIn(gate["mechanical"], ("GREEN",))
        # r5.57 review: the page left out that claim_final is BLOCK too when the file is checked with --deliverable
        self.assertIn("AUTHOR 回到 ACCEPTED，状态带“作者决定跳过审稿”的警告；机器检查和审稿不会变成 GREEN、PASS，"
                      "不能说“机器检查通过”“已审”。`status --deliverable` 对这份文件仍是 `no`、退出码 1，“说定本”（`claim_final`）也是 BLOCK", block)
        out = self.guard("status", "run.json", "--deliverable", "ch03.txt")
        self.assertEqual(out.returncode, 1)
        self.assertEqual(gate["permissions"]["claim_final"]["decision"], "BLOCK")
        self.assertEqual(self.gate()["permissions"]["claim_final"]["decision"], "ALLOW")

    def test_fact_guard_after_the_accepted_file_changes(self):
        ledger = self.ledger()
        save(self.dir / "正文" / "第03章.md", "# 第三章\n\n雨停的时候，周岚把铜匣交给老韩。\n")
        out = run(SCRIPTS / "fact_guard.py", "status", ledger, "--chapters-dir", self.dir / "正文")
        self.assertEqual(out.returncode, 1)
        self.assertIn("TEXT_CHANGED_SINCE_ACCEPTED", out.stdout)
        self.assertIn("覆盖以后 `fact_guard.py status` 报 `TEXT_CHANGED_SINCE_ACCEPTED`", fidelity_block())
        data = json.loads(read(ledger))
        data["chapters"]["3"]["sha256"] = sha(self.dir / "正文" / "第03章.md")
        write_json(ledger, data)
        out = run(SCRIPTS / "fact_guard.py", "status", ledger, "--chapters-dir", self.dir / "正文")
        self.assertEqual(out.returncode, 0, out.stdout)
        self.assertIn("作者确认了新文件，再把事实账里这一章登记的文件和 `sha256` 换成新文件的", fidelity_block())


class TheAuthorTakesAnAcceptanceBack(ToolCase):
    def test_written_once_in_the_delivery_states(self):
        block = withdrawal_block()
        text = page("references/quality-loop.md")
        delivery = text[text.index("## 交付状态"):text.index("## 阶段与权限")]
        self.assertIn(block, delivery)
        for phrase in ("作者对同一版、字没改过的稿子收回采纳，或者明确否决",
                       # r5.57 review: where the words go when no chapter gate is open was not said
                       "照作者原话记下来，带出处（哪一条消息），记进工作记录；开着新章全流程的，下面第 2 条的 `reopen` 也带着原话。"
                       "原来的采纳记录照留，不删、不改。",
                       "章节门的 `reopen`，`stage` 写 `final`，用 `learning_loop.py apply` 写进项目记录",
                       "`chapter_gate.py status` 显示当前阶段回到 `final`、`next_action` 是 `present`",
                       "`chapters` 里这一章的 `status`，连同这一章记下的事实的 `layer`，都改成 `candidate`",
                       "`python3 scripts/fact_guard.py impact 事实账 --changed-chapter 章号 --chapters-dir 正文目录`",
                       "只改了章、没改事实的，`fact_guard.py status` 报 `SOURCE_CHAPTER_NOT_ACCEPTED`",
                       "[学习循环](learning-loop.md)“取舍由谁定”第 5、7 条", "[示范记忆](demonstration-learning.md)“认可跟着文字走”",
                       "**现在的限制。** `workflow_guard.py` 还没有收回采纳的命令：同一版的 `status` 仍显示 `AUTHOR=ACCEPTED`",
                       "不能照这个状态说“已定稿”“定本”", "这一版没有改这个脚本。"):
            self.assertIn(phrase, block)
        reopen = page("references/chapter-confirmation.md")
        reopen = reopen[reopen.index("**重开**（`reopen`）"):reopen.index("**读进度**")]
        self.assertIn("作者对已经定稿的这一章收回采纳的，也是带作者原话重开 `final`；事实账、学习循环怎样跟着改，交付门现在的限制，"
                      "见 [质量闭环](quality-loop.md)“交付状态”里的“作者收回采纳”。", reopen)
        for path in rule_pages():
            if path.name != "quality-loop.md":
                self.assertNotIn("还没有收回采纳的命令", read(path), path.name)

    def test_the_words_are_the_learning_pages_own(self):
        rule = "先前的采纳不再算数，要作者重新明确采纳"
        self.assertIn(rule, withdrawal_block())
        self.assertIn(rule, page("references/demonstration-learning.md"))
        loop = page("references/learning-loop.md")
        self.assertIn("作者接受以后又提出否定意见的，先前那条接受记录随即作废", loop)
        self.assertIn("收尾以后作者才提的否定意见也照实记", loop)

    def test_workflow_guard_still_has_no_command_for_it(self):
        out = run(SCRIPTS / "workflow_guard.py", "--help")
        commands = set(re.search(r"\{([a-z,]+)\}", out.stdout).group(1).split(","))
        # When a command for taking an acceptance back is added, the limit in quality-loop.md has to be rewritten.
        self.assertEqual(commands, {"check", "start", "reserve", "replan", "record", "accept", "status"})
        self.accepted_chapter()
        # nothing in the run state can say the author took it back, so a manifest at stage accepted still passes
        write_json(self.dir / "delivery.json", {"schema": "delivery-manifest/1", "stage": "accepted", "expected_units": ["ch03"],
                                                "records": [{"unit": "ch03", "candidate": "ch03.txt", "state": "run.json"}]})
        report = json.loads(run(SCRIPTS / "delivery_manifest.py", self.dir / "delivery.json").stdout)
        self.assertEqual((report["status"], report["units"][0]["gate"]["author"]), ("PASS", "ACCEPTED"))
        self.assertIn("`delivery_manifest.py` 照这个状态把这一章算作已采纳", withdrawal_block())
        write_json(self.dir / "withdraw.json", {"author_decision": "作者收回对第三章这一版的采纳。",
                                                "source": "合成：作者消息第 30 条“这一章先别算定稿。”", "affected_scope": "第三章"})
        out = self.guard("replan", "run.json", "--event-id", "replan-w", "--spec", "checks.json", "--decision", "withdraw.json")
        self.assertEqual(out.returncode, 0, out.stdout)
        gate = self.gate()
        self.assertEqual((gate["author"], gate["permissions"]["claim_final"]["decision"]), ("ACCEPTED", "ALLOW"))
        self.assertIn("“说定本”（`claim_final`）仍是 ALLOW；`replan` 也不改这一项", withdrawal_block())

    def test_reopening_the_final_stage(self):
        store = self.dir / "book.json"
        write_json(self.dir / "data.json", {"characters": {}, "settings": {}, "chapters": {}})
        self.assertEqual(run(SCRIPTS / "project_state.py", "init", store, "--project-id", "book",
                             "--data", self.dir / "data.json").returncode, 0)
        serial = [0]

        def apply(event):
            serial[0] += 1
            path = self.dir / ("event-%d.json" % serial[0])
            write_json(path, event)
            version = json.loads(run(SCRIPTS / "learning_loop.py", "status", store).stdout)["version"]
            out = run(SCRIPTS / "learning_loop.py", "apply", store, path, "--project-id", "book", "--if-version", version)
            self.assertEqual(out.returncode, 0, out.stdout + out.stderr)
            return json.loads(out.stdout)

        apply({"event_id": "cfg", "op": "chapter_gate", "action": "configure", "visual_required": False,
               "teacher_handoff": "host", "actor_role": "author", "mode": "human", "author_quote": "这本书不看图，不交教师。",
               "source_ref": "合成：作者消息第 2 条"})
        digest = hashlib.sha256("合成定稿".encode()).hexdigest()
        for k, stage in enumerate(("scope", "outline", "preparation", "draft", "review", "revision", "final")):
            shown = {"event_id": "p-" + stage, "op": "chapter_gate", "chapter_id": "ch03", "action": "present",
                     "stage": stage, "content": "合成成果：" + stage, "source_ref": "合成：第 %d 条" % (k + 3)}
            if stage in ("draft", "revision", "final"):
                shown["artifact_sha256"] = digest
            out = apply(shown)
            confirm = {"event_id": "c-" + stage, "op": "chapter_gate", "chapter_id": "ch03", "action": "confirm",
                       "stage": stage, "presentation_id": out["presentation_id"],
                       "presentation_version": out["presentation_version"], "actor_role": "author", "mode": "human",
                       "author_quote": "这一步可以。", "source_ref": "合成：作者消息第 %d 条" % (k + 13)}
            if stage == "final":
                confirm.update(decision="accept_final_version", author_quote="定稿。")
            apply(confirm)
        apply({"event_id": "reopen-final", "op": "chapter_gate", "chapter_id": "ch03", "action": "reopen", "stage": "final",
               "reason": "作者收回采纳", "author_quote": "这一章先别算定稿。", "source_ref": "合成：作者消息第 30 条"})
        status = json.loads(run(SCRIPTS / "chapter_gate.py", "status", store, "--chapter-id", "ch03").stdout)
        self.assertEqual((status["current_stage"], status["next_action"], status["last_valid_confirmation"]["stage"]),
                         ("final", "present", "revision"))
        history = json.loads(read(store))["data"]["chapter_confirmations"]["ch03"]["history"]
        final = next(e for e in history if e.get("presentation_id") == "p-final")
        self.assertEqual((final["status"], final["confirmation"]["author_quote"]), ("invalidated", "定稿。"))
        self.assertIn("最后有效的确认是完整修订稿那一步", withdrawal_block())

    def test_the_fact_ledger_set_back_to_candidate(self):
        ledger = self.ledger()
        data = json.loads(read(ledger))
        data["chapters"]["3"]["status"] = "candidate"
        write_json(ledger, data)
        out = run(SCRIPTS / "fact_guard.py", "status", ledger, "--chapters-dir", self.dir / "正文")
        self.assertEqual(out.returncode, 1)
        self.assertIn("SOURCE_CHAPTER_NOT_ACCEPTED", out.stdout)
        for fact in data["facts"]:
            if fact["chapter"] == 3:
                fact["layer"] = "candidate"
        write_json(ledger, data)
        out = run(SCRIPTS / "fact_guard.py", "status", ledger, "--chapters-dir", self.dir / "正文")
        self.assertEqual((out.returncode, json.loads(out.stdout)["accepted_through_chapter"]), (0, None))
        out = run(SCRIPTS / "fact_guard.py", "impact", ledger, "--changed-chapter", "3", "--chapters-dir", self.dir / "正文")
        report = json.loads(out.stdout)
        self.assertEqual((report["status"], report["chapters_to_recheck"]), ("REGRESSION_REQUIRED", [4, 5]))

class WhatTheReviewRanAgain(ToolCase):
    """r5.57 review: cases the first wording of the page described wrongly or left out, run again here."""

    def write_review(self, candidate, quote):
        write_json(self.dir / "review-md.json", {
            "schema": "editorial-review/2", "verdict": "PASS", "candidate_sha256": sha(self.dir / candidate),
            "reviewer": {"mode": "self_check", "label": "合成演练：同一模型自查"}, "checked_against": ["合成演练：本章全文"],
            "inputs_read": [], "evidence": [{"quote": quote, "in": "candidate"}], "issues": [],
            "machine_dispositions": [], "counter_evidence": "合成演练，只核对工具行为"})

    def replan_to_md(self, event):
        save(self.dir / "ch03.md", "# 第三章 渡口\n\n" + read(self.dir / "ch03.txt").replace("\n", "\n\n"))
        write_json(self.dir / "checks.json", {"candidate": "ch03.md", "checks": [{"id": "len", "type": "length", "min": 20}]})
        write_json(self.dir / "md-decision.json", {"author_decision": "第三章改用 Markdown 文件 ch03.md",
                                                   "source": "合成：作者消息第 20 条“以后用 md 那份。”",
                                                   "affected_scope": "第三章"})
        return self.guard("replan", "run.json", "--event-id", event, "--spec", "checks.json", "--decision", "md-decision.json")

    def manifest(self, candidate):
        write_json(self.dir / "delivery.json", {"schema": "delivery-manifest/1", "stage": "accepted", "expected_units": ["ch03"],
                                                "records": [{"unit": "ch03", "candidate": candidate, "state": "run.json"}]})
        out = run(SCRIPTS / "delivery_manifest.py", self.dir / "delivery.json")
        report = json.loads(out.stdout)
        return out.returncode, report["status"], report["units"][0]["problems"]

    def test_hard_wraps_quotes_titles_and_two_chapters_swapped(self):
        block = fidelity_block()
        save(self.dir / "wrapped.txt", "　　楼下传来自行车铃，像要下\n雨。\n　　她锁上门。\n外面的风已经凉了。\n")
        report = self.changes("楼下传来自行车铃，像要下雨。\n\n她锁上门。外面的风已经凉了。\n", "wrapped.txt")
        self.assertEqual([(c["original"]["text"], c["edits"]) for c in report["changed"]],
                         [("楼下传来自行车铃，像要下", [{"from": "", "to": "雨。"}])])
        self.assertEqual([d["text"] for d in report["deleted"]], ["雨。"])
        self.assertEqual((report["added"], report["unaligned"], report["moved"]), ([], [], []))
        self.assertEqual((report["counts"]["original"]["paragraphs"], report["counts"]["revised"]["paragraphs"]), (4, 2))
        self.assertIn("切开处有一头只剩一两个字的（“像要下”和“雨。”），列成一句“改了的句子”（差在：添「雨。」）加一句“删掉的句子”；"
                      "切在句末的，什么也不列，只有开头那行统计里的段数少了。", block)
        save(self.dir / "q.txt", "“好，走吧。”他说，拎起包。\n")
        inside = self.changes("“好。走吧。”他说，拎起包。\n", "q.txt")
        self.assertEqual(([c["edits"] for c in inside["changed"]], len(inside["dialogue"]["changed"]), inside["unaligned"]),
                         ([[{"from": "，", "to": "。"}]], 1, []))
        outside = self.changes("“好，走吧。”他说。拎起包。\n", "q.txt")
        self.assertEqual((outside["changed"], [u["label"] for u in outside["unaligned"]]), ([], ["一句拆成了几句"]))
        self.assertIn("在引号里列在“改了的句子”里，台词也记一处“改了”", block)
        save(self.dir / "titled.txt", "第一章 晨\n　　天亮了，鸟在叫。\n")
        report = self.changes("# 第一章 晨\n\n天亮了，鸟在叫。\n", "titled.txt")
        self.assertEqual([c["edits"] for c in report["changed"]], [[{"from": "", "to": "#"}]])
        self.assertIn("原稿已有的标题只加了 `#` 的，列在“改了的句子”里，差在：添「#」。", block)
        save(self.dir / "two.txt", "第七章 渡口\n　　船靠了岸，老人先下去。他回头看了一眼江面，什么也没说。\n"
                                   "第八章 集市\n　　早市散得快，卖菜的收了摊子。一个孩子蹲在路边数硬币。\n")
        report = self.changes("# 第八章 集市\n\n早市散得快，卖菜的收了摊子。一个孩子蹲在路边数硬币。\n\n"
                              "# 第七章 渡口\n\n船靠了岸，老人先下去。他回头看了一眼江面，什么也没说。\n", "two.txt")
        self.assertEqual([m["original"]["text"] for m in report["moved"]], ["早市散得快，卖菜的收了摊子。", "一个孩子蹲在路边数硬币。"])
        self.assertEqual(report["counts"]["unchanged"], 2)  # the other chapter's two sentences count as untouched
        self.assertEqual([c["original"]["text"] for c in report["changed"]], ["第七章 渡口"])
        self.assertEqual([(u["label"], u["original"][0]["text"]) for u in report["unaligned"]], [("挪了位置又改了字", "第八章 集市")])
        self.assertIn("两章换了先后，只有一章的正文列在“挪了位置、字没改”里，另一章的正文算一字没动", block)
        self.assertIn("章节顺序要另外人工核。", block)

    def test_keep_lines_catch_what_the_joined_sentences_hide(self):
        block = fidelity_block()
        lines = [l for l in ORIGINAL.split("\n") if l.strip()]
        save(self.dir / "keep.txt", "\n".join(lines) + "\n")  # as they stand, paragraph indents included
        save(self.dir / "keep-bare.txt", "\n".join(l.strip() for l in lines) + "\n")

        def keep(text, name="keep.txt"):
            save(self.dir / "rev.md", text)
            out = run(SCRIPTS / "detail_check.py", "changes", self.dir / "orig.txt", self.dir / "rev.md",
                      "--keep", self.dir / name, "--format", "json")
            self.assertEqual(out.returncode, 0, out.stderr)
            return [r["status"] for r in json.loads(out.stdout)["keep"]["lines"]]

        everything = ["kept"] * len(lines)
        self.assertEqual(keep(CONVERTED), everything)
        self.assertEqual(keep(CONVERTED, "keep-bare.txt"), everything)
        changed = keep(CONVERTED.replace("晃了一下", "晃了晃"))
        self.assertEqual([n for n, status in enumerate(changed) if status != "kept"], [3])
        changed = keep(CONVERTED.replace("箱子比她想的轻，", "箱子比她想的轻,"))
        self.assertEqual([n for n, status in enumerate(changed) if status != "kept"], [2])
        for old, new in (("里面的东西晃了", "里面的东西又晃了"), ("灯罩裂了", "灯罩 裂了"), ("像是半空。\n\n老韩", "像是半空。老韩")):
            self.assertEqual(keep(CONVERTED.replace(old, new)), everything, new)
        # r5.57 final verify: a short half-line changed in a few characters is "missing", not "changed".
        missing = keep(CONVERTED.replace("晃了一下，像是半空。", "晃了一下，像空的。"))
        self.assertEqual([(n, status) for n, status in enumerate(missing) if status != "kept"], [(3, "missing")])
        self.assertIn("加 `--keep 锁句文件`：把原稿的每个非空行照原样写成一行（段首缩进脚本会去掉），每一行都要是“原样在”。"
                      "接起来的句子里改了字或标点，那一行报“改了”；短的那一行（比如硬换行切下来的半句）改了字，常常报成“找不到”。"
                      "两样都不是“原样在”。", block)
        self.assertIn("两行接头处多出来的字、汉字之间的空格、两段并成一段、章节换了先后，它照样报“原样在”", block)
        self.assertIn("`--keep` 每一行都是“原样在”；“对不上”和硬换行接起来的那几处逐字读过；段数和章节顺序核过；"
                      "`punctuation_lint.py --baseline` 没有新出现的空格和半角标点。", block)

    def test_other_half_width_forms_and_spaces(self):
        def introduced(text):
            save(self.dir / "rev.md", text)
            out = run(SCRIPTS / "punctuation_lint.py", self.dir / "rev.md", "--baseline", self.dir / "conv.md", "--format", "json")
            return [i["rule"] for i in json.loads(out.stdout)["introduced"]]
        self.assertEqual(introduced(CONVERTED.replace("“还有两箱。”", '"还有两箱。"')), ["P06", "P06"])
        self.assertEqual(introduced(CONVERTED.replace("把烟掐了。", "把烟掐了...")), ["P05"])
        self.assertEqual(introduced(CONVERTED.replace("灯罩裂了", "灯罩　裂了")), ["P08"])

    def test_the_scope_check_compares_whole_lines(self):
        def check(text):
            save(self.dir / "cand.md", text)
            write_json(self.dir / "scope.json", {"candidate": "cand.md", "checks": [
                {"id": "sc", "type": "scope", "source": "orig.txt", "editable_lines": [[1, 1]]}]})
            return json.loads(self.guard("check", "scope.json").stdout)["status"]
        title = "# 第三章 渡口\n"
        self.assertEqual(check(title + ORIGINAL), "GREEN")
        self.assertEqual(check(title + ORIGINAL.replace("老韩说", "老韩讲")), "RED")
        self.assertEqual(check(title + ORIGINAL.replace("一盏灯", "一盏马灯")), "GREEN")  # line 1 has to be editable
        self.assertEqual(check(ORIGINAL.replace("　　", "")), "RED")
        self.assertIn("只往最前面插一行标题时用得上，可是要在最前面插行，第 1 行得设成可改，第 1 行自己改了字它也不报", fidelity_block())

    def test_a_new_path_accepted_without_review(self):
        self.accepted_chapter()
        self.assertEqual(self.replan_to_md("replan-md").returncode, 0)
        write_json(self.dir / "accept-md.json", {"candidate_sha256": sha(self.dir / "ch03.md"),
                                                 "source": "合成：作者“只是换了格式，不用再审，就用 ch03.md。”", "scope": "第三章"})
        out = self.guard("accept", "run.json", "--event-id", "accept-md", "--decision", "accept-md.json", "--skip-review")
        self.assertEqual(out.returncode, 0, out.stdout)
        gate = self.gate("--deliverable", "ch03.md")
        self.assertEqual((gate["author"], gate["deliverable"]["matches"], gate["permissions"]["claim_final"]["decision"]),
                         ("ACCEPTED", "no", "BLOCK"))
        self.assertEqual(self.gate("--deliverable", "ch03.txt")["deliverable"]["matches"], "exact")
        self.assertEqual(self.manifest("ch03.md"), (1, "INCOMPLETE", ["GATE_INCOMPLETE", "AUTHOR_SKIPPED_REVIEW"]))
        block = fidelity_block()
        self.assertIn("（换了路径的，拿旧文件去核反倒是 `exact`）", block)
        self.assertIn("这样采纳的章报 `GATE_INCOMPLETE` 和 `AUTHOR_SKIPPED_REVIEW`，整批不是 PASS", block)

    def test_a_new_path_checked_again(self):
        self.accepted_chapter()
        self.assertEqual(self.replan_to_md("replan-md").returncode, 0)
        out = self.guard("reserve", "run.json", "--event-id", "reserve-md")
        self.assertEqual(out.returncode, 0, out.stdout)
        self.write_review("ch03.md", "周岚把船绳绕上第三根桩子")
        out = self.guard("record", "run.json", "--event-id", "verify-md", "--review", "review-md.json")
        self.assertEqual(out.returncode, 0, out.stdout)
        write_json(self.dir / "accept-md.json", {"candidate_sha256": sha(self.dir / "ch03.md"),
                                                 "source": "合成：作者“可以，就用 ch03.md。”", "scope": "第三章"})
        self.assertEqual(self.guard("accept", "run.json", "--event-id", "accept-md", "--decision", "accept-md.json").returncode, 0)
        gate = self.gate("--deliverable", "ch03.md")
        self.assertEqual((gate["deliverable"]["matches"], gate["permissions"]["claim_final"]["decision"]), ("exact", "ALLOW"))
        self.assertEqual(json.loads(read(self.dir / "run.json"))["budgets"]["revisions_used"], 1)
        self.assertEqual(self.manifest("ch03.md"), (0, "PASS", []))
        self.assertIn("这要用掉一轮返修额度；走完以后 `--deliverable` 对新文件是 `exact`，批量清单也是 PASS。", fidelity_block())

    def test_when_the_revision_budget_is_used_up(self):
        self.accepted_chapter("--max-revisions", "0")
        out = self.replan_to_md("replan-md")
        self.assertEqual((out.returncode, json.loads(out.stdout)["failure"]), (2, "BUDGET_EXHAUSTED"))
        out = self.guard("reserve", "run.json", "--event-id", "reserve-md")
        self.assertEqual((out.returncode, json.loads(out.stdout)["failure"]), (2, "BUDGET_EXHAUSTED"))
        (self.dir / "ch03.txt").write_bytes((self.dir / "ch03.md").read_bytes())
        write_json(self.dir / "accept-2.json", {"candidate_sha256": sha(self.dir / "ch03.txt"),
                                                "source": "合成：作者“只是加了章标题，不用再审。”", "scope": "第三章"})
        out = self.guard("accept", "run.json", "--event-id", "accept-2", "--decision", "accept-2.json", "--skip-review")
        self.assertEqual(out.returncode, 0, out.stdout)
        self.assertEqual(self.gate()["author"], "ACCEPTED")
        self.assertIn("返修额度已经用完的：`replan`、`reserve` 都报 `BUDGET_EXHAUSTED`，换了路径的采纳和再过一遍检查都记不进去。"
                      "不另起任务、不改状态文件绕过额度", fidelity_block())
        self.assertIn("覆盖原路径的文件、作者说不用再审的，`accept --skip-review` 不受额度限制。", fidelity_block())

    def test_a_skip_review_acceptance_checked_with_deliverable(self):
        save(self.dir / "ch.txt", read(self.dir / "orig.txt"))
        write_json(self.dir / "checks.json", {"candidate": "ch.txt", "checks": [{"id": "len", "type": "length", "min": 20}]})
        self.assertEqual(self.guard("start", "run.json", "--task-id", "ch", "--spec", "checks.json").returncode, 0)
        write_json(self.dir / "accept.json", {"candidate_sha256": sha(self.dir / "ch.txt"),
                                              "source": "合成：作者“不用审，就这样。”", "scope": "全文"})
        out = self.guard("accept", "run.json", "--event-id", "accept-1", "--decision", "accept.json", "--skip-review")
        self.assertEqual(out.returncode, 0, out.stdout)
        final = self.gate()["permissions"]["claim_final"]
        self.assertEqual(final["decision"], "ALLOW")
        self.assertIn("说定本时照实注明", final["reason"])
        out = self.guard("status", "run.json", "--deliverable", "ch.txt")
        gate = json.loads(out.stdout)["gate"]
        self.assertEqual((out.returncode, gate["deliverable"]["matches"], gate["permissions"]["claim_final"]["decision"]),
                         (1, "no", "BLOCK"))
        self.write_review("ch.txt", "周岚把船绳绕上第三根桩子")
        self.assertEqual(self.guard("record", "run.json", "--event-id", "verify-1", "--review", "review-md.json").returncode, 0)
        self.assertEqual(self.gate("--deliverable", "ch.txt")["deliverable"]["matches"], "exact")
        self.assertIn("交付前带 `--deliverable` 核跳审采纳的这一版（r5.57 用合成材料实际跑过）：结果是 `no`、退出码 1，"
                      "“说定本”（`claim_final`）也是 BLOCK，因为脚本拿要交的文件和最后一次 `record` 过的那一版比，跳审采纳时记下的那一版不算；"
                      "不带 `--deliverable` 时“说定本”是 ALLOW，理由写着“说定本时照实注明”。", page("references/quality-loop.md"))
        self.assertIn("补做了检查和审稿（`record` 过这一版）以后，`--deliverable` 才对得上。", page("references/quality-loop.md"))
        # r5.57 orchestrator decision: a skip-review acceptance is still the author's acceptance. The page must not
        # tell the host to stop calling it the author's version; it only must not pass it off as a checked final.
        self.assertIn("这时不把它说成检查过的定本：交付时写明这是作者跳过审稿采纳的版本（作者原话和出处），"
                      "交付门对这份文件没有检查记录；作者的采纳照记，不因为这一条打折扣。", page("references/quality-loop.md"))
        self.assertNotIn("这时对这份文件不说“定本”", page("references/quality-loop.md"))

    def test_the_authors_objection_without_findings(self):
        store = self.dir / "book.json"
        write_json(self.dir / "data.json", {"characters": {}, "settings": {}, "chapters": {}})
        self.assertEqual(run(SCRIPTS / "project_state.py", "init", store, "--project-id", "book",
                             "--data", self.dir / "data.json").returncode, 0)
        serial = [0]

        def apply(event):
            serial[0] += 1
            path = self.dir / ("event-%d.json" % serial[0])
            write_json(path, event)
            version = json.loads(run(SCRIPTS / "learning_loop.py", "status", store).stdout)["version"]
            out = run(SCRIPTS / "learning_loop.py", "apply", store, path, "--project-id", "book", "--if-version", version)
            return out.returncode, json.loads(out.stdout.strip() or out.stderr)  # a refused event is reported on stderr

        text = "雨小了，许青把雨衣挂回门后，鞋底还在滴水。\n"
        digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
        for event in ({"event_id": "cfg", "op": "configure", "loop_enabled": True, "enabled": True, "actor_role": "author",
                       "mode": "human", "quote": "开学习记录。", "source_ref": "合成：作者第 1 条"},
                      {"event_id": "s1", "op": "start", "run_id": "r1", "task": "revision", "tags": ["收紧"], "group_id": "g1",
                       "input_text": text, "source_ref": "合成", "constraints": ["不加事实"]},
                      {"event_id": "p1", "op": "plan", "run_id": "r1", "applications": [], "checks": ["事实不变"]},
                      {"event_id": "d1", "op": "draft", "run_id": "r1", "text": text, "source_ref": "合成",
                       "actor": {"name": "w", "context_id": "c1"}},
                      {"event_id": "rv1", "op": "review", "run_id": "r1", "review_id": "t1", "draft_sha256": digest,
                       "reviewer": {"name": "t", "role": "teacher", "mode": "independent_agent", "context_id": "c2"},
                       "verdict": "pass", "findings": [], "source_ref": "合成"},
                      {"event_id": "fin", "op": "finish", "run_id": "r1", "draft_sha256": digest},
                      {"event_id": "aa", "op": "author_accept", "run_id": "r1", "draft_sha256": digest, "quote": "定稿。",
                       "source_ref": "合成：作者第 20 条", "actor_role": "author", "mode": "human"}):
            code, out = apply(event)
            self.assertEqual(code, 0, (event["op"], out))
        objection = {"op": "review", "run_id": "r1", "draft_sha256": digest, "findings": [],
                     "reviewer": {"name": "作者", "role": "author", "mode": "human", "context_id": "author"},
                     "source_ref": "合成：作者第 30 条“这一章先别算定稿。”"}
        code, out = apply(dict(objection, event_id="ob1", review_id="a1", verdict="revise"))
        self.assertEqual((code, out.get("message")), (2, "revise verdict requires findings"))
        code, out = apply(dict(objection, event_id="ob2", review_id="a2", verdict="blocked"))
        self.assertEqual((code, out["next_action"], out["open_author_objections"]), (0, "ask_author_or_stop", ["a2"]))
        self.assertIn("作者说了具体问题的记 `revise`，问题照作者原话列进 `findings`；只说收回、没说问题的记 `blocked`，`findings` 留空，"
                      "不替作者编问题（`revise` 不带 `findings` 会被拒）。", withdrawal_block())


class TheReviewedSentences(unittest.TestCase):
    """r5.57 review: sentences a reviewer could reverse without any test noticing, pinned as they stand."""

    def test_the_fidelity_block(self):
        block = fidelity_block()
        for phrase in ("看到的错字、标点问题列给作者，不改进转换稿。",
                       "请作者对新文件重新确认，不替作者认。",
                       "交付时写明作者采纳的是原文件那一版，这份是它的格式转换稿，转换稿本身没有经过交付门检查。",
                       "这样采纳的文件交付时怎样写，照[质量闭环](quality-loop.md)“交付状态”里跳过审稿那一条；要它过交付核对，走下一条。",
                       "标点检查照样把这些半角报成 P06：项目规则文件的 `ignore` 只能逐处豁免",
                       "拿取出的文字比，版式照那一页逐页看。"):
            self.assertIn(phrase, block)
        for gone in ("这样就够了", "（[中文标点](chinese-punctuation.md)“先分清三类问题”里的作品约定）"):
            self.assertNotIn(gone, block)

    def test_the_pointing_sentences(self):
        line = next(l for l in page("SKILL.md").splitlines() if "保真转换" in l)
        self.assertEqual(line, "- 只换格式、不动字句的（比如加章标题、转 Markdown）单算一类，叫保真转换，不因为篇幅长就扩成整章精修、"
                               "重写或审稿；哪些算在内、怎样核、交付怎样写、已经采纳的章换了格式怎样办，见 [编辑](references/editing.md)"
                               "“先定范围”里的“保真转换”（r5.57）。全角半角和标点不算在内，照 [中文标点](references/chinese-punctuation.md)。")
        line = next(l for l in page("references/chapter-confirmation.md").splitlines() if l.startswith("- **不扩大**"))
        self.assertEqual(line, "- **不扩大**：分析、保真转换（只换格式、不动字句，见 [编辑](editing.md)“先定范围”里的“保真转换”）、"
                               "局部标点修复、单段润色、在已有稿子上改这类任务，照原来的范围，不扩成整章重写，也不为它补走七个阶段。")
        # r5.57 paired routing test: with only the two cards in a chat-only host, 6/6 format-only runs were routed right
        # but 0/6 used the delivery wording, because the card only pointed at a page that host does not have.
        self.assertIn("只换格式、不动字句的（比如加章标题、转 Markdown）是保真转换，不按这三级改，见[编辑](../references/editing.md)"
                      "“先定范围”里的“保真转换”（r5.57）：字句和标点都不动，看到的错字列给作者；交付写“格式检查通过，文学质量未审”，"
                      "再写核了什么、怎样核的，没跑脚本的写人工逐句对照。拿不准时按低一级做", page("assets/revision-card.md"))

    def test_the_withdrawal_block(self):
        block = withdrawal_block()
        for phrase in ("作者另外确认过的设定（`layer`、`basis` 都是 `author_confirmed` 的）不跟着改。",
                       "事实账放在项目状态文件的 `data.facts` 里的，照[状态存储](state-storage.md)读版本、带版本保存。",
                       "学习循环里说的“撤回”是作者撤回自己的否定意见，不是这里的收回采纳。",
                       # left for the maintainer to keep or drop (it is not in the decisions); drop this line with it
                       "作者的决定工坊不驳回。"):
            self.assertIn(phrase, block)


class TheExamplesTitle(unittest.TestCase):
    def test_the_title_says_how_many_examples_there_are(self):
        text = read(ROOT / "EXAMPLES.md")
        numbers = [int(n) for n in re.findall(r"(?m)^## (\d+)\. ", text)]
        self.assertEqual(numbers, list(range(1, len(numbers) + 1)))
        self.assertEqual(text.splitlines()[0], "# %s个可复制的使用示例" % chinese_number(len(numbers)))


if __name__ == "__main__":
    unittest.main()

"""Step 2b: group the same picture at other sizes or compressions with ImageHash, keeping every source.

Exact copies (the same sha256) are one image found at several addresses. Near copies are grouped when every
configured perceptual hash (phash and dhash by default) is within imagehash.max_distance bits. Grouping deletes
nothing: every candidate, address and source page stays in the run, and the group says which images belong together.
r5.37: an unknown or empty imagehash.algorithms is refused (with nothing to compare, every pair used to count as near);
new groups make the order and the bundle built on the old ones outdated.
"""
from . import common

ALGORITHMS = {"phash": "phash", "dhash": "dhash", "ahash": "average_hash", "whash": "whash"}  # whash needs PyWavelets


def imagehash_status():
    try:
        import imagehash
        from PIL import Image  # noqa: F401
    except Exception as exc:  # noqa: BLE001
        return False, "ImageHash is not installed (pip install ImageHash): %s" % exc, None
    return True, "imagehash %s" % getattr(imagehash, "__version__", "?"), getattr(imagehash, "__version__", "?")


def hashes(path, algorithms, size):
    import imagehash
    from PIL import Image

    out = {}
    with Image.open(path) as image:
        image.load()
        for name in algorithms:
            function = getattr(imagehash, ALGORITHMS[name])
            out[name] = str(function(image, hash_size=size))
    return out


def distance(a, b):
    import imagehash
    return int(imagehash.hex_to_hash(a) - imagehash.hex_to_hash(b)) if len(a) == len(b) else None


def run_dedupe(folder, config):
    run = common.Run(folder)
    candidates = run.candidates()
    options = config["imagehash"]
    algorithms = list(options.get("algorithms") or [])
    if not algorithms or any(a not in ALGORITHMS for a in algorithms):
        raise common.VisualError("imagehash.algorithms is a nonempty list of %s" % ", ".join(sorted(ALGORITHMS)))
    for c in candidates:
        if c.get("image"):
            c["image"].pop("gid", None)  # groups come only from this run of the step
    ok, why, version = imagehash_status()
    if not ok:
        record = {"schema": "visual-dedupe/1", "status": "not_installed", "error": why, "images": [], "groups": []}
        outdated = run.outdate("dedupe")
        run.save_candidates(candidates)
        run.save("dedupe.json", dict(record, outdated=outdated))
        run.step("dedupe", {"status": "not_installed"})
        return {"status": "not_installed", "error": why, "outdated": outdated}
    images = {}
    for c in candidates:
        image = c.get("image")
        if not image:
            continue
        item = images.setdefault(image["sha256"], {"sha256": image["sha256"], "file": image["file"], "cids": [],
                                                    "pages": [], "pixels": image["width"] * image["height"],
                                                    "what": image["what"]})
        item["cids"].append(c["cid"])
        if c["page_url"] not in item["pages"]:
            item["pages"].append(c["page_url"])
    problems = []
    for item in images.values():
        try:
            item["hashes"] = hashes(run.path(item["file"]), algorithms, int(options.get("hash_size", 8)))
        except Exception as exc:  # noqa: BLE001 - recorded per image
            item["error"] = "%s: %s" % (type(exc).__name__, exc)
            problems.append(item["sha256"])
    keys = [k for k, v in images.items() if "hashes" in v]
    parent = {k: k for k in keys}

    def root(k):
        while parent[k] != k:
            parent[k] = parent[parent[k]]
            k = parent[k]
        return k

    limit = int(options.get("max_distance", 8))
    pairs = []
    for i, a in enumerate(keys):
        for b in keys[i + 1:]:
            dist = {n: distance(images[a]["hashes"][n], images[b]["hashes"][n]) for n in algorithms}
            if dist and all(d is not None and d <= limit for d in dist.values()):
                parent[root(a)] = root(b)
                pairs.append({"a": a, "b": b, "distance": dist})
    groups = {}
    for k in keys:
        groups.setdefault(root(k), []).append(k)
    out_groups = []
    for n, members in enumerate(sorted(groups.values(), key=lambda m: min(keys.index(x) for x in m)), 1):
        members = sorted(members, key=lambda k: -images[k]["pixels"])
        out_groups.append({"gid": "G%02d" % n, "images": members, "representative": members[0],
                           "cids": [c for k in members for c in images[k]["cids"]],
                           "sources": list(dict.fromkeys(p for k in members for p in images[k]["pages"]))})
    for group in out_groups:
        for k in group["images"]:
            images[k]["gid"] = group["gid"]
    for c in candidates:
        if c.get("image") and "gid" in images.get(c["image"]["sha256"], {}):
            c["image"]["gid"] = images[c["image"]["sha256"]]["gid"]
    status = "ok" if keys else "empty"
    outdated = run.outdate("dedupe")
    run.save_candidates(candidates)
    record = {"schema": "visual-dedupe/1", "status": status, "imagehash_version": version, "algorithms": algorithms,
              "hash_size": int(options.get("hash_size", 8)), "max_distance": limit,
              "images": [dict({k: v for k, v in images[k].items() if k != "pixels"}) for k in images],
              "near_pairs": pairs, "groups": out_groups, "unreadable": problems, "outdated": outdated}
    run.save("dedupe.json", record)
    run.step("dedupe", {"status": status, "images": len(keys), "groups": len(out_groups)})
    return {"status": status, "images": len(keys), "groups": len(out_groups), "unreadable": len(problems),
            "outdated": outdated}

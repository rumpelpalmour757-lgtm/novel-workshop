"""角色台词的可复核线索；统计值和规则命中不构成文学质量判定。

默认仅提示少量具体可疑措辞。广泛的短句/声纹提示须显式开启。
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Dict, Iterable, List, Mapping, Optional, Tuple

from dialogue_core import DialogueSpan, extract_dialogues
from genre_profiles import GenreLintProfile, normalize_scene_exemptions


@dataclass(frozen=True)
class VoiceprintProfile:
    name: str
    archetype: str
    min_avg_len: float
    min_colloquial_rate: float
    voice_prompt: str

    def __post_init__(self):
        if not math.isfinite(self.min_avg_len) or self.min_avg_len < 0:
            raise ValueError('min_avg_len 必须是有限非负数')
        if not math.isfinite(self.min_colloquial_rate) or not 0 <= self.min_colloquial_rate <= 1:
            raise ValueError('min_colloquial_rate 必须在 0 到 1 之间')


# Book-specific profiles are supplied by the selected project config.
VOICEPRINT_REGISTRY: Dict[str, VoiceprintProfile] = {}

# 只统计这些明示的字面线索；命中率不称为“活人味”的测量结果。
RE_COLLOQUIAL_MARKERS = re.compile(
    r'(?:不用|就行|就能|就算|不就|可别|先别|老实|胡乱|使劲|玩意儿?|家伙|哪能|总算|行了|得嘞|瞧瞧|使两天|当拐)'
    r'|先[^。！？；]{0,20}再'
    r'|[吧呢啊嘛哟喽呗哈呐](?=[，。！？；、\s]|$)'
)
RE_CLAUSE_SPLIT = re.compile(r'[，。！？；、,!?;]|…+|—+')
RE_SUSPICIOUS_EXPRESSIONS = re.compile(r'挺挡咬|很防砍')
CONFIRMED_CONFIDENCE = frozenset({'explicit', 'manual'})

# 旧名字保留为记录类型别名，构造字段按共享逐引语接口执行。
DialogueLine = DialogueSpan


@dataclass
class VoiceLintIssue:
    para_index: int
    speaker: str
    rule_id: str
    quote: str
    reason: str
    rewrite_instruction: str
    severity: str = 'REVIEW'
    quote_id: str = ''
    quote_index: int = 0
    start: int = 0
    end: int = 0
    source_quote: str = ''
    confidence: str = 'unknown'
    matched_span: str = ''
    category: str = 'VOICE'


def extract_dialogues_with_speaker(
    paragraphs: List[str], *, registry: Optional[Mapping[str, VoiceprintProfile]] = None,
    aliases=None, speaker_overrides=None,
) -> List[DialogueSpan]:
    """保守提取每个引语；说话人和置信依据由共享解析器返回。"""
    profiles = VOICEPRINT_REGISTRY if registry is None else registry
    return extract_dialogues(paragraphs, tuple(profiles), aliases=aliases, speaker_overrides=speaker_overrides)


def _clauses(text: str) -> List[str]:
    return [c.strip() for c in RE_CLAUSE_SPLIT.split(text) if c.strip()]


def _issue(d: DialogueSpan, rule_id: str, reason: str, instruction: str,
           matched_span: str = '') -> VoiceLintIssue:
    return VoiceLintIssue(
        para_index=d.para_index, speaker=d.speaker, rule_id=rule_id,
        quote=d.quote, reason=reason, rewrite_instruction=instruction,
        quote_id=d.quote_id, quote_index=d.quote_index, start=d.start, end=d.end,
        source_quote=d.text, confidence=d.confidence, matched_span=matched_span,
    )


def analyze_voice_and_idioms(
    paragraphs: List[str], *, registry: Optional[Mapping[str, VoiceprintProfile]] = None,
    aliases=None, speaker_overrides=None, stress_speakers: Iterable[str] = (),
    include_style_hints: bool = False, min_profile_quotes: int = 3,
    genre_profile: Optional[GenreLintProfile] = None,
    style_exempt_quotes=(),
) -> Tuple[Dict[str, dict], List[VoiceLintIssue]]:
    """返回角色指标和人工复核项。

    explicit/manual 引语才计入角色指标；动作推断单独计数。声纹阈值是本次
    输入的参考线。`stress_speakers` 由调用者确认当前受压角色，不能从“血、歪”
    等字面词推断。没有发言的角色不生成虚构的零分报告。
    题材规则是显式启用规则的上限，不会开启 include_style_hints；场景豁免只
    作用于 {quote_id: rule_ids} 中逐句明确列出的文风项，不影响构词候选、
    角色统计或压力复核。
    """
    if isinstance(min_profile_quotes, bool) or not isinstance(min_profile_quotes, int) or min_profile_quotes < 1:
        raise ValueError('min_profile_quotes 必须是正整数')
    if isinstance(stress_speakers, str):
        raise ValueError('stress_speakers 请传角色名集合，而不是字符串')
    if genre_profile is not None and not isinstance(genre_profile, GenreLintProfile):
        raise ValueError('genre_profile 必须是 GenreLintProfile 或 None')
    style_exempt = normalize_scene_exemptions(style_exempt_quotes)
    stressed = frozenset(stress_speakers)
    markers = RE_COLLOQUIAL_MARKERS if genre_profile is None else genre_profile.colloquial_markers
    has_marker = (lambda text: bool(markers.search(text))) if genre_profile is None else genre_profile.has_colloquial_marker
    synthetic_enabled = genre_profile is None or 'SYN_01_DEGREE_ACT_VERB' in genre_profile.enabled_rules
    short_rule_id = 'COMP_02_IMPERATIVE_TRIPLE_CHOP'
    short_enabled = genre_profile is None or short_rule_id in genre_profile.enabled_rules
    profiles = VOICEPRINT_REGISTRY if registry is None else registry
    dialogues = extract_dialogues_with_speaker(
        paragraphs, registry=profiles, aliases=aliases, speaker_overrides=speaker_overrides,
    )
    grouped: Dict[str, List[DialogueSpan]] = {}
    for line in dialogues:
        grouped.setdefault(line.speaker, []).append(line)
    report: Dict[str, dict] = {}
    for speaker, all_lines in grouped.items():
        confirmed = [d for d in all_lines if d.confidence in CONFIRMED_CONFIDENCE]
        profile = profiles.get(speaker)
        clauses = [c for d in confirmed for c in _clauses(d.text)]
        raw_average = sum(len(c) for c in clauses) / len(clauses) if clauses else None
        raw_rate = sum(has_marker(d.text) for d in confirmed) / len(confirmed) if confirmed else None
        if not confirmed or profile is None:
            status = 'UNASSESSED: 说话人未确认或没有角色配置'
        elif len(confirmed) < min_profile_quotes:
            status = f'INSUFFICIENT_DATA: 确认台词不足{min_profile_quotes}条，不能判断声纹'
        elif raw_average is not None and raw_average < profile.min_avg_len and raw_rate < profile.min_colloquial_rate:
            status = 'REVIEW: 两项字面指标低于角色参考线，需结合场景回读'
        else:
            status = 'NO_THRESHOLD_ALERT: 未触发参考线，不代表文风合格'
        displayed_rate = None if raw_rate is None else f'{raw_rate * 100:.1f}%'
        report[speaker] = {
            '台词数': len(confirmed),
            '待确认台词数': len(all_lines) - len(confirmed),
            '平均分句长': None if raw_average is None else round(raw_average, 1),
            '口语标记命中率': displayed_rate,
            '口语烟火气率': displayed_rate,  # 旧字段别名；含义以口语标记命中率为准。
            '诊断状态': status,
            '指标说明': '字面统计，非文学质量评分；待确认台词未参与统计。',
        }
        if genre_profile is not None:
            report[speaker].update({
                '题材配置': genre_profile.genre_id,
                '口语标记来源': 'genre_profile.colloquial_markers',
                '有效口语标记': markers.pattern,
                '连续短句平均长度参考线': genre_profile.max_avg_clause_len,
                '连续短句参考线来源': 'genre_profile.max_avg_clause_len',
                '连续短句提示已启用': include_style_hints and short_enabled,
                '角色参考线': None if profile is None else {
                    'min_avg_len': profile.min_avg_len,
                    'min_colloquial_rate': profile.min_colloquial_rate,
                },
            })

    issues: List[VoiceLintIssue] = []
    for d in dialogues:
        if synthetic_enabled:
            for match in RE_SUSPICIOUS_EXPRESSIONS.finditer(d.text):
                issues.append(_issue(
                    d, 'SYNTHETIC_COLLOQUIAL_VV', f'命中待复核措辞“{match.group(0)}”；仅凭字面不能判定为语病。',
                    '结合原句和实际指代判断搭配是否自然；可以保留。若需修改，只调整命中措辞，保留原意，不新增动作、物品或事实。',
                    match.group(0),
                ))
        profile = profiles.get(d.speaker)
        confirmed = d.confidence in CONFIRMED_CONFIDENCE
        clauses = _clauses(d.text)
        # 显式压力状态下，只有较长且信息密集的发言才给回读线索；不要求“嘶”或省略号。
        if confirmed and d.speaker in stressed and len(d.text) >= 32 and len(clauses) >= 3:
            issues.append(_issue(
                d, 'STRESS_SPEECH_REVIEW', '调用者声明该角色正处于生理压力；此段较长，请核对其说话能力与当时动作。',
                '核对当前伤势、说话时机和信息必要性；允许清晰讲话。没有原文依据不添加痛呼、喘息、停顿或动作。',
            ))
        if (not include_style_hints or not short_enabled or not confirmed or profile is None
                or short_rule_id in style_exempt.get(d.quote_id, ())):
            continue
        enough_samples = report[d.speaker]['台词数'] >= min_profile_quotes
        short_enough = bool(clauses) and (
            max(map(len, clauses)) <= 8 if genre_profile is None
            else sum(map(len, clauses)) / len(clauses) <= genre_profile.max_avg_clause_len
        )
        if (profile.archetype in {'folksy_warm', 'competent_tech'} and enough_samples
                and d.text.count('。') >= 3 and len(clauses) >= 3
                and short_enough and not has_marker(d.text)):
            issues.append(_issue(
                d, 'VOICEPRINT_COLLAPSE_TELEGRAPH', '命中连续短句复核线；可能是有意的命令、停顿或人物口吻。',
                f'结合上下文和作者认可的声音样本判断是否保留。角色参考：{profile.voice_prompt} 不以添加语气词或合并句号作为达标要求。',
            ))
    return report, issues


def build_surgical_patch_prompt(issues: List[VoiceLintIssue], *, paragraphs=None) -> str:
    """构建可验证的逐引语补丁请求；应用模型答复必须另经 apply_dialogue_patch。"""
    if paragraphs is None:
        raise ValueError('构建补丁必须提供原始 paragraphs：build_surgical_patch_prompt(issues, paragraphs=paragraphs)')
    from patch_guard import build_patch_request, format_patch_prompt
    return format_patch_prompt(build_patch_request(paragraphs, issues))

#!/usr/bin/env python3
"""Export the linked skill resources and optional projects using only Python 3."""

import argparse
import os
from pathlib import Path, PurePosixPath
import posixpath
import re
import tempfile
from urllib.parse import unquote, urlsplit
import zipfile


PROJECT_PREFIX = "assets/project-packs/"
# Resource links use inline Markdown or reference definitions; paths containing
# spaces use <angle brackets>. Code examples do not declare file dependencies.
INLINE_LINK = re.compile(
    r'!?\[([^\]\n]+)\]\(\s*(?:<([^>\n]+)>|([^\s)]+))'
    r'(?:\s+(?:"[^"\n]*"|\'[^\'\n]*\'))?\s*\)'
)
REFERENCE_DEF = re.compile(
    r'^ {0,3}\[([^\]\n]+)\]:\s*(?:<([^>\n]+)>|(\S+)).*$', re.MULTILINE
)


GUIDE = """# 小说写作工坊：迁移说明

工作流参考：BJM v2.7（2026-09-13）。
方法补充：参考用户提供的 Oh Story 快照（2026-09-18），增加参考拆解、短篇、章节工作卡、旧稿导入和作者偏好分层。

这份包将通用方法、作者选择与具体作品资料分开，可用于新作品或新的AI会话。

## 选择用法

| 目标环境 | 使用方法 |
| --- | --- |
| 支持文件夹式 Skills | 使用 novel-workshop 文件夹，保留内部相对位置，按目标环境支持的方式导入。 |
| 只有聊天、项目指令或附件输入 | 提供 portable-novel-workshop.md，以及当前任务、项目资料与原稿。单文件已展开全部 Markdown 方法和模板。 |
| 换一本小说 | 使用新作品的档案、文风卡和原稿，按题材选择相关方法。 |
| 换AI或会话继续同一作品 | 携带项目档案、文风卡（如有）、状态记录、最新及相关原文，从未完成处接续。 |

## 包含的内容

- novel-workshop/：设定大纲、长短篇正文、参考拆解、编辑、衔接、成长体系、文风、审改循环、旧稿导入、项目接续及模板；也包含只读正文提示检查、可执行约束检查、修订状态工具和导出脚本。
- portable-novel-workshop.md：展开的写作指令，适合直接上传或复制；写作不依赖脚本、网络和特定账户。
- 附带项目时，入口在 novel-workshop/assets/project-packs/index.md，与安装版位置一致。项目只是可选快照，只有选定该作品时才读取。

早期包中的 optional-projects/ 已统一放入上述 assets/project-packs/，项目内相对路径保持一致。只带通用方法的包不会包含具体小说资料。

## 开始与恢复

提供材料后可说：“按小说写作工坊处理。本轮润色，保留情节、人物动机和信息顺序，只交正文。”也可指定只分析、续写、设计卷纲或检查衔接。

需要长期跟踪时说：“为这部作品开启持续维护，草稿与已采纳状态分开记录。”只需开启一次；新会话仍需带上记录和相关原稿。

起草、核查和修订可由一个AI顺序完成。多代理不是使用条件；自查不能声称独立验证。检查过程默认留在内部，不附在小说正文后。

有 Python 时可按 references/execution.md 使用 workflow_guard.py 检查明确条件、保存修订额度和恢复点。程序只核对已声明的条件，文笔、张力和人物逻辑仍需审稿；纯聊天版保留相同方法与文本交接，不宣称程序检查已执行。恢复时携带原任务状态，避免重复计数。

prose_lint.py 只提示重复段落、遗留占位和项目指定表达，结果不是AI来源检测或文笔裁决。作者偏好按范围携带，小说事实只随具体项目走。上游许可保留在 novel-workshop/assets/third-party/，不代表本包已安装上游项目。

## 更新后重新导出

文件夹版中，在 novel-workshop 目录运行：

```bash
python3 scripts/export_portable.py /目标目录/novel-workshop-portable.zip
```

需要附带项目时加 --include-projects。新增资源须以相对 Markdown 链接接入主文件或参考文件；导出器沿链接收集并校验文件，缺失引用会报错并保留旧包；导出成功时更新指定的 ZIP 文件。纯聊天单文件版不包含可执行脚本，重新导出请使用文件夹版。

安装入口取决于目标环境。迁移的是方法与资料，不是原对话记忆，也不保证不同模型产生相同文笔。
"""


def prose_only(text):
    """Ignore fenced and inline code when discovering resource links."""
    lines = []
    fence = None
    for line in text.splitlines():
        marker = re.match(r"^ {0,3}(`{3,}|~{3,})", line)
        if marker:
            token = marker.group(1)
            if fence is None:
                fence = token
            elif token[0] == fence[0] and len(token) >= len(fence):
                fence = None
            continue
        if fence is None:
            lines.append(line)
    return re.sub(r"(`+).*?\1", "", "\n".join(lines))


def link_targets(text):
    text = prose_only(text)
    for pattern in (INLINE_LINK, REFERENCE_DEF):
        for match in pattern.finditer(text):
            yield match.group(2) or match.group(3)


def local_target(relative, target):
    """Resolve a local file link without allowing it to leave the package."""
    url = urlsplit(target)
    if url.scheme or url.netloc:
        if url.scheme == "file":
            raise ValueError(f"Use a relative resource link in {relative}: {target}")
        return None
    if not url.path:
        return None
    path = unquote(url.path)
    if "\\" in path or path.startswith("/"):
        raise ValueError(f"Resource path must be relative in {relative}: {target}")
    joined = posixpath.normpath(str(PurePosixPath(relative).parent / path))
    if joined == ".." or joined.startswith("../"):
        raise ValueError(f"Resource escapes package in {relative}: {target}")
    return joined


def read_resource(root, relative):
    source = root / relative
    try:
        source.resolve().relative_to(root.resolve())
    except ValueError as exc:
        raise ValueError(f"Resource escapes skill directory: {relative}") from exc
    if not source.is_file():
        raise FileNotFoundError(f"Missing linked resource: {relative}")
    return source.read_bytes()


def collect_core(root):
    """Follow dependencies, so adding a linked module needs no code change."""
    resources = {}
    pending = ["SKILL.md"]
    while pending:
        relative = pending.pop(0)
        if relative in resources:
            continue
        if relative.startswith(PROJECT_PREFIX):
            raise ValueError("Keep optional project links in the optional project index")
        data = read_resource(root, relative)
        resources[relative] = data
        if PurePosixPath(relative).suffix.lower() == ".md":
            for target in link_targets(data.decode("utf-8")):
                linked = local_target(relative, target)
                if linked is not None:
                    pending.append(linked)
    return resources


def plain_links(text):
    """Use labels for internal links whose Markdown is embedded below."""
    def is_external(target):
        url = urlsplit(target)
        return bool(url.scheme or url.netloc)

    def replace_inline(match):
        target = match.group(2) or match.group(3)
        return match.group(0) if is_external(target) else match.group(1)

    definitions = {
        m.group(1).casefold(): m.group(2) or m.group(3)
        for m in REFERENCE_DEF.finditer(text)
    }

    def replace_reference(match):
        label = match.group(1)
        identifier = (match.group(2) or label).casefold()
        target = definitions.get(identifier)
        return label if target and not is_external(target) else match.group(0)

    text = REFERENCE_DEF.sub(
        lambda m: m.group(0) if is_external(m.group(2) or m.group(3)) else "", text
    )
    text = INLINE_LINK.sub(replace_inline, text)
    return re.sub(r"\[([^\]\n]+)\](?:\[([^\]\n]*)\])?", replace_reference, text)


def validate_links(entries):
    for relative, data in entries.items():
        if PurePosixPath(relative).suffix.lower() != ".md":
            continue
        for target in link_targets(data.decode("utf-8")):
            linked = local_target(relative, target)
            if linked is not None and linked not in entries:
                raise FileNotFoundError(f"Broken archive link: {relative} -> {target}")


def export(root, output, include_projects=False):
    root, output = Path(root), Path(output)
    core = collect_core(root)
    main = core["SKILL.md"].decode("utf-8")
    frontmatter = re.match(r"\A---\r?\n.*?\r?\n---(?:\r?\n|\Z)", main, re.DOTALL)
    if not frontmatter:
        raise ValueError("SKILL.md frontmatter is missing or incomplete")
    entries = {"novel-workshop/" + name: data for name, data in core.items()}
    single = [
        "# 小说写作工坊：便携单文件版",
        "本文件已展开所有 Markdown 方法与模板，后文按来源文件名标记。请使用内嵌内容，无需另读这些文件。具体项目由用户另行提供；导出和执行检查脚本属于文件夹版，纯聊天模式不执行脚本，不冒称程序检查或自动存档。",
        plain_links(main[frontmatter.end():].strip()),
    ]
    for relative, data in sorted(core.items()):
        if relative != "SKILL.md" and PurePosixPath(relative).suffix.lower() in {".md", ".txt"}:
            single.append("-----\n\n# 内嵌内容：" + relative + "\n\n" + plain_links(data.decode("utf-8").strip()))
    entries["portable-novel-workshop.md"] = ("\n\n".join(single).rstrip() + "\n").encode("utf-8")
    entries["README.md"] = GUIDE.encode("utf-8")

    if include_projects:
        projects = root / PROJECT_PREFIX
        for source in sorted(projects.rglob("*")):
            if source.is_file():
                relative = source.relative_to(root).as_posix()
                entries["novel-workshop/" + relative] = read_resource(root, relative)

    validate_links(entries)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=output.parent, prefix=".novel-export-", suffix=".zip", delete=False) as stream:
            temporary = Path(stream.name)
        with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for name, data in sorted(entries.items()):
                archive.writestr(name, data)
        with zipfile.ZipFile(temporary) as archive:
            error = archive.testzip()
            if error:
                raise ValueError("Archive integrity check failed: " + error)
            for name, data in entries.items():
                if archive.read(name) != data:
                    raise ValueError("Archive content mismatch: " + name)
        os.replace(temporary, output)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()
    return len(entries)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--include-projects", action="store_true")
    args = parser.parse_args()
    if args.output.suffix.lower() != ".zip":
        parser.error("output must end in .zip")
    root = Path(__file__).resolve().parents[1]
    count = export(root, args.output, args.include_projects)
    print(f"Exported {count} files: {args.output}")


if __name__ == "__main__":
    main()

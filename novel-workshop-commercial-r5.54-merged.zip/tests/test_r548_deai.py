#!/usr/bin/env python3
"""r5.48: de-AI revision that improves the text and keeps what works.

The author's report on r5.46/r5.47: a stock bodily reaction that occurred once was kept "because it occurs once"; "the
character's realisation now" kept a moral-of-the-story ending; the only prescribed rewrite of a feeling word was a
bodily reaction, so 空气凝固 became 指节发白; "a sentence that does not hinder reading stays" plus "strict polishing adds
nothing" made the writer only delete; prose_lint reported 2 of the 30 tells in the combat sample and 0 of 15 in the
kitchen sample; a zero-change record that said only "全段逐句读过，无需修改" passed the strict gate.

These tests pin what a program can pin: the scanner's bounded variants and its group of optional hints, the gate's new
refusals and the way it reports a passing record, and the wiring of the rules (the gate card, the revision card at the
top of the single file). Whether a revision written under these rules reads better is not something they can show; the
held-out comparison and its limits are in VERIFICATION.md.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
SCRIPTS = SKILL / "scripts"
GUARD = SCRIPTS / "workflow_guard.py"

# The author's failing combat sample (r5.46 review, T1) and kitchen sample (T2), shortened to the lines that matter.
COMBAT = ("夜色如墨，废弃的钢铁厂里一片死寂，空气仿佛在这一刻凝固了。\n\n"
          "陈野站在厂房中央，深吸一口气，眼中闪过一丝坚定的光芒。他知道，这一战，他不能输。\n\n"
          "一股前所未有的压迫感扑面而来。\n\n"
          "陈野的心跳骤然加速，指节因为用力而发白。但他没有退缩。\n\n"
          "他咬紧牙关，体内的气血如江河奔涌，一股磅礴的力量瞬间涌遍全身。\n\n"
          "陈野站在原地，大口喘着粗气，嘴角却勾起一抹弧度。\n\n"
          "这一刻，他终于明白了：真正的强大，不是没有恐惧，而是在恐惧面前依然选择出拳。\n")
KITCHEN = ("外婆的厨房还是老样子。\n\n"
           "林晚站在门口，心中涌起一股说不清的情绪。\n\n"
           "她轻轻拿起那块洗得发白的抹布，指尖微微颤抖。抹布上还残留着淡淡的皂角味。\n\n"
           "她知道，有些东西，一旦失去，就再也找不回来了。但那些爱，会一直留在她心里，温暖她往后的每一个日子。\n")
HUMAN = ("老周把三轮车往回收站门口一横，没熄火，跳下来就去掀篷布，篷布底下压着半扇冰箱门、两捆电线、一个缺了腿的电饭煲，"
         "他一样一样往地上扔，扔到电饭煲的时候停了一下，拿起来晃了晃，里头哗啦响。\n\n"
         "“又是钢珠。”他说，“这礼拜第三个了。”\n\n"
         "我没吭声。西边的烟囱又开始冒黄烟了，一股一股往上顶，顶到半空就散成一片，把太阳糊成个蛋黄。\n")


def lint_module():
    spec = importlib.util.spec_from_file_location("r548_prose_lint", SCRIPTS / "prose_lint.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read(rel):
    return (SKILL / rel).read_text(encoding="utf-8")


class Scanner(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.lint = lint_module()

    def hits(self, text, hints=()):
        return [(f["rule"], f["quote"]) for f in self.lint.inspect_text(text, hints=hints)["findings"]]

    def rules(self, text, hints=()):
        return {rule for rule, _ in self.hits(text, hints)}

    def test_default_rules_now_see_the_failing_samples(self):
        # r5.47 by default: 2 places in the combat sample, none in the kitchen sample.
        combat = self.hits(COMBAT)
        self.assertIn(("tension-telling", "一片死寂"), combat)
        self.assertIn(("tension-telling", "一股前所未有的压迫感"), combat)
        self.assertTrue(any(rule == "weak-scene-ending" for rule, _ in combat), combat)
        kitchen = self.rules(KITCHEN)
        self.assertEqual({"tension-telling", "weak-scene-ending"}, kitchen & {"tension-telling", "weak-scene-ending"})

    def test_default_rules_add_nothing_to_a_human_written_passage(self):
        self.assertEqual(self.hits(HUMAN), [])
        self.assertEqual(self.hits(HUMAN, ("deai",)), [])

    def test_stock_reactions_with_words_in_between(self):
        for text, quote in (("陈野嘴角却勾起一抹弧度。", "嘴角却勾起一抹"), ("她的指节因为用力而发白。", "指节因为用力而发白"),
                            ("他喉结上下滚动了一下。", "喉结上下滚动"), ("冷汗瞬间湿透了他的后背。", "冷汗瞬间湿透")):
            self.assertIn(("stock-reaction", quote), self.hits(text, ("stock-reaction",)), text)
        # Still optional (CON-011 names it so): the default run does not report it.
        self.assertNotIn("stock-reaction", self.rules("他深吸一口气，推开了门。"))
        # A comma ends the clause: the next clause's 发白 is not this 指节's.
        self.assertEqual(self.hits("他攥着指节，墙皮都发白了。", ("stock-reaction",)), [])

    def test_the_deai_group(self):
        self.assertEqual(self.lint.expand_hints(["deai"]),
                         ["stock-reaction", "inner-declaration", "contrast-moral", "abstract-surge", "stock-simile",
                          "soft-adverbs"])
        found = self.rules(COMBAT, ("deai",))
        for rule in ("stock-reaction", "inner-declaration", "contrast-moral", "abstract-surge", "stock-simile"):
            self.assertIn(rule, found)
        # A rules file can name the group too, as the gate passes it on.
        report = self.lint.inspect_text(COMBAT, {"hints": ["deai"]})
        self.assertIn("contrast-moral", report["checks_run"])
        with self.assertRaises(ValueError):
            self.lint.inspect_text(COMBAT, {"hints": ["deai", "nonsense"]})

    def test_negatives_are_not_reported(self):
        for text in ("“我知道，”老周把烟掐了，“你别跟我说这些。”",           # a character's own words
                     "他知道那条路，小时候走过，雨天会塌一段。",               # knowing a fact, not a declaration
                     "他这才明白，那三百块是老何替他垫的。",                   # realising a fact
                     "到了第三年，他还是没太弄明白，但已经习惯了往江面上看一眼。",  # negated, found after freeze
                     "老郝扶着梯子，尽量说得清楚：“先别松手。”",              # a complement, not knowing (r5.50: newly written)
                     "“不是我不帮你，而是这钱真不在我手上。”他摊开手。",       # an argument in a line
                     "漏水的不是屋顶，而是墙里那根老管子。",                   # narration stating a fact
                     "一股机油味从车底下冒出来。", "他憋着一股劲，把那袋水泥扛上了三楼。",
                     "太阳被烟糊成个蛋黄，挂在烟囱顶上。", "她轻轻敲了两下门，等了一会儿，又敲了两下。"):
            self.assertEqual(self.hits(text, ("deai",)), [], text)

    def test_short_beats_is_left_out_of_the_group_and_runs_when_named(self):
        text = ("他退了一步，看着那头兽从阴影里出来，獠牙上挂着涎水，一路滴在地上。\n\n下一秒，它动了。\n\n"
                "它扑过来的时候带起一股腥风，他侧身避开，爪子擦着脸过去，血顺着下巴往下淌。\n\n疼痛让他更加清醒。\n\n"
                "他攥住铁棍往前一送，戳进了它张开的嘴里，铁棍在里面卡住，他整个人被甩到墙上。\n\n砰！\n\n"
                "墙皮哗啦啦往下掉，他从地上爬起来，抹了一把脸上的灰，铁棍还卡在那东西嘴里。\n")
        self.assertNotIn("short-beats", self.rules(text, ("deai",)))
        self.assertIn("short-beats", self.rules(text, ("short-beats",)))

    def test_the_command_line_and_the_limits_say_what_a_hit_is(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "draft.txt"
            path.write_bytes((COMBAT).encode("utf-8"))
            proc = subprocess.run([sys.executable, "-I", str(SCRIPTS / "prose_lint.py"), str(path), "--hint", "deai"],
                                  capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(proc.returncode, 0, proc.stderr)
            report = json.loads(proc.stdout)
        self.assertIn("命中不等于写错", report["limits"])
        self.assertIn("没有命中也不说明写得好或没有 AI 腔", report["limits"])
        stock = next(f for f in report["findings"] if f["rule"] == "stock-reaction")
        self.assertIn("出现一次也要看", stock["message"])
        tension = next(f for f in report["findings"] if f["rule"] == "tension-telling")
        self.assertIn("换成指节发白、深吸一口气这类现成反应不算改好", tension["message"])


class Gate(unittest.TestCase):
    """The author's counterexample, and what a zero-change record now has to show."""

    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        (self.dir / "original.md").write_bytes((COMBAT).encode("utf-8"))
        (self.dir / "draft.md").write_bytes((COMBAT).encode("utf-8"))
        (self.dir / "checks.json").write_bytes(json.dumps({"candidate": "draft.md", "mode": "strict", "checks": [
            {"id": "prose", "type": "prose"}, {"id": "rev", "type": "revision", "source": "original.md"}]}).encode("utf-8"))
        self.assertEqual(self.guard("start", "run.json", "--task-id", "r548", "--spec", "checks.json")[0], 0)
        self.items = [item["id"] for item in self.guard("check", "checks.json")[1]["review_items"]]

    def tearDown(self):
        shutil.rmtree(self.dir)

    def guard(self, *args):
        proc = subprocess.run([sys.executable, "-I", "-B", str(GUARD), *args], cwd=self.dir, capture_output=True,
                              text=True, encoding="utf-8")
        try:
            return proc.returncode, json.loads(proc.stdout)
        except ValueError:
            return proc.returncode, {"raw": proc.stdout[-400:], "stderr": proc.stderr[-400:]}

    def review(self, note, reasons=None, label="同一模型在本对话中自查", dimension_note=None, mutate=None):
        reasons = reasons or {key: "这一处“%s”交作者看，写进交付说明（%s）" % (key[-8:], key) for key in self.items}
        notes = {"paragraphing": "七段按动作主体分，单行段留作冲击", "dialogue_punctuation": "全段没有台词，标点照原样",
                 "scene_reconstruction": "厂房中央和陈野的位置清楚", "narrative_function": "没有删改，信息不变",
                 "continuity": "没有前文，不适用", "revision_comparison": "零修改，和原稿逐字相同"}
        value = {"schema": "editorial-review/2", "verdict": "PASS",
                 "candidate_sha256": hashlib.sha256(COMBAT.encode("utf-8")).hexdigest(),
                 "reviewer": {"mode": "self_check", "label": label}, "checked_against": ["original.md"],
                 "inputs_read": ["original.md"],
                 "evidence": [{"quote": "夜色如墨，废弃的钢铁厂", "in": "candidate"},
                              {"quote": "一股前所未有的压迫感", "in": "candidate"},
                              {"quote": "依然选择出拳", "in": "candidate"}],
                 "issues": [], "counter_evidence": "核对过候选稿就是原稿", "limits": "只看了这一段",
                 "machine_dispositions": [{"id": key, "decision": "keep", "reason": reasons[key]} for key in self.items],
                 "dimensions": [{"id": key, "status": "not_applicable" if key == "continuity" else "met",
                                 "note": dimension_note or notes[key]} for key in notes],
                 "expression": {"scope": "chapter", "decisions": [],
                                "segments": [{"from": "夜色如墨", "to": "选择出拳。", "note": note}]}}
        if mutate:
            mutate(value)
        (self.dir / "review.json").write_bytes((json.dumps(value, ensure_ascii=False)).encode("utf-8"))
        return self.guard("record", "run.json", "--event-id", "v1", "--review", "review.json")

    def test_template_text_is_refused(self):
        code, out = self.review("“夜色如墨”到“选择出拳”逐句读过", dimension_note="替换为：读了哪些段")
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertIn("替换为", out["message"])

    def test_the_authors_counterexample_is_refused(self):
        code, out = self.review("全段逐句读过，无需修改")
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertIn("quotes nothing from it", out["message"])
        self.assertEqual(self.guard("status", "run.json")[1]["gate"]["editorial"], "UNTESTED")

    def test_generic_or_copied_reasons_are_refused(self):
        generic = {key: "开场定调，作者的口吻" for key in self.items}
        code, out = self.review("“夜色如墨”到“选择出拳”逐句读过", reasons=generic)
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertIn("names only the kind of effect", out["message"])
        copied = {key: "这一处交作者看，改法写进交付说明" for key in self.items}
        code, out = self.review("“夜色如墨”到“选择出拳”逐句读过", reasons=copied)
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertIn("copied to several places", out["message"])

    def test_zero_change_with_its_basis_passes_and_says_what_was_checked(self):
        code, out = self.review("“夜色如墨”开头到“选择出拳”结尾逐句读过：没有改，命中的几处都列给作者")
        self.assertEqual(code, 0, out)
        gate = self.guard("status", "run.json")[1]["gate"]
        self.assertEqual(gate["editorial"], "PASS[self_check]")
        self.assertEqual((gate["review_record"], gate["content_judgment"]), ("FORMAT_CHECKED", "SELF_CHECK"))
        self.assertIn("record=FORMAT_CHECKED, content=NOT_VERIFIED_BY_PROGRAM", gate["summary"])
        self.assertIn("文笔和去 AI 味的判断没有经过程序验证", gate["summary"])
        self.assertEqual(gate["permissions"]["claim_prose_quality"]["decision"], "BLOCK")


    def test_made_up_quotes_wrong_places_and_empty_reasons_are_refused(self):
        note = "“夜色如墨”开头到“选择出拳”结尾逐句读过：没有改，命中的几处都列给作者"
        end = COMBAT.find("依然选择出拳")
        keep = {"decision": "keep", "judgment": "结尾这一句是格言式的点题", "reason": "结尾“依然选择出拳”交作者定"}
        two = [{"from": "夜色如墨", "to": "他不能输。", "note": "“夜色如墨，废弃的钢铁厂”到“他不能输”没有改，列给作者"},
               {"from": "一股前所未有", "to": "选择出拳。", "note": "“夜色如墨，废弃的钢铁厂”这一段读过，没有改"}]
        cases = [
            ("a quote that is not in the text", "EVIDENCE_NOT_FOUND",
             lambda v: v["evidence"].__setitem__(0, {"quote": "陈野一拳打碎了钢柱", "in": "candidate"})),
            ("an anchor that is not in the text", "EVIDENCE_NOT_FOUND",
             lambda v: v["expression"]["segments"][0].__setitem__("from", "夜色如漆")),
            ("a kept sentence that is not in the text", "EVIDENCE_NOT_FOUND",
             lambda v: v["expression"]["decisions"].append(dict(keep, quote="陈野一拳打碎了钢柱"))),
            ("a kept sentence at the wrong place", "EVIDENCE_NOT_FOUND",
             lambda v: v["expression"]["decisions"].append(dict(keep, quote="依然选择出拳", offset=3))),
            ("a change that was not made", "CHANGE_NOT_APPLIED",
             lambda v: v["expression"]["decisions"].append({"decision": "change", "before": "一股前所未有的压迫感扑面而来",
                                                            "after": "", "judgment": "单独成段替读者下结论",
                                                            "reason": "删掉这句直述的压迫感"})),
            ("an empty keep reason", "REVIEW_INCOMPLETE", lambda v: v["machine_dispositions"][0].__setitem__("reason", " ")),
            ("an empty decision reason", "REVIEW_INCOMPLETE",
             lambda v: v["expression"]["decisions"].append(dict(keep, quote="依然选择出拳", reason=""))),
            ("a note quoting another part", "REVIEW_INCOMPLETE",
             lambda v: v["expression"].__setitem__("segments", two)),
        ]
        for what, failure, mutate in cases:
            code, out = self.review(note, mutate=mutate)
            self.assertEqual((code, out.get("failure")), (2, failure), (what, out))
        self.assertEqual(self.guard("status", "run.json")[1]["gate"]["editorial"], "UNTESTED")
        # The same record with the kept sentence at its real place goes through.
        code, out = self.review(note, mutate=lambda v: v["expression"]["decisions"].append(dict(keep, quote="依然选择出拳",
                                                                                              offset=end)))
        self.assertEqual(code, 0, out)


class Wiring(unittest.TestCase):
    def test_the_judgments_are_in_the_rules(self):
        audit = read("references/prose-audit.md")
        for heading in ("## 现成身体反应：次数只是线索（r5.48）", "## 情绪直述的改法：按这一场选（r5.48）",
                        "## 点题式收尾：认识和措辞分开判（r5.48）"):
            self.assertIn(heading, audit)
        self.assertIn("出现次数只是线索", audit)
        self.assertIn("不要把“少写身体反应”变成新的硬规定", audit)
        self.assertIn("认识成立、措辞不合：留认识，改措辞", audit)
        editing = read("references/editing.md")
        for scope in ("| 严格保义润色 |", "| 在既有事实内改写 |", "| 场景重写或扩写 |"):
            self.assertIn(scope, editing)
        self.assertIn("原段成立，只说明不用为别的毛病动它，不是不往作者要的方向改的理由", editing)
        self.assertIn("6. **交稿说明（r5.48）。**", editing)
        self.assertIn("换成指节发白、深吸一口气这类现成反应不算改好", read("references/sentence-craft.md"))
        self.assertIn("2.1 怎样用（r5.48）", read("references/scene-dramaturgy.md"))

    def test_the_other_entries_no_longer_send_emotion_to_body_reactions_only(self):
        # Found after the held-out comparison: two more entries still said "turn it into a body reaction".
        self.assertNotIn("转成这一场独有的生理反应和微动作", read("references/short-fiction.md"))
        self.assertNotIn("情绪是不是转成了生理反应和微动作", read("references/adversarial-review.md"))
        for rel in ("references/short-fiction.md", "references/adversarial-review.md"):
            self.assertIn("“情绪直述的改法：按这一场选”", read(rel), rel)
        audit = read("references/prose-audit.md")
        self.assertIn("不是说只出现一次就放行", audit)
        self.assertIn("也不是放行条件", audit)
        self.assertNotIn('"text": "深吸一口气", "min_occurrences": 3', audit)
        # Found on the reproduction material: "写真的就留" and "一股劲不报" were cited to keep ready-made reactions.
        self.assertIn("“真的”是说这个反应在这一场有来由、接着有用处", audit)
        self.assertIn("“一股从没有过的劲冲上来”是在替读者宣布他变强", audit)
        self.assertIn("“下一秒”“就在这时”前面没有一个在走的时刻可接", audit)
        self.assertIn("也不换个说法留下", read("assets/revision-card.md"))
        self.assertIn("拿掉人名还能当一句道理讲", audit)
        self.assertIn("拿掉人名还能当一句道理讲", read("assets/revision-card.md"))  # r5.49 review P2

    def test_the_gate_card_and_the_revision_card_say_the_same(self):
        card = read("assets/delivery-gate-card.md")
        self.assertLessEqual(len(card.encode("utf-8")), 5004)
        self.assertIn("换成现成反应不算改好，它出现一次也要看", card)
        self.assertIn("点名方向有那类毛病就改，没有可不改，不改剧情", card)  # r5.49: zero changes allowed (plan item 34)
        self.assertNotIn("原段成立也照改", card)
        self.assertIn("删了有用的也算", card)  # r5.49 review A02: not judged by the amount deleted
        self.assertNotIn("只删不补变薄", card)
        self.assertNotIn("情绪、氛围直述词改成生理反应和微动作", card)
        revision = read("assets/revision-card.md")
        for phrase in ("**严格保义润色**", "**在既有事实内改写**", "**场景重写或扩写**", "现成身体反应（出现一次也要看）",
                       "交稿说明", "单文件不带风格包", "不说“去 AI 味已完成”"):
            self.assertIn(phrase, revision)

    def test_the_single_file_opens_with_both_cards(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "portable.zip"
            proc = subprocess.run([sys.executable, "-I", str(SCRIPTS / "export_portable.py"), str(target), "--mode", "sale",
                                   "--format", "portable"], capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(proc.returncode, 0, proc.stderr + proc.stdout)
            with zipfile.ZipFile(target) as archive:
                single = archive.read("portable-novel-workshop.md").decode("utf-8")
        gate = single.index("# 内嵌内容：assets/delivery-gate-card.md")
        revision = single.index("# 内嵌内容：assets/revision-card.md")
        constitution = single.index("# 内嵌内容：CONSTITUTION.md")
        self.assertLess(gate, revision)
        self.assertLess(revision, constitution)
        self.assertLess(revision, len(single) * 0.05)
        self.assertEqual(single.count("# 内嵌内容：assets/revision-card.md"), 1)


if __name__ == "__main__":
    unittest.main()

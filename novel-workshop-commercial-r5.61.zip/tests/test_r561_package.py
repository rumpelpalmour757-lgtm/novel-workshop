#!/usr/bin/env python3
"""r5.61: the version is the same everywhere, and the release notes say what this release did.

r5.60 pinned its version in test_r560_package.py; from r5.61 on that file checks that the r5.60 entries stay in the
changelog and the verification notes as history, and the current version is pinned here, the same way.

The first part pins the version (CLOSE-04, items 1 to 3): the five pages, the manifest, the headings of the two notes
and the line under the verification heading; the whole version line of SKILL.md and of README.md, each saying what
this release did and nothing it did not do (searches refused with 401 or 403 do not stop the run, and collect does not
look for Pillow first: neither was done, so neither is claimed); README under its byte budget, its "本版" section on
r5.61, and r5.60 one line under the earlier releases, above r5.59. One more check is on USAGE.md's sentence on what ran
in the making of this release (CLOSE-14, first place).

The second part checks what the two notes must cover (CLOSE-04, items 4 to 16): QUICKSTART's sentence on delivery
records names r5.60 only once the rehearsal is done and holds, and the notes say so; where the release comes from,
told in the coordinator's words (the author asked for the visual chain to be upgraded, read the coordinator's plan and
said to do as the coordinator advised), without the author's words and without naming any application; what each part
changed; the one thing the author approved kept apart from what the coordinator did on its own advice (the three things
the plan asked the author to decide, the three things only the author knows, the five questions put to the author later
and not answered yet), with the note that the author can change them; what the coordinator decided on the way; the
incompatible changes and how to upgrade and roll back; what did not change; the known issues, one per line, numbered
without a gap; the test counts the notes give against the test files; what the verification notes say was run, the
comparison of the two releases and what it cannot show, the author's device test (not done: the notes say so, and the
pages still say the host was not verified); the checks filled in late, marked the same way in both notes; and nothing
promised for a later release.

The author's words are kept in the maintenance notes, outside the package; no page may quote them. That is checked in
the maintenance environment, not here, and this file holds neither the words nor a fingerprint of them. These tests
only check that the pages and the notes say what they must; they do not show that anything writes better.
"""
import json
import os
from pathlib import Path
import re
import sys
import unittest

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
VERSION = "2026-11-27-r5.61"
DATE = "2026-11-27"  # the manifest date: the day of the latest rebuild
TITLE = "小说写作工坊 r5.61"
PREVIOUS = "2026-11-26-r5.60"
PAGES = ("README.md", "QUICKSTART.md", "USAGE.md", "EXAMPLES.md", "skills/novel-workshop/SKILL.md")
WHAT = ("照参考图改一份已有的稿有了做法，交稿说明的出处多一类“照图”；素材卡“现场素材”加了可填可不填的几栏；"
        "新加看图与手记卡（先看宿主有什么，宿主自己找图、宿主画的图怎样记，跑不了脚本时记手记）；"
        "灵感库收对话里看过、没有文件的图，作者给的图一条命令入库；找图脚本修了几处失败时说不清的地方。")
README_LINE = "版本：%s（`%s`）。在 r5.60 上升级视觉链路：%s" % (TITLE, VERSION, WHAT)
SKILL_LINE = ("%s（`%s`）。在 r5.60 上升级视觉链路：%s交付门五个脚本、门卡、改稿卡、宪法正文、登记表、安装器和上锁的六节没有改；"
              "这一版写给宿主的做法没有在真的宿主上验证过。" % (TITLE, VERSION, WHAT))
README_BUDGET = 24000  # bytes; test_r554_dialogue.py, test_r520_review_repairs.py, test_r559_package.py and
#                        test_r560_package.py hold it too
NOT_DONE = ("被拒绝", "401", "403", "Pillow")  # the two halves this release did not do (PLAN section 1)
BOUND_SCRIPTS = ("`workflow_guard.py`", "`punctuation_lint.py`", "`prose_lint.py`", "`fact_guard.py`", "`project_state.py`")
PENDING = "待补"
# the checks filled in late: heading in the verification notes, start of the line in the changelog
LATER = (("公开包查漏", "- 公开包查漏"), ("升级和退回", "- 升级和退回演练"), ("节外的话对读", "- 节外的话对读"),
         ("新旧对照", "- 新旧对照"), ("作者设备上的试用", "- 作者设备上的试用"))
QUICK = "升级的，交付记录照旧。"


def read(path):
    return (ROOT / path).read_text(encoding="utf-8")


def newest_entry(text):
    """The text of the first '## ' section of a changelog-like page, heading included."""
    parts = re.split(r"(?m)^(?=## )", text)
    return parts[1] if len(parts) > 1 else ""


def part(text, heading):
    """From a '### ' heading to the next '### ' heading ("" if the heading is missing)."""
    start = text.find("\n### " + heading)
    if start < 0:
        return ""
    end = text.find("\n### ", start + 1)
    return text[start:] if end < 0 else text[start:end]


def body(section):
    """A '### ' section without its heading line, from its first non-empty line."""
    return section.split("\n### ", 1)[-1].split("\n", 1)[-1].lstrip("\n") if section else ""


def version_line(page):
    """The line of a page that states its version."""
    return next((line for line in read(page).splitlines() if "`" + VERSION + "`" in line), "")


def quickstart_line():
    return next((line for line in read("QUICKSTART.md").splitlines() if QUICK in line), "")


class Version(unittest.TestCase):
    def test_the_version_is_the_same_everywhere(self):
        for page in PAGES:
            self.assertIn("`" + VERSION + "`", read(page).split("\n## ", 1)[0], page)
        manifest = json.loads(read("PACKAGE-MANIFEST.json"))
        self.assertEqual((manifest["version"], manifest["date"]), (VERSION, DATE))
        verification = newest_entry(read("VERIFICATION.md"))
        self.assertTrue(verification.startswith("## " + VERSION + " 的验证"), verification[:60])
        self.assertIn("\n小说写作工坊 · `" + VERSION + "`\n", verification)
        self.assertTrue(newest_entry(read("CHANGELOG.md")).startswith("## %s（%s）" % (VERSION, TITLE)))
        # SKILL.md's version line is rewritten whole; what follows it ("下面几个模块默认都关着……") stays
        self.assertIn("\n" + SKILL_LINE + "下面几个模块默认都关着，谁来开、记在哪，见“可选模块：默认关着”。\n",
                      read("skills/novel-workshop/SKILL.md"))
        for page, line in (("README.md", README_LINE), ("skills/novel-workshop/SKILL.md", SKILL_LINE)):
            for words in NOT_DONE:
                self.assertNotIn(words, line, (page, words))

    def test_the_title_names_this_release_and_no_page_calls_it_a_candidate(self):
        for page in ("README.md", "skills/novel-workshop/SKILL.md"):
            self.assertIn(TITLE, version_line(page), page)
        for page in PAGES:
            line = version_line(page)
            self.assertNotIn("候选", line.split("`" + VERSION + "`")[0], page)  # what the page says this release is
            self.assertNotIn("`" + PREVIOUS + "`", line.split("。")[0], page)
        for page in ("CHANGELOG.md", "VERIFICATION.md"):
            heading = newest_entry(read(page)).splitlines()[0]
            self.assertNotIn("候选", heading, page)

    def test_the_readme_says_what_this_release_did(self):
        readme = read("README.md")
        self.assertLess(len(readme.encode("utf-8")), README_BUDGET)
        self.assertIn("\n" + README_LINE + "\n", readme)
        current = next(p for p in re.split(r"(?m)^(?=## )", readme) if p.startswith("## 本版"))
        self.assertTrue(current.startswith("## 本版（r5.61）"), current[:40])
        for phrase in ("**照图改已有稿**", "原稿写明的照原稿，图只补没写的", "**看图与手记卡**", "跑不了脚本时记手记",
                       "宿主自己找的图、画的图各有记法", "**灵感库**", "收对话里看过、没有文件的图", "交稿时记借了哪几样",
                       "**找图脚本**", "限流就停", "只有来源页的请求也收",
                       "交付门脚本、门卡、改稿卡、宪法正文、登记表、上锁六节没改", "[CHANGELOG.md](CHANGELOG.md)",
                       "宿主里的做法都没验证", "**不说明写得更好**"):
            self.assertIn(phrase, current, phrase)
        for phrase in ("待补", "下一版") + NOT_DONE:
            self.assertNotIn(phrase, current, phrase)
        history = readme.split("## 历次版本", 1)[1].split("\n## ", 1)[0]
        self.assertLess(history.index("- **r5.60**："), history.index("- **r5.59**："))


class Usage(unittest.TestCase):
    def test_what_ran_in_the_making_of_this_release(self):  # CLOSE-14, first place
        part_ = read("USAGE.md").split("### 视觉素材（r5.35 起，可选）", 1)[1].split("\n### ", 1)[0]
        item = next(line for line in part_.splitlines() if line.startswith("- **本版在制作环境里的实际情况**："))
        for phrase in ("一项也没有重新跑通", "从没在同一台机器上一起通过", "没有在真实网络上跑过"):
            self.assertIn(phrase, item, phrase)
        self.assertNotIn("被网络拒绝", part_)
        # what follows the new sentences stays: ask the reader to run doctor --probe and one whole run
        self.assertIn("这一版改过的脚本没有在真实网络上跑过。在你的电脑上跑一次 `doctor --probe` 和一次完整运行", item)


class ReleaseNotes(unittest.TestCase):
    def setUp(self):
        self.entry = newest_entry(read("CHANGELOG.md"))
        self.assertTrue(self.entry.startswith("## %s（%s）" % (VERSION, TITLE)), self.entry[:60])
        self.verification = newest_entry(read("VERIFICATION.md"))

    def test_quickstart_names_r560_only_after_the_rehearsal(self):  # CLOSE-04 item 4, CLOSE-13
        line = quickstart_line()
        self.assertIn("从合并候选、r5.55、r5.56、r5.57、r5.58", line)
        self.assertIn("r5.59", line)
        rehearsal = part(self.verification, "升级和退回")
        self.assertTrue(rehearsal.strip())
        tests = part(self.entry, "六、")
        if PENDING in rehearsal:
            self.assertNotIn("r5.60", line)
            self.assertIn("没有补 r5.60", tests)
        else:
            self.assertIn("r5.59 或 r5.60 升级的，交付记录照旧。", line)
            self.assertIn("`QUICKSTART.md` 讲交付记录的那一句补上了 r5.60", tests)
            self.assertIn("`governance_warnings` 是空的", tests)
            self.assertIn("`QUICKSTART.md` 讲交付记录的那一句照这个结果补上了 r5.60", self.verification)

    def test_the_opening_says_where_it_comes_from_and_what_it_does_not_claim(self):  # item 5
        opening = self.entry.split("\n### ", 1)[0]
        for phrase in ("在 r5.60（`2026-11-26-r5.60`）上做", "只动视觉链路", "作者要升级视觉链路", "编排方先做了只读的摸底",
                       "写了一份方案", "作者看过，让照编排方的建议办", "作者可以改，说一声就改",
                       "公开包里不写作者的原话", "不点名任何一家应用（一律说“宿主”）", "同一个模型的新实例",
                       "**不是独立评审**", "新旧对照从简做了一遍", "作者设备上的试用没有做",
                       "写给宿主的做法没有在真的宿主上验证过", "没有联网重跑找图", "**不说明写得更好**",
                       "r5.60 的包原样留着"):
            self.assertIn(phrase, opening, phrase)

    def test_the_parts_say_what_changed(self):  # item 6
        expected = {
            "一、": ("`references/editing.md`", "`assets/voice-material-card.md`", "`SKILL.md`", "手上有参考图时",
                    "这一处先不补", "照图可以补的边界", "“照图”", "照宿主画的图", "“待判断的变化”那一块",
                    "作者采纳以前不算本书事实", "没改，照原稿", "工坊编的", "九栏可填可不填的", "宿主画的图另写‘宿主画的’",
                    "交付门脚本没有改，不核新加的九栏", "没有在真实的书上用过"),
            "二、": ("`assets/visual-notes-card.md`（新）", "`references/chapter-confirmation.md`",
                    "`references/drafting.md`", "`references/projects.md`", "`scripts/export_portable.py`",
                    "能跑脚本、脚本连得上网、五个项目装好了", "宿主画的图", "写进了哪一稿", "两边都记了的以库为准",
                    "上锁的“确认是什么意思”一节一字没动", "`chapter_policy`", "`visual_required:false`",
                    "章节门的脚本没有改", "手记没有修订号", "没有在真的宿主上验证过"),
            "三、": ("`scripts/inspiration_library.py`", "`scripts/inspiration_write.py`",
                    "`assets/inspiration-selection.example.json`（新）", "`references/inspiration-library.md`",
                    "格式还是第 2 版", "不用迁移", "`conversation`", "`author_chat`", "`host_generated`", "`drafted`",
                    "`shown_as`", "图里看不清的", "第 M 章已采纳", "`record`", "`UNCHANGED`", "`add-image`",
                    "`--source web`", "`--source generated`", "`--mode` 只收 `add`、`replace`", "`--conflict`",
                    "改不回 `drafted`", "交付门不核", "手记并进库只在现编的材料上走过"),
            "四、": ("`scripts/visual_materials/common.py`", "`providers/openverse.py`", "`providers/searxng.py`",
                    "`scripts/visual_materials/doctor.py`", "`scripts/visual_materials/adopt.py`",
                    "`scripts/visual_materials/verify.py`", "`assets/visual-request.example.json`",
                    "`assets/visual-choice.example.json`", "`references/visual-materials.md`", "429",
                    "被拒绝（401、403）的照 r5.60 记一条、接着发下一个词", "`pages_only`", "退出码从 1 变 0",
                    "`run_check`", "`RUN_STEPS_VERIFIED`", "不等于五项接通", "工坊没核过", "另外取得权利人的授权",
                    "`collect.py` 没有改", "没碰真实的搜索服务"),
            "五、": ("`SKILL.md`", "`README.md`", "`QUICKSTART.md`", "`EXAMPLES.md`", "`USAGE.md`",
                    "约一百四十万", "`add-image`", "`scripts/inspiration_library.py`"),
            "六、": ("`tests/test_r560_package.py` 转成历史", "611 个", "别的现成测试一项也没有改",
                    "`PACKAGE-MANIFEST.json`", "`portable-novel-workshop.md`", "清单列 620 个文件",
                    "计划里的条目编号", "版本号改成 `%s`" % VERSION),
        }
        for heading, phrases in expected.items():
            text = part(self.entry, heading)
            self.assertTrue(text, heading)
            for phrase in phrases:
                self.assertIn(phrase, text, (heading, phrase))

    def test_what_the_author_approved_is_kept_apart(self):  # item 7
        approved = part(self.entry, "作者认了的")
        self.assertTrue(body(approved).startswith("只有一条：作者看过方案，让照编排方的建议办。"), approved[:80])
        self.assertIn("公开包里不写作者的原话", approved)
        self.assertNotRegex(approved, r"(?m)^\s*(?:- |\d+\. )")  # one statement, no list of other approvals
        own = part(self.entry, "编排方照自己的建议办、作者没有单独回过的")
        phrases = ("对话里看过、没有文件的图进库", "宿主画的图：可以用，带四条限定", "“写前看图”的规矩：不动",
                   "宿主能看图、能自己搜索、跑不了脚本", "照现有规矩先问", "手上只有原稿和图",
                   "发布：由作者定", "在作者自己的设备上试几步：没有做", "拿什么算做好了：没有说法",
                   "交付门卡、改稿卡上要不要加讲图的话：不加", "宿主自己找的图要不要另算一种视觉准备：不另算")
        for phrase in phrases + ("**不是作者定的**", "作者可以改，说一声就改", "五个项目在一台机器上真接通"):
            self.assertIn(phrase, own, phrase)
        for phrase in phrases:
            self.assertNotIn(phrase, approved, phrase)
        decided = part(self.entry, "编排方路上定下的做法")
        self.assertIn("要改，说一声就改", decided)
        numbers = [int(n) for n in re.findall(r"(?m)^(\d+)\. ", decided)]
        self.assertEqual(numbers, list(range(1, len(numbers) + 1)))
        self.assertGreaterEqual(len(numbers), 10)
        for phrase in ("那一处先不补", "“待判断的变化”那一块", "另起一页卡", "版本号不升", "只做“限流就停”",
                       "`--source web`、`--source generated`", "`--mode` 只收 `add`、`replace`",
                       "能跑脚本、脚本连得上网、五个项目装好了", "不加新的命令行开关", "图里看不清的"):
            self.assertIn(phrase, decided, phrase)
        differs = part(self.entry, "实施时和计划不一致的地方")
        for phrase in ("`2026-11-26-r5.61`", "`%s`" % VERSION, "`--id` 写它的编号", "四句比计划的原话多了半句",
                       "验证以后又改了几处", "另冻了一版", "加了“照图”两个字", "连宿主自己找在内",
                       "每一遍一位新实例、两位不知道版本的核对人", "计划里排了不做的几样照旧没做"):
            self.assertIn(phrase, differs, phrase)

    def test_the_tests_listed_are_the_test_files(self):  # item 8
        tests = part(self.entry, "六、")
        named = re.findall(r"`tests/(test_r561_[a-z_]+\.py)`（(\d+) 项", tests)
        self.assertEqual(sorted(name for name, _ in named),
                         sorted(path.name for path in (ROOT / "tests").glob("test_r561_*.py")))
        self.assertEqual(len(named), 6)
        for name, count in named:
            source = (ROOT / "tests" / name).read_text(encoding="utf-8")
            self.assertEqual(len(re.findall(r"(?m)^    def test_", source)), int(count), name)
        self.assertIn("`tests/test_r560_package.py` 转成历史", tests)

    def test_the_incompatible_changes_and_how_to_upgrade_and_roll_back(self):  # item 9
        incompatible = part(self.entry, "不兼容的变化")
        for phrase in ("`conversation`", "`author_chat`", "`host_generated`", "`drafted`", "格式名还是第 2 版",
                       "`source.type must be one of author_file, link, search, text`",
                       "`observation is {scope, image_sha256, seen, unclear, by, date}`",
                       "`unknown field(s) drafted`", "原本是 r5.60 认的记法的条目也一样", "“搜索词：”后面空着",
                       "印成普通借的", "图里看不清的", "只管第 2 版的库", "任何一章记过 establish",
                       "第 M 章已采纳", "和 r5.60 逐字相同", "`pages_only`、退出码 0", "退出码从 1 变 0",
                       "`UNCHANGED`、退出码 0", "被拒绝（401、403）的照 r5.60 接着发", "`run_check`",
                       "`record`、`drafted` 两段", "`add-image`", "技能目录多了四个文件", "多嵌三份样例",
                       "“参考图”", "九栏", "`input_ready` 是 BLOCKED"):
            self.assertIn(phrase, incompatible, phrase)
        upgrade = part(self.entry, "怎样升级和退回")
        for phrase in ("从 r5.60 升上来", "python install.py --upgrade --dry-run", "`assets/project-packs/`",
                       "灵感库不用迁移", "交付记录照旧", "`governance_warnings` 是空的", "新加的四个文件",
                       "这一版没有删掉的文件", "从 r5.59 或更早升上来", "退回 r5.60", "先退库", "`restore`",
                       "`library.history/log.jsonl`", "`--root <库所在的文件夹>`", "能 `restore` 回来",
                       "库留着不动", "不照印出来的“搜索词：”抄", "不要为了让 r5.60 的 `check` 过去",
                       "没人看过或作者说的", "r5.60 没有 `add-image`", "手记是文本文件", "手动把备份移回原处",
                       "升级和退回演练：做了", "不是发布用的 ZIP", "`--include-dev`、`--keep`", "没有验证"):
            self.assertIn(phrase, upgrade, phrase)

    def test_what_did_not_change(self):  # item 10
        unchanged = part(self.entry, "没有改的")
        for phrase in BOUND_SCRIPTS + ("逐字节相同", "`assets/delivery-gate-card.md`", "`assets/revision-card.md`",
                                       "`CONSTITUTION.md`", "`install.py`", "`assets/constitution-rules.json`",
                                       "连 `note` 也没有动", "交付门卡、改稿卡上没有讲图的话", "上锁的六节一字没动",
                                       "83 张风格卡", "`chapter_gate.py`", "`learning_loop.py`",
                                       "`demonstration_memory.py`", "`visual_materials/collect.py`",
                                       "这一版改的脚本只有 13 个", "L1、L2 两行没有动"):
            self.assertIn(phrase, unchanged, phrase)
        line = next(l for l in unchanged.splitlines() if "这一版改的脚本只有 13 个" in l)
        self.assertEqual(len(re.findall(r"`[a-z_/]+\.py`", line.split("13 个：", 1)[1])), 13)

    def test_the_known_issues(self):  # item 11
        known = part(self.entry, "这一版的已知问题")
        lines = re.findall(r"(?m)^(\d+)\. (.*)$", known)
        self.assertEqual([int(n) for n, _ in lines], list(range(1, len(lines) + 1)))
        self.assertGreaterEqual(len(lines), 20)
        text = dict((int(n), t) for n, t in lines)
        for number, phrases in ((1, ("没有在真的宿主上验证过",)),
                                (2, ("“写前看图”", "多问作者一次", "`visual_required:false`", "作者当章的原话", "脚本不绑")),
                                (3, ("交付门卡、改稿卡上没有讲图的话",)),
                                (6, ("从没在同一台机器上一起跑通", "一项也没有重新跑")),
                                (7, ("401、403", "照旧发")),
                                (14, ("Pillow", "意外退出")),
                                (21, ("改不回 `drafted`", "已成本书事实，照前文写")),
                                (24, ("三份输入样例也整份嵌着",))):
            for phrase in phrases:
                self.assertIn(phrase, text[number], (number, phrase))
        earlier = part(self.entry, "上一版留下的已知问题")
        for phrase in ("r5.60 一节", "这一版都没有动", "不在这里重抄", "题面写了 42 道", "章节门 29 种情形"):
            self.assertIn(phrase, earlier, phrase)


class Verification(unittest.TestCase):
    def setUp(self):
        self.entry = newest_entry(read("VERIFICATION.md"))
        self.assertTrue(self.entry.startswith("## " + VERSION + " 的验证"), self.entry[:60])
        self.changelog = newest_entry(read("CHANGELOG.md"))

    def test_the_verification_notes_name_what_was_run(self):  # item 12
        for phrase in ("python3 -I -B tests/run_tests.py", "Python 3.13", "Python 3.9", "`__pycache__`", "同一个模型",
                       "**不是独立评审**", "第一次冻结", "第二次冻结", "`2026-11-26-r5.61`", "`tests/test_r561_package.py`",
                       "`tests/test_r560_package.py`", "611 个", "**不说明写得更好**"):
            self.assertIn(phrase, self.entry, phrase)
        rows = 0
        for line in part(self.entry, "全套测试").splitlines():
            match = re.search(r"运行 (\d+) 项，跳过 (\d+) 项，其余 (\d+) 项全部通过", line)
            if match:
                rows += 1
                ran, skipped, passed = (int(n) for n in match.groups())
                self.assertEqual(ran - skipped, passed, line[:60])
        self.assertGreaterEqual(rows, 2)  # Python 3.13 and Python 3.9, on the last package folder
        # the ZIP holds what the manifest lists and the manifest itself
        listed = len(json.loads(read("PACKAGE-MANIFEST.json"))["files"])
        packaging = part(self.entry, "清单和单文件版")
        self.assertEqual([int(n) for n in re.findall(r"ZIP 里 (\d+) 个文件", packaging)], [listed + 1])
        self.assertIn("清单列的 %d 个加清单自己" % listed, packaging)
        self.assertIn("`--version %s --date %s`" % (VERSION, DATE), packaging)
        size = (ROOT / "portable-novel-workshop.md").stat().st_size
        self.assertIn("单文件版 {:,} 字节".format(size), packaging)
        machine = part(self.entry, "机器核对")
        for phrase in ("一条命令入库", "在对话里看过的图、宿主画的图", "`drafted`", "`establish`", "只列一次",
                       "`UNCHANGED`", "`pages_only`", "断着网的 `doctor`", "去重、排序没装", "章节门四种情形",
                       "九栏", "三条手记", "两种模式", "429", "旧库", "第二次冻结以后"):
            self.assertIn(phrase, machine, phrase)
        locked = part(self.entry, "上锁的六节")
        for phrase in ("`locked_check.py`", "`ALL OK`", "`darwin_eval.py freeze`", "`INSUFFICIENT_EVIDENCE`",
                       "不判 `BLOCKED_CONSTITUTION_CHANGE`", "连 `note` 也没有动"):
            self.assertIn(phrase, locked, phrase)
        records = part(self.entry, "交付记录")
        for phrase in ("`governance_warnings` 是空的", "开始时版本 NWC-1.8，现在 NWC-1.8", "四项状态"):
            self.assertIn(phrase, records, phrase)

    def test_the_comparison_says_what_it_cannot_show(self):  # item 13
        compared = part(self.entry, "新旧对照")
        self.assertTrue(compared.strip())
        if body(compared).startswith("没有做"):
            self.assertIn("新旧对照没有做", read("README.md"))
            return
        for phrase in ("同一个模型", "不是独立评审", "不是作者的宿主", "各只做了一遍", "不说明 r5.60 更差",
                       "**不说明写得更好**", "宿主自己找图、宿主画图不在这次对照里", "新版不如旧版的地方",
                       "模型那一半没有重做"):
            self.assertIn(phrase, compared, phrase)
        self.assertIn("新旧对照只做了一遍", read("README.md"))

    def test_the_device_test(self):  # item 14
        device = part(self.entry, "作者设备上的试用")
        self.assertTrue(device.strip())
        if body(device).startswith("没有做"):
            self.assertIn("这一版写给宿主的做法没有在真的宿主上验证过", read("skills/novel-workshop/SKILL.md"))
            self.assertIn("宿主里的做法都没验证", read("README.md"))
            self.assertNotIn("下一版", device)
        else:
            for phrase in ("桌面", "手机", "没验证"):
                self.assertIn(phrase, device, phrase)
        # no application is named: the section has no Latin words but the names of the package's own pages
        self.assertLessEqual(set(re.findall(r"[A-Za-z]{2,}", device)), {"SKILL", "md", "README"})

    def test_the_checks_filled_in_late_are_marked_the_same_in_both_notes(self):  # item 15
        unverified = part(self.changelog, "没有验证的")
        waiting = []
        for heading, start in LATER:
            section = part(self.entry, heading)
            self.assertTrue(section.strip(), heading)
            line = next((l for l in unverified.splitlines() if l.startswith(start)), "")
            self.assertTrue(line, start)
            if PENDING in section:
                waiting.append(heading)
                self.assertIn(PENDING, line, heading)  # still to be filled in: the changelog says so too
            else:
                self.assertNotIn(PENDING, line, heading)  # filled in: the changelog no longer calls it pending
        opening = self.entry.split("\n### ", 1)[0]
        self.assertEqual(PENDING in opening, bool(waiting), waiting)
        if PENDING in part(self.entry, "公开包查漏"):
            self.assertIn("“公开包里没有作者原话、作者书里的词”算没验证", unverified)

    def test_the_newest_entries_promise_nothing_for_a_later_release(self):  # item 16
        for text in (self.entry, self.changelog):
            for phrase in ("下一版", "下个版本", "冻结以后补", "结果待补"):
                self.assertNotIn(phrase, text, phrase)
            self.assertNotRegex(text, r"r5\.(?:6[2-9]|[7-9]\d)")  # no release after this one is named


if __name__ == "__main__":
    unittest.main()

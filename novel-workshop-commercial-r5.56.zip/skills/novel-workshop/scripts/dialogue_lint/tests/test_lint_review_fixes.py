"""Smaller fixes from the merged-candidate review, each pinned by behaviour.

- the text handed to the model carries plain names, not rule labels or recipes, and
  says the author confirms before anything is applied;
- a replacement cannot bring in quotation marks or 【】 the line did not have;
- genre presets do not switch on the system-bracket anchor check, and their marker
  lists hold no setting words;
- “对某某没有说”“跟某某一起说” are not taken as the first person speaking.
All names and text are synthetic.
"""
import copy
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from dialogue_antipatterns import DIALOGUE_ANTIPATTERN_REGISTRY, scan_dialogue_antipatterns
from dialogue_core import extract_dialogues
from genre_profiles import GENRE_PROFILES
from patch_guard import apply_dialogue_patch, build_patch_request, format_patch_prompt
from voice_lint import VoiceprintProfile, analyze_voice_and_idioms

NAMES = ('周禾', '吴钧')


class ModelFacingTextTests(unittest.TestCase):
    def setUp(self):
        self.text = ['周禾说：“在左边柜里。”', '周禾说：“尽管下着雨但是还得走。”',
                     '周禾说：“我需要你去看看。”', '周禾说：“先关门。再关窗。后关灯。”']
        registry = {'周禾': VoiceprintProfile('周禾')}
        issues = scan_dialogue_antipatterns(self.text, names=NAMES, include_style_hints=True)
        issues += analyze_voice_and_idioms(self.text, registry=registry, include_style_hints=True,
                                           min_profile_quotes=1)[1]
        self.request = build_patch_request(self.text, issues)
        self.prompt = format_patch_prompt(self.request)

    def test_request_holds_names_and_descriptions_not_rule_labels_or_recipes(self):
        self.assertTrue(self.request['items'])
        for item in self.request['items']:
            for problem in item['issues']:
                self.assertEqual(set(problem) - {'name', 'description', 'matched_span', 'severity'}, set())
                self.assertTrue(problem['name'])
        for word in ('MACHINE', 'TRANSLATIONESE', 'SYNTHETIC', 'ROBOTIC', 'CALQUE', 'ABUSE', 'COLLAPSE',
                     'rule_id', 'fix_recipe', 'rewrite_instruction', '翻译腔', '机器'):
            self.assertNotIn(word, self.prompt)

    def test_prompt_says_the_author_confirms(self):
        self.assertIn('应用前须由作者确认', self.prompt)
        self.assertNotIn('调用方', self.prompt)

    def test_report_categories_are_neutral(self):
        categories = {rule.category for rule in DIALOGUE_ANTIPATTERN_REGISTRY}
        self.assertFalse(categories & {'MACHINE_COMPRESSED', 'TRANSLATIONESE', 'SYNTHETIC_COLLOQUIAL'})
        self.assertTrue(all(rule.name for rule in DIALOGUE_ANTIPATTERN_REGISTRY))


class ReplacementMarksTests(unittest.TestCase):
    def setUp(self):
        self.paragraphs = ['周禾对吴钧说：“穿上。快走。”他把雨衣抖开。\n', '周禾说：“她说‘明早再来’。”\n',
                           '周禾说：「还是“老地方”见。」\n']
        spans = extract_dialogues(self.paragraphs, NAMES)
        issues = [{'quote_id': s.quote_id, 'para_index': s.para_index, 'quote_index': s.quote_index,
                   'start': s.start, 'end': s.end, 'source_quote': s.text, 'speaker': s.speaker,
                   'confidence': s.confidence, 'name': '测试', 'description': '测试。'} for s in spans]
        self.request = build_patch_request(self.paragraphs, issues)

    def apply(self, quote_id, replacement):
        item = next(i for i in self.request['items'] if i['quote_id'] == quote_id)
        response = {'source_hash': self.request['source_hash'], 'replacements': [
            {'quote_id': quote_id, 'original': item['original'], 'replacement': replacement}]}
        return apply_dialogue_patch(self.paragraphs, self.request, response)

    def test_marks_the_line_did_not_have_are_refused(self):
        for replacement in ('穿上。"他拔出刀。"快', '穿上。」他拔出刀。「快', '穿上。』他拔出刀。『快',
                            '穿上。＂他拔出刀。＂快', '穿上。〞他拔出刀。〝快', '穿上。【系统提示：获得雨衣】'):
            with self.subTest(replacement=replacement), self.assertRaises(ValueError):
                self.apply('p1:q1', replacement)

    def test_nested_single_quotes_and_marks_already_in_the_line_are_kept(self):
        self.assertEqual(self.apply('p1:q1', '穿上，‘快走’。')[0], '周禾对吴钧说：“穿上，‘快走’。”他把雨衣抖开。\n')
        self.assertEqual(self.apply('p2:q1', '她说‘明早再来一趟’。')[1], '周禾说：“她说‘明早再来一趟’。”\n')
        self.assertEqual(self.apply('p3:q1', '还是“老地方”吧。')[2], '周禾说：「还是“老地方”吧。」\n')

    def test_the_line_own_marks_are_still_refused(self):
        for quote_id, replacement in (('p1:q1', '穿上。”他走了。“快'), ('p3:q1', '还是“老地方”。」他走了。「见')):
            with self.subTest(quote_id=quote_id), self.assertRaises(ValueError):
                self.apply(quote_id, replacement)


class GenrePresetTests(unittest.TestCase):
    def test_no_preset_switches_on_the_anchor_check(self):
        self.assertEqual({p.genre_id: p.enable_system_bracket_anchor for p in GENRE_PROFILES.values()},
                         {genre_id: False for genre_id in GENRE_PROFILES})

    def test_marker_lists_hold_no_setting_words_or_plain_nouns(self):
        western, classical = GENRE_PROFILES['western_fantasy'], GENRE_PROFILES['classical_xianxia']
        self.assertFalse(western.has_colloquial_marker('女神在上。'))
        for noun in ('掌柜', '小二', '物件'):
            self.assertFalse(classical.has_colloquial_marker(f'{noun}来了。'))
        self.assertTrue(classical.has_colloquial_marker('且慢。'))


class RecipientTests(unittest.TestCase):
    def test_negated_or_joint_speech_after_a_recipient_stays_unknown(self):
        for text in ('周禾对吴钧没有说：“走吧。”', '周禾对吴钧没说：“走吧。”', '周禾对吴钧不敢说：“走吧。”',
                     '周禾对吴钧本想说：“走吧。”', '周禾跟吴钧一起说：“好。”', '周禾跟吴钧齐声说：“好。”',
                     '周禾跟吴钧同时说：“好。”'):
            with self.subTest(text=text):
                span = extract_dialogues([text], NAMES)[0]
                self.assertEqual((span.speaker, span.confidence), ('未知', 'unknown'))

    def test_plain_recipient_forms_still_name_the_speaker(self):
        for text in ('周禾对吴钧说：“走吧。”', '周禾对吴钧低声说：“走吧。”', '周禾朝门口那人喊：“走吧。”'):
            with self.subTest(text=text):
                span = extract_dialogues([text], NAMES)[0]
                self.assertEqual((span.speaker, span.confidence), ('周禾', 'explicit'))


if __name__ == '__main__':
    unittest.main()

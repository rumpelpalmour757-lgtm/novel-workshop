// 可选：经 Google 官方的 ACP 运行时（Antigravity CLI 的 agy acp，或 ACP Registry 的 antigravity-acp）请 Gemini 改选中的一段。
// 登录、凭据和模型请求全由官方程序自己处理；工坊只启动它、和它说 ACP，看不到也不保存 Google 账号、密码或令牌，
// 自己不发任何网络请求。回复只是候选：工坊不把它写进任何文稿，放不放进编辑器、保不保存都由作者定。
//
// 状态：未安装 → 可启动 → 待登录 → 已认证 → 可调用；另有 认证取消、认证失败、连接失败、额度受限、配置失效、取消未确认、结果未知。
// 四件事分开显示，互不代替：程序来源（作者填了核对过的 SHA-256、而且对得上）、ACP 握手、官方程序自己的登录、
// 真实的模型回复。“已认证”只说明登录成功。只有这一次连接里一次真实请求拿回了完整的正文（end_turn、没有丢行、
// 没有中途换模型、作者没有点停止），对方自称 Antigravity、不是模拟程序，而且程序来源核对过，才记“已真实接通”，
// 连同时间、请求的模型、官方程序回报的模型设置、运行时路径和版本、agentInfo。来源没核对的最多只记协议结果。
// 换了运行时（路径、种类、开关、核对的校验值、版本）就清掉；之后重新连接或登录过，就不再当作现在的状态。
//
// 旧连接作废：程序设置（路径、种类、开关、核对的校验值）和连接时那一份不一样了，或者重新检查发现程序不对
// （校验不符、找不到、和连着的不是同一个），旧连接就不能再发送：旧预览作废，“已真实接通”清掉，还没发出的那一轮
// 记成没有发出，已经发出的按停止和结果未知的老规矩了结，不自动重发。什么时候查：
// - 在页面上保存设置：和连着的那一份比，变了马上作废；
// - acp.json 在写作台外面被改了（或者环境变量变了）：不盯文件。每次读状态、预览时拿来比，对不上就报“不能发送”、
//   不算现在接通、预览里没有收件方；真正作废、断开在下一次发送或“检查运行时”的时候；
// - 发送：写“已发出”之前读一次 acp.json，写完以后再读一次，和连接、停止、收件方一起在同一段里核对，
//   核对完到发出 session/prompt 之间没有任何等待。
//
// 不做的事：不读不存 Cookie 或 OAuth 令牌；不反代；不轮换账号；不包装 agy -p；额度受限时不自动重试、
// 不改用 Gemini API 或任何付费接口；结果未知的请求不自动重发。自动互审没有实现，固定是关闭的。
// 每次发送都新开一个官方会话：上一次的内容不会带进下一次，换书、换文稿不串上下文；迟到的消息按会话编号只归原来那一轮。
//
// 本机记录（见 acp-store.mjs）：acp-status.json 给作者看的状态；acp-events.jsonl 只追加的事件（一轮真正发出之前先落盘，
// 写作台中途退出后再打开，发出了没结束的那一轮显示“结果未知”，等作者自己确认）；acp.lock 单实例锁。
// 都只记元数据（时间、编号、字数、SHA-256、运行时和模型设置），不记正文、令牌和账号信息。

import { createHash, randomUUID } from "node:crypto";
import { mkdtemp, rename, stat } from "node:fs/promises";
import { join } from "node:path";
import { configDirectory } from "./gemini-assist.mjs";
import {
  AcpClosedError,
  AcpConnection,
  AcpRpcError,
  AcpTimeoutError,
  CLIENT_CAPABILITIES,
  PROTOCOL_VERSION,
  RPC,
  methodNotFound,
} from "./acp-client.mjs";
import {
  ALLOWED_FLAGS,
  commandLine,
  inspectRuntime,
  makeScrubber,
  makeWorkDirectory,
  normalizeSha256,
  removeWorkDirectory,
  startRuntime,
  sweepStaleWorkDirectories,
} from "./acp-runtime.mjs";
import { EventJournal, InstanceLock, RecordStore, StoreError, openTurns, readJsonStrict, writePrivateJson } from "./acp-store.mjs";

export const CLIENT_INFO = Object.freeze({ name: "novel-workshop", title: "小说写作工坊 本地写作台", version: "r5.50" });
export const MAX_TEXT_CHARS = 6000;
export const MAX_INSTRUCTION_CHARS = 500;
const MAX_REPLY_CHARS = 200_000;
const KEEP_TASKS = 8;

export const DEFAULT_TIMEOUTS = Object.freeze({
  versionMs: 15_000,
  initializeMs: 30_000,
  loginMs: 300_000,
  sessionMs: 60_000,
  optionMs: 30_000,
  promptIdleMs: 600_000,
  promptTotalMs: 1_800_000,
  cancelWaitMs: 20_000,
});

export const LADDER = Object.freeze(["未安装", "可启动", "待登录", "已认证", "可调用"]);
export const STATE_LABELS = Object.freeze({
  not_checked: "还没检查官方程序",
  not_installed: "未安装",
  path_invalid: "路径错误",
  checksum_mismatch: "校验不符",
  launchable: "可启动",
  needs_login: "待登录",
  authenticated: "已认证",
  ready: "可调用",
  auth_cancelled: "认证取消",
  auth_failed: "认证失败",
  connect_failed: "连接失败",
  quota_limited: "额度受限",
  config_invalid: "配置失效",
  cancel_unconfirmed: "取消未确认",
  result_unknown: "结果未知",
  store_unreadable: "本机记录读不出来",
  other_instance: "另一个在用",
  runtime_invalidated: "旧连接已作废",
});
export const OUTCOME_LABELS = Object.freeze({
  complete: "完整回复（候选稿）",
  empty: "结束了，但没有正文",
  truncated: "不完整（截断或丢了一部分）",
  turn_limit: "模型调用次数到上限（max_turn_requests）",
  refused: "官方程序拒绝回答（refusal）",
  cancelled: "已停止（官方程序确认了）",
  cancel_race: "点了停止，官方程序仍交回了整段",
  cancel_unconfirmed: "取消未确认",
  model_changed: "这一轮里模型被换了",
  unknown: "结果未知",
  auth_required: "要重新登录",
  quota: "额度受限",
  failed: "出错",
  not_sent: "没有发出",
  unknown_stop: "结束原因不认识",
});
const BUSY_LABELS = Object.freeze({
  checking: "正在检查官方程序",
  connecting: "正在连接官方程序",
  logging_in: "等官方程序完成登录：在它打开的浏览器里登录（工坊看不到、也不保存你的账号和密码）",
  opening_session: "正在打开会话、读取官方程序给出的模型和思考强度",
  setting_option: "正在切换设置",
  sending: "正在发出",
  saving: "正在保存设置",
});
const AUTH_LABELS = Object.freeze({
  unknown: "还没有登录（官方程序要求时再登录）",
  logging_in: "正在登录",
  ok: "登录成功（已认证）",
  implicit: "官方程序没有要求登录（可能记着你以前在这台电脑上的登录）",
  needed: "官方程序说要先登录",
  expired: "登录已失效，要重新登录",
  cancelled: "登录取消了",
  failed: "登录没有成功",
});
// 这些结果留着已经收到的文字，标成不完整，不当候选稿（只能复制）。
const PARTIAL_OUTCOMES = new Set(["cancelled", "cancel_race", "truncated", "turn_limit", "unknown", "cancel_unconfirmed", "model_changed", "quota", "failed", "auth_required"]);
// 这些结果“可能已经用了额度、可能已经被处理”：记进事件以后，要作者自己确认才算了结；下一轮成功也不会把它抹掉。
const OPEN_OUTCOMES = new Set(["unknown", "cancel_unconfirmed"]);

export const AUTO_REVIEW = Object.freeze({ enabled: false, label: "自动互审：关闭（订阅用途范围未确认）" });

// 试接通时发的合成示例：工坊自己编的两句，不是任何人的作品。
export const SELFTEST_SAMPLE = Object.freeze({
  text: "码头边那盏路灯忽明忽暗，照得一地碎冰一会儿白一会儿黑。修灯的老周踩着梯子上去拧了两下灯泡，灯稳住了，他自己倒差点从梯子上滑下来。",
  instruction: "这是接通测试用的合成示例，不是任何人的作品。把这两句改得紧凑一点；情节别动，别加新东西。",
});

// 固定的编辑说明。这只是请求，不是保护：官方程序有自己的工具，能不能读写别处由它决定（见说明文档）。
export const ACP_FRAME = [
  "你是中文小说编辑，替作者改一段他在本地写作台里选中的文字。",
  "只用文字回答：不要读写任何文件，不要运行命令，不要调用工具，也不要反问作者。",
  "按作者这次的要求改；作者没提到的地方不动。",
  "不加新情节、新人物、新设定或新信息，不加心理解释和总结升华。",
  "原段已经成立、没有要改的，就原样交回。",
  "只输出改好的正文，不加标题、说明、引号或列表。",
].join("\n");

export class AcpAssistError extends Error {
  constructor(status, code, message) {
    super(message);
    this.name = "AcpAssistError";
    this.status = status;
    this.code = code;
  }
}

function sha256Text(text) {
  return createHash("sha256").update(String(text), "utf8").digest("hex");
}

function charCount(text) {
  return [...String(text)].length;
}

export function duration(ms) {
  return ms >= 120_000 ? `${Math.round(ms / 60_000)} 分钟` : `${Math.max(1, Math.round(ms / 1000))} 秒`;
}

function str(value, max = 120) {
  return typeof value === "string" ? value.slice(0, max) : null;
}

export function buildPromptBlocks({ kind = "selection", text, instruction }) {
  const ask = typeof instruction === "string" && instruction.trim() ? instruction.trim() : "帮我改这段。";
  return {
    blocks: [
      { type: "text", text: ACP_FRAME },
      { type: "text", text: `作者的要求：${ask}` },
      { type: "text", text: `要改的正文：\n${text}` },
    ],
    kinds: ["frame", "instruction", kind === "selftest" ? "sample" : "selection"],
    ask,
  };
}

// 上下文快照：每段的种类、字数、SHA-256；digest 同时绑定要发的文字和发给谁（运行时、模型、思考强度），
// 预览以后这几样任何一样变了，确认就作废。不含文字本身。
export function contextSnapshot({ kind, blocks, kinds, ask, text, source = null, binding = null, at = new Date().toISOString() }) {
  const pieces = blocks.map((block, index) => ({ kind: kinds[index], type: block.type, chars: charCount(block.text), sha256: sha256Text(block.text) }));
  return {
    kind,
    pieces,
    instructionChars: charCount(ask),
    textChars: charCount(text),
    textSha256: sha256Text(text),
    totalChars: pieces.reduce((sum, piece) => sum + piece.chars, 0),
    binding,
    digest: sha256Text(JSON.stringify({ blocks, binding })),
    source,
    excluded: kind === "selftest" ? "不发任何文稿，只发工坊自带的合成示例" : "不发文件名、路径和文稿的其他部分",
    createdAt: at,
    taskId: null,
    sent: false,
  };
}

function cleanSource(source) {
  if (!source || typeof source !== "object") return null;
  const path = typeof source.path === "string" && source.path.length <= 400 && !/[\0\r\n]/.test(source.path) ? source.path : null;
  const version = typeof source.version === "string" && /^[a-f0-9]{64}$/.test(source.version) ? source.version : null;
  return path || version ? { path, version, note: "只记在本机，不发给官方程序" } : null;
}

export function preparePrompt({ kind = "selection", text, instruction, source, binding = null } = {}) {
  let body = text;
  let ask = instruction;
  if (kind === "selftest") {
    body = SELFTEST_SAMPLE.text;
    ask = SELFTEST_SAMPLE.instruction;
  } else {
    if (typeof body !== "string" || !body.trim()) throw new AcpAssistError(400, "empty_selection", "先在文稿里选中要改的那段");
    if (charCount(body) > MAX_TEXT_CHARS) throw new AcpAssistError(413, "selection_too_long", `一次最多发送 ${MAX_TEXT_CHARS} 字，请少选一些`);
    if (ask !== undefined && ask !== null && typeof ask !== "string") throw new AcpAssistError(400, "invalid_instruction", "要求必须是文字");
    if (charCount(ask || "") > MAX_INSTRUCTION_CHARS) throw new AcpAssistError(413, "instruction_too_long", `要求最多 ${MAX_INSTRUCTION_CHARS} 字`);
  }
  const built = buildPromptBlocks({ kind, text: body, instruction: ask });
  const snapshot = contextSnapshot({ kind, blocks: built.blocks, kinds: built.kinds, ask: built.ask, text: body, source: kind === "selftest" ? null : cleanSource(source), binding });
  return { blocks: built.blocks, snapshot };
}

export function parseHandshake(result) {
  if (!result || typeof result !== "object") return { problem: "官方程序对 initialize 的回应不是一个对象" };
  const version = result.protocolVersion;
  if (!Number.isInteger(version)) return { problem: "官方程序没有说它用哪个协议版本" };
  if (version !== PROTOCOL_VERSION) return { problem: `官方程序要用协议版本 ${version}，工坊只实现了版本 ${PROTOCOL_VERSION}；没有往下连` };
  const info = result.agentInfo && typeof result.agentInfo === "object"
    ? { name: str(result.agentInfo.name), title: str(result.agentInfo.title), version: str(result.agentInfo.version) }
    : null;
  const authMethods = (Array.isArray(result.authMethods) ? result.authMethods : [])
    .filter((method) => method && typeof method.id === "string" && method.id && method.id.length <= 120)
    .slice(0, 20)
    .map((method) => {
      const entry = { id: method.id, name: str(method.name) || method.id, description: str(method.description, 300), type: str(method.type, 40) };
      if (entry.type === "terminal") {
        // 终端登录：只留官方程序声明的参数（字符串，最多 10 个）和环境变量的名字，不留值。
        entry.args = Array.isArray(method.args) ? method.args.filter((arg) => typeof arg === "string" && arg.length <= 200 && !/[\0\r\n]/.test(arg)).slice(0, 10) : [];
        entry.envNames = method.env && typeof method.env === "object" && !Array.isArray(method.env)
          ? Object.keys(method.env).filter((name) => /^[A-Za-z_][A-Za-z0-9_]{0,60}$/.test(name)).slice(0, 10)
          : [];
      }
      return entry;
    });
  const caps = result.agentCapabilities && typeof result.agentCapabilities === "object" ? result.agentCapabilities : {};
  const prompt = caps.promptCapabilities && typeof caps.promptCapabilities === "object" ? caps.promptCapabilities : {};
  const mcp = caps.mcpCapabilities && typeof caps.mcpCapabilities === "object" ? caps.mcpCapabilities : {};
  const sessionCaps = caps.sessionCapabilities && typeof caps.sessionCapabilities === "object"
    ? Object.keys(caps.sessionCapabilities).filter((key) => caps.sessionCapabilities[key]).slice(0, 20).map((key) => key.slice(0, 40))
    : [];
  return {
    protocolVersion: version,
    agentInfo: info,
    authMethods,
    capabilities: {
      loadSession: caps.loadSession === true,
      promptCapabilities: { image: prompt.image === true, audio: prompt.audio === true, embeddedContext: prompt.embeddedContext === true },
      mcpCapabilities: { http: mcp.http === true, sse: mcp.sse === true },
      authLogout: Boolean(caps.auth && typeof caps.auth === "object" && caps.auth.logout),
      sessionCapabilities: sessionCaps,
    },
    // 只看它自己怎么说：能不能证明真是 Google 的程序，靠作者核对路径和校验值。
    official: /antigravity/i.test(`${info?.name || ""} ${info?.title || ""}`),
    // 工坊自己的测试程序会在 _meta 里标明自己是模拟的：它产出的一切都标成“模拟”。
    simulated: Boolean(result._meta && typeof result._meta === "object" && result._meta["novel-workshop/simulated"] === true),
  };
}

function flattenValues(options) {
  const values = [];
  for (const entry of Array.isArray(options) ? options.slice(0, 200) : []) {
    if (entry && typeof entry.value === "string") {
      values.push({ value: entry.value.slice(0, 200), name: str(entry.name) || entry.value.slice(0, 120), description: str(entry.description, 300), group: null });
    } else if (entry && Array.isArray(entry.options)) {
      for (const inner of entry.options.slice(0, 200)) {
        if (inner && typeof inner.value === "string") {
          values.push({ value: inner.value.slice(0, 200), name: str(inner.name) || inner.value.slice(0, 120), description: str(inner.description, 300), group: str(entry.name) || str(entry.group) });
        }
      }
    }
  }
  return values;
}

// 会话配置项：只收官方程序给出的；工坊只改其中“模型”和“思考强度”两类，其余只显示。
export function parseConfigOptions(list) {
  const out = [];
  for (const option of Array.isArray(list) ? list.slice(0, 30) : []) {
    if (!option || typeof option.id !== "string" || !option.id || option.id.length > 120) continue;
    out.push({
      id: option.id,
      name: str(option.name) || option.id,
      description: str(option.description, 300),
      category: str(option.category, 60),
      type: str(option.type, 40),
      currentValue: typeof option.currentValue === "string" ? option.currentValue.slice(0, 200) : typeof option.currentValue === "boolean" ? option.currentValue : null,
      values: flattenValues(option.options),
    });
  }
  return out;
}

const SETTABLE = Object.freeze({ model: "模型", thought_level: "思考强度" });

function isQuota(error) {
  if (!(error instanceof AcpRpcError)) return false;
  let data = "";
  try {
    data = JSON.stringify(error.data ?? "").slice(0, 2000);
  } catch {}
  return /quota|rate[ _-]?limit|resource[ _-]?exhausted|too many requests|\b429\b|exhausted|\bcredits?\b/i.test(`${error.rpcMessage} ${data}`);
}

function isAuthRequired(error) {
  return error instanceof AcpRpcError && !isQuota(error) && (error.code === RPC.AUTH_REQUIRED || /auth(entication)?[ _-]?required|not authenticated|unauthenticated/i.test(error.rpcMessage));
}

function newTaskId() {
  return `acp-${Date.now().toString(36)}-${randomUUID().slice(0, 8)}`;
}

export function acpConfigFile(env = process.env) {
  return join(configDirectory(env), "acp.json");
}

export function acpStatusFile(env = process.env) {
  return join(configDirectory(env), "acp-status.json");
}

export function acpEventsFile(env = process.env) {
  return join(configDirectory(env), "acp-events.jsonl");
}

export function acpLockFile(env = process.env) {
  return join(configDirectory(env), "acp.lock");
}

function cleanPreferences(value) {
  const out = {};
  if (!value || typeof value !== "object") return out;
  for (const category of Object.keys(SETTABLE)) {
    const entry = value[category];
    if (entry && typeof entry.configId === "string" && typeof entry.value === "string") {
      out[category] = { configId: entry.configId.slice(0, 120), value: entry.value.slice(0, 200), name: str(entry.name) || entry.value.slice(0, 120) };
    }
  }
  return out;
}

function cleanPathInput(value) {
  let text = String(value).trim();
  // Windows 资源管理器“复制为路径”会带一对引号。
  if (/^".*"$/.test(text) || /^'.*'$/.test(text)) text = text.slice(1, -1).trim();
  return text;
}

function publicRuntime(runtime) {
  if (!runtime) return null;
  const { realPath, identity, launchConfig, ...rest } = runtime;
  return { ...rest, realPath: realPath && realPath !== runtime.path ? realPath : null, sourceVerified: sourceVerified(runtime) };
}

function runtimeSummary(runtime) {
  return {
    state: runtime.state,
    path: runtime.path || null,
    kind: runtime.kind || null,
    args: runtime.args || null,
    version: runtime.version || null,
    size: runtime.size ?? null,
    sha256: runtime.sha256 || null,
    checksum: runtime.checksum || null,
    checkedAt: runtime.checkedAt,
  };
}

function publicSnapshot(snapshot) {
  return snapshot ? JSON.parse(JSON.stringify(snapshot)) : null;
}

function taskCounters(task) {
  return {
    chars: task.chars,
    chunks: task.chunkCount,
    nonTextChunks: task.nonTextChunks,
    thoughtChunks: task.thoughtChunks,
    toolCalls: task.toolCalls,
    toolCallUpdates: task.toolCallUpdates,
    plans: task.plans,
    otherUpdates: task.otherUpdates,
    permissionRequests: task.permissionRequests,
    permissionRejected: task.permissionRejected,
    permissionCancelled: task.permissionCancelled,
    afterCancelChunks: task.afterCancelChunks,
    lateUpdates: task.lateUpdates,
    overflow: task.overflow,
    replyGap: task.replyGap,
  };
}

// 给页面看的这一轮：正文只在页面这边出现（候选或标明不完整的部分输出），作者选中的原文不回传。
function publicTask(task) {
  if (!task) return null;
  const finished = task.state === "finished";
  return {
    id: task.id,
    kind: task.kind,
    state: task.state,
    outcome: task.outcome,
    outcomeLabel: task.outcome ? OUTCOME_LABELS[task.outcome] : null,
    stopReason: task.stopReason,
    message: task.message,
    startedAt: task.startedAt,
    sentAt: task.sentAt,
    finishedAt: task.finishedAt,
    cancelRequested: Boolean(task.cancelRequested),
    timedOut: task.timedOut || null,
    simulated: Boolean(task.simulated),
    requested: task.requested,
    reportedModel: task.reportedModel,
    modelMismatch: task.modelMismatch || null,
    ...taskCounters(task),
    streamText: finished ? null : task.chunks.join(""),
    candidate: finished ? task.candidate : null,
    partial: finished ? task.partial : null,
    insertable: finished && task.outcome === "complete" && task.kind === "selection",
    snapshot: publicSnapshot(task.snapshot),
  };
}

// 记进 acp-status.json 的这一轮：只有结果、计数和快照（字数与 SHA-256），没有任何文字。
function recordedTask(task) {
  return {
    id: task.id,
    kind: task.kind,
    outcome: task.outcome,
    stopReason: task.stopReason,
    startedAt: task.startedAt,
    finishedAt: task.finishedAt,
    simulated: Boolean(task.simulated),
    requested: task.requested,
    reportedModel: task.reportedModel,
    ...taskCounters(task),
    snapshot: publicSnapshot(task.snapshot),
  };
}

function settingFrom(options, category, pref) {
  if (pref) return { value: pref.value, name: pref.name, chosen: true };
  const option = (options || []).find((entry) => entry.category === category);
  if (!option || option.currentValue === null || option.currentValue === undefined) return null;
  const entry = option.values.find((candidate) => candidate.value === option.currentValue);
  return { value: option.currentValue, name: entry?.name || String(option.currentValue), chosen: false };
}

// 决定启动哪个程序、怎么核对它的几项。任何一项真的变了，旧连接就作废；存的还是原来的值，就什么也不变。
const LAUNCH_FIELDS = Object.freeze([["runtimePath", "程序路径"], ["kind", "种类"], ["flags", "官方开关"], ["expectedSha256", "你核对过的校验值（SHA-256）"]]);

function launchConfigOf(settings) {
  return {
    runtimePath: settings?.runtimePath || null,
    kind: settings?.kind || null,
    flags: [...(settings?.flags || [])].sort(),
    expectedSha256: settings?.expectedSha256 || null,
  };
}

function launchChanges(before, after) {
  if (!before || !after) return LAUNCH_FIELDS.map(([, label]) => label);
  return LAUNCH_FIELDS.filter(([key]) => JSON.stringify(before[key]) !== JSON.stringify(after[key])).map(([, label]) => label);
}

// 重新检查到的是不是连着的那一个程序（路径、种类、启动参数、SHA-256 都一样）。
function sameProgram(left, right) {
  return Boolean(left && right) && left.path === right.path && left.kind === right.kind
    && JSON.stringify(left.args || []) === JSON.stringify(right.args || []) && left.sha256 === right.sha256;
}

// 程序来源：作者填了核对过的 SHA-256（解压后那个程序文件的），而且和文件对得上，才算核对过。
// Windows 的 .cmd/.bat 启动脚本：算出来的只是启动脚本自己的校验值，它启动的程序没有算过，不算核对过。
function sourceVerified(runtime) {
  return Boolean(runtime && runtime.state === "launchable" && runtime.checksum?.match === true && runtime.hashOf !== "windows-shim");
}

export function isSourceVerified(runtime) {
  return sourceVerified(runtime);
}

// “已真实接通”的记录要按 r5.50 的规矩记下的才算：来源核对过、不是模拟程序。
// r5.49 记下的（没有核对来源，也没有连接编号）只当历史，显示成“以前接通过（旧规则，来源未核对）”，永远不算现在的。
function genuineReal(real) {
  return Boolean(real && real.sourceVerified === true && real.simulated !== true && real.connectionId);
}

function revokedError(revoked) {
  return new AcpAssistError(409, "acp_connection_revoked", `旧连接已作废：${revoked?.reason || "程序设置或核对结果变了"}。它不能再发送；点“检查运行时”核对好程序，再点“连接”。`);
}

export class AcpProvider {
  constructor({ env = process.env, platform = process.platform, arch = process.arch, timeouts = {}, overrides = {}, now = () => new Date(), home, tool = "写作台", eventsCapBytes, lockOptions = {} } = {}) {
    this.env = env;
    this.platform = platform;
    this.arch = arch;
    this.timeouts = { ...DEFAULT_TIMEOUTS, ...timeouts };
    this.overrides = overrides || {};
    this.now = now;
    this.tool = tool;
    this.scrub = makeScrubber({ env, platform, ...(home ? { home } : {}) });
    this.store = new RecordStore(acpStatusFile(env));
    this.journal = new EventJournal(acpEventsFile(env), eventsCapBytes ? { capBytes: eventsCapBytes } : {});
    this.lock = new InstanceLock(acpLockFile(env), lockOptions);
    this.runtime = null;
    this.connectedRuntime = null;
    this.generation = 0;
    this.conn = null;
    this.proc = null;
    this.workDir = null;
    this.handshake = null;
    this.auth = { state: "unknown" };
    this.session = null;
    this.sessions = new Map();
    this.sessionsOpened = 0;
    this.lastOptions = [];
    this.condition = null;
    this.quotaPause = null;
    this.busy = null;
    this.task = null;
    this.tasks = new Map();
    this.acknowledged = new Set();
    this.loginAbort = false;
    this.lastDiagnostics = { stderr: [], protocol: null };
    this.counters = { staleMessages: 0, strayUpdates: 0, sessionUpdates: 0 };
    this.journalCache = null;
    // 最近一次让旧连接作废的原因（重新连上以后清掉）。
    this.invalidation = null;
    // 只在这一次用的选择（检查脚本的 --model / --thinking），不写进本机设置。
    this.transientPreferences = {};
  }

  at() {
    return this.now().toISOString();
  }

  get recordWrites() {
    return Promise.all([this.store.chain, this.journal.chain]);
  }

  // ---- 本机设置与记录
  async settings() {
    let stored;
    try {
      stored = await readJsonStrict(acpConfigFile(this.env));
    } catch (error) {
      if (error instanceof StoreError) throw new AcpAssistError(500, "acp_store_unreadable", error.message);
      throw error;
    }
    const envPath = typeof this.env.NOVEL_WORKSHOP_ACP_RUNTIME === "string" ? this.env.NOVEL_WORKSHOP_ACP_RUNTIME.trim() : "";
    const overridePath = typeof this.overrides.runtimePath === "string" ? this.overrides.runtimePath.trim() : "";
    const filePath = typeof stored.runtimePath === "string" ? stored.runtimePath : "";
    const runtimePath = overridePath || envPath || filePath || null;
    const kind = [this.overrides.kind, stored.kind].find((value) => value === "agy-cli" || value === "registry-binary") || null;
    const flags = (Array.isArray(this.overrides.flags) ? this.overrides.flags : Array.isArray(stored.flags) ? stored.flags : []).filter((flag) => ALLOWED_FLAGS.includes(flag));
    return {
      runtimePath,
      runtimeSource: overridePath ? "command" : envPath ? "env" : filePath ? "configured" : null,
      expectedSha256: normalizeSha256(this.overrides.expectedSha256) || normalizeSha256(this.env.NOVEL_WORKSHOP_ACP_SHA256) || normalizeSha256(stored.expectedSha256),
      kind,
      flags,
      preferences: { ...cleanPreferences(stored.preferences), ...this.transientPreferences },
    };
  }

  // 读 acp-status.json（每次都读磁盘上的那份）。坏了就抛 AcpAssistError，不当成空的。
  async loadRecord() {
    let record;
    try {
      record = await this.store.load();
    } catch (error) {
      if (error instanceof StoreError) throw new AcpAssistError(500, "acp_store_unreadable", error.message);
      throw error;
    }
    // 额度暂停以磁盘上的为准（每次都读）：写作台重启以后、或者 check-acp 在写作台开着时碰到额度受限，都照样暂停。
    this.quotaPause = record.quotaPause && typeof record.quotaPause.message === "string" ? record.quotaPause : null;
    return record;
  }

  async writeRecord(patch) {
    try {
      return await this.store.update(patch);
    } catch {
      // 坏掉的记录不往上写（StoreError）；状态里会报出来。
      return null;
    }
  }

  async ensureStoresReadable() {
    await this.settings();
    await this.loadRecord();
    await this.journal.read().catch((error) => {
      if (error instanceof StoreError) throw new AcpAssistError(500, "acp_store_unreadable", error.message);
      throw error;
    });
  }

  // 单实例：同一时间只让一个写作台（或 check-acp）用 Google AI。拿到以后一直拿着，关掉时放开。
  lockHint() {
    return `如果确定没有别的写作台或 check-acp 开着，删掉这个文件再试：${this.lock.path}`;
  }

  otherInstanceMessage(holder) {
    const who = holder?.tool || "写作台";
    const since = holder?.startedAt ? `，${holder.startedAt} 起` : "";
    return `另一个${who}正在用 Google AI（进程 ${holder?.pid ?? "未知"}${since}）。同一时间只能有一个在用：先关掉那一个（或等它的检查跑完），再点一次。${this.lockHint()}`;
  }

  async ensureLock() {
    const result = await this.lock.acquire(this.tool);
    if (result.ok) return;
    if (result.lost) {
      throw new AcpAssistError(409, "acp_lock_lost", `这个写作台拿着的锁被另一个程序接手了（比如电脑睡了很久，那边以为这里已经关掉）：先关掉另一个，再关掉这个重新打开。${this.lockHint()}`);
    }
    throw new AcpAssistError(409, "acp_other_instance", this.otherInstanceMessage(result.holder));
  }

  async saveConfig(payload = {}, { fromHttp = false } = {}) {
    if (!payload || typeof payload !== "object") throw new AcpAssistError(400, "invalid_payload", "设置内容无效");
    if (fromHttp && (payload.kind !== undefined || payload.flags !== undefined)) {
      // 种类和官方开关决定启动哪个程序、带什么参数：只能在本机的 acp.json 里改，或给 check-acp 加参数，页面不收。
      throw new AcpAssistError(400, "acp_config_local_only", "种类（kind）和官方开关（flags）只能在本机的 acp.json 里改，或者给 check-acp 加参数；写作台页面不收这两项。");
    }
    if (this.busy || this.taskActive()) throw new AcpAssistError(409, "acp_busy", `${BUSY_LABELS[this.busy?.code] || "正在连接、登录或等回复"}：先等它结束或先断开，再改设置`);
    // 保存的这一会儿不让发送、检查、连接插进来（它们会说“正在保存设置”，等一下再点）。
    this.busy = { code: "saving", since: this.at() };
    try {
      await this.saveConfigLocked(payload);
    } finally {
      this.busy = null;
    }
    return this.status();
  }

  async saveConfigLocked(payload) {
    await this.ensureLock();
    // 连着的时候，拿连接时的那一份比（acp.json 可能在外面被改过，页面存的又正好是改过以后的值）。
    const before = this.connected() && !this.conn.revoked && this.connectedRuntime?.launchConfig
      ? this.connectedRuntime.launchConfig
      : await this.settings().then(launchConfigOf, () => null);
    const file = acpConfigFile(this.env);
    let stored;
    try {
      stored = await readJsonStrict(file);
    } catch (error) {
      if (!(error instanceof StoreError) || payload.clear !== true) {
        throw new AcpAssistError(500, "acp_store_unreadable", error.message);
      }
      // 清除时遇到坏掉的设置文件：改名留着（不删），从空的重来。
      await rename(file, `${file}.broken-${Date.now()}`).catch(() => {});
      stored = {};
    }
    const next = { ...stored };
    if (payload.clear === true) {
      for (const key of ["runtimePath", "expectedSha256", "kind", "flags"]) delete next[key];
    }
    if (payload.runtimePath !== undefined) {
      const value = payload.runtimePath === null ? "" : cleanPathInput(payload.runtimePath);
      if (!value) delete next.runtimePath;
      else if (value.length > 1000 || /[\0\r\n]/.test(value)) throw new AcpAssistError(400, "invalid_runtime_path", "运行时路径无效");
      else next.runtimePath = value;
    }
    if (payload.expectedSha256 !== undefined) {
      const raw = payload.expectedSha256 === null ? "" : String(payload.expectedSha256).trim();
      if (!raw) delete next.expectedSha256;
      else {
        const value = normalizeSha256(raw);
        if (!value) throw new AcpAssistError(400, "invalid_sha256", "校验值应该是 64 位十六进制（SHA-256）");
        next.expectedSha256 = value;
      }
    }
    if (payload.kind !== undefined) {
      if (payload.kind === null || payload.kind === "" || payload.kind === "auto") delete next.kind;
      else if (payload.kind === "agy-cli" || payload.kind === "registry-binary") next.kind = payload.kind;
      else throw new AcpAssistError(400, "invalid_kind", "种类只能是 agy-cli（官方 CLI）或 registry-binary（ACP Registry 发行包）");
    }
    if (payload.flags !== undefined) {
      if (!Array.isArray(payload.flags) || payload.flags.some((flag) => !ALLOWED_FLAGS.includes(flag))) {
        throw new AcpAssistError(400, "invalid_flags", `只能加这几个开关：${ALLOWED_FLAGS.join("、")}`);
      }
      if (payload.flags.length) next.flags = [...new Set(payload.flags)];
      else delete next.flags;
    }
    try {
      await writePrivateJson(file, { ...next, format: undefined });
    } catch {
      throw new AcpAssistError(500, "acp_config_unwritable", "保存本机设置失败（用户配置目录写不进去）");
    }
    const storedChanged = ["runtimePath", "kind", "expectedSha256"].some((key) => next[key] !== stored[key])
      || JSON.stringify(next.flags || []) !== JSON.stringify(stored.flags || []);
    if (storedChanged) this.runtime = null;
    // 真正用来启动和核对的那一份（环境变量优先于这里存的）变了：旧连接作废，“已真实接通”清掉。
    const changes = launchChanges(before, launchConfigOf(await this.settings()));
    if (changes.length) await this.invalidateFor("config_changed", `你改了${changes.join("、")}`);
  }

  // 旧连接作废：不再许发送；预览绑着这一次连接，旧预览跟着作废；“已真实接通”清掉。
  // 还在准备、没发出的那一轮记成没有发出；已经发出的按停止的老规矩了结（留着已收到的部分，不自动重发），了结以后再结束旧连接。
  async invalidateFor(code, reason) {
    const conn = this.conn;
    if (conn && !conn.revoked) {
      const at = this.at();
      conn.revoked = { code, reason, at };
      this.invalidation = { code, reason, at, generation: conn.generation };
      this.setCondition("runtime_invalidated", `旧连接已作废：${reason}。它不能再发送，刚才的预览也作废了；点“检查运行时”核对好程序，再点“连接”。`);
      const task = this.task;
      const sent = task && task.state !== "finished" && task.state !== "preparing";
      if (task && task.state === "preparing") task.cancelRequested = task.cancelRequested || "invalidated";
      if (sent) {
        this.requestCancel(task, "invalidated");
        task.whenFinished.then(() => (this.conn === conn ? this.dropConnection("invalidated") : null)).catch(() => {});
      } else {
        await this.dropConnection("invalidated");
      }
    }
    // 设置变了：上一次“检查运行时”的结果是按旧设置查的，不再显示（免得旧的“来源已核对”挨着新的校验值）。
    if (code === "config_changed") this.runtime = null;
    await this.clearReal(`${reason}，上一次的“已真实接通”不再算数`);
  }

  // 本机设置（实际生效的那一份）和连着的程序连接时的那一份差在哪儿。没连着、已经作废，就不比。
  settingsDrift(settings) {
    if (!this.connected() || this.conn.revoked || !this.connectedRuntime?.launchConfig || !settings) return [];
    return launchChanges(this.connectedRuntime.launchConfig, launchConfigOf(settings));
  }

  async savePreference(category, entry) {
    const file = acpConfigFile(this.env);
    let stored;
    try {
      stored = await readJsonStrict(file);
    } catch (error) {
      throw new AcpAssistError(500, "acp_store_unreadable", error.message);
    }
    const preferences = cleanPreferences(stored.preferences);
    preferences[category] = entry;
    await writePrivateJson(file, { ...stored, preferences }).catch(() => {
      throw new AcpAssistError(500, "acp_config_unwritable", "保存选择失败（用户配置目录写不进去）");
    });
  }

  async clearReal(reason) {
    const record = await this.loadRecord().catch(() => ({}));
    if (!record.real) return;
    await this.writeRecord({ real: null, realCleared: { at: this.at(), reason } });
  }

  // ---- 事件记录里还没了结的轮次
  async openTurnsInfo(other = null) {
    const keyOf = async (path) => {
      const info = await stat(path).catch(() => null);
      return info ? `${info.size}:${info.mtimeMs}` : "-";
    };
    const key = `${await keyOf(this.journal.oldPath)}|${await keyOf(this.journal.path)}`;
    if (!this.journalCache || this.journalCache.key !== key) {
      const { events, badLines } = await this.journal.read();
      this.journalCache = { key, open: openTurns(events), badLines };
    }
    const turns = new Map(this.journalCache.open.map((turn) => [turn.taskId, turn]));
    // 进程里的轮次比磁盘上的新：还在跑的不算；已经结束的按这里的结果算；作者刚确认过的去掉。
    for (const task of this.tasks.values()) {
      if (!task.sentAt) continue;
      if (task.state !== "finished" || !OPEN_OUTCOMES.has(task.outcome)) turns.delete(task.id);
      else if (!turns.has(task.id)) turns.set(task.id, { taskId: task.id, sent: { at: task.sentAt, kind: task.kind }, finished: { outcome: task.outcome } });
    }
    for (const id of this.acknowledged) turns.delete(id);
    const all = [...turns.values()].map((turn) => {
      // 还没结束、而且发它的那个写作台还拿着锁（还活着）：那是另一个写作台正在进行的一轮，不是没人管的。
      const running = !turn.finished && Boolean(other?.token) && turn.sent?.holder === other.token;
      return {
        taskId: turn.taskId,
        kind: turn.sent?.kind || null,
        sentAt: turn.sent?.at || null,
        outcome: turn.finished?.outcome || null,
        model: turn.sent?.model || null,
        // 模拟程序的那一轮：没有经过 Google，不用额度。
        simulated: turn.sent?.simulated === true,
        running,
        reason: running
          ? "另一个写作台正在进行这一轮（还没结束）"
          : turn.finished
            ? turn.finished.outcome === "cancel_unconfirmed"
              ? "停止没有得到官方程序的确认"
              : "这一轮结果未知（官方程序中途退出、断线或超时）"
            : "写作台在这一轮结束前退出了（或被关掉了）",
      };
    }).sort((left, right) => String(left.sentAt).localeCompare(String(right.sentAt)));
    return { open: all.filter((turn) => !turn.running), running: all.filter((turn) => turn.running), badLines: this.journalCache.badLines };
  }

  async acknowledge({ taskId } = {}) {
    await this.ensureLock();
    const { open } = await this.openTurnsInfo(await this.lock.otherHolder().catch(() => null));
    if (!open.some((turn) => turn.taskId === taskId)) throw new AcpAssistError(409, "acp_turn_not_open", "这一轮不在待确认的清单里（可能已经确认过了）");
    try {
      await this.journal.append({ event: "acknowledged", taskId, by: "author", note: "作者自己确认；工坊拿不到 Google 的回执" });
    } catch {
      throw new AcpAssistError(500, "acp_events_unwritable", "写不进本机事件记录（用户配置目录）");
    }
    this.acknowledged.add(taskId);
    return this.status();
  }

  // ---- 状态
  setCondition(code, message) {
    this.condition = { code, label: STATE_LABELS[code], message, at: this.at() };
  }

  clearCondition(codes) {
    if (this.condition && codes.includes(this.condition.code)) this.condition = null;
  }

  taskActive() {
    return Boolean(this.task && this.task.state !== "finished");
  }

  connected() {
    return Boolean(this.conn && this.handshake);
  }

  async status() {
    // 已经结束的那一轮，先等它的结果记进本机记录再报状态：不会出现“这一轮结束了、但已真实接通还没记上”的一刻。
    await Promise.all([...this.tasks.values()].map((task) => task.recorded));
    let storeError = null;
    let record = {};
    try {
      record = await this.loadRecord();
    } catch (error) {
      storeError = error.message;
      record = this.store.memory || {};
    }
    let settings = { runtimePath: null, runtimeSource: null, expectedSha256: null, kind: null, flags: [], preferences: {} };
    try {
      settings = await this.settings();
    } catch (error) {
      storeError = storeError || error.message;
    }
    const other = await this.lock.otherHolder().catch(() => null);
    let journal = { open: [], running: [], badLines: 0 };
    try {
      journal = await this.openTurnsInfo(other);
    } catch (error) {
      storeError = storeError || error.message;
    }
    const runtime = this.runtime;
    const connected = this.connected();
    let step = runtime?.state === "launchable" ? 1 : 0;
    let base = runtime ? runtime.state : "not_checked";
    if (connected) {
      step = 2;
      base = "needs_login";
      if (this.auth.state === "ok") {
        step = 3;
        base = "authenticated";
      }
      if (this.sessionsOpened > 0 && !["needed", "expired"].includes(this.auth.state)) {
        step = 4;
        base = "ready";
      }
    }
    const lastOpen = journal.open.at(-1);
    let condition = this.condition;
    if (!condition && this.quotaPause) condition = { code: "quota_limited", label: STATE_LABELS.quota_limited, message: this.quotaPause.message, at: this.quotaPause.at };
    if (!condition && lastOpen) {
      const code = lastOpen.outcome === "cancel_unconfirmed" ? "cancel_unconfirmed" : "result_unknown";
      const allSimulated = journal.open.every((turn) => turn.simulated);
      const message = allSimulated
        ? `［模拟］${STATE_LABELS[code]}：有 ${journal.open.length} 轮发给模拟程序（工坊自己的测试程序）以后没有明确结果（${lastOpen.reason}）。没有经过 Google，不用额度；点“我知道了”确认就行。`
        : `${STATE_LABELS[code]}：有 ${journal.open.length} 轮发出以后没有明确结果（${lastOpen.reason}），可能已经被 Google 处理、用了额度。工坊不会自动重发；请在官方产品里看看，再点“我知道了”确认。`;
      condition = { code, label: STATE_LABELS[code], message, at: lastOpen.sentAt };
    }
    if (other && !this.lock.held) condition = { code: "other_instance", label: STATE_LABELS.other_instance, message: this.otherInstanceMessage(other), at: other.startedAt };
    if (storeError) condition = { code: "store_unreadable", label: STATE_LABELS.store_unreadable, message: storeError, at: this.at() };
    const code = condition?.code || base;
    const login = record.login;
    // 按 r5.50 的规矩记下的才算“已真实接通”；r5.49 留下的只当历史（旧规则，来源未核对）。
    const real = genuineReal(record.real) ? record.real : null;
    const legacyReal = record.real && !real ? record.real : null;
    // acp.json 在外面被改过（或环境变量变了）：连着的还是旧设置下核对的程序。不在读状态时断开它，只报不能发、不算现在接通。
    const drift = storeError ? [] : this.settingsDrift(settings);
    // “已真实接通”只当作这一次连接的状态：要是这一次连接（连接编号对得上）里拿到的、连接没作废，而且之后没有再登录过。
    // 重新连接、重启写作台以后，连接编号都是新的，旧的标记只当历史。
    const realCurrent = Boolean(real && connected && this.handshake && !this.conn.revoked && !drift.length && real.connectionId && real.connectionId === this.handshake.connectionId
      && String(real.at) > String(this.handshake.at)
      && !(login?.outcome === "ok" && String(login.at) > String(real.at)));
    const sendBlock = this.sendBlock(drift);
    const handshake = connected ? this.handshake : null;
    const diagnostics = this.conn
      ? { stderr: this.conn.stderrTail(), protocol: { ...this.conn.stats } }
      : this.lastDiagnostics;
    return {
      state: code,
      label: STATE_LABELS[code],
      baseState: base,
      baseLabel: STATE_LABELS[base],
      message: condition?.message || (runtime && !connected ? runtime.message : null),
      ladder: { steps: LADDER, step },
      condition,
      busy: this.busy ? { ...this.busy, label: BUSY_LABELS[this.busy.code] || this.busy.code } : null,
      connected,
      // 现在能不能发；不能发的原因。页面按它灰掉发送按钮（服务端发出前另外再核对）。
      canSend: !sendBlock,
      sendBlock,
      invalidation: this.invalidation,
      simulated: Boolean(connected && this.handshake?.simulated),
      verification: this.verificationStates({ record, runtime, connected, real, realCurrent, legacyReal, drift, settings: storeError ? null : settings }),
      generation: this.generation,
      runtime: publicRuntime(runtime),
      settings: {
        runtimePath: settings.runtimePath,
        runtimeSource: settings.runtimeSource,
        expectedSha256: settings.expectedSha256,
        kind: settings.kind,
        flags: settings.flags,
        allowedFlags: ALLOWED_FLAGS,
      },
      handshake,
      lastHandshake: record.handshake || null,
      auth: { ...this.auth, label: AUTH_LABELS[this.auth.state] || this.auth.state },
      session: this.session && connected ? { options: this.session.options, used: this.session.used } : null,
      preferences: settings.preferences,
      task: publicTask(this.task),
      real,
      legacyReal,
      realCurrent,
      realCleared: record.realCleared || null,
      lastSimulated: record.lastSimulated || null,
      openTurns: journal.open,
      runningElsewhere: journal.running,
      journal: { badLines: journal.badLines, recordWriteError: this.store.writeError },
      // 锁里的随机编号只在本机比对用，不给页面。
      instance: { held: this.lock.held, other: other ? { pid: other.pid, tool: other.tool, startedAt: other.startedAt } : null },
      storeError,
      diagnostics: { ...diagnostics, ...this.counters },
      selftestSample: SELFTEST_SAMPLE,
      limits: { maxTextChars: MAX_TEXT_CHARS, maxInstructionChars: MAX_INSTRUCTION_CHARS },
      timeouts: { loginMs: this.timeouts.loginMs, cancelWaitMs: this.timeouts.cancelWaitMs },
      quotaPause: this.quotaPause,
      autoReview: AUTO_REVIEW,
      apiFallback: false,
    };
  }

  // 四件事分开：程序来源、ACP 握手、官方程序自己的登录、真实的模型回复。只写工坊真拿到的，不推测；
  // 账号是谁、额度还剩多少，工坊拿不到，就照直说拿不到。
  verificationStates({ record, runtime, connected, real, realCurrent, legacyReal = null, drift = [], settings = null }) {
    // 连着、没作废的连接看连接时核对的那一份；作废了（哪怕还在等已经发出的那一轮停下）就看最新一次检查的结果。
    const live = connected && !this.conn?.revoked;
    const program = live ? this.connectedRuntime : runtime;
    // 没连着时，上一次检查是按旧设置查的（设置后来变了），不再拿它说来源。
    const staleCheck = !live && program?.launchConfig && settings && launchChanges(program.launchConfig, launchConfigOf(settings)).length > 0;
    // ACP Registry 登记的是发行包 zip 的校验值：只对 Registry 发行包有意义，而且和程序文件本身的分开写。
    const registry = program?.kind === "registry-binary" ? program.registry || null : null;
    const checksums = {
      binary: program?.sha256 || null,
      binaryOf: program?.hashOf === "windows-shim" ? "Windows 的 .cmd 启动脚本本身" : program?.hashOf === "link-target" ? "链接指向的那个程序文件" : "程序文件本身（解压以后的）",
      expected: program?.checksum?.expected || null,
      registryZip: registry?.archiveSha256 ? { version: registry.version, platformKey: registry.platformKey, sha256: registry.archiveSha256, note: "这是 ACP Registry 登记的发行包 zip（压缩包）的校验值，不是解压后程序的；解压前用 check-acp --zip 核对" } : null,
    };
    let source;
    if (!program || staleCheck) source = { state: "not_checked", label: staleCheck ? "设置在上次检查以后变了：重新点“检查运行时”" : "还没检查程序" };
    else if (live && drift.length) source = { state: "stale", label: `本机设置在连接以后变了（${drift.join("、")}）：连着的还是按旧设置核对的程序，先点“检查运行时”`, detail: null };
    else if (program.state === "checksum_mismatch") source = { state: "mismatch", label: "校验不符：程序和你核对过的 SHA-256 对不上", detail: program.message };
    else if (program.state !== "launchable") source = { state: "missing", label: program.label || "找不到程序", detail: program.message };
    else if (program.hashOf === "windows-shim") source = { state: "unverified", label: "来源未核对：校验值是 .cmd/.bat 启动脚本的，不是它启动的程序的；最多只算协议结果。要核对来源，路径填程序本身（比如 agy.exe）" };
    else if (sourceVerified(program)) source = { state: "verified", label: "来源已核对：SHA-256 和你填的一致" };
    else source = { state: "unverified", label: "来源未核对：你没有填核对过的 SHA-256（工坊只记下了它现在的），最多只算协议结果" };
    if (!live && connected && this.conn?.revoked && source.state === "verified") source = { ...source, state: "unverified", label: "旧连接已作废：重新检查、连接以后再看来源" };
    source = { ...source, path: program?.path || null, checksums };

    const lastHandshake = record?.handshake || null;
    let handshake;
    if (connected) {
      const info = this.handshake.agentInfo;
      handshake = {
        state: "ok",
        label: `握手成功（ACP 协议版本 ${this.handshake.protocolVersion}）`,
        agentInfo: info,
        agentNote: info ? `它自称“${info.title || info.name || "未知"}”${info.version ? ` ${info.version}` : ""}（这是它自己说的，工坊核实不了）` : "它没有给出 agentInfo",
        claimsOfficial: Boolean(this.handshake.official),
        simulated: Boolean(this.handshake.simulated),
      };
    } else if (lastHandshake && lastHandshake.ok === false) handshake = { state: "failed", label: "上一次握手没有成功", detail: lastHandshake.message || null };
    else handshake = { state: "none", label: "没有连接" };

    const auth = this.auth.state;
    const login = {
      state: connected ? auth : "none",
      label: connected ? AUTH_LABELS[auth] || auth : "没有连接",
      methodId: connected ? this.auth.methodId || null : null,
      // 登录由官方程序自己做（它打开浏览器）；工坊拿不到账号是谁。
      account: null,
      accountNote: "工坊拿不到是哪个 Google 账号：官方程序没有告诉工坊",
    };

    const last = record?.lastSimulated || null;
    const lastHere = Boolean(last && connected && last.connectionId && last.connectionId === this.handshake.connectionId);
    let reply;
    if (realCurrent) reply = { state: "real", label: "已真实接通：这一次连接里拿回了完整回复，程序来源核对过" };
    else if (lastHere && last.countsAs === "simulated") reply = { state: "simulated", label: "［模拟］模拟程序拿回了完整回复，不算真实接通", why: last.why || [] };
    else if (lastHere) reply = { state: "protocol_only", label: "只算协议结果：拿回了完整回复，但不算真实接通", why: last.why || [] };
    else if (real) reply = { state: "earlier", label: `以前真实接通过（${real.at}）；这一次连接还没有${drift.length ? "（本机设置在连接以后又变了）" : ""}` };
    else if (legacyReal) reply = { state: "earlier_legacy", label: `以前接通过（旧规则，来源未核对，${legacyReal.at}）：那是旧版本按“自称 Antigravity”记下的，不算真实接通`, why: ["旧版本记下的，程序来源没有核对"] };
    else reply = { state: "none", label: "还没有拿回过完整回复" };
    const mark = realCurrent ? real : lastHere ? last : null;
    reply = {
      ...reply,
      // 模型：只有官方程序列出、回报的；额度：只有官方程序报过的受限，工坊读不到余额。
      requestedModel: mark?.requestedModel || null,
      reportedModel: mark?.reportedModel || null,
      quota: this.quotaPause ? { state: "limited", message: this.quotaPause.message } : { state: "unknown", label: "工坊读不到余额" },
    };
    return { source, handshake, login, reply };
  }

  async exclusive(code, work, { allowDuringTask = false } = {}) {
    if (this.busy) throw new AcpAssistError(409, "acp_busy", `${BUSY_LABELS[this.busy.code] || "正在处理上一步"}；等它结束再点`);
    if (!allowDuringTask && this.taskActive()) throw new AcpAssistError(409, "acp_task_running", "正在等官方程序回复：先点“停止”或等它结束");
    this.busy = { code, since: this.at() };
    try {
      await this.ensureLock();
      await this.ensureStoresReadable();
      return await work();
    } finally {
      this.busy = null;
    }
  }

  requireConnection() {
    if (!this.connected()) {
      if (this.invalidation) throw revokedError(this.invalidation);
      throw new AcpAssistError(409, "acp_not_connected", "还没有连接官方程序：先点“连接”。");
    }
    if (this.conn.revoked) throw revokedError(this.conn.revoked);
    return this.conn;
  }

  // 现在能不能发：连着、旧连接没作废。页面按这个灰掉发送按钮；服务端发出前另外再核对。
  sendBlock(drift = []) {
    if (this.conn?.revoked) return `旧连接已作废：${this.conn.revoked.reason}`;
    if (!this.connected()) return this.invalidation ? `旧连接已作废：${this.invalidation.reason}` : "还没有连接官方程序";
    if (drift.length) return `本机设置在连接以后变了（${drift.join("、")}）：点“检查运行时”核对，再重新连接`;
    return null;
  }

  describeError(error) {
    if (error instanceof AcpTimeoutError) return `等了 ${duration(error.timeoutMs)}没有回应`;
    if (error instanceof AcpClosedError) return `连接断了（${error.reason || "原因不明"}）`;
    if (error instanceof AcpRpcError) return `官方程序说：${this.scrub(error.rpcMessage) || `错误 ${error.code}`}`;
    return this.scrub(error?.message || String(error));
  }

  // ---- 运行时
  async probe() {
    await this.ensureLock();
    await this.ensureStoresReadable();
    const settings = await this.settings();
    const runtime = await inspectRuntime({
      configuredPath: settings.runtimePath,
      kind: settings.kind,
      expectedSha256: settings.expectedSha256,
      flags: settings.flags,
      env: this.env,
      platform: this.platform,
      arch: this.arch,
      probe: true,
      versionTimeoutMs: this.timeouts.versionMs,
      source: settings.runtimeSource,
      now: this.now,
    });
    runtime.launchConfig = launchConfigOf(settings);
    this.runtime = runtime;
    const record = await this.loadRecord();
    const patch = { runtime: runtimeSummary(runtime) };
    const real = record.real;
    const versionChanged = Boolean(real?.runtimeVersion && runtime.version && real.runtimeVersion !== runtime.version);
    // 按 r5.50 规矩记下的：开关、核对的校验值也要和记下时一样，而且这一次检查来源也核对过，才留着。
    const settingsChanged = genuineReal(real) && (!real.launchConfig || launchChanges(real.launchConfig, runtime.launchConfig).length > 0 || !sourceVerified(runtime));
    if (real && (runtime.state !== "launchable" || real.runtimePath !== runtime.path || real.runtimeKind !== runtime.kind || real.runtimeSha256 !== runtime.sha256 || versionChanged || settingsChanged)) {
      patch.real = null;
      patch.realCleared = { at: this.at(), reason: settingsChanged && runtime.state === "launchable" && real.runtimePath === runtime.path && real.runtimeSha256 === runtime.sha256 && !versionChanged
        ? "程序的设置变了（开关、核对的校验值），或者这一次检查来源没有核对，上一次的“已真实接通”不再算数"
        : "官方程序换了（路径、种类、校验值或版本变了），上一次的“已真实接通”不再算数" };
    }
    await this.writeRecord(patch);
    // 连着的时候重新检查：校验不符、找不到、或者已经不是连着的那一个程序，旧连接作废。
    const connected = this.conn && this.connectedRuntime;
    if (connected && !this.conn.revoked) {
      let problem = null;
      if (runtime.state !== "launchable") problem = `重新检查的结果是“${runtime.label}”：${runtime.message}`;
      else if (!sameProgram(runtime, this.connectedRuntime)) problem = "重新检查到的程序和连着的不是同一个（路径、种类、启动参数或 SHA-256 变了）";
      else {
        const changes = launchChanges(this.connectedRuntime.launchConfig, runtime.launchConfig);
        if (changes.length) problem = `设置和连接时不一样了（${changes.join("、")}）`;
      }
      if (problem) await this.invalidateFor("check_failed", problem);
    } else if (!this.conn && runtime.state === "launchable") {
      // 作者已经核对好了程序：“旧连接已作废”的提示换成“可启动”，等他点连接。
      this.clearCondition(["runtime_invalidated"]);
    }
    return runtime;
  }

  async check() {
    return this.exclusive("checking", async () => {
      await this.probe();
      return this.status();
    }, { allowDuringTask: true });
  }

  async connect() {
    return this.exclusive("connecting", async () => {
      if (this.conn?.revoked) throw new AcpAssistError(409, "acp_already_connected", "旧连接已作废，正在等官方程序确认停下已经发出的那一轮：等一下再连接，或者先点“断开”。");
      if (this.conn) throw new AcpAssistError(409, "acp_already_connected", "已经连着官方程序了；要重连先点“断开”。");
      const runtime = await this.probe();
      if (runtime.state !== "launchable") throw new AcpAssistError(400, `acp_${runtime.state}`, runtime.message);
      this.condition = null;
      // 上次写作台被强行结束时留下的工作目录（那个进程已经不在了）顺手删掉。
      await sweepStaleWorkDirectories().catch(() => 0);
      const workDir = await makeWorkDirectory();
      this.generation += 1;
      const generation = this.generation;
      let proc;
      try {
        proc = await startRuntime(runtime, { cwd: workDir, env: this.env, platform: this.platform });
      } catch (error) {
        await removeWorkDirectory(workDir);
        const message = `连接失败：${this.scrub(error?.message || error)}`;
        this.setCondition("connect_failed", message);
        throw new AcpAssistError(502, "acp_spawn_failed", message);
      }
      const conn = new AcpConnection({
        generation,
        stdin: proc.child.stdin,
        stdout: proc.child.stdout,
        stderr: proc.child.stderr,
        scrub: this.scrub,
        onNotification: (method, params, source) => this.onNotification(method, params, source),
        onRequest: (method, params, source) => this.onAgentRequest(method, params, source),
        onClose: (reason, source) => this.onConnectionClosed(reason, source),
        onProtocolError: (problem, source) => this.onProtocolProblem(problem, source),
      });
      proc.exited.then(({ code, signal }) => conn.close(`官方程序退出了（${signal || `退出码 ${code}`}）`));
      Object.assign(this, { conn, proc, workDir, connectedRuntime: runtime, handshake: null, session: null, sessionsOpened: 0, lastOptions: [] });
      this.auth = { state: "unknown" };
      this.sessions = new Map();
      let result;
      try {
        result = await conn.request("initialize", { protocolVersion: PROTOCOL_VERSION, clientCapabilities: CLIENT_CAPABILITIES, clientInfo: CLIENT_INFO }, { timeoutMs: this.timeouts.initializeMs });
      } catch (error) {
        const message = `连接失败：握手没有成功，${this.describeError(error)}`;
        await this.dropConnection("handshake_failed");
        this.setCondition("connect_failed", message);
        await this.writeRecord({ handshake: { ok: false, at: this.at(), message } });
        throw new AcpAssistError(502, "acp_handshake_failed", message);
      }
      const handshake = parseHandshake(result);
      if (handshake.problem) {
        const message = `连接失败：${handshake.problem}`;
        await this.dropConnection("handshake_invalid");
        this.setCondition("connect_failed", message);
        await this.writeRecord({ handshake: { ok: false, at: this.at(), message } });
        throw new AcpAssistError(502, "acp_handshake_invalid", message);
      }
      // 每次连接一个新编号：预览、“已真实接通”都绑着它，重新连接（哪怕是同一个程序）、重启写作台以后都不沿用。
      this.handshake = { ...handshake, at: this.at(), generation, connectionId: randomUUID() };
      this.invalidation = null;
      const record = await this.loadRecord().catch(() => ({}));
      const before = record.real?.agentInfo?.version;
      const now = handshake.agentInfo?.version;
      if (before && now && before !== now) await this.clearReal(`官方程序报的版本变了（${before} → ${now}），上一次的“已真实接通”不再算数`);
      await this.writeRecord({ handshake: { ok: true, ...this.handshake } });
      return this.status();
    });
  }

  // ---- 登录：只用官方程序在握手里列出的方式；终端方式和环境变量方式不经工坊
  terminalLoginMessage(method) {
    const runtime = this.connectedRuntime;
    const envNote = method.envNames?.length ? `；它还声明了这几个环境变量：${method.envNames.join("、")}（值看官方说明，工坊不替你设）` : "";
    if (method.args?.length && runtime) {
      return `这种方式要在终端里由官方程序自己登录。官方程序声明的命令是：${commandLine(runtime, method.args, this.platform)}${envNote}。先点“断开”，在终端里运行它，按提示登录完，再回来点“连接”。`;
    }
    return `这种方式要在终端里由官方程序自己登录，但官方程序没有说明具体该运行什么，工坊不知道命令${envNote}：请照官方的说明操作（Antigravity CLI 的文档提到过 agy acp --login，这里没有核实过）。登录完先点“断开”，再点“连接”。`;
  }

  async login({ methodId } = {}) {
    return this.exclusive("logging_in", async () => {
      const conn = this.requireConnection();
      const methods = this.handshake.authMethods;
      const method = methods.find((entry) => entry.id === methodId);
      if (!method) {
        throw new AcpAssistError(400, "acp_method_not_listed", methods.length
          ? `官方程序没有列出“${String(methodId ?? "")}”这种登录方式；它列出的是：${methods.map((entry) => entry.id).join("、")}`
          : "官方程序没有列出任何登录方式");
      }
      if (method.type === "terminal") throw new AcpAssistError(400, "acp_method_terminal", this.terminalLoginMessage(method));
      if (method.type === "env_var") {
        throw new AcpAssistError(400, "acp_method_env", "这种方式要把密钥放进环境变量交给官方程序；工坊不替官方程序传任何密钥，这里不支持。");
      }
      // 登录以前开的会话不再用：登录以后可能换了账号，模型清单和会话都要在新的登录下重开。
      if (this.session) this.session.used = true;
      this.session = null;
      this.sessionsOpened = 0;
      this.lastOptions = [];
      this.loginAbort = false;
      this.auth = { state: "logging_in", methodId, startedAt: this.at() };
      try {
        await conn.request("authenticate", { methodId }, { timeoutMs: this.timeouts.loginMs });
      } catch (error) {
        return this.loginFailed(error, methodId);
      }
      if (conn !== this.conn) return this.loginFailed(new AcpClosedError("authenticate", "连接已经断开"), methodId);
      this.auth = { state: "ok", methodId, at: this.at() };
      this.clearCondition(["auth_cancelled", "auth_failed"]);
      await this.writeRecord({ login: { at: this.auth.at, methodId, outcome: "ok" } });
      return this.status();
    });
  }

  async loginFailed(error, methodId) {
    let outcome = "failed";
    let code = "auth_failed";
    let status = 401;
    let message;
    if (this.loginAbort) {
      outcome = "cancelled";
      code = "auth_cancelled";
      status = 409;
      message = "认证取消：登录完成前你断开了连接。";
    } else if (error instanceof AcpTimeoutError) {
      outcome = "timeout";
      status = 504;
      message = `认证失败：登录等了 ${duration(this.timeouts.loginMs)}没有完成，工坊不再等，已经结束它启动的这个官方程序。要是你其实已经在浏览器里登录好了，重新连接后官方程序可能已经记住了。`;
      await this.dropConnection("login_timeout");
    } else if (error instanceof AcpClosedError) {
      status = 502;
      message = `认证失败：官方程序在登录途中退出了（${error.reason || "原因不明"}）。`;
    } else if (error instanceof AcpRpcError && /cancel/i.test(error.rpcMessage)) {
      outcome = "cancelled";
      code = "auth_cancelled";
      status = 409;
      message = `认证取消：${this.describeError(error)}`;
    } else {
      message = `认证失败：${this.describeError(error)}`;
    }
    this.loginAbort = false;
    this.auth = { state: outcome === "cancelled" ? "cancelled" : "failed", methodId, at: this.at(), message };
    this.setCondition(code, message);
    await this.writeRecord({ login: { at: this.auth.at, methodId, outcome } });
    throw new AcpAssistError(status, `acp_${code}`, message);
  }

  // ---- 会话与配置项
  sessionError(error) {
    if (error instanceof AcpAssistError) return error;
    if (isQuota(error)) {
      const message = this.quotaMessage(error);
      this.pauseForQuota(message);
      return new AcpAssistError(429, "acp_quota", message);
    }
    if (isAuthRequired(error)) {
      const expired = this.auth.state === "ok" || this.auth.state === "implicit";
      this.auth = { state: expired ? "expired" : "needed", methodId: this.auth.methodId || null, at: this.at() };
      return expired
        ? new AcpAssistError(401, "acp_auth_expired", "官方程序说登录已经失效（Authentication required）：点“用 Google 登录”重新登录。")
        : new AcpAssistError(401, "acp_auth_required", "官方程序说要先登录（Authentication required）：点“用 Google 登录（官方程序打开）”。");
    }
    if (error instanceof AcpTimeoutError) return new AcpAssistError(504, "acp_timeout", `官方程序${this.describeError(error)}`);
    if (error instanceof AcpClosedError) return new AcpAssistError(502, "acp_disconnected", this.describeError(error));
    if (error instanceof AcpRpcError) return new AcpAssistError(502, "acp_request_failed", this.describeError(error));
    return new AcpAssistError(500, "acp_internal", this.scrub(error?.message || String(error)));
  }

  // 额度受限：停下来，不重试、不改用 API；作者在页面上确认以后才放行下一次发送（重连、重启写作台都不自动放行）。
  pauseForQuota(message) {
    this.quotaPause = { at: this.at(), message };
    this.setCondition("quota_limited", message);
    this.writeRecord({ quotaPause: this.quotaPause });
  }

  quotaMessage(error) {
    return `额度受限：${this.describeError(error)}。工坊已暂停发送：不会自动重试，也不会改用 Gemini API 或别的付费接口。请到 Google 官方产品里查看 Antigravity 的额度。注意：工坊看不到、也拦不住 Google 账号里的 AI 额度超额消费；不想超额花钱，请把 Google 账号里 Antigravity 套餐页的“AI Credit Overages”设成 Never。`;
  }

  rememberOptions(session, options) {
    if (options.length) {
      session.options = options;
      this.lastOptions = options;
    }
  }

  // fresh 为真时总是新开（“选择模型和思考强度”要拿官方程序现在给的清单）；否则先用还没发过请求的那个会话。
  async openSession({ fresh = false } = {}) {
    const conn = this.requireConnection();
    if (!fresh && this.session && !this.session.used && this.session.generation === conn.generation) return this.session;
    const cwd = await mkdtemp(join(this.workDir, "session-"));
    let result;
    try {
      result = await conn.request("session/new", { cwd, mcpServers: [] }, { timeoutMs: this.timeouts.sessionMs });
    } catch (error) {
      throw this.sessionError(error);
    }
    if (conn !== this.conn) throw new AcpAssistError(409, "acp_disconnected", "连接已经断开");
    const id = typeof result?.sessionId === "string" && result.sessionId && result.sessionId.length <= 200 ? result.sessionId : null;
    if (!id) throw new AcpAssistError(502, "acp_session_invalid", "官方程序没有给出会话编号");
    const session = { id, generation: conn.generation, options: [], used: false, taskId: null, cwd, createdAt: this.at() };
    this.rememberOptions(session, parseConfigOptions(result.configOptions));
    this.session = session;
    this.sessions.set(id, session);
    this.sessionsOpened += 1;
    if (["unknown", "needed", "cancelled", "failed"].includes(this.auth.state)) {
      this.auth = { ...this.auth, state: "implicit", at: this.at() };
      this.clearCondition(["auth_cancelled", "auth_failed"]);
    }
    return session;
  }

  preferenceProblems(options, preferences) {
    const problems = [];
    for (const [category, label] of Object.entries(SETTABLE)) {
      const pref = preferences[category];
      if (!pref) continue;
      const option = options.find((entry) => entry.id === pref.configId) || options.find((entry) => entry.category === category);
      if (!option) problems.push(`你选过的${label}“${pref.name}”这次官方程序没有给出${label}这个设置；没有替你换别的`);
      else if (!option.values.some((value) => value.value === pref.value)) problems.push(`你选的${label}“${pref.name}”不在官方程序这次给出的清单里；没有替你换成别的，先重新选择`);
    }
    return problems;
  }

  async models() {
    return this.exclusive("opening_session", async () => {
      this.requireConnection();
      const session = await this.openSession({ fresh: true });
      const problems = this.preferenceProblems(session.options, (await this.settings()).preferences);
      if (problems.length) this.setCondition("config_invalid", `配置失效：${problems.join("；")}。`);
      else this.clearCondition(["config_invalid"]);
      return this.status();
    });
  }

  async setOptionOn(session, option, value) {
    const conn = this.requireConnection();
    let result;
    try {
      result = await conn.request("session/set_config_option", { sessionId: session.id, configId: option.id, value }, { timeoutMs: this.timeouts.optionMs });
    } catch (error) {
      const failure = this.sessionError(error);
      if (failure.code === "acp_request_failed" || failure.code === "acp_timeout") {
        const message = `配置失效：官方程序没有接受把${SETTABLE[option.category] || option.name}换成“${value}”（${failure.message}）`;
        this.setCondition("config_invalid", message);
        throw new AcpAssistError(502, "acp_config_invalid", message);
      }
      throw failure;
    }
    const options = parseConfigOptions(result?.configOptions);
    if (options.length) this.rememberOptions(session, options);
    else {
      const local = session.options.find((entry) => entry.id === option.id);
      if (local) local.currentValue = value;
    }
    const updated = session.options.find((entry) => entry.id === option.id);
    if (updated?.currentValue !== value) {
      const message = `配置失效：官方程序没有切换到“${value}”（它报的当前值是 ${updated?.currentValue ?? "未知"}）`;
      this.setCondition("config_invalid", message);
      throw new AcpAssistError(502, "acp_config_invalid", message);
    }
  }

  async setOption({ configId, value, persist = true } = {}) {
    return this.exclusive("setting_option", async () => {
      this.requireConnection();
      const session = await this.openSession();
      const option = session.options.find((entry) => entry.id === configId);
      if (!option) throw new AcpAssistError(400, "acp_option_unknown", "官方程序这次没有给出这个设置；点“选择模型和思考强度”刷新一下");
      if (!SETTABLE[option.category]) throw new AcpAssistError(400, "acp_option_readonly", "工坊只改模型和思考强度，其他设置只显示");
      const entry = option.values.find((candidate) => candidate.value === value);
      if (!entry) throw new AcpAssistError(400, "acp_value_unknown", "这个值不在官方程序给出的清单里");
      await this.setOptionOn(session, option, value);
      const choice = { configId: option.id, value, name: entry.name };
      if (persist) {
        delete this.transientPreferences[option.category];
        await this.savePreference(option.category, choice);
      } else {
        this.transientPreferences[option.category] = choice;
      }
      const problems = this.preferenceProblems(session.options, (await this.settings()).preferences);
      if (!problems.length) this.clearCondition(["config_invalid"]);
      return this.status();
    });
  }

  async applyPreferences(session, task) {
    const { preferences } = await this.settings();
    const problems = this.preferenceProblems(session.options, preferences);
    if (problems.length) {
      const message = `配置失效：${problems.join("；")}。这一轮没有发出。`;
      this.setCondition("config_invalid", message);
      throw new AcpAssistError(409, "acp_config_invalid", message);
    }
    for (const category of Object.keys(SETTABLE)) {
      const pref = preferences[category];
      if (!pref) continue;
      const option = session.options.find((entry) => entry.id === pref.configId) || session.options.find((entry) => entry.category === category);
      if (option.currentValue === pref.value) continue;
      this.checkAbort(task);
      await this.setOptionOn(session, option, pref.value);
    }
    const requested = {};
    for (const category of Object.keys(SETTABLE)) {
      const option = session.options.find((entry) => entry.category === category);
      requested[category] = option ? settingFrom(session.options, category, preferences[category]) : null;
    }
    return requested;
  }

  // 官方程序最后一次回报的会话设置（session/new、set_config_option 的回应或 config_option_update）。
  // 这是会话设置，不是逐条回复出自哪个模型的证明；没有就是未知。
  reportedSetting(sessionId, category) {
    const session = this.sessions.get(sessionId);
    const setting = session ? settingFrom(session.options, category, null) : null;
    return setting ? { value: setting.value, name: setting.name, source: "官方程序回报的会话设置" } : null;
  }

  // 这一次要发给谁：运行时（路径、种类、校验值、版本、agentInfo）、模型、思考强度。并进预览的 digest。
  runtimeBinding() {
    // 作废了的旧连接不算收件方：在它上面拿的预览发不出去。
    const runtime = this.connected() && !this.conn.revoked ? this.connectedRuntime : null;
    if (!runtime) return null;
    return {
      path: runtime.path,
      kind: runtime.kind,
      sha256: runtime.sha256 || null,
      version: runtime.version || null,
      agent: this.handshake?.agentInfo ? `${this.handshake.agentInfo.title || this.handshake.agentInfo.name || "未知"} ${this.handshake.agentInfo.version || ""}`.trim() : null,
      // 绑着这一次连接：重新连接（哪怕是同一个程序）以后，旧预览都作废。
      connection: this.handshake?.connectionId || null,
      source: sourceVerified(runtime) ? "verified" : "unverified",
      simulated: Boolean(this.handshake?.simulated),
    };
  }

  async sendBinding() {
    const settings = await this.settings();
    const { preferences } = settings;
    const options = this.session?.options?.length ? this.session.options : this.lastOptions;
    return {
      // 本机设置和连接时不一样了：没有收件方（预览发不出去；发送时会作废旧连接）。
      runtime: this.settingsDrift(settings).length ? null : this.runtimeBinding(),
      model: settingFrom(options, "model", preferences.model),
      thinking: settingFrom(options, "thought_level", preferences.thought_level),
    };
  }

  // ---- 发送一轮
  async preview(payload = {}) {
    const binding = await this.sendBinding();
    const prepared = preparePrompt({ kind: payload.kind === "selftest" ? "selftest" : "selection", text: payload.text, instruction: payload.instruction, source: payload.source, binding });
    return { blocks: prepared.blocks, snapshot: prepared.snapshot };
  }

  checkAbort(task) {
    if (task?.cancelRequested) throw new AcpAssistError(409, "acp_cancelled_before_send", "你在发出前停止了：这一轮没有发出。");
  }

  newTask(kind, snapshot) {
    const task = {
      id: newTaskId(),
      kind,
      state: "preparing",
      outcome: null,
      stopReason: null,
      message: null,
      startedAt: this.at(),
      sentAt: null,
      finishedAt: null,
      snapshot,
      sessionId: null,
      generation: this.generation,
      // 发给模拟程序的每一轮都标着（不只是拿回完整回复的那几轮）。
      simulated: Boolean(this.handshake?.simulated),
      requested: null,
      reportedModel: null,
      modelMismatch: null,
      chunks: [],
      chars: 0,
      chunkCount: 0,
      nonTextChunks: 0,
      thoughtChunks: 0,
      toolCalls: 0,
      toolCallUpdates: 0,
      plans: 0,
      otherUpdates: 0,
      permissionRequests: 0,
      permissionRejected: 0,
      permissionCancelled: 0,
      afterCancelChunks: 0,
      lateUpdates: 0,
      overflow: false,
      replyGap: false,
      cancelRequested: null,
      timedOut: null,
      candidate: null,
      partial: null,
      timers: {},
      recorded: Promise.resolve(),
    };
    task.whenFinished = new Promise((accept) => {
      task.markFinished = accept;
    });
    snapshot.taskId = task.id;
    this.task = task;
    this.tasks.set(task.id, task);
    while (this.tasks.size > KEEP_TASKS) this.tasks.delete(this.tasks.keys().next().value);
    return task;
  }

  async startPrompt(payload = {}) {
    const kind = payload.kind === "selftest" ? "selftest" : "selection";
    const previewed = payload.expectedDigest !== undefined;
    // 旧连接作废了：直接说原因（不说成“预览变了”）。
    if (this.conn?.revoked || (!this.connected() && this.invalidation)) throw revokedError(this.conn?.revoked || this.invalidation);
    const binding = await this.sendBinding();
    const prepared = preparePrompt({ kind, text: payload.text, instruction: payload.instruction, source: payload.source, binding });
    if (previewed && payload.expectedDigest !== prepared.snapshot.digest) {
      throw new AcpAssistError(409, "acp_preview_changed", "要发的内容、官方程序、模型或思考强度和刚才预览的不一样了：请重新预览再发。");
    }
    await this.loadRecord().catch(() => {});
    const pausedAtSend = this.quotaPause;
    if (this.quotaPause && payload.acknowledgeQuota !== true) {
      throw new AcpAssistError(429, "acp_quota_paused", "上一次官方程序说额度受限，工坊已暂停发送：先到官方产品里看看额度。要再试一次，在页面上确认后再发；工坊不会自动重试，也不会改用 API。");
    }
    const started = await this.exclusive("sending", async () => {
      const conn = this.requireConnection();
      const task = this.newTask(kind, prepared.snapshot);
      let session;
      try {
        session = await this.openSession();
        this.checkAbort(task);
        task.requested = await this.applyPreferences(session, task);
        this.checkAbort(task);
        if (conn !== this.conn) throw new AcpAssistError(409, "acp_disconnected", "连接已经断开：这一轮没有发出。");
        if (previewed) {
          // 预览时显示的模型和思考强度，必须就是这一轮实际设置的那一个。
          for (const [key, category, label] of [["model", "model", "模型"], ["thinking", "thought_level", "思考强度"]]) {
            const want = binding[key]?.value;
            const got = task.requested?.[category]?.value;
            if (want !== undefined && want !== null && got !== want) {
              throw new AcpAssistError(409, "acp_preview_changed", `官方程序这次的${label}是“${got ?? "未知"}”，和预览时的“${want}”不一样：没有发出，请重新预览。`);
            }
          }
        }
        // 发出以前再核对一次本机设置：还是连接时的那一份（acp.json 可能在别处被改过）。
        const changes = launchChanges(this.connectedRuntime?.launchConfig, launchConfigOf(await this.settings()));
        if (changes.length) await this.invalidateFor("config_changed", `本机设置在连接以后变了（${changes.join("、")}）`);
        if (conn.revoked) throw revokedError(conn.revoked);
        if (conn !== this.conn) throw new AcpAssistError(409, "acp_disconnected", "连接已经断开：这一轮没有发出。");
      } catch (error) {
        // 作废、停止、断开优先：这一轮没有发出，说清是因为什么（不说成“连接断了”）。
        const failure = conn.revoked
          ? revokedError(conn.revoked)
          : task.cancelRequested
            ? new AcpAssistError(409, "acp_cancelled_before_send", task.cancelRequested === "disconnect" ? "你在发出前断开了连接：这一轮没有发出。" : "你在发出前停止了：这一轮没有发出。")
            : this.sessionError(error);
        this.finishTask(task, { outcome: failure.code === "acp_quota" ? "quota" : failure.code.startsWith("acp_auth") ? "auth_required" : "not_sent", message: `没有发出：${failure.message}` });
        throw failure;
      }
      // 真正发出之前，先把“已发出、未结束”写到磁盘：写作台中途被关掉，下次打开也能看到这一轮结果未知。
      const runtime = this.connectedRuntime;
      try {
        await this.journal.append({
          event: "sent",
          taskId: task.id,
          kind,
          digest: task.snapshot.digest,
          chars: task.snapshot.totalChars,
          generation: conn.generation,
          runtime: { path: runtime?.path || null, kind: runtime?.kind || null, version: runtime?.version || null, sha256: runtime?.sha256 || null },
          agentVersion: this.handshake?.agentInfo?.version || null,
          model: task.requested?.model?.value ?? null,
          thinking: task.requested?.thought_level?.value ?? null,
          holder: this.lock.token,
          simulated: task.simulated,
        });
      } catch {
        this.finishTask(task, { outcome: "not_sent", message: "没有发出：写不进本机事件记录（用户配置目录）。工坊要先记下“已发出”才发。" });
        throw new AcpAssistError(500, "acp_events_unwritable", "写不进本机事件记录（用户配置目录），这一轮没有发出。");
      }
      // 写记录的那一下：作者可能点了停止或断开、acp.json 可能在外面被改了、重新检查可能发现程序不对。
      // 所以写完以后再读一次本机设置，然后在下面这一段里一起核对（连接、停止、作废、设置、收件方），
      // 核对完到发出 session/prompt 之间不再有任何 await。核对不过：这一轮记成“没有发出”，不当成结果未知。
      let settingsAfter = null;
      try {
        settingsAfter = await this.settings();
      } catch {
        settingsAfter = null;
      }
      const drift = settingsAfter ? launchChanges(this.connectedRuntime?.launchConfig, launchConfigOf(settingsAfter)) : ["本机设置（读不出来）"];
      const sameRecipient = JSON.stringify(this.runtimeBinding()) === JSON.stringify(binding.runtime);
      if (task.cancelRequested || conn !== this.conn || conn.closed || conn.revoked || !sameRecipient || drift.length) {
        await this.journal.append({ event: "finished", taskId: task.id, outcome: "not_sent", stopReason: null, chars: 0 }).catch(() => {});
        if (drift.length && !task.cancelRequested && conn === this.conn && !conn.revoked) {
          await this.invalidateFor("config_changed", `本机设置在连接以后变了（${drift.join("、")}）`);
        }
        const failure = conn.revoked
          ? revokedError(conn.revoked)
          : task.cancelRequested || conn !== this.conn || conn.closed
            ? new AcpAssistError(409, "acp_cancelled_before_send", "你在发出前停止了：这一轮没有发出。")
            : new AcpAssistError(409, "acp_preview_changed", "要发给的程序或连接和刚才不一样了：这一轮没有发出，请重新预览。");
        this.finishTask(task, { outcome: "not_sent", message: `没有发出：${failure.message}` });
        throw failure;
      }
      session.used = true;
      session.taskId = task.id;
      task.sessionId = session.id;
      task.generation = conn.generation;
      task.state = "running";
      task.sentAt = this.at();
      task.snapshot.sent = true;
      // 这一轮属于哪一次连接、哪个程序：结果只按它们记，迟到的结果碰不到后来的连接。
      task.runtime = this.connectedRuntime;
      task.handshake = this.handshake;
      task.protocolErrorsAtStart = conn.stats.protocolErrors;
      this.runPrompt(task, conn, session, prepared.blocks);
      // 作者确认过额度受限以后发出去了：清掉暂停（磁盘上的也清，不管是不是这个进程记下的）。
      if (pausedAtSend || this.quotaPause) {
        task.quotaAcknowledged = true;
        this.quotaPause = null;
        this.clearCondition(["quota_limited"]);
        this.writeRecord({ quotaPause: null });
      }
      return { taskId: task.id, snapshot: publicSnapshot(task.snapshot) };
    });
    return { ...started, status: await this.status() };
  }

  armIdle(task) {
    if (task.timers.idle) clearTimeout(task.timers.idle);
    task.timers.idle = setTimeout(() => this.promptTimedOut(task, "idle"), this.timeouts.promptIdleMs);
  }

  clearTaskTimers(task) {
    for (const timer of Object.values(task.timers)) if (timer) clearTimeout(timer);
    task.timers = {};
  }

  runPrompt(task, conn, session, blocks) {
    this.armIdle(task);
    task.timers.total = setTimeout(() => this.promptTimedOut(task, "total"), this.timeouts.promptTotalMs);
    task.done = conn.request("session/prompt", { sessionId: session.id, prompt: blocks }, { timeoutMs: 0 }).then(
      (result) => {
        task.settled = true;
        if (task.state === "finished") {
          task.lateResponse = true;
          return;
        }
        this.finishTask(task, { stopReason: typeof result?.stopReason === "string" ? result.stopReason.slice(0, 60) : null });
      },
      (error) => {
        task.settled = true;
        if (task.state === "finished") return;
        const kept = task.chunks.length ? "已经收到的部分标成不完整，不当候选稿。" : "";
        if (error instanceof AcpClosedError) {
          this.finishTask(task, { outcome: "unknown", message: `结果未知：官方程序在回答途中断开了（${error.reason || "原因不明"}）。不能确定 Google 那边是否已经处理，这一轮不会自动重发。${kept}` });
        } else if (isQuota(error)) {
          this.finishTask(task, { outcome: "quota", message: `${this.quotaMessage(error)}${kept}` });
        } else if (isAuthRequired(error)) {
          this.finishTask(task, { outcome: "auth_required", message: `官方程序说登录已经失效（Authentication required）：这一轮没有完整结果，重新登录后由你决定要不要再发。${kept}` });
        } else {
          this.finishTask(task, { outcome: "failed", message: `出错：${this.describeError(error)}。这一轮没有候选稿，工坊不会自动重试。${kept}` });
        }
      },
    ).catch((error) => {
      console.error("[acp-assist]", error);
    });
    return task.done;
  }

  promptTimedOut(task, which) {
    if (task.state === "finished" || task.timedOut) return;
    task.timedOut = which;
    this.requestCancel(task, "timeout");
  }

  requestCancel(task, why) {
    if (task.state === "finished") return;
    if (!task.cancelRequested) task.cancelRequested = why;
    if (task.state !== "running") return;
    task.state = "cancelling";
    task.cancelAt = this.at();
    for (const name of ["idle", "total"]) {
      if (task.timers[name]) clearTimeout(task.timers[name]);
      task.timers[name] = null;
    }
    try {
      this.conn?.notify("session/cancel", { sessionId: task.sessionId });
      task.cancelSent = true;
    } catch {
      // 连接已经断了：断线那边会把这一轮收成“结果未知”。
    }
    task.timers.cancel = setTimeout(() => this.cancelNotConfirmed(task), this.timeouts.cancelWaitMs);
  }

  async cancelNotConfirmed(task) {
    if (task.state === "finished") return;
    const seconds = duration(this.timeouts.cancelWaitMs);
    if (task.timedOut) {
      this.finishTask(task, { outcome: "unknown", message: `结果未知：官方程序太久没有回应，工坊发了停止请求，${seconds}内也没有得到确认，已经结束工坊启动的这个官方程序。不能确定 Google 那边是否已经处理，这一轮不会自动重发。` });
    } else {
      this.finishTask(task, { outcome: "cancel_unconfirmed", message: `取消未确认：停止请求发出 ${seconds}后官方程序还没有确认，工坊已经结束它启动的这个官方程序。已经收到的部分标成不完整；这一轮的结果未知，不会自动重发。` });
    }
    await this.dropConnection("cancel_unconfirmed");
  }

  async cancel({ taskId } = {}) {
    const task = this.task;
    if (!task || task.state === "finished") throw new AcpAssistError(409, "acp_nothing_to_cancel", "现在没有进行中的请求");
    if (taskId && taskId !== task.id) throw new AcpAssistError(409, "acp_wrong_task", "要停的不是当前这一轮（页面上的状态过时了，刷新一下）");
    this.requestCancel(task, "author");
    return this.status();
  }

  finishTask(task, { stopReason = null, outcome = null, message = null } = {}) {
    if (task.state === "finished") return;
    this.clearTaskTimers(task);
    const text = task.chunks.join("").replace(/\r\n?/g, "\n");
    task.reportedModel = task.sessionId ? this.reportedSetting(task.sessionId, "model") : null;
    let result = outcome;
    let note = null;
    if (!result) {
      if (stopReason === "end_turn") result = text.trim() ? "complete" : "empty";
      else if (stopReason === "max_tokens") result = "truncated";
      else if (stopReason === "max_turn_requests") result = "turn_limit";
      else if (stopReason === "refusal") result = "refused";
      else if (stopReason === "cancelled") result = "cancelled";
      else result = "unknown_stop";
      if (task.timedOut) result = "unknown";
      if (result === "complete" && task.overflow) {
        result = "truncated";
        note = `回复超过 ${MAX_REPLY_CHARS} 字，工坊只收了前面一部分，不当候选稿。`;
      } else if (result === "complete" && task.replyGap) {
        result = "truncated";
        note = "回复途中有一行协议消息坏了或超长被丢掉，结果可能缺字，不当候选稿；可以复制下面收到的部分。";
      } else if (result === "complete" && task.cancelRequested) {
        result = "cancel_race";
      } else if (result === "complete") {
        const want = task.requested?.model?.value;
        const got = task.reportedModel?.value;
        if (want !== undefined && want !== null && got !== undefined && got !== null && want !== got) {
          result = "model_changed";
          task.modelMismatch = { requested: task.requested.model, reported: task.reportedModel };
        }
      }
    }
    task.state = "finished";
    task.outcome = result;
    task.stopReason = stopReason;
    task.finishedAt = this.at();
    task.message = message || note || this.outcomeMessage(task, result, stopReason);
    task.candidate = result === "complete" ? text.trim() : null;
    task.partial = PARTIAL_OUTCOMES.has(result) && text ? text : null;
    if (result === "model_changed") this.setCondition("config_invalid", task.message);
    if (result === "quota") this.pauseForQuota(task.message);
    if (result === "auth_required") {
      const expired = this.auth.state === "ok" || this.auth.state === "implicit";
      this.auth = { state: expired ? "expired" : "needed", methodId: this.auth.methodId || null, at: this.at() };
    }
    task.recorded = this.recordTask(task).catch(() => {});
    task.markFinished();
  }

  outcomeMessage(task, outcome, stopReason) {
    switch (outcome) {
      case "complete":
        return "收到了完整回复（end_turn）。这只是候选稿：可以复制，或放进编辑器后照常保存（保存前先备份、核对版本）。";
      case "empty":
        return "官方程序结束了这一轮（end_turn），但没有给出正文，没有候选稿。";
      case "truncated":
        return "回答被截断了（max_tokens）：下面是不完整的部分输出，不当候选稿；少选一些再试。";
      case "turn_limit":
        return "这一轮官方程序调用模型的次数到上限了（max_turn_requests）：下面是不完整的部分输出，不当候选稿。";
      case "refused":
        return "官方程序拒绝回答（refusal），没有候选稿。";
      case "cancelled":
        return task.cancelRequested
          ? "已停止：官方程序确认了（cancelled）。停止前收到的部分标成不完整，不当候选稿。"
          : "官方程序自己停下了这一轮（cancelled），没有候选稿。";
      case "cancel_race":
        return `你点了停止，但官方程序仍以 end_turn 交回了整段（停止以后又收到 ${task.afterCancelChunks} 段）：标成不完整，不当候选稿，也不算已真实接通；可以复制。`;
      case "model_changed":
        return `官方程序在这一轮里把模型从“${task.modelMismatch?.requested?.name ?? "未知"}”换成了“${task.modelMismatch?.reported?.name ?? "未知"}”：这份回复不一定出自你要的模型，不当候选稿，也不算已真实接通；可以复制。下一次发送前先点“选择模型和思考强度”看看。`;
      case "unknown":
        return "结果未知：这一轮不会自动重发。";
      default:
        return `官方程序给了一个工坊不认识的结束原因（${stopReason ?? "没有"}），这份结果不当候选稿。`;
    }
  }

  async recordTask(task) {
    const handshake = task.handshake || null;
    const runtime = task.runtime || null;
    const patch = { lastTask: recordedTask(task) };
    if (task.outcome === "complete" && handshake && runtime) {
      const mark = {
        at: task.finishedAt,
        taskKind: task.kind,
        requestedModel: task.requested?.model || null,
        requestedThought: task.requested?.thought_level || null,
        reportedModel: task.reportedModel || null,
        runtimePath: runtime.path,
        runtimeKind: runtime.kind,
        runtimeVersion: runtime.version || null,
        runtimeSha256: runtime.sha256 || null,
        agentInfo: handshake.agentInfo,
        protocolVersion: handshake.protocolVersion,
        stopReason: task.stopReason,
        chars: task.chars,
        connectionId: handshake.connectionId || null,
        launchConfig: runtime.launchConfig || null,
        sourceVerified: sourceVerified(runtime),
        expectedSha256: runtime.checksum?.expected || null,
        simulated: Boolean(handshake.simulated),
        claimsOfficial: Boolean(handshake.official),
      };
      // 不算真实接通的几种：模拟程序；不自称 Antigravity；程序来源没核对（最多只算协议结果）；
      // 这一轮结束时旧连接已经作废或断开（迟到的结果不能把“已接通”找回来）。
      const why = [];
      if (handshake.simulated) why.push("这是模拟程序（工坊自己的测试程序，不是 Google 的）");
      if (!handshake.official) why.push(`对方不自称 Antigravity（自称“${handshake.agentInfo?.title || handshake.agentInfo?.name || "未知"}”）`);
      if (!mark.sourceVerified) {
        why.push(runtime.hashOf === "windows-shim"
          ? "程序来源没有核对（校验值是 .cmd/.bat 启动脚本的，不是它启动的程序的）"
          : "程序来源没有核对（没有填你核对过的 SHA-256，或者对不上）");
      }
      const settingsNow = await this.settings().then(launchConfigOf, () => null);
      if (!settingsNow || launchChanges(runtime.launchConfig, settingsNow).length) why.push("这一轮里本机设置变了");
      const current = Boolean(this.conn && !this.conn.revoked && this.handshake?.connectionId && this.handshake.connectionId === handshake.connectionId);
      if (!current) why.push("这一轮结束时这次连接已经作废或断开");
      if (!why.length) {
        patch.real = mark;
        patch.realCleared = null;
      } else {
        patch.lastSimulated = { ...mark, countsAs: handshake.simulated ? "simulated" : "protocol_only", why };
      }
    }
    if (task.sentAt) {
      await this.journal.append({ event: "finished", taskId: task.id, outcome: task.outcome, stopReason: task.stopReason, chars: task.chars }).catch(() => {});
    }
    await this.writeRecord(patch);
  }

  async waitForTask(taskId) {
    const task = this.tasks.get(taskId);
    if (!task) throw new AcpAssistError(404, "acp_task_unknown", "找不到这一轮");
    await task.whenFinished;
    await task.recorded;
    return publicTask(task);
  }

  // ---- 官方程序发来的消息
  onProtocolProblem(problem, source) {
    if (source !== this.conn) return;
    const task = this.task;
    if (!task || (task.state !== "running" && task.state !== "cancelling")) return;
    // 坏掉或超长被丢掉的一行如果可能是一段回复，这一轮的正文就可能缺了一块。
    if (problem?.maybeChunk) task.replyGap = true;
  }

  onNotification(method, params, source) {
    if (source !== this.conn) {
      this.counters.staleMessages += 1;
      return;
    }
    if (method !== "session/update") return;
    const sessionId = typeof params?.sessionId === "string" ? params.sessionId : null;
    const update = params?.update;
    const session = sessionId ? this.sessions.get(sessionId) : null;
    if (!session || !update || typeof update.sessionUpdate !== "string") {
      this.counters.strayUpdates += 1;
      return;
    }
    if (update.sessionUpdate === "config_option_update") {
      this.rememberOptions(session, parseConfigOptions(update.configOptions));
      return;
    }
    const task = session.taskId ? this.tasks.get(session.taskId) : null;
    if (!task) {
      this.counters.sessionUpdates += 1;
      return;
    }
    if (task.state === "finished") {
      // 迟到的消息只归它原来那一轮，记一笔，不拼进任何候选稿。
      task.lateUpdates += 1;
      return;
    }
    if (task.state === "running") this.armIdle(task);
    const kind = update.sessionUpdate;
    if (kind === "agent_message_chunk") {
      const content = update.content;
      if (content && content.type === "text" && typeof content.text === "string") {
        // 超过上限以后整轮不再收：留下的部分是连续的前一段，不会中间缺一块。
        if (task.overflow) return;
        const count = charCount(content.text);
        if (task.chars + count > MAX_REPLY_CHARS) {
          task.overflow = true;
          return;
        }
        task.chunks.push(content.text);
        task.chars += count;
        task.chunkCount += 1;
        if (task.state === "cancelling") task.afterCancelChunks += 1;
      } else {
        task.nonTextChunks += 1;
      }
    } else if (kind === "agent_thought_chunk") task.thoughtChunks += 1;
    else if (kind === "tool_call") task.toolCalls += 1;
    else if (kind === "tool_call_update") task.toolCallUpdates += 1;
    else if (kind === "plan") task.plans += 1;
    else task.otherUpdates += 1;
  }

  // 官方程序发来的请求：权限一律不给（能拒绝就选拒绝，停止以后一律答 cancelled）；
  // 文件、终端和别的方法工坊没有声明，一律 Method not found。
  onAgentRequest(method, params, source) {
    if (source !== this.conn) throw methodNotFound(method);
    if (method !== "session/request_permission") throw methodNotFound(method);
    const session = typeof params?.sessionId === "string" ? this.sessions.get(params.sessionId) : null;
    const task = session?.taskId ? this.tasks.get(session.taskId) : null;
    const options = Array.isArray(params?.options) ? params.options : [];
    if (task) task.permissionRequests += 1;
    if (!task || task.state !== "running") {
      if (task) task.permissionCancelled += 1;
      return { outcome: { outcome: "cancelled" } };
    }
    const reject = options.find((option) => option?.kind === "reject_once" && typeof option.optionId === "string")
      || options.find((option) => option?.kind === "reject_always" && typeof option.optionId === "string");
    if (!reject) {
      task.permissionCancelled += 1;
      return { outcome: { outcome: "cancelled" } };
    }
    task.permissionRejected += 1;
    return { outcome: { outcome: "selected", optionId: reject.optionId } };
  }

  onConnectionClosed(reason, source) {
    if (source !== this.conn) return;
    // 不是工坊自己断开的：官方程序退出了或者管道断了。
    this.lastDiagnostics = { stderr: source.stderrTail(), protocol: { ...source.stats } };
    const proc = this.proc;
    const dir = this.workDir;
    this.conn = null;
    this.proc = null;
    this.workDir = null;
    this.session = null;
    this.handshake = null;
    const task = this.task;
    if (task && (task.state === "running" || task.state === "cancelling")) {
      this.finishTask(task, { outcome: "unknown", message: `结果未知：官方程序在回答途中退出了（${reason || "原因不明"}）。不能确定 Google 那边是否已经处理，这一轮不会自动重发。` });
    } else if (!this.condition) {
      this.setCondition("connect_failed", `连接失败：官方程序退出了（${reason || "原因不明"}）。`);
    }
    Promise.resolve(proc?.stop()).catch(() => {}).then(() => removeWorkDirectory(dir)).catch(() => {});
  }

  async dropConnection(reason) {
    const conn = this.conn;
    const proc = this.proc;
    const dir = this.workDir;
    if (conn) this.lastDiagnostics = { stderr: conn.stderrTail(), protocol: { ...conn.stats } };
    this.conn = null;
    this.proc = null;
    this.workDir = null;
    this.session = null;
    this.handshake = null;
    if (!["cancelled", "failed"].includes(this.auth.state)) this.auth = { state: "unknown" };
    conn?.close({
      handshake_failed: "握手没有成功",
      handshake_invalid: "握手结果不对",
      login_timeout: "登录超时",
      cancel_unconfirmed: "停止没有得到确认",
      server_shutdown: "写作台关闭",
      disconnected: "作者断开",
      invalidated: "旧连接已作废",
    }[reason] || reason);
    if (proc) await proc.stop();
    if (dir) await removeWorkDirectory(dir);
  }

  async disconnect({ reason = "disconnected" } = {}) {
    if (this.busy?.code === "logging_in") this.loginAbort = true;
    const task = this.task;
    if (task && task.state !== "finished") {
      if (task.state === "preparing") task.cancelRequested = "disconnect";
      else this.finishTask(task, { outcome: "unknown", message: "结果未知：回答完成前断开了连接。不能确定 Google 那边处理到哪一步，这一轮不会自动重发。" });
    }
    if (this.conn) await this.dropConnection(reason);
    return this.status();
  }

  async shutdown() {
    await this.disconnect({ reason: "server_shutdown" }).catch(() => {});
    for (const task of this.tasks.values()) await task.recorded.catch(() => {});
    await this.recordWrites.catch(() => {});
    this.lock.releaseSync();
  }
}

export function createAcpProvider(options = {}) {
  return new AcpProvider(options);
}

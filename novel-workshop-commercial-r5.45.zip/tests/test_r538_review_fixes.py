#!/usr/bin/env python3
"""r5.38: the reproducible points of the r5.37 review, as regression tests (offline, with stand-ins).

The review's probes were not run; their paths are written out here. Stand-ins for the network, the crawler and the
model show how the records behave, not that any real service or model works. Pinned:

1.1 the same image again: an image the library already picked is changed only as the author says (mode add, replace
    or use), and without a mode it is refused before anything is written; add keeps what was taken (with the choice
    that took it), replace keeps the old parts in the log, use only adds a chapter; the same choice again writes
    nothing; one part can be taken back (not a part in the accepted text, which replace cannot drop either); an image
    turned down before can be taken later; an image already picked and now not wanted is a withdrawal, said before
    anything is written (a visual choice that says withdraw is pointed to the library); two people adding to the same
    entry keep both additions with --rebase; another image under the same id is refused; a later look at the image
    replaces the library's, an older one does not; a selection's mode, parts and withdraw are checked before writing,
    and the library check sees a part taken twice or a kept part's broken decision; a part taken for one scene stays
    on that scene's card when the image is used in another chapter (found by the ordinary flow), until the author adds
    it there too;
1.2 the adoption receipt: the author's chain is complete only for the selection that was written; a new choice waits
    until it is written; an earlier adoption is history; a receipt from before r5.38 does not count;
1.3 what was seen, by version: a later look at the same image that changes anything (unclear, suggest, conflicts,
    date) is a new version; reuse takes the latest, shown with its id; reuse is refused when a newer version came in
    after the template was made; an archive from before r5.38 is read by order;
2.  rank's cache: a changed file is not encoded, cached, scored or recommended; a cached vector is used only for the
    file it was made from, and the model is only given bytes checked against the name they are stored under; nothing
    left to rank is files_changed (exit 1); a cache from before r5.38 is not read; joint speech across a comma
    (两人齐声说, 宋青、林满…，齐声说) is never given to one person, and the people who may be in the group are listed
    (the whole 、 chain, not the one looked at);
3.  every library write has an operation_id: the same original restored twice is logged twice, a pending line is
    never logged twice; page words not read this time are marked as earlier; another page showing the same image is a
    source;
4.  one ordinary flow, offline: a feeling, candidates, one part taken, the same image's other part added, the image used
    again in the next chapter, and the next chapter's card;
5.  the two references say what can be done and what is refused before writing.
"""
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


r537 = load(HERE / "test_r537_review_fixes.py", "r538_r537")
vm, picture, read, write, run, answer = r537.vm, r537.picture, r537.read, r537.write, r537.run, r537.answer
READ, WRITE, SCRIPTS, REQUEST, FakeModel = r537.READ, r537.WRITE, r537.SCRIPTS, r537.REQUEST, r537.FakeModel
empty_library, SEEN = r537.empty_library, r537.SEEN


def choice(bundle_id, n, part=None, mode=None, words="", date="2026-10-24", use=None):
    item = {"n": n}
    if part:
        item["take"] = [{"part": part, "scope": "stable", "subject": "旧铺子"}]
    if mode:
        item["mode"] = mode
    if use:
        item["use"] = use
    return {"schema": "visual-choice/1", "bundle_id": bundle_id,
            "decision": {"by": "作者", "date": date, "words": words or "%d 的%s" % (n, (part or "用处")[:2])},
            "choose": [item]}


def selection(**fields):
    return dict({"schema": "inspiration-selection/1", "decision": {"by": "作者", "date": "2026-10-24"}}, **fields)


def picked_library(path, take=None, established=None, sha="ab" * 32):
    entry = {"id": "WEB-1", "kind": "place", "title": "旧铺子", "status": "picked",
             "source": {"type": "link", "url": "https://page.example.org/shop", "license": "CC BY 2.0"},
             "image": {"sha256": sha, "width": 320, "height": 240},
             "observation": {"scope": "original", "image_sha256": sha, "seen": "柜台在左，墙上一排灯", "by": "作者",
                             "date": "2026-10-23"},
             "take": take or [{"part": "布局", "scope": "stable"}], "decision": {"by": "作者", "date": "2026-10-23",
                                                                             "words": "要布局"},
             "use": [{"chapter": 7, "scene": "S1"}], "conflicts": []}
    if established:
        entry["established"] = established
    return write(path, {"schema": "inspiration-library/2", "book": "测试", "revision": 1, "entries": [entry]})


def log_lines(library):
    target = Path(str(library)).with_name(Path(library).stem + ".history") / "log.jsonl"
    return [json.loads(x) for x in target.read_text(encoding="utf-8").splitlines() if x.strip()]


class Base(r537.Base):
    def adopt(self, run_dir, library, revision, **kw):
        return vm("adopt").run_adopt(run_dir, library, revision, **kw)

    def verify(self, run_dir):
        return vm("verify").run_verify(run_dir)

    def looked(self):
        run_dir, cfg, stand, bundle = self.bundled()
        self.observe(run_dir, cfg, {1: dict(SEEN, seen="柜台在下方，墙上一排竖着的亮条"), 2: dict(SEEN, seen="二号的水沟")})
        return run_dir, cfg, stand, bundle


# --- 1.1 the same image again --------------------------------------------------------------------------------------

class SameImageAgain(Base):
    def first_part(self):
        run_dir, cfg, stand, bundle = self.looked()
        library = empty_library(self.root / "library.json")
        self.select(run_dir, cfg, choice(bundle["bundle_id"], 1, "布局：柜台在下方", words="1 的布局", date="2026-10-23"))
        self.assertEqual(self.adopt(run_dir, library, 0)["status"], "OK")
        return run_dir, cfg, stand, bundle, library

    def test_another_part_of_an_image_already_taken(self):
        # The review's path: 布局 adopted; the same image chosen again for 灯光, nothing said about 布局.
        run_dir, cfg, stand, bundle, library = self.first_part()
        self.select(run_dir, cfg, choice(bundle["bundle_id"], 1, "灯光：墙上一排竖着的亮条", words="1 的灯光也要"))
        before = library.read_bytes()
        report = self.adopt(run_dir, library, 1)
        self.assertEqual(report["status"], "ERROR")
        for phrase in ("already picked", "布局：柜台在下方", "mode add", "mode replace", "mode use", "nothing written"):
            self.assertIn(phrase, report["error"])
        self.assertEqual(library.read_bytes(), before)  # 布局 was not silently replaced by 灯光
        # The author says it is added.
        self.select(run_dir, cfg, choice(bundle["bundle_id"], 1, "灯光：墙上一排竖着的亮条", mode="add",
                                         words="1 的灯光也要"))
        report = self.adopt(run_dir, library, 1)
        self.assertEqual((report["status"], report["revision"]), ("OK", 2), report)
        entry = read(library)["entries"][0]
        self.assertEqual([(t["part"], t["decision"]["words"]) for t in entry["take"]],
                         [("布局：柜台在下方", "1 的布局"), ("灯光：墙上一排竖着的亮条", "1 的灯光也要")])
        self.assertEqual(entry["decision"]["words"], "1 的灯光也要")  # the latest; each part keeps its own
        self.assertEqual(entry["use"], [{"chapter": 7, "scene": "S1"}])
        code, report = answer(run(READ, "check", library))
        self.assertEqual((code, report["problems"]), (0, []), report)
        code, card, err = run(READ, "card", library, "--chapter", "7")
        self.assertIn("布局：柜台在下方（稳定）；灯光：墙上一排竖着的亮条（稳定）", card)
        last = log_lines(library)[-1]
        self.assertEqual(last["changes"][entry["id"]]["parts_added"], ["灯光：墙上一排竖着的亮条"])
        self.assertTrue(last["operation_id"].startswith("op-"))

    def test_the_same_choice_again_writes_nothing(self):
        run_dir, cfg, stand, bundle, library = self.first_part()
        self.select(run_dir, cfg, choice(bundle["bundle_id"], 1, "布局：柜台在下方", mode="add", words="还是布局"))
        before, lines = library.read_bytes(), len(log_lines(library))
        report = self.adopt(run_dir, library, 1)
        self.assertEqual((report["status"], report["revision"]), ("UNCHANGED", 1), report)
        self.assertEqual((library.read_bytes(), len(log_lines(library))), (before, lines))
        self.assertTrue(self.verify(run_dir)["chain"]["complete"])  # the library holds this choice
        # A part already taken another way is not changed by add: that needs replace.
        changed = choice(bundle["bundle_id"], 1, "布局：柜台在下方", mode="add")
        changed["choose"][0]["take"][0]["scope"] = "scene"
        self.select(run_dir, cfg, changed)
        report = self.adopt(run_dir, library, 1)
        self.assertEqual(report["status"], "ERROR")
        self.assertIn("use mode replace", report["error"])

    def test_replace_when_the_author_says_so(self):
        run_dir, cfg, stand, bundle, library = self.first_part()
        self.select(run_dir, cfg, choice(bundle["bundle_id"], 1, "灯光：墙上一排竖着的亮条", mode="replace",
                                         words="不要布局了，只要灯光"))
        self.assertEqual(self.adopt(run_dir, library, 1)["status"], "OK")
        entry = read(library)["entries"][0]
        self.assertEqual([t["part"] for t in entry["take"]], ["灯光：墙上一排竖着的亮条"])
        change = log_lines(library)[-1]["changes"][entry["id"]]
        self.assertEqual(change["mode"], "replace")
        self.assertEqual([(t["part"], t["decision"]["words"]) for t in change["take_before"]],
                         [("布局：柜台在下方", "1 的布局")])  # the old part and the choice that took it stay in the log

    def test_the_same_image_in_another_chapter(self):
        run_dir, cfg, stand, bundle, library = self.first_part()
        sha = bundle["items"][0]["sha256"]
        later = self.root / "run-ch8"
        vm("search").run_search(dict(REQUEST, chapter=8, scene="S2"), cfg, later, fetch=stand)
        vm("collect").run_collect(later, cfg, fetch=stand, crawl=lambda p, c: ([], None))
        vm("review").run_bundle(later, cfg)
        again = read(later / "review" / "bundle.json")
        n = next(i["n"] for i in again["items"] if i["sha256"] == sha)
        made = vm("selection").run_select(later, cfg, write(self.root / "c8.json", choice(again["bundle_id"], n, mode="use",
                                                                                           words="第八章也用它")))
        self.assertEqual(made["status"], "ok")
        report = self.adopt(later, library, 1)
        self.assertEqual((report["status"], report["revision"]), ("OK", 2), report)
        entry = read(library)["entries"][0]
        self.assertEqual(entry["use"], [{"chapter": 7, "scene": "S1"}, {"chapter": 8, "scene": "S2"}])
        self.assertEqual([t["part"] for t in entry["take"]], ["布局：柜台在下方"])
        code, card, err = run(READ, "card", library, "--chapter", "8")
        self.assertIn("布局：柜台在下方", card)
        with self.assertRaises(vm("common").VisualError):  # use does not take parts
            vm("selection").run_select(later, cfg, write(self.root / "c9.json", choice(again["bundle_id"], n, "灯光",
                                                                                        mode="use")))

    def test_a_part_for_one_scene_stays_there(self):
        # Found by the ordinary flow (repro/r5.38/ordinary-flow): the image used again in chapter 8 brought along, on
        # chapter 8's card, a part the author had taken only for a scene of chapter 7.
        run_dir, cfg, stand, bundle = self.looked()
        library = empty_library(self.root / "library.json")
        first = choice(bundle["bundle_id"], 1, "布局：柜台在下方", words="1 的布局，那排亮条只用这一场")
        first["choose"][0]["take"].append({"part": "灯光：墙上一排竖着的亮条", "scope": "scene", "subject": "旧铺子"})
        self.select(run_dir, cfg, first)
        self.assertEqual(self.adopt(run_dir, library, 0)["status"], "OK")
        entry = read(library)["entries"][0]
        self.assertEqual([t.get("taken_for") for t in entry["take"]], [None, [{"chapter": 7, "scene": "S1"}]])
        sha = bundle["items"][0]["sha256"]
        later = self.root / "run-ch8"
        vm("search").run_search(dict(REQUEST, chapter=8, scene="S2"), cfg, later, fetch=stand)
        vm("collect").run_collect(later, cfg, fetch=stand, crawl=lambda p, c: ([], None))
        vm("review").run_bundle(later, cfg)
        again = read(later / "review" / "bundle.json")
        n = next(i["n"] for i in again["items"] if i["sha256"] == sha)
        vm("selection").run_select(later, cfg, write(self.root / "c8.json", choice(again["bundle_id"], n, mode="use",
                                                                                   words="第八章也用它")))
        self.assertEqual(self.adopt(later, library, 1)["status"], "OK")
        code, card, err = run(READ, "card", library, "--chapter", "8")
        self.assertIn("布局：柜台在下方（稳定）", card)
        self.assertNotIn("灯光：墙上一排竖着的亮条（这一场）", card)
        self.assertIn("不带到这里：“灯光：墙上一排竖着的亮条”只用在第 7 章 S1（为那一场借的）；这里也要用，请作者说（mode add）", card)
        code, card7, err = run(READ, "card", library, "--chapter", "7")
        self.assertIn("灯光：墙上一排竖着的亮条（这一场）", card7)
        # The author says chapter 8's scene takes it too: the same part, added for this scene.
        more = choice(again["bundle_id"], n, "灯光：墙上一排竖着的亮条", mode="add", words="第八章也要那排亮条")
        more["choose"][0]["take"][0]["scope"] = "scene"
        vm("selection").run_select(later, cfg, write(self.root / "c8b.json", more))
        report = self.adopt(later, library, 2)
        self.assertEqual(report["changes"][entry["id"]]["parts_for_more_scenes"], ["灯光：墙上一排竖着的亮条"])
        code, card, err = run(READ, "card", library, "--chapter", "8")
        self.assertIn("灯光：墙上一排竖着的亮条（这一场）", card)
        code, report = answer(run(READ, "check", library))
        self.assertEqual(report["problems"], [])

    def test_an_image_turned_down_before_can_be_taken(self):
        run_dir, cfg, stand, bundle = self.looked()
        first = bundle["items"][0]
        entry_id = "VM-" + first["sha256"][:10]
        library = write(self.root / "library.json", {"schema": "inspiration-library/2", "book": "测试", "revision": 1,
                                                     "entries": [{"id": entry_id, "kind": "place", "title": "不要的",
                                                                  "status": "rejected", "source": {
                                                                      "type": "link", "url": first["page_url"],
                                                                      "license": "未核，只作写作参考"},
                                                                  "image": {"sha256": first["sha256"], "width": 1,
                                                                            "height": 1},
                                                                  "observation": {"scope": "none"},
                                                                  "decision": {"by": "作者", "date": "2026-10-20"}}]})
        self.select(run_dir, cfg, choice(bundle["bundle_id"], 1, "布局：柜台在下方", words="现在要它的布局"))
        report = self.adopt(run_dir, library, 1)  # r5.37: "already in the library; leave entry out"
        self.assertEqual(report["status"], "OK", report)
        entry = read(library)["entries"][0]
        self.assertEqual((entry["status"], entry["decision"]["words"]), ("picked", "现在要它的布局"))
        self.assertEqual(entry["observation"]["seen"], "柜台在下方，墙上一排竖着的亮条")  # the look made now

    def test_taking_back_is_not_a_choice(self):
        run_dir, cfg, stand, bundle = self.looked()
        asked = choice(bundle["bundle_id"], 1, "布局")
        asked["withdraw"] = [{"n": 1, "parts": ["布局"]}]
        with self.assertRaises(vm("common").VisualError) as caught:
            self.select(run_dir, cfg, asked)
        for phrase in ("inspiration_write.py adopt", "withdraw", "nothing written"):
            self.assertIn(phrase, str(caught.exception))
        self.assertFalse((run_dir / "selection.json").exists())


class SameEntryInTheLibrary(unittest.TestCase):
    """1.1 in the library writer itself: these need no image decoding, so they run without Pillow too."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_taking_back_one_part(self):
        w = load(WRITE, "r538_w1")
        library = picked_library(self.root / "lib.json", take=[{"part": "布局", "scope": "stable"},
                                                              {"part": "灯光", "scope": "scene"}],
                                 established=[{"part": "布局", "where": "项目档案", "chapter": 7}])
        with self.assertRaises(w.LibraryError) as caught:
            w.adopt(library, selection(withdraw=[{"id": "WEB-1", "parts": ["布局"]}]), 1)
        self.assertIn("accepted text", str(caught.exception))
        report = w.adopt(library, selection(decision={"by": "作者", "date": "2026-10-24", "words": "灯光不要了"},
                                            withdraw=[{"id": "WEB-1", "parts": ["灯光"]}]), 1)
        self.assertEqual(report["status"], "OK")
        entry = read(library)["entries"][0]
        self.assertEqual((entry["status"], [t["part"] for t in entry["take"]]), ("picked", ["布局"]))
        self.assertEqual(entry["take"][0]["decision"]["words"], "要布局")
        self.assertEqual(log_lines(library)[-1]["changes"]["WEB-1"]["parts_withdrawn"], ["灯光"])
        with self.assertRaises(w.LibraryError):
            w.adopt(library, selection(withdraw=[{"id": "WEB-1", "parts": ["楼梯"]}]), 2)

    def test_two_people_add_to_the_same_entry(self):
        w = load(WRITE, "r538_w2")
        library = picked_library(self.root / "lib.json")
        w.keep(library, library.read_bytes(), 1)  # revision 1 is in the history, as after any write
        first = selection(decision={"by": "作者", "date": "2026-10-24", "words": "加灯光"},
                          adopt=[{"id": "WEB-1", "mode": "add", "take": [{"part": "灯光", "scope": "scene"}]}])
        second = selection(decision={"by": "作者", "date": "2026-10-24", "words": "加材质"},
                           adopt=[{"id": "WEB-1", "mode": "add", "take": [{"part": "材质", "scope": "stable"}]}])
        self.assertEqual(w.adopt(library, first, 1)["revision"], 2)
        with self.assertRaises(w.Conflict):
            w.adopt(library, second, 1)  # without --rebase the revision guard still stops it
        report = w.adopt(library, second, 1, rebase=True)
        self.assertEqual((report["status"], report["revision"]), ("OK", 3), report)
        self.assertEqual([t["part"] for t in read(library)["entries"][0]["take"]], ["布局", "灯光", "材质"])
        replacing = selection(adopt=[{"id": "WEB-1", "mode": "replace", "take": [{"part": "楼梯", "scope": "stable"}]}])
        with self.assertRaises(w.Conflict) as caught:
            w.adopt(library, replacing, 1, rebase=True)  # a replacement made on revision 1 cannot go on top
        self.assertEqual(caught.exception.changed, ["WEB-1"])

    def test_another_image_under_the_same_id(self):
        w = load(WRITE, "r538_w3")
        library = picked_library(self.root / "lib.json")
        other = json.loads(json.dumps(read(library)["entries"][0]))
        other["image"]["sha256"] = "cd" * 32
        with self.assertRaises(w.LibraryError) as caught:
            w.adopt(library, selection(adopt=[{"id": "WEB-1", "entry": other, "mode": "add",
                                               "take": [{"part": "灯光", "scope": "scene"}]}]), 1)
        self.assertIn("another image version", str(caught.exception))
        with self.assertRaises(w.LibraryError):  # a mode for an entry the library does not have
            w.adopt(library, selection(adopt=[{"id": "WEB-9", "mode": "add", "take": [{"part": "x", "scope": "scene"}]}]),
                    1)

    def test_replace_keeps_what_the_accepted_text_uses(self):
        w = load(WRITE, "r538_w4")
        library = picked_library(self.root / "lib.json", established=[{"part": "布局", "where": "项目档案", "chapter": 7}])
        before = library.read_bytes()
        with self.assertRaises(w.LibraryError) as caught:
            w.adopt(library, selection(adopt=[{"id": "WEB-1", "mode": "replace",
                                               "take": [{"part": "灯光", "scope": "scene"}]}]), 1)
        self.assertIn("accepted text", str(caught.exception))
        self.assertEqual(library.read_bytes(), before)
        report = w.adopt(library, selection(adopt=[{"id": "WEB-1", "mode": "replace", "take": [
            {"part": "布局", "scope": "stable"}, {"part": "灯光", "scope": "scene"}]}]), 1)
        self.assertEqual(report["status"], "OK")

    def test_not_wanted_now_is_taking_back(self):
        # An image already picked, now turned down: that is a withdrawal, said before anything is written.
        w = load(WRITE, "r538_w5")
        library = picked_library(self.root / "lib.json")
        before = library.read_bytes()
        with self.assertRaises(w.LibraryError) as caught:
            w.adopt(library, selection(reject=[{"id": "WEB-1"}]), 1)
        for phrase in ("withdraw", "nothing written"):
            self.assertIn(phrase, str(caught.exception))
        self.assertEqual(library.read_bytes(), before)

    def test_what_a_selection_may_say(self):
        w = load(WRITE, "r538_w6")
        library = picked_library(self.root / "lib.json")
        before = library.read_bytes()
        cases = [
            ({"adopt": [{"id": "WEB-1", "mode": "merge", "take": [{"part": "灯光", "scope": "scene"}]}]}, "mode is add"),
            ({"adopt": [{"id": "WEB-1", "mode": "add", "take": [{"part": "灯光", "scope": "scene"},
                                                                 {"part": "灯光", "scope": "stable"}]}]}, "named twice"),
            ({"adopt": [{"id": "WEB-1", "mode": "use", "take": [{"part": "灯光", "scope": "scene"}],
                         "use": [{"chapter": 8}]}]}, "leave take out"),
            ({"adopt": [{"id": "WEB-1", "mode": "use"}]}, "mode use only adds"),
            ({"withdraw": [{"id": "WEB-1", "parts": ["布局"], "replaced_by": "WEB-2"}]}, "replaced_by is for"),
        ]
        for fields, phrase in cases:
            with self.subTest(phrase=phrase):
                with self.assertRaises(w.LibraryError) as caught:
                    w.adopt(library, selection(**fields), 1)
                self.assertIn(phrase, str(caught.exception))
        self.assertEqual(library.read_bytes(), before)

    def test_the_library_check_of_parts(self):
        def problems(name, take):
            code, report = answer(run(READ, "check", picked_library(self.root / name, take=take)))
            return report["problems"]

        plain = problems("plain.json", [{"part": "布局", "scope": "stable"}])
        twice = problems("twice.json", [{"part": "布局", "scope": "stable"}, {"part": "布局", "scope": "scene"}])
        self.assertEqual([p for p in twice if p not in plain], ["WEB-1: a part is taken twice"])
        broken = problems("broken.json", [{"part": "布局", "scope": "stable", "decision": {"by": "", "date": "x"}}])
        self.assertTrue(any("as decision: {by, date, words}" in p for p in broken if p not in plain), broken)
        kept = problems("kept.json", [{"part": "布局", "scope": "stable",
                                       "decision": {"by": "作者", "date": "2026-10-23", "words": "要布局"}}])
        self.assertEqual(kept, plain)

    def test_a_later_look_is_kept_an_older_one_is_not(self):
        # A run's candidate entry carries its latest look at the image; the library keeps the newer of the two.
        w = load(WRITE, "r538_w7")
        library = picked_library(self.root / "lib.json")  # looked at on 2026-10-23
        entry = json.loads(json.dumps(read(library)["entries"][0]))
        older = dict(entry["observation"], seen="更早的一次：只看到柜台", date="2026-10-20")
        w.adopt(library, selection(adopt=[{"id": "WEB-1", "entry": dict(entry, observation=older), "mode": "add",
                                           "take": [{"part": "灯光", "scope": "scene"}]}]), 1)
        self.assertEqual(read(library)["entries"][0]["observation"]["seen"], "柜台在左，墙上一排灯")
        later = dict(entry["observation"], seen="再看一次：柜台在左，灯是油灯", date="2026-10-24")
        report = w.adopt(library, selection(adopt=[{"id": "WEB-1", "entry": dict(entry, observation=later,
                                                                                   conflicts=["不是市电"]),
                                                    "mode": "add", "take": [{"part": "灯光", "scope": "scene"}]}]), 2)
        self.assertEqual(report["status"], "OK")
        now = read(library)["entries"][0]
        self.assertEqual((now["observation"]["seen"], now["conflicts"]), ("再看一次：柜台在左，灯是油灯", ["不是市电"]))


# --- 1.2 the adoption receipt --------------------------------------------------------------------------------------

class AdoptionReceipt(Base):
    def test_a_new_choice_waits_until_it_is_written(self):
        # The review's path: 1 adopted; the choice changed to 2 and not written; verify-run said complete.
        run_dir, cfg, stand, bundle = self.looked()
        library = empty_library(self.root / "library.json")
        self.select(run_dir, cfg, choice(bundle["bundle_id"], 1, "布局"))
        self.assertEqual(self.adopt(run_dir, library, 0)["status"], "OK")
        chain = self.verify(run_dir)["chain"]
        self.assertTrue(chain["complete"])
        self.assertTrue(chain["state"].startswith("written"))
        self.select(run_dir, cfg, choice(bundle["bundle_id"], 2, "水沟"))
        chain = self.verify(run_dir)["chain"]
        self.assertFalse(chain["complete"])
        self.assertIn("not written yet", chain["state"])
        self.assertEqual([a["status"] for a in chain["earlier_adoptions"]], ["OK"])  # history, not current
        self.assertEqual(len(read(library)["entries"]), 1)
        self.assertEqual(self.adopt(run_dir, library, 1)["status"], "OK")
        chain = self.verify(run_dir)["chain"]
        self.assertTrue(chain["complete"])
        receipt = read(run_dir / "adopt.json")
        self.assertEqual(receipt["selection_sha256"], vm("common").sha256_file(run_dir / "selection.json"))
        self.assertEqual((receipt["bundle_id"], receipt["library_revision"]), (bundle["bundle_id"], 2))
        self.assertTrue(receipt["operation_id"].startswith("op-"))

    def test_looking_again_makes_the_chain_wait(self):
        run_dir, cfg, stand, bundle = self.looked()
        library = empty_library(self.root / "library.json")
        self.select(run_dir, cfg, choice(bundle["bundle_id"], 1, "布局"))
        self.adopt(run_dir, library, 0)
        self.observe(run_dir, cfg, {1: dict(SEEN, seen="再看一遍：柜台在下方")})  # the selection moves to outdated/
        chain = self.verify(run_dir)["chain"]
        self.assertFalse(chain["complete"])
        self.assertIn("no current choice", chain["state"])

    def test_a_receipt_from_before_r538(self):
        run_dir, cfg, stand, bundle = self.looked()
        self.select(run_dir, cfg, choice(bundle["bundle_id"], 1, "布局"))
        write(run_dir / "adopt.json", {"status": "OK", "revision": 1, "library": "library.json"})
        chain = self.verify(run_dir)["chain"]
        self.assertFalse(chain["complete"])
        self.assertIn("before r5.38", chain["state"])


# --- 1.3 what was seen, by version ---------------------------------------------------------------------------------

V1 = {"scope": "original", "seen": "柜台在左，后面有一盏灯", "by": "作者", "date": "2026-10-23", "unclear": "灯的电源看不清"}


class ObservationVersions(Base):
    def rebuilt(self, run_dir, cfg):
        vm("rank").run_rank(run_dir, cfg, backend=FakeModel())  # a new order: the bundle is made again
        vm("review").run_bundle(run_dir, cfg)
        return self.template(run_dir)

    def reuse_first(self, run_dir, cfg, template):
        template["items"][0]["reuse"] = True
        return self.record(run_dir, cfg, template)

    def test_a_correction_is_what_is_reused(self):
        # The review's path: the same image, the same seen, then unclear narrowed and a conflict found.
        run_dir, cfg, stand, bundle = self.bundled()
        v2 = dict(V1, date="2026-10-24", unclear="只能看到灯罩，电线走向看不清", conflicts=["本书无城市电网，不能把灯认成市电灯"])
        self.assertEqual(self.observe(run_dir, cfg, {1: V1})["status"], "OK")
        report = self.observe(run_dir, cfg, {1: v2})
        sha = bundle["items"][0]["sha256"]
        self.assertEqual(report["archived"], ["O-%s-v2" % sha[:8]])
        versions = [r for r in read(run_dir / "observations.archive.json")["items"] if r["sha256"] == sha]
        self.assertEqual([(r["id"], r.get("supersedes")) for r in versions],
                         [("O-%s-v1" % sha[:8], None), ("O-%s-v2" % sha[:8], "O-%s-v1" % sha[:8])])
        template = self.rebuilt(run_dir, cfg)
        shown = template["items"][0]["seen_before"]
        self.assertEqual((shown["observation_id"], shown["conflicts"]), ("O-%s-v2" % sha[:8], v2["conflicts"]))
        text = (run_dir / "review" / "review.md").read_text(encoding="utf-8")
        self.assertIn("最新的一版是 O-%s-v2" % sha[:8], text)
        self.assertIn("本书无城市电网", text)
        self.assertEqual(self.reuse_first(run_dir, cfg, template)["status"], "OK")
        now = read(run_dir / "review" / "observations.recorded.json")["items"][0]
        self.assertEqual((now["unclear"], now["conflicts"], now["date"]), (v2["unclear"], v2["conflicts"], "2026-10-24"))
        self.assertEqual(now["reused_from"]["id"], "O-%s-v2" % sha[:8])

    def test_each_field_alone_is_a_new_version(self):
        for field, value in (("unclear", "只看清灯罩"), ("suggest", ["灯光"]), ("conflicts", ["不能是市电"]),
                             ("date", "2026-10-25")):
            with self.subTest(field=field):
                self.tearDown()
                self.setUp()
                run_dir, cfg, stand, bundle = self.bundled()
                self.observe(run_dir, cfg, {1: V1})
                self.observe(run_dir, cfg, {1: dict(V1, **{field: value})})
                template = self.rebuilt(run_dir, cfg)
                self.assertEqual(template["items"][0]["seen_before"]["version"], 2)
                self.reuse_first(run_dir, cfg, template)
                now = read(run_dir / "review" / "observations.recorded.json")["items"][0]
                self.assertEqual(now[field], value)

    def test_the_same_look_again_is_not_a_new_version(self):
        run_dir, cfg, stand, bundle = self.bundled()
        self.observe(run_dir, cfg, {1: V1})
        self.assertEqual(self.observe(run_dir, cfg, {1: V1})["archived"], [])
        self.assertEqual(len(read(run_dir / "observations.archive.json")["items"]), 1)

    def test_reuse_after_a_newer_version_came_in(self):
        run_dir, cfg, stand, bundle = self.bundled()
        self.observe(run_dir, cfg, {1: V1})
        shown = self.rebuilt(run_dir, cfg)  # shows v1
        newer = json.loads(json.dumps(shown))
        newer["items"][0].update(dict(V1, conflicts=["后来发现：灯是油灯"]))
        newer["items"][0].pop("seen_before")
        self.assertEqual(self.record(run_dir, cfg, newer)["status"], "OK")  # v2, recorded from the same template
        report = self.reuse_first(run_dir, cfg, shown)
        self.assertEqual(report["status"], "PROBLEMS")
        self.assertIn("was recorded for this image since", report["problems"][0])

    def test_an_archive_from_before_r538(self):
        run_dir, cfg, stand, bundle = self.bundled()
        sha = bundle["items"][0]["sha256"]
        write(run_dir / "observations.archive.json", {"schema": "visual-observation-archive/1", "items": [
            dict(V1, sha256=sha, bundle_id="B-old", n=1, recorded="2026-10-23T10:00:00"),
            dict(V1, sha256=sha, seen="柜台在左，后面一盏油灯", bundle_id="B-old", n=1, recorded="2026-10-23T11:00:00")]})
        template = self.rebuilt(run_dir, cfg)
        self.assertEqual((template["items"][0]["seen_before"]["observation_id"],
                          template["items"][0]["seen_before"]["seen"]), ("O-%s-v2" % sha[:8], "柜台在左，后面一盏油灯"))


# --- 2. rank's cache -----------------------------------------------------------------------------------------------

class ContentModel:
    """A stand-in model that says which bytes it was given: [1, 0] for the target version, [0, 1] for anything else."""

    def __init__(self, target, name="content-probe"):
        self.target, self.name, self.encoded = target, name, []

    def identity(self):
        return self.name

    def images(self, paths):
        common = vm("common")
        out = []
        for p in paths:
            digest = common.sha256_file(p)
            self.encoded.append(digest)
            out.append([1.0, 0.0] if digest == self.target else [0.0, 1.0])
        return out

    def text(self, words):
        return [1.0, 0.0]


class RankCache(Base):
    def collected(self):
        report, run_dir, stand, cfg = self.searched()
        vm("collect").run_collect(run_dir, cfg, fetch=stand, crawl=lambda p, c: ([], None))
        common = vm("common")
        first = common.Run(run_dir).candidates()[0]["image"]
        return run_dir, cfg, stand, common.Run(run_dir), first

    def rank(self, run_dir, cfg, model):
        vm("rank").run_rank(run_dir, cfg, text_query="shop", backend=model)
        return read(run_dir / "rank.json")

    def score(self, rank, sha):
        return next((s["text"] for s in rank["scores"] if s["sha256"] == sha), None)

    def test_a_changed_file_is_never_encoded_under_its_name(self):
        # The review's path: the file changed to another picture, rank, collect again, rank again with the same model.
        run_dir, cfg, stand, folder, first = self.collected()
        sha = first["sha256"]
        folder.path(first["file"]).write_bytes(picture("door"))
        rank = self.rank(run_dir, cfg, ContentModel(sha))
        self.assertEqual([x["sha256"] for x in rank["not_ranked"]], [sha])
        self.assertNotIn(sha, rank["order"])
        self.assertNotIn(sha, read(run_dir / rank["cache"])["images"])  # nothing cached under its name
        vm("collect").run_collect(run_dir, cfg, fetch=stand, crawl=lambda p, c: ([], None))
        model = ContentModel(sha)
        rank = self.rank(run_dir, cfg, model)
        self.assertEqual(model.encoded, [sha])  # encoded now, from the right bytes
        self.assertEqual(self.score(rank, sha), 1.0)

    def test_a_file_changed_after_its_vector_was_cached(self):
        run_dir, cfg, stand, folder, first = self.collected()
        sha = first["sha256"]
        self.rank(run_dir, cfg, ContentModel(sha))
        right = folder.path(first["file"]).read_bytes()
        folder.path(first["file"]).write_bytes(picture("door"))
        model = ContentModel(sha)
        rank = self.rank(run_dir, cfg, model)
        self.assertEqual(([x["sha256"] for x in rank["not_ranked"]], self.score(rank, sha)), ([sha], None))
        folder.path(first["file"]).write_bytes(right)
        rank = self.rank(run_dir, cfg, model)
        self.assertEqual((self.score(rank, sha), model.encoded), (1.0, []))  # the cached vector is of these bytes

    def test_no_file_left_to_rank(self):
        run_dir, cfg, stand, folder, first = self.collected()
        for c in folder.candidates():
            if c.get("image"):
                folder.path(c["image"]["file"]).write_bytes(b"changed: not the version the run recorded")
        model = ContentModel(first["sha256"])
        report = vm("rank").run_rank(run_dir, cfg, text_query="shop", backend=model)
        self.assertEqual((report["status"], report["clip_used"], model.encoded), ("files_changed", False, []))
        self.assertEqual(read(run_dir / "rank.json")["recommend"], [])
        cli = load(SCRIPTS / "visual_materials_cli.py", "r538_cli")
        with mock.patch.object(cli.rank, "run_rank", return_value=report):
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(cli.main(["rank", "--run", str(run_dir)]), 1)  # a step that could not do its job

    def test_a_vector_is_made_only_from_the_bytes_checked(self):
        run_dir, cfg, stand, folder, first = self.collected()
        rank, model = vm("rank"), ContentModel(first["sha256"])
        self.assertEqual(rank.encode_checked(folder, model, [dict(first, sha256="0" * 64)]), {})
        self.assertEqual(model.encoded, [])  # the model is never given bytes that are not the version named
        vectors = rank.encode_checked(folder, model, [first])
        self.assertEqual((list(vectors), model.encoded), ([first["sha256"]], [first["sha256"]]))

    def test_a_cache_from_before_r538_is_not_read(self):
        run_dir, cfg, stand, folder, first = self.collected()
        sha = first["sha256"]
        common = vm("common")
        old = "cache/openclip-%s.json" % common.sha256_bytes(b"content-probe")[:16]
        write(run_dir / old, {"identity": "content-probe", "images": {sha: [0.0, 1.0]}})  # a vector of other bytes
        rank = self.rank(run_dir, cfg, ContentModel(sha))
        self.assertEqual(self.score(rank, sha), 1.0)
        self.assertEqual(rank["older_cache_not_used"], [Path(old).name])


# --- 2. joint speech across a comma --------------------------------------------------------------------------------

NAMES = ["宋青", "林满", "程棠"]
JOINT = [  # (line, the one speaker, or None when no single person may be named)
    ("宋青看了林满一眼，两人齐声说：“先别碰。”", None), ("宋青看了林满一眼，二人齐声说：“先别碰。”", None),
    ("宋青、林满站在门口，齐声说：“先别碰。”", None), ("宋青、林满、程棠站在门口，齐声说：“先别碰。”", None),
    ("宋青看向林满，两个人同时喊：“快跑！”", None), ("宋青看了林满一眼，二人同时开口：“先别碰。”", None),
    ("宋青、林满两人对视一眼，一同说：“先别碰。”", None), ("宋青、林满站在门口：“先别碰。”", None),
    ("宋青和林满看着程棠，齐声说：“先别碰。”", None), ("宋青看了林满一眼，他们齐声说：“先别碰。”", None),
    ("宋青看了林满一眼，众人齐声说：“先别碰。”", None),
    # what stays as it was
    ("宋青放下杯子，回头说：“先别碰。”", "宋青"), ("宋青放下杯子，同时说：“先别碰。”", "宋青"),
    ("宋青看了林满一眼，笑着说：“先别碰。”", "宋青"), ("宋青比林满先说道：“先别碰。”", "宋青"),
    ("宋青叮嘱林满说：“先别碰。”", "宋青"), ("宋青听见林满说：“先别碰。”", "林满"), ("宋青对林满和程棠说：“先别碰。”", "宋青"),
]


class JointSpeech(unittest.TestCase):
    def test_a_group_is_never_one_person(self):
        dl = load(SCRIPTS / "dialogue_lines.py", "r538_dl")
        for text, speaker in JOINT:
            with self.subTest(text=text):
                report = dl.inspect(text, "blank", NAMES, None)
                lines = [x for items in report["speakers"].values() for x in items] + report["unattributed"]
                self.assertEqual(lines[0]["speaker"], speaker, lines[0])
        for text, candidates in (("宋青看了林满一眼，两人齐声说：“先别碰。”", ["宋青", "林满"]),  # who may be in the group
                                 ("宋青、林满、程棠站在门口，齐声说：“先别碰。”", ["宋青", "林满", "程棠"]),
                                 ("宋青、林满、程棠站在门口：“先别碰。”", ["宋青", "林满", "程棠"]),  # the whole chain
                                 ("宋青和林满看着程棠，齐声说：“先别碰。”", ["宋青", "林满"])):  # not the one looked at
            with self.subTest(text=text):
                report = dl.inspect(text, "blank", NAMES, None)
                self.assertEqual(report["unattributed"][0]["candidates"], candidates)


# --- 3. operation ids in the library's history ---------------------------------------------------------------------

class OperationIds(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.w = load(WRITE, "r538_ops")

    def tearDown(self):
        self.tmp.cleanup()

    def v1(self):
        path = self.root / "library.json"
        path.write_bytes(self.w.dumps({"schema": "inspiration-library/1", "book": "测试", "entries": []}))
        return path

    def test_the_same_original_restored_twice(self):
        # The review's path: migrate, restore the original, migrate, restore it again with the log failing, migrate.
        w, path = self.w, self.v1()
        w.migrate(path, replace=True)
        backup = next(w.history_dir(path).glob("v1-original-*.json"))
        w.restore(path, 1, backup=backup)
        w.migrate(path, replace=True)
        with mock.patch.object(w, "log", side_effect=OSError("injected")):
            with self.assertRaises(w.CommittedIncomplete) as caught:
                w.restore(path, 1, backup=backup)
        self.assertTrue(caught.exception.operation_id)
        report = w.migrate(path, replace=True)
        self.assertEqual((report["finished_pending"]["pending"], report["finished_pending"]["operation_id"]),
                         ("finished", caught.exception.operation_id))
        log = w.history(path)
        self.assertEqual([r["action"] for r in log], ["migrate", "restore", "migrate", "restore", "migrate"])
        self.assertTrue(log[3]["finished_later"])
        self.assertEqual(len({r["operation_id"] for r in log}), 5)

    def test_a_line_is_never_logged_twice(self):
        w, path = self.w, self.v1()
        w.migrate(path, replace=True)
        real = os.remove

        def keep_the_note(target):
            if str(target).endswith(w.PENDING):
                raise OSError("injected: the note stays")
            real(target)

        backup = next(w.history_dir(path).glob("v1-original-*.json"))
        with mock.patch.object(w.os, "remove", side_effect=keep_the_note):
            with self.assertRaises(w.CommittedIncomplete) as caught:
                w.restore(path, 1, backup=backup)  # the log line was written; removing the note failed
        w.migrate(path, replace=True)
        ids = [r["operation_id"] for r in w.history(path)]
        self.assertEqual(ids.count(caught.exception.operation_id), 1)

    def test_a_note_from_before_r538(self):
        w, path = self.w, self.v1()
        w.migrate(path, replace=True)
        backup = next(w.history_dir(path).glob("v1-original-*.json"))
        w.restore(path, 1, backup=backup)
        digest = w.sha(path.read_bytes())
        record = {"action": "restore", "from_revision": 1, "to_revision": None, "restored": backup.name,
                  "sha256": digest, "kept_before": "before-restore-r0001.json"}
        marker = w.history_dir(path) / w.PENDING
        # Its line is the last one: that write was logged, the note only stayed behind.
        marker.write_bytes(w.dumps({"record": record, "sha256": digest}))
        self.assertEqual(w.finish_pending(path)["pending"], "finished")
        self.assertEqual([r["action"] for r in w.history(path)], ["migrate", "restore"])
        # The last line is another write: this one was never logged.
        w.log(path, {"action": "migrate", "from": "x", "to_revision": 1, "sha256": "0" * 64})
        marker.write_bytes(w.dumps({"record": record, "sha256": digest}))
        w.finish_pending(path)
        self.assertEqual([r["action"] for r in w.history(path)], ["migrate", "restore", "migrate", "restore"])


# --- 3. page words and sources -------------------------------------------------------------------------------------

PAGE1, PAGE2 = "https://pages.example.org/one", "https://pages.example.org/two"
SHARED = "https://images.example.org/shared.png"


class PageContext(Base):
    def prepared(self):
        common = vm("common")
        folder = self.root / "run"
        run_ = common.Run(folder)
        request = {"schema": common.REQUEST_SCHEMA, "chapter": 7, "scene": "S1", "queries": {"searxng": ["铺子"]},
                   "pages": [PAGE2]}
        run_.save("run.json", {"schema": common.RUN_SCHEMA, "request": request, "steps": {}})
        run_.save_candidates([{"cid": "C01", "image_url": SHARED, "thumbnail_url": "", "page_url": PAGE1,
                               "title": "铺子", "page_text": "SEARCH_TEXT", "creator": "", "license": "CC BY 2.0",
                               "license_url": "https://creativecommons.org/licenses/by/2.0/",
                               "found_by": [{"provider": "searxng", "page_url": PAGE1, "license": "CC BY 2.0"}]}])
        body = picture("shop")

        def fetch(url, *args, **kwargs):
            return common.Response(200, {"Content-Type": "image/png"}, body, url, 0)

        def crawler(pages, config):
            return [{"page_url": p, "status": "ok", "images": [{"src": SHARED, "alt": "ONLY_OLD_PAGE_ALT" if p == PAGE1
                                                                else "OTHER_PAGE_ALT", "desc": "OLD_PAGE_DESC",
                                                                "score": 1, "width": 320}]} for p in pages], "stand-in"

        return folder, run_, fetch, crawler

    def test_another_page_with_the_same_image_is_a_source(self):
        folder, run_, fetch, crawler = self.prepared()
        vm("collect").run_collect(folder, r537.config(), fetch=fetch, crawl=crawler)
        found = run_.candidates()[0]["found_by"]
        self.assertEqual([(f["provider"], f["page_url"]) for f in found], [("searxng", PAGE1), ("crawl4ai", PAGE2)])
        self.assertNotIn("license", found[1])  # the other page's sighting does not take the first page's licence

    def test_page_words_not_read_this_time_are_marked(self):
        # The review's path: the first read finds ONLY_OLD_PAGE_ALT; the second read fails, the image is fetched again.
        folder, run_, fetch, crawler = self.prepared()
        cfg = r537.config()
        vm("collect").run_collect(folder, cfg, fetch=fetch, crawl=crawler)
        self.assertEqual(run_.candidates()[0]["on_page"]["alt"], "ONLY_OLD_PAGE_ALT")

        def failing(pages, config):
            return [{"page_url": p, "status": "error", "error": "injected", "images": []} for p in pages], None

        vm("collect").run_collect(folder, cfg, fetch=fetch, crawl=failing)
        candidate = run_.candidates()[0]
        self.assertNotIn("on_page", candidate)
        self.assertEqual(candidate["stale_on_page"]["alt"], "ONLY_OLD_PAGE_ALT")
        self.assertIn("did not read the page (error)", candidate["stale_on_page"]["why"])
        vm("review").run_bundle(folder, cfg)
        text = (folder / "review" / "review.md").read_text(encoding="utf-8")
        self.assertIn("上一次读页时网页上的文字（这次没读到", text)
        self.assertNotIn("- 网页上的文字（不是看图所得）：SEARCH_TEXT ONLY_OLD_PAGE_ALT", text)
        bundle = read(folder / "review" / "bundle.json")
        vm("selection").run_select(folder, cfg, write(self.root / "c.json", choice(bundle["bundle_id"], 1, "布局")))
        entry = read(folder / "selection.json")["adopt"][0]["entry"]
        self.assertEqual(entry["page_text"], "SEARCH_TEXT")  # the earlier page words do not go into the library
        vm("collect").run_collect(folder, cfg, fetch=fetch, crawl=crawler)  # read again: current again
        candidate = run_.candidates()[0]
        self.assertEqual((candidate["on_page"]["alt"], "stale_on_page" in candidate), ("ONLY_OLD_PAGE_ALT", False))


# --- 4. one ordinary flow, offline ---------------------------------------------------------------------------------

class OrdinaryFlow(Base):
    def test_from_a_feeling_to_the_next_chapter(self):
        # A feeling ("我喜欢这间铺子的拥挤和那盏暖灯，但说不出来") becomes a request with a few words; stand-ins answer.
        feeling = dict(REQUEST, purpose="作者说：喜欢这间铺子的拥挤和那盏暖灯")
        report, run_dir, stand, cfg = self.searched(request=feeling)
        vm("collect").run_collect(run_dir, cfg, fetch=stand, crawl=lambda p, c: ([], None))
        vm("rank").run_rank(run_dir, cfg, backend=FakeModel())
        vm("review").run_bundle(run_dir, cfg)
        bundle = read(run_dir / "review" / "bundle.json")
        self.observe(run_dir, cfg, {1: dict(SEEN, seen="柜台在下方，墙上一排竖着的亮条")})
        library = empty_library(self.root / "library.json")
        self.select(run_dir, cfg, choice(bundle["bundle_id"], 1, "布局：柜台在下方", words="要 1 的布局"))
        self.assertEqual(self.adopt(run_dir, library, 0)["status"], "OK")
        self.select(run_dir, cfg, choice(bundle["bundle_id"], 1, "灯光：墙上一排竖着的亮条", mode="add",
                                         words="1 的灯光也要"))
        self.assertEqual(self.adopt(run_dir, library, 1)["status"], "OK")
        self.assertTrue(self.verify(run_dir)["chain"]["complete"])
        sha = bundle["items"][0]["sha256"]
        later = self.root / "run-ch8"
        vm("search").run_search(dict(feeling, chapter=8, scene="S1"), cfg, later, fetch=stand)
        vm("collect").run_collect(later, cfg, fetch=stand, crawl=lambda p, c: ([], None))
        vm("review").run_bundle(later, cfg)
        again = read(later / "review" / "bundle.json")
        n = next(i["n"] for i in again["items"] if i["sha256"] == sha)
        vm("selection").run_select(later, cfg, write(self.root / "c8.json", choice(again["bundle_id"], n, mode="use",
                                                                                   words="第八章也用这间铺子")))
        self.assertEqual(self.adopt(later, library, 2)["status"], "OK")
        code, card, err = run(READ, "card", library, "--chapter", "8")
        self.assertIn("布局：柜台在下方（稳定）；灯光：墙上一排竖着的亮条（稳定）", card)
        code, report = answer(run(READ, "check", library))
        self.assertEqual(report["problems"], [])
        self.assertEqual([r["action"] for r in answer(run(WRITE, "history", library))[1]["log"]],
                         ["adopt", "adopt", "adopt"])


class TheReferencesSayIt(unittest.TestCase):
    """What can be done and what is refused before writing is said where the author's helper reads it."""

    def test_visual_materials(self):
        text = (SCRIPTS.parent / "references" / "visual-materials.md").read_text(encoding="utf-8")
        for phrase in ("`add` 是在原来借的之外再借这几样", "`replace` 是改成只借这几样", "`use` 是只把它也用到这一章这一场",
                       "没写的，写库时会被拒，什么都不写", "`adopt.json` 是回执", "采用链只在回执对得上现在这份 selection.json",
                       "沿用的就是这一版", "缺了或变了的不算、不排、不推荐", "`stale_on_page`", "那一页记进这张图的 `found_by`",
                       "| 同一张图库里已经挑过，这次没写 `mode` |", "这是撤回，在灵感库里做", "| 排序时图的文件缺了或变了 | `not_ranked` |",
                       "只为某一场借的（`scene`）只出现在那一场的素材块上"):
            self.assertIn(phrase, text)

    def test_inspiration_library(self):
        text = (SCRIPTS.parent / "references" / "inspiration-library.md").read_text(encoding="utf-8")
        for phrase in ("`mode: add`", "`mode: replace`", "`mode: use`", "没写的，什么都不写，报出来请作者说清", "`UNCHANGED`",
                       "`withdraw` 写 `parts`", "`replace` 也不能把它换掉", "不记成 `reject`", "`operation_id`，r5.38",
                       "补日志按编号认", "记着是为哪一场借的（`taken_for`"):
            self.assertIn(phrase, text)


if __name__ == "__main__":
    unittest.main()

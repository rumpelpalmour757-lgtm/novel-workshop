import contextlib
from dataclasses import FrozenInstanceError, replace
import io
import json
from pathlib import Path
import re
import sys
import tempfile
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from genre_profiles import (GENRE_PROFILES, KNOWN_RULE_IDS, PROFILE_MODERN_GRITTY,
    resolve_genre_profile, scene_keyword_hints, resolve_scene_overrides)
from dialogue_core import extract_dialogues
from run_lint import main


def config(genre='modern_gritty'):
    return {'genre_id': genre, 'profiles': {'季宁': {
        'archetype': 'folksy_warm', 'min_avg_len': 6, 'min_colloquial_rate': .3,
        'voice_prompt': '只按已知口吻复核。'}}}


class GenreConfigTests(unittest.TestCase):
    def test_profile_is_immutable_and_override_cannot_mutate_preset(self):
        with self.assertRaises(FrozenInstanceError):
            PROFILE_MODERN_GRITTY.genre_id = 'changed'
        empty = resolve_genre_profile('modern_gritty', {'enabled_rules': []})
        self.assertEqual(empty.enabled_rules, frozenset())
        self.assertEqual(PROFILE_MODERN_GRITTY.enabled_rules, KNOWN_RULE_IDS)
        self.assertEqual(resolve_genre_profile(), None)

    def test_invalid_thresholds_patterns_and_rule_ids_are_rejected(self):
        invalid = [{'max_avg_clause_len': v} for v in (-1, 0, True, float('inf'), float('nan'), '9')]
        invalid += [{'enabled_rules': ['UNKNOWN']}, {'enabled_rules': 'SYN_01_DEGREE_ACT_VERB'},
            {'colloquial_markers': ''}, {'colloquial_markers': '('}, {'colloquial_markers': '.*'},
            {'enable_system_bracket_anchor': 'yes'}, {'unknown': True}]
        for override in invalid:
            with self.subTest(override=override), self.assertRaises(ValueError):
                resolve_genre_profile('modern_gritty', override)
        with self.assertRaises(ValueError):
            resolve_genre_profile('not_a_preset')
        with self.assertRaises(ValueError):
            resolve_genre_profile(None, {'enabled_rules': []})

    def test_markers_are_not_syllables_inside_unrelated_words(self):
        for profile in GENRE_PROFILES.values():
            self.assertFalse(profile.has_colloquial_marker('吧台在那边。'))
            self.assertFalse(profile.has_colloquial_marker('哈密瓜。'))
        self.assertTrue(resolve_genre_profile('western_fantasy').has_colloquial_marker('见鬼。'))
        self.assertFalse(resolve_genre_profile('modern_gritty').has_colloquial_marker('见鬼。'))

    def test_keywords_are_hints_only_and_scene_override_requires_exact_quote(self):
        paras=['季宁说：“耳麦放这里。”季宁说：“在门后头。”']
        dialogues=extract_dialogues(paras, ('季宁',))
        hints=scene_keyword_hints(paras, PROFILE_MODERN_GRITTY)
        self.assertEqual(len(hints),1)
        self.assertFalse(hints[0]['automatic_exemption'])
        record={'para_index':1,'quote_index':2,'quote':'在门后头。','mode':'tactical','reason':'作者确认是电台通话。','exempt_rule_ids':['COMP_04_COORDINATE_REPLY']}
        exempt, applied=resolve_scene_overrides(dialogues,[record])
        self.assertEqual(exempt, {'p1:q2':frozenset({'COMP_04_COORDINATE_REPLY'})})
        self.assertEqual(len(applied),1)
        for changed in ({**record,'quote':'旧稿。'}, {**record,'reason':''}, {**record,'mode':'auto'}):
            with self.subTest(record=changed), self.assertRaises(ValueError):
                resolve_scene_overrides(dialogues,[changed])


class GenreCLITests(unittest.TestCase):
    def scan(self, text, settings, *extra):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory); source=root/'source.txt'; cfg=root/'config.json'; report=root/'report.json'
            source.write_text(text,encoding='utf-8'); cfg.write_text(json.dumps(settings,ensure_ascii=False),encoding='utf-8')
            with contextlib.redirect_stdout(io.StringIO()),contextlib.redirect_stderr(io.StringIO()):
                result=main(['scan',str(source),'--config',str(cfg),'--style-hints','--output',str(report),*extra])
            return result, json.loads(report.read_text(encoding='utf-8')) if report.exists() else None

    def test_preset_changes_actual_rule_execution(self):
        _, modern=self.scan('季宁说：“在门后头。”',config())
        self.assertIsNotNone(modern)
        self.assertIn('COMP_04_COORDINATE_REPLY',[i['rule_id'] for i in modern['antipattern_issues']])
        result, classical=self.scan('季宁说：“在门后头。”',config('classical_xianxia'))
        self.assertEqual(result,0)
        self.assertEqual(classical['antipattern_issues'],[])
        self.assertEqual(classical['genre_profile']['genre_id'],'classical_xianxia')

    def test_empty_rules_disables_both_copies_of_the_candidate(self):
        cfg=config(); cfg['genre_overrides']={'enabled_rules':[]}
        result, data=self.scan('季宁说：“挺挡咬。”',cfg)
        self.assertEqual(result,0)
        self.assertEqual(data['voice_issues'],[])
        self.assertEqual(data['antipattern_issues'],[])

    def test_keyword_cannot_waive_other_quotations(self):
        text='季宁看了眼耳麦，说：“在门后头。”季宁说：“在门后头。”'
        cfg=config()
        result, data=self.scan(text,cfg)
        self.assertEqual(result,0)
        self.assertEqual(len(data['antipattern_issues']),2)
        cfg['scene_overrides']=[{'para_index':1,'quote_index':1,'quote':'在门后头。','mode':'tactical','reason':'仅第一句为作者确认的通话。','exempt_rule_ids':['COMP_04_COORDINATE_REPLY']}]
        result,data=self.scan(text,cfg)
        self.assertEqual(result,0)
        self.assertEqual([i['quote_id'] for i in data['antipattern_issues']],['p1:q2'])

    def test_genre_alone_does_not_enable_system(self):
        result,data=self.scan('【收束】。',config())
        self.assertEqual(result,0)
        self.assertEqual(data['system_bracket_issues'],[])

    def test_book_can_enable_anchor_checks_in_classical_preset(self):
        cfg=config('classical_xianxia')
        cfg['system_brackets']={'enabled':True,'check_anchors':True,'active_tags':['收束'],
            'anchor_pattern':'柄端微震。','forbid_outer_punctuation':True}
        result,data=self.scan('【收束】。',cfg)
        self.assertEqual(result,1)
        self.assertTrue(any(i['severity']=='ERROR' for i in data['system_bracket_issues']))

    def test_cli_choice_overrides_book_default(self):
        result,data=self.scan('季宁说：“在门后头。”',config('modern_gritty'),'--genre','classical_xianxia')
        self.assertEqual(result,0)
        self.assertEqual(data['genre_profile']['genre_id'],'classical_xianxia')
        self.assertEqual(data['antipattern_issues'],[])


if __name__=='__main__':
    unittest.main()

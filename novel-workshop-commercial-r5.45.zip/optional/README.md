# 可选开发扩展：TypeSafe／Jev

这个目录供开发小说辅助工具的人使用。`typesafe-ai` 提供结构化判断、提取、排序等工作流的开发指导，不负责生成小说正文。

普通创作只需主包里的小说写作工坊。只有需要开发这些功能时，才把 `typesafe-ai` 目录导入目标环境，或在根目录运行安装器并加 `--include-dev`。

真正接入时，需要依据 TypeSafe 当前文档确认服务可用性、账户、接口与费用；本包没有密钥、API 额度或已开通的服务。安装不会调用 API 或安装 SDK。

技能入口：[SKILL.md](typesafe-ai/SKILL.md)。许可证：[LICENSE](typesafe-ai/LICENSE)。

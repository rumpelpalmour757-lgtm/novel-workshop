#!/usr/bin/env python3
"""r5.59: the workshop's builtin page reader (scripts/visual_materials/static_reader.py) and page_reader (the author's
decisions of 2026-11-19 on the visual chain, item 7).

The pages here are made up for these tests and served by a stand-in network (an injected fetch) or by a temporary
HTTP server on 127.0.0.1; Crawl4AI is a stand-in module. Nothing here shows how the reader does on real websites, how
many credits it misses or misreads, or what the real Crawl4AI does. Waiting is counted on a virtual clock; decoding is
a stand-in (Pillow is not needed), so the whole file runs on Python 3.9 except the two cases with the stand-in
Crawl4AI, which the workshop only runs on 3.10 or newer. Pinned:

1. what the reader takes from the HTML: img src, srcset (an address with a comma stays whole; the widest, else the
   highest density), data-src, data-original, data-srcset, picture/source (jpeg, png and untyped sources before webp
   or avif), <base href>; data: and javascript: addresses dropped and counted; a noscript copy is the same image, a
   placeholder src that many images share does not make them one; hidden images (display:none, visibility:hidden,
   hidden, aria-hidden, template) are not listed, only counted; zero-width characters are removed; images that only a
   script would add, or that sit in a title or textarea, are not seen, and the scripts not run are counted;
2. what the page says: the figcaption, the credit or caption right after an image (never text before it, never past
   the next image), licence links, the page's rel=license and the JSON-LD ImageObject fields of that image; collect
   keeps them in on_page.page_says with checked: false, and the candidate's creator and licence stay empty; an
   image's desc is its caption only (a credit apart from it stays in page_says, r5.59 after the review);
3. every page request goes through the run's Session: robots.txt first (a page it does not allow is never asked), the
   host's turn (Crawl-delay), refusals (403, 429, a check page) stop the host, a page that is not 200 or not HTML is
   not read, too large is too large; on a local server the page request carries the workshop's user agent and no
   referer or cookie, and a redirect to another program on this machine is not followed, nor an image on it written
   another way (%31%32%37.0.0.1); the reader still works after html.parser was imported again;
4. page_reader: auto (the default) reads with the builtin reader when Crawl4AI cannot run and when its browser does
   not start, and with Crawl4AI when it runs; crawl4ai never falls back; builtin never uses Crawl4AI; a page Crawl4AI
   read and the site refused is not read again by the builtin reader; the record says builtin, never crawl4ai, and
   verify-run lists it on a line of its own outside the five, also when the run's fetch was the real network; the
   config takes only auto, crawl4ai and builtin;
5. doctor says who reads the pages and why; the documents say when the builtin reader is used and what it cannot read;
   the reader imports nothing outside the standard library and parses as Python 3.9.
"""
import ast
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


hygiene = load(HERE / "test_r559_collect_hygiene.py", "r559_reader_hygiene")
vm, config, Net, response = hygiene.vm, hygiene.config, hygiene.Net, hygiene.response
image, robots, session, candidate, run_folder, read, write = (hygiene.image, hygiene.robots, hygiene.session,
                                                              hygiene.candidate, hygiene.run_folder, hygiene.read,
                                                              hygiene.write)
SKILL, SCRIPTS, UA = hygiene.SKILL, hygiene.SCRIPTS, hygiene.UA

SITE = "https://dock.example.org"
GALLERY_URL = SITE + "/gallery.html"
GALLERY = """<!doctype html>
<html lang="zh"><head><meta charset="utf-8"><title>河边旧码头 <img src="/img/in-title.jpg"></title>
<link rel="license" href="https://creativecommons.org/licenses/by/4.0/">
<script type="application/ld+json">{"@context": "https://schema.org", "@type": "ImageObject",
 "contentUrl": "https://dock.example.org/img/crane.png", "creator": {"@type": "Person", "name": "某摄影者"},
 "creditText": "某摄影者 / 码头档案", "license": "https://creativecommons.org/licenses/by-nc/4.0/"}</script>
<script>document.write('<img src="/img/by-script.jpg">');</script>
</head><body>
<header><img src="/static/logo.png" alt="站标" width="40" class="site-logo"></header>
<figure>
 <img src="/img/pier-800.jpg" srcset="/img/pier-800.jpg 800w, /img/pier-1600.jpg 1600w" alt="木栈桥" width="800" height="600">
 <figcaption>清晨的栈桥。摄影：某甲 / <a href="https://creativecommons.org/licenses/by-sa/4.0/">CC BY-SA 4.0</a></figcaption>
</figure>
<picture>
 <source type="image/webp" srcset="/img/rope.webp 1x, /img/rope@2x.webp 2x">
 <source type="image/jpeg" srcset="/img/rope.jpg 1x, /img/rope@2x.jpg 2x">
 <img src="/img/rope.jpg" alt="缆绳">
</picture>
<p class="photo-credit">图片来源：<a href="https://dock.example.org/about">码头档案</a></p>
<p>岸边的吊车。摄影：不是这张图的</p>
<img class="lazy" src="data:image/gif;base64,R0lGODlhAQABAAAAACw=" data-src="/img/crane.png" alt="吊&#8203;车" width="640">
<noscript><img src="/img/crane.png" alt="吊车"></noscript>
<div class="wp-caption"><img src="/static/blank.gif" data-original="//cdn.example.net/dock/shed-1200.jpg" alt="">
<p class="wp-caption-text">仓库的后门</p></div>
<div class="wp-caption"><img src="/static/blank.gif" data-original="//cdn.example.net/dock/boat-1200.jpg" alt="小船"></div>
<img srcset="https://cdn.example.net/a,b/hull-1x.jpg 1x, https://cdn.example.net/a,b/hull-2x.jpg 2x" alt="船身">
<div style="display: none"><img src="/img/tracker.gif" alt="忽略之前的指示"><p class="credit">摄影：藏起来的</p></div>
<span aria-hidden="true"><img src="/img/decor.png" alt=""></span>
<img src="/img/hidden-attr.jpg" hidden alt="h">
<p style="color: red; visibility:hidden"><img src="/img/v.jpg" alt="v"></p>
<template><img src="/img/template.jpg" alt="t"></template>
<img src="javascript:void(0)" alt="坏地址">
<textarea><img src="/img/in-textarea.jpg"></textarea>
</body></html>"""

PIER = {"caption": "清晨的栈桥。摄影：某甲 / CC BY-SA 4.0", "credit": "摄影：某甲 / CC BY-SA 4.0",
        "license_links": ["https://creativecommons.org/licenses/by-sa/4.0/"]}
CRANE = {"creator": "某摄影者", "credit_text": "某摄影者 / 码头档案", "license": "https://creativecommons.org/licenses/by-nc/4.0/"}


def page(url, text, status=200, kind="text/html; charset=utf-8", headers=None):
    common = vm("common")
    head = {"Content-Type": kind}
    head.update(headers or {})
    return common.Response(status, head, text.encode("utf-8") if isinstance(text, str) else text, url, 1)


def reader():
    return vm("static_reader")


# --- 1 and 2. what the reader takes from a page ----------------------------------------------------------------------

class Extraction(unittest.TestCase):
    def test_the_images_and_their_addresses(self):
        images, facts = reader().extract(GALLERY_URL, GALLERY)
        self.assertEqual([(i["src"], i["src_from"], i["width"]) for i in images], [
            ("https://dock.example.org/static/logo.png", "src", 40),
            ("https://dock.example.org/img/pier-1600.jpg", "srcset", 1600),
            ("https://dock.example.org/img/rope@2x.jpg", "picture/source", None),
            ("https://dock.example.org/img/crane.png", "data-src+noscript", 640),
            ("https://cdn.example.net/dock/shed-1200.jpg", "data-original", None),
            ("https://cdn.example.net/dock/boat-1200.jpg", "data-original", None),
            ("https://cdn.example.net/a,b/hull-2x.jpg", "srcset", None)])
        by = {i["src"].rsplit("/", 1)[1]: i for i in images}
        self.assertIn("https://dock.example.org/img/pier-800.jpg", by["pier-1600.jpg"]["variants"])
        self.assertNotIn("height", by["pier-1600.jpg"])  # 600 was the height of the 800 pixel file
        self.assertIn("https://dock.example.org/img/rope@2x.webp", by["rope@2x.jpg"]["variants"])
        self.assertEqual(by["crane.png"]["alt"], "吊车")  # the zero-width space is gone
        self.assertEqual(facts, {"license_links": ["https://creativecommons.org/licenses/by/4.0/"], "hidden_images": 5,
                                 "dropped_images": 1, "scripts_not_run": 1})
        listed = json.dumps(images, ensure_ascii=False)
        for gone in ("tracker", "decor", "hidden-attr", "/v.jpg", "template", "by-script", "in-title", "in-textarea",
                     "忽略之前的指示", "藏起来的"):
            self.assertNotIn(gone, listed)

    def test_what_the_page_says(self):
        images, _ = reader().extract(GALLERY_URL, GALLERY)
        says = {i["src"].rsplit("/", 1)[1]: i.get("page_says") for i in images}
        self.assertEqual(says["pier-1600.jpg"], PIER)
        self.assertEqual(says["rope@2x.jpg"], {"credit": "图片来源：码头档案"})  # an inline link does not split it
        self.assertEqual(says["crane.png"], {"structured": CRANE})  # the text before it belongs to the rope
        self.assertEqual(says["shed-1200.jpg"], {"caption": "仓库的后门"})
        self.assertIsNone(says["boat-1200.jpg"])
        self.assertIsNone(says["logo.png"])
        desc = {i["src"].rsplit("/", 1)[1]: i["desc"] for i in images}
        # r5.59, after the review: desc is the caption only; a credit apart from the caption stays in page_says
        self.assertEqual((desc["pier-1600.jpg"], desc["rope@2x.jpg"]), (PIER["caption"], ""))

    def test_srcset_densities_formats_and_placeholders(self):
        html = """<base href="https://other.example.org/base/">
        <img srcset="a.jpg, b.jpg 2x, c.jpg 1.5x" alt="x">
        <picture><source type="image/avif" srcset="only.avif 2000w"><img src="fallback.jpg" alt="y"></picture>
        <picture><source type="image/avif" srcset="lone.avif"></picture>
        <picture><source type="image/avif" srcset="last.avif 900w"><img src="data:image/gif;base64,xx"></picture>
        <img src="/lazy.gif" data-src="one.jpg"><img src="/lazy.gif" data-src="two.jpg">
        <img src="data:image/png;base64,xx"><img src="">"""
        images, facts = reader().extract("https://page.example.org/a/b.html", html)
        self.assertEqual([(i["src"], i["src_from"]) for i in images], [
            ("https://other.example.org/base/b.jpg", "srcset"),
            ("https://other.example.org/base/fallback.jpg", "src"),
            ("https://other.example.org/base/last.avif", "picture/source (image/avif)"),
            ("https://other.example.org/base/one.jpg", "data-src"),
            ("https://other.example.org/base/two.jpg", "data-src")])  # one shared placeholder: still two images
        self.assertEqual(facts, {"base": "https://other.example.org/base/", "dropped_images": 2})

    def test_an_image_inside_a_title_is_not_taken_by_any_parser(self):
        # The html.parser of the Pythons here reads <title> and <textarea> as text; an older one hands their tags
        # over, as below. The reader takes no image from them either way.
        parsed = reader()._Page("https://p.example.org/")
        for tag in ("title", "textarea"):
            parsed.handle_starttag(tag, [])
            parsed.handle_starttag("img", [("src", "/in-%s.jpg" % tag)])
            parsed.handle_data("摄影：不是图注")
            parsed.handle_endtag(tag)
        parsed.handle_starttag("img", [("src", "/ok.jpg")])
        parsed.close()
        self.assertEqual([i["src"] for i in parsed.images], ["https://p.example.org/ok.jpg"])
        self.assertEqual(parsed.events, [("img", 0)])

    def test_text_is_cleaned_and_bounded(self):
        static = reader()
        self.assertEqual(static.clean_text("a\u200bb\u200d c\ufeff\u2066d\u2069\x07  e"), "ab cd e")
        self.assertEqual(len(static.clean_text("长" * 500, 200)), 200)
        many = "".join('<img src="/i/%d.jpg">' % n for n in range(static.MAX_IMAGES + 7))
        images, facts = static.extract("https://p.example.org/", many)
        self.assertEqual((len(images), facts["images_not_listed"]), (static.MAX_IMAGES, 7))

    def test_charsets(self):
        static = reader()
        cases = [({"Content-Type": "text/html"}, "<meta charset=gb2312><img src='/a.jpg' alt='码头'>".encode("gb2312"),
                  "gb18030"),
                 ({"Content-Type": "text/html"}, ('<meta http-equiv="Content-Type" content="text/html; charset=GBK">'
                                                  "<img alt='码头' src='/a.jpg'>").encode("gbk"), "gb18030"),
                 ({"Content-Type": "text/html; charset=big5"}, "<img src='/a.jpg' alt='碼頭'>".encode("big5"), "big5"),
                 ({"Content-Type": "text/html; charset=latin-1"}, b"\xef\xbb\xbf" + "<img alt='码头'>".encode("utf-8"),
                  "utf-8")]
        for headers, body, charset in cases:
            with self.subTest(charset=charset, body=body[:20]):
                text, used = static.decode_page(body, headers)
                self.assertEqual(used, charset)
                self.assertIn("码头" if charset != "big5" else "碼頭", text)
        text, used = static.decode_page(b"<p>x</p>", {"Content-Type": "text/html; charset=x-made-up"})
        self.assertIn("does not know", used)

    def test_the_probe_makes_no_request(self):
        self.assertEqual(reader().probe()["status"], "ok")
        self.assertEqual(reader().probe()["requests"], 0)

    def test_after_html_parser_was_imported_again(self):
        # r5.59, after the review: a test that patches sys.modules can leave a second html.parser behind; the reader's
        # parser class was made from the first one. On Python 3.12 and later, HTMLParser.__init__ calls super(), so
        # calling the module's class by name failed there for every page.
        import html
        import importlib
        static = reader()
        saved_module, saved_attribute = sys.modules.pop("html.parser"), getattr(html, "parser", None)
        try:
            fresh = importlib.import_module("html.parser")
            self.assertIsNot(fresh.HTMLParser, static._Page.__mro__[1])
            images, _ = static.extract(GALLERY_URL, GALLERY)
            self.assertEqual(len(images), 7)
        finally:
            sys.modules["html.parser"] = saved_module
            html.parser = saved_attribute


# --- 3. every page request through the run's Session ------------------------------------------------------------------

class ThroughTheSession(hygiene.Temp):
    def test_robots_pacing_and_the_record(self):
        routes = {SITE + "/robots.txt": robots("User-agent: *\nDisallow: /private/\nCrawl-delay: 2\n"),
                  GALLERY_URL: page(GALLERY_URL, GALLERY), SITE + "/second.html": page(SITE + "/second.html", "<p>x</p>"),
                  SITE + "/private/notes.html": page(SITE + "/private/notes.html", GALLERY)}
        net = Net(routes)
        sess, clock = session(config(), net)
        records, version = reader().read_pages([GALLERY_URL, SITE + "/private/notes.html", SITE + "/second.html"],
                                               config(), sess)
        self.assertEqual(version, "builtin-reader/1")
        self.assertEqual([(r["status"], r["reader"]) for r in records],
                         [("ok", "builtin"), ("robots_disallowed", "builtin"), ("no_images", "builtin")])
        self.assertNotIn(SITE + "/private/notes.html", net.asked)
        self.assertEqual(net.count(SITE + "/robots.txt"), 1)
        at = dict(net.times)
        self.assertEqual(at[SITE + "/second.html"] - at[GALLERY_URL], 2.0)  # robots.txt's Crawl-delay
        first = records[0]
        self.assertEqual((first["http_status"], first["charset"], len(first["sha256"])), (200, "utf-8", 64))
        self.assertEqual(first["page_says"], {"license_links": ["https://creativecommons.org/licenses/by/4.0/"]})
        self.assertIn("script", first["note"])
        self.assertEqual([e["kind"] for e in sess.log], ["robots", "page", "page"])

    def test_refusals_and_pages_that_are_not_read(self):
        common = vm("common")
        challenge = "<html><head><title>Just a moment...</title></head><body><img src='/x.jpg'></body></html>"
        cases = {"refused": page(SITE + "/p", "", 403), "rate_limited": page(SITE + "/p", "", 429),
                 "check page": page(SITE + "/p", challenge), "failed": page(SITE + "/p", "<img src='/x.jpg'>", 404),
                 "not_html": page(SITE + "/p", b"%PDF-1.4", kind="application/pdf"),
                 "too_large": common.TooLarge("more than 3000000 bytes"), "timeout": common.Timeout("slow")}
        for name, answer in cases.items():
            with self.subTest(case=name):
                net = Net({SITE + "/p": answer, SITE + "/q": page(SITE + "/q", "<img src='/y.jpg'>")})
                sess, _ = session(config(), net)
                first, second = reader().read_pages([SITE + "/p", SITE + "/q"], config(), sess)[0]
                self.assertEqual(first["status"], "refused" if name == "check page" else name)
                self.assertEqual(first["images"], [])
                stopped = name in ("refused", "rate_limited", "check page")
                self.assertEqual(second["status"], first["status"] if stopped else "ok")
                self.assertEqual(net.count(SITE + "/q"), 0 if stopped else 1)  # nothing more asked of a refusing host
        net = Net({SITE + "/p": [page(SITE + "/p", "", 503), page(SITE + "/p", "<img src='/x.jpg'>")]})
        sess, _ = session(config(network={"retries": 1}), net)
        self.assertEqual(reader().read_page(SITE + "/p", config(), sess)["status"], "ok")  # a 5xx, waited, tried again
        net = Net({SITE + "/p": page(SITE + "/p", "<img src='/x.jpg'>", kind="")})
        sess, _ = session(config(), net)
        self.assertEqual(reader().read_page(SITE + "/p", config(), sess)["status"], "ok")  # no type, but HTML

    def test_the_page_size_limit(self):
        seen = []

        def answer(url, cfg, headers=None, data=None, max_bytes=None, method=None):
            seen.append((url, (headers or {}).get("Accept"), max_bytes))
            return page(url, "<img src='/x.jpg'>") if url.endswith(".html") else response(404, b"", "text/plain")

        cfg = config(network={"max_page_bytes": 12345})
        sess, _ = session(cfg, answer)
        reader().read_page(SITE + "/a.html", cfg, sess)
        self.assertEqual(seen[-1], (SITE + "/a.html", "text/html,application/xhtml+xml", 12345))


class OnALocalServer(hygiene.LocalServerBase):  # the base only: hygiene's own local-server tests run there
    def test_what_the_server_sees_and_a_redirect_not_followed(self):
        self.a.routes.update({
            "/robots.txt": (200, {"Content-Type": "text/plain"}, b"User-agent: *\nAllow: /\n"),
            "/page.html": (200, {"Content-Type": "text/html; charset=utf-8"},
                           ('<figure><img src="/a.png" alt="门" width="400"><figcaption>摄影：某乙</figcaption></figure>'
                            '<img src="http://127.0.0.1:%d/x.png" alt="另一个程序" width="400">'
                            '<img src="http://%%31%%32%%37.0.0.1:%d/secret.png" alt="另一种写法" width="400">'
                            % (self.b.port, self.b.port)).encode("utf-8")),
            "/away.html": hygiene.moved("http://127.0.0.1:%d/page.html" % self.b.port),
            "/a.png": hygiene.PNG_ANSWER})
        folder, run_ = run_folder(self.root, [], pages=[self.a.url("/page.html"), self.a.url("/away.html")])
        sess, _ = self.sess()
        cfg = config(page_reader={"use": "builtin"})
        vm("collect").run_collect(folder, cfg, session=sess)
        record = read(folder / "collect.json")
        by = {p["page_url"]: p for p in record["pages"]}
        self.assertEqual(by[self.a.url("/page.html")]["status"], "ok")
        self.assertEqual(by[self.a.url("/away.html")]["status"], "private_address")
        self.assertEqual(by[self.a.url("/away.html")]["not_asked"], "http://127.0.0.1:%d/page.html" % self.b.port)
        self.assertEqual(self.b.seen, [])  # neither the redirect nor the image on the other program was asked
        pages = [s for s in self.a.seen if s["path"] == "/page.html"]
        self.assertEqual(len(pages), 1)
        for seen in self.a.seen:
            self.assertEqual(seen["headers"]["user-agent"], UA)
            self.assertNotIn("referer", seen["headers"])
            self.assertNotIn("cookie", seen["headers"])
        self.assertEqual(pages[0]["headers"]["accept"], "text/html,application/xhtml+xml")
        self.assertEqual(record["transport"], {"fetch": "http_local_test", "crawl": "builtin"})
        fetched = {f["url"]: f["status"] for f in record["fetched"]}
        self.assertEqual(fetched[self.a.url("/a.png")], "ok")
        self.assertEqual(fetched["http://127.0.0.1:%d/x.png" % self.b.port], "private_address")
        self.assertEqual(fetched["http://%%31%%32%%37.0.0.1:%d/secret.png" % self.b.port], "private_address")
        self.assertFalse(vm("verify").run_verify(folder)["components"]["crawl4ai"]["live_verified"])


# --- 4. page_reader and what collect and verify-run record -------------------------------------------------------------

def gallery_net():
    routes = {SITE + "/robots.txt": robots("User-agent: *\nDisallow: /private/\nCrawl-delay: 2\n"),
              GALLERY_URL: page(GALLERY_URL, GALLERY), SITE + "/private/notes.html": page(SITE + "/private/notes.html",
                                                                                          GALLERY)}
    for path in ("img/pier-800.jpg", "img/rope@2x.jpg", "img/crane.png"):
        routes[SITE + "/" + path] = image(hygiene.PNG + path.encode("ascii"))  # five different files
    for name in ("shed-1200.jpg", "boat-1200.jpg"):
        routes["https://cdn.example.net/dock/" + name] = image(hygiene.PNG + name.encode("ascii"))
    return Net(routes)


def gallery_candidates():
    return [candidate(1, SITE + "/img/pier-800.jpg", GALLERY_URL),
            candidate(2, "https://cdn.example.net/dock/boat-1200.jpg", "https://other.example.net/boats")]


def stand_in_crawl4ai(enter=None, answer=None):
    """A stand-in crawl4ai whose browser does not start (enter) or whose every page answers answer."""
    module = types.ModuleType("crawl4ai")
    module.__version__ = "stand-in"

    class Options:
        def __init__(self, **kwargs):
            pass

    class Crawler:
        def __init__(self, **kwargs):
            pass

        async def __aenter__(self):
            if enter:
                raise enter
            return self

        async def __aexit__(self, *args):
            return False

        async def arun(self, url, config):
            return answer

    module.AsyncWebCrawler, module.BrowserConfig, module.CrawlerRunConfig = Crawler, Options, Options
    module.CacheMode = types.SimpleNamespace(BYPASS=0)
    return module


class Collect(hygiene.Temp):
    def collect_gallery(self, cfg):
        net = gallery_net()
        result, record, run_, clock = self.collect(cfg, net, gallery_candidates(),
                                                   pages=[SITE + "/private/notes.html"], crawl=None)
        return result, record, run_, net

    def test_the_builtin_reader_in_a_collect(self):
        result, record, run_, net = self.collect_gallery(config(page_reader={"use": "builtin"}))
        self.assertEqual(result["reader"], "builtin")
        by = {p["page_url"]: p for p in record["pages"]}
        self.assertEqual((by[GALLERY_URL]["status"], by[SITE + "/private/notes.html"]["status"]),
                         ("ok", "robots_disallowed"))
        self.assertNotIn(SITE + "/private/notes.html", net.asked)
        cands = {c["cid"]: c for c in run_.candidates()}
        self.assertEqual(cands["C01"]["on_page"], {
            "alt": "木栈桥", "desc": PIER["caption"], "score": 6, "page_says": {
                "caption": PIER["caption"], "credit": PIER["credit"], "checked": False,
                "license_links": ["https://creativecommons.org/licenses/by-sa/4.0/",
                                  "https://creativecommons.org/licenses/by/4.0/"]}})
        urls = [c["image_url"] for c in cands.values()]
        self.assertNotIn(SITE + "/img/pier-1600.jpg", urls)  # the larger file of C01 is not a second candidate
        self.assertEqual(urls.count("https://cdn.example.net/dock/boat-1200.jpg"), 1)
        self.assertIn({"provider": "builtin", "page": GALLERY_URL, "page_url": GALLERY_URL, "score": 2},
                      cands["C02"]["found_by"])  # the same image on a page read now: a sighting of its own
        added = [c for c in cands.values() if c["cid"] not in ("C01", "C02")]
        self.assertEqual([c["image_url"] for c in added], [SITE + "/img/rope@2x.jpg",
                                                           "https://cdn.example.net/dock/shed-1200.jpg",
                                                           SITE + "/img/crane.png"])
        for c in added:
            self.assertEqual(c["found_by"][0]["provider"], "builtin")
            self.assertEqual((c["creator"], c["license"], c["license_url"]), ("", "", ""))
        self.assertEqual(cands["C05"]["on_page"]["page_says"]["structured"], CRANE)
        self.assertIs(cands["C05"]["on_page"]["page_says"]["checked"], False)
        self.assertEqual(record["reader"], "builtin")
        self.assertEqual(record["reader_version"], "builtin-reader/1")
        self.assertEqual(record["transport"], {"fetch": "injected", "crawl": "builtin"})
        self.assertNotIn("crawl4ai_version", record)
        self.assertEqual((record["page_reader"]["use"], record["page_reader"]["fallback"]), ("builtin", None))
        self.assertEqual((record["crawl4ai"]["pages_ok"], record["page_reader"]["pages_ok"]), (0, 1))
        self.assertIn("builtin reader", " ".join(record["next"]))
        self.assertEqual({f["cid"]: f["status"] for f in record["fetched"]},
                         {"C01": "ok", "C02": "ok", "C03": "ok", "C04": "ok", "C05": "ok"})
        times = [t for u, t in net.times if u.startswith(SITE)]
        self.assertTrue(all(b - a >= 2.0 for a, b in zip(times[1:], times[2:])), times)  # pages and images alike
        report = vm("verify").run_verify(run_.folder)
        self.assertEqual(sorted(report["components"]), ["crawl4ai", "imagehash", "openclip", "openverse", "searxng"])
        self.assertEqual(report["components"]["crawl4ai"]["missing"], vm("verify").BUILTIN_LINE)
        self.assertEqual(report["builtin_reader"]["line"], "页面是工坊自带的读页读的，不是 Crawl4AI：crawl4ai 这一项不算接通。")
        self.assertEqual((report["builtin_reader"]["counts_toward_five"], report["builtin_reader"]["pages_ok"]),
                         (False, 1))
        vm("review").run_bundle(run_.folder, config(page_reader={"use": "builtin"}))
        text = (run_.folder / "review" / "review.md").read_text(encoding="utf-8")
        self.assertIn("- 网页上写的署名和授权（工坊没有核对，只供你去来源页核）：摄影：某甲 / CC BY-SA 4.0", text)
        self.assertIn("- 谁找到的：builtin（工坊自带的读页）、searxng", text)

    def test_the_builtin_reader_on_the_real_network_is_not_crawl4ai(self):
        # r5.59, after the review: verify-run's "the builtin reader is not Crawl4AI" must hold for a run whose fetch
        # was the real network too, not only for a test's stand-in fetch.
        result, record, run_, net = self.collect_gallery(config(page_reader={"use": "builtin"}))
        data = read(run_.folder / "collect.json")
        data["transport"]["fetch"] = "http"
        write(run_.folder / "collect.json", data)
        report = vm("verify").run_verify(run_.folder)
        crawl = report["components"]["crawl4ai"]
        self.assertEqual((crawl["ran"], crawl["live_verified"], crawl["missing"]),
                         (False, False, vm("verify").BUILTIN_LINE))
        self.assertEqual(report["builtin_reader"]["pages_ok_on_the_open_web"], 1)

    def test_auto_without_crawl4ai_reads_with_the_builtin_reader(self):
        collect = vm("collect")
        with mock.patch.object(collect, "crawl4ai_status", lambda: (False, "Crawl4AI is not installed (stand-in)", None)):
            result, record, run_, net = self.collect_gallery(config())
        self.assertEqual((record["reader"], record["page_reader"]["use"]), ("builtin", "auto"))
        self.assertIn("auto and Crawl4AI cannot run here", record["page_reader"]["why"])
        self.assertEqual({p["page_url"]: p["status"] for p in record["pages"]}[GALLERY_URL], "ok")
        self.assertIn(GALLERY_URL, net.asked)

    def test_crawl4ai_only_never_falls_back(self):
        collect = vm("collect")
        with mock.patch.object(collect, "crawl4ai_status", lambda: (False, "Crawl4AI is not installed (stand-in)", None)):
            result, record, run_, net = self.collect_gallery(config(page_reader={"use": "crawl4ai"}))
        self.assertEqual(record["reader"], "crawl4ai")
        by = {p["page_url"]: p for p in record["pages"]}
        self.assertEqual(by[GALLERY_URL]["status"], "not_installed")
        self.assertNotIn(GALLERY_URL, net.asked)
        self.assertIn("no page is read, and the builtin reader is not used", record["page_reader"]["why"])
        self.assertEqual(len(run_.candidates()), 2)

    def test_choose_reader(self):
        collect = vm("collect")
        for status, use, reader in (((True, "crawl4ai 9", "9"), "auto", "crawl4ai"),
                                    ((False, "no", None), "auto", "builtin"),
                                    ((True, "crawl4ai 9", "9"), "builtin", "builtin"),
                                    ((False, "no", None), "crawl4ai", "crawl4ai")):
            with self.subTest(status=status[0], use=use):
                with mock.patch.object(collect, "crawl4ai_status", lambda: status):
                    self.assertEqual(collect.choose_reader(config(page_reader={"use": use}))[0], reader)

    @unittest.skipIf(sys.version_info < (3, 10), "the workshop only runs Crawl4AI on Python 3.10 or newer")
    def test_auto_falls_back_when_the_browser_does_not_start(self):
        module = stand_in_crawl4ai(enter=RuntimeError("BrowserType.launch: executable doesn't exist"))
        with mock.patch.dict(sys.modules, {"crawl4ai": module}):
            result, record, run_, net = self.collect_gallery(config())
        fallback = record["page_reader"]["fallback"]
        self.assertEqual((fallback["from"], fallback["to"], fallback["pages"], fallback["crawl4ai_version"]),
                         ("crawl4ai", "builtin", 2, "stand-in"))  # the gallery and the page of C02
        self.assertIn("did not start", fallback["why"])
        self.assertEqual((record["reader"], record["transport"]["crawl"]), ("builtin", "builtin"))
        self.assertEqual((record["crawl4ai"]["importable"], record["crawl4ai"]["browser_started"]), (True, False))
        self.assertEqual({p["page_url"]: p["status"] for p in record["pages"]}[GALLERY_URL], "ok")
        self.assertIn("crawl4ai-setup", " ".join(record["next"]))
        self.assertNotIn("crawl4ai_version", record)
        self.assertEqual(result["browser_started"], False)
        with mock.patch.dict(sys.modules, {"crawl4ai": module}):  # crawl4ai only: the pages stay browser_failed
            self.tearDown()
            self.setUp()
            result, record, run_, net = self.collect_gallery(config(page_reader={"use": "crawl4ai"}))
        self.assertEqual({p["page_url"]: p["status"] for p in record["pages"]}[GALLERY_URL], "browser_failed")
        self.assertNotIn(GALLERY_URL, net.asked)

    @unittest.skipIf(sys.version_info < (3, 10), "the workshop only runs Crawl4AI on Python 3.10 or newer")
    def test_auto_uses_crawl4ai_and_a_refusal_is_not_tried_again_with_the_builtin_reader(self):
        found = types.SimpleNamespace(status_code=200, success=True, html="<html></html>", media={"images": [
            {"src": SITE + "/img/new.jpg", "alt": "新", "desc": "", "score": 4, "width": 400}]})
        with mock.patch.dict(sys.modules, {"crawl4ai": stand_in_crawl4ai(answer=found)}):
            result, record, run_, net = self.collect_gallery(config())
        self.assertEqual((record["reader"], record["crawl4ai_version"], record["page_reader"]["fallback"]),
                         ("crawl4ai", "stand-in", None))
        added = [c for c in run_.candidates() if c["image_url"] == SITE + "/img/new.jpg"]
        self.assertEqual(added[0]["found_by"][0]["provider"], "crawl4ai")
        self.assertNotIn(GALLERY_URL, net.asked)  # Crawl4AI read it, the builtin reader did not
        refused = types.SimpleNamespace(status_code=403, success=True, html="<html>no</html>", media={"images": []})
        self.tearDown()
        self.setUp()
        with mock.patch.dict(sys.modules, {"crawl4ai": stand_in_crawl4ai(answer=refused)}):
            result, record, run_, net = self.collect_gallery(config())
        self.assertEqual({p["page_url"]: p["status"] for p in record["pages"]}[GALLERY_URL], "refused")
        self.assertEqual((record["reader"], record["page_reader"]["fallback"]), ("crawl4ai", None))
        self.assertFalse([u for u in net.asked if u.startswith(SITE) and not u.endswith("/robots.txt")])


class Config(hygiene.Temp):
    def test_page_reader_in_the_config(self):
        common = vm("common")
        self.assertEqual((config()["page_reader"], config()["network"]["max_page_bytes"]), ({"use": "auto"}, 3000000))
        for use in ("auto", "crawl4ai", "builtin"):
            self.assertEqual(config(page_reader={"use": use})["page_reader"]["use"], use)
        refused = {"page_reader.use is one of auto, crawl4ai, builtin": [{"page_reader": {"use": "chrome"}},
                                                                        {"page_reader": {"use": ""}}],
                   "config section page_reader is an object": [{"page_reader": "builtin"}],
                   "unknown key(s) in config section page_reader": [{"page_reader": {"use": "auto", "browser": "x"}}],
                   "工坊不做这件事": [{"page_reader": {"proxy": "http://p:1"}}],
                   "network.max_page_bytes": [{"network": {"max_page_bytes": 0}}, {"network": {"max_page_bytes": 1.5}}]}
        for words, configs in refused.items():
            for data in configs:
                with self.subTest(config=data):
                    path = write(self.root / "c.json", dict({"schema": common.CONFIG_SCHEMA}, **data))
                    with self.assertRaises(common.VisualError) as caught:
                        common.load_config(path)
                    self.assertIn(words, str(caught.exception))
        example = json.loads((SKILL / "assets" / "visual-materials-config.example.json").read_text(encoding="utf-8"))
        self.assertEqual((example["page_reader"], example["network"]["max_page_bytes"]), ({"use": "auto"}, 3000000))
        self.assertIn("page_reader.use", example["note"])


# --- 5. doctor, the documents, the standard library ------------------------------------------------------------------

class Doctor(unittest.TestCase):
    def run_doctor(self, cfg, ok, probe=False, crawl4ai_probe=None):
        doctor, collect = vm("doctor"), vm("collect")
        status = (True, "crawl4ai stand-in", "stand-in") if ok else (False, "Crawl4AI is not installed (stand-in)", None)
        with mock.patch.object(doctor, "crawl4ai_status", lambda: status), \
                mock.patch.object(collect, "crawl4ai_status", lambda: status), \
                mock.patch.object(doctor, "probe_crawl4ai", lambda c: dict(crawl4ai_probe or {"status": "ok",
                                                                                                "browser_started": True})):
            return doctor.run_doctor(cfg, probe=probe, fetch=Net({}))  # a probe never reaches the network here

    def test_doctor_says_who_reads_the_pages_and_why(self):
        cases = [(config(), False, "builtin", "读来源页用工坊自带的读页（page_reader.use 是 auto，这台机器上 Crawl4AI 用不了"),
                 (config(page_reader={"use": "builtin"}), True, "builtin", "page_reader.use 写的是 builtin"),
                 (config(), True, "crawl4ai", "读来源页用 crawl4ai（page_reader.use 是 auto；浏览器起不来时 collect 改用自带读页）"),
                 (config(page_reader={"use": "crawl4ai"}), False, "crawl4ai", "collect 不读来源页，也不改用自带读页")]
        for cfg, ok, reader_name, words in cases:
            with self.subTest(use=cfg["page_reader"]["use"], crawl4ai=ok):
                report = self.run_doctor(cfg, ok)
                self.assertEqual(report["page_reader"]["reader"], reader_name)
                self.assertTrue(report["page_reader"]["why"].startswith("page_reader.use is"))
                self.assertIn(words, report["summary"])
                self.assertEqual(sorted(report["components"]), ["crawl4ai", "imagehash", "openclip", "openverse",
                                                                "searxng"])  # the reader is not a sixth component

    def test_with_probe(self):
        report = self.run_doctor(config(), True, probe=True, crawl4ai_probe={
            "status": "browser_failed", "browser_started": False, "error": "the browser did not start: stand-in"})
        self.assertEqual(report["page_reader"]["reader"], "builtin")
        self.assertIn("did not start in the probe", report["page_reader"]["why"])
        self.assertIn("Crawl4AI 的浏览器起不来", report["summary"])
        self.assertEqual((report["page_reader"]["probe"]["status"], report["page_reader"]["probe"]["requests"]),
                         ("ok", 0))
        report = self.run_doctor(config(page_reader={"use": "crawl4ai"}), True, probe=True)
        self.assertNotIn("probe", report["page_reader"])
        # r5.59, after the review: page_reader.use crawl4ai and the browser did not start in the probe: say so
        report = self.run_doctor(config(page_reader={"use": "crawl4ai"}), True, probe=True, crawl4ai_probe={
            "status": "browser_failed", "browser_started": False, "error": "the browser did not start: stand-in"})
        self.assertIn("Crawl4AI 的浏览器在 probe 里起不来，collect 读不了来源页", report["summary"])
        self.assertNotIn("读来源页用 crawl4ai", report["summary"])


class Documents(unittest.TestCase):
    def test_visual_materials(self):
        text = (SKILL / "references" / "visual-materials.md").read_text(encoding="utf-8")
        for phrase in ("`page_reader.use`：谁读来源页。`auto`（默认）：Crawl4AI 能用就用它，用不了（没装、Python 低于 3.10、浏览器起不来）就用工坊自带的读页",
                       "`crawl4ai`：只用 Crawl4AI，用不了就不读来源页，也不改用自带读页",
                       "自带读页只用 Python 标准库，用工坊的普通请求取网页的 HTML，不开浏览器，不跑页面脚本：靠脚本才显示的图读不到",
                       "`scripts_not_run`", "`hidden_images`", "网页文字里的零宽字符记录前去掉",
                       "两种读页都先问 robots.txt，不许的页面不打开", "记在 `on_page.page_says`，标明未核，不当作授权",
                       vm("verify").BUILTIN_LINE, "（工坊自带的读页读的不算）",
                       "工坊本身 Python 3.9 就能用；读来源页这一步要 3.10 以上才能用 Crawl4AI（还要装好它和它的浏览器），自带读页不受这个限制",
                       "| 自带读页读的页面上，图要靠脚本才显示 | 页面 `no_images`，记 `scripts_not_run` |",
                       "| 来源页地址回的不是网页（PDF、图片等），或者一页太大 | 页面 `not_html` / `too_large` |",
                       "自带读页只在本机合成的网页和本机临时服务上测过，没在真实网站上跑过"):
            self.assertIn(phrase, text)
        self.assertNotIn("不满足时 collect 只取搜索给的图，页面记 `not_installed`。Crawl4AI 装了但浏览器起不来", text)


class StandardLibrary(unittest.TestCase):
    def test_the_reader_uses_the_standard_library_and_parses_as_python_39(self):
        folder = SCRIPTS / "visual_materials"
        source = (folder / "static_reader.py").read_text(encoding="utf-8")
        tree = ast.parse(source)
        imported = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imported |= {a.name for a in node.names}
            elif isinstance(node, ast.ImportFrom):
                imported.add(("." * node.level) + (node.module or ""))
        self.assertEqual(imported, {"codecs", "html.parser", "json", "re", "urllib.parse", "."})
        for name in ("static_reader.py", "collect.py", "common.py", "doctor.py", "verify.py"):
            with self.subTest(file=name):
                ast.parse((folder / name).read_text(encoding="utf-8"), feature_version=(3, 9))

    def test_the_export_carries_the_reader(self):
        exporter = load(SCRIPTS / "export_portable.py", "r559_reader_export")
        self.assertIn("scripts/visual_materials/static_reader.py", exporter.VISUAL_PACKAGE)


if __name__ == "__main__":
    unittest.main()

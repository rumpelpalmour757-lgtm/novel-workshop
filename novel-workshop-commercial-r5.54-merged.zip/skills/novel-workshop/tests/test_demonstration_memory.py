import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts/demonstration_memory.py"
spec = importlib.util.spec_from_file_location("demonstration_memory", SCRIPT)
memory = importlib.util.module_from_spec(spec)
spec.loader.exec_module(memory)


def case(case_id, status="teacher_approved", split="development", group=None, project="book"):
    item = json.loads((ROOT / "assets/demonstration-case-template.json").read_text(encoding="utf-8"))
    item.update(id=case_id, project_id=project, group_id=group or case_id,
                status=status, split=split, tags=["dialogue"],
                before=f"原稿{case_id}", after=f"改稿{case_id}")
    item["source"] = {"ref": "fixture", "version": "1", "reviewer": "fixture-teacher",
                      "evidence": "Synthetic fixture only; no real author approval."}
    if status == "author_accepted":
        item["author_acceptance"] = {"quote": "合成测试中的认可", "ref": "fixture-author"}
    item["hashes"] = {key: hashlib.sha256(item[key].encode()).hexdigest()
                      for key in ("before", "after")}
    return item


def state(*items, enabled=True):
    return {"project_id": "book", "data": {"characters": {"keeper": {"name": "保留"}},
            "settings": {}, "chapters": {}, "demonstration_learning": {"enabled": enabled},
            "demonstrations": {c["id"]: c for c in items}}}


class DemonstrationMemoryTests(unittest.TestCase):
    def test_selection_respects_status_scope_and_author_priority(self):
        payload = state(case("teacher"), case("author", "author_accepted"),
                        case("candidate", "candidate"), case("rejected", "rejected"),
                        case("retired", "retired"), case("other-book", project="elsewhere"))
        errors, cases, _ = memory.validate(payload)
        self.assertEqual(errors, [])
        self.assertEqual([c["id"] for c in memory.select(cases, "book", "dialogue_revision", [], [], 3)],
                         ["author", "teacher"])

    def test_holdout_blocks_entire_group_and_duplicate_text(self):
        held = case("held", split="holdout", group="same-scene")
        sibling = case("sibling", group="same-scene")
        duplicate = case("duplicate")
        duplicate["after"] = held["after"]
        duplicate["hashes"]["after"] = held["hashes"]["after"]
        payload = state(held, sibling, duplicate, case("safe"))
        _, cases, _ = memory.validate(payload)
        self.assertEqual([c["id"] for c in memory.select(cases, "book", "dialogue_revision", [], [], 3)], ["safe"])

    def test_missing_author_evidence_and_stale_text_are_invalid(self):
        author = case("author", "author_accepted")
        author["author_acceptance"] = None
        author["after"] += "未重新认可的更改"
        errors, _, _ = memory.validate(state(author))
        self.assertTrue(any("author quote" in e for e in errors))
        self.assertTrue(any("hashes.after" in e for e in errors))

    def test_heldout_text_cannot_swap_input_and_target(self):
        held = case("held", split="holdout")
        swapped = case("swapped")
        swapped["before"] = held["after"]
        swapped["hashes"]["before"] = held["hashes"]["after"]
        _, cases, _ = memory.validate(state(held, swapped, case("safe")))
        self.assertEqual([c["id"] for c in memory.select(cases, "book", "dialogue_revision", [], [], 3)], ["safe"])

    def test_index_never_emits_example_text_or_approval_evidence(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "state.json"
            path.write_text(json.dumps(state(case("one"), case("held", split="holdout"))), encoding="utf-8")
            run = subprocess.run([sys.executable, str(SCRIPT), "index", str(path),
                                  "--project-id", "book", "--task", "dialogue_revision"],
                                 capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(run.returncode, 0, run.stderr)
            record = json.loads(run.stdout)["cases"][0]
            self.assertEqual(set(record), {"id", "project_id", "group_id", "task", "tags", "status", "split"})
            self.assertNotIn("原稿", run.stdout)
            self.assertNotIn("fixture-teacher", run.stdout)

    def test_unchanged_example_is_allowed(self):
        item = case("keep")
        item["after"] = item["before"]
        item["hashes"]["after"] = item["hashes"]["before"]
        item["decisions"] = ["保留原文，无需修改。"]
        self.assertEqual(memory.validate(state(item))[0], [])

    def test_tags_and_explicit_group_exclusion(self):
        _, cases, _ = memory.validate(state(case("one"), case("two")))
        self.assertEqual(memory.select(cases, "book", "dialogue_revision", ["combat"], [], 3), [])
        self.assertEqual([c["id"] for c in memory.select(cases, "book", "dialogue_revision", ["dialogue"], ["one"], 3)], ["two"])

    def test_cli_is_read_only_and_disabled_is_empty(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "state.json"
            path.write_text(json.dumps(state(case("one"), enabled=False)), encoding="utf-8")
            before = path.read_bytes()
            run = subprocess.run([sys.executable, str(SCRIPT), "select", str(path),
                                  "--project-id", "book", "--task", "dialogue_revision"],
                                 capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(run.returncode, 0, run.stderr)
            self.assertEqual(json.loads(run.stdout)["cases"], [])
            self.assertEqual(path.read_bytes(), before)
            invalid = subprocess.run([sys.executable, str(SCRIPT), "select", str(path),
                                      "--project-id", "book", "--task", "dialogue_revision", "--evaluation"],
                                     capture_output=True)
            self.assertNotEqual(invalid.returncode, 0)

    def test_existing_state_commit_roundtrip_preserves_story(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            path, initial, proposed = [folder / n for n in ("state.json", "initial.json", "proposed.json")]
            initial.write_text(json.dumps(state()["data"]), encoding="utf-8")
            state_script = ROOT / "scripts/project_state.py"
            def run(*args):
                result = subprocess.run([sys.executable, str(state_script), *map(str, args)],
                                        capture_output=True, text=True, encoding="utf-8")
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
                return json.loads(result.stdout)
            run("init", path, "--project-id", "book", "--data", initial)
            baseline = run("read", path)
            updated = copy.deepcopy(baseline["data"])
            updated["demonstrations"] = {"one": case("one")}
            proposed.write_text(json.dumps(updated), encoding="utf-8")
            run("commit", path, "--if-version", baseline["version"], "--proposed", proposed)
            saved = run("read", path)
            self.assertEqual(saved["data"]["characters"], baseline["data"]["characters"])
            self.assertEqual(memory.validate(saved)[0], [])
            self.assertEqual(len(memory.select(saved["data"]["demonstrations"], "book", "dialogue_revision", [], [], 3)), 1)


if __name__ == "__main__":
    unittest.main()

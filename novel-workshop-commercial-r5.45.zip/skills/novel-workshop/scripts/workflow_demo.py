#!/usr/bin/env python3
"""Three-chapter fictional integration fixture. All reviews/acceptances are SIMULATED.

Uses real guards and project state; never a literary evaluation or real approval.
New output directory required. Re-running a matching fixture resumes its events.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True


def module(name):
    spec = importlib.util.spec_from_file_location("demo_" + name, Path(__file__).with_name(name + ".py"))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def write(path, value):
    path.write_text(value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


BODIES = [
    "林舟把铜匣放进柜子，锁好柜门。钥匙仍挂在他腰间。\n",
    "天亮后，林舟打开柜门，把铜匣放进自己的布袋。钥匙仍挂在他腰间。\n",
    "林舟到达码头，铜匣还在自己的布袋里。他隔着袋口摸了摸锁扣。\n",
]
QUOTES = ["林舟把铜匣放进柜子", "把铜匣放进自己的布袋", "铜匣还在自己的布袋里"]
VALUES = ["柜子", "林舟的布袋", "林舟的布袋"]


def run(root, stop_after=None):
    guard, state_api, delivery = (module(x) for x in ("workflow_guard", "project_state", "delivery_manifest"))
    root = Path(root).resolve()
    marker = {"fixture": "workflow-demo/1", "warning": "全部原文、审稿和作者采纳均为虚构测试数据"}
    if root.exists():
        if not (root / "DEMO.json").is_file() or json.loads((root / "DEMO.json").read_text(encoding="utf-8")) != marker:
            raise ValueError("Refusing to overwrite an existing non-demo directory")
    else:
        root.mkdir(parents=True)
        write(root / "DEMO.json", marker)
    project = root / "project-state.json"
    if not project.exists():
        state_api.init_state(project, "fictional-demo", {"characters": {}, "settings": {}, "chapters": {},
            "facts": {"schema": "fact-ledger/1", "entities": {"box": {"name": "铜匣"}}, "chapters": {}, "facts": []}})
    for number, body in enumerate(BODIES, 1):
        prefix = "ch%d" % number
        candidate, state, spec = (root / (prefix + suffix) for suffix in (".md", ".run.json", ".checks.json"))
        review_path = root / (prefix + ".review.json")
        if not state.exists():
            baseline = state_api.read_state(project)
            write(root / (prefix + ".ledger.json"), baseline["data"]["facts"])
            write(root / (prefix + ".original.md"), body)
            write(candidate, body.replace("柜子，", "柜子,,") if number == 1 else body)
            write(spec, {"candidate": candidate.name, "checks": [
                {"id": "punct", "type": "punctuation"}, {"id": "prose", "type": "prose"},
                {"id": "facts", "type": "facts", "ledger": prefix + ".ledger.json", "claims": prefix + ".claims.json", "chapters_dir": "."},
                {"id": "length", "type": "length", "min": 20}]})
            write(root / (prefix + ".claims.json"), {"schema": "fact-claims/1", "chapter": number,
                "candidate": candidate.name, "candidate_sha256": sha(candidate), "extracted_by": "SIMULATED fixture",
                "claims": [{"id": "location", "entity": "box", "attribute": "location", "value": VALUES[number-1],
                            "basis": "witnessed_action", "quote": QUOTES[number-1], "change": number == 2}]})
            guard.start(state, "SIMULATED-" + prefix, spec)
        current = guard.load_state(state)
        events = set(current["events"])
        sources = [a["path"] for a in guard.frozen_inputs(current) if a["role"] == "source"]
        def review(verdict):
            # Static fixture judgments, never produced from machine verdicts.
            return {"schema": "editorial-review/2", "candidate_sha256": sha(candidate),
                    "reviewer": {"mode": "self_check", "label": "SIMULATED integration fixture"},
                    "verdict": verdict, "checked_against": ["虚构铜匣去向测试"], "inputs_read": sources,
                    "evidence": [{"quote": QUOTES[number-1]}],
                    "issues": [] if verdict == "PASS" else [{"quote": "柜子,,", "expected": "中文逗号", "impact": "标点格式错误"}],
                    "machine_dispositions": ([{"id": "facts:F-location", "decision": "keep", "reason": "模拟审稿：本章直接描写铜匣所在位置。"}]
                                             if number in (1, 2) and verdict == "PASS" else []),
                    "counter_evidence": "模拟审稿核对物品移动；不表示真实编辑或作者意见。"}
        if number == 1 and "failed" not in events:
            write(review_path, review("NEEDS_REVISION"))
            guard.record(state, "failed", review_path)
        if number == 1 and stop_after == "failed-review":
            return {"status": "PAUSED", "warning": marker["warning"], "state": str(state)}
        if "checked" not in events:
            if number == 1:
                guard.reserve(state, "repair-once")
                write(candidate, body)
                claims_path = root / (prefix + ".claims.json")
                claims = json.loads(claims_path.read_text(encoding="utf-8"))
                claims["candidate_sha256"] = sha(candidate)
                write(claims_path, claims)
            write(review_path, review("PASS"))
            guard.record(state, "checked", review_path)
        current = guard.load_state(state)
        if not current["human_approvals"]:
            decision = root / (prefix + ".simulated-acceptance.json")
            write(decision, {"candidate_sha256": sha(candidate), "source": "SIMULATED TEST ONLY：虚构作者采纳，非用户消息", "scope": prefix})
            guard.accept(state, "simulated-accept", decision)
        snapshot = state_api.read_state(project)
        if str(number) not in snapshot["data"]["chapters"]:
            data = snapshot["data"]
            data["chapters"][str(number)] = {"status": "accepted", "simulation": True}
            data["facts"]["chapters"][str(number)] = {"status": "accepted", "file": candidate.name, "sha256": sha(candidate)}
            data["facts"]["facts"].append({"id": "location-%d" % number, "entity": "box", "attribute": "location",
                "value": VALUES[number-1], "chapter": number, "layer": "accepted", "basis": "witnessed_action",
                "source": "%s；SIMULATED TEST ONLY" % candidate.name, "change": number == 2})
            state_api.commit_state(project, snapshot["version"], data)
    manifest = root / "delivery.json"
    write(manifest, {"schema": "delivery-manifest/1", "stage": "accepted", "expected_units": ["ch1", "ch2", "ch3"],
        "records": [{"unit": "ch%d" % n, "candidate": "ch%d.md" % n, "state": "ch%d.run.json" % n} for n in (1, 2, 3)]})
    result = delivery.check(manifest)
    result["warning"] = marker["warning"]
    write(root / "demo-report.json", result)
    return result


def utf8_stdio():
    """Reports are UTF-8 on every platform; a Windows pipe would otherwise use the local code page."""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--stop-after", choices=["failed-review"])
    args = parser.parse_args()
    try:
        result = run(args.output, args.stop_after)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["status"] in {"PASS", "PAUSED"} else 1
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False))
        return 2
    except Exception as exc:
        # project_state.StateError, e.g. unsupported_platform: the demo's project store needs POSIX flock.
        if not hasattr(exc, "code"):
            raise
        print(json.dumps({"status": "ERROR", "failure": exc.code, "error": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    sys.exit(main())

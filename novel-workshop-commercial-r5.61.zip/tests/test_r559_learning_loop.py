#!/usr/bin/env python3
"""r5.59: four small changes to learning_loop.py, and proof that old records and old events still work.

The author read the r5.59 proposal and answered "do as the maker suggests" to the items put to him and "go ahead" to
section 3; section 3 item 7 is these four changes to scripts/learning_loop.py (not a delivery-gate script):

1. `learn` may carry `tags`; given, they replace the run's start tags on the case. Where the trouble lay is often known
   only after the revision. Before, extra tags on `learn` were dropped silently. The ledger keeps the event as sent.
2. A `plan` application may carry `scopes`, one per scene (the beat card's Scene ID), each with its own decision, reason
   and checks. A scene with an unmet condition or a matching exception can only decline; the application is decline
   exactly when every scene declines. Before, a chapter with one scene that fits and one that hits an exception could
   only be recorded by writing the exception down as "not hit".
3. The `actor` of `draft` and `revise` may carry `role` (author or writer); `learn` copies the final draft's role to
   the case's `source.after_by`. It is a declaration like every identity field; the script cannot tell who wrote it.
   (The proposal names `revise`; `draft` takes the same actor object, so it takes the same optional field.)
4. When the pass a run finishes on is the author's own review, `completion` is `author_reviewed`; before, such a run
   was recorded `self_checked`. The author's pass is a review, not an acceptance: the case still needs author_accept or
   case_accept to become author_accepted.

Backward compatibility: old records still read, old commands still work. `OldEventsAndRecords` replays one fixed
history written only with events an r5.58 user could send (configure, four runs off the chapter gate and one under it
with every stage, plan with conditions given as a list and exceptions as a map, a declined case, finish as
teacher_reviewed, self_checked and author_objection_open, author_accept, learn, case_accept, case_status, stop) and
checks that the store file it writes, and what status, show, context, chapter_gate.py status and
demonstration_memory.py check/index print from it, have the SHA-256 that r5.58's own scripts produce for the same
history (measured once on the r5.58 release package, with Python 3.13 and 3.9, and pinned here). A record written
earlier with completion self_checked is read and kept as it is (not rewritten).

Run against the r5.58 package (NW_PACKAGE_ROOT), the byte-for-byte pair and the history check pass, and so do the
tests that send the old forms (no tags at learn, no scopes, no role, the other completion values, a teacher's pass
after the author's): that is the point of them. The tests of the new forms fail there.

These tests check what the script stores and refuses. They do not show that the next chapter is written better.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
SCRIPTS = SKILL / "scripts"
START = "<!-- NOVEL_WORKSHOP_LEARNING_START -->"
END = "<!-- NOVEL_WORKSHOP_LEARNING_END -->"
AUTHOR = {"actor_role": "author", "mode": "human"}

# SHA-256 of what r5.58's learning_loop.py / demonstration_memory.py write and print for OldEventsAndRecords' history.
R558_STORE_SHA256 = "158ca1d28e76ab1938b2385de062060716d2c75f3589e40f34cc98b4538d3547"
R558_READS_SHA256 = "2241a6e4431a185630f17417fe4e256dda743846ab484e4c71366cdc74289769"


def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def load_loop(root=None):
    path = (Path(root) if root else ROOT) / "skills" / "novel-workshop" / "scripts" / "learning_loop.py"
    spec = importlib.util.spec_from_file_location("r559_learning_loop_%d" % abs(hash(str(path))), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(script, *args, root=None):
    path = (Path(root) if root else ROOT) / "skills" / "novel-workshop" / "scripts" / script
    proc = subprocess.run([sys.executable, "-I", "-B", str(path), *map(str, args)], capture_output=True, text=True,
                          encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


def new_store(path, project="book", extra=None):
    data = {"demonstration_learning": {"enabled": True, "loop_enabled": True, "max_revisions": 3},
            "demonstrations": {}, "learning_runs": {}, "learning_events": {}}
    data.update(extra or {})
    payload = {"schema_version": 1, "project_id": project, "revision": 0, "data": data}
    Path(path).write_bytes(("# 合成学习记录\n\n" + START + "\n```json\n" + json.dumps(payload, ensure_ascii=False)
                            + "\n```\n" + END + "\n\n手写便笺照原样留着。\n").encode("utf-8"))
    return Path(path)


def payload_of(path):
    text = Path(path).read_text(encoding="utf-8")
    return json.loads(text[text.index("```json") + 7:text.rindex("```")])


class Recorder:
    """Applies events in order with the package's (or another root's) learning_loop module."""

    def __init__(self, path, loop, project="book"):
        self.path, self.loop, self.project, self.serial = Path(path), loop, project, 0

    def send(self, event):
        version = self.loop.read_store(self.path)[1]
        return self.loop.apply_event(self.path, event, self.project, version)

    def op(self, op, run_id=None, **fields):
        self.serial += 1
        event = {"event_id": "e%03d-%s" % (self.serial, op), "op": op, **fields}
        if run_id is not None:
            event["run_id"] = run_id
        return self.send(event)

    def refused(self, op, run_id=None, **fields):
        before = self.path.read_bytes()
        self.serial += 1
        event = {"event_id": "x%03d-%s" % (self.serial, op), "op": op, **fields}
        if run_id is not None:
            event["run_id"] = run_id
        try:
            self.send(event)
        except self.loop.LoopError as exc:
            assert self.path.read_bytes() == before, "a refused event must not write"
            return exc
        raise AssertionError("event was accepted: %r" % (event,))

    def gate(self, action, chapter, stage=None, **fields):
        self.serial += 1
        event = {"event_id": "g%03d-%s" % (self.serial, action), "op": "chapter_gate", "action": action,
                 "chapter_id": chapter, **fields}
        if stage:
            event["stage"] = stage
        if action == "configure":
            event.pop("chapter_id")
        return self.send(event)

    def refused_gate(self, action, chapter, stage=None, **fields):
        before = self.path.read_bytes()
        try:
            self.gate(action, chapter, stage, **fields)
        except self.loop.LoopError as exc:
            assert self.path.read_bytes() == before, "a refused event must not write"
            return exc
        raise AssertionError("chapter_gate event was accepted: %s %s" % (action, stage))

    def stage(self, chapter, stage, quote, artifact=None, final=False):
        fields = {"content": "合成的" + stage + "阶段成果", "source_ref": "合成工作记录#" + stage}
        if artifact:
            fields["artifact_sha256"] = artifact
        shown = self.gate("present", chapter, stage, **fields)
        confirm = {"presentation_id": shown["presentation_id"], "presentation_version": shown["presentation_version"],
                   "author_quote": quote, "source_ref": "合成对话#" + stage, **AUTHOR}
        if final:
            confirm["decision"] = "accept_final_version"
        return self.gate("confirm", chapter, stage, **confirm)

    def reviewer(self, role, mode, context):
        return {"name": "合成" + role, "role": role, "mode": mode, "context_id": context}


TEXT_A = "他把伞靠在门边。“雨大，你先进来。”"
TEXT_A2 = "他把伞靠在门边。“进来。”"
TEXT_B = "她把账本合上。“明天再算。”"
TEXT_C = "老人把茶推过去。“先喝口热的。”"
TEXT_C2 = "老人把茶推过去，没说话。"
TEXT_D = "船靠了岸，没人急着下。"


def old_history(rec):
    """Only events and fields an r5.58 user could send. Fixed ids and text: the result is deterministic."""
    rec.op("configure", loop_enabled=True, enabled=True, max_revisions=3, quote="开始记示范。",
           source_ref="合成对话#开启", **AUTHOR)
    finding = [{"id": "f1", "issue": "回应没接住动作", "evidence": "“雨大，你先进来。”", "scope": "第一句"}]
    # Run A: teacher review, revision, teacher pass -> teacher_reviewed, teacher-approved case.
    rec.op("start", "A", task="dialogue_revision", tags=["回应"], group_id="scene-a", input_text="他把伞靠在门边。",
           source_ref="合成#A", constraints=["伞留在门边"])
    rec.op("plan", "A", applications=[], checks=["回应接住动作"])
    rec.op("draft", "A", text=TEXT_A, source_ref="合成#A1", actor={"name": "合成写作者", "context_id": "w1"})
    rec.op("review", "A", review_id="t1", draft_sha256=sha(TEXT_A), reviewer=rec.reviewer("teacher", "independent_agent", "t"),
           verdict="revise", findings=finding, source_ref="合成#t1")
    rec.op("decide", "A", review_id="t1", decisions=[{"finding_id": "f1", "decision": "adopt", "reason": "照改"}])
    rec.op("revise", "A", parent_sha256=sha(TEXT_A), review_id="t1", text=TEXT_A2, source_ref="合成#A2",
           actor={"name": "合成写作者", "context_id": "w1"})
    rec.op("review", "A", review_id="t2", draft_sha256=sha(TEXT_A2), reviewer=rec.reviewer("teacher", "independent_agent", "t"),
           verdict="pass", findings=[], rechecks=["t1"], source_ref="合成#t2")
    rec.op("finish", "A", draft_sha256=sha(TEXT_A2))
    rec.op("learn", "A", case_id="caseA", why="合成依据。", when=["熟人进门"], decisions=["照改"], **{"except": ["对方是生客"]})
    # Run B: selects caseA, declines it (list form for conditions, map for exceptions); self-check; author accepts.
    rec.op("start", "B", task="dialogue_revision", tags=["回应"], group_id="scene-b", input_text="她把账本合上。",
           source_ref="合成#B", constraints=[])
    rec.op("plan", "B", applications=[{"case_id": "caseA", "decision": "decline", "reason": "生客",
                                       "conditions_checked": ["熟人进门"], "exceptions_checked": {"对方是生客": True}}],
           checks=["合成"])
    rec.op("draft", "B", text=TEXT_B, source_ref="合成#B1", actor={"name": "合成写作者", "context_id": "w2"})
    rec.op("review", "B", review_id="s1", draft_sha256=sha(TEXT_B), reviewer=rec.reviewer("writer", "self_check", "w2"),
           verdict="pass", findings=[], source_ref="合成#s1")
    rec.op("finish", "B", draft_sha256=sha(TEXT_B))
    rec.op("author_accept", "B", draft_sha256=sha(TEXT_B), quote="采纳当前稿。", source_ref="合成对话#B", **AUTHOR)
    rec.op("learn", "B", case_id="caseB", why="合成依据。", when=["收工的时候"], decisions=["留着"], **{"except": []})
    # Run C: the author objects, a writer's pass after the revision -> author_objection_open; candidate; retired.
    rec.op("start", "C", task="scene_revision", tags=["回应"], group_id="scene-c", input_text="老人把茶推过去。",
           source_ref="合成#C", constraints=[])
    rec.op("plan", "C", applications=[], checks=["合成"])
    rec.op("draft", "C", text=TEXT_C, source_ref="合成#C1", actor={"name": "合成写作者", "context_id": "w3"})
    rec.op("review", "C", review_id="a1", draft_sha256=sha(TEXT_C), reviewer=rec.reviewer("author", "human", "author"),
           verdict="revise", findings=[{"id": "f1", "issue": "他不说这句", "evidence": "“先喝口热的。”", "scope": "第一句"}],
           source_ref="合成对话#C")
    rec.op("decide", "C", review_id="a1", decisions=[{"finding_id": "f1", "decision": "adopt", "reason": "作者的话"}])
    rec.op("revise", "C", parent_sha256=sha(TEXT_C), review_id="a1", text=TEXT_C2, source_ref="合成#C2",
           actor={"name": "合成写作者", "context_id": "w3"})
    rec.op("review", "C", review_id="s2", draft_sha256=sha(TEXT_C2), reviewer=rec.reviewer("writer", "self_check", "w3"),
           verdict="pass", findings=[], rechecks=["a1"], source_ref="合成#s2")
    rec.op("finish", "C", draft_sha256=sha(TEXT_C2))
    rec.op("learn", "C", case_id="caseC", why="合成依据。", when=["长辈招呼"], decisions=["删台词"], **{"except": []})
    rec.op("case_status", case_id="caseC", status="retired", reason="合成：退役")
    # Run D under the chapter gate, the workshop reviewing (configure host); final acceptance; learn.
    rec.gate("configure", None, visual_required=False, teacher_handoff="host", author_quote="整本书不交老师。",
             source_ref="合成对话#策略", **AUTHOR)
    for stage, quote in (("scope", "好"), ("outline", "继续"), ("preparation", "写")):
        rec.stage("ch01", stage, quote)
    rec.stage("ch01", "draft", "可以", artifact=sha(TEXT_D))
    rec.op("start", "D", task="chapter_revision", tags=["分场"], group_id="ch01", input_text=TEXT_D, source_ref="合成#D",
           constraints=[], chapter_id="ch01")
    rec.op("plan", "D", applications=[], checks=["合成"])
    rec.op("draft", "D", text=TEXT_D, source_ref="合成#D1", actor={"name": "合成写作者", "context_id": "w4"})
    rec.op("review", "D", review_id="s3", draft_sha256=sha(TEXT_D), reviewer=rec.reviewer("writer", "self_check", "w4"),
           verdict="pass", findings=[], source_ref="合成#s3")
    rec.op("finish", "D", draft_sha256=sha(TEXT_D))
    rec.stage("ch01", "review", "好")
    rec.stage("ch01", "revision", "好", artifact=sha(TEXT_D))
    rec.stage("ch01", "final", "定稿。", artifact=sha(TEXT_D), final=True)
    rec.op("author_accept", "D", draft_sha256=sha(TEXT_D), quote="定稿。", source_ref="合成对话#final", **AUTHOR)
    rec.op("learn", "D", case_id="caseD", why="合成依据。", when=["险事过后"], decisions=["照原样"], **{"except": []})
    # Run E stops; caseA gets the author's later acceptance.
    rec.op("start", "E", task="dialogue_revision", tags=[], group_id="scene-e", input_text="合成输入。", source_ref="合成#E",
           constraints=[])
    rec.op("stop", "E", reason="合成：停下")
    rec.op("case_accept", case_id="caseA", case_sha256=sha(TEXT_A2), quote="采纳当前稿。", source_ref="合成对话#A",
           **AUTHOR)


def reads(path, root=None):
    """What a user reads back from the store; the store path itself is left out."""
    outputs = []
    for args in (("learning_loop.py", "status", path),
                 *(("learning_loop.py", "show", path, "--run-id", run_id, "--brief") for run_id in "ABCDE"),
                 ("learning_loop.py", "show", path, "--run-id", "C"),
                 ("learning_loop.py", "context", path, "--project-id", "book", "--task", "dialogue_revision"),
                 ("learning_loop.py", "context", path, "--project-id", "book", "--task", "chapter_revision"),
                 ("chapter_gate.py", "status", path, "--chapter-id", "ch01"),
                 ("demonstration_memory.py", "check", path),
                 ("demonstration_memory.py", "index", path, "--project-id", "book", "--task", "dialogue_revision")):
        code, out, err = run(*args, root=root)
        outputs.append("%d\n%s\n%s" % (code, out, err))
    return "\n----\n".join(outputs)


def replay(root=None):
    """Write the old history with the given package's scripts; return (store bytes, reads)."""
    with tempfile.TemporaryDirectory() as tmp:
        path = new_store(Path(tmp) / "学习记录.md")
        old_history(Recorder(path, load_loop(root)))
        return path.read_bytes(), reads(path, root)


class Fixture(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = new_store(Path(self.temp.name) / "学习记录.md")
        self.loop = load_loop()
        self.rec = Recorder(self.path, self.loop)

    def data(self):
        return payload_of(self.path)["data"]

    def finished_run(self, run_id="R", text="她把杯子推回来。", reviewer=("writer", "self_check", "w"), tags=("对白",),
                     actor_role=None):
        self.rec.op("start", run_id, task="chapter_revision", tags=list(tags), group_id="g-" + run_id,
                    input_text="她把杯子推过去。", source_ref="合成#" + run_id, constraints=[])
        self.rec.op("plan", run_id, applications=[], checks=["合成"])
        actor = {"name": "合成", "context_id": "w"}
        if actor_role:
            actor["role"] = actor_role
        self.rec.op("draft", run_id, text=text, source_ref="合成#" + run_id, actor=actor)
        self.rec.op("review", run_id, review_id="p-" + run_id, draft_sha256=sha(text),
                    reviewer=self.rec.reviewer(*reviewer), verdict="pass", findings=[], source_ref="合成#p")
        return self.rec.op("finish", run_id, draft_sha256=sha(text))


class LearnTags(Fixture):
    def test_tags_given_at_learn_replace_the_start_tags_on_the_case(self):
        self.finished_run(tags=("对白",), reviewer=("teacher", "independent_agent", "t"))
        self.rec.op("learn", "R", case_id="c1", why="合成。", when=["合成条件"], decisions=["合成"], tags=["说话人认不出", "多人同场"],
                    **{"except": []})
        data = self.data()
        self.assertEqual(data["demonstrations"]["c1"]["tags"], ["说话人认不出", "多人同场"])
        self.assertEqual(data["learning_runs"]["R"]["tags"], ["对白"])  # the run keeps what it started with
        ledger = [entry["event"] for entry in data["learning_events"].values() if entry["op"] == "learn"]
        self.assertEqual(ledger[0]["tags"], ["说话人认不出", "多人同场"])  # the ledger keeps the event as sent
        # the next run finds it by the new tags, not by the old one
        self.assertEqual(self.loop.context(self.path, "book", "chapter_revision", ["多人同场"])["count"], 1)
        self.assertEqual(self.loop.context(self.path, "book", "chapter_revision", ["对白"])["count"], 0)

    def test_without_tags_the_start_tags_stay(self):
        self.finished_run(tags=("对白",))
        self.rec.op("learn", "R", case_id="c1", why="合成。", when=["合成条件"], decisions=["合成"], **{"except": []})
        self.assertEqual(self.data()["demonstrations"]["c1"]["tags"], ["对白"])

    def test_bad_tags_are_refused_without_a_write(self):
        self.finished_run()
        for tags in ("对白", [""], ["对白", "对白"], [1], None):
            with self.subTest(tags=tags):
                error = self.rec.refused("learn", "R", case_id="c1", why="合成。", when=["合成条件"], decisions=["合成"],
                                         tags=tags, **{"except": []})
                self.assertEqual(error.code, "invalid_event")
        self.assertEqual(self.data()["demonstrations"], {})


class PlanScopes(Fixture):
    def setUp(self):
        super().setUp()
        # an approved case to apply: a teacher-reviewed run learned in another group
        self.rec.op("start", "T", task="chapter_revision", tags=["对白"], group_id="old", input_text="旧输入。",
                    source_ref="合成#T", constraints=[])
        self.rec.op("plan", "T", applications=[], checks=["合成"])
        self.rec.op("draft", "T", text="旧终稿。", source_ref="合成#T", actor={"name": "合成", "context_id": "w"})
        self.rec.op("review", "T", review_id="tp", draft_sha256=sha("旧终稿。"),
                    reviewer=self.rec.reviewer("teacher", "independent_agent", "t"), verdict="pass", findings=[],
                    source_ref="合成#tp")
        self.rec.op("finish", "T", draft_sha256=sha("旧终稿。"))
        self.rec.op("learn", "T", case_id="熟客", why="合成。", when=["熟客来办常办的事"], decisions=["合成"],
                    **{"except": ["对方是头一回来的生客"]})
        self.rec.op("start", "R", task="chapter_revision", tags=["对白"], group_id="ch02", input_text="新输入。",
                    source_ref="合成#R", constraints=[])

    def scope(self, scene, decision, hit, reason="合成"):
        return {"scene_id": scene, "decision": decision, "reason": reason,
                "conditions_checked": {"熟客来办常办的事": not hit}, "exceptions_checked": {"对方是头一回来的生客": hit}}

    def test_one_scene_applies_and_one_declines(self):
        result = self.rec.op("plan", "R", checks=["合成"], applications=[{
            "case_id": "熟客", "decision": "apply", "reason": "第一场熟客，第二场生客",
            "scopes": [self.scope("ch02-s1", "apply", False), self.scope("ch02-s2", "decline", True, "生客命中例外")]}])
        self.assertEqual(result["next_action"], "draft")
        stored = self.data()["learning_runs"]["R"]["applications"][0]
        self.assertEqual([(s["scene_id"], s["decision"]) for s in stored["scopes"]],
                         [("ch02-s1", "apply"), ("ch02-s2", "decline")])
        self.assertIs(stored["scopes"][1]["exceptions_checked"]["对方是头一回来的生客"], True)
        self.assertNotIn("exceptions_checked", stored)
        self.assertEqual(self.rec.op("draft", "R", text="新初稿。", source_ref="合成",
                                     actor={"name": "合成", "context_id": "w"})["next_action"], "review")

    def test_every_scene_declining_makes_the_application_decline(self):
        self.rec.op("plan", "R", checks=["合成"], applications=[{
            "case_id": "熟客", "decision": "decline", "reason": "两场都是生客",
            "scopes": [self.scope("ch02-s1", "decline", True), self.scope("ch02-s2", "decline", True)]}])
        self.assertEqual(self.data()["learning_runs"]["R"]["applications"][0]["decision"], "decline")

    def test_wrong_scopes_are_refused_without_a_write(self):
        bad = {
            "a scene hitting the exception cannot apply": {
                "decision": "apply", "scopes": [self.scope("s1", "apply", True)]},
            "application decision must follow the scenes (one applies)": {
                "decision": "decline", "scopes": [self.scope("s1", "apply", False)]},
            "application decision must follow the scenes (none applies)": {
                "decision": "apply", "scopes": [self.scope("s1", "decline", True)]},
            "a scene named twice": {
                "decision": "apply", "scopes": [self.scope("s1", "apply", False), self.scope("s1", "decline", True)]},
            "empty scopes": {"decision": "decline", "scopes": []},
            "scopes is not a list": {"decision": "decline", "scopes": {"s1": "decline"}},
            "a scope without its checks": {"decision": "decline",
                                           "scopes": [{"scene_id": "s1", "decision": "decline", "reason": "合成"}]},
            "a scope without a reason": {"decision": "decline", "scopes": [
                {**self.scope("s1", "decline", True), "reason": ""}]},
            # r5.59 review: a scene that applies and whose decision is not one of the three names (no other check
            # catches this one)
            "a scope decision outside apply, adapt and decline": {
                "decision": "apply", "scopes": [dict(self.scope("s1", "apply", False), decision="use")]},
            "both scopes and the application's own checks": {
                "decision": "apply", "scopes": [self.scope("s1", "apply", False)],
                "conditions_checked": {"熟客来办常办的事": True}, "exceptions_checked": {"对方是头一回来的生客": False}},
        }
        for label, fields in bad.items():
            with self.subTest(label):
                error = self.rec.refused("plan", "R", checks=["合成"],
                                         applications=[{"case_id": "熟客", "reason": "合成", **fields}])
                self.assertEqual(error.code, "invalid_event")
                if fields["scopes"] and isinstance(fields["scopes"], list) and fields["scopes"][0].get("decision") == "use":
                    self.assertIn("Invalid scope decision", str(error))
        self.assertEqual(self.data()["learning_runs"]["R"]["status"], "started")

    def test_without_scopes_the_old_rule_holds(self):
        error = self.rec.refused("plan", "R", checks=["合成"], applications=[{
            "case_id": "熟客", "decision": "apply", "reason": "合成",
            "conditions_checked": {"熟客来办常办的事": True}, "exceptions_checked": {"对方是头一回来的生客": True}}])
        self.assertIn("requires decline", str(error))


class WhoWroteTheText(Fixture):
    def test_role_on_revise_reaches_the_case_as_after_by(self):
        self.rec.op("start", "R", task="chapter_revision", tags=["对白"], group_id="g", input_text="原稿。",
                    source_ref="合成#R", constraints=[])
        self.rec.op("plan", "R", applications=[], checks=["合成"])
        self.rec.op("draft", "R", text="初稿。", source_ref="合成", actor={"name": "合成写作者", "context_id": "w", "role": "writer"})
        self.rec.op("review", "R", review_id="a1", draft_sha256=sha("初稿。"),
                    reviewer=self.rec.reviewer("author", "human", "author"), verdict="revise",
                    findings=[{"id": "f1", "issue": "合成", "evidence": "初稿。", "scope": "全段", "replacement": "作者稿。"}],
                    source_ref="合成对话#1")
        self.rec.op("decide", "R", review_id="a1", decisions=[{"finding_id": "f1", "decision": "adopt", "reason": "作者亲改"}])
        self.rec.op("revise", "R", parent_sha256=sha("初稿。"), review_id="a1", text="作者稿。", source_ref="作者亲改稿",
                    actor={"name": "作者", "context_id": "author", "role": "author"})
        run = self.data()["learning_runs"]["R"]
        self.assertEqual([d["actor"].get("role") for d in run["drafts"]], ["writer", "author"])
        self.assertEqual(run["current_draft"]["actor"]["role"], "author")
        self.rec.op("review", "R", review_id="a2", draft_sha256=sha("作者稿。"),
                    reviewer=self.rec.reviewer("author", "human", "author"), verdict="pass", findings=[], rechecks=["a1"],
                    source_ref="合成对话#1")
        self.rec.op("finish", "R", draft_sha256=sha("作者稿。"))
        self.rec.op("learn", "R", case_id="c1", why="合成。", when=["合成"], decisions=["合成"], **{"except": []})
        self.assertEqual(self.data()["demonstrations"]["c1"]["source"]["after_by"], "author")

    def test_no_role_writes_no_after_by(self):
        self.finished_run()
        self.rec.op("learn", "R", case_id="c1", why="合成。", when=["合成"], decisions=["合成"], **{"except": []})
        self.assertNotIn("after_by", self.data()["demonstrations"]["c1"]["source"])

    def test_writer_role_is_kept_as_writer(self):
        self.finished_run(actor_role="writer")
        self.rec.op("learn", "R", case_id="c1", why="合成。", when=["合成"], decisions=["合成"], **{"except": []})
        self.assertEqual(self.data()["demonstrations"]["c1"]["source"]["after_by"], "writer")

    def test_an_unknown_role_is_refused_without_a_write(self):
        self.rec.op("start", "R", task="chapter_revision", tags=[], group_id="g", input_text="原稿。", source_ref="合成",
                    constraints=[])
        self.rec.op("plan", "R", applications=[], checks=["合成"])
        for role in ("teacher", "", None, "Author"):
            with self.subTest(role=role):
                error = self.rec.refused("draft", "R", text="初稿。", source_ref="合成",
                                         actor={"name": "合成", "context_id": "w", "role": role})
                self.assertEqual(error.code, "invalid_event")
        self.assertEqual(self.data()["learning_runs"]["R"]["drafts"], [])


class TheAuthorsPassIsNotASelfCheck(Fixture):
    def test_author_reviewed(self):
        self.finished_run(reviewer=("author", "human", "author"))
        run = self.data()["learning_runs"]["R"]
        self.assertEqual(run["completion"], "author_reviewed")
        # a review, not an acceptance: the case is only a candidate
        self.rec.op("learn", "R", case_id="c1", why="合成。", when=["合成"], decisions=["合成"], **{"except": []})
        self.assertEqual(self.data()["demonstrations"]["c1"]["status"], "candidate")
        self.assertEqual(self.loop.context(self.path, "book", "chapter_revision")["count"], 0)

    def test_the_other_values_are_unchanged(self):
        self.finished_run("W", reviewer=("writer", "self_check", "w"))
        self.finished_run("T", reviewer=("teacher", "independent_agent", "t"))
        runs = self.data()["learning_runs"]
        self.assertEqual((runs["W"]["completion"], runs["T"]["completion"]), ("self_checked", "teacher_reviewed"))

    def test_a_teacher_pass_after_the_authors_stays_teacher_reviewed(self):
        self.rec.op("start", "R", task="chapter_revision", tags=[], group_id="g", input_text="原稿。", source_ref="合成",
                    constraints=[])
        self.rec.op("plan", "R", applications=[], checks=["合成"])
        self.rec.op("draft", "R", text="初稿。", source_ref="合成", actor={"name": "合成", "context_id": "w"})
        for review_id, role, mode in (("a", "author", "human"), ("t", "teacher", "independent_agent")):
            self.rec.op("review", "R", review_id=review_id, draft_sha256=sha("初稿。"),
                        reviewer=self.rec.reviewer(role, mode, review_id), verdict="pass", findings=[], source_ref="合成")
        self.rec.op("finish", "R", draft_sha256=sha("初稿。"))
        self.assertEqual(self.data()["learning_runs"]["R"]["completion"], "teacher_reviewed")

    def test_help_lists_the_new_forms(self):
        code, out, err = run("learning_loop.py", "apply", "--help")
        self.assertEqual(code, 0, err)
        for phrase in ("completion is author_reviewed", "scopes:[{scene_id,decision,reason,", "role:author|writer",
                       "Optional tags:[text] replace the run's start tags on the case", "source.after_by"):
            self.assertIn(phrase, " ".join(out.split()))


class OldEventsAndRecords(unittest.TestCase):
    """Old events give r5.58's results byte for byte; old records read as r5.58 read them."""

    @classmethod
    def setUpClass(cls):
        cls.store, cls.reads = replay()

    def test_the_store_is_byte_for_byte_r558s(self):
        self.assertEqual(hashlib.sha256(self.store).hexdigest(), R558_STORE_SHA256)

    def test_reading_it_prints_what_r558_printed(self):
        self.assertEqual(hashlib.sha256(self.reads.encode("utf-8")).hexdigest(), R558_READS_SHA256)

    def test_the_history_covers_what_it_says(self):
        data = json.loads(self.store.decode("utf-8").split("```json\n", 1)[1].split("\n```", 1)[0])["data"]
        runs = data["learning_runs"]
        self.assertEqual({key: run.get("completion") for key, run in runs.items()},
                         {"A": "teacher_reviewed", "B": "self_checked", "C": "author_objection_open",
                          "D": "self_checked", "E": None})
        self.assertEqual({key: case["status"] for key, case in data["demonstrations"].items()},
                         {"caseA": "author_accepted", "caseB": "author_accepted", "caseC": "retired",
                          "caseD": "author_accepted"})
        self.assertEqual(runs["E"]["status"], "stopped")
        self.assertNotIn("after_by", json.dumps(data, ensure_ascii=False))

    def test_an_earlier_self_checked_record_is_read_and_kept_as_written(self):
        # A record written before r5.59: the author's pass finished the run and it was stored as self_checked.
        with tempfile.TemporaryDirectory() as tmp:
            path = new_store(Path(tmp) / "学习记录.md")
            rec = Recorder(path, load_loop())
            rec.op("start", "R", task="chapter_revision", tags=["对白"], group_id="g", input_text="原稿。",
                   source_ref="合成", constraints=[])
            rec.op("plan", "R", applications=[], checks=["合成"])
            rec.op("draft", "R", text="初稿。", source_ref="合成", actor={"name": "合成", "context_id": "w"})
            rec.op("review", "R", review_id="a", draft_sha256=sha("初稿。"), reviewer=rec.reviewer("author", "human", "a"),
                   verdict="pass", findings=[], source_ref="合成")
            rec.op("finish", "R", draft_sha256=sha("初稿。"))
            text = path.read_text(encoding="utf-8")
            self.assertIn('"completion":"author_reviewed"', text)
            path.write_bytes(text.replace('"completion":"author_reviewed"', '"completion":"self_checked"').encode("utf-8"))
            code, out, err = run("learning_loop.py", "show", path, "--run-id", "R", "--brief")
            self.assertEqual(code, 0, err)
            self.assertEqual(json.loads(out)["run"]["completion"], "self_checked")
            self.assertEqual(json.loads(out)["next_action"], "learn")
            rec.op("learn", "R", case_id="c1", why="合成。", when=["合成"], decisions=["合成"], **{"except": []})
            self.assertEqual(payload_of(path)["data"]["learning_runs"]["R"]["completion"], "self_checked")
            code, out, err = run("demonstration_memory.py", "check", path)
            self.assertEqual(code, 0, out + err)


if __name__ == "__main__":
    unittest.main()

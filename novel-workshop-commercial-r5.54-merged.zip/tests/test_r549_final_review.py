#!/usr/bin/env python3
"""r5.49: the post-polish final review (from the author's final-review rules v18 and a handoff of 11-05 about them).

It is one section of editing.md, used when the author asks for a final pass after polishing; each of its eight checks
points to the module that already covers it, keeps what the handoff said to keep, and sets no quotas. These tests pin
that: eight rows, every pointer lands on a section that exists, the verdicts, zero changes allowed, no counts, nothing
invented (no added pain, no made-up return of a borrowed thing), and the route in SKILL.md.
"""
import os
from pathlib import Path
import re
import sys
import unittest

sys.dont_write_bytecode = True
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"


def read(rel):
    return (SKILL / rel).read_text(encoding="utf-8")


def section():
    text = read("references/editing.md")
    start = text.index("## 精修后终审：查规则执行过头和补丁接缝（r5.49）")
    return text[start:text.index("\n## ", start + 4)]


class FinalReview(unittest.TestCase):
    def test_eight_rows_each_pointing_at_an_existing_section(self):
        rows = [line for line in section().splitlines() if line.startswith("| ") and not line.startswith("| 查什么")
                and not line.startswith("| ---")]
        self.assertEqual(len(rows), 8)
        for row in rows:
            cell = row.rstrip(" |").rsplit("|", 1)[1]
            links = re.findall(r"\[[^\]]+\]\(([^)]+\.md)\)((?:“[^”]+”)+)", cell)
            self.assertTrue(links, row)
            for target, titles in links:
                headings = [line.lstrip("#").strip() for line in read("references/" + target).splitlines()
                            if line.startswith("#")]
                for title in re.findall(r"“([^”]+)”", titles):
                    self.assertTrue(any(h.startswith(title) for h in headings), (target, title))

    def test_keeps_the_handoffs_limits(self):
        text = section()
        for phrase in ("明确矛盾／表达可选调整／证据不足／保留", "可以一处都不改", "不要求越审越短", "没有原稿只查当前稿",
                       "不说“恢复了原句”", "不一律换成痛觉", "没写归还不等于没还，不编归还", "不按“至少”“好在”“好歹”这些字判错",
                       "不设“一章几处”“每场一处”“留白几成”的配额", "不判断文本是不是 AI 写的", "平时不加这一步"):
            self.assertIn(phrase, text)
        self.assertIsNone(re.search(r"不得超过\s*\d|至少\s*\d+\s*处|30%", text))

    def test_the_route(self):
        self.assertIn("[editing.md](references/editing.md)“精修后终审”", read("SKILL.md"))


if __name__ == "__main__":
    unittest.main()

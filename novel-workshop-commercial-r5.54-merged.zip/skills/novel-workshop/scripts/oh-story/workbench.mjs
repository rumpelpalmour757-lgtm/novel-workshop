#!/usr/bin/env node
// 双击 open-workbench（只读）或 open-workbench-edit（可改稿）启动本地写作台，不用记命令行参数。
// 作品目录：命令行 --root，或上次用过的目录，或“文档/小说写作工坊”，都没有就问一次并记住。
// 记住的只是目录路径，存在本机用户配置目录的 workbench.json 里；不记文稿内容。

import { existsSync, statSync } from "node:fs";
import { mkdir, mkdtemp, readFile, writeFile } from "node:fs/promises";
import { homedir, tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { createInterface } from "node:readline/promises";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { configDirectory } from "./gemini-assist.mjs";

const HERE = dirname(fileURLToPath(import.meta.url));
const SERVER = join(HERE, "dashboard-server.mjs");
const DEFAULT_ROOT = join(homedir(), "Documents", "小说写作工坊");
const MIN_NODE = 18;

// 演示用的合成作品：工坊自己写的两小段，不是任何人的作品；只在 --demo 时写进系统临时目录。
const DEMO_FILES = {
  "README.md": "# 合成示例\n\n这是写作台自带的合成示例，不是任何人的作品，放在系统临时目录里。可以随便试：开始编辑、保存（会先备份）、草稿、对比、改稿建议。\n",
  "正文/第001章.md": "# 第一章 灯（合成示例）\n\n入秋以后，岬角上的灯一到半夜就闪两下灭一下。守灯的老魏把梯子靠上灯座，一级一级往上爬，腰上挂的工具袋叮当乱响。\n\n灯罩里积了一层死蛾子。他用袖口抹开玻璃，借着手电去看灯丝，灯丝好好的，倒是底座那颗接线螺丝松了半圈。\n",
  "正文/第002章.md": "# 第二章 船（合成示例）\n\n天快亮的时候，海面上漂过来一条没开灯的小船，桨架空着，船帮上搭着一件湿透的蓝布褂子。\n",
  "设定/岬角.md": "# 岬角（合成示例）\n\n- 灯塔在岬角最东头，离码头一里半。\n- 守灯人每月初一下山领一次煤油。\n",
};

export function nodeTooOld(version = process.versions.node) {
  return Number(String(version).split(".")[0]) < MIN_NODE;
}

export async function createDemoWorkspace(base = tmpdir()) {
  const folder = await mkdtemp(join(base, "novel-workshop-demo-"));
  const root = join(folder, "合成示例作品");
  for (const [relative, content] of Object.entries(DEMO_FILES)) {
    await mkdir(dirname(join(root, relative)), { recursive: true });
    await writeFile(join(root, relative), content, "utf8");
  }
  return root;
}

export function parseLauncherArguments(argv) {
  const options = { root: null, edit: null, demo: false };
  for (let index = 0; index < argv.length; index += 1) {
    const value = argv[index];
    if (value === "--root") options.root = argv[++index] || null;
    else if (value === "--edit") options.edit = true;
    else if (value === "--read-only") options.edit = false;
    else if (value === "--demo") options.demo = true;
    else if (!value.startsWith("--") && !options.root) options.root = value;
  }
  return options;
}

// Ctrl+C、Ctrl+Break（Windows）、关掉窗口时，写作台服务自己会收尾（结束它启动的官方程序、删掉临时目录）。
// 启动器不抢先退出，等服务退了再退；POSIX 上把信号转给服务（重复收到也只收尾一次），Windows 上不转
// （那边同一个控制台里的服务自己也收到；kill 会直接结束它，来不及收尾）。
export function launcherSignals(platform = process.platform) {
  return ["SIGINT", "SIGTERM", "SIGHUP", ...(platform === "win32" ? ["SIGBREAK"] : [])];
}

export function waitForServer(child, platform = process.platform) {
  for (const signal of launcherSignals(platform)) {
    process.on(signal, () => {
      if (platform === "win32") return;
      try {
        child.kill(signal);
      } catch {}
    });
  }
  child.on("exit", (code) => process.exit(code ?? 0));
}

function isDirectory(path) {
  try {
    return statSync(path).isDirectory();
  } catch {
    return false;
  }
}

async function rememberedRoot() {
  try {
    const saved = JSON.parse(await readFile(join(configDirectory(), "workbench.json"), "utf8"));
    return typeof saved?.root === "string" && isDirectory(saved.root) ? saved.root : null;
  } catch {
    return null;
  }
}

async function rememberRoot(root) {
  try {
    await mkdir(configDirectory(), { recursive: true, mode: 0o700 });
    await writeFile(join(configDirectory(), "workbench.json"), `${JSON.stringify({ root }, null, 2)}\n`, "utf8");
  } catch {
    // 记不住也不影响这次打开
  }
}

async function main() {
  if (nodeTooOld()) {
    console.error(`这台电脑的 Node.js 是 ${process.versions.node}，写作台需要 ${MIN_NODE} 或更新版本：到 https://nodejs.org 装新版后再双击。`);
    process.exitCode = 1;
    return;
  }
  const options = parseLauncherArguments(process.argv.slice(2));
  if (options.demo) {
    const root = await createDemoWorkspace();
    console.log(`合成示例放在：${root}`);
    console.log("这是写作台自带的合成示例，不是你的作品；可以随便改，关掉窗口后不会再用到它。");
    const child = spawn(process.execPath, [SERVER, "--root", root, "--open", "--allow-edit"], { stdio: "inherit" });
    waitForServer(child);
    return;
  }
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  try {
    let root = options.root ? resolve(options.root) : await rememberedRoot();
    if (!root && isDirectory(DEFAULT_ROOT)) root = DEFAULT_ROOT;
    while (!root || !isDirectory(root)) {
      if (root) console.log(`找不到这个文件夹：${root}`);
      const answer = (await rl.question("把作品所在的文件夹拖进这个窗口（或粘贴路径），然后按回车：")).trim().replace(/^["']|["']$/g, "");
      if (!answer) continue;
      root = resolve(answer);
    }
    let edit = options.edit;
    if (edit === null) {
      const answer = (await rl.question("直接按回车：只读打开。输入 2 再按回车：可以改稿（每次保存前自动备份）。")).trim();
      edit = answer === "2";
    }
    rl.close();
    await rememberRoot(root);
    console.log(edit ? "以可改稿方式打开；每份文稿先点“开始编辑”才能改。" : "以只读方式打开。要改稿，关掉这个窗口，双击 open-workbench-edit。");
    const args = [SERVER, "--root", root, "--open"];
    if (edit) args.push("--allow-edit");
    const child = spawn(process.execPath, args, { stdio: "inherit" });
    waitForServer(child);
  } finally {
    rl.close();
  }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url) && existsSync(SERVER)) {
  main().catch((error) => {
    console.error(`写作台没能启动：${error?.message || error}`);
    process.exitCode = 1;
  });
}

#!/usr/bin/env python3
"""r5.59: maintenance and acceptance material for dialogue and scenes.

The author read the r5.59 proposal and answered that the items put to him go as the workshop advised and that the
section 3 changes go ahead. This file covers the maintenance side:

1. The passages of module pages that hold the author's powers are locked (section 2, item 4, option A): the registry
   lists them under protected_sections, and darwin_eval.py compares each named section of the two arms at freeze; a
   changed, renamed, doubled or missing section blocks a "candidate better" verdict without the author's approval,
   exactly like a change to the constitution. The constitution text itself is not changed.
2. Eight dialogue and scene anchors (item 5, option A), new material, marked as not yet read by the author.
3. Two runs per held-out question (item 6, option A): runs of one question share a "group" and are merged first.
4. "Would following the current rules still fail?" before changing a rule (section 3, item 2): skill-evaluation.md,
   the maintenance SKILL.md and the feedback log template (cause, rule_ref, schema 2).
5. Regression cases for dialogue and scenes, and the no_new_dialogue check of detail_check.py (section 3, item 9).

These tests show that the records and checks are in place and do what their help says. They do not show that the
workshop writes better dialogue or scenes: that is for the author to judge, on the paired scenario tests and the
anchor runs. Every passage below is newly written for this file.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILLS = ROOT / "skills"
SKILL = SKILLS / "novel-workshop"
DARWIN = SKILLS / "darwin-novel-workshop"
EVAL = DARWIN / "scripts" / "darwin_eval.py"
CHECK = SKILL / "scripts" / "detail_check.py"
REGISTRY = SKILL / "assets" / "constitution-rules.json"
ANCHORS = DARWIN / "assets" / "dialogue-scene-anchors.json"
NEW_AND_UNREAD = "工坊新编，措辞作者还没看过"
PROTECTED = [
    ("novel-workshop/references/learning-loop.md", "取舍由谁定", "第 4—7 条", "r5.58_lines", "33-36"),
    ("novel-workshop/references/quality-loop.md", "交付状态：四项分开，未测不算通过", "作者收回采纳（r5.57）及下面五条", "r5.58_lines",
     "99-104"),
    ("novel-workshop/references/teacher-review.md", "2. 每一处：记一类，写拟处置，写谁来定", "表格里“只有作者”那一行", "r5.58_lines", "34"),
    ("novel-workshop/references/editorial-judgment.md", "边界", "第 1、2、5 条", "r5.58_lines", "198, 199, 202"),
    ("novel-workshop/references/author-preferences.md", "从一次纠错提炼规则", "第 1、3 步", "r5.59_lines", "57, 59"),
    ("novel-workshop/references/chapter-confirmation.md", "确认是什么意思", "整节", "r5.59_lines", "53-60"),
]
# r5.59 itself changes two of the locked passages, both approved with the rest of the proposal: an exception after the
# "作者改了来源、方案或正文" line of chapter-confirmation.md (section 2, item 3, option B, with the maker's follow-ups on
# a chapter that still goes to the teacher and on the author's revision at stage 6) and a sentence at the end of
# step 3 of author-preferences.md (section 3, item 4). The proposal recorded the r5.58 text for every entry. r5.59
# wrap-up (the maker's decisions, section 6, item 2): what the author locks now is the r5.59 text of these two, so their
# entries give r5.59_lines and the sha256 of those lines of the r5.59 file; the other four keep the r5.58 record. The
# r5.58 hashes the two entries carried before are kept here to show they were replaced.
CHANGED_IN_R559 = {"novel-workshop/references/author-preferences.md", "novel-workshop/references/chapter-confirmation.md"}
R558_SHA256 = {"novel-workshop/references/author-preferences.md":
               "15656cb835fe262a5ad6db68116ae986c44d596846c6011911cb118a967eeefc",
               "novel-workshop/references/chapter-confirmation.md":
               "4ad431d54b0e50d52a36a33658cf5f5e4555270f3ab3c8eb0e6c1f640bf5cfe6"}

# r5.59, after the paired scenario tests: the exception began "第 5 阶段还没确认的时候", which read as covering stage 4
# too (a draft handed over, the teacher's result not back yet). On both stage-4 questions r5.58 was right four times out
# of four and r5.59 partly right four times out of four (each time for taking the exception at stage 4). The author
# chose to narrow it: only while stage 4 is confirmed and stage 5 is not, or stage 5 is confirmed and stage 6 is not;
# at stage 4 the author's text is a new draft. The locked section changed again, so the entry's sha256 is the hash of
# the narrowed lines (still 53-60), and the sentence pinned here is the narrowed opening. The hash the entry carried
# before the narrowing is kept to show it was replaced.
# r5.59, wording fix before release: the narrowed opening now also says that on a chapter whose draft the author
# takes to the teacher the teacher return must already be registered, so the pinned sentence and NARROWED_SHA256
# are those of the reworded lines (still 53-60).
# r5.59, second wording fix before release: the bullet says the stage-4 sentence is for the author's own text handed
# back alone, and how a chapter recorded as not going to the teacher and a teacher's result brought back with the
# author's text are handled; the pinned sentence is unchanged and NARROWED_SHA256 is that of the reworded lines
# (still 53-60).
# r5.59, third wording fix before release: the bullet was reworded once more (the chapter recorded as not
# going to the teacher, and the "不交教师了" sentence); the pinned sentence is unchanged and NARROWED_SHA256 is
# that of the reworded lines (still 53-60).
R559_SENTENCE = {"novel-workshop/references/author-preferences.md": "作者划掉的归纳，记进“已撤销”，写明是作者划掉的",
                 "novel-workshop/references/chapter-confirmation.md": "例外（r5.59）：第 4 阶段已经确认、第 5 阶段还没确认的时候（初稿由作者交教师的章，还要已经登记了教师回传）"}
BEFORE_NARROWING_SHA256 = "f8998fb155ab91bce9b663af497feb6da8ee7ef9c7d51a9eb1c5d90d388000e6"
NARROWED_SHA256 = "e73b02c0181c6f18221885f9c5f9a0aee2008745a4850269919272d4f9a8de72"


def line_numbers(spec):
    numbers = [int(n) for n in re.findall(r"\d+", spec)]
    return list(range(numbers[0], numbers[1] + 1)) if "-" in spec else numbers
WOULD_IT_STILL_FAIL = (
    "改规则以前先问：照现在的规则认真做，还会不会出这种错？会，说明规则缺了、写错了或范围不清，再改；不会，就是这一次"
    "没照做，改的是读取和查验（入口指没指过去、写前准备的必查项、交付门卡、在审稿记录的 note 里写明看了哪一节；交付门绑定"
    "的五个脚本不在此列），不另加规则。能改原来那一句的，不另加一段；新加的写明替掉了哪一句。查下来哪条都不用改，也算这一"
    "轮做完，逐条写明为什么不改。作者明说要加的照作者的，这一问只管工坊自己提的改动。")


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


darwin = load(EVAL, "r559_darwin_eval")
detail = load(CHECK, "r559_detail_check")


def read(path):
    return Path(path).read_text(encoding="utf-8")


def write(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.encode("utf-8"))
    return path


def section(text, heading):
    return text.split("\n" + heading + "\n", 1)[1].split("\n## ", 1)[0]


def check(*args):
    proc = subprocess.run([sys.executable, "-I", "-B", str(CHECK), *map(str, args)], capture_output=True, text=True,
                          encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


class Eval(unittest.TestCase):
    """Two arms in a temporary folder and the darwin_eval functions called directly."""

    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        self.base, self.cand = self.dir / "base", self.dir / "cand"

    def tearDown(self):
        shutil.rmtree(self.dir)

    def copy_arms(self):
        files = ["novel-workshop/CONSTITUTION.md", "novel-workshop/assets/constitution-rules.json"]
        files += [entry[0] for entry in PROTECTED]
        for arm in (self.base, self.cand):
            for name in files:
                target = arm / name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(SKILLS / name, target)

    def edit(self, name, old, new):
        path = self.cand / name
        text = read(path)
        self.assertEqual(text.count(old), 1, old)
        write(path, text.replace(old, new))

    def tasks(self, work, tasks, dimensions=None):
        write(work / "TASKS.json", json.dumps({"tasks": tasks, "dimensions": dimensions or [
            {"id": "facts", "hard": True}, {"id": "prose", "hard": False}]}, ensure_ascii=False))

    def judge(self, work, task, results, mode="independent_agent"):
        record = json.loads(read(work / "sealed" / (task + ".mapping.json")))
        label = {arm: letter for letter, arm in record["mapping"].items()}
        # r5.59: the verdict names the A/B files it was made on (the hashes blind returned; test_r559_verdict_packets.py)
        verdict = {"task": task, "judge": {"mode": mode, "label": "测试评审"},
                   "packets": {letter: item["sha256"] for letter, item in record["packets"].items()},
                   "dimensions": {dim: {"result": label.get(arm, arm), "evidence": "“雾散了。”"}
                                  for dim, arm in results.items()}}
        darwin.record_verdict(work, task, write(self.dir / "verdict.json", json.dumps(verdict, ensure_ascii=False)))
        darwin.unblind(work, task)

    def run_tasks(self, work, verdicts, approval=None, tasks=None):
        """Freeze, then blind, judge and reveal each task; verdicts maps a task to {dimension: winning arm or tie}."""
        self.tasks(work, tasks or [{"id": task, "split": "holdout"} for task in verdicts])
        record = darwin.freeze(work, self.base, self.cand, approval)
        for n, (task, results) in enumerate(verdicts.items()):
            out = self.dir / "out" / task
            darwin.blind(work, task, write(out / "base.md", "雾散了。旧%d\n" % n),
                         write(out / "cand.md", "雾散了。新%d\n" % n), seed=n)
            self.judge(work, task, results)
        return record, darwin.summarize(work)

    def approval(self):
        return write(self.dir / "approval.json", json.dumps({
            "author_decision": "测试材料：作者批准这一处改动", "source": "测试材料", "scope": "这一节"}, ensure_ascii=False))


# ------------------------------------------------------------------ 1. protected sections (section 2, item 4)
class ProtectedSectionsRegistry(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.registry = json.loads(read(REGISTRY))
        cls.entries = cls.registry["protected_sections"]

    def test_the_six_entries_as_drafted(self):
        # r5.59 wrap-up: the two sections r5.59 changed record r5.59_lines instead of r5.58_lines (see CHANGED_IN_R559)
        self.assertEqual([(e["file"], e["section"], e["part"], list(e)[3], e[list(e)[3]]) for e in self.entries], PROTECTED)
        for entry in self.entries:
            lines = "r5.59_lines" if entry["file"] in CHANGED_IN_R559 else "r5.58_lines"
            self.assertEqual(list(entry), ["file", "section", "part", lines, "sha256"])
            self.assertRegex(entry["sha256"], "^[0-9a-f]{64}$")
        # next to protected_files; the constitution text and the priority lists are not touched by it
        self.assertEqual(list(self.registry)[5:7], ["protected_files", "protected_sections"])
        self.assertEqual(self.registry["protected_files"],
                         ["novel-workshop/CONSTITUTION.md", "novel-workshop/assets/constitution-rules.json"])
        self.assertIn("protected_sections (r5.59, approved by the author on 2026-11-19)", self.registry["note"])
        self.assertIn("sha256 of those lines of the r5.58 file, each with its line break, joined in order",
                      self.registry["note"])
        self.assertIn("r5.59 changed two of these sections itself, as the approved plan says", self.registry["note"])
        self.assertIn("the author locks them as they stand in r5.59, so those two entries give r5.59_lines and the sha256 "
                      "of those lines of the r5.59 file instead.", self.registry["note"])
        # the constitution's version stays NWC-1.8: the constitution text is not changed (decisions, section 6, item 1)
        self.assertEqual(self.registry["version"], "NWC-1.8")

    def test_each_section_is_found_once(self):
        for entry in self.entries:
            with self.subTest(entry=entry["file"]):
                found = darwin.section_of(read(SKILLS / entry["file"]), entry["section"])
                self.assertNotIn(found, ("missing", "ambiguous"))
                self.assertTrue(found.startswith("#"))

    def test_the_recorded_hashes_are_of_the_r558_lines(self):
        # Where r5.59 left the passage as it was, the same lines (shifted by what r5.59 added above them) give the
        # recorded hash. r5.59 wrap-up (decisions, section 6, item 2): the two passages r5.59 changes with the author's
        # approval record the r5.59 lines and their hash, which replaces the r5.58 one.
        for entry in self.entries:
            lines = read(SKILLS / entry["file"]).split("\n")
            with self.subTest(entry=entry["file"]):
                if entry["file"] in CHANGED_IN_R559:
                    numbers = line_numbers(entry["r5.59_lines"])
                    text = "".join(lines[n - 1] + "\n" for n in numbers)
                    self.assertEqual(hashlib.sha256(text.encode("utf-8")).hexdigest(), entry["sha256"])
                    self.assertNotEqual(entry["sha256"], R558_SHA256[entry["file"]])
                    # the recorded lines are the locked part of the section as it reads now, r5.59's sentences included
                    section_text = darwin.section_of(read(SKILLS / entry["file"]), entry["section"])
                    for number in numbers:
                        self.assertIn(lines[number - 1], section_text)
                    self.assertIn(R559_SENTENCE[entry["file"]], text)
                    continue
                numbers = line_numbers(entry["r5.58_lines"])
                hashes = {hashlib.sha256("".join(lines[n - 1 + shift] + "\n" for n in numbers).encode("utf-8")).hexdigest()
                          for shift in range(-60, 200) if 0 < numbers[0] + shift and numbers[-1] + shift <= len(lines)}
                self.assertIn(entry["sha256"], hashes)

    def test_the_lock_follows_the_narrowed_exception(self):
        # r5.59, after the paired scenario tests (see R559_SENTENCE): the lock on chapter-confirmation.md
        # "确认是什么意思" holds the narrowed text. The registry's hash is that of lines 53-60 of the page as it stands,
        # each with its line break (the way the note says), and it is no longer the hash before the narrowing.
        entry = next(e for e in self.entries if e["file"] == "novel-workshop/references/chapter-confirmation.md")
        self.assertEqual((entry["section"], entry["part"], entry["r5.59_lines"]), ("确认是什么意思", "整节", "53-60"))
        self.assertEqual(entry["sha256"], NARROWED_SHA256)
        self.assertNotEqual(entry["sha256"], BEFORE_NARROWING_SHA256)
        page = read(SKILLS / entry["file"])
        lines = page.split("\n")
        locked = "".join(lines[n - 1] + "\n" for n in line_numbers(entry["r5.59_lines"]))
        self.assertEqual(hashlib.sha256(locked.encode("utf-8")).hexdigest(), entry["sha256"])
        self.assertEqual(lines[51], "## 确认是什么意思")  # the heading sits right above the locked lines
        self.assertTrue(lines[61].startswith("## "))  # and the next section starts right after them
        self.assertIn("这条例外只管这两种时候。", locked)
        self.assertNotIn("作者的稿子先留着、不登记", locked)
        # the section darwin_eval.py compares at freeze is found once and holds the same lines
        found = darwin.section_of(page, entry["section"])
        self.assertTrue(found.startswith("## 确认是什么意思\n"))
        self.assertEqual(found, "\n".join(lines[51:60]).rstrip())

    def test_the_parts_say_what_the_author_locked(self):
        text = {entry["file"]: darwin.section_of(read(SKILLS / entry["file"]), entry["section"]) for entry in self.entries}
        self.assertIn("4. **作者本人的否定意见不能由工坊驳回。**", text["novel-workshop/references/learning-loop.md"])
        self.assertIn("- **作者收回采纳（r5.57）。**", text["novel-workshop/references/quality-loop.md"])
        self.assertIn("台词里添的话、删的话 | 只有作者", text["novel-workshop/references/teacher-review.md"])
        self.assertIn("2. **候选卡不进写作上下文。**", text["novel-workshop/references/editorial-judgment.md"])
        self.assertIn("AI 自拟稿、自查通过、作者沉默或直接要下一章，都不算作者认可。",
                      text["novel-workshop/references/author-preferences.md"])
        self.assertIn("“我先看看”、否定、暂缓、含糊的反馈，不记成接受。", text["novel-workshop/references/chapter-confirmation.md"])

    def test_the_docs_say_so(self):
        skill = read(DARWIN / "SKILL.md")
        self.assertIn("登记表 `protected_sections` 列着的几节，是各模块里保护作者权限的条文", skill)
        self.assertIn("改了一个字、挪了一句、在中间或末尾多加一句，标题改了、找不到或者出现两次，都算改了", skill)
        self.assertIn("两版登记表的清单都读，候选从清单上删掉的一节照样核。", skill)
        # r5.59 review: the limit of the check is written down, and line ends do not count
        self.assertIn("反过来，节外的话不核：写在这一节标题前面（上一节的末尾）、紧跟着另起的同级或更高一级的一节、别的页里改它意思的话，"
                      "`sections_changed` 都不列，看维护差异时要人读。", skill)
        self.assertIn("先统一成 LF 再比，只换了换行、内容没改的不算改了。", skill)
        self.assertIn("评测工具只核清单上那几节本身：写在这一节标题前面、紧跟着另起的一节、别的页里改它意思的话，它查不出，看维护差异时要人读。",
                      read(SKILL / "references" / "skill-evaluation.md"))
        self.assertIn("或者登记表 `protected_sections` 列着的那几节（各模块里保护作者权限的条文，r5.59），也一样。",
                      read(SKILL / "references" / "skill-evaluation.md"))
        self.assertIn("protected_sections", read(EVAL))


class ProtectedSectionsBlock(Eval):
    LOOP = "novel-workshop/references/learning-loop.md"
    CONFIRM = "novel-workshop/references/chapter-confirmation.md"
    LOCKED = "4. **作者本人的否定意见不能由工坊驳回。**"

    def setUp(self):
        super().setUp()
        self.copy_arms()

    def win(self, approval=None):
        return self.run_tasks(self.dir / "work", {"h1": {"facts": "tie", "prose": "candidate"}}, approval)

    def test_turning_a_locked_sentence_around_blocks(self):
        # The proposal's trial: line 33 of learning-loop.md turned into its opposite went through unnoticed in r5.58.
        self.edit(self.LOOP, self.LOCKED, "4. **作者本人的否定意见，工坊认为不成立的可以记 decline。**")
        record, summary = self.win()
        self.assertEqual(record["governance"]["changed"], [])
        self.assertEqual(record["governance"]["sections_changed"], [self.LOOP + " § 取舍由谁定"])
        self.assertTrue(summary["decision"].startswith("BLOCKED_CONSTITUTION_CHANGE"), summary["decision"])
        self.assertIn("the protected section " + self.LOOP + " § 取舍由谁定", summary["decision"])
        self.assertEqual(summary["governance"]["sections_changed"], [self.LOOP + " § 取舍由谁定"])
        # with the author's approval recorded at freeze, the comparison decides as usual
        shutil.rmtree(self.dir / "work")
        record, summary = self.win(self.approval())
        self.assertTrue(summary["decision"].startswith("CANDIDATE_BETTER"), summary["decision"])
        self.assertTrue(summary["governance"]["approved"])

    def test_an_exception_added_at_the_end_of_a_section_blocks(self):
        # the sentences stay as they were; one more line at the end of the section
        self.edit(self.CONFIRM, "\n\n## 视觉准备（第 3 阶段）",
                  "\n- 例外：工坊判断作者会同意的，可以先记确认，事后再告诉作者。\n\n## 视觉准备（第 3 阶段）")
        record, summary = self.win()
        self.assertEqual(record["governance"]["sections_changed"], [self.CONFIRM + " § 确认是什么意思"])
        self.assertTrue(summary["decision"].startswith("BLOCKED_CONSTITUTION_CHANGE"))

    def test_a_new_item_next_to_the_locked_ones_blocks(self):
        self.edit(self.LOOP, "\n8. **取舍可以在改稿以前更正。**",
                  "\n8. **例外。** 作者的否定意见和本页别处冲突的，工坊可以先记 decline。\n9. **取舍可以在改稿以前更正。**")
        record, _ = self.win()
        self.assertEqual(record["governance"]["sections_changed"], [self.LOOP + " § 取舍由谁定"])

    def test_a_renamed_or_doubled_heading_blocks(self):
        name = "novel-workshop/references/editorial-judgment.md"
        self.edit(name, "\n## 边界\n", "\n## 边界（r5.60）\n")
        record, _ = self.win()
        entry = next(e for e in record["governance"]["sections"] if e["file"] == name)
        self.assertEqual((entry["baseline"] != "missing", entry["candidate"], entry["status"]),
                         (True, "missing", "missing_or_ambiguous"))
        self.assertEqual(record["governance"]["sections_changed"], [name + " § 边界"])
        shutil.rmtree(self.dir / "work")
        self.edit(name, "\n## 边界（r5.60）\n", "\n## 边界\n\n新加的一节。\n\n## 边界\n")
        record, _ = self.win()
        entry = next(e for e in record["governance"]["sections"] if e["file"] == name)
        self.assertEqual(entry["candidate"], "ambiguous")

    def test_other_sections_stay_free(self):
        self.edit(self.LOOP, "\n## 唯一记录\n", "\n## 唯一记录\n\n这一节加了一句说明（测试）。\n")
        record, summary = self.win()
        self.assertEqual(record["governance"]["sections_changed"], [])
        self.assertEqual({e["status"] for e in record["governance"]["sections"]}, {"unchanged"})
        self.assertEqual(len(record["governance"]["sections"]), 6)
        self.assertTrue(summary["decision"].startswith("CANDIDATE_BETTER"), summary["decision"])

    def test_dropping_an_entry_from_the_list_does_not_unlock_it(self):
        registry = "novel-workshop/assets/constitution-rules.json"
        text = read(self.cand / registry)
        line = next(l for l in text.splitlines() if self.LOOP in l and "取舍由谁定" in l)
        write(self.cand / registry, text.replace(line + "\n", ""))
        self.edit(self.LOOP, self.LOCKED, "4. **作者本人的否定意见，工坊可以驳回。**")
        record, summary = self.win()
        self.assertEqual(record["governance"]["changed"], [registry])
        self.assertEqual(record["governance"]["sections_changed"], [self.LOOP + " § 取舍由谁定"])
        entry = next(e for e in record["governance"]["sections"] if e["file"] == self.LOOP)
        self.assertEqual(entry["listed_by"], ["baseline"])
        self.assertTrue(summary["decision"].startswith("BLOCKED_CONSTITUTION_CHANGE"))

    def test_a_list_that_cannot_be_read_blocks(self):
        for arm in (self.base, self.cand):
            path = arm / "novel-workshop" / "assets" / "constitution-rules.json"
            data = json.loads(read(path))
            data["protected_sections"] = "learning-loop.md"
            write(path, json.dumps(data, ensure_ascii=False))
        write(self.cand / "novel-workshop" / "SKILL.md", "候选")
        record, summary = self.win()
        self.assertEqual(len(record["governance"]["sections_changed"]), 2)
        self.assertTrue(all("protected_sections must be a list" in p for p in record["governance"]["sections_changed"]))
        self.assertTrue(summary["decision"].startswith("BLOCKED_CONSTITUTION_CHANGE"))

    def crlf(self, arm, names):
        for name in names:
            path = arm / name
            path.write_bytes(path.read_bytes().replace(b"\r\n", b"\n").replace(b"\n", b"\r\n"))

    def again(self):
        shutil.rmtree(self.dir / "work", ignore_errors=True)
        self.copy_arms()

    def test_line_ends_and_a_bom_are_not_a_change(self):
        # r5.59 review: a Windows checkout (CRLF) made every section "missing" and blocked with nothing changed
        pages = [entry[0] for entry in PROTECTED]
        registry = "novel-workshop/assets/constitution-rules.json"
        self.crlf(self.base, pages)
        self.crlf(self.cand, pages)
        for arm in (self.base, self.cand):
            (arm / registry).write_bytes(b"\xef\xbb\xbf" + (arm / registry).read_bytes())
        write(self.cand / "novel-workshop" / "SKILL.md", "候选")
        record, summary = self.win()
        self.assertEqual((record["governance"]["changed"], record["governance"]["sections_changed"]), ([], []))
        self.assertEqual([e["status"] for e in record["governance"]["sections"]], ["unchanged"] * 6)
        self.assertTrue(summary["decision"].startswith("CANDIDATE_BETTER"), summary["decision"])
        # only the candidate saved again with CRLF, one page with a BOM too: the words are the same
        self.again()
        self.crlf(self.cand, pages)
        page = self.cand / self.LOOP
        page.write_bytes(b"\xef\xbb\xbf" + page.read_bytes())
        record, summary = self.win()
        self.assertEqual(record["governance"]["sections_changed"], [])
        self.assertTrue(summary["decision"].startswith("CANDIDATE_BETTER"), summary["decision"])
        # a real change on a CRLF page still counts
        self.again()
        self.crlf(self.cand, pages)
        page = self.cand / self.LOOP
        data = page.read_bytes()
        self.assertIn(b"\r\n", data)
        page.write_bytes(data.replace(self.LOCKED.encode("utf-8"), "4. **作者本人的否定意见，工坊可以驳回。**".encode("utf-8")))
        record, summary = self.win()
        self.assertEqual(record["governance"]["sections_changed"], [self.LOOP + " § 取舍由谁定"])
        self.assertTrue(summary["decision"].startswith("BLOCKED_CONSTITUTION_CHANGE"))

    def test_words_outside_the_section_are_not_compared(self):
        # r5.59 review: what the pages now say the tool does not see; a reviewer reads the diff for these
        for label, old, new in (
                ("above the heading", "\n## 取舍由谁定\n", "\n下文“取舍由谁定”第 4 条已经停用。\n\n## 取舍由谁定\n"),
                ("a section right after", "\n## 唯一记录\n",
                 "\n## 取舍由谁定的例外\n\n- 作者的否定意见，工坊认为不成立的可以记 decline。\n\n## 唯一记录\n")):
            with self.subTest(label):
                self.again()
                self.edit(self.LOOP, old, new)
                record, summary = self.win()
                self.assertEqual(record["governance"]["sections_changed"], [])
                self.assertTrue(summary["decision"].startswith("CANDIDATE_BETTER"), summary["decision"])

    def test_a_path_written_another_way_blocks(self):
        # r5.59 review: the entries name files the way the frozen tree does (relative, "/", nothing to resolve)
        registry = "novel-workshop/assets/constitution-rules.json"
        for written in ("./novel-workshop/references/learning-loop.md", "novel-workshop/../novel-workshop/references/learning-loop.md",
                        "novel-workshop\\references\\learning-loop.md", "/novel-workshop/references/learning-loop.md", ""):
            with self.subTest(written=written):
                self.again()
                for arm in (self.base, self.cand):
                    data = json.loads(read(arm / registry))
                    data["protected_sections"][0]["file"] = written
                    write(arm / registry, json.dumps(data, ensure_ascii=False))
                write(self.cand / "novel-workshop" / "SKILL.md", "候选")
                record, summary = self.win()
                self.assertEqual(record["governance"]["changed"], [])
                self.assertEqual(record["governance"]["sections_changed"], [
                    "%s (%s): protected_sections must be a list of entries with a relative file and a section heading"
                    % (registry, arm) for arm in ("baseline", "candidate")])
                self.assertTrue(summary["decision"].startswith("BLOCKED_CONSTITUTION_CHANGE"))

    def test_a_registry_that_is_not_json_blocks(self):
        registry = "novel-workshop/assets/constitution-rules.json"
        for arm in (self.base, self.cand):
            write(arm / registry, "{\"protected_sections\": [")
        write(self.cand / "novel-workshop" / "SKILL.md", "候选")
        record, summary = self.win()
        self.assertEqual(record["governance"]["sections_changed"], [
            "%s (%s): the registry is not readable JSON" % (registry, arm) for arm in ("baseline", "candidate")])
        self.assertTrue(summary["decision"].startswith("BLOCKED_CONSTITUTION_CHANGE"))

    def test_the_command_line_shows_it(self):
        self.edit(self.LOOP, self.LOCKED, "4. **作者本人的否定意见，工坊可以驳回。**")
        work = self.dir / "cli"
        proc = subprocess.run([sys.executable, "-I", "-B", str(EVAL), "freeze", str(work), "--baseline", str(self.base),
                               "--candidate", str(self.cand)], capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        self.assertEqual(json.loads(proc.stdout)["governance"]["sections_changed"], [self.LOOP + " § 取舍由谁定"])


class SectionsOfAPage(unittest.TestCase):
    PAGE = ("# 页\n\n## 甲\n\n一句。\n\n```\n## 不是标题\n```\n\n### 甲下面\n\n两句。\n\n## 乙\n\n三句。\n")

    def test_a_section_runs_to_the_next_heading_of_its_level(self):
        self.assertEqual(darwin.section_of(self.PAGE, "甲"),
                         "## 甲\n\n一句。\n\n```\n## 不是标题\n```\n\n### 甲下面\n\n两句。")
        self.assertEqual(darwin.section_of(self.PAGE, "甲下面"), "### 甲下面\n\n两句。")
        self.assertEqual(darwin.section_of(self.PAGE, "乙"), "## 乙\n\n三句。")
        self.assertEqual(darwin.section_of(self.PAGE, "不是标题"), "missing")
        self.assertEqual(darwin.section_of(self.PAGE + "\n## 乙\n", "乙"), "ambiguous")

    def test_line_ends_and_a_bom_read_as_lf(self):
        # r5.59 review: CRLF (a Windows checkout), CR and a leading BOM give the same section as LF
        for page in (self.PAGE.replace("\n", "\r\n"), self.PAGE.replace("\n", "\r"), "\ufeff" + self.PAGE):
            with self.subTest(page=page[:6]):
                self.assertEqual(darwin.section_of(page, "甲"), darwin.section_of(self.PAGE, "甲"))
        self.assertEqual(darwin.section_of("\ufeff## 甲\r\n\r\n一句。\r\n", "甲"), "## 甲\n\n一句。")

    def test_arms_without_the_list_are_compared_as_before(self):
        with tempfile.TemporaryDirectory() as tmp:
            base, cand = Path(tmp) / "b", Path(tmp) / "c"
            write(base / "SKILL.md", "旧规则")
            write(cand / "SKILL.md", "新规则")
            record = darwin.freeze(Path(tmp) / "work", base, cand)
            self.assertEqual((record["governance"]["changed"], record["governance"]["sections"],
                              record["governance"]["sections_changed"]), ([], [], []))


# ------------------------------------------------------------------ 3. two runs per question (section 2, item 6)
class Groups(Eval):
    def setUp(self):
        super().setUp()
        write(self.base / "SKILL.md", "旧规则")
        write(self.cand / "SKILL.md", "新规则")

    def test_the_merge_rule(self):
        table = [(("improved", "regressed"), False, "insufficient"), (("improved", "regressed"), True, "regressed"),
                 (("improved", "same"), False, "improved"), (("improved", "insufficient"), False, "improved"),
                 (("improved", "untested"), False, "untested"), (("regressed", "same"), False, "regressed"),
                 (("regressed", "untested"), False, "regressed"), (("same", "same"), True, "same"),
                 (("same", "insufficient"), True, "insufficient"), (("improved", "improved"), True, "improved"),
                 (("untested", "untested"), False, "untested")]
        for values, hard, expected in table:
            with self.subTest(values=values, hard=hard):
                self.assertEqual(darwin.merge_runs(list(values), hard), expected)

    def test_the_registry_is_checked(self):
        dims = [{"id": "facts", "hard": True}, {"id": "prose"}]
        for tasks, message in (
                ([{"id": "a1", "split": "holdout", "group": "a"}], "has one task"),
                ([{"id": "a1", "split": "holdout", "group": "a"}, {"id": "a2", "split": "dev", "group": "a"}], "mixes dev"),
                ([{"id": "a1", "split": "holdout", "group": "a"},
                  {"id": "a2", "split": "holdout", "group": "a", "dimensions": ["prose"]}], "different dimensions"),
                ([{"id": "a1", "split": "holdout", "group": "a"}, {"id": "a2", "split": "holdout", "group": "a"},
                  {"id": "a", "split": "holdout"}], "id of a task outside it"),
                ([{"id": "a1", "split": "holdout", "group": "a/b"}, {"id": "a2", "split": "holdout", "group": "a/b"}],
                 "valid id")):
            with self.subTest(message=message):
                with self.assertRaisesRegex(darwin.EvalError, message):
                    darwin.validate_registry({"tasks": tasks, "dimensions": dims})

    def test_runs_of_one_question_count_once(self):
        # Ungrouped, four runs give 2 improved against 1 regressed and the candidate would be better; as two questions
        # run twice each, one improved and one regressed, so there is no clear improvement.
        verdicts = {"a1": {"facts": "tie", "prose": "candidate"}, "a2": {"facts": "tie", "prose": "candidate"},
                    "b1": {"facts": "tie", "prose": "baseline"}, "b2": {"facts": "tie", "prose": "tie"}}
        tasks = [{"id": task, "split": "holdout", "group": task[0]} for task in verdicts]
        _, summary = self.run_tasks(self.dir / "grouped", verdicts, tasks=tasks)
        self.assertTrue(summary["decision"].startswith("NO_CLEAR_IMPROVEMENT"), summary["decision"])
        self.assertEqual((summary["improved"], summary["regressed"], summary["holdout"]["same"]), (1, 1, 2))
        self.assertEqual(summary["questions"], [
            {"task": "a", "split": "holdout", "runs": ["a1", "a2"], "independent": True,
             "results": {"facts": "same", "prose": "improved"}},
            {"task": "b", "split": "holdout", "runs": ["b1", "b2"], "independent": True,
             "results": {"facts": "same", "prose": "regressed"}}])
        self.assertEqual(summary["holdout_tasks_judged"], 2)
        self.assertEqual([row["group"] for row in summary["rows"]], ["a", "a", "b", "b"])
        self.assertIn("报告里照实写几次", summary["group_rule"])
        _, plain = self.run_tasks(self.dir / "plain", verdicts)
        self.assertTrue(plain["decision"].startswith("CANDIDATE_BETTER"), plain["decision"])
        self.assertEqual((plain["improved"], plain["regressed"]), (2, 1))
        self.assertNotIn("questions", plain)
        self.assertNotIn("group_rule", plain)
        self.assertTrue(all("group" not in row for row in plain["rows"]))

    def test_both_ways_is_insufficient_and_a_hard_regression_stays(self):
        verdicts = {"a1": {"facts": "tie", "prose": "candidate"}, "a2": {"facts": "tie", "prose": "baseline"}}
        tasks = [{"id": task, "split": "holdout", "group": "a"} for task in verdicts]
        _, summary = self.run_tasks(self.dir / "soft", verdicts, tasks=tasks)
        self.assertEqual(summary["questions"][0]["results"], {"facts": "same", "prose": "insufficient"})
        self.assertTrue(summary["decision"].startswith("NO_CLEAR_IMPROVEMENT"), summary["decision"])
        verdicts = {"a1": {"facts": "baseline", "prose": "candidate"}, "a2": {"facts": "candidate", "prose": "candidate"}}
        _, summary = self.run_tasks(self.dir / "hard", verdicts, tasks=tasks)
        self.assertEqual(summary["questions"][0]["results"], {"facts": "regressed", "prose": "improved"})
        self.assertTrue(summary["decision"].startswith("KEEP_BASELINE"), summary["decision"])
        self.assertEqual(summary["hard_regressions"],
                         [{"task": "a", "dimension": "facts", "split": "holdout", "independent": True}])

    def test_a_run_not_yet_judged_leaves_the_question_untested(self):
        self.tasks(self.dir / "work", [{"id": "a1", "split": "holdout", "group": "a"},
                                       {"id": "a2", "split": "holdout", "group": "a"}])
        darwin.freeze(self.dir / "work", self.base, self.cand)
        out = self.dir / "out"
        darwin.blind(self.dir / "work", "a1", write(out / "b.md", "旧\n"), write(out / "c.md", "新\n"), seed=1)
        self.judge(self.dir / "work", "a1", {"facts": "candidate", "prose": "candidate"})
        summary = darwin.summarize(self.dir / "work")
        self.assertEqual(summary["questions"][0]["results"], {"facts": "untested", "prose": "untested"})
        self.assertEqual(summary["holdout_tasks_judged"], 0)
        self.assertTrue(summary["decision"].startswith("INSUFFICIENT_EVIDENCE"), summary["decision"])

    def test_a_self_check_in_a_group_is_not_an_independent_question(self):
        # r5.59 review: a group counts as independently judged only when every run was (all, not any); a self-check
        # stays a diagnostic and does not count toward the held-out tally or its hard constraints
        work = self.dir / "work"
        self.tasks(work, [{"id": "a1", "split": "holdout", "group": "a"}, {"id": "a2", "split": "holdout", "group": "a"}])
        darwin.freeze(work, self.base, self.cand)
        out = self.dir / "out"
        for n, (task, mode) in enumerate((("a1", "independent_agent"), ("a2", "self_check"))):
            darwin.blind(work, task, write(out / task / "b.md", "旧%d\n" % n), write(out / task / "c.md", "新%d\n" % n), seed=n)
            self.judge(work, task, {"facts": "candidate", "prose": "candidate"}, mode=mode)
        summary = darwin.summarize(work)
        self.assertEqual(summary["questions"], [
            {"task": "a", "split": "holdout", "runs": ["a1", "a2"], "independent": False,
             "results": {"facts": "improved", "prose": "improved"}}])
        self.assertEqual(summary["holdout"], dict.fromkeys(darwin.OUTCOMES, 0))
        self.assertEqual((summary["holdout_tasks_judged"], summary["holdout_tasks_independently_judged"]), (1, 0))
        self.assertEqual(summary["holdout_hard_gaps"],
                         [{"task": "a", "dimension": "facts", "reason": "not_independently_judged"}])
        self.assertTrue(summary["decision"].startswith("INSUFFICIENT_EVIDENCE"), summary["decision"])
        self.assertEqual([row["independent"] for row in summary["rows"]], [True, False])

    def test_the_rule_is_written_where_maintenance_reads_it(self):
        evaluation = read(SKILL / "references" / "skill-evaluation.md")
        step = next(line for line in evaluation.splitlines() if line.startswith("2. 保存两边实际输出与失败记录"))
        for phrase in ("每道留出题新旧两边各跑两次（r5.59）",
                       "同一道题两次方向不一致的（一次改善、一次退步），这道题记“证据不足”；两次都没有退步、至少一次改善的，才记“改善”",
                       "两次也说不上稳定，只是少碰巧一点，报告里照实写“两次”。", "`group`"):
            self.assertIn(phrase, step)
        skill = read(DARWIN / "SKILL.md")
        self.assertIn("每一次登记成一道题，写同一个 `\"group\"`", skill)
        self.assertIn("硬约束维度上哪一次退步了，就记退步，不拿另一次抵消。", skill)


# ------------------------------------------------------------------ 2. dialogue and scene anchors (section 2, item 5)
class DialogueSceneAnchors(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = json.loads(read(ANCHORS))
        cls.anchors = {a["id"]: dict(a, task=a.get("task") or cls.data["task"]) for a in cls.data["anchors"]}

    def outcome(self, anchor_id, text):
        return detail.check_candidate(self.anchors[anchor_id], text)

    def test_eight_new_anchors_not_yet_read_by_the_author(self):
        self.assertEqual(self.data["format"], "novel-workshop-writing-anchors")
        self.assertEqual(list(self.anchors), ["D01", "D02", "D03", "D04", "D05", "S01", "S02", "S03"])
        self.assertTrue(all(a["source"] == NEW_AND_UNREAD for a in self.anchors.values()))
        self.assertIn("八例都是工坊新编，措辞作者还没看过", self.data["note"])
        polish_nothing_new = "这一段帮我精修一下，准备定稿。情节别动，也别加新东西。"
        tasks = {"D01": polish_nothing_new, "D02": polish_nothing_new, "D03": "对白改得有张力一点。",
                 "D04": "这一段帮我精修一下。", "D05": "这一段帮我精修一下。", "S01": polish_nothing_new,
                 "S02": "改得更有戏一点。", "S03": "这一段帮我精修一下。"}
        self.assertEqual({k: a["task"] for k, a in self.anchors.items()}, tasks)
        self.assertEqual(sorted(k for k, a in self.anchors.items() if a.get("no_new_dialogue")), ["D01", "D02", "S01"])
        self.assertEqual(self.anchors["S03"]["avoid"], ["有些日子，就这样过去了"])
        for anchor_id in ("D01", "D02", "S01"):  # should not be touched
            self.assertEqual(self.anchors[anchor_id]["approved_after"], self.anchors[anchor_id]["before"])
        for anchor_id in ("D04", "D05", "S03"):  # should be changed
            self.assertNotEqual(self.anchors[anchor_id]["approved_after"], self.anchors[anchor_id]["before"])
            self.assertTrue(self.anchors[anchor_id]["avoid"])

    def test_they_pass_their_self_test(self):
        code, out, err = check("anchors", ANCHORS, "--self-test")
        self.assertEqual(code, 0, out + err)
        self.assertIn("通过 11 个，共 11 个。", out)

    def test_a_terse_reply_filled_in_fails(self):
        before = self.anchors["D01"]["before"]
        filled = before.replace("“五点。”", "“五点吧。”").replace("“不去。”", "“不去，我还有作业呢。”")
        result = self.outcome("D01", filled)
        self.assertEqual(result["status"], "FAIL")
        self.assertEqual(result["missing_keep"], ["“五点。”", "“不去。”"])
        chatty = self.anchors["D02"]["before"].replace("“够。”", "“够啦，你放心吧。”")
        self.assertEqual(self.outcome("D02", chatty)["missing_keep"], ["“够。”"])
        self.assertEqual(self.outcome("D01", before)["status"], "PASS")

    def test_one_set_phrase_for_everyone_fails(self):
        self.assertEqual(self.outcome("D05", self.anchors["D05"]["before"])["status"], "FAIL")
        self.assertEqual(self.outcome("D05", self.anchors["D05"]["approved_after"])["status"], "PASS")

    def test_a_quarrel_put_into_a_lingering_scene_fails(self):
        before = self.anchors["S01"]["before"]
        quarrel = before.replace("两个人谁也没说话。", "“你早该同意卖。”老二说。\n“现在说这个有什么用？”\n两个人谁也没说话。")
        result = self.outcome("S01", quarrel)
        self.assertEqual(result["status"], "FAIL")
        self.assertEqual(result["missing_keep"], [])
        self.assertEqual([row["text"] for row in result["new_dialogue"]], ["“你早该同意卖。”", "“现在说这个有什么用？”"])
        self.assertTrue(any(r.startswith("新加了台词：") for r in result["reasons"]))

    def test_the_honest_answer_has_to_stay_and_lines_may_be_added(self):
        before = self.anchors["D03"]["before"]
        dodged = before.replace("“在宁波开货车，跑冷链，一年回不了两趟家。”", "“你猜？”")
        self.assertEqual(self.outcome("D03", dodged)["missing_keep"], ["宁波", "开货车", "冷链", "回不了两趟家"])
        added = before.replace("“我也是跑车的，拉家具。”", "“你呢？”\n“我也是跑车的，拉家具。”")
        self.assertEqual(self.outcome("D03", added)["status"], "PASS")
        # S02 may grow too; a hard-added obstacle is not something the literal check can see (semantic judgment)
        phone = self.anchors["S02"]["before"] + "\n秀兰的手机响了，房东在电话里说，这铺子不租了。"
        self.assertEqual(self.outcome("S02", phone)["status"], "PASS")
        self.assertIn("这一点字面核对查不出，每一份输出另记语义判断", self.anchors["S02"]["why"])

    def test_the_material_stays_out_of_the_rule_pages(self):
        pages = [SKILL / "SKILL.md", DARWIN / "SKILL.md", SKILL / "CONSTITUTION.md"]
        pages += sorted((SKILL / "references").glob("*.md"))
        text = "\n".join(read(p) for p in pages)
        for name in ("小凯", "老耿", "蔡东", "郑远", "林晓", "周敏", "梅姐", "老祁", "小罗", "冯大成", "秀兰", "老魏"):
            self.assertNotIn(name, text)
        for anchor in self.anchors.values():
            for sentence in re.split("[。！？\n]", anchor["before"]):
                if len(sentence) >= 8:
                    self.assertNotIn(sentence, text)

    def test_the_pages_point_to_it(self):
        self.assertIn("[dialogue-scene-anchors.json](assets/dialogue-scene-anchors.json)（r5.59，八例，工坊新编，措辞作者还没看过）",
                      read(DARWIN / "SKILL.md"))
        self.assertIn("`assets/dialogue-scene-anchors.json`，r5.59，八例，工坊新编，措辞作者还没看过",
                      read(SKILL / "references" / "skill-evaluation.md"))


# ------------------------------------------------------------------ 5. no_new_dialogue (section 3, item 9)
class NoNewDialogue(unittest.TestCase):
    BEFORE = "灶上的水开了。阿梨把壶提下来，给两只杯子都倒满。\n“烫。”\n周叔点点头。"
    WITH_LINE = "灶上的水开了。阿梨把壶提下来，给两只杯子都倒满。\n“烫。”\n“你慢点喝，别急。”\n周叔点点头。"

    def anchor(self, **extra):
        return dict({"id": "X01", "source": "测试", "task": "精修，别加新东西。", "before": self.BEFORE,
                     "approved_after": self.BEFORE, "keep": ["“烫。”", "周叔点点头"], "avoid": [], "why": "测试"}, **extra)

    def files(self, tmp, anchor, output):
        data = {"format": "novel-workshop-writing-anchors", "format_version": 1, "task": "精修。", "anchors": [anchor]}
        path = write(Path(tmp) / "a.json", json.dumps(data, ensure_ascii=False))
        write(Path(tmp) / "out" / "X01.txt", output)
        return path

    def test_a_new_line_fails_only_where_the_anchor_says_so(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = self.files(tmp, self.anchor(no_new_dialogue=True), self.WITH_LINE)
            self.assertEqual(check("anchors", path, "--self-test")[0], 0)
            code, out, _ = check("anchors", path, "--outputs", Path(tmp) / "out")
            self.assertEqual(code, 1, out)
            self.assertIn("新加了台词：“你慢点喝，别急。”（第 3 段）", out)
            code, out, _ = check("anchors", path, "--outputs", Path(tmp) / "out", "--format", "json")
            result = json.loads(out)["results"][0]
            self.assertEqual((result["status"], result["new_dialogue"]),
                             ("FAIL", [{"para": 3, "text": "“你慢点喝，别急。”"}]))
            # the same anchor without the field: the literal check alone lets the added line through
            path = self.files(tmp, self.anchor(), self.WITH_LINE)
            code, out, _ = check("anchors", path, "--outputs", Path(tmp) / "out")
            self.assertEqual(code, 0, out)

    def test_changed_lines_are_left_to_keep_and_reading(self):
        changed = self.BEFORE.replace("“烫。”", "“烫，慢点。”")
        result = detail.check_candidate(self.anchor(no_new_dialogue=True), changed)
        self.assertEqual((result["status"], result["missing_keep"], result["new_dialogue"]), ("FAIL", ["“烫。”"], []))
        untouched = detail.check_candidate(self.anchor(no_new_dialogue=True), self.BEFORE)
        self.assertEqual((untouched["status"], untouched["reasons"]), ("PASS", []))

    def test_a_line_split_in_two_is_not_new(self):
        # r5.59 review: splitting a long line with an action in the middle, or into two paragraphs, adds nothing
        before = "她从后厨出来。\n“锅里还有半锅粥，你自己盛，凉了就热一下。”\n周叔点点头。"
        anchor = dict(self.anchor(no_new_dialogue=True), before=before, approved_after=before, keep=["周叔点点头"])
        for split in ("她从后厨出来。\n“锅里还有半锅粥，你自己盛。”她想了想，“凉了就热一下。”\n周叔点点头。",
                      "她从后厨出来。\n“锅里还有半锅粥，你自己盛。”\n“凉了就热一下。”\n周叔点点头。"):
            with self.subTest(split=split):
                result = detail.check_candidate(anchor, split)
                self.assertEqual((result["status"], result["new_dialogue"]), ("PASS", []), result["reasons"])
                # the listing for people still shows the lines one against one
                self.assertTrue(detail.changes(before, split)["dialogue"]["new"])

    def test_a_short_new_line_next_to_a_changed_one_fails(self):
        changed = self.BEFORE.replace("“烫。”", "“烫，慢点。”\n“你别急。”")
        result = detail.check_candidate(self.anchor(no_new_dialogue=True, keep=["周叔点点头"]), changed)
        self.assertEqual((result["status"], result["new_dialogue"]), ("FAIL", [{"para": 3, "text": "“你别急。”"}]))
        added = self.BEFORE.replace("“烫。”", "“烫。”\n“哦。”")
        self.assertEqual(detail.check_candidate(self.anchor(no_new_dialogue=True), added)["new_dialogue"],
                         [{"para": 3, "text": "“哦。”"}])

    def test_lines_in_other_quotes_are_not_seen_and_the_page_says_so(self):
        for line in ("『你慢点喝，别急。』", "\"你慢点喝，别急。\"", "——你慢点喝，别急。"):
            with self.subTest(line=line):
                text = self.BEFORE.replace("周叔点点头。", line + "\n周叔点点头。")
                self.assertEqual(detail.check_candidate(self.anchor(no_new_dialogue=True), text)["new_dialogue"], [])
        step = next(line for line in read(SKILL / "references" / "skill-evaluation.md").splitlines()
                    if line.startswith("4. 核对："))
        self.assertIn("用『』、‘’、英文引号或破折号引出的话，这一项认不出，要人读。", step)

    def test_anchors_without_the_field_check_as_before(self):
        result = detail.check_candidate(self.anchor(), self.WITH_LINE)
        self.assertEqual(set(result), {"id", "status", "reasons", "missing_keep", "avoid_left", "listing"})
        self.assertEqual(result["status"], "PASS")
        code, out, err = check("anchors", DARWIN / "assets" / "writing-anchors.json", "--self-test", "--format", "json")
        self.assertEqual(code, 0, out + err)
        results = json.loads(out)["results"]
        self.assertEqual(len(results), 5)
        self.assertTrue(all("new_dialogue" not in r for r in results))

    def test_the_field_must_be_true_or_false(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = self.files(tmp, self.anchor(no_new_dialogue="yes"), self.BEFORE)
            code, out, _ = check("anchors", path, "--self-test")
            self.assertEqual(code, 2)
            self.assertIn("no_new_dialogue, when given, must be true or false", out)
            data = json.loads(read(path))
            del data["anchors"][0]["no_new_dialogue"]
            data["anchors"][0]["no_new_lines"] = True
            write(path, json.dumps(data, ensure_ascii=False))
            code, out, _ = check("anchors", path, "--self-test")
            self.assertEqual(code, 2)
            self.assertIn("unknown fields no_new_lines", out)

    def test_the_rule_page_says_when_to_use_it(self):
        step = next(line for line in read(SKILL / "references" / "skill-evaluation.md").splitlines()
                    if line.startswith("4. 核对："))
        self.assertIn("任务是精修、别加新东西的对照例，可以标 `no_new_dialogue: true`（r5.59）", step)
        self.assertIn("任务是改得更有戏、更有张力的不标：作者要的就是改", step)
        self.assertIn('"no_new_dialogue": true (r5.59', read(CHECK))
        # r5.59 review: what the item does not catch is said, and the two anchors that may grow rest on reading
        for phrase in ("原有的一句拆成两句的，不算新加；原有的一句改了字、拉长或补全，和原句还像的，算改了，这一项不拦，靠 `keep` 和语义判断；"
                       "改得认不出原句的，算新加。",
                       "这一类对照例的 `avoid` 可以是空的，`keep` 只守事实，拦争吵、硬加的阻碍和绕弯子，靠的是每一例另记的语义判断。"):
            self.assertIn(phrase, step)
        self.assertNotIn("靠 `keep`、`avoid` 和每一例另记的语义判断", step)
        self.assertIn("a line cut in two is not new", read(CHECK))
        opening = next(line for line in read(SKILL / "references" / "skill-evaluation.md").splitlines()
                       if line.startswith("改起草、修改、去 AI 腔一类的写作规则"))
        self.assertIn("也有工坊新编、写明“措辞作者还没看过”的，作者看过以前只用来拦这几种写法，它的改法不当作作者的认可（r5.59）。",
                      opening)


# ------------------------------------------------------------------ 4. would following the rules still fail? (section 3, item 2)
class WouldTheRulesStillFail(unittest.TestCase):
    def test_the_question_comes_before_changing_a_rule(self):
        part = section(read(SKILL / "references" / "skill-evaluation.md"), "## 根据结果修订并停止")
        paragraphs = [p for p in part.split("\n\n") if p.strip()]
        self.assertTrue(paragraphs[0].endswith("不把某道题的答案写进技能。"))
        self.assertEqual(paragraphs[1], WOULD_IT_STILL_FAIL)
        self.assertTrue(paragraphs[2].startswith("采用候选版的最低门槛："))

    def test_the_maintenance_steps_point_to_it(self):
        part = section(read(DARWIN / "SKILL.md"), "## 形成可比较的候选")
        steps = [line for line in part.splitlines() if re.match(r"\d\. ", line)]
        self.assertEqual([s[:2] for s in steps], ["1.", "2.", "3.", "4."])
        self.assertTrue(steps[2].startswith(
            "3. 改规则以前，先照 `novel-workshop` 的 `references/skill-evaluation.md`“根据结果修订并停止”问一句：照现在的规则"
            "认真做，还会不会出这种错；不会，就改读取和查验，不另加规则（r5.59）。选择最可能影响结果的一项规则问题，做最小改进。"))

    def test_the_feedback_log_records_the_cause(self):
        template = json.loads(read(DARWIN / "assets" / "feedback-log-template.json"))
        self.assertEqual(template["schema"], "author-feedback-log/2")
        entry = template["entries"][0]
        self.assertEqual(list(entry), ["id", "date", "author_words", "source", "chapters", "rules", "problem", "cause",
                                       "rule_ref", "status", "reason", "regression_case", "tests", "evidence"])
        self.assertTrue(entry["cause"].startswith("拟："))
        for phrase in ("cause 是工坊拟的原因，不是作者的话", "references/quality-loop.md“单元之间的经验回流”里的复盘",
                       "没有规则管到；有规则管到、这一次没照做；照规则做了反而改坏；作者的取舍；看不出原因",
                       "作者一句话可以改", "rule_ref 写管到这一处的那一页那一节"):
            self.assertIn(phrase, template["note"])
        # the five causes are defined once, in the quality loop; the template only points there
        quality = read(SKILL / "references" / "quality-loop.md")
        self.assertIn("工坊拟的原因，五选一：没有规则管到；有规则管到、这一次没照做（写明哪一页哪一节）；"
                      "照规则做了反而改坏（写明哪一条）；这一处是作者的取舍", quality)
        self.assertIn("工坊拟的原因（`cause`，五类照 `novel-workshop` 的 `references/quality-loop.md`“单元之间的经验回流”里的复盘",
                      read(DARWIN / "SKILL.md"))


# ------------------------------------------------------------------ 5. regression cases (section 3, item 9)
class RegressionCases(unittest.TestCase):
    def test_the_four_dialogue_and_scene_cases(self):
        cases = {c["id"]: c for c in json.loads(read(ROOT / "tests" / "regression-cases.json"))["cases"]}
        titles = {"T": "说话人认不出：", "U": "人人一个口气、惜字的人被补全：", "V": "停留场、兑现场被套上四拍、硬加争执：",
                  "W": "精修时新加了台词："}
        for case_id, start in titles.items():
            with self.subTest(case=case_id):
                case = cases[case_id]
                self.assertTrue(case["title"].startswith(start))
                self.assertTrue(case["editorial"])
                self.assertTrue(any(name.startswith("test_r559_maintenance.") for name in case["tests"]))
                for name in case["tests"]:
                    if name.startswith("test_r559_maintenance."):
                        _, cls, method = name.split(".")
                        self.assertIn(method, globals()[cls].__dict__)
        self.assertEqual(cases["W"]["editorial"][0]["section"], "## 2. 每一处：记一类，写拟处置，写谁来定")
        # r5.59 review: W named the field no_new_dialogue where a section heading belongs
        self.assertEqual(cases["W"]["editorial"][2], {"file": "novel-workshop/references/skill-evaluation.md",
                                                      "section": "## 写作对照例"})
        for case_id in titles:
            for ref in cases[case_id]["editorial"]:
                with self.subTest(case=case_id, section=ref["section"]):
                    self.assertRegex(ref["section"], r"^#{2,3} ")
                    lines = read(SKILLS / ref["file"]).splitlines()
                    self.assertTrue(any(line.startswith(ref["section"]) for line in lines))


if __name__ == "__main__":
    unittest.main()

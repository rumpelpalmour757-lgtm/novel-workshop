#!/usr/bin/env python3
"""r5.2: repairs for the 2026-10-16 review of the r5.1 candidate (findings N01-N03).

N01  a repeated line of dialogue hid a changed end mark in another occurrence of the same words.
N02  confirming a skip-review acceptance again dropped the skip mark (and the refusal called the skip a review).
N03  after the author skipped the review, a review recorded later still failed the batch check.
All material is invented for these tests; acceptances and reviews are labelled test data.
"""

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SCRIPTS = ROOT / "skills" / "novel-workshop" / "scripts"
QUOTES = ["院门仍然紧紧关着。", "桌上的灯一直亮着。", "门外已经没有声音。"]
# The review's own N01 text: two people say the same words; only his exclamation becomes a full stop.
TEXT = "院门仍然紧紧关着。\n\n“快走！”他喊，“快走。”她回答。\n\n桌上的灯一直亮着。\n\n他抬头看了一眼墙上的钟。\n\n门外已经没有声音。\n"


def whole_text(text):
    """r5.11: a strict-mode PASS needs the expression record. These short test texts are read as one segment; the
    record is test data that only lets the gate get to what this file tests."""
    body = text.strip()
    begin = next(body[:k] for k in range(4, len(body) + 1) if len("".join(body[:k].split())) >= 4)
    end = next(body[-k:] for k in range(4, len(body) + 1)
               if len("".join(body[-k:].split())) >= 4 and body.count(body[-k:]) == 1)
    return {"scope": "chapter", "decisions": [],
            "segments": [{"from": begin, "to": end, "note": "测试数据：只验证结构，全文连读过"}]}


def compare(original, revised):
    spec = importlib.util.spec_from_file_location("r52_punctuation", SCRIPTS / "punctuation_lint.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.compare_texts(original, revised)


def changes(original, revised):
    return [(t["line"], t["column"], t["before"] + "→" + t["after"], t["match"])
            for t in compare(original, revised)["tone_changes"]]


class RepeatedDialogue(unittest.TestCase):
    """N01: the same words said twice are matched one to one, never by "some occurrence had these marks"."""

    def test_the_review_case_first_of_two_identical_lines_changes(self):  # !/. -> ./.
        report = compare("“快走！”他喊，“快走。”她回答。\n", "“快走。”他喊，“快走。”她回答。\n")
        self.assertEqual(report["status"], "REVIEW")
        self.assertEqual([(t["id"], t["before"], t["after"]) for t in report["tone_changes"]], [("TONE-L1-C1", "！", "。")])

    def test_question_turned_statement_in_a_repeated_line(self):  # ?/. -> ./.
        self.assertEqual(changes("“真的？”他问，“真的。”她说。\n", "“真的。”他问，“真的。”她说。\n"),
                         [(1, 1, "？→。", "same_line")])

    def test_swapped_marks_with_unchanged_counts_are_both_reported(self):  # !/. -> ./!
        self.assertEqual(changes("“快走！”他喊，“快走。”她回答。\n", "“快走。”他喊，“快走！”她回答。\n"),
                         [(1, 1, "！→。", "same_line"), (1, 9, "。→！", "same_line")])

    def test_removing_or_adding_an_identical_line_is_not_a_tone_change(self):
        both = "“快走！”他喊。\n\n“快走。”她回答。\n"
        self.assertEqual(changes(both, "“快走。”她回答。\n"), [])
        self.assertEqual(changes("“快走。”她回答。\n", both), [])

    def test_removing_one_and_changing_the_other_is_still_reported(self):
        self.assertEqual(changes("“快走！”他喊。\n\n“快走。”她回答。\n", "“快走！”她回答。\n"),
                         [(1, 1, "。→！", "same_line")])

    def test_moving_paragraphs_is_not_reported(self):
        self.assertEqual(changes("“快走！”他喊。\n\n门开了。\n\n“慢点。”她说。\n", "“慢点。”她说。\n\n门开了。\n\n“快走！”他喊。\n"), [])
        # Two paragraphs with the same words swap places: still nothing changed.
        self.assertEqual(changes("“快走！”他喊。\n\n门开了。\n\n“快走。”她说。\n", "“快走。”她说。\n\n门开了。\n\n“快走！”他喊。\n"), [])

    def test_a_moved_paragraph_with_a_changed_mark_is_reported(self):
        self.assertEqual(changes("“快走！”他喊。\n\n门开了。\n\n“慢点。”她说。\n", "“慢点。”她说。\n\n门开了。\n\n“快走。”他喊。\n"),
                         [(5, 1, "！→。", "moved_line")])

    def test_an_edited_paragraph_keeps_its_dialogue_in_order(self):
        self.assertEqual(changes("“快走！”他喊，“快走。”她回答。\n", "“快走。”他压低声音，“快走。”她回答。\n"),
                         [(1, 1, "！→。", "changed_line")])
        self.assertEqual(changes("“走？”他问。\n\n“走。”她说。\n", "“走？”他低声问。\n\n“走。”她轻声说。\n"), [])

    def test_repeats_that_cannot_be_matched_are_flagged_not_passed(self):
        # The two lines swapped places, both were reworded and their marks swapped: no pairing is reliable, and taking
        # either one would hide a change. Both revised lines are flagged as uncertain.
        report = compare("“快走！”他喊。\n\n门开了。\n\n“快走。”她说。\n", "“快走！”她低声说。\n\n门开了。\n\n“快走。”他大喊。\n")
        self.assertEqual([(t["line"], t["match"]) for t in report["tone_changes"]], [(1, "uncertain"), (5, "uncertain")])
        self.assertIn("对不上", report["tone_changes"][0]["message"])
        # The message gives the real reason: here the counts did not change, the two ways of pairing disagree.
        self.assertEqual([t["uncertain_reason"] for t in report["tone_changes"]], ["order_unclear", "order_unclear"])
        self.assertIn("两版都出现 2 次", report["tone_changes"][0]["message"])
        self.assertIn("第 1 行句末“！”，第 5 行句末“。”", report["tone_changes"][0]["message"])
        # One of two identical lines removed while the paragraph was rewritten: which one is left cannot be told.
        self.assertEqual(changes("“快走！”他喊，“快走。”她回答。\n", "“快走。”他小声说。\n"), [(1, 1, "！、。→。", "uncertain")])
        removed = compare("“快走！”他喊，“快走。”她回答。\n", "“快走。”他小声说。\n")["tone_changes"][0]
        self.assertEqual(removed["uncertain_reason"], "count_changed")
        self.assertIn("原稿里出现 2 次，修订稿里出现 1 次", removed["message"])
        # Too many repeats to pair: only an occurrence whose marks none of the originals had is flagged.
        many = "".join("“好。”他说了第%d句。\n\n" % i for i in range(21))
        reworded = "".join("“好%s”她换了第%d种说法。\n\n" % ("！" if i == 3 else "。", i) for i in range(21))
        self.assertEqual([(t["line"], t["match"], t["uncertain_reason"]) for t in compare(many, reworded)["tone_changes"]],
                         [(7, "uncertain", "too_many")])

    def test_a_quotation_over_several_lines_is_compared_line_by_line(self):
        # Before r5.2 only quotations that close on the same line were compared; a long speech that reopens each
        # paragraph, or one soft-wrapped inside one quotation, could change a mark in the middle unseen.
        reopened = "“我姓秦，在南城做了十年押运！\n“这趟活儿给你三成。\n“路上不许问货是什么？”\n"
        self.assertEqual(changes(reopened, reopened.replace("三成。", "三成！")), [(2, 1, "。→！", "same_line")])
        wrapped = "“我姓秦，在南城做了十年押运！\n这趟活儿给你三成。\n路上不许问货是什么？”\n"
        self.assertEqual(changes(wrapped, wrapped.replace("是什么？”", "是什么。”")), [(3, 1, "？→。", "same_line")])
        self.assertEqual(changes(wrapped, wrapped), [])
        self.assertEqual(changes("“走吧。”\n\n他点头。\n", "“走吧。”\n\n他点头！\n"), [])  # narration stays narration

    def test_the_review_case_needs_a_decision_at_the_gate(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            (work / "original.md").write_bytes((TEXT).encode("utf-8"))
            (work / "candidate.md").write_bytes((TEXT.replace("“快走！”", "“快走。”", 1)).encode("utf-8"))
            (work / "checks.json").write_bytes((json.dumps({"candidate": "candidate.md", "mode": "strict", "checks": [
                {"id": "body", "type": "contains", "text": QUOTES[0]},
                {"id": "rev", "type": "revision", "source": "original.md"}]})).encode("utf-8"))

            def run(*args):
                proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPTS / "workflow_guard.py"), *args], cwd=work,
                                      capture_output=True, text=True, encoding="utf-8")
                return proc.returncode, json.loads(proc.stdout)

            self.assertEqual(run("start", "state.json", "--task-id", "n01", "--spec", "checks.json")[0], 0)
            items = [x["id"] for x in run("check", "checks.json")[1]["review_items"]]
            self.assertEqual(items, ["rev:TONE-L3-C1"])

            def review(dispositions):
                (work / "review.json").write_bytes((json.dumps({
                    "schema": "editorial-review/2", "verdict": "PASS",
                    "candidate_sha256": hashlib.sha256((work / "candidate.md").read_bytes()).hexdigest(),
                    "reviewer": {"mode": "self_check", "label": "测试数据"}, "checked_against": ["测试数据"],
                    "inputs_read": ["original.md"], "evidence": [{"quote": q, "in": "candidate"} for q in QUOTES],
                    "issues": [], "machine_dispositions": dispositions,
                    "dimensions": [{"id": key, "status": "met", "note": "测试数据：只验证结构"} for key in
                                   ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function",
                                    "continuity", "revision_comparison")],
                    "expression": whole_text((work / "candidate.md").read_text(encoding="utf-8")),
                    "counter_evidence": "测试数据：不作文学判断"}, ensure_ascii=False)).encode("utf-8"))
                return run("record", "state.json", "--event-id", "v1", "--review", "review.json")

            code, out = review([])
            self.assertEqual((code, out["failure"]), (2, "REVIEW_INCOMPLETE"))
            self.assertIn("rev:TONE-L3-C1", out["message"])
            code, out = review([{"id": "rev:TONE-L3-C1", "decision": "keep", "reason": "测试数据：作者要他平静地说"}])
            self.assertEqual(code, 0, out)


class SkipReviewLifecycle(unittest.TestCase):
    """N02 and N03: what a skip-review acceptance means later, kept apart from whether the bytes are reviewed now."""

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.work = Path(self.temp.name)
        self.write("candidate.md", TEXT)
        self.write("checks.json", {"candidate": "candidate.md", "mode": "strict",
                                   "checks": [{"id": "body", "type": "contains", "text": QUOTES[0]}]})
        self.write("decision.json", {"candidate_sha256": self.sha(), "scope": "本章完整正文",
                                     "source": "作者当前消息：跳过审稿，直接采纳这一版。（测试数据）"})
        self.cli("start", "state.json", "--task-id", "skip", "--spec", "checks.json")

    def write(self, name, value):
        (self.work / name).write_bytes((value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)).encode("utf-8"))

    def sha(self):
        return hashlib.sha256((self.work / "candidate.md").read_bytes()).hexdigest()

    def cli(self, *args, code=0, script="workflow_guard.py"):
        proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPTS / script), *args], cwd=self.work,
                              capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(proc.returncode, code, proc.stdout + proc.stderr)
        return json.loads(proc.stdout)

    def accept(self, event, *extra, code=0):
        return self.cli("accept", "state.json", "--event-id", event, "--decision", "decision.json", *extra, code=code)

    def gate(self):
        return self.cli("status", "state.json")["gate"]

    def review(self, verdict="PASS"):
        dimensions = [{"id": key, "status": "met", "note": "测试数据：只验证结构"} for key in
                      ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function",
                       "continuity", "revision_comparison")]
        issues = []
        if verdict == "NEEDS_REVISION":
            issues = [{"quote": QUOTES[1], "in": "candidate", "expected": "测试数据：要求重写这一句", "impact": "测试数据"}]
            dimensions[0].update(status="issue", evidence=[{"quote": QUOTES[1], "in": "candidate"}])
        self.write("review.json", {
            "schema": "editorial-review/2", "verdict": verdict, "candidate_sha256": self.sha(),
            "reviewer": {"mode": "self_check", "label": "测试数据"}, "checked_against": ["测试数据"], "inputs_read": [],
            "evidence": [{"quote": q, "in": "candidate"} for q in QUOTES], "issues": issues, "machine_dispositions": [],
            "dimensions": dimensions, "expression": whole_text((self.work / "candidate.md").read_text(encoding="utf-8")),
            "counter_evidence": "测试数据：不作文学判断"})
        return self.cli("record", "state.json", "--event-id", "review-1", "--review", "review.json")

    def batch(self, code, **extra):
        self.write("delivery.json", {"schema": "delivery-manifest/1", "stage": "accepted", "expected_units": ["ch"],
                                     "records": [{"unit": "ch", "candidate": "candidate.md", "state": "state.json"}],
                                     **extra})
        report = self.cli("delivery.json", code=code, script="delivery_manifest.py")
        return report["status"], report["units"][0]["problems"], report["units"][0]["notes"]

    def test_confirming_an_unreviewed_version_again_keeps_the_skip(self):
        self.accept("skip-1", "--skip-review")
        before = (self.work / "state.json").read_bytes()
        self.accept("skip-1", "--skip-review")  # a retry of the same event changes nothing
        self.assertEqual((self.work / "state.json").read_bytes(), before)
        self.accept("skip-2", "--skip-review")  # the author confirms again, still without a review
        gate = self.gate()
        self.assertTrue(gate["review_skipped_by_author"])
        self.assertIn("采纳时作者决定跳过审稿", gate["deliverable_label"])
        state = json.loads((self.work / "state.json").read_text(encoding="utf-8"))
        self.assertEqual([(h["event_id"], h.get("review_skipped")) for h in state["human_approvals"]],
                         [("skip-1", True), ("skip-2", True)])
        self.assertEqual(sum(a.get("review") == "skipped_by_author" for a in state["artifacts"]), 1)
        self.assertEqual(state["evidence"], [])

    def test_a_plain_acceptance_cannot_count_a_skip_as_a_review(self):
        self.accept("skip-1", "--skip-review")
        out = self.accept("accept-2", code=2)
        self.assertEqual(out["failure"], "ACCEPT_INVALID")
        self.assertIn("no recorded review", out["message"])
        self.assertIn("skip-1", out["message"])
        self.assertTrue(self.gate()["review_skipped_by_author"])  # nothing was dropped

    def test_after_a_real_review_the_states_show_it_and_the_history_keeps_the_skip(self):
        self.accept("skip-1", "--skip-review")
        self.review()
        gate = self.gate()
        self.assertEqual((gate["mechanical"], gate["editorial"], gate["author"]), ("GREEN", "PASS[self_check]", "ACCEPTED"))
        self.assertEqual((gate["review_skipped_by_author"], gate["reviewed_since_skip"]), (True, True))
        self.assertIn("之后补做了审稿", gate["deliverable_label"])
        self.assertTrue(any("之后对这一版补做了检查和审稿" in w for w in gate["stage_warnings"]))
        out = self.accept("skip-3", "--skip-review", code=2)
        self.assertIn("already has a recorded review (review-1)", out["message"])
        self.accept("accept-4")  # the author accepts the reviewed bytes
        gate = self.gate()
        self.assertEqual((gate["review_skipped_by_author"], gate["reviewed_since_skip"]), (False, False))
        state = json.loads((self.work / "state.json").read_text(encoding="utf-8"))
        self.assertEqual([(h["event_id"], bool(h.get("review_skipped"))) for h in state["human_approvals"]],
                         [("skip-1", True), ("accept-4", False)])

    def test_the_batch_follows_the_current_review_and_keeps_the_skip_as_a_note(self):
        self.accept("skip-1", "--skip-review")
        self.assertEqual(self.batch(1), ("INCOMPLETE", ["GATE_INCOMPLETE", "AUTHOR_SKIPPED_REVIEW"], []))
        self.review()
        status, problems, notes = self.batch(0)
        self.assertEqual((status, problems), ("PASS", []))
        self.assertTrue(notes and notes[0].startswith("AUTHOR_SKIPPED_REVIEW_AT_ACCEPTANCE"))
        status, problems, _ = self.batch(1, require_independent=True)
        self.assertEqual((status, problems), ("INCOMPLETE", ["INDEPENDENT_REVIEW_REQUIRED"]))
        self.write("candidate.md", TEXT + "补一句。\n")
        status, problems, _ = self.batch(1)
        self.assertEqual(status, "INCOMPLETE")
        self.assertIn("GATE_INCOMPLETE", problems)
        self.assertIn("AUTHOR_NOT_ACCEPTED", problems)

    def test_a_review_that_did_not_pass_is_reported_as_such_not_as_missing(self):
        self.accept("skip-1", "--skip-review")
        self.review(verdict="NEEDS_REVISION")
        gate = self.gate()
        self.assertEqual((gate["editorial"], gate["review_skipped_by_author"], gate["reviewed_since_skip"]),
                         ("NEEDS_REVISION", True, True))
        status, problems, notes = self.batch(1)
        self.assertEqual((status, problems), ("INCOMPLETE", ["GATE_INCOMPLETE"]))
        self.assertTrue(notes and notes[0].startswith("AUTHOR_SKIPPED_REVIEW_AT_ACCEPTANCE"))


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""r5.59: the technique library borrows a few ways of judging and recording from Cangjie Skill 2.5.0.

The author passed on Cangjie Skill 2.5.0 (a method for turning one book into a set of skills) as a possible reference
for the technique library. The maker's proposal took only ideas from it, in the workshop's own words and with new
examples, and none of its files, scripts, templates or count thresholds. The author read the proposal and answered
that the items left to him go by the maker's advice and that the section-three changes go ahead. For this part that
means:

- assets/technique-card-template.md is replaced by the proposal's full draft: one card whose shared parts are always
  read and whose "dialogue" and "scene" parts are filled when the card is about that; a card number with a revision
  number and a status; where the device did not work in the original; three trial writes by the workshop (another
  character, another scene, a scene where the card should not be used) before a card is judged usable; the workshop's
  judgement, the trial in this book and the author's adoption kept apart; problems after use recorded on the card.
  The wording is the maker's draft, taken as advised; the author can change it at any time.
- deconstruction-library.md drops its own nine-field copy of the card for a link (one place to maintain the card),
  and gains a few sentences: list what the author wants to learn and say where each item went; go back to the text
  for places where the same device did not work; one complete instance is enough for a card, and seeing it again is
  not more evidence; two kinds of limits; a card meant for a general module goes through maintenance; a technique
  card is not a judgement card. Its source section names the Cangjie files the ideas came from.
- assets/reference-source-template.md gains a line on permission ("本书作者" there is the person writing this book).
- The source notes and the third-party notices record Cangjie and the claude-skills collection with their copyright
  lines as their licence files give them. Nothing of theirs is in the package, so there are still three third-party
  components.

These tests check that the structure and the wording are there; they do not show that taking a reference apart, or
writing with a card, gets any better.

r5.60 (the author's decisions on the card template): the card is ordered by when a column is read. Its ten parts are
now '### ' parts under two halves and a bottom block, "反例与失效" is split in two, the status line has three more
states, and the sentence on redoing the trial writes after a change now sends the reader to "改卡分轻重". The tests
below look the parts up at their new level and pin those sentences as r5.60 has them; every other sentence pinned
here is word for word what r5.59 had. What r5.60 added is in test_r560_technique_card.py.
"""
import hashlib
import importlib.util
import os
from pathlib import Path
import re
import unittest
import zlib

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
REFS = SKILL / "references"
ASSETS = SKILL / "assets"
CARD = ASSETS / "technique-card-template.md"
PAGE = REFS / "deconstruction-library.md"
SOURCE_CARD = ASSETS / "reference-source-template.md"
NOTES = ASSETS / "third-party" / "SOURCE-NOTES.md"
NOTICES = ROOT / "THIRD-PARTY-NOTICES.md"
CANGJIE_COMMIT = "3adf9e61eec96edf34055432942f2952cfd7cfd9"


def read(path):
    return path.read_text(encoding="utf-8") if path.is_file() else ""


def section(text, heading):
    """The body under a '## ' heading, up to the next '## ' heading ("" if there is none)."""
    parts = re.split(r"(?m)^## ", text)
    return next((part.split("\n", 1)[1] if "\n" in part else "" for part in parts[1:]
                 if part.split("\n", 1)[0].strip() == heading), "")


def part(text, heading):
    """The body under a '### ' heading, up to the next '## ' or '### ' heading ("" if there is none). r5.60."""
    match = re.search(r"(?ms)^### " + re.escape(heading) + r"\n(.*?)(?=^#{2,3} |\Z)", text)
    return match.group(1) if match else ""


def row_with(text, phrase):
    return next((line for line in text.splitlines() if line.startswith("|") and phrase in line), "")


def undecided_wording():
    """The wording from before the licence was chosen, as test_r555_package.py keeps it (one list, not two)."""
    spec = importlib.util.spec_from_file_location("r555_for_r559", Path(__file__).with_name("test_r555_package.py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.UNDECIDED


class TheCard(unittest.TestCase):
    def setUp(self):
        self.text = read(CARD)

    def test_the_card_has_the_shared_parts_then_the_optional_ones(self):
        # r5.60: two halves and a bottom block; nine of the ten r5.59 parts are '### ' parts under them with their
        # names unchanged, and "反例与失效" is split (see the failures test below)
        self.assertEqual(re.findall(r"(?m)^## (.+)$", self.text),
                         ["上半：挑卡、起草、写完自查时读这一半", "下半：建卡、改卡、复盘时读这一半", "本书适配与使用记录"])
        headings = re.findall(r"(?m)^### (.+)$", self.text)
        for kept in ("卡头", "来源证据", "做法", "留卡前试写（工坊自己写几句）", "和工坊已有模块的关系",
                     "工坊的判断、本书试用、作者采纳（三件事分开记）", "用过以后的问题", "对白另填（这张卡管对白时）",
                     "场景另填（这张卡管场景时）"):
            self.assertEqual(headings.count(kept), 1, kept)
        self.assertNotIn("反例与失效", headings)
        opening = self.text.split("\n## ", 1)[0]
        for phrase in ("只为回答作者一个问题、不存档的点评，不必建卡",
                       "“对白另填”“场景另填”按这张卡管的是哪一样选填，两样都管的两块都填",
                       "各栏都不按字数、条数、出现次数填，也不按填满了多少算好坏"):
            self.assertIn(phrase, opening)
        self.assertIn("**管哪一样**：对白／场景／两样都管", part(self.text, "卡头"))  # r5.60 adds a fourth kind after it

    def test_a_card_is_judged_usable_only_after_three_trial_writes(self):
        trials = part(self.text, "留卡前试写（工坊自己写几句）")
        for phrase in ("**换一个人物**", "**换一个场面**", "**不该用的场面**",
                       "要判成“可用”，换人物、换场面、不该用的场面这三样试写都要做过",
                       "记成“工坊试写，没有在留出章节上验证”", "不按成立了几问打分",
                       "不成立的照实留着，用来改“成立条件”和“失效情境”，不删",
                       "也不拿作者书里的正文练手", "试写写得顺，不说明用到本书里会写得更好"):
            self.assertIn(phrase, trials)

    def test_the_three_questions_and_the_three_trial_writes_have_different_names(self):
        judgement = part(self.text, "工坊的判断、本书试用、作者采纳（三件事分开记）")
        self.assertIn("看三个问题：原文撑得住吗（来源证据）；换人物、换场面做得出来吗（留卡前试写）；对本书哪一件事有用",
                      judgement)
        self.assertIn("三样试写", self.text)
        self.assertNotIn("三问", self.text)
        # "入库" already means "the author picked it" on the inspiration-library page; the card does not reuse it.
        self.assertNotIn("入库", self.text)

    def test_a_card_has_a_number_a_revision_and_a_status(self):
        head = part(self.text, "卡头")
        for phrase in ("**编号与修订号**", "卡上的说法改了只加修订号", "才另起编号，旧卡留着",
                       "作者采纳的是哪一版要对得上", # r5.60: "候选，没试写" before, "归档" and "收进了规矩" after
                       "**卡的状态**：候选，没试写／在用／被取代（被哪一张、从哪天起）／并进了别的卡／拆开了／归档",
                       "旧卡不删"):
            self.assertIn(phrase, head)
        adoption = part(self.text, "工坊的判断、本书试用、作者采纳（三件事分开记）")
        for phrase in ("采纳的是第几版修订", "旧版的采纳不带过来", "新卡默认“没给作者看”",
                       "沉默、接着要下一章、工坊自评、审稿通过、老师说好，都不算作者采纳",
                       "作者采纳只管本书"):
            self.assertIn(phrase, adoption)

    def test_problems_after_use_are_recorded_on_the_card(self):
        after = part(self.text, "用过以后的问题")
        for phrase in ("一次记一条", "**归哪一类**", "该用的时候没想到它／不该用的时候用了／作用链本身不对／做法少了一步／失效情境没写到／和模块打架",
                       # r5.60: a change that only narrows tests the new case only; any other change is as before
                       "别的改动，留卡前试写那几问重做一遍", "改卡只改卡上的说法，不改作者的设定和作者采纳的正文",
                       "只缩条件，不把作者一次局部的意见扩成通则", "作者没说的不猜"):
            self.assertIn(phrase, after)

    def test_the_evidence_is_one_complete_instance_and_the_card_finds_where_it_failed(self):
        evidence = part(self.text, "来源证据")
        for phrase in ("一处写全的就可以留卡", "多出现几次不算多一份证据，也不说明它更好",
                       "不用常识补成原作的写法", "注明是推断，不是读者调查", "只有二手转述的，写“原文未核”"):
            self.assertIn(phrase, evidence)
        # r5.60: where the device failed in the original and the limits of the reference are in the lower half;
        # where this card fails and what overuse looks like are in the upper half, apart from what drafting reads
        failures = part(self.text, "反例与局限")
        for phrase in ("**原作里没起作用的地方**", "找不到就写“原作里没找到”，不编",
                       "原作的写法不等于更好的写法", "只写参考，不借这一栏评判本书"):
            self.assertIn(phrase, failures)
        self.assertIn("写成“回头看的是……”，不写成次数线", part(self.text, "失效情境、用过头的样子、不可搬用的（起草时不读）"))

    def test_the_card_gives_way_to_the_modules(self):
        opening = self.text.split("\n## ", 1)[0]
        self.assertIn("工坊的模块是执行的依据，卡只是参考依据：卡和模块说法不一样时照模块办", opening)
        self.assertIn("记进新增设定清单列给作者，不写成本书的设定", opening)
        relation = part(self.text, "和工坊已有模块的关系")
        for phrase in ("执行照模块，这张卡只补参考依据，不另立一条规则", "不自己改模块", "作者定以前照模块办",
                       "查过没有对应的写“查过，没有对应”"):
            self.assertIn(phrase, relation)

    def test_the_two_card_kinds_keep_their_own_thresholds(self):
        # r5.59 wrap-up (decisions section 6, item 9): the draft said a judgement card needs three cases from two
        # scenes. The judgement-card page keeps thinner cards ("单薄") and lets five conditions make a candidate; the
        # sentence now says that and points at the page's section. A correction of fact, not a new rule.
        self.assertIn("技法卡一处写全就可以留；判断卡照[从改稿记录里学编辑判断](../references/editorial-judgment.md)"
                      "“够候选的门槛，和“单薄””，五条都满足才够候选（第一条是至少三条案例、来自至少两场不同的戏），"
                      "够不上的留作单薄的卡，只有一条案例的不做卡。", self.text)
        self.assertNotIn("判断卡要至少三条案例", self.text)
        # What the card says about judgement cards is what the judgement-card page says.
        page = read(REFS / "editorial-judgment.md")
        threshold = page.split("### 够候选的门槛，和“单薄”\n", 1)[1].split("\n### ", 1)[0]
        self.assertIn("一张卡同时满足下面五条，才算够候选：", threshold)
        self.assertIn("1. 至少三条案例，来自至少两场不同的戏。", threshold)
        self.assertIn("达不到的标“单薄”。单薄的卡可以留着", threshold)
        self.assertIn("只有一条案例的不做卡，留在案例里。", threshold)

    def test_the_reference_author_is_the_original_author(self):
        self.assertIn("作品、原作者、版次、实际读到的范围", part(self.text, "来源证据"))
        self.assertIn("原作者的立场", part(self.text, "反例与局限"))  # r5.60: the part's new name

    def test_every_link_resolves_and_every_named_section_is_there(self):
        links = re.findall(r"\]\(([^)\s]+)\)", self.text)
        self.assertGreaterEqual(len(links), 10)
        for target in links:
            path, _, anchor = target.partition("#")
            resolved = (CARD.parent / path).resolve()
            self.assertTrue(resolved.is_file(), target)
            if anchor:
                self.assertIn(anchor, re.findall(r"(?m)^#+ (.+)$", read(resolved)), target)
        named = {REFS / "dialogue-craft.md": ("顺着回应改", "一段对白的最小工作卡", "两件事分开做", "谁在说"),
                 REFS / "scene-dramaturgy.md": ("事后一拍", "跨章"),
                 ASSETS / "scene-beat-card.md": ("场上的人声",)}
        for path, names in named.items():
            for name in names:
                self.assertIn(name, read(path), (path.name, name))


class TheDeconstructionPage(unittest.TestCase):
    def setUp(self):
        self.text = read(PAGE)

    def test_the_old_inline_card_is_a_link_now(self):
        part = section(self.text, "提炼可迁移技法")
        self.assertIn("技法卡照 [技法卡模板](../assets/technique-card-template.md) 填，这一页不另放一份", part)
        self.assertNotIn("```", part)
        for old in ("技法名称／编号：", "读者需求：", "机制链：", "应用状态："):
            self.assertNotIn(old, self.text, old)
        # "读者需求" went into the first link of the card's 作用链.
        self.assertIn("**作用链**：原先的处境或期待 → 触发", read(CARD))
        # The rule this follows stays.
        self.assertIn("同一机制正文保留一个维护位置", self.text)

    def test_what_the_author_wants_to_learn_is_listed_and_accounted_for(self):
        part = section(self.text, "输入与边界")
        for phrase in ("作者有具体想学的地方（“三个人同场时话头怎么换”“吵完架第二天怎么开口”），先照作者的话列出来",
                       "拆完逐条写下落：成了哪几张卡、只作参考记在哪里、原文不够待核、原作里没写到",
                       "没写到的照实说没写到，不拿别处的写法顶上", "只问一句的点评不列"):
            self.assertIn(phrase, part)

    def test_the_reading_goes_back_for_where_the_device_did_not_work(self):
        part = section(self.text, "提炼可迁移技法")
        for phrase in ("做法找完以后，回原文另读一遍，专找同一手法没起作用、显得假，或者原作在相近场面有意没用它的地方",
                       "写进卡上“原作里没起作用的地方”那一栏；找不到就写找不到",
                       "一处写全就可以留卡；只有一个名字、一句评语的，不用常识补成原作的做法",
                       "同一处从几个角度都看到了，仍是一处证据"):
            self.assertIn(phrase, part)
        # The column the page sends the reader to is on the card.
        self.assertIn("**原作里没起作用的地方**", read(CARD))

    def test_the_report_writes_two_kinds_of_limits(self):
        step = next((line for line in section(self.text, "长篇流程").splitlines() if line.startswith("9. ")), "")
        # r5.59 review: the proposal's draft reads "局限分两种写。一种是……" with a full stop; the page had a colon there.
        for phrase in ("局限分两种写。一种是这次读到的范围不够；一种是参考本身因为类型惯例、写作年代、原作者立场，不该跟着学。"
                       "只写参考，不借这一栏评判本书。",):
            self.assertIn(phrase, step)
        self.assertIn("可迁移机制和未覆盖部分", step)  # the older half of the step stays

    def test_a_card_for_a_general_module_goes_through_maintenance(self):
        part = section(self.text, "按需建立与维护技法库")
        for phrase in ("技法卡要写进[对白专项](dialogue-craft.md)、[分场规范](scene-dramaturgy.md)这些通用模块的，"
                       "照[技能维护](skill-evaluation.md)走新旧对照，例子另写，不带原作的人物、桥段和台词",
                       # r5.59 wrap-up (decisions section 6, item 9): corrected like the card template above
                       "技法卡和判断卡是两样东西，门槛各管各的：技法卡一处写全就可以留；判断卡照[从改稿记录里学编辑判断]"
                       "(editorial-judgment.md)“够候选的门槛，和“单薄””，五条都满足才够候选（第一条是至少三条案例、来自"
                       "至少两场不同的戏），够不上的留作单薄的卡，只有一条案例的不做卡。",
                       "](editorial-judgment.md)"):
            self.assertIn(phrase, part)

    def test_each_new_sentence_is_written_once(self):
        texts = {path.name: path.read_text(encoding="utf-8") for path in REFS.glob("*.md")}
        for phrase in ("拆完逐条写下落", "回原文另读一遍，专找同一手法没起作用", "同一处从几个角度都看到了，仍是一处证据",
                       "局限分两种写", "技法卡和判断卡是两样东西", "这一页不另放一份"):
            homes = sorted(name for name, text in texts.items() if phrase in text)
            self.assertEqual(homes, ["deconstruction-library.md"], phrase)

    def test_the_source_section_names_cangjie_and_what_was_left_out(self):
        part = section(self.text, "来源与本工坊适配")
        for phrase in ("仓颉 Skill 2.5.0", CANGJIE_COMMIT, "`methodology/00-overview.md`", "`methodology/01-stage0-adler.md`",
                       "`methodology/03-stage1.5-triple-verify.md`", "`extractors/counter-example-extractor.md`",
                       "用本工坊的话重写", "没有带它的脚本、模板原文和按数量定的门槛", "也不照它把书编成技能、装进宿主"):
            self.assertIn(phrase, part)
        self.assertIn("`oh-story-claudecode-0.8.4`", part)  # the older source stays


class TheSourceCard(unittest.TestCase):
    def test_the_source_card_records_permission(self):
        text = read(SOURCE_CARD)
        self.assertIn("- 授权：本书作者自己写的／本书作者提供、授权不明／公有领域／已授权（写授权出处）／不明。"
                      "授权不明的，短引只留在本书的私人记录里，不进公开包和通用示例。", text.splitlines())
        # The reference's own author keeps its line; the new line says 本书作者 so the two are not mixed up.
        self.assertIn("- 作者、作品、出版或发表时间、版次：", text.splitlines())


class TheRecords(unittest.TestCase):
    def setUp(self):
        self.notes = read(NOTES)
        self.notices = read(NOTICES)

    def test_the_cangjie_row_keeps_the_year_only_copyright_line(self):
        row = row_with(self.notes, "仓颉 Skill 2.5.0")
        for phrase in (CANGJIE_COMMIT, "`Copyright (c) 2026`，只有年份，没有写权利人", "这里照原样记，不替它补名字",
                       "上游按 MIT 许可发布", "本包没有收它的文件", "没有带它的脚本、模板原文、schema",
                       "作者 2026-11-19 转来的发布包"):
            self.assertIn(phrase, row)
        # The repository account is not a copyright holder and is not written as one.
        self.assertNotIn("kangarooking", self.notes + self.notices)

    def test_the_claude_skills_row_copies_each_copyright_line(self):
        row = row_with(self.notes, "claude-skills 合集")
        for phrase in ("`Copyright (c) 2025 Alireza Rezvani`", "`Copyright (c) 2026 Reza Rezvani`",
                       "`Denver Technologies, Inc.` 和 `Alireza Rezvani` 两行", "warpdotdev/common-skills",
                       "`Copyright (c) 2026 Microsoft Corporation`", "`engineering/skill-retro`",
                       "`engineering/skills/agent-regression-evals`", "`engineering/agent-memory`",
                       "`engineering/memory-engineering`", "`engineering-team/self-improving-agent`",
                       "`engineering/skillopt-sleep`", "没有引入它的钩子、会话记录抓取、自评分数文件、插件安装步骤和脚本",
                       "本包没有收这些目录的文件"):
            self.assertIn(phrase, row)

    def test_the_notices_name_both_as_ideas_only(self):
        part = section(self.notices, "名字和引用")
        for phrase in ("拆文页和技法卡模板参考过仓颉 Skill 2.5.0（MIT）的拆书思路；按包内记录，没有使用它的文件、脚本或模板原文",
                       "它的许可里版权行只有年份，没有写权利人", "参考过 claude-skills 合集",
                       "没有使用它的代码、钩子或脚本"):
            self.assertIn(phrase, part)
        self.assertIn("本地工作台的界面布局参考过 InkOS（AGPL-3.0）的写作台思路", part)  # the older line stays

    def test_the_new_lines_do_not_bring_back_the_undecided_wording(self):
        new_lines = [row_with(self.notes, "仓颉 Skill 2.5.0"), row_with(self.notes, "claude-skills 合集")]
        new_lines += [line for line in section(self.notices, "名字和引用").splitlines()
                      if "仓颉" in line or "claude-skills" in line]
        self.assertEqual(len(new_lines), 4)
        for line in new_lines:
            for phrase in undecided_wording():
                self.assertNotIn(phrase, line, phrase)

    def test_nothing_of_theirs_is_in_the_package_so_there_are_still_three_components(self):
        self.assertEqual(sorted(path.name for path in (ASSETS / "third-party").iterdir()),
                         ["INTEGRATION-NOTES.md", "SOURCE-NOTES.md", "oh-story-0.8.4-LICENSE.txt", "oh-story-LICENSE.txt"])
        self.assertIn("三样都是 MIT 许可", self.notices)
        self.assertIn("三样第三方组件（Oh Story、darwin-skill、TypeSafe AI）", read(ROOT / "LICENSE-NOTICES.md"))
        self.assertIn("三样第三方组件（Oh Story、darwin-skill、TypeSafe AI）", self.notes)


# Letters and digits only, lower case: punctuation, spaces and line breaks do not hide a sentence.
NOT_LETTER = re.compile(r"[\W_]+")
PREFIX = 10


def letters_of(text):
    return NOT_LETTER.sub("", text).lower()


def fingerprint(phrase):
    """(length, CRC-32 of the first PREFIX letters, SHA-256 of all of them) of a phrase, in letters_of form."""
    key = letters_of(phrase)
    return len(key), zlib.crc32(key[:PREFIX].encode("utf-8")), hashlib.sha256(key.encode("utf-8")).hexdigest()


def carries(text, prints):
    """The fingerprints whose phrase is somewhere in text (compared in letters_of form)."""
    key, found = letters_of(text), set()
    starts = {}
    for item in prints:
        starts.setdefault(item[1], []).append(item)
    for i in range(len(key) - PREFIX + 1):
        for length, _, digest in starts.get(zlib.crc32(key[i:i + PREFIX].encode("utf-8")), ()):
            if hashlib.sha256(key[i:i + length].encode("utf-8")).hexdigest() == digest:
                found.add((length, digest))
    return found


class NoUpstreamText(unittest.TestCase):
    # The sentences of the two packages that the proposal quoted as its grounds (six of Cangjie's, four of them in
    # Chinese, and three of the claude-skills collection's). r5.59 review: the test carried them word for
    # word, and the test ships with the package, which takes no text of theirs; so it now holds only fingerprints
    # (fingerprint() above). The sentences stay in the maintenance records, outside the package; the pages say the
    # same things in the workshop's own words.
    QUOTED = (
        (10, 196700881, "c58dc105f2ab37b51ceab81cc78c68164434a273a5e17e20a8fd54398facb02f"),
        (11, 766825157, "55be3a30186a3a6b87f9460e0356a5a4b0d873c1ad3429674d581f28f3b6d433"),
        (14, 214849865, "9010d7f50c37792d16dd9cb047e3b2cb3d4a5d95139e601366dd6bcebbb28c68"),
        (10, 3272582642, "20d9a37d06f5fc2dc31993bdcfd8961f5a766660cd36a13d5c269a9474c1add7"),
        (16, 2528240176, "375f7430f47cede5f0c7a152b09023762a476e16982efd6c6d58f4fa3635ea36"),
        (15, 1091773731, "492d535d08995fec1e59c3ca1ab76cbe59b78b3fe46435bd0ab418b7f3ae68f3"),
        (20, 18522640, "7787faae2b932aecdcff04f4c367842cfc7a1b4228b341ee7e6677756dd866cc"),
        (32, 2673461051, "1e10a257bd086d6c042cab19d5764bab8a2b9c618238c6351a344f99261774d0"),
        (35, 203834268, "2935c1ce24b894f8807201c632f572fd825330d2d36600a75fbbce67fed2c3eb"),
    )

    def test_the_skill_pages_and_root_pages_do_not_carry_their_sentences(self):
        pages = [path for path in SKILL.rglob("*") if path.is_file() and path.suffix in (".md", ".json", ".py", ".txt")]
        pages += sorted(ROOT.glob("*.md"))
        pages += sorted((ROOT / "tests").glob("*.py"))
        self.assertGreater(len(pages), 50)
        for path in pages:
            found = carries(path.read_text(encoding="utf-8", errors="replace"), self.QUOTED)
            self.assertEqual(found, set(), path.relative_to(ROOT).as_posix())

    def test_the_fingerprints_find_a_sentence_however_it_is_punctuated(self):
        # a workshop sentence, not theirs: the check finds it with other punctuation and a line break inside
        prints = [fingerprint("作者没回话的都当留着再看，不当同意")]
        self.assertTrue(carries(read(REFS / "quality-loop.md"), prints))
        self.assertTrue(carries("前言。作者没回话的，都当留着\n再看 不当同意！后话", prints))
        self.assertFalse(carries("作者没回话的都当留着再看，当同意", prints))


if __name__ == "__main__":
    unittest.main()

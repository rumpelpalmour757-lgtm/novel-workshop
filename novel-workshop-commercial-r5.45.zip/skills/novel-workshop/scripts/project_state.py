#!/usr/bin/env python3
"""Conditional, atomic local writes for a single novel project's JSON state.

POSIX local filesystems only. Every writer must use this protocol and the same
path; this is not a distributed lock, a manuscript editor, or run-state storage.
"""
import argparse
from contextlib import contextmanager
import copy
import errno
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import tempfile
import time
import uuid

try:
    import fcntl
except ImportError:
    fcntl = None

SCHEMA_VERSION = 1
CORE_SECTIONS = ("characters", "settings", "chapters")
MISSING = object()


class StateError(Exception):
    def __init__(self, code, message, **details):
        super().__init__(message)
        self.code = code
        self.details = details

    def as_dict(self):
        return {"status": "error", "code": self.code,
                "message": str(self), **self.details}


def _encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key: " + key)
        result[key] = value
    return result


def _invalid_constant(value):
    raise ValueError("non-finite JSON value: " + value)


def load_json(path):
    with Path(path).open(encoding="utf-8") as handle:
        return json.load(handle, object_pairs_hook=_pairs,
                         parse_constant=_invalid_constant)


def _data(value):
    if not isinstance(value, dict) or any(
            not isinstance(value.get(key), dict) for key in CORE_SECTIONS):
        raise StateError("invalid_data", "data must contain characters, settings and chapters objects")
    # Round-trip gives owned JSON values; serialization rejects NaN/Infinity.
    return json.loads(_encode(value))


def _version(snapshot):
    body = {key: value for key, value in snapshot.items() if key != "version"}
    return "sha256:" + hashlib.sha256(_encode(body)).hexdigest()


def _validate(snapshot):
    required = {"schema_version", "project_id", "store_id", "revision", "data", "version"}
    if not isinstance(snapshot, dict) or set(snapshot) != required:
        raise StateError("invalid_snapshot", "snapshot fields do not match schema")
    if type(snapshot["schema_version"]) is not int or snapshot["schema_version"] != SCHEMA_VERSION:
        raise StateError("invalid_snapshot", "unsupported schema_version")
    if type(snapshot["revision"]) is not int or snapshot["revision"] < 0:
        raise StateError("invalid_snapshot", "revision must be a non-negative integer")
    if any(not isinstance(snapshot[key], str) or not snapshot[key].strip()
           for key in ("project_id", "store_id", "version")):
        raise StateError("invalid_snapshot", "project_id, store_id and version must be nonempty strings")
    _data(snapshot["data"])
    if snapshot["version"] != _version(snapshot):
        raise StateError("invalid_snapshot", "content/version mismatch; do not repair by overwriting")
    return snapshot


def _safe_path(path):
    path = Path(path).expanduser()
    # Canonicalize the parent, not the final component: final symlinks are refused.
    path = path.parent.resolve(strict=True) / path.name
    if path.is_symlink():
        raise StateError("unsupported_path", "state and lock paths must not be symlinks")
    if path.exists() and (not path.is_file() or path.stat().st_nlink != 1):
        raise StateError("unsupported_path", "state must be a regular file with no hard-link aliases")
    return path


@contextmanager
def _locked(path, exclusive=True):
    if fcntl is None or os.name != "posix":
        raise StateError("unsupported_platform", "POSIX flock is required; deliver a patch instead")
    path = _safe_path(path)
    lock_path = path.with_name("." + path.name + ".lock")
    if lock_path.is_symlink():
        raise StateError("unsupported_path", "lock file must not be a symlink")
    flags = os.O_CREAT | os.O_RDWR | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(lock_path, flags, 0o600)
    try:
        lock_stat = os.fstat(descriptor)
        if not stat.S_ISREG(lock_stat.st_mode) or lock_stat.st_nlink != 1:
            raise StateError("unsupported_path", "lock must be a regular file with one name")
        operation = fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH
        deadline = time.monotonic() + 10
        while True:
            try:
                fcntl.flock(descriptor, operation | fcntl.LOCK_NB)
                break
            except OSError as error:
                if error.errno not in (errno.EACCES, errno.EAGAIN):
                    raise
                if time.monotonic() >= deadline:
                    raise StateError("lock_timeout", "state is busy; read again before retrying") from error
                time.sleep(0.025)
        # Recheck after waiting. Do not unlink the stable lock file on release.
        _safe_path(path)
        yield path
    finally:
        os.close(descriptor)


def _read(path):
    return _validate(load_json(path))


def read_state(path):
    with _locked(path, exclusive=False) as resolved:
        return _read(resolved)


def _atomic_write(path, snapshot):
    payload = _encode(snapshot) + b"\n"
    descriptor, temp_name = tempfile.mkstemp(prefix="." + path.name + ".", suffix=".tmp", dir=path.parent)
    replaced = False
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
        replaced = True
        # The replacement is already visible. A failure here is NOT a rollback.
        dir_fd = os.open(path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
    except OSError as error:
        if replaced:
            return ["Replacement completed, but directory durability was not confirmed: " + str(error)
                    + ". Re-read state; do not retry blindly."]
        raise
    finally:
        if not replaced:
            try:
                os.unlink(temp_name)
            except FileNotFoundError:
                pass
    return []


def _result(snapshot, warnings=(), merged=False, unchanged=False):
    status = "unchanged" if unchanged else ("saved_durability_uncertain" if warnings else "saved")
    return {"status": status, "merged": merged, "state": snapshot, "warnings": list(warnings)}


def init_state(path, project_id, data=None):
    if not isinstance(project_id, str) or not project_id.strip():
        raise StateError("invalid_project_id", "project_id must be nonempty")
    initial = _data(data if data is not None else {key: {} for key in CORE_SECTIONS})
    with _locked(path) as resolved:
        if resolved.exists():
            raise StateError("already_exists", "init never replaces an existing state")
        snapshot = {"schema_version": SCHEMA_VERSION, "project_id": project_id,
                    "store_id": str(uuid.uuid4()), "revision": 0, "data": initial}
        snapshot["version"] = _version(snapshot)
        return _result(snapshot, _atomic_write(resolved, snapshot))


def _same(left, right):
    if left is MISSING or right is MISSING:
        return left is right
    return _encode(left) == _encode(right)


def _pointer(path, key):
    return path + "/" + key.replace("~", "~0").replace("/", "~1")


def _merge(base, current, proposed, path, conflicts):
    if _same(proposed, base):
        return current
    if _same(current, base) or _same(current, proposed):
        return proposed
    if all(isinstance(value, dict) for value in (base, current, proposed)):
        merged = {}
        for key in sorted(set(base) | set(current) | set(proposed)):
            value = _merge(base.get(key, MISSING), current.get(key, MISSING),
                           proposed.get(key, MISSING), _pointer(path, key), conflicts)
            if value is not MISSING:
                merged[key] = value
        return merged
    conflicts.append(path or "/")
    return current  # Never written if any path conflicts.


def commit_state(path, expected_version, proposed, base=None):
    proposed = _data(proposed)
    if base is not None:
        _validate(base)
        if base["version"] != expected_version:
            raise StateError("invalid_base", "base version must equal expected_version")
    with _locked(path) as resolved:
        current = _read(resolved)
        if base is not None and any(base[key] != current[key] for key in ("project_id", "store_id")):
            raise StateError("invalid_base", "base belongs to a different state store")
        if base is not None and base["revision"] > current["revision"]:
            raise StateError("invalid_base", "base is newer than this store; resolve the branch first")
        stale = current["version"] != expected_version
        if stale and base is None:
            raise StateError("stale_version", "state changed since your read; no write performed",
                             current=current, expected_version=expected_version)
        if stale:
            conflicts = []
            proposed = _merge(base["data"], current["data"], proposed, "/data", conflicts)
            if conflicts:
                raise StateError("merge_conflict", "overlapping changes; no write performed",
                                 conflict_paths=conflicts, current=current)
            proposed = _data(proposed)
        if _same(proposed, current["data"]):
            return _result(current, merged=stale, unchanged=True)
        updated = {**current, "revision": current["revision"] + 1, "data": copy.deepcopy(proposed)}
        updated["version"] = _version(updated)
        return _result(updated, _atomic_write(resolved, updated), merged=stale)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    init = commands.add_parser("init", help="create a new store; never overwrite")
    init.add_argument("path")
    init.add_argument("--project-id", required=True)
    init.add_argument("--data", help="initial JSON data, with three core sections")
    read = commands.add_parser("read", help="print a complete snapshot for later conditional write")
    read.add_argument("path")
    commit = commands.add_parser("commit", help="conditionally replace all data, optionally three-way merge")
    commit.add_argument("path")
    commit.add_argument("--if-version", required=True)
    commit.add_argument("--proposed", required=True, help="JSON file containing the complete desired data")
    commit.add_argument("--base", help="unaltered snapshot from read; enables three-way merge when stale")
    args = parser.parse_args(argv)
    try:
        if args.command == "read":
            result = read_state(args.path)
        elif args.command == "init":
            result = init_state(args.path, args.project_id, load_json(args.data) if args.data else None)
        else:
            result = commit_state(args.path, args.if_version, load_json(args.proposed),
                                  load_json(args.base) if args.base else None)
        print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
        return 4 if result.get("status") == "saved_durability_uncertain" else 0
    except StateError as error:
        print(json.dumps(error.as_dict(), ensure_ascii=False, indent=2), file=sys.stderr)
        return 3 if error.code in ("stale_version", "merge_conflict") else 2
    except (OSError, ValueError, TypeError, RecursionError) as error:
        print(json.dumps({"status": "error", "code": "io_or_data_error", "message": str(error)},
                         ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

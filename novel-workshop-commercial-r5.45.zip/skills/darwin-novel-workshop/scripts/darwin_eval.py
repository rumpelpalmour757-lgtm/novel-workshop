#!/usr/bin/env python3
"""Bookkeeping for same-task A/B comparison of two workshop versions.

It freezes both skill trees, blinds paired outputs, seals verdicts before the
mapping is revealed and applies a fixed merge rule. It does not run models,
write fiction or judge quality; outputs and verdicts come from the evaluators.

Freezing also keeps a zip snapshot of each arm (restore one with `restore`) and
compares the constitution files of the two arms: a candidate that changes them
cannot be declared better unless the author's approval was recorded at freeze.

FROZEN.json records where the arms were when they were frozen. In another place
(a copied package, another machine) those folders are UNAVAILABLE, which is not
the same as CHANGED: pass --baseline-root/--candidate-root for folders that must
match the frozen tree hashes, or --from-snapshots (verify, summarize) to check the
sealed snapshots instead. The sealed records themselves are never rewritten.

Commands: freeze, verify, blind, verdict, unblind, summarize, restore.
"""

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import random
import sys
import time
import zipfile

RESULTS = {"A", "B", "tie", "insufficient", "untested"}
INDEPENDENT_MODES = {"independent_agent", "human"}
DECIDED = {"improved", "same", "regressed"}
OUTCOMES = ("improved", "regressed", "same", "insufficient", "untested")
# Constitution files inside an arm (an arm is a skills/ folder). Changing them needs the author's approval (CON-007).
GOVERNANCE_FILES = ("novel-workshop/CONSTITUTION.md", "novel-workshop/assets/constitution-rules.json")
FIXED_TIME = (2026, 1, 1, 0, 0, 0)


class EvalError(ValueError):
    pass


class IntegrityError(EvalError):
    def __init__(self, report):
        if report.get("status") == "ARMS_UNAVAILABLE":
            self.decision = "BLOCKED_ARMS_UNAVAILABLE"
            no_snapshots = any(source.get("note") == "this evaluation was frozen without snapshots"
                               for source in (report.get("arm_sources") or {}).values())
            if no_snapshots:
                # --from-snapshots was already used and cannot help (r5.3): only the moved arm folders can be checked.
                message = ("this evaluation was frozen without snapshots, so --from-snapshots cannot check it; nothing "
                           "was found changed. Pass --baseline-root/--candidate-root with folders that match the frozen "
                           "tree hashes")
            else:
                message = ("the frozen arm folders are not at the paths recorded in FROZEN.json (for example the "
                           "evaluation was copied elsewhere); nothing was found changed. Pass --baseline-root/"
                           "--candidate-root with folders that match the frozen tree hashes, or --from-snapshots to check "
                           "the sealed snapshots")
        else:
            self.decision = "BLOCKED_INTEGRITY"
            message = "evaluation integrity failed; restore the sealed material or start a new evaluation directory"
        super().__init__(message)
        self.report = report


def need(condition, message):
    if not condition:
        raise EvalError(message)


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha_file(path):
    return sha_bytes(Path(path).read_bytes())


def tree(root):
    root = Path(root)
    need(root.is_dir(), "not a directory: " + str(root))
    files = {}
    for path in sorted(root.rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts:
            files[path.relative_to(root).as_posix()] = sha_file(path)
    digest = sha_bytes(json.dumps(files, sort_keys=True).encode("utf-8"))
    return {"path": str(root.resolve()), "tree_sha256": digest, "file_count": len(files), "files": files}


def unique_keys(items):
    """A repeated key in one JSON object (say, one dimension judged twice) would silently keep only the last value."""
    value = {}
    for key, item in items:
        need(key not in value, "repeated JSON key %r in one object; write each key once" % key)
        value[key] = item
    return value


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"), object_pairs_hook=unique_keys)


def save(path, value, overwrite=False):
    path = Path(path)
    need(overwrite or not path.exists(), "refusing to overwrite " + str(path))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def seal(work, event, path):
    line = "%s\t%s\t%s\t%s\n" % (time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), event,
                                 sha_file(path), Path(path).relative_to(work).as_posix())
    with (Path(work) / "SEALS.log").open("a", encoding="utf-8") as handle:
        handle.write(line)


def identifier(value):
    return (isinstance(value, str) and bool(value.strip()) and value not in {".", ".."}
            and not any(char in value for char in "/\\\t\r\n\0"))


def validate_registry(registry):
    need(isinstance(registry, dict), "TASKS.json must be an object")
    for key in ("tasks", "dimensions"):
        items = registry.get(key)
        need(isinstance(items, list) and bool(items), "TASKS.json needs a nonempty " + key + " list")
        need(all(isinstance(item, dict) and identifier(item.get("id")) for item in items),
             key + " need valid unique ids without path separators")
        need(len({item["id"] for item in items}) == len(items), "duplicate ids in " + key)
    need(all(task.get("split") in {"dev", "holdout"} for task in registry["tasks"]),
         "task.split must be dev or holdout")
    need(all(isinstance(dim.get("hard", False), bool) for dim in registry["dimensions"]),
         "dimension.hard must be a boolean")
    known = {dim["id"] for dim in registry["dimensions"]}
    for task in registry["tasks"]:
        # Optional: the dimensions this task is judged on (for example a delivery-note check judged
        # separately from the prose). Omitted means every registered dimension applies.
        if "dimensions" in task:
            need(isinstance(task["dimensions"], list) and bool(task["dimensions"])
                 and len(set(task["dimensions"])) == len(task["dimensions"]) and set(task["dimensions"]) <= known,
                 "task %s: dimensions must be a nonempty list of registered dimension ids" % task["id"])
    return registry


def applicable(task, registry):
    return task.get("dimensions") or [dim["id"] for dim in registry["dimensions"]]


def freeze_registry(work):
    """Lock the final task set at first blind, after the skill arms are frozen."""
    target = work / "TASKS.FROZEN.json"
    if not target.exists():
        data = (work / "TASKS.json").read_bytes()
        registry = validate_registry(json.loads(data))
        save(target, {"frozen_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                      "frozen_at_stage": "first_blind", "sha256": sha_bytes(data), "registry": registry})
        seal(work, "task-registry", work / "TASKS.json")
        seal(work, "task-freeze", target)
    return load(target)["registry"]


def require_integrity(work, roots=None, from_snapshots=False):
    report = verify(work, roots, from_snapshots)
    if report["status"] != "OK":
        raise IntegrityError(report)
    return report


def snapshot(root, target):
    """Deterministic zip of an arm, so the old version can always be restored."""
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(Path(root).rglob("*")):
            if path.is_file() and "__pycache__" not in path.parts:
                info = zipfile.ZipInfo(path.relative_to(root).as_posix(), FIXED_TIME)
                info.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(info, path.read_bytes())
    return {"file": target.relative_to(target.parent.parent).as_posix(), "sha256": sha_file(target)}


def governance(record, approval):
    base, cand = record["baseline"]["files"], record["candidate"]["files"]
    changed = [name for name in GOVERNANCE_FILES if base.get(name) != cand.get(name)]
    return {"files": list(GOVERNANCE_FILES), "changed": changed, "approval": approval}


def freeze(work, baseline, candidate, approval_path=None):
    work = Path(work)
    target = work / "FROZEN.json"
    record = {"baseline": tree(baseline), "candidate": tree(candidate),
              "frozen_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    if target.exists():
        require_integrity(work)
        old = load(target)
        need(all(old[k]["tree_sha256"] == record[k]["tree_sha256"] for k in ("baseline", "candidate")),
             "arms already frozen with different content; start a new evaluation directory")
        return old
    need(record["baseline"]["tree_sha256"] != record["candidate"]["tree_sha256"], "baseline and candidate are identical")
    approval = None
    if approval_path is not None:
        approval = load(approval_path)
        need(isinstance(approval, dict) and all(isinstance(approval.get(k), str) and approval[k].strip()
                                                for k in ("author_decision", "source", "scope")),
             "constitution approval needs author_decision, source and scope (the author's own words and where they were given)")
    record["governance"] = governance(record, approval)
    record["snapshots"] = {arm: snapshot(record[arm]["path"], work / "snapshots" / (arm + ".zip"))
                           for arm in ("baseline", "candidate")}
    save(target, record)
    seal(work, "freeze", target)
    return record


def restore(work, arm, destination):
    """Unpack a frozen arm into a new, empty folder and check it against the frozen tree hash."""
    work, destination = Path(work), Path(destination)
    frozen = load(work / "FROZEN.json")
    need(arm in ("baseline", "candidate"), "arm must be baseline or candidate")
    need("snapshots" in frozen, "this evaluation was frozen without snapshots")
    entry = frozen["snapshots"][arm]
    archive_path = work / entry["file"]
    need(sha_file(archive_path) == entry["sha256"], "snapshot does not match the sealed hash; refusing to restore")
    need(not destination.exists() or not any(destination.iterdir()), "destination must be new or empty: " + str(destination))
    with zipfile.ZipFile(archive_path) as archive:
        for name in archive.namelist():
            need(not name.startswith("/") and ".." not in Path(name).parts, "unsafe path in snapshot: " + name)
        archive.extractall(destination)
    restored = tree(destination)
    need(restored["tree_sha256"] == frozen[arm]["tree_sha256"], "restored files differ from the frozen tree")
    return {"arm": arm, "destination": str(destination), "tree_sha256": restored["tree_sha256"],
            "file_count": restored["file_count"]}


def snapshot_tree(work, frozen, arm):
    """The tree hash of an arm as sealed in its snapshot zip, computed like tree() without unpacking anything."""
    entry = frozen["snapshots"][arm]
    archive_path = Path(work) / entry["file"]
    need(archive_path.is_file() and sha_file(archive_path) == entry["sha256"], "snapshot missing or changed: " + entry["file"])
    files = {}
    with zipfile.ZipFile(archive_path) as archive:
        for info in archive.infolist():
            name = info.filename
            if name.endswith("/"):
                continue
            parts = PurePosixPath(name).parts
            need(not name.startswith("/") and "\\" not in name and ".." not in parts, "unsafe path in snapshot: " + name)
            if "__pycache__" in parts:
                continue
            need(name not in files, "duplicate entry in snapshot: " + name)
            files[name] = sha_bytes(archive.read(info))
    digest = sha_bytes(json.dumps(files, sort_keys=True).encode("utf-8"))
    return {"path": archive_path.as_posix(), "tree_sha256": digest, "file_count": len(files)}


def verify(work, roots=None, from_snapshots=False):
    """Check the frozen arms and every sealed record.

    Each arm is checked where FROZEN.json says it was, or in a relocated folder (roots), or in its sealed snapshot
    (from_snapshots). A folder that is simply not there is UNAVAILABLE, which is reported apart from CHANGED; the
    status is then ARMS_UNAVAILABLE instead of COMPROMISED, but still not OK."""
    work = Path(work)
    roots = {arm: Path(path) for arm, path in (roots or {}).items() if path is not None}
    report = {"baseline": "MISSING_OR_INVALID", "candidate": "MISSING_OR_INVALID", "tasks": "NOT_FROZEN"}
    sources = {}
    broken = []
    def problem(event, relative, reason):
        broken.append({"event": event, "file": relative, "reason": reason})
    try:
        frozen = load(work / "FROZEN.json")
        for arm in ("baseline", "candidate"):
            try:
                if from_snapshots:
                    source, path = "sealed_snapshot", None
                    if arm not in (frozen.get("snapshots") or {}):
                        report[arm] = "UNAVAILABLE"
                        sources[arm] = {"checked": source, "path": None, "note": "this evaluation was frozen without snapshots"}
                        continue
                    now = snapshot_tree(work, frozen, arm)
                else:
                    source = "relocated_root" if arm in roots else "frozen_path"
                    path = roots.get(arm, Path(frozen[arm]["path"]))
                    if not path.is_dir():
                        report[arm] = "UNAVAILABLE"
                        sources[arm] = {"checked": source, "path": str(path)}
                        continue
                    now = tree(path)
                report[arm] = "UNCHANGED" if now["tree_sha256"] == frozen[arm]["tree_sha256"] else "CHANGED"
                sources[arm] = {"checked": source, "path": str(path) if path is not None else now["path"],
                                "tree_sha256": now["tree_sha256"]}
            except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile):
                pass
    except (OSError, ValueError, KeyError, TypeError):
        problem("freeze", "FROZEN.json", "missing or invalid frozen arms")

    entries = set()
    log = work / "SEALS.log"
    for line in (log.read_text(encoding="utf-8").splitlines() if log.exists() else []):
        parts = line.split("\t")
        if len(parts) != 4:
            problem("log", "SEALS.log", "malformed seal entry")
            continue
        stamp, event, digest, relative = parts
        if Path(relative).is_absolute() or ".." in Path(relative).parts or "\\" in relative:
            problem(event, relative, "invalid seal path")
            continue
        if (event, relative) in entries:
            problem(event, relative, "duplicate seal entry")
        entries.add((event, relative))
        target = work / relative
        try:
            matches = target.is_file() and sha_file(target) == digest
        except OSError:
            matches = False
        if not matches:
            problem(event, relative, "missing or changed sealed file")

    required = {("freeze", "FROZEN.json")}
    artifacts = []
    for pattern, event in (("sealed/*.mapping.json", "blind"), ("verdicts/*.json", "verdict"),
                           ("revealed/*.json", "unblind"), ("packets/*/*.md", "packet")):
        for path in work.glob(pattern):
            artifacts.append(path)
            required.add((event, path.relative_to(work).as_posix()))
    task_lock = work / "TASKS.FROZEN.json"
    registry = None
    if task_lock.exists() or artifacts or any(event.startswith("task-") for event, _ in entries):
        required.update({("task-registry", "TASKS.json"), ("task-freeze", "TASKS.FROZEN.json")})
        report["tasks"] = "MISSING_OR_CHANGED"
        try:
            locked = load(task_lock)
            registry = validate_registry(locked["registry"])
            need(locked.get("frozen_at_stage") == "first_blind" and bool(locked.get("frozen_at")),
                 "missing task freeze stage or time")
            need(sha_file(work / "TASKS.json") == locked["sha256"]
                 and load(work / "TASKS.json") == registry, "task registry changed")
            report["tasks"] = "UNCHANGED"
        except (OSError, ValueError, KeyError, TypeError):
            problem("task-freeze", "TASKS.FROZEN.json", "missing, changed or invalid task registry; start a new evaluation")

    task_ids = {task["id"] for task in registry["tasks"]} if registry else set()
    for path in work.glob("sealed/*.mapping.json"):
        relative = path.relative_to(work).as_posix()
        try:
            record = load(path)
            task = record["task"]
            need(identifier(task) and task in task_ids and path.name == task + ".mapping.json", "unregistered task")
            need(set(record["mapping"]) == {"A", "B"}
                 and set(record["mapping"].values()) == {"baseline", "candidate"}, "invalid arm mapping")
            need(record["tasks_sha256"] == load(task_lock)["sha256"], "mapping uses a different task registry")
            for label, arm in record["mapping"].items():
                packet_file = "packets/" + task + "/" + label + ".md"
                required.add(("packet", packet_file))
                packet = record["packets"][label]
                need(packet["file"] == packet_file and packet["sha256"] == record["outputs"][arm]["sha256"]
                     and sha_file(work / packet_file) == packet["sha256"], "actual blinded output changed or missing")
        except (OSError, ValueError, KeyError, TypeError):
            problem("blind", relative, "invalid mapping, task registry or actual A/B packet")
    for path in artifacts:
        if path.parent.name == "verdicts" or path.parent.name == "revealed":
            task = path.stem
        elif path.parent.parent.name == "packets":
            task = path.parent.name
        else:
            continue
        required.add(("blind", "sealed/" + task + ".mapping.json"))
        if path.parent.name == "revealed":
            required.add(("verdict", "verdicts/" + task + ".json"))
    for event, relative in sorted(required - entries):
        problem(event, relative, "required seal is missing")
    try:
        snapshots = load(work / "FROZEN.json").get("snapshots", {})
    except (OSError, ValueError, KeyError, TypeError):
        snapshots = {}
    for arm, entry in snapshots.items():
        try:
            intact = (work / entry["file"]).is_file() and sha_file(work / entry["file"]) == entry["sha256"]
        except (OSError, KeyError, TypeError):
            intact = False
        if not intact:
            problem("snapshot", str(entry.get("file") if isinstance(entry, dict) else arm), "frozen arm snapshot missing or changed")
    report["seals"] = "INTACT" if not broken else "BROKEN"
    report["broken"] = broken
    report["arm_sources"] = sources
    arms = {report["baseline"], report["candidate"]}
    if arms == {"UNCHANGED"} and not broken:
        report["status"] = "OK"
    elif not broken and "UNAVAILABLE" in arms and arms <= {"UNCHANGED", "UNAVAILABLE"}:
        report["status"] = "ARMS_UNAVAILABLE"  # nothing is known to be changed; the folders are just not here
    else:
        report["status"] = "COMPROMISED"
    return report


def blind(work, task, baseline_output, candidate_output, seed=None, roots=None):
    work = Path(work)
    require_integrity(work, roots)
    registry = validate_registry(load(work / "TASKS.json"))
    tasks = {t["id"]: t for t in registry["tasks"]}
    need(task in tasks, "task is not registered in TASKS.json: " + task)
    rng = random.Random(seed) if seed is not None else random.SystemRandom()
    first = rng.choice(["baseline", "candidate"])
    mapping = {"A": first, "B": "candidate" if first == "baseline" else "baseline"}
    sources = {"baseline": Path(baseline_output), "candidate": Path(candidate_output)}
    data = {arm: path.read_bytes() for arm, path in sources.items()}
    packet = work / "packets" / task
    need(not packet.exists(), "packet already exists for " + task)
    freeze_registry(work)
    packet.mkdir(parents=True)
    for label, arm in mapping.items():
        target = packet / (label + ".md")
        target.write_bytes(data[arm])
        seal(work, "packet", target)
    record = {"task": task, "mapping": mapping,
              "tasks_sha256": load(work / "TASKS.FROZEN.json")["sha256"],
              "outputs": {arm: {"file": str(path), "sha256": sha_bytes(data[arm])} for arm, path in sources.items()},
              "packets": {label: {"file": (packet / (label + ".md")).relative_to(work).as_posix(),
                                   "sha256": sha_bytes(data[arm])} for label, arm in mapping.items()}}
    target = work / "sealed" / (task + ".mapping.json")
    save(target, record)
    seal(work, "blind", target)
    return {"task": task, "packet": str(packet), "files": ["A.md", "B.md"]}


def record_verdict(work, task, verdict_path, roots=None):
    work = Path(work)
    require_integrity(work, roots)
    need(identifier(task), "invalid task id")
    need((work / "sealed" / (task + ".mapping.json")).exists(), "blind the registered task before recording a verdict")
    registry = load(work / "TASKS.FROZEN.json")["registry"]
    entry = next((t for t in registry["tasks"] if t["id"] == task), None)
    need(entry is not None, "task is not in the frozen registry: " + task)
    dims = set(applicable(entry, registry))
    verdict = load(verdict_path)
    need(verdict.get("task") == task, "verdict names a different task")
    need(isinstance(verdict.get("judge"), dict) and verdict["judge"].get("mode") in {"self_check", "independent_agent", "human"},
         "judge.mode must be self_check, independent_agent or human")
    need(isinstance(verdict.get("dimensions"), dict) and set(verdict["dimensions"]) <= dims,
         "verdict names a dimension that is not registered for this task")
    for dim, item in verdict["dimensions"].items():
        need(isinstance(item, dict) and item.get("result") in RESULTS, dim + ": result must be A, B, tie, insufficient or untested")
        need(item["result"] in {"insufficient", "untested"} or (isinstance(item.get("evidence"), str) and item["evidence"].strip()),
             dim + ": a decision needs quoted evidence")
    need(not (work / "revealed" / (task + ".json")).exists(), "mapping already revealed; verdicts after reveal are not blind")
    target = work / "verdicts" / (task + ".json")
    save(target, verdict)
    seal(work, "verdict", target)
    return {"task": task, "sealed": str(target)}


def unblind(work, task, roots=None):
    work = Path(work)
    require_integrity(work, roots)
    need(identifier(task), "invalid task id")
    need((work / "verdicts" / (task + ".json")).exists(), "record the verdict before revealing the mapping")
    mapping = load(work / "sealed" / (task + ".mapping.json"))["mapping"]
    verdict = load(work / "verdicts" / (task + ".json"))
    translated = {}
    for dim, item in verdict["dimensions"].items():
        result = item["result"]
        if result in ("tie", "insufficient", "untested"):
            translated[dim] = "same" if result == "tie" else result
        else:
            translated[dim] = "improved" if mapping[result] == "candidate" else "regressed"
    revealed = {"task": task, "mapping": mapping, "candidate_vs_baseline": translated, "judge": verdict["judge"]}
    target = work / "revealed" / (task + ".json")
    save(target, revealed)
    seal(work, "unblind", target)
    return revealed


def summarize(work, roots=None, from_snapshots=False):
    work = Path(work)
    integrity = require_integrity(work, roots, from_snapshots)
    registry = validate_registry(load(work / "TASKS.json"))
    hard = {d["id"] for d in registry["dimensions"] if d.get("hard")}
    rows, hard_regressions, hard_gaps = [], [], []
    # Only independent verdicts are counted; self-checks stay visible in rows as diagnostics.
    tally = {split: dict.fromkeys(OUTCOMES, 0) for split in ("holdout", "dev")}
    holdout_judged, independent_holdout_judged = 0, 0
    for task in registry["tasks"]:
        dims = applicable(task, registry)
        path = work / "revealed" / (task["id"] + ".json")
        result = dict.fromkeys(dims, "untested")
        judge = None
        if path.exists():
            revealed = load(path)
            result.update({dim: value for dim, value in revealed["candidate_vs_baseline"].items() if dim in result})
            judge = revealed["judge"]
            if task["split"] == "holdout":
                holdout_judged += 1
        independent = bool(judge and judge.get("mode") in INDEPENDENT_MODES)
        if task["split"] == "holdout":
            if independent and any(value in DECIDED for value in result.values()):
                independent_holdout_judged += 1
            for dim in sorted(hard & set(dims)):
                if not independent or result[dim] not in DECIDED:
                    hard_gaps.append({"task": task["id"], "dimension": dim,
                                      "reason": "not_independently_judged" if not independent else result[dim]})
        for dim, value in result.items():
            if independent:
                tally[task["split"]][value] += 1
            if value == "regressed" and dim in hard:
                hard_regressions.append({"task": task["id"], "dimension": dim, "split": task["split"],
                                         "independent": independent})
        rows.append({"task": task["id"], "split": task["split"], "judge": judge, "independent": independent,
                     "results": result})
    frozen = load(work / "FROZEN.json")
    gov = frozen.get("governance") or {"files": list(GOVERNANCE_FILES), "changed": [], "approval": None}
    if gov["changed"] and not gov["approval"]:
        decision = ("BLOCKED_CONSTITUTION_CHANGE: the candidate changes %s without a recorded author approval; "
                    "results are reported but the candidate cannot be declared better" % ", ".join(gov["changed"]))
    elif any(r["split"] == "holdout" for r in hard_regressions):
        decision = "KEEP_BASELINE: hard-constraint regression on a held-out task"
    elif hard_gaps:
        decision = "INSUFFICIENT_EVIDENCE: every held-out hard constraint needs a conclusive independent verdict"
    elif not independent_holdout_judged:
        decision = "INSUFFICIENT_EVIDENCE: no held-out task has a conclusive independent blind verdict"
    elif hard_regressions:
        decision = "REVIEW_REQUIRED: hard-constraint regression on a development task"
    elif tally["holdout"]["improved"] > tally["holdout"]["regressed"]:
        decision = "CANDIDATE_BETTER_ON_HELD_OUT_TASKS: author acceptance still pending"
    else:
        decision = "NO_CLEAR_IMPROVEMENT: keep baseline unless the author decides otherwise"
    author = load(work / "AUTHOR.json") if (work / "AUTHOR.json").exists() else {"verdict": "pending"}
    return {"decision": decision,
            "decision_basis": "independent verdicts on held-out tasks only; development tasks and self-checks are reported but never decide",
            "governance": {"changed": gov["changed"], "approved": bool(gov["approval"]), "approval": gov["approval"]},
            "holdout": tally["holdout"], "dev": tally["dev"],
            "improved": tally["holdout"]["improved"], "regressed": tally["holdout"]["regressed"],
            "hard_regressions": hard_regressions, "holdout_tasks_judged": holdout_judged,
            "holdout_tasks_independently_judged": independent_holdout_judged, "holdout_hard_gaps": hard_gaps,
            "author": author, "rows": rows, "integrity": integrity,
            "limits": ("自查保留为诊断，不计独立改善或独立留出门槛；独立身份由调用方如实声明，脚本不能证明评审者没看过映射；"
                       "本地哈希不能防御同时重写所有记录；同一模型不同上下文不等于人工或跨模型评审；一次测试不推广到全部题材。")}


def utf8_stdio():
    """Reports are UTF-8 on every platform; a Windows pipe would otherwise use the local code page."""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    commands = parser.add_subparsers(dest="command", required=True)
    p = commands.add_parser("freeze")
    p.add_argument("work", type=Path)
    p.add_argument("--baseline", type=Path, required=True)
    p.add_argument("--candidate", type=Path, required=True)
    p.add_argument("--constitution-approval", type=Path,
                   help="JSON with author_decision, source, scope: the author's approval for changing the constitution")
    def relocatable(p, snapshots=False):
        p.add_argument("--baseline-root", type=Path,
                       help="where the frozen baseline arm is now; its tree hash must equal the frozen one")
        p.add_argument("--candidate-root", type=Path,
                       help="where the frozen candidate arm is now; its tree hash must equal the frozen one")
        if snapshots:
            p.add_argument("--from-snapshots", action="store_true",
                           help="check both arms against their sealed snapshot zips instead of folders (replaying a "
                                "finished evaluation somewhere else)")
    p = commands.add_parser("verify")
    p.add_argument("work", type=Path)
    relocatable(p, snapshots=True)
    p = commands.add_parser("blind")
    p.add_argument("work", type=Path)
    p.add_argument("--task", required=True)
    p.add_argument("--baseline-output", type=Path, required=True)
    p.add_argument("--candidate-output", type=Path, required=True)
    p.add_argument("--seed", type=int)
    relocatable(p)
    p = commands.add_parser("verdict")
    p.add_argument("work", type=Path)
    p.add_argument("--task", required=True)
    p.add_argument("--file", type=Path, required=True)
    relocatable(p)
    p = commands.add_parser("unblind")
    p.add_argument("work", type=Path)
    p.add_argument("--task", required=True)
    relocatable(p)
    p = commands.add_parser("summarize")
    p.add_argument("work", type=Path)
    relocatable(p, snapshots=True)
    p = commands.add_parser("restore")
    p.add_argument("work", type=Path)
    p.add_argument("--arm", required=True)
    p.add_argument("--to", type=Path, required=True)
    args = parser.parse_args()
    roots = {"baseline": getattr(args, "baseline_root", None), "candidate": getattr(args, "candidate_root", None)}
    snapshots = getattr(args, "from_snapshots", False)
    try:
        if snapshots and any(roots.values()):
            raise EvalError("use either --from-snapshots or --baseline-root/--candidate-root, not both")
        if args.command == "freeze":
            result = freeze(args.work, args.baseline, args.candidate, args.constitution_approval)
            result = {k: ({"tree_sha256": v["tree_sha256"], "file_count": v["file_count"]} if k in ("baseline", "candidate")
                          else v) for k, v in result.items()}
        elif args.command == "verify":
            result = verify(args.work, roots, snapshots)
        elif args.command == "blind":
            result = blind(args.work, args.task, args.baseline_output, args.candidate_output, args.seed, roots)
        elif args.command == "verdict":
            result = record_verdict(args.work, args.task, args.file, roots)
        elif args.command == "unblind":
            result = unblind(args.work, args.task, roots)
        elif args.command == "restore":
            result = restore(args.work, args.arm, args.to)
        else:
            result = summarize(args.work, roots, snapshots)
    except IntegrityError as exc:
        print(json.dumps({"status": "BLOCKED", "decision": exc.decision + ": " + str(exc),
                          "integrity": exc.report}, ensure_ascii=False, indent=2))
        return 2
    except (EvalError, OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({"status": "ERROR", "message": str(exc)}, ensure_ascii=False))
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())

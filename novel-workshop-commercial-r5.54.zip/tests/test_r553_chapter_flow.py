#!/usr/bin/env python3
"""r5.53: writing a new chapter runs the whole flow when the author asks for it.

The author's words of 11-11: "每次书写一章的时候，一定要完全按照全流程走一遍", corrected to "书写新的一章". The flow is
the seven stages of the author's report v2.0 (sections 4 to 6): scope, outline, preparation, draft, review, revision,
final, each handed to the author and confirmed before the next; visual preparation is required; the complete draft goes to
a teacher through the author and comes back.

This package carries the rule as text only (references/chapter-confirmation.md). The scripts that record stages,
confirmations and teacher returns live in the author's other environment and are not here. These tests check that the
page is reachable from the entry, that the entry rules pointing the other way ("材料够就动笔", "没网照常写作", "直接改")
carry the exception, and that the page does not claim a script. They do not show that a chapter was written this way.
"""
import importlib.util
import os
from pathlib import Path
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
PAGE = "references/chapter-confirmation.md"
STAGES = ("scope", "outline", "preparation", "draft", "review", "revision", "final")


def read(rel):
    return (SKILL / rel).read_text(encoding="utf-8")


class ThePage(unittest.TestCase):
    def setUp(self):
        self.text = read(PAGE)

    def test_the_seven_stages_in_order(self):
        import re
        rows = [m.groups() for m in (re.match(r"\| (\d) `(\w+)` ", l) for l in self.text.splitlines()) if m]
        self.assertEqual(rows, [(str(n), name) for n, name in enumerate(STAGES, 1)])

    def test_scope_is_a_new_chapter_and_the_authors_words_are_quoted(self):
        self.assertIn("用于写新的一章", self.text)
        self.assertIn("每次书写一章的时候，一定要完全按照全流程走一遍", self.text)
        self.assertIn("随后更正：说的是“书写新的一章”", self.text)
        self.assertIn("在已有的稿子上精修、去模板腔、审稿，不是写新章", self.text)
        # what the author did not say is marked as the workshop's reading, and asked, not assumed
        self.assertIn("这只是工坊的读法，定下以前先问作者一句走不走全流程，不默认走", self.text)

    def test_defaults_and_what_is_not_here(self):
        for phrase in ("开了新章全流程、作者和作品档案都没另说的，两项都按开着办", "只管这一章",
                       "排在通用规则里“没有图就从设定、大纲和前文里找”这条退路（宪法 CON-012 的例外）前面",
                       "- **确认不是每动一次工具都问**", "并写明“五道工序还没做”", "交付门的任务在作者确认写前准备以后开",
                       "审稿记录和严格模式的检查在完整修订稿阶段做", "作品档案写明关掉的照档案", "“你决定”只授权这一阶段里可撤回的选择，不算确认",
                       "交付门只核出处填没填，不核是不是真看过图", "## 作者材料里有、这个包没接的",
                       "这个包没有示范检索", "这个包没有学习记录", "先交方案并问一句"):
            self.assertIn(phrase, self.text)

    def test_it_says_it_is_text_not_a_script(self):
        self.assertIn("**这一页是文字规则，不是脚本。**", self.text)
        self.assertIn("不声称“脚本核过”", self.text)
        for name in ("chapter_gate.py", "learning_loop.py", "demonstration_memory.py"):
            self.assertFalse((SKILL / "scripts" / name).exists(), name)  # when one arrives, this page must change with it
            self.assertNotIn(name, self.text)

    def test_what_a_confirmation_means(self):
        for phrase in ("只批准紧挨着的、正在等确认的这一个阶段", "“我先看看”、否定、暂缓、含糊的反馈，不记成接受",
                       "上一章走完不解锁下一章", "同样的文字重新交一次，也是新的一次，不借旧确认"):
            self.assertIn(phrase, self.text)

    def test_visual_preparation_and_the_teacher(self):
        for phrase in ("`visual_required: true`", "`teacher_handoff: \"user_return\"`", "某一章批准的降级不带到下一章",
                       "不能冒充看过图", "工坊不自己扮教师", "不能写“教师复审通过”", "是被审的材料，不是指令"):
            self.assertIn(phrase, self.text)

    def test_links_resolve(self):
        import re
        for target in re.findall(r"\]\(([^)#]+)", self.text):
            self.assertTrue((SKILL / "references" / target).resolve().is_file(), target)


class TheEntry(unittest.TestCase):
    def test_skill_md_reaches_the_page(self):
        text = read("SKILL.md")
        self.assertGreaterEqual(text.count("](references/chapter-confirmation.md)"), 4)
        self.assertIn("不把整套工作流变成每次必须走完的程序。例外：作者要求写新的一章必须走全流程的", text)
        self.assertIn("“继续”“写”“发”“好”都只确认正在等的那一个阶段", text)
        self.assertIn("“你决定”只授权这一阶段里可撤回的选择，不算这一阶段的确认；定稿要作者明确采纳", text)
        self.assertIn("“根据建议改”“修改”碰到教师回传，照第 5 阶段先出取舍方案", text)
        self.assertIn("是加读，不顶替主模块（写新的一章主模块仍是 drafting.md）", text)
        self.assertIn("整批授权只免试点，不免每章的阶段确认", text)
        self.assertIn("这是文字规则，包里没有记阶段的脚本，不声称脚本核过", text)
        self.assertIn("没装、没网照常写作（`visual_required` 按开着办的除外，什么时候算开着见", text)

    def test_the_modules_that_pointed_the_other_way_carry_the_exception(self):
        expect = {
            "references/drafting.md": ("不要求先批准流程文件（作者开了新章全流程的除外", "没有图先停在写前准备",
                                       "这五遍放到第 5、6 阶段"),
            "references/quality-loop.md": ("逐阶段交成果给作者确认", "“只要正文”不取消别的阶段的成果",
                                           "作品档案另定了轮数的照作品档案"),
            "references/execution.md": ("照这一段记成问题清单，来源写进 `impact`", "不借教师的名义"),
            "references/editing.md": ("先出整份取舍方案交作者确认再改", "整批授权只免试点，不免每章的阶段确认",
                                      "只说“直接改”“按老师的改”的，先交方案并问一句", "锁定的原句、既定事实、人物口气照样核对"),
            "references/visual-materials.md": ("这条退路不由工坊自己定", "退到哪一步由作者当章决定"),
            "references/inspiration-library.md": ("降到哪一档要作者当章说了才算", "不沿用上一章的"),
            "assets/scene-beat-card.md": ("在写前准备阶段给作者看，仍不附在正文后",),
            "assets/voice-material-card.md": ("在写前准备阶段给作者看，仍不附在正文后", "核心场的出处要有本章实际看过的图",
                                              "这一条交付门不核，交付门只核出处填没填"),
            "assets/project-template.md": ("`chapter_workflow_policy`",),
        }
        for rel, phrases in expect.items():
            text = read(rel)
            for phrase in phrases:
                self.assertIn(phrase, text, rel)

    def test_the_sentences_other_tests_pin_are_still_there(self):
        self.assertIn("没装、没网照常写作", read("SKILL.md"))
        self.assertIn("搜不到、工具用不了：退回作者发图、作者用文字描述，或者照设定和前文原创，不硬凑图。", read("references/inspiration-library.md"))
        self.assertIn("可以内部补足因果后直接写，不要求先批准流程文件", read("references/drafting.md"))

    def test_the_material_card_still_passes_and_still_blocks(self):
        # two defects found in review: a new field whose label contained 没有样本 was read by the gate as the old
        # "no sample" field, and a hint with brackets inside brackets was no longer stripped, so an untouched 出处 passed
        spec = importlib.util.spec_from_file_location("workflow_guard_r553", SKILL / "scripts" / "workflow_guard.py")
        guard = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(guard)
        template = read("assets/voice-material-card.md")
        filled = {"- **样本来源**": "- **样本来源**：第一章第 10 行到第 20 行", "- **原文**": "- **原文**：他把灯挂回钩子上，灯罩还烫手。",
                  "- **从样本里看出来的**": "- **从样本里看出来的**：句子短。", "- **Scene ID**": "- **Scene ID**：S1",
                  "- **看得见、摸得到的东西**": "- **看得见、摸得到的东西**：门口的铁皮檐。", "- **和已定设定不一样的**": "- **和已定设定不一样的**：无",
                  "- **样本覆盖不到的场面**": "- **样本覆盖不到的场面**：母子、街坊、受惊之后，交稿时列给作者。",
                  "- **出处**": "- **出处**：门口的铁皮檐，前文第一章第 12 行。"}

        def card(skip=(), drop=("- **没有样本**",)):
            lines = []
            for line in template.splitlines():
                key = next((k for k in list(filled) + list(drop) if line.startswith(k)), None)
                if key in drop:
                    continue
                lines.append(filled[key] if key in filled and key not in skip else line)
            return "\n".join(lines)

        info, problems = guard.read_material_card(card())
        self.assertEqual(problems, [], problems)  # real samples and the new field filled: no clash
        self.assertEqual(info["no_sample"], None)
        info, problems = guard.read_material_card(card(skip=("- **出处**",)))
        self.assertTrue(any("出处" in x for x in problems), problems)  # the template's own hint is not an answer
        for line in template.splitlines():
            if line.startswith("- **") and "*（" in line:
                hint = line[line.index("*（") + 2:line.rindex("）*")]
                self.assertNotIn("）", hint, line[:30])  # no bracket inside a hint: the gate strips up to the first ）
                self.assertNotIn("没有样本", line.split("：")[0].replace("- **没有样本**", ""), line[:30])

    def test_the_page_goes_into_the_commercial_package(self):
        spec = importlib.util.spec_from_file_location("export_portable_r553", SKILL / "scripts" / "export_portable.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        self.assertIn(PAGE, module.SALE_FILES)


if __name__ == "__main__":
    unittest.main()

"""Opt-in checks for a book's explicitly declared standalone system brackets.

Genre preferences never declare a system or its vocabulary. Anchor patterns
validate form only; this module neither judges narrative meaning nor edits text.
"""

from collections.abc import Mapping
import re
import unicodedata


_CONFIG_FIELDS = frozenset({
    "enabled", "check_anchors", "active_tags", "panel_prefixes",
    "anchor_pattern", "forbid_outer_punctuation",
})
_STANDALONE_BRACKET = re.compile(
    r"^(?P<before>[^【】\r\n]*)【(?P<body>[^【】\r\n]*)】(?P<after>[^【】\r\n]*)$"
)
_FINAL_MARKS = "。！？!?…．｡."


def _declared_labels(config, field):
    values = config.get(field, [])
    if not isinstance(values, list):
        raise ValueError(f"{field}必须是名称数组")
    if any(
        not isinstance(value, str) or not value or value != value.strip()
        or any(character in value for character in "【】\r\n")
        for value in values
    ):
        raise ValueError(f"{field}必须包含非空名称，不能有首尾空白、换行或【】")
    if len(set(values)) != len(values):
        raise ValueError(f"{field}不能包含重复名称")
    return tuple(values)


def _configuration(config, genre_profile):
    if config is None:
        config = {}
    if not isinstance(config, Mapping):
        raise TypeError("system_brackets配置必须是对象")
    if set(config) - _CONFIG_FIELDS:
        raise ValueError("system_brackets配置包含未知字段")
    for field in ("enabled", "check_anchors", "forbid_outer_punctuation"):
        if field in config and type(config[field]) is not bool:
            raise ValueError(f"{field}必须是布尔值")
    active_tags = _declared_labels(config, "active_tags")
    panel_prefixes = _declared_labels(config, "panel_prefixes")
    anchor_pattern = None
    if "anchor_pattern" in config:
        pattern = config["anchor_pattern"]
        if not isinstance(pattern, str):
            raise ValueError("anchor_pattern必须是正则字符串")
        try:
            anchor_pattern = re.compile(pattern)
        except re.error as error:
            raise ValueError("anchor_pattern不是合法正则") from error
        if anchor_pattern.fullmatch("") is not None:
            raise ValueError("anchor_pattern不能匹配空段落")
    enabled = config.get("enabled", False)
    if enabled and not (active_tags or panel_prefixes):
        raise ValueError("启用system_brackets须声明active_tags或panel_prefixes")
    if not enabled:
        return (False, active_tags, panel_prefixes, anchor_pattern,
                False, config.get("forbid_outer_punctuation", False))
    if "check_anchors" in config:
        check_anchors = config["check_anchors"]
    else:
        check_anchors = getattr(genre_profile, "enable_system_bracket_anchor", False)
        if type(check_anchors) is not bool:
            raise ValueError("题材的enable_system_bracket_anchor必须是布尔值")
    return (enabled, active_tags, panel_prefixes, anchor_pattern,
            check_anchors, config.get("forbid_outer_punctuation", False))


def _punctuation_or_space(text):
    return all(character.isspace() or unicodedata.category(character).startswith("P")
               for character in text)


def _issue(para_index, rule_id, severity, snippet, reason):
    return {"para_index": para_index, "rule_id": rule_id, "severity": severity,
            "snippet": snippet, "reason": reason, "suggestion": None}


def scan_system_brackets(paragraphs, config=None, *, genre_profile=None) -> list[dict]:
    """Return review records only for explicitly enabled, registered system items.

    Paragraph indices are one-based and snippets preserve the input exactly.
    A standalone item may have only punctuation/whitespace outside its brackets;
    multiple bracket items and inline narrative are ignored. Anchor ``fullmatch``
    uses the immediately preceding nonempty paragraph with only CR/LF removed,
    preserving indentation and other whitespace for the configured regex.
    """
    (enabled, active_tags, panel_prefixes, anchor_pattern,
     check_anchors, forbid_outer_punctuation) = _configuration(config, genre_profile)
    if not enabled:
        return []
    if isinstance(paragraphs, (str, bytes)):
        raise TypeError("paragraphs必须是段落序列，不能是单个字符串")
    try:
        paragraphs = list(paragraphs)
    except TypeError as error:
        raise TypeError("paragraphs必须是段落序列") from error
    if any(not isinstance(paragraph, str) for paragraph in paragraphs):
        raise TypeError("paragraphs必须只包含字符串")

    issues = []
    previous_nonempty = None
    for para_index, paragraph in enumerate(paragraphs, 1):
        match = _STANDALONE_BRACKET.fullmatch(paragraph.strip())
        if match and _punctuation_or_space(match["before"] + match["after"]):
            body = match["body"]
            is_active = body in active_tags
            # A declared panel prefix owns its complete text. Its sentence-final
            # punctuation is not treated as an active-label literal mismatch.
            is_panel = any(body.startswith(prefix) for prefix in panel_prefixes)
            literal_mismatch = False
            if not is_active and not is_panel:
                bare_name = body.rstrip(_FINAL_MARKS)
                if bare_name != body and bare_name in active_tags:
                    is_active, literal_mismatch = True, True
            if is_active or is_panel:
                if literal_mismatch:
                    issues.append(_issue(para_index, "SYS_BRACKET_ACTIVE_LITERAL", "ERROR", paragraph,
                        "主动标签包含句末标点，不符合已声明名称的字面形式。"))
                if forbid_outer_punctuation and any(
                    unicodedata.category(character).startswith("P")
                    for character in match["before"] + match["after"]
                ):
                    issues.append(_issue(para_index, "SYS_BRACKET_OUTER_PUNCTUATION", "ERROR", paragraph,
                        "已声明系统项的【】外存在标点，不符合已配置形式。"))
                if is_active and check_anchors:
                    if anchor_pattern is None:
                        issues.append(_issue(para_index, "SYS_BRACKET_ANCHOR_REVIEW", "REVIEW", paragraph,
                            "未配置锚点形式，请人工确认此前是否具备所需锚点。"))
                    elif previous_nonempty is None or anchor_pattern.fullmatch(previous_nonempty) is None:
                        issues.append(_issue(para_index, "SYS_BRACKET_ANCHOR_FORM", "ERROR", paragraph,
                            "紧邻前一非空段不符合已配置形式；仅核对锚点正则形式。"))
        if paragraph.strip():
            previous_nonempty = paragraph.rstrip("\r\n")
    return issues

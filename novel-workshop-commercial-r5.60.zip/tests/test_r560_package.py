#!/usr/bin/env python3
"""r5.60: the version is the same everywhere, and the release notes say what this release did.

r5.59 pinned its version in test_r559_package.py; from r5.60 on that file checks that the r5.59 entries stay in the
changelog and the verification notes as history, and the current version is pinned here, the same way.

The release notes are checked for what they must cover: where the release comes from (the author passed on a few
outside assessments and an outside package of writing-craft material; the coordinator checked them against the pages
and scripts and gave advice; the author decided; told in the coordinator's words, without saying where the assessments
came from); what each part changed (the technique card and how drafting uses it, the style cards, the four records,
the chapter confirmation and the learning loop, the tests); what the author approved (the locked sentence, the items
shown to him before they were written, the trial finding he accepted, the sentence added to the chain column of the
technique card), what the workshop did first on its own advice
with the author not objecting, and what the coordinator decided on the way, with the note that the author can change
it; where the work differs from the plan; the incompatible changes and how to roll back; what did not change (the five
bound scripts, the delivery gate card, the revision card, the constitution, the installer; the registry gained one
sentence in its note; the style cards are no longer byte for byte the same); the known issues (the trial findings this
release does not change, the places in the locked section on confirmation that still read two ways, the flashback
chapters the fact check cannot compare); how to upgrade; what was not done and what was not verified. The test counts
the notes give are checked against the test files, and the switches in the two new tests against what the notes say.

The locked sentence (lock 1): r5.60 added one sentence to step 2 of the locked section of the author-preferences page.
The author approved adding it, was shown the finished sentence once more, and approved that on 2026-11-26; only then
did it go in. One check here holds the page, the registry note and the two notes to that state. The record of the
approval is kept in the maintenance notes, outside the package.

Not done in this release, and said so plainly in the notes, with no figures: answering and grading the paired
scenario tests (42 were written), running the chapter gate's 29 situations, the writing anchors as a whole, and any
use on a real book or a real chapter. Three checks are filled in after this file was written: the private-material
check of the package, the upgrade and rollback rehearsal, and the reading of the words outside the locked sections.
Each has its own heading in the verification notes; while a heading still says "待补" (to be filled in), the
changelog says the same of it, and QUICKSTART's sentence on delivery records does not name r5.59 (it gains r5.59 only
when the rehearsal has been done and its result holds). The newest entries promise nothing for a later release.

The author's replies are kept in the maintenance notes, outside the package, and no page may quote them; that is
checked in the maintenance environment, not here, and this file holds neither the words nor a fingerprint of them.
These tests only check that the notes say what they must; they do not show that the technique cards or the style cards
work better, or that anything writes better.
"""
import json
import os
from pathlib import Path
import re
import sys
import unittest

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
VERSION = "2026-11-26-r5.60"
TITLE = "小说写作工坊 r5.60"
PREVIOUS = "2026-11-19-r5.59"
PAGES = ("README.md", "QUICKSTART.md", "USAGE.md", "EXAMPLES.md", "skills/novel-workshop/SKILL.md")
WHAT = ("技法卡分三个时候读（挑卡、起草、写完自查），可以先存成候选卡，改卡分轻重，一场最多用两张，交稿时在正文外说明用了哪张；"
        "风格卡加载默认只印方向，写过头的样子留到写完核对，卡片库照作者认过的清单改了 17 张卡；"
        "示范记忆、判断卡、作者改法累计、事实账四份记录的说明页和模板修正；"
        "作者交回改稿那一条补了一种少见情形（修订稿等确认时，把晚到的教师意见和改过的修订稿一起带回）怎样办、学习记录怎样记")
README_LINE = "版本：小说写作工坊 r5.60（`2026-11-26-r5.60`）。在 r5.59 上做几件事：" + WHAT + "。"
SKILL_LINE = ("小说写作工坊 r5.60（`2026-11-26-r5.60`）。在 r5.59 上做几件事：" + WHAT + "。"
              "交付门五个脚本、门卡、改稿卡、宪法正文和章节门、学习循环、示范记忆的脚本没有改；"
              "上锁的六节里，作者改法累计“从一次纠错提炼规则”第 2 步照作者认过的整句加了一句，别的五节没有动；"
              "`style_cards.py` 的 `load` 默认不再印示例和过量信号。")
BOUND_SCRIPTS = ("`workflow_guard.py`", "`punctuation_lint.py`", "`prose_lint.py`", "`fact_guard.py`", "`project_state.py`")
README_BUDGET = 24000  # bytes; test_r554_dialogue.py, test_r520_review_repairs.py and test_r559_package.py hold it too
LOCK1_DATE = "2026-11-26"
LOCK1_NOTE = ("r5.60 added one sentence to step 2 of the author-preferences.md section (the registered steps 1 and 3 and "
              "their sha256 are unchanged); the author approved it on %s." % LOCK1_DATE)
LOCK1_SENTENCE = ("开了[从改稿记录里学编辑判断](editorial-judgment.md)的书，作者没说“以后都这样”的单处改法，"
                  "先记成本书的改稿案例，不另提跨书的待确认条目。")
PENDING = "待补"
# the three checks filled in later: heading in the verification notes, start of the line in the changelog
LATER = (("公开包查漏", "- 公开包查漏"), ("升级和退回", "- 升级和退回演练"), ("节外的话对读", "- 节外的话对读"))


def read(path):
    return (ROOT / path).read_text(encoding="utf-8")


def newest_entry(text):
    """The text of the first '## ' section of a changelog-like page, heading included."""
    parts = re.split(r"(?m)^(?=## )", text)
    return parts[1] if len(parts) > 1 else ""


def part(text, heading):
    """From a '### ' heading to the next '### ' heading ("" if the heading is missing)."""
    start = text.find("\n### " + heading)
    if start < 0:
        return ""
    end = text.find("\n### ", start + 1)
    return text[start:] if end < 0 else text[start:end]


def version_line(page):
    """The line of a page that states its version."""
    return next((line for line in read(page).splitlines() if "`" + VERSION + "`" in line), "")


class Version(unittest.TestCase):
    def test_the_version_is_the_same_everywhere(self):
        for page in PAGES:
            self.assertIn("`" + VERSION + "`", read(page).split("\n## ", 1)[0], page)
        manifest = json.loads(read("PACKAGE-MANIFEST.json"))
        self.assertEqual((manifest["version"], manifest["date"]), (VERSION, "2026-11-26"))
        verification = newest_entry(read("VERIFICATION.md"))
        self.assertTrue(verification.startswith("## " + VERSION + " 的验证"), verification[:60])
        self.assertIn("\n小说写作工坊 · `" + VERSION + "`\n", verification)
        self.assertTrue(newest_entry(read("CHANGELOG.md")).startswith("## %s（%s）" % (VERSION, TITLE)))
        # SKILL.md's version line is rewritten whole; what follows it ("下面几个模块默认都关着……") stays
        self.assertIn("\n" + SKILL_LINE + "下面几个模块默认都关着，谁来开、记在哪，见“可选模块：默认关着”。\n",
                      read("skills/novel-workshop/SKILL.md"))

    def test_the_title_names_this_release_and_no_page_calls_it_a_candidate(self):
        for page in ("README.md", "skills/novel-workshop/SKILL.md"):
            self.assertIn(TITLE, version_line(page), page)
        for page in PAGES:
            line = version_line(page)
            self.assertNotIn("候选", line.split("`" + VERSION + "`")[0], page)  # what the page says this release is
            self.assertNotIn("`" + PREVIOUS + "`", line.split("。")[0], page)
        for page in ("CHANGELOG.md", "VERIFICATION.md"):
            heading = newest_entry(read(page)).splitlines()[0]
            self.assertNotIn("候选", heading, page)

    def test_the_readme_says_what_this_release_did(self):
        readme = read("README.md")
        self.assertLess(len(readme.encode("utf-8")), README_BUDGET)
        self.assertIn("\n" + README_LINE + "\n", readme)
        current = next(p for p in re.split(r"(?m)^(?=## )", readme) if p.startswith("## 本版"))
        self.assertTrue(current.startswith("## 本版（r5.60）"), current[:40])
        for phrase in ("**技法卡**", "分三个时候读", "候选卡", "只收窄的改卡保留原来的采纳", "一场最多两张",
                       "门卡、改稿卡上没写", "**风格卡**", "`--examples`", "`review`", "**四份记录**",
                       "倒叙章", "**章节确认**", "先重开审稿阶段", "随改稿说的“通过”不记成原来那一版的确认",
                       "交付门脚本、门卡、改稿卡、宪法正文没改", "上锁六节只加了作者认过的一句",
                       "[CHANGELOG.md](CHANGELOG.md)", "成对场景题没答题评分", "章节门情形没实测", "公版小说",
                       "新编小样书", "**不说明写得更好**"):
            self.assertIn(phrase, current, phrase)
        for phrase in ("逐条", PENDING, "下一版"):  # the author answered by group; nothing is promised here
            self.assertNotIn(phrase, current, phrase)
        history = readme.split("## 历次版本", 1)[1].split("\n## ", 1)[0]
        self.assertLess(history.index("- **r5.59**："), history.index("- **r5.58**："))
        # the r5.59 exception is told with its condition (review of r5.59)
        line = next(l for l in history.splitlines() if l.startswith("- **r5.59**："))
        self.assertIn("初稿确认以后（交教师的章还要教师结果带回以后）作者交回改稿并说通过的，不重开初稿", line)

    def test_quickstart_names_r559_only_after_the_rehearsal(self):
        # The sentence on delivery records gains r5.59 once the upgrade and rollback rehearsal has been done and its
        # result holds. While the verification notes still say the rehearsal is to be filled in, the
        # sentence does not name r5.59 and the changelog says it was left out; afterwards the two agree either way.
        line = next((l for l in read("QUICKSTART.md").splitlines() if "升级的，交付记录照旧。" in l), "")
        self.assertIn("从合并候选、r5.55、r5.56、r5.57", line)
        rehearsal = part(newest_entry(read("VERIFICATION.md")), "升级和退回")
        self.assertTrue(rehearsal)
        tests = part(newest_entry(read("CHANGELOG.md")), "五、")
        self.assertIn("`QUICKSTART.md` 讲交付记录的那一句", tests)
        if PENDING in rehearsal:
            self.assertNotIn("r5.59", line)
            self.assertIn("没有补 r5.59", tests)
        else:
            self.assertEqual("r5.59" in line, "没有补 r5.59" not in tests)


class ReleaseNotes(unittest.TestCase):
    def setUp(self):
        self.entry = newest_entry(read("CHANGELOG.md"))
        self.assertTrue(self.entry.startswith("## %s（%s）" % (VERSION, TITLE)), self.entry[:60])

    def test_the_opening_says_where_it_comes_from_and_what_it_does_not_claim(self):
        opening = self.entry.split("\n### ", 1)[0]
        for phrase in ("在 r5.59（`2026-11-19-r5.59`）上做", "几份外部评估", "一份外部的写作技法资料包",
                       "编排方逐条对着包里的页和脚本核过", "作者定了", "只收窄的改卡保留作者原来的采纳",
                       "卡片库只改作者在清单上认了的几条", "不碰脚本", "原文一句不搬", "作者回话照各条的建议办",
                       "上锁的六节里只动了一处", "作者 %s 点了头" % LOCK1_DATE,
                       "公开包里不写作者的原话", "也不写那几份评估出自哪里", "同一个模型（Claude）的新实例",
                       "**不是独立评审**", "一部公版的现代白话短篇", "新编的小样书", "题面写了 42 道",
                       "这一版没有答题和评分", "章节门 29 种情形没有实测", "写作对照例没有整版跑",
                       "**不说明写得更好**", "r5.59 的包原样留着"):
            self.assertIn(phrase, opening, phrase)

    def test_the_parts_say_what_changed(self):
        expected = {
            "一、": ("`assets/technique-card-template.md`", "`references/deconstruction-library.md`",
                    "`references/reference-study.md`", "`references/drafting.md`", "`assets/scene-beat-card.md`",
                    "`references/scene-dramaturgy.md`", "`references/editing.md`", "`SKILL.md`",
                    "`references/quality-loop.md`", "`references/chapter-confirmation.md`",
                    "`assets/third-party/SOURCE-NOTES.md`", "原来的栏一栏没删", "先存成候选卡至少填七栏",
                    "作者原来的采纳保留", "作者只是不要照这张卡写出来的那几句", "本书规则，写进哪一份由作者定",
                    "列给作者看不算作者采纳", "原包没有附许可文件", "L1、L2 两行没有改",
                    "交付门卡和改稿卡这一版没动", "没有写技法卡的两样例外", "没有验证过", "没有在真实章节上用过",
                    "“作用链”一栏加一句", "末一环写成一件看得见的事",
                    "在“失效情境”里注明“这一手不推剧情”，挑卡时读得到"),
            "二、": ("`assets/style-cards/cards.json`", "17 张卡 24 栏 30 处", "卡数 83 不变", "不写“逐条”",
                    "`references/style-cards.md`", "`scripts/style_cards.py`", "`--examples`", "`review`",
                    "93 条", "16 张卡 21 个", "`fixed_base_card`", "`--no-fixed-base`", "“全在不言中”那一句的读法留着",
                    "`SKILL.md`、`USAGE.md`", "工坊起草、作者认过的", "作者都没有逐条看过",
                    "`load`、`review`、`copied` 三个命令的文字输出都印", "计划只写了 `load` 印"),
            "三、": ("`references/demonstration-learning.md`", "`references/editorial-judgment.md`",
                    "`assets/editorial-judgment-template.json`", "`references/author-preferences.md`",
                    "`references/continuity.md`", "`assets/fact-ledger-template.json`",
                    "`assets/fact-claims-template.json`", "`references/execution.md`", "`references/revision-passes.md`",
                    "`assets/demonstration-case-template.json`", "`chapter_revision`", "上锁的“边界”一节没有动",
                    "`fact_guard.py` 没有改", "判断卡文件、自审单没有脚本核", "没有在真实的书上用过",
                    "**上锁的那一句（锁1）。**"),
            "四、": ("`references/chapter-confirmation.md`", "`references/learning-loop.md`", "方案交出以后又来了一批",
                    "作者的稿子不登记成教师回传", "工坊交出的那一版修订稿", "不拿它给原来那一次展示记 `confirm`",
                    "脚本分不出", "上锁的“确认是什么意思”一节一字没动", "上锁的“取舍由谁定”一节一字没动",
                    "作者认了做法甲", "不是作者定的，是编排方跟着上一版的逐字读补的", "作者看过原句和拟改句以后认了",
                    "章节门、学习循环的脚本没有改", "只在合成材料上走过，没有在真实章节上走过"),
            "五、": ("`tests/test_r560_package.py`", "`tests/test_r559_package.py`", "`STAGE3_APPROVED`",
                    "`TEXT_ONLY_SENTENCE_APPROVED` 是 `False`", "`tests/test_r560_confirm.py` 五个开关都是 `True`",
                    "上锁的那一句落进包以后跟着换的三处", "`tests/test_r560_records.py`", "`tests/test_r554_dialogue.py`",
                    "`PACKAGE-MANIFEST.json`", "`portable-novel-workshop.md`", "`QUICKSTART.md` 讲交付记录的那一句"),
        }
        for heading, phrases in expected.items():
            text = part(self.entry, heading)
            self.assertTrue(text, heading)
            for phrase in phrases:
                self.assertIn(phrase, text, (heading, phrase))

    def test_the_locked_sentence_is_on_the_page_in_the_registry_and_in_the_notes(self):
        # the page: the sentence stands in step 2, right after "回本书记录。", once
        page = read("skills/novel-workshop/references/author-preferences.md")
        step = [line for line in page.splitlines() if line.startswith("2. **归因与定范围。**")]
        self.assertEqual(len(step), 1)
        self.assertIn("回本书记录。" + LOCK1_SENTENCE + "无法分辨是个人偏好还是普通错误时标明", step[0])
        self.assertEqual(page.count(LOCK1_SENTENCE), 1)
        # the registry: the note ends with one sentence on it and the day the author approved it; nothing else changed
        # in the entry for this section (the registered steps 1 and 3 are pinned in test_r560_records.py)
        registry = json.loads(read("skills/novel-workshop/assets/constitution-rules.json"))
        self.assertTrue(registry["note"].endswith(" " + LOCK1_NOTE), registry["note"][-260:])
        self.assertEqual(registry["note"].count("r5.60"), 1)
        entry = next(e for e in registry["protected_sections"] if e["file"].endswith("author-preferences.md"))
        self.assertEqual((entry["part"], entry["r5.59_lines"]), ("第 1、3 步", "57, 59"))
        # the notes: what was added, that the author approved the finished sentence on that day, where the record is,
        # and what the freeze of r5.59 against this release reports
        told = part(self.entry, "三、")
        for phrase in ("“回本书记录。”后面加了一句，别的字没有动", "作者没说“以后都这样”的单处改法，先记成本书的改稿案例，"
                       "不另提跨书的待确认条目", "改好的整句又交作者看了一遍", "作者 %s 点了头" % LOCK1_DATE,
                       "批准记录备在维护记录里，不在包里", "`note` 末尾记了一句", "不写原话",
                       "登记的第 1、3 步两行、行号和它们的哈希没有变", "这一节报变了，带着批准记录才过",
                       "另外五节报没变", "没有在真实记录上用过"):
            self.assertIn(phrase, told, phrase)
        checked = part(newest_entry(read("VERIFICATION.md")), "上锁的六节")
        for phrase in ("`darwin_eval.py freeze`", "五节报没变", "“从一次纠错提炼规则”一节报变了",
                       "`BLOCKED_CONSTITUTION_CHANGE`", "`--constitution-approval`", "批准记录备在维护记录里，不在包里",
                       "作者 %s 点了头" % LOCK1_DATE, "登记表只差 `note`", "逐字节相同"):
            self.assertIn(phrase, checked, phrase)
        for text in (self.entry, newest_entry(read("VERIFICATION.md"))):
            self.assertNotIn("还等作者点头", text)

    def test_what_the_author_approved_and_what_was_done_first(self):
        approved = part(self.entry, "作者认了的")
        for key in ("锁1", "锁2—锁8", "锁9", "看1", "看2", "看3", "看4", "看5", "看6", "看7", "看8", "看9", "看10",
                    "告1", "告2", "试17", "试3"):
            self.assertRegex(approved, r"(?m)^- [^\n]*" + re.escape(key) + r"[（：、]", key)
        for phrase in ("29 处", "18 条", "作者回话照各条的建议办", "公开包里不写作者的原话", "一字没改", "读法一", "做法甲",
                       "“作者认过”不写“逐条”", "落进包里了",
                       "技法卡模板“作用链”一栏加一句", "照作者看过的落进模板，一字没改",
                       "后半句和作者看过的拟句有两处不一样"):
            self.assertIn(phrase, approved, phrase)
        first = part(self.entry, "工坊先照建议办、作者没反对的")
        for phrase in ("告3", "告4—告10", "作者没反对", "7 处后续细节", "作者没说过不同意"):
            self.assertIn(phrase, first, phrase)
        decided = part(self.entry, "编排方定下的几处做法")
        self.assertIn("要改，说一声就改", decided)
        numbers = [int(n) for n in re.findall(r"(?m)^(\d+)\. ", decided)]
        self.assertEqual(numbers, list(range(1, len(numbers) + 1)))
        self.assertGreaterEqual(len(numbers), 5)
        for phrase in ("`review`、`copied`", "改稿卡这一版不动", "没有改成定期", "不进包"):
            self.assertIn(phrase, decided, phrase)
        differs = part(self.entry, "实施时和计划不一致的地方")
        for phrase in ("`2026-11-20-r5.60`", "`2026-11-26-r5.60`", "分句前面另补了一个“；”", "计划只写了 `load`",
                       "成对场景题答题和评分、章节门 29 种情形实测、写作对照例整版，这一版没有做"):
            self.assertIn(phrase, differs, phrase)

    def test_the_incompatible_changes_and_how_to_upgrade_and_roll_back(self):
        incompatible = part(self.entry, "不兼容的变化")
        for phrase in ("`style_cards.py load`", "`--examples`", "`review`", "`render(data, cards)`", "`exempt`", "`hints`",
                       "`domain`", "`fixed_base_card`", "填 `null` 也算", "退出码 2", "r5.59 没有 `review` 这个命令",
                       "全卡组的相反写法", "开始时版本 NWC-1.8，现在 NWC-1.8", "技法卡模板重排了", "BLOCKED",
                       "`chapter_revision`", "`cases`、`cards`"):
            self.assertIn(phrase, incompatible, phrase)
        upgrade = part(self.entry, "怎样升级")
        for phrase in ("从 r5.59 升上来", "python install.py --upgrade --dry-run", "`assets/project-packs/`", "交付记录照旧",
                       "`governance_warnings`", "只是提示", "从 r5.58 或更早升上来", "退回 r5.59", "先删掉这一栏",
                       "r5.59 没有 `review`", "没有验证", "升级和退回演练"):
            self.assertIn(phrase, upgrade, phrase)

    def test_what_did_not_change_and_the_known_issues(self):
        unchanged = part(self.entry, "没有改的")
        for phrase in BOUND_SCRIPTS + ("逐字节相同", "`assets/delivery-gate-card.md`", "`assets/revision-card.md`",
                                       "`CONSTITUTION.md`", "`install.py`", "`chapter_gate.py`", "`learning_loop.py`",
                                       "这一版改的脚本只有 `style_cards.py`", "和 r5.59 不再逐字节相同", "上锁的六节",
                                       "只在 `note` 末尾多了一句", "另外五节一字没动"):
            self.assertIn(phrase, unchanged, phrase)
        # r5.59 could still say the 83 style cards and the registry were byte for byte the same; this release changed
        # the card library and added one sentence to the registry note
        self.assertNotIn("83 张风格卡和 r5.59 逐字节相同", unchanged)
        same_bytes = next(l for l in unchanged.splitlines() if "`assets/delivery-gate-card.md`" in l)
        self.assertNotIn("constitution-rules.json", same_bytes)
        earlier = part(self.entry, "上一版留下的已知问题")
        for phrase in ("已知的一处", "锁2", "锁3", "锁4", "锁5", "锁6", "锁7", "锁8", "看5", "看6", "看7", "看8", "看9",
                       "`workflow_guard.py` 还没有收回采纳的命令", "跨章回归"):
            self.assertIn(phrase, earlier, phrase)
        known = part(self.entry, "这一版的已知问题")
        # the trial findings this release leaves as they are, one line each
        self.assertEqual(re.findall(r"(?m)^- 试(\d+) ", known), ["1", "2"] + [str(n) for n in range(4, 16)] + ["18"])
        self.assertNotIn("- 试16 ", known)  # an observed fact: it goes under what was not verified
        self.assertNotIn("- 试17 ", known)  # the author approved the sentence; it is in the template
        # the places in the locked section on confirmation that the author left as they are in this release
        self.assertEqual(re.findall(r"(?m)^- 锁(\d) ", known), [str(n) for n in range(2, 9)])
        self.assertIn("作者定了这一版不动（锁2—锁8）", known)
        # the flashback chapters: the fact check does not compare the flashback part, and that is not a pass
        for phrase in ("倒叙章的事实核对", "事实核对脚本这一版没有改", "`UNTESTED`（没比），不写成通过",
                       "要人回前文对着读", "以后改事实核对脚本时"):
            self.assertIn(phrase, known, phrase)

    def test_the_test_counts_and_the_switches_in_the_notes_are_the_test_files(self):
        tests = part(self.entry, "五、")
        named = re.findall(r"`tests/(test_r560_[a-z_]+\.py)`（(\d+) 项", tests)
        self.assertEqual(sorted(name for name, _ in named),
                         sorted(path.name for path in (ROOT / "tests").glob("test_r560_*.py")))
        for name, count in named:
            source = (ROOT / "tests" / name).read_text(encoding="utf-8")
            self.assertEqual(len(re.findall(r"(?m)^    def test_", source)), int(count), name)
        pipeline = read("tests/test_r560_technique_pipeline.py")
        for line in ("STAGE3_APPROVED = True", "TIDYING_APPROVED = True", 'TIDYING_READING = "rules"',
                     "TEXT_ONLY_SENTENCE_APPROVED = False"):
            self.assertRegex(pipeline, r"(?m)^" + re.escape(line) + r"(?:[ \t]|$)", line)
        confirm = read("tests/test_r560_confirm.py")
        for name in ("PASS_NOTE", "GATE_NOTE", "OPENING", "TEACHER_PARAGRAPH", "STAGE_SIX"):
            self.assertRegex(confirm, r"(?m)^%s_APPROVED = True\b" % name, name)


class Verification(unittest.TestCase):
    def setUp(self):
        self.entry = newest_entry(read("VERIFICATION.md"))
        self.assertTrue(self.entry.startswith("## " + VERSION + " 的验证"), self.entry[:60])
        self.changelog = newest_entry(read("CHANGELOG.md"))

    def test_the_verification_notes_name_what_was_run(self):
        for phrase in ("python3 -I -B tests/run_tests.py", "Python 3.13", "Python 3.9", "`__pycache__`", "同一个模型",
                       "**不是独立评审**", "2103 项", "不过 21 项", "`tests/test_r560_package.py`",
                       "`tests/test_r559_package.py`", "605", "试拆试写", "`scene_beats`", "`1867b0cf…`",
                       "`fixed_base_card`", "`fact_guard.py check`", "逐字节相同", "`governance_warnings`",
                       "开始时版本 NWC-1.8，现在 NWC-1.8", "**不说明写得更好**"):
            self.assertIn(phrase, self.entry, phrase)
        rows = 0
        for line in part(self.entry, "全套测试").splitlines():
            match = re.search(r"运行 (\d+) 项，跳过 (\d+) 项，其余 (\d+) 项全部通过", line)
            if match:
                rows += 1
                ran, skipped, passed = (int(n) for n in match.groups())
                self.assertEqual(ran - skipped, passed, line[:60])
        self.assertGreaterEqual(rows, 2)  # Python 3.13 and Python 3.9, after the close
        # the ZIP holds what the manifest lists and the manifest itself
        listed = len(json.loads(read("PACKAGE-MANIFEST.json"))["files"])
        packaging = part(self.entry, "清单和单文件版")
        self.assertEqual([int(n) for n in re.findall(r"ZIP 里 (\d+) 个文件", packaging)], [listed + 1])
        self.assertIn("清单列的 %d 个加清单自己" % listed, packaging)
        self.assertIn("`--version 2026-11-26-r5.60 --date 2026-11-26`", packaging)
        trial = part(self.entry, "试拆试写")
        for phrase in ("一部公版的现代白话短篇", "不用译本", "新编", "18 条", "14 条", "试16", "试17", "试18", "试3",
                       "AI 扮工坊、AI 扮作者", "说明不了照卡写得更好",
                       "那以后模板加了试17 那一句和“作用链”一栏的那一句", "没有拿加了这两句的模板再走一遍"):
            self.assertIn(phrase, trial, phrase)
        # the machine checks were run before the items the author approved went in; the notes say so, and that the
        # scripts and templates they ran on are the ones in the package
        machine = part(self.entry, "机器核对")
        for phrase in ("在作者认了的条目写进去以前的候选的副本上跑的", "和现在包里的相同", "收尾时没有把这四样重跑",
                       "交付门不核这一栏", "三个命令的文字输出各印一行", "不是这一版 29 种情形的实测"):
            self.assertIn(phrase, machine, phrase)

    def test_what_was_not_done_is_said_plainly(self):
        opening = self.entry.split("\n### ", 1)[0]
        for phrase in ("这一版没有做", "题面写了 42 道", "章节门 29 种情形实测", "写作对照例整版"):
            self.assertIn(phrase, opening, phrase)
        for text in (part(self.entry, "没有做的"), part(self.changelog, "没有验证的")):
            for phrase in ("成对场景题", "题面写了 42 道", "这一版没有答题和评分", "章节门 29 种情形", "没有实测",
                           "写作对照例没有整版跑", "真实的书", "真实的章节"):
                self.assertIn(phrase, text, phrase)
            self.assertNotRegex(text, r"对 \d+、部分对")  # no figures: the scenarios were not answered
        for text in (part(self.entry, "没有验证的"), part(self.changelog, "没有验证的")):
            for phrase in ("试16", "越具体越容易被勾着写出来", "不说明写得更好", "Windows"):
                self.assertIn(phrase, text, phrase)

    def test_the_three_checks_filled_in_later_are_marked_the_same_in_both_notes(self):
        unverified = part(self.changelog, "没有验证的")
        waiting = []
        for heading, start in LATER:
            section = part(self.entry, heading)
            self.assertTrue(section.strip(), heading)
            line = next((l for l in unverified.splitlines() if l.startswith(start)), "")
            if PENDING in section:
                waiting.append(heading)
                self.assertIn(PENDING, line, heading)  # still to be filled in: the changelog says so too
            else:
                self.assertNotIn(PENDING, line, heading)  # filled in: the changelog no longer calls it pending
        # the opening of the verification notes says "待补" exactly while one of the three still waits
        opening = self.entry.split("\n### ", 1)[0]
        self.assertEqual(PENDING in opening, bool(waiting), waiting)
        if PENDING in part(self.entry, "公开包查漏"):
            self.assertIn("“公开包里没有作者原话、作者书里的词”算没验证", unverified)

    def test_the_newest_entries_promise_nothing_for_a_later_release(self):
        for text in (self.entry, self.changelog):
            for phrase in ("下一版", "下个版本", "冻结以后补", "结果待补"):
                self.assertNotIn(phrase, text, phrase)
            self.assertNotRegex(text, r"r5\.(?:6[1-9]|[7-9]\d)")  # no release after this one is named


if __name__ == "__main__":
    unittest.main()

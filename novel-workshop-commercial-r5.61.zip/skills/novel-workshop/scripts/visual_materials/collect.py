"""Step 2a: read the source pages that matter (with Crawl4AI, or the workshop's builtin reader), then fetch and decode
the images.

Crawl4AI renders each page in a headless browser and lists its images (src, alt, desc, score, width). Only the pages
of this run's candidates (and pages the request names) are read, at most budgets.max_pages, robots.txt respected by
default. Images are fetched up to budgets.max_images, at most network.max_image_bytes each, and kept only if Pillow
can decode them: an HTML page, a broken file or something that is not an image is recorded as such, never as an
image. When the original cannot be fetched, the thumbnail is tried and the record says it is only the thumbnail
(r5.59: not when robots.txt, the site or network.blocked_hosts kept the original back, nor once budgets.max_requests
is reached; see below).

r5.37 (the r5.35 review, point 3): Crawl4AI being importable, its browser starting and a page being read are three
different things, and the record says which happened. When the browser does not start (or the page reader stops), the
pages are recorded as browser_failed or error and the images the searches found are still fetched (partial); nothing
claims a page was read. A host in network.blocked_hosts is neither opened as a page nor fetched as an image. Fetching
again replaces each candidate's image: an image not fetched this time is kept only as stale_image (with why), so later
steps never take an old file for this fetch, and the files the later steps made from the old fetch move to outdated/.

r5.38 (the r5.37 review, point 3): the page's own words are this read's too. A candidate's on_page comes only from a
page read now (collect.json has when); when its page was not read this time, what an earlier read said is kept as stale_on_page
(with since when and why), shown in the review as earlier page text and never taken into the library as page text.
When a page read now also shows a candidate's image and is not yet among its sightings, the page is added to found_by
(as a crawl4ai sighting of its own, without taking the candidate's licence or author).

r5.59 (the author's decisions of 2026-11-19): every page and every image goes through the run's common.Session: the
address is checked (and every redirect hop), robots.txt is asked once per host and cannot be turned off, one host is
asked at most once every network.min_interval_seconds (or what robots.txt asks), a host that refuses (401, 403, 451,
a check page) or limits the rate (429) is asked nothing more in this run, and budgets.max_requests caps the requests.
A page handed to Crawl4AI is checked the same way first; Crawl4AI's own check_robots_txt stays on as a second check,
its browser is given the workshop's user agent, and the two sets of options it gets are fixed lists. The redirects
Crawl4AI's browser follows itself and what the browser loads for a page (its images, scripts, frames) are not seen
here and not checked; when the result says where the page ended (redirected_url, a field name not checked against an
installed Crawl4AI), that address is checked afterwards like a hop (blocked_hosts, this machine and private networks,
a stopped host, robots.txt), and a page that ended where the workshop would not go is recorded so and nothing from it
is used. A refusal is recorded on the host that gave it. A page the reader answers with any status but 200 is not
counted as read and its images are not added. An original not fetched because robots.txt does not allow it
(robots_disallowed), because its robots.txt could not be read this time (robots_unreachable), because its site refused
(refused) or because its host is in network.blocked_hosts (blocked), after a redirect too, is not replaced by a
thumbnail from any site, its own or another: the site or the author said no to this image, or it is not known that the
site says yes. A site that cannot be reached at all (no address found, the connection refused, its robots.txt timing
out or answering a 5xx) counts as robots_unreachable: its robots.txt, asked first, could not be read. Nor is a
thumbnail tried once budgets.max_requests is reached (skipped_max_requests): nothing more is asked in this run. Other
failures (a 429, a wait too long, a timeout of the original itself, a file too large, an HTTP error, not an image, an
address on this machine or a private network, more than five redirects, an address that cannot be read in one
spelling or a redirect to one that is not http(s)) still fall back to a thumbnail; after a 429 or a wait too long,
one on the same site is not asked either (that host is asked nothing more in this run), one on another site is.
Pages on blocked hosts are left out before budgets.max_pages is counted. When Crawl4AI hands back only a lazy-loading
placeholder (data:), data-src, data-original and srcset are tried in turn, and the images still without an address are
counted in the page record (dropped_images). What a page itself says about who made an image and under what licence (a
credit line, a licence link) goes only into on_page.page_says with checked: false: review.md shows it on a line of its
own, select and adopt never read it, and the candidate's creator and licence stay as the searches gave them.

r5.59, the builtin reader (the author's decision 7): who reads the pages is page_reader.use. auto (the default) uses
Crawl4AI when it can run here and the workshop's builtin reader (static_reader.py, the standard library only, no
browser, no page scripts) when it cannot: not installed, Python older than 3.10, or its browser did not start (then
the pages it could not read are read by the builtin reader, and the record says so). crawl4ai never falls back;
builtin never uses Crawl4AI. The builtin reader asks every page through the same Session, so all of the above holds
for it too. A page read by the builtin reader is never recorded under Crawl4AI's name: found_by and transport.crawl
say builtin, collect.json says which reader and version (reader, reader_version, page_reader), crawl4ai_version is
written only when Crawl4AI read the pages, and verify-run does not count such a run for Crawl4AI. An image a page
lists under several addresses (srcset, data-src, a noscript copy) is the search's candidate when any of them is, so
the larger version on the page does not become a second candidate.

A page reader given as crawl(pages, config) returns ([{page_url, status, http_status, error, images: [{src, alt, desc,
score, width, page_says, variants}], page_says}], version): page_says (optional, per image or for the whole page) is
{credit, caption, license_links, structured}, what the page says; collect adds checked: false. variants (optional)
are the other addresses of the same image.
"""
import asyncio
import io
import re
import sys
import urllib.parse

from . import common, static_reader

IMAGE_TYPES = {"JPEG": "jpg", "PNG": "png", "WEBP": "webp", "GIF": "gif", "BMP": "bmp", "TIFF": "tif"}
# r5.59: where a lazy-loading image keeps its real address when src holds only a placeholder (Crawl4AI's own key
# names for these, if it hands them back at all, were not checked against an installed copy).
LAZY_KEYS = ("data-src", "data_src", "data-original", "data_original")
SRCSET_KEYS = ("srcset", "data-srcset", "data_srcset")
NOT_ADDRESSES = ("data:", "blob:", "javascript:", "about:")
# An original not fetched for these reasons is not replaced by a thumbnail, from the same site or another (r5.59):
# robots.txt or the site said no, robots.txt could not be read to say yes (a site that cannot be reached at all is
# this one: its robots.txt is asked first), or the author blocked the host; and once the request budget is reached,
# nothing more is asked in this run. Every other reason (rate_limited, host_paused, timeout, too_large, http_error,
# private_address, too_many_redirects, error ...) still falls back to the thumbnail: no site said no, and for the
# last three the address itself is the trouble (the thumbnail's address is checked the same way before it is asked).
NO_THUMBNAIL = {
    "robots_disallowed": "robots.txt does not allow the original",
    "robots_unreachable": "the original's robots.txt could not be read this time (so it is not known to allow it)",
    "refused": "the original's site refused",
    "blocked": "the original's host is in network.blocked_hosts",
    "skipped_max_requests": "budgets.max_requests was reached, so nothing more is asked in this run",
}


def crawl4ai_status():
    if sys.version_info < (3, 10):
        return False, "Crawl4AI needs Python 3.10 or newer (this is %d.%d)" % sys.version_info[:2], None
    try:
        import crawl4ai  # noqa: F401
    except Exception as exc:  # noqa: BLE001 - any import failure means it cannot run here
        return False, "Crawl4AI is not installed (pip install crawl4ai, then crawl4ai-setup): %s" % exc, None
    return True, "crawl4ai %s" % getattr(crawl4ai, "__version__", "?"), getattr(crawl4ai, "__version__", "?")


BLOCKED = common.BLOCKED


def choose_reader(config):
    """(reader, why): who reads the source pages, by page_reader.use and what this machine has. reader is crawl4ai or
    builtin; with auto, Crawl4AI's browser not starting still turns a collect over to the builtin reader."""
    use = config["page_reader"].get("use", "auto")
    if use == "builtin":
        return "builtin", "page_reader.use is builtin"
    ok, why, _ = crawl4ai_status()
    if use == "crawl4ai":
        return "crawl4ai", "page_reader.use is crawl4ai" + ("" if ok else (
            "; it cannot run here (%s): no page is read, and the builtin reader is not used" % why))
    if ok:
        return "crawl4ai", ("page_reader.use is auto and Crawl4AI imports here (%s); if its browser does not start, "
                            "the builtin reader reads the pages" % why)
    return "builtin", "page_reader.use is auto and Crawl4AI cannot run here (%s)" % why


def browser_options(config):
    """Everything BrowserConfig gets (a fixed list, r5.59). user_agent is the workshop's own; that BrowserConfig takes
    it under this name is from Crawl4AI's documentation and was not checked on a machine with Crawl4AI installed."""
    return {"headless": bool(config["crawl4ai"].get("headless", True)), "verbose": False,
            "user_agent": config["network"]["user_agent"]}


def run_options(config, cache_mode):
    """Everything CrawlerRunConfig gets (a fixed list, r5.59). check_robots_txt stays on: load_config refuses false, and
    only doctor --probe turns it off, for the page it makes itself."""
    options = config["crawl4ai"]
    return {"cache_mode": cache_mode, "wait_for_images": bool(options.get("wait_for_images", True)),
            "scan_full_page": bool(options.get("scan_full_page", True)),
            "page_timeout": int(options.get("page_timeout_ms", 30000)),
            "check_robots_txt": bool(options.get("check_robots_txt", True)), "exclude_external_images": False,
            "verbose": False}


def _address(value):
    value = (value or "").strip() if isinstance(value, str) else ""
    return "" if not value or value.lower().startswith(NOT_ADDRESSES) else value


def media_images(page, items):
    """The images Crawl4AI listed for page: ([{src, alt, desc, score, width}], how many had no usable address). A src
    that is empty or only a placeholder is replaced by data-src, data-original or the largest srcset candidate."""
    images, dropped = [], 0
    for item in items or []:
        item = item if isinstance(item, dict) else getattr(item, "__dict__", {})
        src, came_from = _address(item.get("src")), "src"
        if not src:
            for key in LAZY_KEYS:
                src = _address(item.get(key))
                if src:
                    came_from = key
                    break
        if not src:
            for key in SRCSET_KEYS:
                src = _address(common.best_in_srcset(item.get(key) if isinstance(item.get(key), str) else ""))
                if src:
                    came_from = key
                    break
        if not src:
            dropped += 1
            continue
        image = {"src": urllib.parse.urljoin(page, src), "alt": item.get("alt") or "", "desc": item.get("desc") or "",
                 "score": item.get("score"), "width": item.get("width")}
        if came_from != "src":
            image["src_from"] = came_from
        images.append(image)
    return images, dropped


def crawl_pages(pages, config, session=None, local_probe=False):
    """Each page with Crawl4AI: [{page_url, status, http_status, error, images: [...]}]. A blocked host is not opened
    (status blocked). When the browser does not start, every page is browser_failed; when the reader stops later, the
    pages not reached are not_read; when the browser fails to close after reading, the pages read are kept and say so.

    r5.59: each page goes through session (a common.Session; a new one when none is given) before the browser starts
    and again right before it is read: its address, robots.txt, a host that refused or asked to wait, the budget, and
    the host's turn. local_probe is only for doctor --probe, whose one page is made here (raw:), not a website."""
    ok, why, version = crawl4ai_status()
    if not ok:
        return [{"page_url": p, "status": "not_installed", "error": why, "images": []} for p in pages], None
    from crawl4ai import AsyncWebCrawler, BrowserConfig, CacheMode, CrawlerRunConfig

    if not local_probe:
        session = session or common.Session(config)
    early = {}
    for page in pages:
        if local_probe:
            continue
        problem = session.check(page, "page")
        if problem:
            early[page] = dict({"page_url": page, "images": []}, **problem)
    allowed = [p for p in pages if p not in early]

    async def main():
        out = []
        browser = BrowserConfig(**browser_options(config))
        run = CrawlerRunConfig(**run_options(config, CacheMode.BYPASS))
        started = False
        try:
            async with AsyncWebCrawler(config=browser) as crawler:
                started = True
                for page in allowed:
                    problem = None if local_probe else session.admit(page, "page")
                    if problem:  # a page before it on the same host was refused, or the budget ran out
                        out.append(dict({"page_url": page, "images": []}, **problem))
                        continue
                    record = {"page_url": page, "time": common.now(), "images": []}
                    try:
                        result = await crawler.arun(url=page, config=run)
                    except Exception as exc:  # noqa: BLE001 - one page failing is that page's record
                        record.update(status="error", error="%s: %s" % (type(exc).__name__, exc))
                        out.append(record)
                        continue
                    code = getattr(result, "status_code", None)
                    record["http_status"] = code
                    html = getattr(result, "html", None)
                    # Where the browser ended after the redirects it followed itself (the field name is from
                    # Crawl4AI's documentation, not checked against an installed copy): checked afterwards like a hop.
                    landed = getattr(result, "redirected_url", None)
                    landed = landed if isinstance(landed, str) and re.match(r"^https?://", landed, re.I) else None
                    if landed and landed != page:
                        record["final_url"] = common.clean_url(landed)
                        problem = None if local_probe else session.landed_problem(landed)
                        if problem:
                            record.update(status=problem["status"], error="the page reader ended at %s, where the "
                                          "workshop does not go (%s): nothing from the page is used"
                                          % (common.clean_url(landed), problem.get("error") or problem["status"]))
                            out.append(record)
                            continue
                    refusal = None if local_probe else session.note_read(page, code, html if isinstance(html, str)
                                                                          else None, final_url=landed)
                    if refusal:
                        record.update(status=refusal, error="the page answered HTTP %s%s: nothing more is asked of "
                                      "this host in this run" % (code, "" if code in common.REFUSING + (429,) else
                                                                 " (a check page)"))
                        out.append(record)
                        continue
                    if not getattr(result, "success", False):
                        record.update(status="failed", error=getattr(result, "error_message", "") or "not successful")
                        out.append(record)
                        continue
                    if code != 200 and not local_probe:
                        record.update(status="failed", error="the page reader answered HTTP %s: not counted as read"
                                      % code)
                        out.append(record)
                        continue
                    media = getattr(result, "media", None) or {}
                    record["images"], dropped = media_images(page, media.get("images", []) or [])
                    if dropped:
                        record["dropped_images"] = dropped
                    record["status"] = "ok" if record["images"] else "no_images"
                    out.append(record)
        except Exception as exc:  # noqa: BLE001 - the browser not starting or closing is recorded, not raised
            note = "%s: %s" % (type(exc).__name__, exc)
            done = {r["page_url"] for r in out}
            if not started:
                status, error = "browser_failed", "the browser did not start: " + note
            else:
                status, error = "not_read", "the page reader stopped: " + note
                for record in out:
                    record["browser"] = "stopped with an error after this page: " + note
            out += [{"page_url": p, "status": status, "error": error, "images": []} for p in allowed if p not in done]
        return out

    records = {r["page_url"]: r for r in (asyncio.run(main()) if allowed else [])}
    records.update(early)
    for page in pages:
        if page not in records:
            records[page] = {"page_url": page, "status": "blocked", "error": BLOCKED, "images": []}
    return [records[p] for p in pages], version


def decode(data):
    """(format, width, height) when Pillow can read the bytes as an image; raises ValueError otherwise."""
    try:
        from PIL import Image
    except ImportError as exc:
        raise RuntimeError("Pillow is not installed (pip install Pillow)") from exc
    try:
        with Image.open(io.BytesIO(data)) as probe:
            probe.verify()
        with Image.open(io.BytesIO(data)) as image:
            image.load()
            return image.format or "", image.size[0], image.size[1]
    except Exception as exc:  # noqa: BLE001 - Pillow raises many kinds for a broken file
        raise ValueError("%s: %s" % (type(exc).__name__, exc)) from exc


def fetch_image(url, config, fetch=None, session=None):
    """{status, sha256, format, width, height, bytes, data} for one address, through session (r5.59: the address and
    its redirects checked, robots.txt asked, the host's turn waited, refusals kept for the rest of the run)."""
    session = session or common.Session(config, fetch=fetch)
    outcome, response = session.request(url, "image", headers={"Accept": "image/*"},
                                        max_bytes=config["network"]["max_image_bytes"])
    seen = {k: outcome[k] for k in ("final_url", "redirects", "not_asked") if outcome.get(k)}
    if response is None:
        out = {"status": outcome["status"], "error": outcome.get("error", "")}
        if outcome.get("http_status") is not None:
            out["http_status"] = outcome["http_status"]
        return dict(out, **seen)
    if response.status != 200:
        return dict({"status": "http_error", "http_status": response.status}, **seen)
    kind = (common.header(response.headers, "Content-Type") or "").lower()
    if kind.startswith(("text/", "application/json")):
        return dict({"status": "not_image", "error": "the address answered %s" % kind.split(";")[0]}, **seen)
    try:
        fmt, width, height = decode(response.body)
    except ValueError as exc:
        return dict({"status": "undecodable", "error": str(exc), "bytes": len(response.body)}, **seen)
    return dict({"status": "ok", "sha256": common.sha256_bytes(response.body), "format": fmt, "width": width,
                 "height": height, "bytes": len(response.body), "data": response.body}, **seen)


def said(page_said, image):
    """What the page says about an image's maker and licence (r5.59): the page's own and the image's, or what reads like
    a credit or a licence in its alt and description; marked checked: false, or None."""
    out = dict(page_said or {})
    for key, value in (image.get("page_says") or common.page_says_of(image.get("desc"), image.get("alt"))).items():
        out[key] = sorted(set(out.get(key) or []) | set(value or [])) if key == "license_links" else value
    out = {k: v for k, v in out.items() if v not in (None, "", [], {})}
    return dict(out, checked=False) if out else None


def run_collect(folder, config, fetch=None, crawl=None, session=None):
    if session is not None and fetch is not None and session.fetch is not fetch:
        raise ValueError("give fetch or a session made with it, not both")
    session = session or common.Session(config, fetch=fetch)
    reader, why = choose_reader(config) if crawl is None else ("injected", "a page reader was handed in (a test)")
    run = common.Run(folder)
    manifest = run.manifest()
    candidates = run.candidates()
    budgets = config["budgets"]
    listed = []
    for page in manifest["request"].get("pages", []) + [c["page_url"] for c in candidates]:
        if page not in listed:
            listed.append(page)
    # r5.59: pages on blocked hosts are left out before the budget is counted, so they take no reader's place.
    readable = [p for p in listed if not common.blocked(p, config)][:budgets["max_pages"]]
    listed = [p for p in listed if p in readable or common.blocked(p, config)]
    importable = crawl4ai_status()[0] if crawl is None else None
    gated, to_read = {}, readable
    if crawl is not None:
        to_read = []
        for page in readable:
            problem = session.admit(page, "page")
            if problem:
                gated[page] = dict({"page_url": page, "images": []}, **problem)
            else:
                to_read.append(page)
    fallback, browser_failed = None, False
    try:
        if crawl is not None:
            crawled, version = crawl(to_read, config) if to_read else ([], None)
        elif reader == "builtin":
            crawled, version = static_reader.read_pages(to_read, config, session)
        else:
            crawled, version = crawl_pages(to_read, config, session) if to_read else ([], None)
            failed = [r["page_url"] for r in crawled if r.get("status") == "browser_failed"]
            browser_failed = bool(failed)
            if failed and config["page_reader"].get("use") == "auto":
                # Crawl4AI could not be used here after all: the builtin reader reads the pages it did not.
                error = next(r.get("error", "") for r in crawled if r.get("status") == "browser_failed")
                fallback = {"from": "crawl4ai", "to": "builtin", "why": error, "pages": len(failed),
                            "crawl4ai_version": version}
                reader = "builtin"
                again, version = static_reader.read_pages(failed, config, session)
                again = {r["page_url"]: r for r in again}
                crawled = [again.get(r["page_url"], r) for r in crawled]
    except Exception as exc:  # noqa: BLE001 - the page reader failing is a failure of the pages, not of the run
        reason = "%s: %s" % (type(exc).__name__, exc)
        crawled, version = [{"page_url": p, "status": "error", "error": "the page reader stopped: " + reason,
                             "images": []} for p in to_read], None
    transport = {"fetch": session.transport, "crawl": reader}
    provider = "builtin" if reader == "builtin" else "crawl4ai"  # whose sighting a page read now is
    by_page = {r["page_url"]: r for r in crawled}
    by_page.update(gated)
    for record in by_page.values():
        # r5.59: a page counts as read only with HTTP 200; a refusal stops its host for the rest of this run.
        code = record.get("http_status")
        if code is None:
            continue
        refusal = session.note_read(record["page_url"], code, final_url=record.get("final_url"))
        if code != 200 and record.get("status") in ("ok", "no_images", "failed"):
            ignored = len(record.get("images") or [])
            record.update(status=refusal or "failed", images=[],
                          error=record.get("error") or "the page reader answered HTTP %s: not counted as read" % code)
            if ignored:
                record["images_not_used"] = ignored
    crawled = [by_page.get(p) or {"page_url": p, "status": "blocked", "error": BLOCKED, "images": []}
               for p in listed if p in by_page or p not in to_read]
    by_url = {c["image_url"]: c for c in candidates}
    added = 0
    read_now, when = {}, common.now()
    for record in crawled:
        if record.get("status") != "ok":
            continue
        on_page = {}
        for i in record.get("images", []):
            for address in [i["src"]] + [v for v in (i.get("variants") or []) if isinstance(v, str)]:
                on_page.setdefault(address, i)
        for c in candidates:
            hit = on_page.get(c["image_url"]) or on_page.get(c.get("thumbnail_url") or "")
            if not hit:
                continue
            if c["page_url"] == record["page_url"]:
                read_now[c["cid"]] = {"alt": hit["alt"], "desc": hit["desc"], "score": hit["score"]}
                says = said(record.get("page_says"), hit)
                if says:
                    read_now[c["cid"]]["page_says"] = says
            known = {f.get("page_url") or f.get("page") for f in c.get("found_by", [])} | {c["page_url"]}
            if record["page_url"] not in known:  # the same image on another page read now: that page is a source too
                c.setdefault("found_by", []).append({"provider": provider, "page": record["page_url"],
                                                     "page_url": record["page_url"], "score": hit.get("score")})
        extra = sorted((i for i in record.get("images", [])
                        if not ({i["src"]} | set(v for v in (i.get("variants") or []) if isinstance(v, str))) & set(by_url)
                        and i["src"].startswith(("http://", "https://")) and not common.blocked(i["src"], config)
                        and not (isinstance(i.get("width"), int) and i["width"] < 200)),
                       key=lambda i: -(i.get("score") or 0))[:int(config["crawl4ai"].get("images_per_page", 3))]
        for image in extra:
            if len(candidates) >= budgets["max_candidates"]:
                break
            item = {"cid": "C%02d" % (len(candidates) + 1), "image_url": image["src"], "thumbnail_url": "",
                    "page_url": record["page_url"], "title": image["alt"], "page_text": image["desc"], "creator": "",
                    "license": "", "license_url": "", "width": image.get("width"), "height": image.get("height"),
                    "found_by": [{"provider": provider, "page": record["page_url"], "page_url": record["page_url"],
                                  "score": image.get("score")}]}
            says = said(record.get("page_says"), image)
            if says:
                read_now[item["cid"]] = {"page_says": says}
            candidates.append(item)
            by_url[item["image_url"]] = item
            added += 1
    statuses_by_page = {r["page_url"]: r.get("status") for r in crawled}
    for c in candidates:
        earlier = c.pop("on_page", None)
        if c["cid"] in read_now:
            c["on_page"] = read_now[c["cid"]]
            c.pop("stale_on_page", None)
        elif earlier:
            status = statuses_by_page.get(c["page_url"], "not read this time (max_pages)")
            c["stale_on_page"] = dict(earlier, stale_since=when, why=(
                "the page was read this time, but this image is not on it now" if status == "ok" else
                "this collect did not read the page (%s)" % status))
    images_dir = run.path("images")
    fetched, kept, stale = [], 0, []
    for c in candidates:
        # This fetch decides the candidate's image: what an earlier fetch got is kept aside, never as this one's.
        old = c.pop("image", None)
        if old:
            old.pop("gid", None)
        if kept >= budgets["max_images"]:
            fetched.append({"cid": c["cid"], "status": "skipped_budget"})
            if old:
                c["stale_image"] = dict(old, stale_since=common.now(), why="not fetched again (skipped_budget)")
                stale.append(c["cid"])
            continue
        result = fetch_image(c["image_url"], config, session=session)
        what = "original"
        if result["status"] != "ok" and c.get("thumbnail_url"):
            if result["status"] in NO_THUMBNAIL:
                result["thumbnail_not_fetched"] = ("%s (%s): its thumbnail is not fetched either, from this site or "
                                                   "another" % (NO_THUMBNAIL[result["status"]], result["status"]))
            else:
                first = {k: v for k, v in result.items() if k != "data"}
                result = fetch_image(c["thumbnail_url"], config, session=session)
                what = "thumbnail"
                result["original_attempt"] = first
        record = {"cid": c["cid"], "what": what, "url": c["image_url"] if what == "original" else c["thumbnail_url"]}
        record.update({k: v for k, v in result.items() if k != "data"})
        if result["status"] == "ok":
            images_dir.mkdir(exist_ok=True)
            name = "%s.%s" % (result["sha256"], IMAGE_TYPES.get(result["format"], "img"))
            (images_dir / name).write_bytes(result["data"])
            record["file"] = "images/" + name
            c["image"] = {"sha256": result["sha256"], "width": result["width"], "height": result["height"],
                          "format": result["format"], "bytes": result["bytes"], "what": what, "file": record["file"]}
            c.pop("stale_image", None)
            kept += 1
        elif old:
            c["stale_image"] = dict(old, stale_since=common.now(), why="this fetch failed (%s)" % result["status"])
            stale.append(c["cid"])
        fetched.append(record)
    page_ok = sum(1 for r in crawled if r.get("status") == "ok")
    statuses = {r.get("status") for r in crawled}
    browser = (False if browser_failed or "browser_failed" in statuses else
               True if (statuses & {"ok", "no_images", "failed"} or any("http_status" in r for r in crawled))
               and transport["crawl"] == "crawl4ai" else None)
    status = "ok" if kept and page_ok else ("partial" if kept or page_ok else "failed")
    every = statuses | {f.get("status") for f in fetched} | {(f.get("original_attempt") or {}).get("status")
                                                            for f in fetched}
    advice = []
    if "browser_failed" in statuses:
        advice.append("the browser did not start: install it (crawl4ai-setup), then run collect again; the images the "
                      "searches found were fetched")
    if "not_installed" in statuses:
        advice.append("Crawl4AI cannot run here and page_reader.use is crawl4ai: no page was read; the images the "
                      "searches found were fetched (page_reader.use auto or builtin reads them with the builtin reader)")
    if fallback:
        advice.append("Crawl4AI's browser did not start (install it: crawl4ai-setup); page_reader.use is auto, so the "
                      "builtin reader read the pages instead")
    if reader == "builtin" and crawled:
        advice.append("the pages were read by the workshop's builtin reader (%s): it runs no page scripts, so images "
                      "that only a script puts on a page were not seen (scripts_not_run); verify-run does not count "
                      "it as Crawl4AI" % (fallback["why"] if fallback else why))
    if "not_html" in statuses:
        advice.append("some source page addresses did not answer with an HTML page (not_html): nothing was read from "
                      "them")
    if "blocked" in every:
        advice.append("pages and images on blocked hosts were neither opened nor fetched (network.blocked_hosts), and "
                      "no thumbnail was fetched in place of such an image")
    if every & {"robots_disallowed", "robots_unreachable"}:
        advice.append("robots.txt does not allow some pages or images, or could not be read this time: they were "
                      "neither opened nor fetched, and nothing was tried another way, not even a thumbnail (robots in "
                      "collect.json)")
    if "refused" in every:
        advice.append("some hosts refused (401, 403, 451 or a check page): nothing more was asked of them in this run, "
                      "nothing was tried another way and no thumbnail was fetched in place of an image they refused; "
                      "to see such an image, open its source page yourself")
    if every & {"rate_limited", "host_paused"}:
        advice.append("some hosts limited the rate (429) or asked for a wait longer than network.max_wait_seconds: "
                      "nothing more was asked of them in this run (where the search gave a thumbnail on another site, "
                      "that thumbnail was tried instead); run again later")
    if every & {"private_address", "too_many_redirects"}:
        advice.append("addresses on this machine or a private network, and chains of more than %d redirects, were not "
                      "asked (where the search gave a thumbnail for such an image, that thumbnail was tried instead); "
                      "send your own images instead" % common.MAX_REDIRECTS)
    if "skipped_max_requests" in every:
        advice.append("budgets.max_requests (%d) was reached: what was left was not asked, not even a thumbnail in "
                      "place of an image" % session.max_requests)
    if stale:
        advice.append("%d candidate(s) kept only an earlier fetch's image (stale_image): fetch again to use them" %
                      len(stale))
    outdated = run.outdate("collect")
    run.save_candidates(candidates)
    record = {"schema": "visual-collect/1", "reader": reader, "reader_version": version,
              "page_reader": {"use": config["page_reader"].get("use", "auto"), "reader": reader, "why": why,
                              "fallback": fallback, "pages_ok": page_ok},
              "pages": crawled,
              "crawl4ai": {"importable": importable, "browser_started": browser,
                           "pages_ok": 0 if reader == "builtin" else page_ok},
              "fetched": fetched, "added_from_pages": added, "decoded": kept, "stale": stale,
              "status": status, "transport": transport, "robots": session.robots_record(),
              "network": session.record(), "next": advice, "outdated": outdated}
    if reader == "crawl4ai":  # kept one more release for older readers of collect.json; reader_version replaces it
        record["crawl4ai_version"] = version
    run.save("collect.json", record)
    run.step("collect", {"status": status, "pages_ok": page_ok, "pages": len(crawled), "decoded": kept,
                         "added_from_pages": added, "stale": len(stale), "requests": session.requests,
                         "reader": reader})
    return {"status": status, "pages": len(crawled), "pages_ok": page_ok, "decoded": kept, "added_from_pages": added,
            "browser_started": browser, "stale": len(stale), "next": advice, "outdated": outdated, "reader": reader}

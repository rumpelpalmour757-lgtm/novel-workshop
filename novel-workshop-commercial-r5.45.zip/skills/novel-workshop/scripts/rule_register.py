#!/usr/bin/env python3
"""Rule-conflict register for one book: check it, list what the author still has to decide, find prior uses of a word.

A book accumulates rule files (the author's rules, a grammar handbook, self-check lists, naming sheets, the project
file, the prose and punctuation rule files). They all sit on the same tier of the constitution, so none outranks
another; CONSTITUTION.md section 1 ("同一层之内") gives the order for settling a clash and section 6 asks that every
rule file be registered on the way in and on the way out. The register (rule-conflicts.json next to the project file;
template: assets/rule-conflicts-template.json; how to fill it: references/continuity.md "规则打架时") records three
things: the rule files in force and superseded, the texts the evidence lines point into, and one item per clash,
mismatch, collision, stale wording or standing exception, each with its sides and its status.

This tool only checks what the register says against itself and against the files it names. Whether a rule should
stay, and how the author decides an open item, it cannot judge.

  python3 rule_register.py check REGISTER [--texts-root DIR]        structure, source versions, evidence lines
  python3 rule_register.py list REGISTER [--status open] [--markdown] the items, e.g. the open ones for the author
  python3 rule_register.py collide --register REGISTER --texts-root DIR WORD [WORD ...]
                                                                     where each word already occurs in the texts;
                                                                     exits 1 when a registered text was not found
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys

SCHEMA = "rule-conflicts/1"
MARKER = "<!-- 原文开始 -->\n"
SOURCE_STATUS = ("in_force", "superseded", "pending")
KINDS = ("conflict", "mismatch", "collision", "stale", "exception")
ITEM_STATUS = ("open", "decided", "closed")
RULE_STEPS = (1, 2, 3, 4)  # section 1 "同一层之内" (NWC-1.2.1): steps the workshop may apply itself; step 5 is the author's


def text_of(value):
    return isinstance(value, str) and bool(value.strip())


def read_lines(path):
    return Path(path).read_text(encoding="utf-8-sig").splitlines()


def original_sha256(path):
    """SHA-256 of the author's text: what follows the marker when the file carries one, else the whole file.

    The file is read as text the way the delivery gate reads it: UTF-8, a leading byte-order mark dropped, CRLF line
    breaks read as LF; the hash is taken over that text in UTF-8 with LF. A file saved on Windows (CRLF, BOM) is the
    same text and gives the same hash; for a UTF-8 file with LF and no mark this is the plain bytes, as before (r5.25:
    the marker was looked for with LF only, so a CRLF copy read as a changed version). A file that is not UTF-8 is
    hashed as its bytes. Registers written under r5.24 and earlier hold a digest over bytes; see r524_sha256."""
    data = Path(path).read_bytes()
    try:
        text = data.decode("utf-8-sig").replace("\r\n", "\n")
    except UnicodeDecodeError:
        return hashlib.sha256(data).hexdigest()
    if MARKER in text:
        text = text.split(MARKER, 1)[1]
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def r524_sha256(path):
    """The digest r5.24 and earlier wrote into registers: over bytes, not text. The bytes after the marker when the
    bytes carry it (looked for with LF, so a CRLF file was hashed whole), else the whole file, BOM included.

    Kept so that a register written then still checks (r5.27, review H525-01): for a file with CRLF line breaks or a
    BOM the two rules give different digests, and r5.25 reported such an unchanged file as changed. A registered digest
    counts as this kind only when this rule, applied to the file as it is now, gives exactly the registered value, that
    is, when the file has the very bytes it had when it was registered. Nothing else is let through."""
    data = Path(path).read_bytes()
    marker = MARKER.encode("utf-8")
    if marker in data:
        data = data.split(marker, 1)[1]
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def check(register_path, texts_root=None):
    """Return {"status", "problems", "counts", ...}; status is FAIL when anything in the register does not hold.

    A register of the wrong shape is a FAIL with a message, never a traceback (r5.22)."""
    try:
        return _check(Path(register_path), texts_root)
    except (TypeError, AttributeError, KeyError, ValueError, OSError) as error:
        return {"status": "FAIL", "problems": ["malformed register (%s: %s)" % (type(error).__name__, error)],
                "counts": {}}


def _check(register_path, texts_root):
    problems = []

    def need(condition, message):
        if not condition:
            problems.append(message)
        return condition

    try:
        register = load(register_path)
    except (OSError, ValueError) as error:
        return {"status": "FAIL", "problems": ["cannot read the register: %s" % error], "counts": {}}
    if not need(isinstance(register, dict) and register.get("schema") == SCHEMA, "schema must be %s" % SCHEMA):
        return {"status": "FAIL", "problems": problems, "counts": {}}
    need(text_of(register.get("project")), "project must name the book")
    need(text_of(register.get("updated")), "updated must give the date of the last check")

    # --- sources: the rule files, in force or superseded
    sources = register.get("sources")
    need(isinstance(sources, list) and sources, "sources must be a non-empty list")
    by_id, stale_sources, legacy_sources, source_text = {}, [], [], {}
    for entry in sources if isinstance(sources, list) else []:
        if not need(isinstance(entry, dict) and text_of(entry.get("id")), "each source needs an id"):
            continue
        for key in ("file", "sha256", "superseded_by", "label"):
            need(entry.get(key) is None or isinstance(entry[key], str),
                 "source %s: %s must be a string (or left out)" % (entry["id"], key))
        # external switches off the file, hash and quote checks, so only a real JSON true counts (r5.22: the string
        # "false" used to count as true). false, null and leaving it out are a local file, checked as such (r5.23: null
        # was accepted but the notes said only true or false). Anything else is reported and the checks run as for a
        # local file.
        need(entry.get("external") is None or isinstance(entry["external"], bool),
             "source %s: external must be true or false (JSON; null or left out means false), not %r"
             % (entry["id"], entry.get("external")))
        sid = entry["id"]
        need(sid not in by_id, "source id %s is listed twice" % sid)
        by_id[sid] = entry
        for key in ("title", "version", "date"):
            need(text_of(entry.get(key)), "source %s needs %s" % (sid, key))
        status = entry.get("status")
        need(status in SOURCE_STATUS, "source %s: status must be one of %s" % (sid, ", ".join(SOURCE_STATUS)))
        if status == "superseded":
            need(text_of(entry.get("superseded_by")), "source %s is superseded but names no superseded_by" % sid)
        else:
            need(not entry.get("superseded_by"), "source %s is %s but has superseded_by" % (sid, status))
        external = entry.get("external") is True
        file_name = entry.get("file")
        if status == "in_force" and not external:
            if need(text_of(file_name), "source %s is in force and not external, so it needs a file" % sid):
                location = register_path.parent / file_name
                if need(location.is_file(), "source %s: file not found: %s" % (sid, file_name)):
                    source_text[sid] = location.read_text(encoding="utf-8-sig")
                    digest = entry.get("sha256")
                    if digest is not None:
                        actual = original_sha256(location)
                        if actual != digest and r524_sha256(location) == digest:
                            # Registered under r5.24 and the bytes are the same: unchanged. Listed with the digest
                            # the current rule gives, which may be copied into the register by hand.
                            legacy_sources.append({"source": sid, "file": file_name, "text_sha256": actual})
                        elif not need(actual == digest, "source %s: %s has changed since the register was checked "
                                      "(registered %s…, now %s…); re-check the items that cite it, then update sha256"
                                      % (sid, file_name, str(digest)[:12], actual[:12])):
                            stale_sources.append(sid)
    for sid, entry in by_id.items():
        if entry.get("status") == "superseded":
            seen, current = {sid}, entry.get("superseded_by")
            while isinstance(current, str) and current in by_id and by_id[current].get("status") == "superseded" \
                    and current not in seen:
                seen.add(current)
                current = by_id[current].get("superseded_by")
            need(isinstance(current, str) and current in by_id and by_id[current].get("status") != "superseded",
                 "source %s: superseded_by must lead to a source that is in force or pending" % sid)

    # --- texts: the chapter versions the evidence lines point into
    texts = register.get("texts", {})
    if not need(isinstance(texts, dict), "texts must be an object: id -> relative path"):
        texts = {}
    lines_of, texts_checked = {}, False
    if isinstance(texts, dict):
        for tid, rel in texts.items():
            need(text_of(tid) and text_of(rel), "texts entries need an id and a path (a string): %r" % (tid,))
        texts = {tid: rel for tid, rel in texts.items() if text_of(rel)}
        if texts_root is not None:
            texts_checked = True
            for tid, rel in texts.items():
                location = Path(texts_root) / rel
                if need(location.is_file(), "text %s: file not found under --texts-root: %s" % (tid, rel)):
                    lines_of[tid] = read_lines(location)

    # --- items
    items = register.get("items")
    need(isinstance(items, list), "items must be a list")
    counts = {"open": 0, "decided": 0, "closed": 0}
    kinds = {kind: 0 for kind in KINDS}
    ids = set()
    for item in items if isinstance(items, list) else []:
        if not need(isinstance(item, dict) and text_of(item.get("id")), "each item needs an id"):
            continue
        iid = item["id"]
        need(iid not in ids, "item id %s is listed twice" % iid)
        ids.add(iid)
        need(text_of(item.get("title")), "item %s needs a title" % iid)
        kind = item.get("kind")
        if need(isinstance(kind, str) and kind in KINDS, "item %s: kind must be one of %s" % (iid, ", ".join(KINDS))):
            kinds[kind] += 1
        sides = item.get("sides")
        minimum = 1 if kind == "exception" else 2
        need(isinstance(sides, list) and len(sides) >= minimum,
             "item %s: a %s needs at least %d sides (a list)" % (iid, kind, minimum))
        sides = sides if isinstance(sides, list) else []
        cites_live = False
        for number, side in enumerate(sides, 1):
            label = "item %s side %d" % (iid, number)
            if not need(isinstance(side, dict), label + " must be an object"):
                continue
            if "source" in side:
                sid = side["source"]
                if need(isinstance(sid, str) and sid in by_id, label + ": unknown source %r" % (sid,)):
                    if by_id[sid].get("status") != "superseded":
                        cites_live = True
                need(text_of(side.get("where")), label + " needs where (which section of the source)")
                need("quote" not in side or isinstance(side["quote"], str), label + ": quote must be a string")
                if sid in source_text and text_of(side.get("quote")):
                    need(side["quote"] in source_text[sid], label + ": the quote is not in %s" % by_id[sid].get("file"))
            elif "text" in side:
                tid = side["text"]
                need(isinstance(tid, str) and tid in texts, label + ": unknown text %r" % (tid,))
                line = side.get("line")
                need(type(line) is int and line >= 1, label + ": line must be a positive integer")
                need(text_of(side.get("quote")), label + " needs the quoted words")
                if isinstance(tid, str) and tid in lines_of and type(line) is int and line >= 1 and text_of(side.get("quote")):
                    if need(line <= len(lines_of[tid]), label + ": %s has only %d lines" % (tid, len(lines_of[tid]))):
                        need(side["quote"] in lines_of[tid][line - 1],
                             label + ": the quote is not on line %d of %s" % (line, tid))
            else:
                need(False, label + " must cite a source or a text")
        status = item.get("status")
        if need(isinstance(status, str) and status in ITEM_STATUS,
                "item %s: status must be one of %s" % (iid, ", ".join(ITEM_STATUS))):
            counts[status] += 1
        if status == "open":
            need(text_of(item.get("ask")), "item %s is open, so ask must say what the author has to decide" % iid)
            need(text_of(item.get("meanwhile")),
                 "item %s is open, so meanwhile must say what is done until the author decides" % iid)
            need(not item.get("resolution") and not item.get("decided_by"),
                 "item %s is open but carries a resolution or decided_by" % iid)
            known = [s for s in sides if isinstance(s, dict) and isinstance(s.get("source"), str) and s["source"] in by_id]
            need(cites_live or not known,
                 "item %s is open but cites only superseded sources; re-check it against the current version" % iid)
        elif status == "decided":
            need(text_of(item.get("resolution")), "item %s is decided, so resolution must say how" % iid)
            decided = item.get("decided_by")
            if need(isinstance(decided, dict) and decided.get("who") in ("author", "workshop"),
                    "item %s: decided_by.who must be author or workshop" % iid):
                need(text_of(decided.get("when")), "item %s: decided_by.when is missing" % iid)
                if decided["who"] == "author":
                    need(text_of(decided.get("words")) and text_of(decided.get("source")),
                         "item %s: an author decision needs the author's words and where they were given" % iid)
                else:
                    step = decided.get("rule_applied")
                    need(type(step) is int and step in RULE_STEPS,
                         "item %s: a workshop decision must name rule_applied 1, 2, 3 or 4 (section 1 '同一层之内'); "
                         "step 5 is the author's" % iid)
        elif status == "closed":
            need(text_of(item.get("resolution")), "item %s is closed, so resolution must say why" % iid)
    return {"status": "FAIL" if problems else "OK", "problems": problems, "counts": counts, "kinds": kinds,
            "sources": {"in_force": sum(1 for s in by_id.values() if s.get("status") == "in_force"),
                        "superseded": sum(1 for s in by_id.values() if s.get("status") == "superseded"),
                        "pending": sum(1 for s in by_id.values() if s.get("status") == "pending"),
                        "stale": stale_sources, "legacy": legacy_sources},
            "texts_checked": texts_checked}


def listing(register_path, status="open", markdown=False):
    register = load(register_path)
    wanted = [i for i in register.get("items", []) if status == "all" or i.get("status") == status]
    if not markdown:
        return wanted
    label = {s.get("id"): s.get("label") or s.get("id") for s in register.get("sources", []) if isinstance(s, dict)}
    lines = []
    for item in wanted:
        head = "- **%s**（%s，%s）%s" % (item.get("id"), item.get("kind"), item.get("status"), item.get("title"))
        if item.get("status") == "open" and item.get("ask"):
            head += "：" + item["ask"]
        elif item.get("resolution"):
            head += "：" + item["resolution"]
        lines.append(head)
        if item.get("status") == "open" and item.get("meanwhile"):
            lines.append("  - 定之前：" + item["meanwhile"])
        for side in item.get("sides", []):
            if "source" in side:
                lines.append("  - %s，%s：%s" % (label.get(side["source"], side["source"]), side.get("where", ""), side.get("quote", "")))
            else:
                lines.append("  - %s 第 %s 行：%s" % (side.get("text"), side.get("line"), side.get("quote", "")))
        if item.get("proposal"):
            lines.append("  - 工坊建议：" + item["proposal"])
    return "\n".join(lines) + ("\n" if lines else "")


def collide(register_path, texts_root, words):
    """Every line of every registered text that contains one of the words: the prior uses a new name must not clash with.

    "complete" is true only when every registered text was read. A text that is not there (moved, or --texts-root
    pointing elsewhere) is listed under missing_texts and makes the result incomplete, so "not read" never looks like
    "read, and no clash" (r5.22; r5.21 skipped it silently)."""
    register = load(register_path)
    texts = register.get("texts") if isinstance(register, dict) else None
    hits = {word: [] for word in words}
    if not isinstance(texts, dict) or not texts:
        return {"complete": False, "error": "the register lists no texts (texts: id -> relative path)", "words": hits,
                "texts": [], "checked": [], "missing_texts": []}
    checked, missing = [], []
    for tid, rel in texts.items():
        location = Path(texts_root) / rel if text_of(rel) else None
        if location is None or not location.is_file():
            missing.append({"text": tid, "path": rel})
            continue
        checked.append(tid)
        for number, line in enumerate(read_lines(location), 1):
            for word in words:
                if word in line:
                    hits[word].append({"text": tid, "line": number, "snippet": line.strip()[:80]})
    return {"complete": not missing, "words": hits, "texts": list(texts), "checked": checked, "missing_texts": missing}


def utf8_stdio():
    """Reports are UTF-8 on every platform; a Windows pipe would otherwise use the local code page."""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main(argv=None):
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    commands = parser.add_subparsers(dest="command", required=True)
    p_check = commands.add_parser("check", help="check the register's structure, sources and evidence lines")
    p_check.add_argument("register")
    p_check.add_argument("--texts-root", help="directory the texts paths are relative to; without it lines are not checked")
    p_list = commands.add_parser("list", help="list items, by default the open ones")
    p_list.add_argument("register")
    p_list.add_argument("--status", default="open", choices=ITEM_STATUS + ("all",))
    p_list.add_argument("--markdown", action="store_true")
    p_collide = commands.add_parser("collide", help="where the given words already occur in the registered texts")
    p_collide.add_argument("--register", required=True)
    p_collide.add_argument("--texts-root", required=True)
    p_collide.add_argument("words", nargs="+")
    args = parser.parse_args(argv)
    if args.command == "check":
        result = check(args.register, args.texts_root)
        print(json.dumps(result, ensure_ascii=False, indent=1))
        return 0 if result["status"] == "OK" else 1
    try:
        if args.command == "list":
            result = listing(args.register, args.status, args.markdown)
            print(result if args.markdown else json.dumps(result, ensure_ascii=False, indent=1))
            return 0
        result = collide(args.register, args.texts_root, args.words)
    except (TypeError, AttributeError, KeyError, ValueError, OSError) as error:
        print(json.dumps({"status": "FAIL", "problems": ["malformed register (%s: %s); run check first"
                                                         % (type(error).__name__, error)]}, ensure_ascii=False, indent=1))
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=1))
    return 0 if result["complete"] else 1


if __name__ == "__main__":
    sys.exit(main())

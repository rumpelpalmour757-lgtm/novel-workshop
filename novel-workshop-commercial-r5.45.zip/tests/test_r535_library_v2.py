#!/usr/bin/env python3
"""r5.35: the inspiration library, format 2 (the r5.34 review, point 2, and the five-project plan's data rules).

The review reproduced on r5.34: a format-1 record that was valid in r5.33 (picked, no take) failed check in r5.34, and
card still printed it as "整张：…", so parts nobody chose could reach the next chapter. The plan asks for an explicit
format 2 with migration, what was looked at bound to the image version, page text kept apart from what was seen, the
parts taken (stable or one scene), who decided, a single guarded way to write, and rollback. These tests pin, with
made-up entries:

- format 1 is read as it was: check passes with a notice, card lists the entry as waiting, never as the whole image;
- migrate writes format 2 beside the original (or in its place after copying it into the history), never turns an
  old pick into the whole image (legacy_picked), refuses when the original has problems, and can be rolled back;
- check on format 2: observation scope and image version, nothing seen for an image nobody looked at, page text apart,
  take with stable/scene, "整张" only with something seen, who decided, what became the book's fact;
- adopt: only the parts named go in ("2 的布局、4 的灯光"), the revision guard (CONFLICT, --rebase only when nobody
  touched the same entries), two writers at once lose nothing, dry runs write nothing, withdraw and establish;
- card works without the image file; restore goes back to a revision.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
READ = SKILL / "scripts" / "inspiration_library.py"
WRITE = SKILL / "scripts" / "inspiration_write.py"
IMAGE = b"\x89PNG made-up bytes for the library tests"
SHA = hashlib.sha256(IMAGE).hexdigest()
OTHER = hashlib.sha256(b"another image version").hexdigest()


def run(script, *args, cwd=None):
    proc = subprocess.run([sys.executable, "-I", "-B", str(script), *map(str, args)], capture_output=True, text=True,
                          encoding="utf-8", cwd=cwd)
    return proc.returncode, proc.stdout, proc.stderr


def out(result):
    code, stdout, stderr = result
    try:
        return code, json.loads(stdout)
    except ValueError:
        raise AssertionError(stdout + stderr)


V1 = {"schema": "inspiration-library/1", "book": "测试", "entries": [
    {"id": "OLD1", "kind": "person", "title": "旧版已选参考", "visible": "瘦高身形；红围裙；左手握扳手",
     "source": {"type": "text", "ref": "旧版人物卡"}, "status": "picked", "use": [{"chapter": 7, "scene": "S1"}],
     "conflicts": []},
    {"id": "OLD2", "kind": "place", "title": "旧版挑过、写了借哪几样", "visible": "柜台在左；楼梯在后；顶灯一盏",
     "source": {"type": "text", "ref": "旧版场景卡"}, "status": "picked", "take": ["布局：柜台在左"], "subject": "铺子",
     "use": [{"chapter": 7, "scene": "S2"}], "conflicts": []},
    {"id": "Q1", "kind": "light", "title": "待找", "visible": "", "source": {"type": "search", "queries": ["雨夜 门口"]},
     "status": "to_find", "use": [{"chapter": 7, "scene": "S1"}], "conflicts": []}]}


def candidate(cid, sha=SHA, scope="original", seen="柜台在左，楼梯在后；顶上一盏吊灯，光圈很小；墙角堆着纸箱"):
    entry = {"id": cid, "kind": "place", "title": "候选 %s" % cid, "status": "candidate", "subjects": ["铺子"],
             "source": {"type": "link", "url": "https://example.org/page/%s" % cid,
                        "image_url": "https://example.org/img/%s.png" % cid, "license": "未核，只作写作参考",
                        "provider": "searxng"},
             "image": {"sha256": sha, "width": 640, "height": 480}, "page_text": "网页标题：老铺子", "use": [],
             "conflicts": []}
    entry["observation"] = {"scope": "none"} if scope == "none" else {"scope": scope, "image_sha256": sha, "seen": seen,
                                                                      "by": "工坊（测试）"}
    return entry


def selection(**fields):
    data = {"schema": "inspiration-selection/1", "decision": {"by": "作者", "date": "2026-10-23", "words": "2 的布局、4 的灯光"}}
    data.update(fields)
    return data


class Case(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def save(self, name, data):
        path = self.root / name
        path.write_bytes(json.dumps(data, ensure_ascii=False).encode("utf-8"))
        return path

    def v2(self, entries=(), revision=0):
        return self.save("library.json", {"schema": "inspiration-library/2", "book": "测试", "revision": revision,
                                          "entries": list(entries)})

    def adopt(self, library, sel, revision, *extra):
        return out(run(WRITE, "adopt", library, "--selection", self.save("sel.json", sel), "--if-revision", revision,
                       *extra))


class FormatOne(Case):
    def test_read_as_it_was(self):
        path = self.save("library.json", V1)
        code, report = out(run(READ, "check", path))
        self.assertEqual((code, report["status"], report["problems"]), (0, "OK", []))
        self.assertEqual(len(report["notices"]), 1)
        self.assertTrue(report["notices"][0].startswith("OLD1: picked without take"))
        code, text, err = run(READ, "card", path, "--chapter", "7")
        self.assertEqual(code, 0, err)
        self.assertNotIn("瘦高身形", text)  # the review's case: never "整张：瘦高身形；红围裙；左手握扳手"
        self.assertIn("挑过但没写借哪几样的（不写进素材，先请作者说借哪几样，不按整张写）：\n- OLD1 旧版已选参考（旧版选过）", text)
        self.assertNotIn("（OLD1）", text)  # not in the material block, not even with nothing taken
        self.assertIn("（OLD2）布局：柜台在左", text)
        self.assertNotIn("楼梯在后", text)


class Migrate(Case):
    def test_beside_the_original(self):
        path = self.save("library.json", V1)
        before = path.read_bytes()
        code, report = out(run(WRITE, "migrate", path, "--date", "2026-10-23"))
        self.assertEqual((code, report["status"], report["legacy_picked"]), (0, "OK", ["OLD1"]), report)
        self.assertEqual(path.read_bytes(), before)
        new = json.loads((self.root / "library.v2.json").read_text(encoding="utf-8"))
        self.assertEqual((new["schema"], new["revision"]), ("inspiration-library/2", 1))
        self.assertEqual(new["migrated_from"], {"schema": "inspiration-library/1",
                                                "sha256": hashlib.sha256(before).hexdigest(), "date": "2026-10-23"})
        old1, old2, q1 = new["entries"]
        self.assertEqual((old1["status"], "take" in old1), ("legacy_picked", False))
        self.assertEqual(old1["observation"], {"scope": "legacy", "seen": "瘦高身形；红围裙；左手握扳手"})
        self.assertIn("采用范围待作者明确，不按整张用", old1["note"])
        self.assertEqual(old2["take"], [{"part": "布局：柜台在左", "scope": "unspecified"}])
        self.assertEqual(old2["subjects"], ["铺子"])
        self.assertNotIn("observation", q1)
        code, report = out(run(READ, "check", self.root / "library.v2.json"))
        self.assertEqual((code, report["problems"]), (0, []))
        self.assertTrue(any(n.startswith("OLD1: picked in format 1 without saying which parts") for n in report["notices"]))
        self.assertTrue(any("stable or only this scene is not recorded" in n for n in report["notices"]))
        code, text, err = run(READ, "card", self.root / "library.v2.json", "--chapter", "7")
        self.assertIn("- OLD1 旧版已选参考（旧版选过）", text)
        self.assertNotIn("（OLD1）", text)
        self.assertNotIn("瘦高身形", text)
        history = self.root / "library.v2.history"
        self.assertTrue((history / "r0001.json").is_file())
        log = [json.loads(line) for line in (history / "log.jsonl").read_text(encoding="utf-8").splitlines()]
        self.assertEqual((log[0]["action"], log[0]["source_sha256"]), ("migrate", hashlib.sha256(before).hexdigest()))
        code, report = out(run(WRITE, "migrate", path))
        self.assertEqual((code, report["status"]), (2, "ERROR"))  # library.v2.json already exists
        code, report = out(run(WRITE, "migrate", self.root / "library.v2.json"))
        self.assertIn("already format 2", report["error"])

    def test_in_place_and_back(self):
        path = self.save("library.json", V1)
        before = path.read_bytes()
        code, report = out(run(WRITE, "migrate", path, "--replace"))
        self.assertEqual(code, 0, report)
        backup = self.root / report["kept"]
        self.assertEqual(backup.read_bytes(), before)
        self.assertEqual(backup.name, "v1-original-%s.json" % hashlib.sha256(before).hexdigest()[:12])
        self.assertEqual(json.loads(path.read_text(encoding="utf-8"))["schema"], "inspiration-library/2")
        code, report = out(run(WRITE, "restore", path, "--if-revision", 1, "--from", backup))
        self.assertEqual((code, report["schema"]), (0, "inspiration-library/1"), report)
        self.assertEqual(path.read_bytes(), before)
        self.assertTrue((self.root / "library.history" / "before-restore-r0001.json").is_file())

    def test_a_library_with_problems_is_not_migrated(self):
        bad = json.loads(json.dumps(V1))
        bad["entries"][0]["visible"] = ""
        path = self.save("library.json", bad)
        code, report = out(run(WRITE, "migrate", path))
        self.assertEqual(code, 2)
        self.assertIn("fix the format-1 problems first", report["error"])
        self.assertFalse((self.root / "library.v2.json").exists())


class CheckFormatTwo(Case):
    def problems(self, entries):
        code, report = out(run(READ, "check", self.v2(entries)))
        return report["problems"]

    def picked(self, **fields):
        entry = candidate("WEB-1")
        entry.update(status="picked", take=[{"part": "布局：柜台在左", "scope": "stable"}],
                     decision={"by": "作者", "date": "2026-10-23"})
        entry.update(fields)
        return entry

    def test_a_complete_record(self):
        self.assertEqual(self.problems([candidate("WEB-1"), candidate("WEB-2", scope="none"), self.picked(id="WEB-3")]), [])

    def test_what_was_looked_at(self):
        nobody = candidate("WEB-1", scope="none")
        nobody["observation"]["seen"] = "编出来的观察"
        cases = (([nobody], "nobody looked at the image (scope none): seen and unclear stay empty"),
                 ([candidate("WEB-1", seen="")], "observation.seen is empty"),
                 ([dict(candidate("WEB-1"), observation={"scope": "original", "seen": "x", "by": "工坊"})],
                  "names the image version it looked at"),
                 ([dict(candidate("WEB-1"), observation={"scope": "original", "image_sha256": OTHER, "seen": "x",
                                                          "by": "工坊"})], "the observation was of another image version"),
                 ([dict(candidate("WEB-1"), observation={"scope": "glance"})], "observation.scope must be one of"),
                 ([{k: v for k, v in candidate("WEB-1").items() if k != "observation"}], "observation says what was looked at"),
                 ([dict(candidate("WEB-1"), page_text="")], "page_text is what the web page says"))
        for entries, problem in cases:
            with self.subTest(problem=problem):
                self.assertTrue(any(problem in p for p in self.problems(entries)), self.problems(entries))

    def test_what_was_taken(self):
        cases = (([self.picked(take=None)], "a picked entry says which parts the author takes"),
                 ([self.picked(take=["布局"])], "take is a list of {part, scope: stable|scene, subject}"),
                 ([self.picked(take=[{"part": "布局", "scope": "always"}])], "take is a list of"),
                 ([self.picked(decision=None)], "says who decided and when"),
                 ([self.picked(take=[{"part": "整张", "scope": "stable"}], observation={"scope": "none"})],
                  "\"整张\" takes everything the image shows"),
                 ([dict(candidate("WEB-1"), take=[{"part": "布局", "scope": "stable"}])], "only a picked entry has it"),
                 ([self.picked(established=[{"part": "布局：柜台在左", "where": "项目档案"}])], "established is a list"))
        for entries, problem in cases:
            with self.subTest(problem=problem):
                entries = [{k: v for k, v in e.items() if v is not None} for e in entries]
                self.assertTrue(any(problem in p for p in self.problems(entries)), self.problems(entries))
        whole = self.picked(take=[{"part": "整张", "scope": "stable"}])
        self.assertEqual(self.problems([whole]), [])

    def test_the_template(self):
        code, report = out(run(READ, "check", SKILL / "assets" / "inspiration-library-template.json"))
        self.assertEqual(report["schema"], "inspiration-library/2")
        self.assertEqual(report["problems"], ["IMG-001: file not found: images/IMG-001.jpg",
                                              "IMG-001: an observation of the original names the image version it "
                                              "looked at (image_sha256)"])  # the two placeholders the user fills in


class Adopt(Case):
    def test_only_the_parts_named(self):
        library = self.v2([candidate("WEB-1"), candidate("WEB-3", sha=OTHER, seen="柜台；地上一摊水；顶上一排冷白灯管")])
        two = candidate("WEB-2", sha=OTHER, seen="窗外的霓虹招牌；屋里一盏暖色台灯；人坐在柜台后")
        sel = selection(adopt=[
            {"id": "WEB-1", "take": [{"part": "布局：柜台在左、楼梯在后", "scope": "stable", "subject": "铺子"}],
             "use": [{"chapter": 7, "scene": "S1"}]},
            {"id": "WEB-2", "entry": two, "take": [{"part": "灯光：屋里一盏暖色台灯", "scope": "scene"}],
             "skip": ["人"], "use": [{"chapter": 7, "scene": "S1"}]}],
            reject=[{"id": "WEB-3"}])
        code, report = self.adopt(library, sel, 0)
        self.assertEqual((code, report["status"], report["revision"]), (0, "OK", 1), report)
        data = json.loads(library.read_text(encoding="utf-8"))
        self.assertEqual([(e["id"], e["status"]) for e in data["entries"]],
                         [("WEB-1", "picked"), ("WEB-3", "rejected"), ("WEB-2", "picked")])
        code, text, err = run(READ, "card", library, "--chapter", "7")
        self.assertIn("（WEB-1）布局：柜台在左、楼梯在后（稳定）（看图：看了原图）", text)
        self.assertIn("（WEB-2）灯光：屋里一盏暖色台灯（这一场）（看图：看了原图；不借：人）", text)
        for seen_only in ("墙角堆着纸箱", "霓虹招牌", "地上一摊水", "人坐在柜台后"):
            self.assertNotIn(seen_only, text)

    def test_choices_that_are_refused(self):
        library = self.v2([candidate("WEB-1"), candidate("WEB-2", scope="none")])
        before = library.read_bytes()
        bad = (selection(adopt=[{"id": "WEB-1", "take": [{"part": "布局", "scope": "unspecified"}]}]),
               selection(adopt=[{"id": "WEB-1", "take": []}]),
               selection(adopt=[{"id": "WEB-1"}]),
               selection(adopt=[{"id": "WEB-9", "take": [{"part": "布局", "scope": "stable"}]}]),
               selection(decision={"by": "作者", "date": "昨天"}, adopt=[{"id": "WEB-1", "take": [{"part": "布局",
                                                                                                "scope": "stable"}]}]),
               selection(adopt=[{"id": "WEB-1", "take": [{"part": "布局", "scope": "stable"}]}],
                         reject=[{"id": "WEB-1"}]),
               selection(adopt=[{"id": "WEB-1", "take": [{"part": "布局", "scope": "stable"}]},
                                {"id": "WEB-1", "take": [{"part": "灯光", "scope": "scene"}]}]),
               {"schema": "inspiration-selection/1", "adopt": []})
        for sel in bad:
            with self.subTest(sel=sel):
                code, report = self.adopt(library, sel, 0)
                self.assertEqual((code, report["status"]), (2, "ERROR"), report)
        # 整张 of an image nobody looked at: the library would not pass check, so nothing is written.
        code, report = self.adopt(library, selection(adopt=[{"id": "WEB-2", "take": [{"part": "整张", "scope": "stable"}]}]), 0)
        self.assertEqual((code, report["status"]), (1, "PROBLEMS"), report)
        self.assertEqual(library.read_bytes(), before)

    def test_the_revision_guard(self):
        library = self.v2([candidate("WEB-1"), candidate("WEB-2")])
        first = selection(adopt=[{"id": "WEB-1", "take": [{"part": "布局", "scope": "stable"}]}])
        second = selection(adopt=[{"id": "WEB-2", "take": [{"part": "灯光", "scope": "scene"}]}])
        self.assertEqual(self.adopt(library, first, 0)[0], 0)
        # The second person read revision 0 too.
        before = library.read_bytes()
        code, report = self.adopt(library, second, 0)
        self.assertEqual((code, report["status"], report["current_revision"]), (3, "CONFLICT", 1))
        self.assertEqual(library.read_bytes(), before)
        code, report = self.adopt(library, second, 0, "--rebase")
        self.assertEqual((code, report["revision"], report["rebased_from"]), (0, 2, 0), report)
        data = json.loads(library.read_text(encoding="utf-8"))
        self.assertEqual([e["status"] for e in data["entries"]], ["picked", "picked"])  # both kept
        # Someone who also read revision 0 and chose differently for WEB-1: WEB-1 changed since, so it is refused.
        again = selection(adopt=[{"id": "WEB-1", "take": [{"part": "只要楼梯", "scope": "stable"}]}])
        before = library.read_bytes()
        code, report = self.adopt(library, again, 0, "--rebase")
        self.assertEqual((code, report["status"], report["changed"]), (3, "CONFLICT", ["WEB-1"]))
        self.assertEqual(library.read_bytes(), before)

    def test_two_writers_at_once(self):
        library = self.v2([candidate("WEB-%d" % n) for n in range(1, 3)])
        sels = [self.save("s%d.json" % n, selection(adopt=[{"id": "WEB-%d" % n, "take": [{"part": "布局", "scope": "stable"}]}]))
                for n in (1, 2)]
        procs = [subprocess.Popen([sys.executable, "-I", "-B", str(WRITE), "adopt", str(library), "--selection", str(s),
                                   "--if-revision", "0"], stdout=subprocess.PIPE, stderr=subprocess.PIPE) for s in sels]
        codes = sorted(p.wait() for p in procs)
        for p in procs:
            p.stdout.close()
            p.stderr.close()
        self.assertEqual(codes[0], 0)
        self.assertIn(codes[1], (2, 3))  # the lock, or the revision: never both written over each other
        data = json.loads(library.read_text(encoding="utf-8"))
        self.assertEqual((data["revision"], sorted(e["status"] for e in data["entries"])), (1, ["candidate", "picked"]))
        loser = next(s for s, e in zip(sels, data["entries"]) if e["status"] == "candidate")
        code, report = out(run(WRITE, "adopt", library, "--selection", loser, "--if-revision", 0, "--rebase"))
        self.assertEqual(code, 0, report)
        data = json.loads(library.read_text(encoding="utf-8"))
        self.assertEqual([e["status"] for e in data["entries"]], ["picked", "picked"])
        self.assertFalse(Path(str(library) + ".lock").exists())

    def test_dry_run_withdraw_establish_restore(self):
        library = self.v2([candidate("WEB-1"), candidate("WEB-2")])
        sel = selection(adopt=[{"id": "WEB-1", "take": [{"part": "布局：柜台在左", "scope": "stable"}],
                                "use": [{"chapter": 7, "scene": "S1"}]}])
        before = library.read_bytes()
        code, report = self.adopt(library, sel, 0, "--dry-run")
        self.assertEqual((code, report["status"]), (0, "DRY-RUN"))
        self.assertIn("（WEB-1）布局：柜台在左（稳定）", report["cards"]["7"])
        self.assertEqual(library.read_bytes(), before)
        self.assertEqual(self.adopt(library, sel, 0)[0], 0)
        code, report = self.adopt(library, selection(establish=[{"id": "WEB-1", "part": "布局：柜台在左",
                                                                  "where": "项目档案：铺子", "chapter": 7}]), 1)
        self.assertEqual((code, report["established"]), (0, ["WEB-1"]), report)
        code, report = self.adopt(library, selection(establish=[{"id": "WEB-1", "part": "楼梯", "where": "项目档案",
                                                                  "chapter": 7}]), 2)
        self.assertIn("is not one of the parts the author took", report["error"])
        code, report = self.adopt(library, selection(withdraw=[{"id": "WEB-1", "replaced_by": "WEB-2"}]), 2)
        self.assertEqual(code, 0, report)
        data = json.loads(library.read_text(encoding="utf-8"))
        self.assertEqual((data["entries"][0]["status"], data["entries"][0]["replaced_by"],
                          data["entries"][0]["established"]),
                         ("withdrawn", "WEB-2", [{"part": "布局：柜台在左", "where": "项目档案：铺子", "chapter": 7}]))
        code, text, err = run(READ, "card", library, "--chapter", "7")
        self.assertNotIn("WEB-1", text)
        withdrawn = library.read_bytes()
        code, report = out(run(WRITE, "restore", library, "--if-revision", 3, "--revision", 1))
        self.assertEqual((code, report["revision"]), (0, 4), report)
        # The revision it replaced is kept beside the history, so the restore itself can be undone.
        self.assertEqual((self.root / "library.history" / "before-restore-r0003.json").read_bytes(), withdrawn)
        data = json.loads(library.read_text(encoding="utf-8"))
        self.assertEqual((data["revision"], data["entries"][0]["status"]), (4, "picked"))
        code, report = out(run(WRITE, "history", library))
        self.assertEqual([x["action"] for x in report["log"]], ["adopt", "adopt", "adopt", "restore"])

    def test_a_held_lock_stops_the_write(self):
        library = self.v2([candidate("WEB-1")])
        Path(str(library) + ".lock").write_bytes(b"123 earlier")
        code, report = self.adopt(library, selection(adopt=[{"id": "WEB-1", "take": [{"part": "布局", "scope": "stable"}]}]), 0)
        self.assertEqual(code, 2)
        self.assertIn("another write holds the lock", report["error"])

    def test_a_failed_swap_leaves_the_old_revision(self):
        # The new revision goes to a temporary file next to the library and is swapped in with os.replace: when the
        # swap fails, the library is still the old revision, the temporary file is gone and the lock is released.
        # r5.37: the history copies and the pending note are written before the swap and taken back when it fails,
        # and the error says that nothing was written.
        spec = importlib.util.spec_from_file_location("r535_inspiration_write", WRITE)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        library = self.v2([candidate("WEB-1")])
        before = library.read_bytes()
        sel = selection(adopt=[{"id": "WEB-1", "take": [{"part": "布局", "scope": "stable"}]}])
        real = os.replace

        def fail_on_library(a, b):
            if Path(b).name == "library.json":
                raise OSError("disk full")
            return real(a, b)

        with mock.patch.object(module.os, "replace", side_effect=fail_on_library):
            with self.assertRaises(module.NotCommitted) as caught:
                module.adopt(library, sel, 0)
        self.assertIn("nothing written", str(caught.exception))
        self.assertEqual(library.read_bytes(), before)
        self.assertEqual(sorted(p.name for p in self.root.iterdir() if p.name.startswith("library.json")), ["library.json"])
        history = self.root / "library.history"
        self.assertEqual(sorted(p.name for p in history.iterdir()) if history.exists() else [], [])
        swaps = []
        with mock.patch.object(module.os, "replace", side_effect=lambda a, b: (swaps.append((Path(a).name, Path(b).name)),
                                                                              real(a, b))):
            self.assertEqual(module.adopt(library, sel, 0)["status"], "OK")
        self.assertEqual([b for a, b in swaps], ["r0000.json", "r0001.json", "pending.json", "library.json"])
        self.assertIn(("library.json.tmp-%d" % os.getpid(), "library.json"), swaps)
        self.assertEqual(json.loads(library.read_bytes().decode("utf-8"))["revision"], 1)
        self.assertFalse((history / "pending.json").exists())

    def test_format_one_is_migrated_first(self):
        path = self.save("library.json", V1)
        code, report = self.adopt(path, selection(adopt=[{"id": "OLD1", "take": [{"part": "体格：瘦高", "scope": "stable"}]}]), 0)
        self.assertIn("migrate it first", report["error"])


class WithoutTheImage(Case):
    def test_the_card_comes_from_the_record(self):
        (self.root / "images").mkdir()
        (self.root / "images" / "a.png").write_bytes(IMAGE)
        entry = {"id": "IMG-1", "kind": "person", "title": "作者的图", "subjects": ["修车铺老板"], "status": "picked",
                 "source": {"type": "author_file", "file": "images/a.png", "sha256": SHA, "creator": "作者",
                            "license": "作者自己的图"},
                 "observation": {"scope": "original", "image_sha256": SHA, "seen": "瘦高，背有点驼；深色围裙",
                                 "by": "工坊（测试）"},
                 "take": [{"part": "体格：瘦高，背有点驼", "scope": "stable"}], "skip": ["围裙"],
                 "decision": {"by": "作者", "date": "2026-10-23"}, "use": [{"chapter": 8, "scene": "S1"}], "conflicts": []}
        library = self.v2([entry])
        code, with_image, err = run(READ, "card", library, "--chapter", "8")
        (self.root / "images" / "a.png").unlink()
        code2, without, err2 = run(READ, "card", library, "--chapter", "8")
        self.assertEqual((code, code2, with_image), (0, 0, without))
        self.assertIn("（IMG-1）体格：瘦高，背有点驼（稳定）（看图：看了原图；不借：围裙）", without)
        code, report = out(run(READ, "check", library))
        self.assertEqual(report["problems"], ["IMG-1: file not found: images/a.png"])


if __name__ == "__main__":
    unittest.main()

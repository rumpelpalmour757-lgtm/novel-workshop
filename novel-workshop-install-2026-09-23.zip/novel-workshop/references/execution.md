# 执行检查、范围与恢复

## 选择足够简单的流程

普通短段落走“处理—检查—交付”。整章返修或多章核查先确定单元及真实依赖；资料够用就执行，不为一次润色建立整张工作图。步骤可由单个AI执行，不要求特定产品或多个模型。

| 原语 | 在小说任务中的作用 |
| --- | --- |
| NODE | 一个有边界的任务，例如审第5章的衔接或只改一场对白 |
| EDGE | 真正要带过去的原稿、状态、证据或用户决定 |
| STATE | 项目、版本、当前单元、已完成部分、剩余轮次与待办 |
| ROUTER | 简短处理或完整核查；返修、继续、跳过可选项或停止的原因 |
| GATE | 明确条件的实际检查，加上有依据的编辑判断 |

同一章节的空间、人物信息与文风可以分别审，再合并发现；后章依赖前章结果时按顺序处理。独立审查仅在工具可用且已有授权时并行，不自行切换模型、扩大代理数量或安装日程。合并相同单元和位置的同一问题，保留证据与分歧，不能把重复报告当成多票支持。

## 可执行条件

工具见 [workflow_guard.py](../scripts/workflow_guard.py)，仅依赖 Python 3 标准库。它只读原稿、候选稿和声明的条件；状态命令只写指定的工作记录，不修改正文。

在项目目录生成 `checks.json`，按本轮明确要求填写。所有路径相对于该文件所在目录；新稿、来源与状态随项目一起迁移。支持的条件如下：

| `type` | 字段 | 实际检查及限制 |
| --- | --- | --- |
| `length` | `min`、`max`，至少一个 | 统计非空白字符，含标点；其他口径另行统计，不能偷换 |
| `literal_count` | `text`、`count` | 字面出现次数，按不重叠匹配计算；不判断同义表达 |
| `contains` | `text` | 指定原句或片段是否保留；不保证上下文含义未变 |
| `scope` | `source`、`editable_lines` | 用原稿行号限定可改区间；插入仅可发生在可改行前或该区间内，文件末尾插入须原末行可改 |
| `quote` | `source`、`text`，可加 `line` | 短引能否在来源或指定起始行找到；仍需编辑判断引文是否支持结论 |
| `file_hash` | `source`、`sha256` | 指定文件是否保持原字节；用于作者冻结的章节 |

示例格式（条件从实际请求生成，不照搬示例数值）：

```json
{
  "candidate": "draft.md",
  "checks": [
    {"id": "keep_last_line", "type": "contains", "text": "他把门关上。"},
    {"id": "edit_scope", "type": "scope", "source": "original.md", "editable_lines": [[3, 5]]}
  ]
}
```

`python3 workflow_guard.py check checks.json` 返回逐条期望、实际结果及证据。`GREEN` 是声明条件全通过；`RED` 有条件失败；空清单是 `NOT_APPLICABLE`，不能说跑过测试。未知检查、无效范围或读不到必需文件返回错误，不能按通过处理。没有 Python 时按同一要求人工核查，并明确核查方式。

## 外置修订状态

需要跨会话修订或对轮数作程序限制时，使用下列命令；`workflow_guard.py` 替换为实际脚本路径：

```bash
python3 workflow_guard.py start run-state.json --task-id book-ch05-edit --spec checks.json --max-revisions 3
python3 workflow_guard.py record run-state.json --event-id verify-0 --review review.json
python3 workflow_guard.py reserve run-state.json --event-id repair-1
python3 workflow_guard.py record run-state.json --event-id verify-1 --review review.json
python3 workflow_guard.py status run-state.json
```

先 `start` 冻结规格与来源，再形成初稿；`record` 实际执行检查并记录裁决。需要返修时在改稿前 `reserve`，修后重新 `record`。初稿不占返修次数；达到上限后不能再预留返修。可在开始时加 `--max-seconds` 设置从创建任务起计算的时间上限。

`review.json` 至少包含 `verdict`（PASS／NEEDS_REVISION／FAIL）、非空 `checked_against` 列表及 `issues` 列表。每条问题记录单元、期望、实际文字与位置、依据、影响和范围。`PASS` 时仍列着未解决问题会被拒收；可选建议放在其他字段。此裁决由编辑提供，程序只校验结构和路由，不替代语义审稿。

状态保留九个字段：`task_id`、`current_node`、`completed_nodes`、`artifacts`、`decisions`、`evidence`、`budgets`、`retry_counts`、`human_approvals`。其中人类授权只存实际已有的记录，空列表不表示缺少普通改稿许可；工具不会据此授予发布权限。完成节点是本轮工作进度，不表示作者采纳草稿。

事件标识在同一任务内唯一，同一次动作重试沿用原标识；重复提交不再次计数，标识相同但内容改变会报冲突。修订额度由程序保存；恢复先读 `status` 和原稿，不重新 `start` 清空额度。规格或已冻结来源变化时报告 `INPUT_CHANGED`，先确认作者的新决定和受影响范围，不偷偷换文件、改预算或另起任务绕过旧限制。

这些程序限制只约束通过此工具执行的步骤；它没有接管模型调用、外部写入或完整运行环境。纯聊天版仍能用文本记录九字段，但不能声称有代码强制停止或自动永久存档。

## 失败先分类

| 命名失败 | 动作 | 小说任务的处理 |
| --- | --- | --- |
| `TRANSIENT_IO` | RETRY | 确认是短暂读取故障后重试一次；写入结果不明先检查原事件是否完成 |
| `OPTIONAL_SOURCE_UNAVAILABLE` | FALLBACK／SKIP | 使用已提供的合适样本，或跳过可选比较并说明覆盖范围 |
| `CHECK_FAILED`、`SCOPE_VIOLATION` | REPAIR | 按证据和修改范围返修，再核查；不盲目重跑同样输入 |
| `MISSING_REQUIRED_SOURCE`、无法裁定的版本冲突 | ESCALATE | 完成可确定部分，再问影响继续工作的关键材料或选择 |
| `INPUT_CHANGED` | 核对后重规划 | 遵守作者新决定，记录新依据及哪些结果需重查，保留原修订账目 |
| `BUDGET_EXHAUSTED`、明确授权边界 | STOP | 保留最好稿和未解决项，交接后停止该分支 |

可选文风样本缺失不能阻塞全部写作；缺少用户要求核对的某章则不能宣称全章检查完毕。复用写入标识避免重复保存同一次结果；已经获得的普通修订授权无需再次申请。

## 多单元任务收尾

检查单元边界是否清楚、每个依赖是否有实际材料、重要发现是否复核、修改是否超范围；确认可从记录恢复，失败没有被静默丢弃，修订有上限，下一步的选择有简短依据。复杂度应与任务相称，不为满足十二项检查的形式再造十二个步骤。

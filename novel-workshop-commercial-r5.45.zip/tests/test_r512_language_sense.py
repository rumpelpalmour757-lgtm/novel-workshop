#!/usr/bin/env python3
"""r5.12: language sense (语感) has a place in the method, and the naming list works the way the modules say.

The 2026-10-19 records the author forwarded (chapters 9 and 10 of the author's project, revised with r5.10): after each
whole-chapter PASS, an outside language review still found collocation slips, words such as "也" and "再" with nothing
to refer back to, one object under several names, and edits that brought in new problems (a repeated word next to the
edit, a tool named again right after it was introduced, an explanation placed before the person it explains had come
in). The skill had no section that asked these questions, and naming decisions made in one chapter were not carried to
the next. r5.12 adds that section (sentence-craft.md), points the whole-chapter expression check and the revision
comparison at it, and keeps the project's naming choices in a naming list whose retired names can be checked with the
prose checker's existing `terms`.

These tests pin what can be pinned without judging prose:
- every section a module names in quotation marks exists in the module it links to (so the L1 row and the new links
  cannot point at nothing);
- the original example changes exactly the words its notes discuss, keeps the one it says to keep, and passes the
  punctuation checker;
- a retired name from the naming list becomes a review item in a strict run and needs a decision, including where it
  is only part of a longer word (the literal limit the modules state);
- none of this is a built-in banned list: the prose checker flags none of these words on its own.
All material is invented for these tests; reviews are labelled test data and are not literary judgments.
"""

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
NOVEL = ROOT / "skills" / "novel-workshop"
SENTENCES = NOVEL / "references" / "sentence-craft.md"
SECTION = "语感：搭配、照应与叫法"


def load(name):
    spec = importlib.util.spec_from_file_location("r512_" + name, NOVEL / "scripts" / (name + ".py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def section(text, title):
    start = text.index("## " + title)
    end = text.find("\n## ", start + 3)
    return text[start:end if end != -1 else len(text)]


class SectionReferences(unittest.TestCase):
    def test_every_quoted_section_reference_exists_in_the_linked_module(self):
        checked = 0
        for md in sorted(NOVEL.rglob("*.md")):
            if "project-packs" in md.parts:
                continue
            text = md.read_text(encoding="utf-8")
            for match in re.finditer(r"\]\(([^)#\s]+\.md)\)((?:“[^”]+”)+)", text):
                target = (md.parent / match.group(1)).resolve()
                self.assertTrue(target.is_file(), "%s -> %s" % (md.relative_to(NOVEL), match.group(1)))
                body = target.read_text(encoding="utf-8")
                headings = [line.lstrip("#").strip() for line in body.splitlines() if line.startswith("#")]
                for name in re.findall(r"“([^”]+)”", match.group(2)):
                    checked += 1
                    self.assertTrue(any(h.startswith(name) for h in headings) or "**" + name in body,
                                    "%s names “%s” in %s, which has no such section"
                                    % (md.relative_to(NOVEL), name, match.group(1)))
        self.assertGreater(checked, 30)  # the pattern still finds the references

    def test_whole_chapter_tasks_and_their_checks_reach_the_language_section(self):
        skill = (NOVEL / "SKILL.md").read_text(encoding="utf-8")
        level1 = next(line for line in skill.splitlines() if line.startswith("| L1 "))
        self.assertIn("“%s”" % SECTION, level1)
        routing = next(line for line in skill.splitlines()
                       if "| [sentence-craft.md](references/sentence-craft.md) |" in line)
        self.assertIn("翻译腔", routing)
        expression = section((NOVEL / "references" / "prose-audit.md").read_text(encoding="utf-8"), "整章任务的表达检查与记录")
        self.assertIn("“%s”" % SECTION, expression)
        comparison = section((NOVEL / "references" / "editing.md").read_text(encoding="utf-8"), "修订前后对照")
        self.assertIn("“%s”" % SECTION, comparison)
        regression = section((NOVEL / "references" / "continuity.md").read_text(encoding="utf-8"), "修订后的回归核对")
        self.assertIn("称谓表", regression)
        self.assertIn("称谓表", (NOVEL / "assets" / "project-template.md").read_text(encoding="utf-8"))
        card = (NOVEL / "assets" / "delivery-gate-card.md").read_text(encoding="utf-8")
        self.assertIn("“也、再、又、第二”有没有着落", card)  # item 4: the sentence-level pass
        # item 6: reread every edit in place; r5.39 (the author's 10-24 list, point 4): with the paragraphs around it,
        # as the closing check of sentence-craft.md already said, not one sentence on each side
        self.assertIn("改完把改动句连同前后段再读一遍", card)


class ExampleFive(unittest.TestCase):
    def example(self):
        part = section(SENTENCES.read_text(encoding="utf-8"), SECTION)
        before = re.search(r"^改前：(.+)$", part, re.M).group(1)
        after = re.search(r"^改后：(.+)$", part, re.M).group(1)
        return part, before, after

    def test_the_example_changes_exactly_what_its_notes_discuss(self):
        part, before, after = self.example()
        # The four edits the notes explain, applied to the old text, give the new text; nothing else changed.
        edits = [("阿禾也蹲下来", "阿禾蹲下来"), ("盯着铜盘看", "盯着看"), ("对读数进行了核对", "核对了读数"),
                 ("在不碰玻璃的情况下用铅笔", "没碰玻璃，用铅笔")]
        text = before
        for old, new in edits:
            self.assertEqual(text.count(old), 1, old)
            text = text.replace(old, new)
        self.assertEqual(text, after)
        for quoted in ("“也”", "“铜盘”", "“对读数进行了核对”", "“在不碰玻璃的情况下”"):
            self.assertIn(quoted, part)
        # r5.13: unifying the name must not make the near repetition the same table warns about (a third 罗盘 in the
        # sentence after one that just said it); the notes say why the object is dropped instead.
        self.assertEqual(after.count("罗盘"), before.count("罗盘"))
        self.assertIn("近距重复", part.split("改后：", 1)[1])
        self.assertIn("再转到正北", after)  # the "再" the notes keep
        self.assertIn("“再转到正北”的“再”是“然后”", part)

    def test_the_example_stays_clean_for_the_punctuation_checker(self):
        _, before, after = self.example()
        lint = load("punctuation_lint")
        for text in (before, after):
            self.assertEqual([f["rule"] for f in lint.lint_text(text)["findings"] if f["severity"] == "ERROR"], [], text)


class NamingList(unittest.TestCase):
    """A name the project retired, written into the prose rules as the continuity module says, needs a decision."""

    TEXT = ("第三章　仓库\n\n阿禾把车厢门推开，里面堆着麻袋。\n\n老沈蹲在车厢板上数袋子，一共十二袋。\n\n"
            "“先搬靠门的。”他说。\n\n阿禾搬下第一袋，放在台阶上。\n\n袋子很沉，她换了一次手。\n\n"
            "最后一袋搬完，天已经黑了。\n")

    def run_guard(self, work, *args):
        proc = subprocess.run([sys.executable, "-I", "-B", str(NOVEL / "scripts" / "workflow_guard.py"), *map(str, args)],
                              cwd=work, capture_output=True, text=True, encoding="utf-8")
        try:
            return proc.returncode, json.loads(proc.stdout)
        except ValueError:
            return proc.returncode, {"raw": proc.stdout + proc.stderr}

    def review(self, work, items, decisions):
        text = (work / "draft.md").read_text(encoding="utf-8")
        lines = [line for line in text.splitlines() if line.strip()]
        body = text[text.index(lines[1]):]
        return {
            "schema": "editorial-review/2", "verdict": "PASS",
            "candidate_sha256": hashlib.sha256((work / "draft.md").read_bytes()).hexdigest(),
            "reviewer": {"mode": "self_check", "label": "测试数据：只验证结构"},
            "checked_against": ["测试数据：称谓表"], "inputs_read": ["prose-rules.json"],
            "evidence": [{"in": "candidate", "quote": q} for q in ("阿禾把车厢门推开", "阿禾搬下第一袋", "最后一袋搬完")],
            "issues": [], "counter_evidence": "测试数据，不是真实文学审稿。",
            "machine_dispositions": [{"id": key, "decision": decisions.get(key, "keep"),
                                      "reason": "测试数据：按称谓表逐处核对过"} for key in items if key in decisions],
            "dimensions": [{"id": key, "status": "met", "note": "测试数据：只验证结构"} for key in
                           ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function")]
                          + [{"id": key, "status": "not_applicable", "note": "测试数据：没有前文或旧版"}
                             for key in ("continuity", "revision_comparison")],
            "expression": {"scope": "chapter", "segments": [
                {"from": body[:6], "to": body.rstrip()[-6:], "note": "测试数据：逐句看过搭配、照应字和叫法"}],
                "decisions": []},
        }

    def test_a_retired_name_is_a_review_item_even_inside_a_longer_word(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            (work / "draft.md").write_bytes((self.TEXT).encode("utf-8"))
            (work / "prose-rules.json").write_bytes((json.dumps({"terms": [
                {"id": "叫法-车厢", "text": "车厢", "min_occurrences": 1}]}, ensure_ascii=False)).encode("utf-8"))
            (work / "checks.json").write_bytes((json.dumps({"candidate": "draft.md", "mode": "strict", "checks": [
                {"id": "prose", "type": "prose", "rules": "prose-rules.json"}]})).encode("utf-8"))
            self.assertEqual(self.run_guard(work, "start", "state.json", "--task-id", "naming", "--spec", "checks.json")[0], 0)
            code, checked = self.run_guard(work, "check", "checks.json")
            items = [item["id"] for item in checked["review_items"]]
            self.assertEqual(items, ["prose:叫法-车厢-L3-C4", "prose:叫法-车厢-L5-C5"])  # "车厢板" counts too
            (work / "review.json").write_bytes((json.dumps(self.review(work, items, {}), ensure_ascii=False)).encode("utf-8"))
            code, out = self.run_guard(work, "record", "state.json", "--event-id", "v1", "--review", "review.json")
            self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
            decisions = {items[0]: "keep", items[1]: "keep"}
            (work / "review.json").write_bytes((json.dumps(self.review(work, items, decisions), ensure_ascii=False)).encode("utf-8"))
            code, out = self.run_guard(work, "record", "state.json", "--event-id", "v2", "--review", "review.json")
            self.assertEqual(code, 0, out)
            code, status = self.run_guard(work, "status", "state.json")
            self.assertEqual(status["gate"]["editorial"], "PASS[self_check]", status.get("gate"))

    def test_the_language_section_is_not_a_built_in_banned_list(self):
        prose = load("prose_lint")
        text = ("他也蹲下来，再看了一眼。\n\n过了几息，她对读数进行了核对。\n\n"
                "在不碰玻璃的情况下，他记下了读数。\n\n两人在门口放下箱子，又放下提带。\n")
        self.assertEqual(prose.inspect_text(text)["status"], "NO_FLAGS")
        self.assertEqual(prose.inspect_text(text, {"terms": []})["status"], "NO_FLAGS")


if __name__ == "__main__":
    unittest.main()

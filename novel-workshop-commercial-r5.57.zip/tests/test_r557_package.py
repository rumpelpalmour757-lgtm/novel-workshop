#!/usr/bin/env python3
"""r5.57: the version is the same everywhere, and the release notes say what this release did.

r5.56 pinned its version in test_r556_package.py; from r5.57 on that file checks that the r5.56 entries stay in the
changelog and the verification notes as history, and the current version is pinned here, the same way.

The release notes are checked for what they must cover: the three things this release did (a format-only task is a
task of its own, fidelity conversion, with how it is checked and how the delivery is worded; what to do when the author
takes an acceptance back, with what the delivery gate cannot do yet; the number in the examples page's title), that
no script changed, how to upgrade from r5.56 and from earlier releases, and what was not verified. These tests only
check that the notes say so; they do not show that the workshop handles these tasks well, or that anything writes
better.
"""
import json
import os
from pathlib import Path
import re
import sys
import unittest

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
VERSION = "2026-11-15-r5.57"
TITLE = "小说写作工坊 r5.57"
PREVIOUS = "2026-11-14-r5.56"
PAGES = ("README.md", "QUICKSTART.md", "USAGE.md", "EXAMPLES.md", "skills/novel-workshop/SKILL.md")
README_LINE = ("版本：小说写作工坊 r5.57（`2026-11-15-r5.57`）。在 r5.56 上做三件事：只换格式、不动字句的算单独一类任务"
               "（保真转换），写明怎样核、交付怎样写；补上作者收回采纳时怎么办，照实写交付门现在的限制；改正使用示例标题里的条数。")
BOUND_SCRIPTS = ("`workflow_guard.py`", "`punctuation_lint.py`", "`prose_lint.py`", "`fact_guard.py`", "`project_state.py`")


def read(path):
    return (ROOT / path).read_text(encoding="utf-8")


def newest_entry(text):
    """The text of the first '## ' section of a changelog-like page, heading included."""
    parts = re.split(r"(?m)^(?=## )", text)
    return parts[1] if len(parts) > 1 else ""


def part(text, heading):
    """From a '### ' heading to the next '### ' heading ("" if the heading is missing)."""
    start = text.find("\n### " + heading)
    if start < 0:
        return ""
    end = text.find("\n### ", start + 1)
    return text[start:] if end < 0 else text[start:end]


def version_line(page):
    """The line of a page that states its version."""
    return next((line for line in read(page).splitlines() if "`" + VERSION + "`" in line), "")


class Version(unittest.TestCase):
    def test_the_version_is_the_same_everywhere(self):
        for page in PAGES:
            self.assertIn("`" + VERSION + "`", read(page), page)
        manifest = json.loads(read("PACKAGE-MANIFEST.json"))
        self.assertEqual(manifest["version"], VERSION)
        self.assertEqual(manifest["date"], "2026-11-15")
        self.assertTrue(newest_entry(read("VERIFICATION.md")).startswith("## " + VERSION + " 的验证"))
        self.assertTrue(newest_entry(read("CHANGELOG.md")).startswith("## %s（%s）" % (VERSION, TITLE)))

    def test_the_title_names_this_release_and_no_page_calls_it_a_candidate(self):
        for page in ("README.md", "skills/novel-workshop/SKILL.md"):
            self.assertIn(TITLE, version_line(page), page)
        for page in PAGES:
            line = version_line(page)
            self.assertNotIn("候选", line.split("`" + VERSION + "`")[0], page)  # what the page says this release is
            self.assertNotIn("`" + PREVIOUS + "`", line.split("。")[0], page)
        for page in ("CHANGELOG.md", "VERIFICATION.md"):
            heading = newest_entry(read(page)).splitlines()[0]
            self.assertNotIn("候选", heading, page)

    def test_the_readme_says_what_this_release_did(self):
        readme = read("README.md")
        self.assertIn("\n" + README_LINE + "\n", readme)
        current = next(p for p in re.split(r"(?m)^(?=## )", readme) if p.startswith("## 本版"))
        self.assertTrue(current.startswith("## 本版（r5.57）"), current[:40])
        for phrase in ("保真转换", "格式检查通过，文学质量未审", "收回采纳", "`workflow_guard.py`", "三十个可复制的使用示例",
                       "不说明写得更好"):
            self.assertIn(phrase, current, phrase)
        history = readme.split("## 历次版本", 1)[1].split("\n## ", 1)[0]
        self.assertIn("- **r5.56**：", history)  # the release before moves into the list, as r5.55 did
        self.assertLess(history.index("- **r5.56**："), history.index("- **r5.55**："))


class ReleaseNotes(unittest.TestCase):
    def setUp(self):
        self.entry = newest_entry(read("CHANGELOG.md"))
        self.assertTrue(self.entry.startswith("## %s（%s）" % (VERSION, TITLE)), self.entry[:60])

    def test_the_opening_says_where_it_comes_from_and_what_it_does_not_claim(self):
        opening = self.entry.split("\n### ", 1)[0]
        for phrase in ("在 r5.56", "BJM", "按编排方的想法来", "同一个模型（Claude）的新实例", "不是独立评审", "不说明写得更好",
                       "r5.56 的包原样留着"):
            self.assertIn(phrase, opening, phrase)

    def test_the_entry_says_what_changed(self):
        fidelity = part(self.entry, "一、")
        for phrase in ("`references/editing.md`", "“先定范围”", "保真转换", "不动标点", "`references/chinese-punctuation.md`",
                       "不扩大", "格式检查通过，文学质量未审", "`detail_check.py changes`", "`--keep`",
                       "`punctuation_lint.py --baseline`", "MECHANICAL", "`SKILL.md`", "`references/chapter-confirmation.md`",
                       "`references/author-preferences.md`", "`references/file-delivery.md`", "`assets/revision-card.md`",
                       "`workflow_guard.py accept --skip-review`", "`replan`"):
            self.assertIn(phrase, fidelity, phrase)
        withdrawal = part(self.entry, "二、")
        for phrase in ("`references/quality-loop.md`", "收回采纳", "`reopen`", "`final`", "`fact_guard.py impact`", "候选",
                       "`references/chapter-confirmation.md`", "`workflow_guard.py` 还没有收回采纳的命令", "没有改"):
            self.assertIn(phrase, withdrawal, phrase)
        skipped = part(self.entry, "三、")
        for phrase in ("`--deliverable`", "“说定本”", "BLOCK", "作者原话和出处"):
            self.assertIn(phrase, skipped, phrase)
        title = part(self.entry, "四、")
        for phrase in ("二十六个可复制的使用示例", "三十个可复制的使用示例", "`tests/test_r535_starter.py`"):
            self.assertIn(phrase, title, phrase)

    def test_the_entry_says_no_script_changed(self):
        tests = part(self.entry, "五、")
        for phrase in ("`tests/test_r557_rules.py`", "`tests/test_r557_package.py`", "`tests/test_r556_package.py`",
                       "`tests/test_r556_rules.py`", "`tests/test_r535_starter.py`", "逐字节相同", "没有改任何脚本") \
                + BOUND_SCRIPTS:
            self.assertIn(phrase, tests, phrase)

    def test_the_decisions_made_on_the_way_are_listed_and_can_be_changed(self):
        decided = part(self.entry, "这一版顺带定下的几处做法")
        for phrase in ("跳过审稿采纳", "章标题", "交付门卡", "5004", "L0、L1、L2", "要改"):
            self.assertIn(phrase, decided, phrase)

    def test_the_entry_says_how_to_upgrade(self):
        upgrade = part(self.entry, "怎样升级")
        for phrase in ("从 r5.56 升上来", "python install.py --upgrade --dry-run", "`assets/project-packs/`", "交付记录照旧",
                       "五个绑定脚本", "r5.56 一节"):
            self.assertIn(phrase, upgrade, phrase)

    def test_the_entry_and_the_verification_notes_say_what_was_not_verified(self):
        verification = newest_entry(read("VERIFICATION.md"))
        for text in (part(self.entry, "没有验证的"), part(verification, "没有验证的")):
            for phrase in ("同一个模型", "Word", "PDF", "原生 Windows", "macOS", "办得好不好", "不说明写得更好"):
                self.assertIn(phrase, text, phrase)

    def test_the_verification_notes_name_what_was_run(self):
        verification = newest_entry(read("VERIFICATION.md"))
        for phrase in ("python3 -I -B tests/run_tests.py", "`__pycache__`", "`tests/test_r557_rules.py`",
                       "`tests/test_r557_package.py`", "成对测试", "只作维护记录", "同一个模型", "升级和退回",
                       "`novel-workshop/assets/project-packs/_author/`", "私料核对"):
            self.assertIn(phrase, verification, phrase)
        pairs = part(verification, "成对测试")
        for phrase in ("30 次", "30/30", "18/18", "不说明"):
            self.assertIn(phrase, pairs, phrase)


if __name__ == "__main__":
    unittest.main()

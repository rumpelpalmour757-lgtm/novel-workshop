# Scene Beat Card (单场戏剧节拍卡)

落笔前填（[分场戏剧张力与正文具象化](../references/scene-dramaturgy.md)）。一章几场，就把下面从 `Scene ID` 起的一块复制几份，写在同一个文件里；过场（Transition）只填 Scene ID 和 Scene Type。其他场（Other：轻松的兑现、关系靠近、哀伤停留、探索奇观）填 Scene ID、Scene Type、POV 和 Change（这一场让关系、认知、行动准备或体验积累变了什么），不填四拍（宪法 CON-011，NWC-1.5）。核心博弈戏每一栏都要填，动作危机戏除道具一栏外都要填；Polarity Shift 写成“[开场处境] -> [收场处境]”，两边不能一样，也不能写“无变化”。检查清单里用 `scene_beats` 声明这个文件，交付门会核对填没填全；卡不交给作者，不附在正文后。

- **Scene ID / Chapter**: 
- **Scene Type**: `[Core Conflict (核心博弈戏) | Action/Crisis (动作危机戏) | Other (其他场：兑现/靠近/停留/探索) | Transition (过场桥段-限200字)]`
- **POV Character & Sensory Limit (视角人物与感知盲区)**: 
- **Change (这一场变了什么)**: *(其他场必填：关系、认知、行动准备或体验积累，从什么到什么，不能写无变化；对手戏不填，看 Polarity Shift)*
- **Polarity Shift (局势极性变化)**: `[  ] -> [  ]` *(例：胜券在握 -> 被抓把柄，禁止填无变化)*
- **Core Prop Anchor (核心交互道具)**: *(本场用于承载情绪/动作的 1~2 个具体物理物品)*

## Four-Step Beat Map (四步博弈节拍)
1. **入场动作与诉求 (Goal - Late In)**: 
2. **对手反制与阻碍 (Obstacle & Escalation)**: 
3. **破局点/意外转折 (The Turn)**: 
4. **出场悬念钩子 (Exit Hook - Early Out)**: 

## Anti-Summary Redlines (本场禁写红线)
- **禁止直接概括的过程**: *(指明哪段交锋必须逐帧展开动作与感官，不准一笔带过)*
- **潜台词冰山 (Subtext)**: *(表面在聊什么 vs 实际在争夺什么)*
- **情绪生理化映射 (Embodiment)**: *(指明本场核心情绪通过什么具体微动作/道具操作来替代形容词)*

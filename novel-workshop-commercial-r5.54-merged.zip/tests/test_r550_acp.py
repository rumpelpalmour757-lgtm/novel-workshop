"""r5.50：Google AI（官方 ACP 运行时）改了设置、或者重新检查出程序不对时，旧连接不能再发送；四件事分开看。

作者在 r5.49 上用包里的模拟程序复现过：连着的时候存一个错的校验值、点“检查运行时”说校验不符，页面照样能发，
旧进程又收到一次合成示例、交回了完整结果；存错校验值也没有马上清掉“已真实接通”。

行为检查在同目录的 acp_check.mjs（名字以 R550- 开头的几条），走页面用的 HTTP 路由（同源请求头、页面令牌），
对着 fixtures/fake_acp_agent.mjs（工坊自己写的模拟 ACP 程序，不是 Google 的）数它收到的 session/prompt：
- 存错校验值 → 旧连接作废、“已真实接通”清掉；检查报校验不符；新预览、旧预览、不带预览的选段都发不出去，收到 0 次；
- 没改设置、重新检查发现程序变了或找不到 → 同样作废；
- 先预览再改设置：存一样的值什么也不变，真的换了路径就作废；
- 准备发送的那一会儿点停止、断开：马上能点，记成没有发出，本机不留“已发出”；检查、改设置插不进来；
- acp.json 在别处被改、作废落在写“已发出”的那一下：发出前的核对发现，没有发出；
- 已经发出的一轮再检查出校验不符：按停止的老规矩了结、不自动重发，迟到的结果不能把“已真实接通”找回来；
- 重启以后旧的“已真实接通”只当历史；来源没核对的最多只算协议结果；模拟程序处处标模拟；程序文件和 zip 的校验值分开写。
锁的“进程号被别的程序用上了”要读 /proc：看不到 /proc 的机器上那一条记成“跳过”并写明原因。这里另外查这条路子
（用 NOVEL_WORKSHOP_TEST_HIDE_PROC=1 模拟），以及页面、说明里能静态查的部分。没有 Node.js 18+ 时跳过。
"""
import os
import re
import shutil
import subprocess
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILL = HERE.parent / "skills" / "novel-workshop"
FOLDER = SKILL / "scripts" / "oh-story"
DASHBOARD = SKILL / "assets" / "dashboard"
NODE = shutil.which("node")


def node_major():
    try:
        out = subprocess.run([NODE, "--version"], capture_output=True, text=True, encoding="utf-8", timeout=30).stdout
        return int(re.match(r"v(\d+)", out).group(1))
    except Exception:  # noqa: BLE001
        return 0


def google_ai_section():
    doc = (SKILL / "references" / "local-workbench.md").read_text(encoding="utf-8")
    start = doc.index("## 可选：Google AI（官方 ACP 运行时）")
    end = doc.index("\n## ", start + 1)
    return doc[start:end]


@unittest.skipUnless(NODE and node_major() >= 18, "需要 Node.js 18 或更新版本")
class SkipIsVisible(unittest.TestCase):
    def test_hidden_proc_turns_one_case_into_a_visible_skip(self):
        env = {**os.environ, "NOVEL_WORKSHOP_TEST_HIDE_PROC": "1", "NOVEL_WORKSHOP_TEST_ONLY": "锁|REG-3"}
        proc = subprocess.run([NODE, str(HERE / "acp_check.mjs"), str(SKILL)], env=env,
                              capture_output=True, text=True, encoding="utf-8", timeout=300)
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        summary = re.search(r"^(\d+) passed, (\d+) skipped, (\d+) failed \((\d+) total\)$", proc.stdout, re.M)
        self.assertIsNotNone(summary, proc.stdout)
        passed, skipped, failed, total = (int(value) for value in summary.groups())
        # 进程号复用那一条跳过，并写明原因；锁的其他判断（开机时间、两分钟没续、两个同时接手、心跳、丢锁）照常通过。
        self.assertEqual((skipped, failed), (1, 0), proc.stdout)
        self.assertGreaterEqual(passed, 2, proc.stdout)
        self.assertEqual(passed + skipped, total)
        self.assertRegex(proc.stdout, r"(?m)^SKIP REG-3 进程号复用")
        self.assertRegex(proc.stdout, r"(?m)^原因：看不到 /proc/\d+/stat 或 /proc/stat（ENOENT）（这一次是用 NOVEL_WORKSHOP_TEST_HIDE_PROC=1 模拟的）")
        self.assertRegex(proc.stdout, r"(?m)^ok FIX-BJM13-RT-03/REG-6 锁：")


class Provider(unittest.TestCase):
    def test_send_path_checks_the_connection_right_before_session_prompt(self):
        text = (FOLDER / "acp-assist.mjs").read_text(encoding="utf-8")
        journal = text.index('event: "sent",')
        reread = text.index("settingsAfter = await this.settings();")
        guard = text.index("const sameRecipient = JSON.stringify(this.runtimeBinding()) === JSON.stringify(binding.runtime);")
        send = text.index("this.runPrompt(task, conn, session, prepared.blocks);")
        # 写完“已发出”以后再读一次本机设置，然后在同一段里和连接、停止、作废、收件方一起核对，再发出。
        self.assertLess(journal, reread)
        self.assertLess(reread, guard)
        self.assertLess(guard, send)
        self.assertIn("if (task.cancelRequested || conn !== this.conn || conn.closed || conn.revoked || !sameRecipient || drift.length) {", text)
        # 核对通过以后到发出之间没有 await（核对不通过的那一支记下“没有发出”就抛出，不往下走）。
        self.assertNotIn("await", text[text.index("session.used = true;", guard):send])
        self.assertIn('if (problem) await this.invalidateFor("check_failed", problem);', text)
        self.assertIn('if (changes.length) await this.invalidateFor("config_changed", `你改了${changes.join("、")}`);', text)

    def test_real_mark_needs_a_verified_source_and_this_connection(self):
        text = (FOLDER / "acp-assist.mjs").read_text(encoding="utf-8")
        for needle in ("if (!mark.sourceVerified) {", 'if (handshake.simulated) why.push(', "if (!current) why.push(",
                       "real.connectionId && real.connectionId === this.handshake.connectionId",
                       'runtime.hashOf !== "windows-shim"', "const real = genuineReal(record.real) ? record.real : null;"):
            self.assertIn(needle, text)


class Page(unittest.TestCase):
    def test_send_buttons_follow_the_server_and_four_states_are_shown(self):
        app = (DASHBOARD / "app.js").read_text(encoding="utf-8")
        for needle in ("const canSend = Boolean(status?.canSend);",
                       "elements.acpSelftest.disabled = busy || active || !connected || !canSend;",
                       "elements.acpSendSelection.disabled = busy || active || !connected || !canSend || !selectionReady;",
                       "!state.acp.status?.canSend;",
                       "function renderAcpVerification(status)"):
            self.assertIn(needle, app)
        html = (DASHBOARD / "index.html").read_text(encoding="utf-8")
        self.assertIn('id="acpVerification"', html)


class Docs(unittest.TestCase):
    def test_google_ai_section_explains_invalidation_and_the_four_states(self):
        section = google_ai_section()
        for fact in ("### 改了设置，或者检查出程序不对：旧连接作废", "**程序来源核对过**", "最多只算“协议结果”",
                     "侧栏里四件事分开显示", "都标成“模拟”", "压缩包的，解压前用 `--zip` 核对",
                     "停止和断开一直能点", "跳过 1 条",
                     # 第二轮复查：旧记录、.cmd 启动脚本、模拟程序怎么认出来、什么时候查。
                     "以前接通过（旧规则，来源未核对）", "工坊认“模拟”只靠这个自报标记", "`simulatedMarker: false`",
                     "对得上也只算协议结果", "工坊不盯着文件", "发送的时候查两次"):
            self.assertIn(fact, section)


if __name__ == "__main__":
    unittest.main()

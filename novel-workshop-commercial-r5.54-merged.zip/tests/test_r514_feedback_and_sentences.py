#!/usr/bin/env python3
"""r5.14: the sentence problems and outside-feedback habits a chapter 10-to-4 back-check found missing.

The 2026-10-19 back-check the author forwarded (chapters 10 back to 4 of the author's project, all revised with the
r5.10 scripts) and two self-check lists the author uses found four kinds of trouble that r5.12's language-sense section
did not name, or named only for edits: two sets of connectives welded into one sentence so that a negation turns
around; a pronoun that slides to the nearest name, or a line of dialogue nobody can be heard saying; a word or a run of
characters with two readings; an object used as if already introduced, or a group described before its last member
came in. Just as often the outside feedback itself was wrong: two different objects treated as one because their names
were alike, a compound noun split the wrong way and an action added to "fix" it, a setting inferred from one detail,
the same old item reported again and again after the text had changed. Revisions also slipped new facts in under the
name of smoother wording.

These tests pin what can be pinned without judging prose:
- the language-sense table has the new kinds, in the order "can it be read at all" before "is it even", with the
  checks and the do-not-do column the modules rely on;
- the working notes sort every edit by what it changes, and sort outside feedback against the current text before
  anything else; the original sixth example keeps two objects apart, expands a compound noun without adding an action
  and does not redo an old item;
- the modules that route here (L1, the revision comparison, the regression check, the project template, the delivery
  card, the gate's documentation) say the same, and the card's must-read list names every section the level rows of
  SKILL.md name (it had lost two since r5.11);
- the gate already supports the recording the documentation suggests: an outside item whose quote is not in the
  current text is refused (it was written for an older version), and an item still in the text after the revision
  needs a decision before PASS.
All material is invented for these tests; reviews are labelled test data and are not literary judgments.
"""

import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
NOVEL = ROOT / "skills" / "novel-workshop"
GUARD = NOVEL / "scripts" / "workflow_guard.py"
SECTION = "语感：搭配、照应与叫法"
KINDS = ["搭配", "句式杂糅与否定", "指代与说话人", "歧义与切分", "语序与修饰归属",
         "照应与着落", "叫法", "量词与尺度", "赘余与近距重复", "翻译腔、书面腔"]
DIMENSIONS = ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function", "continuity",
              "revision_comparison")


def read(relative):
    return (NOVEL / relative).read_text(encoding="utf-8")


def section(text, title):
    start = text.index("## " + title)
    end = text.find("\n## ", start + 3)
    return text[start:end if end != -1 else len(text)]


def language_section():
    return section(read("references/sentence-craft.md"), SECTION)


def rows():
    """The language-sense table: {kind: (how to check, smallest fix, do not)}."""
    found = {}
    for line in language_section().splitlines():
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) == 4 and cells[0] not in ("类别", "---"):
            found[cells[0]] = tuple(cells[1:])
    return found


class SentenceKinds(unittest.TestCase):
    def test_the_table_lists_ten_kinds_reading_problems_first(self):
        self.assertEqual(list(rows()), KINDS)
        intro = language_section().split("|", 1)[0]
        self.assertIn("先查前五类，再查后五类", intro)
        self.assertIn("一整句话连同前后句", intro)  # the unit of the check is the sentence, not a hit word
        self.assertIn("不是禁词表", intro)

    def test_each_new_kind_says_how_to_check_and_what_not_to_do(self):
        table = rows()
        check, fix, avoid = table["句式杂糅与否定"]
        self.assertIn("两套关联词", check)
        self.assertIn("也不能算屋里没人", fix)
        self.assertIn("判断说反", avoid)  # the fix must keep what the sentence claimed
        check, fix, avoid = table["指代与说话人"]
        self.assertIn("往前数", check)
        self.assertIn("单独成段", check)
        self.assertIn("“开始。”", avoid)  # an omission the context already settles stays
        check, fix, avoid = table["歧义与切分"]
        self.assertIn("“原来”", check)
        self.assertIn("乒乓球的球拍卖完了", fix)
        self.assertIn("昨天就卖完了", avoid)  # disambiguating does not add what the text does not say
        check, fix, avoid = table["照应与着落"]
        self.assertIn("第三个人", check)
        self.assertIn("“外层”", avoid)  # a qualifier that does point back is information
        check, fix, avoid = table["叫法"]
        self.assertIn("谁的、在哪、做什么用", check)
        self.assertIn("名字像就并成一件", avoid)
        check, fix, avoid = table["赘余与近距重复"]
        self.assertIn("同一个动作做两遍", check)


class WorkingNotes(unittest.TestCase):
    def notes(self):
        part = language_section()
        return part[part.index("几条做法："):part.index("**例五")]

    def test_every_edit_is_sorted_by_what_it_changes(self):
        notes = self.notes()
        for kind in ("**纯表达**", "**消歧**", "**补信息**", "**改状态**"):
            self.assertIn(kind, notes)
        self.assertIn("后两类要有依据", notes)
        self.assertIn("称谓表按东西记", notes)

    def test_outside_feedback_is_checked_against_the_current_text_first(self):
        notes = self.notes()
        self.assertIn("先在手上这一版里找", notes)
        self.assertIn("所审旧版", notes)
        self.assertIn("采纳、部分采纳、保留、待核", notes)
        for misreading in ("把名字相近的两件东西当成一件", "把复合名词拆错", "凭一个细节推出新设定", "照抄意见里写错的人名"):
            self.assertIn(misreading, notes)
        self.assertIn("[执行检查](execution.md)“外部意见的记录”", notes)

    def test_example_six_keeps_two_objects_apart_and_does_not_redo_an_old_item(self):
        part = language_section()
        example = part[part.index("**例六"):]
        items = re.split(r"\n\n(?=意见[一二三]：)", example)[1:]
        self.assertEqual(len(items), 3, example)
        kept, partial, stale = items
        self.assertIn("处置：保留", kept)
        self.assertIn("两件", kept)
        self.assertIn("处置：部分采纳", partial)
        new_sentence = re.search(r"“(柜台说乒乓球的球拍卖完了[^”]*)”", partial).group(1)
        self.assertNotIn("昨天", new_sentence)  # only the noun is spelled out; nothing is added
        self.assertIn("处置：所审旧版", stale)
        self.assertIn("不报成", stale)  # an old item is neither redone nor reported as a new fix


class Wiring(unittest.TestCase):
    def test_the_modules_that_route_here_say_the_same(self):
        skill = read("SKILL.md")
        routing = next(line for line in skill.splitlines()
                       if "| [sentence-craft.md](references/sentence-craft.md) |" in line)
        self.assertIn("指代", routing)
        self.assertIn("翻译腔", routing)
        comparison = section(read("references/editing.md"), "修订前后对照")
        self.assertIn("先在当前稿里找到意见引的原句", comparison)
        self.assertIn("补信息、改状态", comparison)
        regression = section(read("references/continuity.md"), "修订后的回归核对")
        self.assertIn("名字像不等于同一件", regression)
        self.assertIn("谁的、在哪、做什么用", read("assets/project-template.md"))
        self.assertIn("先在当前稿里找到", read("assets/delivery-gate-card.md"))
        execution = read("references/execution.md")
        paragraph = execution[execution.index("**外部意见的记录"):]
        paragraph = paragraph[:paragraph.index("\n\n")]
        for word in ("EVIDENCE_NOT_FOUND", "ISSUE_UNRESOLVED", "所审旧版", "`keep`"):
            self.assertIn(word, paragraph)

    def test_the_card_names_every_section_the_level_rows_name(self):
        # A chat-only environment may keep nothing but the card in view. Its must-read list had fallen behind the
        # level rows of SKILL.md: r5.11's expression record and r5.12's language section were missing until r5.14.
        wanted = set()
        for line in read("SKILL.md").splitlines():
            if line.startswith(("| L1 ", "| L2 ")):
                wanted.update(re.findall(r"“([^”]+)”", line.split("|")[3]))
        item = next(line for line in read("assets/delivery-gate-card.md").splitlines() if line.startswith("1. **先分级。**"))
        self.assertGreater(len(wanted), 10)
        self.assertEqual(sorted(name for name in wanted if "“%s”" % name not in item), [])


TEXT_LINES = [
    "第三章　雨夜",
    "雨下到半夜，巷子里只剩檐水的声音。阿宁把借来的雨披挂在门后，自己的旧雨衣还压在箱底。",
    "孟叔扶着梯子，小林爬上去拧下灯罩，把旧灯泡递下来。",
    "柜台说乒乓球拍卖完了，她在本子上记了一笔。",
    "天亮以后，阿宁把雨披叠好，准备还给隔壁的周婶。",
]
TEXT = "\n\n".join(TEXT_LINES) + "\n"
SEGMENTS = [{"from": "雨下到半夜", "to": "旧灯泡递下来。", "note": "测试数据：从“雨下到半夜”起前两段逐句连读"},
            {"from": "柜台说乒乓球拍", "to": "还给隔壁的周婶。", "note": "测试数据：从“柜台说乒乓球拍”起后两段逐句连读"}]


class FeedbackAsIssues(unittest.TestCase):
    """Outside feedback written as review issues: the gate tells current items from old ones and tracks them."""

    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        self.write("draft.md", TEXT)
        self.write("checks.json", json.dumps({"candidate": "draft.md", "mode": "strict", "checks": [
            {"id": "length", "type": "length", "min": 50}]}))
        code, out = self.guard("start", "run.json", "--task-id", "feedback", "--spec", "checks.json")
        self.assertEqual(code, 0, out)

    def tearDown(self):
        shutil.rmtree(self.dir)

    def write(self, name, text):
        (self.dir / name).write_bytes((text).encode("utf-8"))

    def guard(self, *args):
        proc = subprocess.run([sys.executable, "-I", "-B", str(GUARD), *args], cwd=self.dir, capture_output=True,
                              text=True, encoding="utf-8")
        try:
            return proc.returncode, json.loads(proc.stdout)
        except ValueError:
            return proc.returncode, {"raw": proc.stdout[-400:], "stderr": proc.stderr[-400:]}

    def record(self, event, verdict, issues=(), decisions=(), segments=SEGMENTS):
        text = (self.dir / "draft.md").read_text(encoding="utf-8")
        value = {"schema": "editorial-review/2", "verdict": verdict,
                 "candidate_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                 "reviewer": {"mode": "self_check", "label": "测试数据：只验证记录结构"},
                 "checked_against": ["测试数据：外部意见三条"], "inputs_read": [],
                 "evidence": [{"quote": q, "in": "candidate"}
                              for q in ("只剩檐水的声音", "把旧灯泡递下来", "准备还给隔壁的周婶")],
                 "issues": list(issues), "machine_dispositions": [], "counter_evidence": "测试数据，不是真实文学审稿。",
                 "dimensions": [{"id": key, "status": "met", "note": "测试数据：只验证记录结构"} for key in DIMENSIONS]}
        if verdict == "PASS":
            value["expression"] = {"scope": "chapter", "segments": list(segments), "decisions": list(decisions)}
        name = event + ".json"
        self.write(name, json.dumps(value, ensure_ascii=False))
        return self.guard("record", "run.json", "--event-id", event, "--review", name)

    def test_old_items_are_refused_and_current_ones_need_a_decision(self):
        two_objects = {"quote": "借来的雨披挂在门后", "expected": "外部意见：雨披和雨衣统一成雨披",
                       "impact": "外部意见一；核对后是两件，打算保留"}
        compound = {"quote": "乒乓球拍卖完了", "expected": "外部意见：改成“乒乓球拍昨天就卖完了”",
                    "impact": "外部意见二；只把名词说全，不加昨天"}
        stale = {"quote": "从绿门出去", "expected": "外部意见：绿门统一成侧门", "impact": "外部意见三"}
        code, out = self.record("v1", "NEEDS_REVISION", [two_objects, compound, stale])
        self.assertEqual((code, out.get("failure")), (2, "EVIDENCE_NOT_FOUND"), out)  # written for an older version
        self.assertIn("从绿门出去", out["message"])
        code, out = self.record("v1b", "NEEDS_REVISION", [two_objects, compound])
        self.assertEqual(code, 0, out)
        self.assertEqual(self.guard("reserve", "run.json", "--event-id", "r1")[0], 0)
        self.write("draft.md", TEXT.replace("乒乓球拍卖完了", "乒乓球的球拍卖完了"))
        segments = [SEGMENTS[0], dict(SEGMENTS[1], **{"from": "柜台说乒乓球的"})]
        change = {"decision": "change", "before": "乒乓球拍卖完了", "after": "乒乓球的球拍卖完了",
                  "judgment": "消歧：两种切法都读得通", "reason": "只把名词说全，原文没有昨天"}
        code, out = self.record("v2", "PASS", decisions=[change], segments=segments)
        self.assertEqual((code, out.get("failure")), (2, "ISSUE_UNRESOLVED"), out)  # the raincoat item is still there
        self.assertIn("借来的雨披挂在门后", out["message"])
        keep = {"decision": "keep", "quote": "借来的雨披挂在门后", "judgment": "借来的雨披和自己的旧雨衣是两件",
                "reason": "后文要还雨披，雨衣另有去处；照改会把归还对象改错"}
        code, out = self.record("v3", "PASS", decisions=[change, keep], segments=segments)
        self.assertEqual(code, 0, out)
        code, status = self.guard("status", "run.json")
        self.assertEqual(status["gate"]["editorial"], "PASS[self_check]")


if __name__ == "__main__":
    unittest.main()

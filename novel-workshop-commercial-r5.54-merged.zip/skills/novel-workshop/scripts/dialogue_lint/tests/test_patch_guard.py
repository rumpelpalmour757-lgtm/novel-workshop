"""Independent patch-boundary tests: untrusted model output cannot edit narration."""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import copy
import unittest

from dialogue_core import extract_dialogues
from patch_guard import apply_dialogue_patch, build_patch_request


class DialoguePatchGuardTests(unittest.TestCase):
    def setUp(self):
        self.paragraphs = ["林舟说：“等等。”他合上书。\r\n", "", "沈砚说：“好。”\r\n"]
        self.spans = extract_dialogues(self.paragraphs, names=("林舟", "沈砚"))
        self.issues = [self.issue(span) for span in self.spans]
        self.request = build_patch_request(self.paragraphs, self.issues)

    @staticmethod
    def issue(span, **updates):
        result = {
            "quote_id": span.quote_id,
            "para_index": span.para_index,
            "quote_index": span.quote_index,
            "start": span.start,
            "end": span.end,
            "source_quote": span.text,
            "speaker": span.speaker,
            "confidence": span.confidence,
            "rule_id": "TEST_REVIEW",
            "message": "请结合上下文复核。",
        }
        result.update(updates)
        return result

    def response(self, *, replacements=None):
        if replacements is None:
            first = self.request["items"][0]
            replacements = [{"quote_id": first["quote_id"], "original": first["original"], "replacement": "稍等。"}]
        return {"source_hash": self.request["source_hash"], "replacements": replacements}

    def test_request_groups_same_quote_issues_and_excludes_uncertain_attribution(self):
        issues = [
            self.issue(self.spans[0], rule_id="RULE_A"),
            self.issue(self.spans[0], rule_id="RULE_B"),
            self.issue(self.spans[1], confidence="inferred"),
            self.issue(self.spans[1], confidence="unknown", speaker="未知"),
        ]
        request = build_patch_request(self.paragraphs, issues)
        self.assertEqual(len(request["items"]), 1)
        item = request["items"][0]
        self.assertEqual(item["quote_id"], "p1:q1")
        self.assertEqual(item["original"], "等等。")
        self.assertEqual(len(item["issues"]), 2)
        self.assertIn("schema_version", request)
        self.assertIn("response_schema", request)

    def test_changed_source_or_wrong_response_hash_is_rejected(self):
        changed = self.paragraphs.copy()
        changed[0] = changed[0].replace("合上书", "放下书")
        bad_response = self.response()
        bad_response["source_hash"] = "wrong-source-version"
        for paragraphs, response in ((changed, self.response()), (self.paragraphs, bad_response)):
            with self.subTest(paragraphs=paragraphs, response=response):
                with self.assertRaises(ValueError):
                    apply_dialogue_patch(paragraphs, self.request, response)

    def test_response_rejects_duplicate_unknown_ids_extra_fields_and_wrong_original(self):
        base = self.response()
        duplicate = copy.deepcopy(base)
        duplicate["replacements"].append(copy.deepcopy(duplicate["replacements"][0]))
        unknown = copy.deepcopy(base)
        unknown["replacements"][0]["quote_id"] = "p999:q999"
        outer_extra = copy.deepcopy(base)
        outer_extra["notes"] = "不应接受额外字段"
        entry_extra = copy.deepcopy(base)
        entry_extra["replacements"][0]["paragraph"] = "不应修改旁白"
        wrong_original = copy.deepcopy(base)
        wrong_original["replacements"][0]["original"] = "不是原台词"
        missing = copy.deepcopy(base)
        del missing["replacements"][0]["original"]
        for label, response in (
            ("duplicate", duplicate), ("unknown", unknown), ("outer_extra", outer_extra),
            ("entry_extra", entry_extra), ("wrong_original", wrong_original), ("missing", missing),
        ):
            with self.subTest(case=label):
                with self.assertRaises(ValueError):
                    apply_dialogue_patch(self.paragraphs, self.request, response)

    def test_replacement_cannot_introduce_chinese_double_quotes_or_newlines(self):
        for replacement in ("“新台词”", "左“右", "左”右", "第一行\n第二行", "第一行\r第二行", "第一行\r\n第二行"):
            with self.subTest(replacement=replacement):
                response = self.response()
                response["replacements"][0]["replacement"] = replacement
                with self.assertRaises(ValueError):
                    apply_dialogue_patch(self.paragraphs, self.request, response)

    def test_slice_application_preserves_narration_blank_lines_and_crlf(self):
        replacements = [
            {"quote_id": "p1:q1", "original": "等等。", "replacement": "稍等一下，先别走。"},
            {"quote_id": "p3:q1", "original": "好。", "replacement": "嗯。"},
        ]
        result = apply_dialogue_patch(self.paragraphs, self.request, self.response(replacements=replacements))
        self.assertEqual(result, ["林舟说：“稍等一下，先别走。”他合上书。\r\n", "", "沈砚说：“嗯。”\r\n"])
        self.assertEqual(self.paragraphs, ["林舟说：“等等。”他合上书。\r\n", "", "沈砚说：“好。”\r\n"])

    def test_forged_request_cannot_relabel_narration_as_quoted_text(self):
        request = copy.deepcopy(self.request)
        item = request["items"][0]
        narration = "他合上书。"
        item["start"] = self.paragraphs[0].index(narration)
        item["end"] = item["start"] + len(narration)
        item["original"] = narration
        response = {"source_hash": request["source_hash"], "replacements": [{
            "quote_id": item["quote_id"], "original": narration, "replacement": "他拔出刀。",
        }]}
        with self.assertRaises(ValueError):
            apply_dialogue_patch(self.paragraphs, request, response)

    def test_empty_and_partial_responses_are_valid(self):
        self.assertEqual(
            apply_dialogue_patch(self.paragraphs, self.request, self.response(replacements=[])),
            self.paragraphs,
        )
        second = {"quote_id": "p3:q1", "original": "好。", "replacement": "行。"}
        result = apply_dialogue_patch(self.paragraphs, self.request, self.response(replacements=[second]))
        self.assertEqual(result[0], self.paragraphs[0])
        self.assertEqual(result[1], "")
        self.assertEqual(result[2], "沈砚说：“行。”\r\n")


if __name__ == "__main__":
    unittest.main()

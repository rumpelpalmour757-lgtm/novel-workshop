#!/usr/bin/env python3
"""r5.56: what the pages say about the author's correction records and the default teacher.

The author decided on 11-14 (r5.56): the author's correction records (作者改法累计) live in the skill folder again, under
assets/project-packs/_author/ (correction-register.md, the single author-level authority, and correction-history.md),
and travel with the package; the commercial package itself ships none of those files, the workshop makes them in the
user's own skill folder when the author turns the module on. r5.55's decision to keep them outside the skill folder is
void, so its sentences ("不放进技能目录", "作者档案所在的地方", "升级安装不动它", "升级以前先把它移到作者档案那里")
are gone from the rule pages, the entry and the usage pages; a record kept where r5.55 said is moved back only after
asking the author. The author also said which teacher he uses: gemini-4-argon with the thinking level set to high. The
pages write it as the default teacher setting, which can be changed (an author or book profile naming another teacher,
or what the author says this time, wins); teacher_name says it was filled in by default; returns already registered are
not changed; nothing claims it writes better.

The installer and exporter behaviour these pages describe is tested in test_r556_author_records.py. These tests only
check the wording and that the claims about the workbench code still hold. They do not show that the records help or
that the default teacher is a good choice.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
FOLDER = "assets/project-packs/_author/"
REGISTER, HISTORY = "correction-register.md", "correction-history.md"
OLD = ("不放进技能目录", "作者档案所在的地方", "升级安装不动它", "升级不会动它", "先把它移到作者档案那里",
       "不在技能目录里，升级", "不动作者档案", "作者档案放在作者档案自己的地方")
DEFAULT_NAME = "gemini-4-argon（思考等级：高）；照默认填，这一份作者没另说"


def read(path):
    return path.read_text(encoding="utf-8")


def page(rel):
    return read(SKILL / rel)


def section(text, heading, level="## "):
    """From the heading to the next heading of the same or a higher level; headings inside ``` fences do not count
    (the blank record formats on the author-preferences page have their own headings)."""
    lines, fenced, start, depth = text.split("\n"), False, None, len(level) - 1
    for i, line in enumerate(lines):
        if line.startswith("```"):
            fenced = not fenced
            continue
        if fenced or not line.startswith("#"):
            continue
        marks = len(line) - len(line.lstrip("#"))
        if start is None and line.startswith(level + heading):
            start = i
        elif start is not None and marks <= depth and line[marks:marks + 1] == " ":
            return "\n".join(lines[start:i])
    if start is None:
        raise AssertionError("missing section: " + heading)
    return "\n".join(lines[start:])


def without_version_notes(text):
    """README without its "本版" and "历次版本" sections: those describe what each release did, r5.55 included."""
    kept = []
    for part in re.split(r"(?m)^(?=## )", text):
        if not part.startswith(("## 本版", "## 历次版本")):
            kept.append(part)
    return "".join(kept)


class TheRecordsLiveInTheSkillFolder(unittest.TestCase):
    def setUp(self):
        self.text = page("references/author-preferences.md")
        self.module = section(self.text, "作者改法累计")

    def test_one_place_two_files_one_authority(self):
        single = section(self.module, "单一记录与开启", "### ")
        for phrase in ("作者改法累计放在技能目录下的 `" + FOLDER + "`",
                       "有效规则摘要 `" + REGISTER + "`，是改法累计唯一的作者级权威",
                       "详细证据与变更历史 `" + HISTORY + "`",
                       "这份记录跟着技能包走：技能包装在哪、带到哪，它就在哪",
                       "不在作者档案、作品目录或宿主的记忆里另存一份当权威",
                       "同一条不在两处各存一份"):
            self.assertIn(phrase, single)

    def test_the_commercial_package_ships_none_of_them(self):
        single = section(self.module, "单一记录与开启", "### ")
        self.assertIn("工坊的商业交付版本身不带 `_author/` 里的任何文件", single)
        self.assertIn("作者开了累计以后，工坊才在作者自己装着的技能目录里建这两份", single)
        self.assertIn("不会拿包里的空白文件盖掉作者已经记下的", single)
        # and it is true of this package: nothing under assets/project-packs/ is listed or present. A personal build
        # carries the author's own records there, so the check is for the commercial package only.
        manifest = json.loads(read(ROOT / "PACKAGE-MANIFEST.json"))
        if "商业交付版" not in manifest.get("product", ""):
            self.skipTest("only the commercial package ships nothing under assets/project-packs/")
        self.assertEqual([f for f in manifest["files"] if "/assets/project-packs/" in f], [])
        self.assertFalse((SKILL / "assets" / "project-packs").exists())
        self.assertEqual(sorted(p.name for p in SKILL.rglob("*correction-*")), [])

    def test_the_blank_files_are_given_on_the_page_not_as_a_packaged_file(self):
        blank = section(self.module, "开启时建的两份文件", "### ")
        for phrase in ("# 作者改法累计：有效规则摘要", "开启状态：", "授权原话和日期：", "修订号：1", "## 已确认", "## 待确认",
                       "# 作者改法累计：详细证据与变更历史", "只往后加，不改写、不删除旧条目。", "## 证据", "## 变更",
                       "状态：已确认／待确认／冲突／已替代／已撤销", "（待确认的写：由哪一处改法归纳，作者还没看过措辞）",
                       "不往 `assets/project-packs/` 里加 `index.md` 或别的文件"):
            self.assertIn(phrase, blank)
        # the fields every entry must have, as the page lists them, are all in the entry format
        for field in ("问题与原则", "触发条件", "例外或不适用范围", "来源证据编号", "确认依据和日期", "替代关系"):
            self.assertIn(field + "：", blank)
        # no template file: a blank one under assets/project-packs/ would overwrite a user's records on an upgrade
        self.assertEqual([p for p in SKILL.rglob("*correction-*") if "project-packs" not in p.parts], [])

    def test_an_existing_record_is_used_not_rebuilt(self):
        self.assertIn("已经有的（升级时带过来的、作者自己放进来的）照用，不重建、不清空", self.module)

    def test_upgrade_rollback_upload_and_export(self):
        part = section(self.module, "升级、退回、换包和导出", "### ")
        for phrase in ("`install.py --upgrade`", "逐个核 SHA-256", "`--keep installed`", "`--keep package`", "`--dry-run`",
                       "备份里那份只是升级那一刻的快照",
                       "用 r5.55 或更早的包退回，那时的安装器不带这份记录",
                       "`<安装位置>/.novel-workshop-backups/<时间>/novel-workshop/assets/project-packs/`",
                       "把旧包里的 `skills/novel-workshop/assets/project-packs/` 整个复制到新包的同一位置",
                       "上传时不带 `.novel-workshop-backups`",
                       "个人导出默认不带 `assets/project-packs/`", "`--include-projects`",
                       "不需要 `assets/project-packs/index.md`", "`--mode sale` 一律不带", "便携单文件不展开这份记录"):
            self.assertIn(phrase, part)

    def test_a_record_kept_where_r555_said_is_moved_back_only_after_asking(self):
        part = section(self.module, "从 r5.55 的位置挪回", "### ")
        for phrase in ("先问作者一句", "不默默挪", "照原处那一份读、写，不在技能目录里另建一份", "原话和历史不改写",
                       "不留两份权威", "作者定以前不往任何一份里写新条目"):
            self.assertIn(phrase, part)

    def test_the_rules_that_did_not_change(self):
        for phrase in ("作者没看过这句措辞以前记“待确认”", "作者确认以后才改成已确认", "写作只执行已确认且适用的条目",
                       "待确认的条目不当规则用", "不静默删除历史"):
            self.assertIn(phrase, self.module)
        self.assertIn("不能偷偷改写历史原话", self.text)

    def test_the_entry_says_the_same(self):
        skill = page("SKILL.md")
        row = next(l for l in section(skill, "可选模块：默认关着").splitlines() if l.startswith("| 作者改法累计 |"))
        for phrase in ("`" + FOLDER + "`", REGISTER, HISTORY, "跟着技能包走", "商业交付版不带这两份，开了才建"):
            self.assertIn(phrase, row)
        rule = next(l for l in skill.splitlines() if l.startswith("- 作者开了 [作者改法累计]"))
        self.assertIn("从技能目录的 `" + FOLDER + REGISTER + "` 读开启状态", rule)
        self.assertIn("问作者一句再挪回，不默默挪，也不留两份", rule)
        self.assertIn("同一文件夹下的 `_author/` 是作者改法累计，不是一本书", skill)
        self.assertIn("`assets/project-packs/` 不带（作品资料和作者改法累计 `_author/` 都不带", skill)
        self.assertIn("`_author/` 是作者改法累计", page("references/projects.md"))

    def test_no_page_keeps_the_r555_wording(self):
        pages = {p.relative_to(ROOT).as_posix(): read(p) for p in sorted(SKILL.rglob("*.md"))
                 if "project-packs" not in p.parts}  # a user's own records and books are not package pages
        pages["skills/darwin-novel-workshop/SKILL.md"] = read(ROOT / "skills" / "darwin-novel-workshop" / "SKILL.md")
        for name in ("QUICKSTART.md", "USAGE.md", "EXAMPLES.md"):
            pages[name] = read(ROOT / name)
        pages["README.md (outside the version notes)"] = without_version_notes(read(ROOT / "README.md"))
        for name, text in pages.items():
            for phrase in OLD:
                self.assertNotIn(phrase, text, (name, phrase))

    def test_the_readme_current_section_is_this_release(self):
        # r5.56 review: the test above leaves out README's "本版" section, which still described r5.55 ("挪出技能目录，
        # 升级安装不动它"), and the r5.56 sentence had been added to the r5 section of earlier versions instead.
        readme = read(ROOT / "README.md")
        current = section(readme, "本版")
        self.assertTrue(current.startswith("## 本版（r5.56）"), current[:40])
        for phrase in OLD + ("挪出技能目录",):
            self.assertNotIn(phrase, current, phrase)
        for phrase in ("`novel-workshop/assets/project-packs/_author/`", "`--keep`", "gemini-4-argon", "可以改"):
            self.assertIn(phrase, current)
        self.assertNotIn("r5.56", section(readme, "r5：工坊宪法"))

    def test_the_author_profile_and_the_register_say_the_same(self):
        # r5.56 review: once the records are on, the author's new cross-work defaults go into the register; the pages
        # said so in one place and the opposite in others, and told the workshop to write into the author's own
        # profile without asking.
        text, module = self.text, self.module
        self.assertIn("作者改法累计固定在技能目录的 `" + FOLDER + "`，开了以后作者新说的跨作品默认也记在那里", text)
        self.assertIn("改法累计属于技能目录的 `" + FOLDER + "`，开了改法累计以后作者新说的跨作品默认也记在那里", text)
        self.assertIn("作者没答应以前不往作者自己的档案里写", module)
        gate = page("references/chapter-confirmation.md")
        self.assertNotIn("就是 `correction-register.md`", gate)
        row = next(l for l in section(page("SKILL.md"), "可选模块：默认关着").splitlines() if l.startswith("| 新章全流程"))
        self.assertIn("“以后每次写新的一章都这样”（开了作者改法累计的，看 `" + REGISTER + "`）", row)

    def test_rolling_back_to_r555_and_to_earlier_releases_is_told_apart(self):
        # r5.56 review: r5.55 reads the records from the author profile, not from the skill folder, so copying them
        # back into the skill folder did not make r5.55 use them; and running the same older package again with
        # --upgrade, as its error message suggests, moves the copied records into the backup again.
        for name, text in (("QUICKSTART.md", read(ROOT / "QUICKSTART.md")),
                           ("author-preferences.md", section(self.module, "升级、退回、换包和导出", "### "))):
            for phrase in ("r5.55 从作者档案读这份记录", "退回 r5.54 或更早的", "不要照它的提示加 `--upgrade` 再装同一个旧包"):
                self.assertIn(phrase, text, (name, phrase))
        doc = "".join(read(ROOT / "install.py").split("\"\"\"")[1].split())
        self.assertIn("<dest>/novel-workshop/assets/project-packs/again", doc)
        self.assertIn("donotrunitagainwith--upgrade", doc)

    def test_the_hand_upload_pages_warn_about_a_package_with_its_own_records(self):
        # r5.56 review: these pages will also go into a personal build, which ships its own _author/; copying the
        # old project-packs over it would silently replace the package's entries.
        pages = {"QUICKSTART.md": read(ROOT / "QUICKSTART.md"), "EXAMPLES.md": section(read(ROOT / "EXAMPLES.md"), "30. "),
                 "author-preferences.md": section(self.module, "升级、退回、换包和导出", "### ")}
        for name, text in pages.items():
            line = next(l for l in text.splitlines() if "整包上传" in l or l.startswith("- 没有 Python"))
            self.assertIn("复制以前先对一下两边", line if "复制以前" in line else text, name)
            self.assertIn("不要直接盖", text, name)
        self.assertIn("只多出包里没有的文件时，它点名是哪些", pages["QUICKSTART.md"])

    def test_the_rule_pages_name_the_files_in_backticks_not_as_links(self):
        # export_portable.py follows relative links and refuses ones into assets/project-packs/, and the commercial
        # package has no such files, so a link would be a broken link here.
        for path in sorted(SKILL.rglob("*.md")):
            if "project-packs" not in path.parts:
                self.assertNotRegex(read(path), r"\]\([^)]*project-packs/_author", path.relative_to(ROOT))

    def test_the_root_pages_say_where_it_is_and_how_it_survives_an_upgrade(self):
        quick = read(ROOT / "QUICKSTART.md")
        for phrase in ("**你的记录跟着升级。**", "`novel-workshop/assets/project-packs/_author/`", "`carried`", "`conflicts`",
                       "python install.py --upgrade --keep installed", "python install.py --upgrade --keep package",
                       "**整包上传、不用 `install.py` 的。**", "**退回时你的记录在哪。**", "“Existing skill differs”",
                       "先把它的 `assets/project-packs/` 另存一份", "工坊看到了会先问你一句，你同意了才挪回"):
            self.assertIn(phrase, quick)
        self.assertIn("`assets/project-packs/_author/`", read(ROOT / "USAGE.md"))
        self.assertIn("## 30. 作者改法累计：开启、确认、换包", read(ROOT / "EXAMPLES.md"))


class TheDefaultTeacher(unittest.TestCase):
    def test_the_handoff_says_the_default_and_that_it_can_change(self):
        gate = section(page("references/chapter-confirmation.md"), "完整初稿以后")
        for phrase in ("交初稿时说清默认的教师设置：交给 gemini-4-argon，思考等级选“高”（High）",
                       "作者档案或作品档案另写了别的教师的，照写的说", "作者这一次另说的，照这一次",
                       "这只是默认设置，作者可以改", "不说用它就写得更好，这一点没有验证过"):
            self.assertIn(phrase, gate)

    def test_teacher_name_is_what_happened_and_says_when_it_was_the_default(self):
        records = section(page("references/chapter-confirmation.md"), "记录怎么写")
        for phrase in ("`teacher_name` 照实际填", "作者这一次说了交给谁，就写谁", "`" + DEFAULT_NAME + "`",
                       # r5.56 review: "照默认交的" is the default said at the handoff, which a profile may set to
                       # another teacher; the page wrote gemini-4-argon for it whatever the profile said.
                       "作者说的是“照默认交的”，写交初稿时说的那个默认：作者档案或作品档案另定了教师的，写那一位；"
                       "没另定的，写 `gemini-4-argon（思考等级：高）`",
                       "交初稿时工坊说过的默认设置，不算作者说了用它", "作者自己也说不清的，写未知",
                       "宿主自己审的不写成教师", "已经登记过的回传不追改 `teacher_name`"):
            self.assertIn(phrase, records)
        review = section(page("references/teacher-review.md"), "回传、取舍与复查怎么记")
        for phrase in ("默认的教师设置是 gemini-4-argon、思考等级选“高”（High）", "`" + DEFAULT_NAME + "`",
                       "作者自己也说不清的写未知", "宿主自己审的不冒充教师", "已经登记过的回传不追改 `teacher_name`",
                       "不说明用它审得更好"):
            self.assertIn(phrase, review)

    def test_the_documented_name_is_registered_and_read_back_as_it_stands(self):
        # r5.56 review: this used to call chapter_gate._text, which only checks for non-empty text, so it could not
        # fail. Now a whole teacher_return is registered through learning_loop.py on newly written neutral text, and
        # teacher_name is read back from the record.
        spec = importlib.util.spec_from_file_location("r556_learning_loop", SKILL / "scripts" / "learning_loop.py")
        loop = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(loop)
        draft = "掌柜把算盘推到一边，低头去找账本。"
        digest = hashlib.sha256(draft.encode("utf-8")).hexdigest()
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "learning.md"
            payload = {"schema_version": 1, "project_id": "book", "revision": 0, "data": {}}
            path.write_bytes(("<!-- NOVEL_WORKSHOP_LEARNING_START -->\n```json\n" + json.dumps(payload)
                              + "\n```\n<!-- NOVEL_WORKSHOP_LEARNING_END -->\n").encode("utf-8"))
            serial = []

            def gate(action, stage=None, **fields):
                serial.append(action)
                event = {"event_id": "g%d" % len(serial), "op": "chapter_gate", "action": action, "chapter_id": "c1",
                         **fields}
                if stage:
                    event["stage"] = stage
                return loop.apply_event(path, event, "book", loop.read_store(path)[1])

            def confirm(shown):
                return gate("confirm", shown["current_stage"], presentation_id=shown["presentation_id"],
                            presentation_version=shown["presentation_version"], actor_role="author", mode="human",
                            author_quote="可以。", source_ref="fixture://author/" + shown["presentation_id"])

            for stage in ("scope", "outline"):
                confirm(gate("present", stage, content="合成：" + stage, source_ref="fixture://" + stage))
            confirm(gate("present", "preparation", content="合成：准备", source_ref="fixture://prep",
                         visual_evidence={"mode": "author_images", "source_refs": ["fixture://img"],
                                          "observation_ref": "fixture://obs", "selection_ref": "fixture://sel"}))
            shown = gate("present", "draft", content="合成：初稿", source_ref="fixture://draft", artifact_sha256=digest)
            confirm(shown)
            returned = gate("teacher_return", draft_presentation_id=shown["presentation_id"],
                            draft_presentation_version=shown["presentation_version"], draft_sha256=digest,
                            returned_text="合成：教师意见。", source_ref="fixture://teacher", teacher_name=DEFAULT_NAME)
            self.assertTrue(returned["teacher_return_id"])
            record = loop.read_store(path)[0]["data"]["chapter_confirmations"]["c1"]["teacher_returns"]
            self.assertEqual([item["teacher_name"] for item in record], [DEFAULT_NAME])

    def test_the_entry_and_usage_pages_say_the_same(self):
        row = next(l for l in section(page("SKILL.md"), "可选模块：默认关着").splitlines()
                   if l.startswith("| 新章全流程"))
        # r5.56 review: "初稿交教师默认的教师设置是" read awkwardly; the row now says "初稿交教师时，默认的……".
        for phrase in ("初稿交教师时，默认的教师设置是 gemini-4-argon、思考等级选“高”（High），可以改",
                       "作者档案或作品档案另写了别的教师的照写的", "作者这一次另说的照这一次"):
            self.assertIn(phrase, row)
        for name in ("QUICKSTART.md", "USAGE.md", "EXAMPLES.md"):
            text = read(ROOT / name)
            self.assertIn("交给 gemini-4-argon，思考等级选“高”（High）", text, name)
            self.assertIn("可以改", text, name)

    def test_nothing_says_the_default_writes_better(self):
        # r5.56 review: this looked only at sentences holding both "gemini-4-argon" and "更好", while the pages put the
        # disclaimer in a sentence of its own, so it checked nothing. Now every paragraph (or list item) that names the
        # default teacher setting is read: a word of comparison in it must stand in a negated sentence, and such a
        # paragraph must also say that it is not shown or not verified.
        pages = [SKILL / "SKILL.md"] + sorted((SKILL / "references").glob("*.md")) + \
                [ROOT / n for n in ("QUICKSTART.md", "USAGE.md", "EXAMPLES.md", "README.md")]
        better = re.compile(r"更好|更准|最好|更强|更高明|效果更")
        seen = 0
        for path in pages:
            for paragraph in re.split(r"\n\s*\n|\n(?=- )|\n(?=\| )", read(path)):
                if "gemini-4-argon" not in paragraph:
                    continue
                seen += 1
                for sentence in re.split(r"[。；\n]", paragraph):
                    if better.search(sentence):
                        self.assertRegex(sentence, r"不说|不说明|没有验证|没验证|不等于", (path.name, sentence))
                        self.assertRegex(paragraph, r"不说明|没有验证|不说用它", (path.name, paragraph[:60]))
        self.assertGreater(seen, 8)

    def test_the_workbench_page_matches_the_workbench_code(self):
        doc = page("references/local-workbench.md")
        # r5.56 review: "不等于选了“高”" claimed what nobody checked (the model's own default may be high).
        self.assertIn("这个侧栏的请求里不指定思考等级，用的是模型自己的默认，工坊没有核对过那是不是“高”", doc)
        self.assertIn("模型选 gemini-4-argon，思考强度选 High", doc)
        self.assertIn("整章初稿超过 6000 字的发不全", doc)
        self.assertIn("也可以用下面 Google AI 侧栏选 High（这条路只用模拟程序测过）", doc)
        for script in ("gemini-assist.mjs", "acp-assist.mjs"):  # the 6000 on the page is the limit in both panels
            self.assertRegex(read(SKILL / "scripts" / "oh-story" / script), r"const MAX_TEXT_CHARS = 6000;", script)
        code = read(SKILL / "scripts" / "oh-story" / "gemini-assist.mjs")
        # The page says the Gemini panel sends no thinking level and defaults to gemini-4-argon; this release did not
        # change the workbench code. If the request ever sets a thinking level, the page has to change with it.
        self.assertIn('export const DEFAULT_MODEL = "gemini-4-argon";', code)
        self.assertNotIn("thinkingConfig", code)
        self.assertNotIn("thinkingLevel", code)


if __name__ == "__main__":
    unittest.main()

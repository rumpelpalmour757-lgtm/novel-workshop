"""The range a candidate may change comes from a fresh scan, not from the request file.

apply scans the chapter again with the same config and options and accepts the request
only when it is exactly what that scan builds. A request rewritten to reach other lines,
or to call an unknown speaker confirmed, is refused and no output file is written.
All names and text are synthetic.
"""
import contextlib
import copy
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from dialogue_core import extract_dialogues
from patch_guard import check_request_matches
from run_lint import main

SOURCE = ('陈原对方禾说：“在左边柜里。”他把雨衣抖开。\n'
          '\n'
          '“谁在那儿？”\n'
          '\n'
          '门外有人咳了一声。“是我。”\n'
          '\n'
          '方禾说：“我先下去看看。”\n')
CONFIG = {'profiles': {'陈原': {}, '方禾': {}}}


def run_cli(args):
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        try:
            code = main(args)
        except SystemExit as stop:
            code = stop.code
    return code, out.getvalue(), err.getvalue()


class ApplyScopeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / 'chapter.txt'
        self.source.write_text(SOURCE, encoding='utf-8')
        self.config = self.root / 'book.json'
        self.config.write_text(json.dumps(CONFIG, ensure_ascii=False), encoding='utf-8')
        self.request = self.root / 'request.json'
        code, _, err = run_cli(['scan', str(self.source), '--config', str(self.config), '--style-hints',
                                '--output', str(self.root / 'report.json'), '--request-output', str(self.request)])
        self.assertEqual(code, 0, err)
        self.req = json.loads(self.request.read_text(encoding='utf-8'))
        self.lines = SOURCE.splitlines(keepends=True)
        self.spans = {s.quote_id: s for s in extract_dialogues(self.lines, ('陈原', '方禾'))}

    def write(self, name, data):
        path = self.root / name
        path.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
        return path

    def apply(self, request_path, replacements, *options):
        response = self.write('response.json', {'source_hash': self.req['source_hash'], 'replacements': replacements})
        target = self.root / 'revised.txt'
        if target.exists():
            target.unlink()
        code, out, err = run_cli(['apply', str(self.source), str(request_path), str(response),
                                  '--output', str(target), *options])
        return code, out, err, target

    def forged_item(self, quote_id):
        span = self.spans[quote_id]
        return {'quote_id': quote_id, 'para_index': span.para_index, 'quote_index': span.quote_index,
                'start': span.start, 'end': span.end, 'original': span.text,
                'speaker': '陈原', 'confidence': 'explicit', 'issues': []}

    def test_scan_offers_only_the_confirmed_line_with_a_hit(self):
        self.assertEqual([i['quote_id'] for i in self.req['items']], ['p1:q1'])
        self.assertEqual(self.req['scan_settings']['style_hints'], True)

    def test_genuine_request_applies_with_the_same_options(self):
        code, out, err, target = self.apply(self.request, [
            {'quote_id': 'p1:q1', 'original': '在左边柜里。', 'replacement': '在左边那个柜子里。'}],
            '--config', str(self.config), '--style-hints')
        self.assertEqual(code, 0, err)
        self.assertEqual(target.read_text(encoding='utf-8'), SOURCE.replace('在左边柜里。', '在左边那个柜子里。'))
        self.assertIn('p1:q1', out)

    def test_request_rewritten_to_reach_unknown_or_unflagged_lines_is_refused(self):
        forged = copy.deepcopy(self.req)
        forged['items'] += [self.forged_item('p3:q1'), self.forged_item('p5:q1'), self.forged_item('p7:q1')]
        path = self.write('forged.json', forged)
        code, _, err, target = self.apply(path, [
            {'quote_id': 'p3:q1', 'original': '谁在那儿？', 'replacement': '别出声。'},
            {'quote_id': 'p7:q1', 'original': '我先下去看看。', 'replacement': '你先下去。'}],
            '--config', str(self.config), '--style-hints')
        self.assertEqual(code, 2)
        self.assertIn('对不上', err)
        self.assertFalse(target.exists())

    def test_request_that_relabels_the_speaker_is_refused(self):
        forged = copy.deepcopy(self.req)
        forged['items'][0]['speaker'] = '方禾'
        code, _, err, target = self.apply(self.write('forged.json', forged), [],
                                          '--config', str(self.config), '--style-hints')
        self.assertEqual(code, 2)
        self.assertFalse(target.exists())

    def test_options_or_config_that_differ_from_the_scan_are_refused(self):
        for options in ((), ('--config', str(self.config)), ('--config', str(self.config), '--style-hints',
                                                             '--genre', 'modern_gritty')):
            with self.subTest(options=options):
                code, _, err, target = self.apply(self.request, [], *options)
                self.assertEqual(code, 2)
                self.assertFalse(target.exists())
        changed = dict(CONFIG, stress_speakers=['方禾'])
        self.config.write_text(json.dumps(changed, ensure_ascii=False), encoding='utf-8')
        code, _, err, target = self.apply(self.request, [], '--config', str(self.config), '--style-hints')
        self.assertEqual(code, 2)
        self.assertFalse(target.exists())

    def test_settings_written_into_the_request_cannot_widen_it(self):
        forged = copy.deepcopy(self.req)
        forged['scan_settings']['style_hints'] = False
        code, _, err, target = self.apply(self.write('forged.json', forged), [],
                                          '--config', str(self.config), '--style-hints')
        self.assertEqual(code, 2)
        self.assertFalse(target.exists())

    def test_older_request_files_are_refused_with_a_rescan_message(self):
        old = copy.deepcopy(self.req)
        old['schema_version'] = 1
        old.pop('scan_settings')
        code, _, err, target = self.apply(self.write('old.json', old), [],
                                          '--config', str(self.config), '--style-hints')
        self.assertEqual(code, 2)
        self.assertIn('重新扫描', err)
        self.assertFalse(target.exists())

    def test_library_check_compares_every_field(self):
        check_request_matches(self.req, copy.deepcopy(self.req))
        for change in ('speaker', 'confidence', 'start', 'original'):
            forged = copy.deepcopy(self.req)
            forged['items'][0][change] = '方禾' if change != 'start' else 0
            with self.subTest(change=change), self.assertRaises(ValueError):
                check_request_matches(forged, self.req)


if __name__ == '__main__':
    unittest.main()

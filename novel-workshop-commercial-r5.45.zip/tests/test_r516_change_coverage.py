#!/usr/bin/env python3
"""r5.16: after an edit, every separate change needs its own decision, not just one per changed block.

A 2026-10-19 outside review of r5.14 (P2-G01) recorded a strict-mode PASS, then changed one line in two places and
re-recorded with a decision for the first change only. The gate accepted it: for each block of changed lines it took
the character differences, merged them into one span from the first changed character to the last, and asked for any
one decision touching that span. A decision for the first change covered the second as well. The same merge let one
decision cover two neighbouring lines that changed together, in a layout without blank lines between paragraphs.

These tests pin the repair, through the real command line:
- two changes on one line, one recorded: refused (REVIEW_INCOMPLETE), and the message names the unrecorded change;
- the same edit with both changes recorded: PASS; with none: refused;
- two neighbouring lines changed in one block, one recorded: refused;
- one change that the character diff splits into several pieces (a shared character in the middle) still needs only
  the one decision that quotes it; a deletion inside a line is covered by the decision whose new words sit there, and
  a clause cut out with nothing in its place by the decision that quotes its old words.
All material is invented for these tests; reviews are labelled test data and are not literary judgments.
"""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
GUARD = ROOT / "skills" / "novel-workshop" / "scripts" / "workflow_guard.py"
DIMENSIONS = ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function", "continuity",
              "revision_comparison")

LINES = [
    "雨停以后，阿禾把木箱放在门边，解开麻绳，取出几只旧瓷碗。她把碗沿朝下排成一行，又把旧布折好放进空箱。",
    "老沈拿来报纸，把桌上的碗一只只包好，码进竹筐，又在筐底垫了一层稻草。",
    "天黑以后，两人抬着竹筐回屋，灯芯剪过一次，屋里亮了些。",
]
EVIDENCE = ("解开麻绳，取出几只旧瓷碗", "老沈拿来报纸", "两人抬着竹筐回屋")
FIRST = ("木箱放在门边", "木箱挪到门外")          # the character diff splits this one: 门 stays in the middle
SECOND = ("旧布折好放进空箱", "旧布展开铺在地上")
NEIGHBOUR = ("一只只包好，码进竹筐", "一只只包好，码进藤筐")  # on the next line


def sha_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def change(pair, why="测试数据：只验证记录结构"):
    return {"decision": "change", "before": pair[0], "after": pair[1], "judgment": why, "reason": why}


class ChangeCoverage(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.dir)

    def write(self, name, text):
        (self.dir / name).write_bytes((text).encode("utf-8"))

    def guard(self, *args):
        proc = subprocess.run([sys.executable, "-I", "-B", str(GUARD), *args], cwd=self.dir, capture_output=True,
                              text=True, encoding="utf-8")
        try:
            return proc.returncode, json.loads(proc.stdout)
        except ValueError:
            return proc.returncode, {"raw": proc.stdout[-400:], "stderr": proc.stderr[-400:]}

    def review(self, name, text, decisions):
        last = [line for line in text.splitlines() if line.strip()][-1]
        value = {"schema": "editorial-review/2", "verdict": "PASS", "candidate_sha256": sha_text(text),
                 "reviewer": {"mode": "self_check", "label": "测试数据：只验证记录结构"},
                 "checked_against": ["测试数据"], "inputs_read": [],
                 "evidence": [{"quote": q, "in": "candidate"} for q in EVIDENCE],
                 "issues": [], "machine_dispositions": [], "counter_evidence": "测试数据，不是真实文学审稿。",
                 "dimensions": [{"id": key, "status": "met", "note": "测试数据：只验证记录结构"} for key in DIMENSIONS],
                 "expression": {"scope": "chapter", "decisions": decisions, "segments": [
                     {"from": text[:8], "to": last[-8:], "note": "测试数据：从头连读到尾，逐句看过改动和前后句"}]}}
        self.write(name, json.dumps(value, ensure_ascii=False))
        return name

    def first_pass(self, text):
        """Record a strict PASS for `text`, then reserve a new round for an edit."""
        self.write("draft.md", text)
        self.write("checks.json", json.dumps({"candidate": "draft.md", "mode": "strict", "checks": [
            {"id": "ending", "type": "contains", "text": "两人抬着竹筐回屋"}]}, ensure_ascii=False))
        self.assertEqual(self.guard("start", "run.json", "--task-id", "t", "--spec", "checks.json")[0], 0)
        code, out = self.guard("record", "run.json", "--event-id", "v1", "--review", self.review("v1.json", text, []))
        self.assertEqual(code, 0, out)

    def edit(self, text):
        self.write("draft.md", text)
        self.assertEqual(self.guard("reserve", "run.json", "--event-id", "r1")[0], 0)

    def record(self, event, text, decisions):
        return self.guard("record", "run.json", "--event-id", event, "--review", self.review(event + ".json", text,
                                                                                             decisions))

    def editorial(self):
        return self.guard("status", "run.json")[1]["gate"]["editorial"]

    def test_two_changes_on_one_line_need_two_decisions(self):
        old = "\n\n".join(LINES) + "\n"
        new = old.replace(*FIRST).replace(*SECOND)
        self.first_pass(old)
        self.edit(new)
        code, out = self.record("v2", new, [change(FIRST)])
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertIn("折好放进空箱", out["message"])  # the unrecorded change, not the recorded one
        self.assertNotEqual(self.editorial(), "PASS[self_check]")
        code, out = self.record("v2b", new, [change(SECOND)])  # the other way round: only the second recorded
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertIn("放在", out["message"])
        code, out = self.record("v3", new, [])
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        code, out = self.record("v4", new, [change(FIRST), change(SECOND)])
        self.assertEqual(code, 0, out)
        self.assertEqual(self.editorial(), "PASS[self_check]")

    def test_neighbouring_lines_changed_together_need_a_decision_each(self):
        old = "\n".join(LINES) + "\n"  # one paragraph per line, no blank lines: both edits fall in one block
        new = old.replace(*FIRST).replace(*NEIGHBOUR)
        self.first_pass(old)
        self.edit(new)
        code, out = self.record("v2", new, [change(FIRST)])
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertIn("line 2", out["message"])
        code, out = self.record("v3", new, [change(FIRST), change(NEIGHBOUR)])
        self.assertEqual(code, 0, out)

    def test_one_change_split_by_the_diff_needs_only_its_own_decision(self):
        old = "\n\n".join(LINES) + "\n"
        new = (old.replace(*FIRST)
               .replace("又把旧布折好放进空箱", "又把旧布放进空箱")      # a deletion inside a sentence
               .replace("，又在筐底垫了一层稻草。", "。"))              # a clause cut out with nothing in its place
        self.first_pass(old)
        self.edit(new)
        cut = {"decision": "change", "before": "又在筐底垫了一层稻草", "after": "",
               "judgment": "测试数据：只验证记录结构", "reason": "测试数据：只验证记录结构"}
        code, out = self.record("v2", new, [change(FIRST), change(("旧布折好放进空箱", "旧布放进空箱"))])
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)  # the cut clause is not recorded
        code, out = self.record("v3", new, [change(FIRST), change(("旧布折好放进空箱", "旧布放进空箱")), cut])
        self.assertEqual(code, 0, out)  # the cut is found by its old words: nothing in the new text marks it
        self.assertEqual(self.editorial(), "PASS[self_check]")


if __name__ == "__main__":
    unittest.main()

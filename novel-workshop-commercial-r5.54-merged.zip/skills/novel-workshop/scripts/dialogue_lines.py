#!/usr/bin/env python3
"""Pull the dialogue of a chapter out by speaker: the third of the five revision passes (r5.33; who-speaks rules r5.35).

python3 dialogue_lines.py CHAPTER [--paragraph-mode blank|line] [--names 甲,乙] [--voices VOICES.json] [--format text|json]
                          [--exchanges] [--long-lines]

--exchanges (r5.53) adds a view for reading the talk exchange by exchange: every line in the order it stands in the text,
with the bit of narration right before it (in the same paragraph, or the last sentence of the paragraph before) and its
speaker, and a blank line where whole paragraphs of narration (NARRATION_BREAK Han characters or more) come between.
A speaking tag that belongs to the line before (“……”老许说。) is not shown as the narration before the next line: it
would read as naming the next speaker. Sorted by speaker, 几点走？ and 行。 read fine on their own; read in place, a reader
sees what just happened and whether the reply takes up the line before. It only lists; it judges nothing.
--exchanges changes the text report only. In the JSON every line always carries `before` (that narration) and `order`
(its place in the text, from 0).

Read-only. Reading every line one speaker at a time is how a reader catches a line that is not this person's: narration
words that slipped into speech (a register mismatch), a calm full sentence where the person is in a hurry, the author
explaining the setting through someone's mouth. This script only does the sorting, and it sorts a line only on clear
evidence next to it (r5.35):

- a speaking tag: the subject of 说/问/喊/道…, before the line (老周对程棠说：) or after it (“……”老周说。);
- the clause that a colon closes, or the sentence just before the line in the same paragraph, when a given name is its
  subject (老周看了程棠一眼：“……” goes to 老周).

In a speaking tag only the people in the verb's own clause count (r5.37, the r5.35 review, point 4): the one heard
speaks (宋青听见林满说: 林满); the one compared (宋青比林满先说道), spoken to, looked at or acted on does not; two people
joined as one subject (宋青和林满同时说, 宋青、林满齐声说) both speak, so nobody is picked; two people with an action
between them (宋青安慰林满说) leave it open, unless that action is itself a speaking verb (宋青叮嘱林满说: 宋青). What is
not clear is listed as not attributed, with the possible speakers: a wrong speaker costs more than a line left open.

r5.38 (the r5.37 review, point 4): a group speaking in a clause of its own (宋青看了林满一眼，两人齐声说; 宋青、林满站在
门口，齐声说) is never given to the person named in the clause before: the line is left open with the people who may be
in the group. The walk back joins names with 、 as with 和 (宋青、林满、程棠站在门口：), the whole chain.

The person spoken to, handed something, looked at, pushed or named after 的 is never taken for the speaker: in
他对宋青说：“……” the speaker is 他, so the line stays not attributed. When the subject is a pronoun or someone not on the
list, or two people could be meant, the line is listed as not attributed (with the possible speakers, if any). The
flags point at words worth a second look: written-register words in speech, words the book's voice file says this
person, or nobody, says aloud, and, with --long-lines (r5.54), long lines. Whether a line sounds like the person is the
reader's judgement; this is not an AI detector and not a verdict.

r5.49 (the author, through a handoff of 11-05: "对白不知道谁是谁说的"): a section "谁在说：要回头读的地方" lists the places
where a reader may lose who is speaking: runs of lines in a row with no stated speaker, a line that starts again after a
stretch of narration with no stated speaker, and lines given to someone only because that person acts right before the
line (readers read them that way too; when the line is someone else's, that is where to add "某某说／问"). It is a list
of places to re-read, not a verdict: two people going back and forth can stay as they are, and the script never guesses a
speaker from the order of the lines. The numbers below only decide what is listed.

r5.54: a line of LONG_MIN Han characters or more is listed under "要再读一遍的" only with --long-lines, and then only
where it is: some people talk at length, and a long line is not a fault. Without the option neither the text report nor
the JSON lists it; the JSON says which it was (long_lines_listed). The other flags are listed as before.

r5.54: a paragraph with no line that ends in a colon (……笑着骂了一句：), right before a paragraph that opens with a line,
is read as the narration right before that line, as if both stood in one paragraph; such a line is no longer listed as
starting again after narration with no stated speaker. Only those two paragraphs count. The script leaves a line
unattributed when it cannot name the subject or when the tag describes speech that has not happened (没有说、本想说). It
also leaves a line unattributed when the sentence the colon closes brings in something written, posted or listed (a
letter, a message, a notice, a list: 写, 告示, 信里, 列了, 如下 …), or when the line itself is a list (一、…, or
words in quotes joined by 、): there the quoted words may be nobody's speech, and a line left open costs less.
"""
import argparse
import bisect
import hashlib
import json
from pathlib import Path
import re
import sys

QUOTE = re.compile(r"“([^”]*)(?:”|$)|「([^」]*)(?:」|$)|『([^』]*)(?:』|$)")
# Words of the written register that rarely come out of anyone's mouth; a hit is a place to read again, not an error.
WRITTEN = ("然而", "因此", "因而", "从而", "并且", "此外", "况且", "倘若", "即便", "此刻", "随即", "旋即", "依旧", "依然",
           "仍旧", "尚未", "业已", "逐一", "依次", "之际", "与此同时")
LONG_MIN = 24  # Han characters in one quoted stretch: listed only with --long-lines, only where it is (r5.54)
LIMITS = ("只按台词旁边写明的说话人分栏：说话标签（谁说、谁问）、冒号前那一句或同段紧挨着的上一句的主语；受话人、"
          "递东西给的人、看着的人不算说话人，认不出、拿不准的单列。标出的词只是要再读一遍的地方，像不像这个人说的由人判断。"
          "“谁在说”一节只列位置，不判断归属对不对，也不按单双行猜是谁；没列出来不说明读者都认得出。不改文件。")
RUN_MIN = 3  # lines in a row with no stated speaker before they are listed (r5.49): a place to re-read, not an error
NARRATION_BREAK = 40  # Han characters of narration paragraphs since the last line: a line after that is listed if unattributed
LONG_NOTE = "一口气 %d 个字：只列位置；有的人说话本来就长，长不是毛病（r5.54）"
# r5.54: a colon at the end of a paragraph with no line brings in the line that opens the next paragraph, unless the
# sentence it closes brings in something written, posted or listed (a letter, a message, a notice, a list).
WRITTEN_INTRO = re.compile(
    r"写|记下|记在|记录|印着|印了|印的|刻着|刻了|刻的|贴了|贴出|列了|列出|列着|列举|如下|以下|下列|信上|信里|信中|信纸|来信|"
    r"回信|短信|微信|邮件|留言|纸条|字条|便条|电报|告示|公告|布告|启事|通告|标语|横幅|牌子|招牌|屏幕")
# A line that is itself a list: it opens with a number of an item (一、 1. （二）), not with counting (一、二、三).
LISTED = re.compile(r"(?:[一二三四五六七八九十]+|\d+)[、.．](?![一二三四五六七八九十\d])|[（(](?:[一二三四五六七八九十]+|\d+)[）)]")

# Speaking verbs, longest first. A one-character verb inside a longer word (知道, 听说, 问题) is not a speaking tag.
SPEECH = ("说道", "问道", "答道", "喊道", "叫道", "嚷道", "喝道", "笑道", "骂道", "回道", "应道", "念道", "回答", "回嘴",
          "嘀咕", "嘟囔", "嘟哝", "咕哝", "低语", "开口", "插嘴", "接话", "打断", "提醒", "解释", "吩咐", "叮嘱", "嘱咐",
          "补充", "追问", "反问", "质问", "询问", "交代", "招呼", "念叨", "告诉", "冷笑", "说", "问", "道", "讲", "喊",
          "嚷", "吼", "骂", "答", "应")
NOT_SPEECH_BEFORE = {"说": "听小传据学演游劝解", "问": "学疑访顾", "道": "知难味街轨通频渠管隧车霸公人一这那几两地",
                     "讲": "演", "应": "反适供效相"}
NOT_SPEECH_AFTER = {"说": "明服法", "问": "题号", "道": "理路具德观士", "讲": "究座台义", "应": "该当用付", "答": "案卷"}
PRONOUNS = ("他们", "她们", "它们", "我们", "你们", "咱们", "他", "她", "它", "我", "你", "您", "咱", "对方", "那人",
            "这人", "此人", "来人", "有人", "众人", "大家", "谁")
# People named by a common noun. They are not on the list, so a clause they open has a speaker the script cannot name.
PEOPLE = ("小伙子", "老太太", "年轻人", "中年人", "女孩", "男孩", "姑娘", "小伙", "少年", "少女", "男人", "女人", "老人",
          "老头", "老太", "孩子", "小孩", "老板", "伙计", "掌柜", "店主", "摊主", "客人", "护士", "医生", "队长", "士兵",
          "守卫", "卫兵", "司机", "师傅", "大叔", "大婶", "大娘", "大爷", "老者", "青年", "妇人", "汉子", "壮汉", "女子",
          "男子", "家伙", "学生", "老师")
# Right before a person, these make him the one spoken to, handed something, looked at or acted on.
OBJECT_BEFORE = re.compile(
    r"(?:对|向|朝|冲|跟|和|与|同|给|替|帮|为|把|将|被|由|陪|找|等|问|告诉|递给|交给|塞给|扔给|丢给|看|望|盯|瞪|瞥|瞧|瞅|"
    r"扫|打量|拦|拉|扶|推|拽|扯|按|搂|抱|拍|指|喊住|叫住|打断|认出|叫醒|摇醒)(?:了|着|过|住|向|给|到|开)?(?:一眼|两眼)?$")
# Right before a person, these leave it open who speaks next (老周让程棠说: who?).
PIVOT_BEFORE = re.compile(r"(?:让|叫|请|要|逼|求|催|劝|命令|示意|允许|教)(?:着|了)?$")
# Words that may open a clause before its subject (这时老周……).
OPENERS = ("这时", "此时", "那时", "这会儿", "于是", "然后", "接着", "随后", "随即", "突然", "忽然", "终于", "最后", "片刻后",
           "半晌", "良久", "转眼")
JOINED = "和与同及跟、"
# r5.37: in a speaking tag. Right before a person: he is the one heard, so he speaks (宋青听见林满说).
HEARD_BEFORE = re.compile(r"(?:听见|听到|听着|听得|听)(?:了)?$")
# Two people joined by one of these right between them are one subject (和、与、及、顿号) or, for 跟/同 without a word
# of togetherness, the second is the one spoken to (他跟宋青说).
JOINERS = {"和": "and", "与": "and", "及": "joint", "、": "joint", "跟": "with", "同": "with"}
TOGETHER = ("异口同声", "同时", "齐声", "一起", "一齐", "一同", "一块", "一道", "共同", "先后", "两人", "两个人", "二人",
            "俩", "都", "们")
# r5.38: a clause with nobody named that still says a group speaks (两人、二人、三个人、俩, or 齐声、同时、一起…).
GROUP = re.compile(r"(?:[两二三四五六几数]个?人|[俩仨]|%s)" % "|".join(w for w in TOGETHER if w not in ("都", "们")))
BOUNDARY = "。！？!?…；;\n"
CLAUSE = "，,：:"
# 老周身后的一个人, 宋青旁边的张三: the name only says where the other person stands, it is not the subject (r5.54 review)
OWNED = re.compile(r"(?:身后|身边|身旁|身前|旁边|边上|背后|后面|后头|前面|对面|跟前|手下|左右|那边|这边)?的")
SPACE = " \t\u3000"


def tail_sentence(text, width=40):
    """The last sentence of a stretch of narration, at most WIDTH characters (r5.53, --exchanges)."""
    text = re.sub(r"[\r\n]+", "", text).strip(SPACE + "“”‘’「」『』")
    if not text:
        return ""
    # a sentence keeps its run of end marks and the closing quote or bracket after them (……, ？！, 。）)
    parts = [x for x in re.findall(r"[^。！？…]*[。！？…]+[”’」』）)》】〕]*|[^。！？…]+$", text) if x.strip(SPACE)]
    last = parts[-1].strip(SPACE) if parts else text
    if not han_count(last):  # only marks are left (the narration ended in a quoted word and a full stop): nothing to show
        return ""
    return last if len(last) <= width else "…" + last[-width:]


def after_tag(text):
    """TEXT without its first sentence: what follows a speaking tag that closed the line before (r5.53)."""
    text = re.sub(r"[\r\n]+", "", text).strip(SPACE)
    m = re.match(r"[^。！？…，,：:；;]*(?:[。！？…]+[”’」』）)》】〕]*|[，,：:；;])", text)
    if not m:
        return ""
    # 老许没应。 老许打断了他。 are what happened, not who spoke: they stay (found in review)
    if re.search(r"(没有?|不|未)[^，。]{0,2}(应|答|说|开口|吭声|接话|作声|出声|言语|理)|打断", m.group()):
        return text
    return text[m.end():]


def colon_sentence(paragraph):
    """The sentence a colon closes at the end of a paragraph with no line (r5.54), or None: when the paragraph does not
    end in a colon, or that sentence brings in something written, posted or listed."""
    if not paragraph.rstrip(SPACE + "\r\n").endswith(("：", ":")):
        return None
    sentence = paragraph[max(paragraph.rfind(ch) for ch in BOUNDARY) + 1:].replace("\r", "")
    return None if WRITTEN_INTRO.search(sentence) else sentence


def listed_line(paragraph, quotes):
    """Whether the line that opens a paragraph is a list (r5.54): an item's number first, or words in quotes joined by 、."""
    said = next(g for g in quotes[0].groups() if g is not None)
    if LISTED.match(said.strip(SPACE)):
        return True
    return len(quotes) > 1 and paragraph[quotes[0].end():quotes[1].start()].strip(SPACE) == "、"


def han_count(text):
    return sum(1 for ch in text if "一" <= ch <= "鿿")


def nonempty_string(value):
    return isinstance(value, str) and bool(value.strip())


def load_voices(data):
    """The book's voice file: speakers with aliases and words they do not say, words only the narration uses, and the
    places the author decided one by one (cases)."""
    if not isinstance(data, dict) or set(data) - {"note", "speakers", "narration_only", "cases"}:
        raise ValueError("The voice file has note, speakers, narration_only and cases only")
    speakers = data.get("speakers", {})
    if not isinstance(speakers, dict):
        raise ValueError("speakers must be an object: name -> {aliases, voice, uses, avoid}")
    for name, item in speakers.items():
        if not nonempty_string(name) or not isinstance(item, dict) or set(item) - {"aliases", "voice", "uses", "avoid"}:
            raise ValueError("Speaker %r: an object with aliases, voice, uses, avoid" % name)
        for key in ("aliases", "uses", "avoid"):
            values = item.get(key, [])
            if not isinstance(values, list) or not all(nonempty_string(v) for v in values):
                raise ValueError("Speaker %s: %s must be a list of nonempty strings" % (name, key))
        if "voice" in item and not nonempty_string(item["voice"]):
            raise ValueError("Speaker %s: voice must be a nonempty string" % name)
    narration_only = data.get("narration_only", [])
    if not isinstance(narration_only, list) or any(
            not isinstance(x, dict) or set(x) - {"text", "say", "note", "except"} or not nonempty_string(x.get("text"))
            or any(k in x and not nonempty_string(x[k]) for k in ("say", "note")) for x in narration_only):
        raise ValueError("narration_only must be a list of {text, say, note, except} with a nonempty text")
    for item in narration_only:
        kept = item.get("except", [])
        if not isinstance(kept, list) or not all(nonempty_string(v) and item["text"] in v and v != item["text"]
                                                 for v in kept):
            raise ValueError("narration_only %s: except lists longer words that contain it (a term the characters "
                             "may say, such as a name of a group)" % item["text"])
    cases = data.get("cases", [])
    if not isinstance(cases, list) or any(
            not isinstance(x, dict) or set(x) - {"word", "chapter", "speaker", "was", "now", "decided", "scope", "note"}
            or not all(nonempty_string(x.get(k)) for k in ("word", "was", "now", "decided"))
            or not (isinstance(x.get("chapter"), int) and not isinstance(x.get("chapter"), bool) and x["chapter"] > 0)
            or any(k in x and not nonempty_string(x[k]) for k in ("speaker", "scope", "note")) for x in cases):
        raise ValueError("cases must be a list of {word, chapter, was, now, decided, speaker, scope, note}: one line the "
                         "author decided, with the chapter, the line before and after, and who decided when")
    return speakers, narration_only


def paragraphs_of(text, paragraph_mode):
    separator = r"\n" if paragraph_mode == "line" else r"\n[ \t\r]*\n"
    out, offset = [], 0
    for match in list(re.finditer(separator, text)) + [None]:
        end = match.start() if match else len(text)
        raw = text[offset:end]
        if raw.strip():
            out.append((offset + len(raw) - len(raw.lstrip()), raw.strip()))
        offset = match.end() if match else len(text)
    return out


class Who:
    """Finds the speaker of one quoted line from the narration right next to it."""

    def __init__(self, aliases):
        self.canonical = {}
        for name, words in aliases.items():
            for word in words:
                self.canonical.setdefault(word, name)
        self.kinds = {w: "name" for w in self.canonical}
        for word in PRONOUNS + PEOPLE:
            self.kinds.setdefault(word, "other")
        people = "|".join(re.escape(w) for w in sorted(self.kinds, key=len, reverse=True))
        self.tokens = re.compile(people)
        self.speech = re.compile("|".join(re.escape(w) for w in SPEECH))
        # What may follow a speaking verb in its clause: 着/了/一句, the person spoken to (他问宋青：).
        self.tail = re.compile(r"(?:道)?(?:着)?(?:了)?(?:一句|一声|两句|几句|声|句)?(?:起来|出来|出口)?(?:%s)?(?:道)?[%s]*"
                               % (people, SPACE))
        # Across a paragraph boundary, a negated or intended speech verb does not introduce spoken words.
        modifier = r"(?:开口|低声|小声|轻声|大声|出声|当面|直接|亲口|再|多)*"
        self.unspoken = re.compile(
            r"(?:没有|没|未曾|从未|尚未|仍未|未|不(?:曾|敢|肯|愿|想|能|会)|(?<![得能可会敢])不|"
            r"(?<!想了)(?<!想)想|想要|打算|准备|正要|差点儿?|险些)" + modifier
            + r"(?:(?:对|向|朝|跟|和|给)(?:%s)%s)?$" % (people, modifier))
        self.openers = re.compile("(?:%s)+" % "|".join(OPENERS))
        names = "|".join(re.escape(w) for w in sorted(self.canonical, key=len, reverse=True)) or "(?!)"
        self.joined = re.compile("[%s](%s)" % (JOINED, names))

    def verbs(self, text):
        """Speaking verbs in text that are not part of another word."""
        out = []
        for m in self.speech.finditer(text):
            word = m.group()
            before = text[m.start() - 1] if m.start() else ""
            after = text[m.end()] if m.end() < len(text) else ""
            if len(word) == 1 and (before and before in NOT_SPEECH_BEFORE.get(word, "")
                                   or after and after in NOT_SPEECH_AFTER.get(word, "")):
                continue
            out.append(m)
        return out

    def opens_clause(self, text, start):
        """Whether the person at start is where a clause's subject stands (after 这时, or 门口的…)."""
        clause_start = max(text.rfind(ch, 0, start) for ch in BOUNDARY + CLAUSE) + 1
        pre = text[clause_start:start].strip(SPACE)
        if not pre:
            return True
        if self.tokens.search(pre):
            return False
        return pre.endswith("的") or bool(self.openers.fullmatch(pre))

    def tag_subject(self, text):
        """(name, candidates) when text ends right before a speaking verb, from the people in the verb's own clause;
        None when that clause names nobody who could be its subject (宋青放下杯子，对林满说: look further back)."""
        start = max(text.rfind(ch) for ch in BOUNDARY + CLAUSE) + 1
        clause = text[start:]
        found = list(self.tokens.finditer(clause))
        if not found:
            words = set(GROUP.findall(clause))
            if not words:
                return None
            name, candidates = self.group_before(text[:start])
            if words == {"同时"} and len(candidates) == 1:
                return candidates[0], []  # 宋青放下杯子，同时说: at the same time as his own action, nobody else named
            return name, candidates
        together = any(word in clause[found[-1].end():] for word in TOGETHER)
        people, possessed = [], False  # people: [word, role, end]; roles: subject, object, pivot, heard
        for m in found:
            word, before = m.group(), clause[:m.start()]
            joiner = clause[people[-1][2]:m.start()].strip(SPACE) if people else None
            if OWNED.match(clause, m.end()):
                # 林满的同伴说 opens the clause: someone not on the list speaks. 看着林满的眼睛说, 听取林满的建议后说:
                # part of what is looked at or taken, not the subject.
                lead = before.strip(SPACE)
                possessed = possessed or not lead or bool(self.openers.fullmatch(lead)) or (
                    joiner in JOINERS and JOINERS[joiner] in ("and", "joint") and people[-1][1] == "subject")
                continue  # 宋青和林满的父亲说: the father may speak with 宋青, so 宋青 is not picked alone
            if before.endswith(("被", "由")) or PIVOT_BEFORE.search(before):
                role = "pivot"
            elif HEARD_BEFORE.search(before):
                role = "heard"
            elif before.endswith("比"):
                role = "object"  # 宋青比林满先说道: 林满 is compared, 宋青 speaks
            elif joiner in JOINERS:
                kind = JOINERS[joiner]
                if people[-1][1] == "object":
                    role = "object"  # 对林满和程棠说: both are spoken to
                elif kind == "joint" or together:
                    role = "joint"
                elif kind == "and":
                    role = "open"  # 宋青和林满说: together, or to 林满; not clear
                else:
                    role = "object"  # 他跟宋青说
            elif OBJECT_BEFORE.search(before):
                role = "object"
            else:
                role = "subject"
            people.append([word, role, m.end()])
        names = lambda rows: [self.canonical[w] for w, r, e in rows if self.kinds[w] == "name"]
        heard = [row for row in people if row[1] == "heard"]
        if heard and heard[-1] is [row for row in people if row[1] != "object"][-1]:
            word = heard[-1][0]
            return (self.canonical[word], []) if self.kinds[word] == "name" else (None, [])
        pivots = [row for row in people if row[1] == "pivot"]
        subjects = [row for row in people if row[1] in ("subject", "heard")]
        grouped = [row for row in people if row[1] in ("joint", "open")]
        if pivots or grouped:
            return None, sorted(set(names(pivots + subjects + grouped)))
        if not subjects:
            return (None, []) if possessed else None
        if possessed:
            return None, sorted(set(names(subjects)))
        if len(subjects) == 1:
            word = subjects[0][0]
            return (self.canonical[word], []) if self.kinds[word] == "name" else (None, [])
        if len(subjects) == 2:
            first, second = subjects
            between = clause[first[2]:clause.index(second[0], first[2])]
            if self.verbs(between):  # 宋青叮嘱林满说: 林满 is the one told
                return (self.canonical[first[0]], []) if self.kinds[first[0]] == "name" else (None, [])
        return None, sorted(set(names(subjects)))

    def group_before(self, text):
        """(None, who may be in the group) for a clause that says a group speaks: the people the walk back over the
        sentence finds (a joined subject is the group), or, when it finds one person, everyone named in the sentence
        (宋青看了林满一眼，两人齐声说: 宋青 and 林满). Never one person alone."""
        sentence = text[max(text.rfind(ch) for ch in BOUNDARY) + 1:]
        name, candidates = self.subject(sentence, False)
        if candidates:
            return None, candidates
        named = [self.canonical[m.group()] for m in self.tokens.finditer(sentence)
                 if self.kinds[m.group()] == "name" and sentence[m.end():m.end() + 1] != "的"]
        return None, sorted(set(named + ([name] if name else []))) if (named or name) else []

    def subject(self, text, tag):
        """(name, candidates): who acts in text, walking back from its end.

        tag: text ends right before a speaking verb, and the people in the verb's own clause decide (tag_subject);
        only when that clause names nobody does the walk go further back. Otherwise the person must open a clause
        (宋青已经按住她的手: 宋青). Objects, possessives and people after 让/叫/请 are skipped; a pronoun or someone not on
        the list as subject means nobody listed.
        """
        if tag:
            found = self.tag_subject(text)
            if found is not None:
                return found
            text = text[:max(text.rfind(ch) for ch in BOUNDARY + CLAUSE) + 1]
            tag = False
        pivot = []
        for m in reversed(list(self.tokens.finditer(text))):
            word = m.group()
            if OWNED.match(text, m.end()):
                continue  # 老周的徒弟, 她的手: not the subject
            before = text[:m.start()]
            if before.endswith(("被", "由")):  # 程棠被老周拦了下来：the one who stops him may be the one who speaks
                if self.kinds[word] == "name":
                    pivot.append(self.canonical[word])
                continue
            if OBJECT_BEFORE.search(before):
                continue
            if PIVOT_BEFORE.search(before):
                if self.kinds[word] == "name":
                    pivot.append(self.canonical[word])
                continue
            same_clause = tag and not any(ch in text[m.end():] for ch in BOUNDARY + CLAUSE)
            if not same_clause and not self.opens_clause(text, m.start()):
                continue
            if self.kinds[word] != "name":
                return None, sorted(set(pivot))
            name = self.canonical[word]
            if pivot:
                return None, sorted(set(pivot + [name]))
            group, at = [name], m.end()
            while not tag:  # 宋青和林满站在门口, 宋青、林满、程棠站在门口: any of them may speak
                joined = self.joined.match(text, at)
                if not joined:
                    break
                group.append(self.canonical[joined.group(1)])
                at = joined.end()
            if len(group) > 1:
                return None, sorted(set(group))
            return name, []
        return None, sorted(set(pivot))

    def before(self, segment, cross_paragraph=False):
        """The narration between the previous line (or the paragraph start) and this line: (name, candidates, basis)."""
        segment = segment.rstrip(SPACE)
        if not segment.strip():
            return None, [], None
        cut = max(segment.rfind(ch) for ch in BOUNDARY)
        lead = segment[cut + 1:]
        if lead.strip(SPACE):
            core = lead.rstrip(SPACE + "：:，,")
            clause_start = max(core.rfind(ch) for ch in CLAUSE) + 1
            last = core[clause_start:]
            for m in reversed(self.verbs(last)):
                if self.tail.fullmatch(last[m.end():]):
                    if cross_paragraph:
                        prefix = last[:m.start()]
                        cue = self.unspoken.search(prefix)
                        if cue and not any(t.start() <= cue.start() < t.end() for t in self.tokens.finditer(prefix)):
                            return None, [], None
                    return self.subject(core[:clause_start + m.start()], True) + ("tag",)
            basis = "colon" if lead.rstrip(SPACE).endswith(("：", ":")) else "beat"
            return self.subject(core, False) + (basis,)
        # The line follows a whole sentence: the one acting in it, right before the line, is taken as the speaker.
        body = segment[:cut]
        return self.subject(body[max(body.rfind(ch) for ch in BOUNDARY) + 1:], False) + ("beat",)

    def after(self, segment):
        """The narration right after the line. Only a speaking verb in its first clause makes it a tag (“……”老周说。);
        a clause that ends in a colon opens the next line instead."""
        m = re.match("[^%s%s]*" % (BOUNDARY, CLAUSE), segment)
        clause = m.group()
        if segment[m.end():m.end() + 1] in ("：", ":"):
            return None, [], None
        verbs = self.verbs(clause)
        if verbs:
            return self.subject(clause[:verbs[0].start()], True) + ("tag",)
        name = self.subject(clause, False)[0]
        return None, [name] if name else [], None  # “走。”老周转身出门。 may be his line; not on its own evidence


def inspect(text, paragraph_mode="blank", names=(), voices=None, long_lines=False):
    """long_lines (r5.54, --long-lines): also flag lines of LONG_MIN Han characters or more; off unless asked for."""
    if paragraph_mode not in {"blank", "line"}:
        raise ValueError("paragraph_mode must be blank or line")
    if voices is not None:
        speakers, narration_only = load_voices(voices)
        cases = voices.get("cases", [])
    else:
        speakers, narration_only, cases = {}, [], []
    aliases = {name: sorted(set([name] + speakers.get(name, {}).get("aliases", [])), key=len, reverse=True)
               for name in list(dict.fromkeys(list(names) + list(speakers)))}
    who = Who(aliases)
    starts = [0] + [m.end() for m in re.finditer("\n", text)]

    def line_of(offset):
        return bisect.bisect_right(starts, offset)

    lines, flags = [], []
    narration = 0  # Han characters of paragraphs with no line, since the last line (r5.49)
    last_sentence = ""  # the last sentence of the paragraph before (r5.53, --exchanges)
    tagged = False  # the narration after the line before was its speaking tag (r5.53)
    colon_above = None  # the sentence a colon closes at the end of the paragraph before, which has no line (r5.54)
    for index, (start, paragraph) in enumerate(paragraphs_of(text, paragraph_mode)):
        quotes = [m for m in QUOTE.finditer(paragraph) if next(g for g in m.groups() if g is not None).strip()]
        if not quotes:
            narration += han_count(paragraph)
            last_sentence = tail_sentence(paragraph)
            tagged = False
            colon_above = colon_sentence(paragraph)
            continue
        above, colon_above = colon_above, None
        if above and (paragraph[:quotes[0].start()].strip(SPACE) or listed_line(paragraph, quotes)):
            above = None  # only for a line that opens the paragraph, and not for a list
        for k, m in enumerate(quotes):
            said = next(g for g in m.groups() if g is not None)
            if not said.strip():
                continue
            previous_end = quotes[k - 1].end() if k else 0
            next_start = quotes[k + 1].start() if k + 1 < len(quotes) else len(paragraph)
            bridge = paragraph[m.end():next_start]
            post = who.after(bridge)
            tag_after = post[2] == "tag"
            pre = who.before(paragraph[previous_end:m.start()])
            if k == 0 and above:
                pre = who.before(above, cross_paragraph=True)
                if pre[2] != "tag":  # only a speaking tag in the paragraph above names the speaker (r5.54 review: 拆开信、门外传来声音 are not)
                    pre = (None, sorted(set(pre[1] + ([pre[0]] if pre[0] else []))), None)
            if post[2] is None and post[1] and k + 1 < len(quotes) and bridge.rstrip(SPACE).endswith(("，", ",")):
                # “三斤。”宋青又压了一次价，“多的算我请你……”: a beat between two parts of one line, set off by a
                # comma, belongs to the one speaking both parts, if the whole bridge has no other subject.
                joint = who.before(bridge)
                if joint[0] and joint[0] == post[1][0]:
                    post = (joint[0], [], "beat")
            if post[2] in ("tag", "beat") and post[0]:
                speaker, candidates, basis = post
            elif post[2] == "tag":  # “……”他说。 someone not on the list, or 他 may point back
                speaker, candidates, basis = None, sorted(set(post[1] + pre[1] + ([pre[0]] if pre[0] else []))), None
            elif pre[0]:
                speaker, candidates, basis = pre
            else:
                speaker, candidates, basis = None, sorted(set(pre[1] + post[1])), None
            before = paragraph[previous_end:m.start()]
            if k and tagged:  # “……”老许说。“……”: the tag names the line before, not this one
                before = after_tag(before)
            before = re.sub(r"[\r\n]+", "", before).strip(SPACE)
            entry = {"line": line_of(start + m.start()), "text": m.group(), "speaker": speaker,
                     "candidates": candidates if speaker is None else [], "basis": basis if speaker else None,
                     "han": han_count(said), "flags": [], "paragraph": index + 1,
                     "narration_before": narration if k == 0 else 0,
                     "before": tail_sentence(before) if before else (last_sentence if k == 0 else ""),
                     "order": len(lines)}
            tagged = tag_after
            narration = 0
            for word in WRITTEN:
                if word in said:
                    entry["flags"].append({"kind": "written", "word": word,
                                           "note": "书面词“%s”进了台词：看人物会不会这样说" % word})
            if speaker and speaker in speakers:
                for word in speakers[speaker].get("avoid", []):
                    if word in said and word not in WRITTEN:
                        entry["flags"].append({"kind": "avoid", "word": word,
                                               "note": "按本书的口吻表，%s不说“%s”" % (speaker, word)})
            for item in narration_only:
                if narration_hit(said, item):
                    entry["flags"].append({"kind": "narration", "word": item["text"],
                                           "note": narration_note(item, cases)})
            if long_lines and entry["han"] >= LONG_MIN:
                entry["flags"].append({"kind": "long", "word": "", "note": LONG_NOTE % entry["han"]})
            lines.append(entry)
            if entry["flags"]:
                flags.append(entry)
        tail = paragraph[quotes[-1].end():]
        last_sentence = tail_sentence(after_tag(tail) if tagged else tail)
        if not last_sentence and tail.strip(SPACE + "\r\n") and not han_count(tail) and not tagged:
            last_sentence = tail_sentence(paragraph)  # 他们管这叫“回潮”。: the quoted word is part of the narration
        tagged = False
    by_speaker = {name: [x for x in lines if x["speaker"] == name] for name in aliases}
    return {
        "speakers": {name: items for name, items in by_speaker.items() if items},
        "unattributed": [x for x in lines if x["speaker"] is None],
        "attribution_review": attribution_review(lines),
        "flagged": flags,
        "dialogue_lines": len(lines),
        "voices": {name: speakers[name].get("voice", "") for name in speakers},
        "limits": LIMITS,
        "long_lines_listed": bool(long_lines),
    }


def attribution_review(lines):
    """Places where a reader may lose who is speaking (r5.49). Runs: RUN_MIN or more lines in a row with no stated speaker
    and no stretch of narration between them; after narration: a line with no stated speaker that comes after
    NARRATION_BREAK Han characters of narration since the line before; by action: lines given to the person who acts
    right before them (basis "beat"), which readers also take that way. Only places, never a speaker guessed from turns."""
    runs, current, last_named = [], [], None
    after_narration = []

    def close():
        if len(current) >= RUN_MIN:
            runs.append({"first_line": current[0]["line"], "last_line": current[-1]["line"], "count": len(current),
                         "last_named_before": last_named})

    previous = None
    for entry in lines:
        broke = previous is not None and entry["narration_before"] >= NARRATION_BREAK
        if broke or entry["speaker"] is not None:
            close()
            current = []
        if broke:
            last_named = None  # after a stretch of narration the speaker named before it is no anchor for the reader
        if entry["speaker"] is None:
            if broke:
                after_narration.append({"line": entry["line"], "narration_han": entry["narration_before"],
                                        "candidates": entry["candidates"]})
            current.append(entry)
        else:
            last_named = {"speaker": entry["speaker"], "line": entry["line"]}
        previous = entry
    close()
    by_action = [{"line": x["line"], "speaker": x["speaker"]} for x in lines if x["speaker"] and x["basis"] == "beat"]
    return {"runs": runs, "after_narration": after_narration, "by_action_before": by_action,
            "settings": {"run_min": RUN_MIN, "narration_break_han": NARRATION_BREAK}}


def narration_hit(said, item):
    """A narration word in a line, outside the longer words the book lets characters say (except)."""
    word, kept = item["text"], item.get("except", [])
    covered = set()
    for term in kept:
        for m in re.finditer(re.escape(term), said):
            covered.update(range(m.start(), m.end()))
    return any(not set(range(m.start(), m.end())) <= covered for m in re.finditer(re.escape(word), said))


def narration_note(item, cases):
    note = ("叙述里的词“%s”进了台词：这个人在这个场合、对这个人、为了这个目的，会不会这么说？（可能是语域错位，也可能正是"
            "他的声口；这是提示，不是判定）" % item["text"])
    if "say" in item:
        note += "本书记过的口头说法：“%s”，只作参考，换词先看意思变没变" % item["say"]
    decided = [c for c in cases if c["word"] == item["text"]]
    if decided:
        note += "；作者逐处定过：" + "；".join("第%d章%s%s→%s（%s，只管那一处）" % (
            c["chapter"], c.get("speaker", ""), c["was"], c["now"], c["decided"]) for c in decided)
    return note


def exchanges_report(report):
    """Every line in the order it stands in the text, with the narration right before it and its speaker (r5.53).
    A blank line where NARRATION_BREAK or more Han characters of whole narration paragraphs come between."""
    every = sorted([x for items in report["speakers"].values() for x in items] + report["unattributed"],
                   key=lambda x: x["order"])
    out = ["", "== 按来回读（只列位置和前文，不是判定）"]
    for x in every:
        if x.get("narration_before", 0) >= NARRATION_BREAK:
            out.append("")
        who = x["speaker"] or ("待认：%s" % "、".join(x["candidates"]) if x["candidates"] else "待认")
        out.append("  第 %d 行  %s%s" % (x["line"], ("（前文：%s）" % x["before"]) if x.get("before") else "", x["text"]))
        out.append("      说话人：%s" % who)
    out.append("  怎样读：每个来回问——刚发生了什么，谁在场，他此刻最挂心什么，会先出什么声，对方接不接这个回答"
               "（对白专项“这一刻会出什么声”“顺着回应改”）；拿掉这一来一回少了什么；新加的话带没带出新的事实、规矩、数目"
               "（带出了，列给作者）。靠人读，不计数。只润色的任务，这一步只记建议，不往正文里加话。")
    return out


def text_report(report, exchanges=False):
    out = ["台词分栏：%s（sha256 %s…），台词 %d 处" % (report.get("file", ""), report.get("sha256", "")[:12],
                                                 report["dialogue_lines"])]
    for name, items in report["speakers"].items():
        voice = report["voices"].get(name)
        out += ["", "== %s，%d 处%s" % (name, len(items), "（%s）" % voice if voice else "")]
        out += ["  第 %d 行  %s%s" % (x["line"], x["text"], "（按前面%s的动作认的）" % name if x["basis"] == "beat" else "")
                for x in items]
    if report["unattributed"]:
        out += ["", "== 叙述里没写明是谁说的，%d 处（按上下文自己认）" % len(report["unattributed"])]
        out += ["  第 %d 行  %s%s" % (x["line"], x["text"], "（可能是：%s）" % "、".join(x["candidates"])
                                    if x["candidates"] else "") for x in report["unattributed"]]
    review = report.get("attribution_review") or {}
    places = []
    for run in review.get("runs", []):
        named = run["last_named_before"]
        places.append((run["first_line"], "  第 %d—%d 行：连着 %d 句没写明是谁说的%s" % (
            run["first_line"], run["last_line"], run["count"],
            "（前面最后写明的是第 %d 行%s）" % (named["line"], named["speaker"]) if named else "")))
    for item in review.get("after_narration", []):
        places.append((item["line"], "  第 %d 行：隔了一段叙述（约 %d 个汉字）再开口，没写是谁%s" % (
            item["line"], item["narration_han"], "（可能是：%s）" % "、".join(item["candidates"]) if item["candidates"] else "")))
    for item in review.get("by_action_before", []):
        places.append((item["line"], "  第 %d 行：按前面%s的动作认的（读者也会这样认）" % (item["line"], item["speaker"])))
    if places:
        out += ["", "== 谁在说：要回头读的地方（只是位置，不是判定）"]
        out += [text for _, text in sorted(places, key=lambda x: x[0])]
        out.append("  怎样看：两个人一来一回、读者跟得上的，可以不动；新人插话、换了人、隔了叙述再开口、前一句其实是另一个人接的地方，"
                   "补“某某说／问”就够，不必加动作；按前面动作认错了的，补上真正说话的人；原稿没有依据定是谁说的，不猜，问作者"
                   "（[对白专项]“谁在说”）".replace("[对白专项]", "对白专项"))
    if report["flagged"]:
        out += ["", "== 要再读一遍的，%d 处" % len(report["flagged"])]
        for x in report["flagged"]:
            out.append("  第 %d 行  %s" % (x["line"], x["text"][:30] + ("…" if len(x["text"]) > 30 else "")))
            out += ["      " + f["note"] for f in x["flags"]]
    out += ["", "先只动句子里面（r5.54）：办的事、给的信息不增不减；只润色的任务不动引号里的句读，想到的列成建议。"
                "逐句问四件事：这词像不像他说的（声口）？他此刻对谁说、为什么说、急不急（急的人也可以把话说完整，对方看得见的"
                "东西常常不必说全；话短了，判断还要落得到事情上、对方接得住）？叙述层的词进了台词没有（语域错位；"
                "他身份里本来就说的术语、行话不算）？短，是他的脾气，还是写的人在省字（口令、报数、念单子、登记核对时的一问一答"
                "本来就短，不改，句号也不并；语气词不为凑口语句句挂一个，也不把该有的那一声拿掉）？四问回到一处：这个人在这个场合、对这个人、为了这个目的，会不会这样说。"
                "再问两样（r5.54）：这句话带着他此刻的态度吗（只问情绪当口和关系要紧的几句：换个人听要不要改；放到事情发生以前"
                "能不能一字不改地说；答不出也可以是他有意说平，惜字的人不因为这一问多说话；小字、称呼不成套地用；定不出态度的列给作者，不猜）？只有 AI 才会这样说吗（照对白专项那一节"
                "逐句问；家常和闲下来的场面再整场看一眼：是不是人人说的都对、都全、都顺、都配合，读下来分不分得出谁是谁；办急事、出勤抢险的场人人短、人人答得上是本分；那一节的表里每一问同一行写着什么时候不算毛病；不为这一问添话、添人）？"
                "是问法，不计数。",
            report["limits"]]
    if exchanges:
        out += exchanges_report(report)
    return "\n".join(out)


def utf8_stdio():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("chapter", type=Path)
    parser.add_argument("--paragraph-mode", choices=("blank", "line"), default="blank")
    parser.add_argument("--names", default="", help="speakers to sort by, separated by commas (，、 also work)")
    parser.add_argument("--voices", type=Path, help="the book's voice file (speakers, aliases, avoid, narration_only)")
    parser.add_argument("--format", choices=("text", "json"), default="text")
    parser.add_argument("--exchanges", action="store_true",
                        help="also list every line in order with the narration right before it (r5.53)")
    parser.add_argument("--long-lines", action="store_true",
                        help="also list lines of %d Han characters or more, only where they are; a long line is not a "
                             "fault, and without this option they are not listed (r5.54)" % LONG_MIN)
    args = parser.parse_args()
    try:
        data = args.chapter.read_bytes()
        names = [n.strip() for n in re.split(r"[,，、]", args.names) if n.strip()]
        voices = json.loads(args.voices.read_text(encoding="utf-8")) if args.voices else None
        report = inspect(data.decode("utf-8-sig"), args.paragraph_mode, names, voices, args.long_lines)
        report.update({"file": str(args.chapter), "sha256": hashlib.sha256(data).hexdigest()})
        print(text_report(report, args.exchanges) if args.format == "text" else json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    except (OSError, UnicodeError, ValueError, TypeError) as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    sys.exit(main())

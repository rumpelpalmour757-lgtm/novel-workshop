#!/usr/bin/env python3
"""r5.7: four refinements of existing evidence checks, from the 2026-10-17 breakdown record of a reference work's
opening (version 18, segments 16-21). Each one sharpens a sentence the workshop already had; none is a new rule, and
every example is new and neutral (nothing from the reference work is in this package).

1. A rule the narrator states outright is new direct evidence; a review does not ask for an experiment on the page.
   Only a conclusion still inside a character's reasoning is recorded as that character's judgment.
2. An absolute statement ("only one bed in the room") covers what it names, not the whole building.
3. A character's offhand "at last" or "first time" is read in its situation before it is checked as a fact.
4. In a run of samples, an earlier "not shown yet" holds up to that segment only; later evidence updates it.

These tests only hold where each refinement is written and that it is written once. Whether reviews get better for
it is not tested and has not been evaluated.
"""
import os
from pathlib import Path
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
REFS = ROOT / "skills" / "novel-workshop" / "references"


def section(name, heading):
    text = (REFS / name).read_text(encoding="utf-8")
    start = text.index("\n## " + heading + "\n")
    end = text.find("\n## ", start + 1)
    return text[start:] if end == -1 else text[start:end]


class EvidenceRefinements(unittest.TestCase):
    def test_a_rule_the_narrator_states_is_new_evidence(self):
        evidence = section("continuity.md", "动作状态与证据等级")
        example = evidence[evidence.index("原创示例：前文“她不知道渡船今天开不开"):]
        example = example[:example.index("\n\n")]
        self.assertIn("叙述者明确说出的规则", example)
        self.assertIn("不要求先写出试验的过程", example)
        self.assertIn("交作者确认", example)

    def test_an_absolute_statement_covers_what_it_names(self):
        checks = section("continuity.md", "衔接检查")
        self.assertIn("先看它管多大的范围", checks)
        self.assertIn("范围外的不算", checks)

    def test_offhand_speech_is_read_in_its_situation(self):
        checks = section("continuity.md", "衔接检查")
        self.assertIn("“总算用上了”", checks)
        self.assertIn("叙述明确写成事实的“第一次”才逐项核对前文", checks)

    def test_later_segments_update_an_earlier_not_yet(self):
        purpose = section("reference-study.md", "明确拆解用途")
        self.assertIn("前段记下的“还没写到”只管到那一段", purpose)
        self.assertIn("不固守旧的结论", purpose)
        # The older half of the rule stays: later evidence does not widen what an earlier segment confirmed.
        self.assertIn("不倒回去扩大前段已经确认的范围", purpose)

    def test_each_refinement_is_written_once(self):
        texts = {path.name: path.read_text(encoding="utf-8") for path in REFS.glob("*.md")}
        for phrase in ("叙述者明确说出的规则", "先看它管多大的范围", "“总算用上了”", "只管到那一段"):
            homes = sorted(name for name, text in texts.items() if phrase in text)
            self.assertEqual(len(homes), 1, (phrase, homes))


if __name__ == "__main__":
    unittest.main()

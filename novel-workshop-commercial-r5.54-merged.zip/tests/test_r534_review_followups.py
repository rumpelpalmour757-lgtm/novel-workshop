#!/usr/bin/env python3
"""r5.34: the follow-ups to the review of r5.32 the author forwarded on 2026-10-23.

The review made five points. Points 1 and 2 (images had no record of which parts the author takes, no carry-over to
the next chapter, no pick-from-candidates flow) were partly met by r5.33's inspiration library; r5.34 adds what was
missing. Points 3 and 4 touch defaults, so the workshop drafted candidates and the author approved both
("批准，按这段改"): constitution NWC-1.5 amends CON-011 (the four beats are for confrontations; other scenes stand on
what changes; the three scene checks are literal hints, a hit may be kept with a reason of its own; the ready-made
smile moves to the optional stock reactions), and the stakes module asks whether a stronger person could do the
protagonist's job instead and counts gains and payoffs. The review's small example (a bottle "broken in two") is fixed.
Point 5 (what the tests cannot show) is written down; the limited text comparison waits for the author's images.

These tests pin the text the author approved, the gate and linter behaviour, the library fields and the wiring. They
cannot show that chapters read better; that is for the author to read.
"""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
GUARD = SKILL / "scripts" / "workflow_guard.py"
LINT = SKILL / "scripts" / "prose_lint.py"
LIBRARY = SKILL / "scripts" / "inspiration_library.py"
V15 = "版本：NWC-1.5（2026-10-23，作者批准修订 CON-011：对手戏照旧，别的场靠变化立住，检测命中可以逐处写理由保留）"
V16 = "版本：NWC-1.6（2026-10-23，作者批准修订 CON-012：素材落在人的动作和感知里，不要求每件陈设都变成道具；NWC-1.5 同日修订了 CON-011）"  # r5.35: NWC-1.6 amends CON-012


def read(relative):
    path = SKILL / relative
    return path.read_text(encoding="utf-8") if path.is_file() else ""


def section(text, heading):
    start = text.find("\n## " + heading)
    if start == -1:
        return ""
    end = text.find("\n## ", start + 4)
    return text[start:end if end != -1 else len(text)]


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(script, *args, cwd=None):
    proc = subprocess.run([sys.executable, "-I", "-B", str(script), *map(str, args)], cwd=cwd, capture_output=True,
                          text=True, encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


class Constitution(unittest.TestCase):
    """NWC-1.5: what the author approved on 2026-10-23 (the review's point 3)."""

    def test_con011_is_the_approved_text(self):
        text = read("CONSTITUTION.md")
        part = text[text.index("### CON-011"):text.index("### CON-012")]
        for phrase in ("对手戏、冲突戏（节拍卡上的核心博弈戏、动作危机戏）要有视角人物这一场必须拿到的具体结果",
                       "按四拍推进，晚进早出，停在翻转或新悬念出现的那一下",
                       "别的场（轻松的兑现、关系靠近、哀伤停留、探索奇观）不套“受阻—加码—翻转—切走”，靠关系、认知、行动准备或体验积累的变化立住，可以展开写",
                       "进场出场什么都没变的，才压成 100—200 字的过场",
                       "情绪直述、微动作和道具按这一场要做的事选用，不是每段都要落一个动作",
                       "跨章留意同一种反应、同一种物件操作、同一种四拍节奏反复出现，换个同义词不算改",
                       "`prose_lint.py` 的三项检测是字面提示：叙述里的命中逐处改写，或者逐处写明具体理由保留，审稿判断理由站不站得住；没命中也不等于这一场落了地",
                       "这一场靠她决定接手这门手艺立住",
                       "“嘴角扬起一抹笑”这类现成表情归可选的现成反应"):
            self.assertIn(phrase, part)
        # What stayed: the hard kind, the scope, the author's exceptions, the quantities for confrontations.
        for phrase in ("### CON-011 分场张力与正文具象（硬，戏剧判断靠编辑）", "整章写作、整章重写和整章审稿",
                       "作者对本书另有明确决定的（全知视角、有意的慢场景、直写情绪等），按作者的",
                       "重头对手戏开场 300 字内落下道具、过场 100—200 字、连续 5 段以上光台词要落地"):
            self.assertIn(phrase, part)
        self.assertNotIn("没有在场阻力的，压成 100—200 字的过场", part)

    def test_version_line_and_record(self):
        text = read("CONSTITUTION.md")
        # r5.49: NWC-1.7 (CON-011 amended again) replaced the version line; the NWC-1.6 and NWC-1.5 entries stay below.
        self.assertIn("版本：NWC-1.7（2026-11-01，作者批准 r5.49 修订方案（回复“按照你的想法去做”），按方案修订 CON-011", text)
        self.assertIn("NWC-1.6，2026-10-23（r5.35）", text)
        self.assertIn("## 二、十二条原则", text)
        self.assertIn("NWC-1.5，2026-10-23（r5.34）：作者转来一份对 r5.32 的审查报告", text)
        self.assertIn("作者看过后批准（“批准，按这段改”）", text)
        self.assertIn("十二条原则和其余条文没变。", text)
        self.assertIn("NWC-1.4，2026-10-23（r5.33）", text)

    def test_the_registry(self):
        registry = json.loads(read("assets/constitution-rules.json"))
        self.assertEqual((registry["version"], registry["date"]), ("NWC-1.7", "2026-11-01"))  # r5.49: NWC-1.7 amends CON-011
        rule = next(r for r in registry["rules"] if r["id"] == "CON-011")
        refs = [(r["type"], r.get("section") or r.get("contains") or r.get("name")) for r in rule["enforced_by"]]
        for ref in (("doc", "Change (这一场变了什么)"), ("script", "TURNING_TYPES = ("),
                    ("test", "test_r534_review_followups.SceneScope.test_an_other_scene_stands_on_what_changes"),
                    ("test", "test_r534_review_followups.SceneScope.test_other_scenes_are_not_judged_as_flat_scenes"),
                    ("test", "test_r534_review_followups.SceneScope.test_a_narration_hit_kept_with_its_own_reason_passes")):
            self.assertIn(ref, refs)
        self.assertNotIn(("test", "test_r532_scene_dramaturgy.Gate.test_scene_rule_hits_in_the_narration_are_rewritten_not_kept"),
                         refs)

    def test_the_approval_is_recorded_in_the_personal_build(self):
        record = ROOT / "maintenance" / "constitution-nwc1.5-2026-10-23" / "APPROVAL.json"
        if not record.is_file():
            self.skipTest("no maintenance folder next to the skills (only the personal build has it)")
        approval = json.loads(record.read_text(encoding="utf-8"))
        self.assertEqual((approval["constitution_version"], approval["author_decision"]), ("NWC-1.5", "批准，按这段改"))
        self.assertIn("别的场（轻松的兑现、关系靠近、哀伤停留、探索奇观）不套“受阻—加码—翻转—切走”", approval["approved_text"]["preview"])


OTHER_CARD = """# Scene Beat Card (单场戏剧节拍卡)

- **Scene ID / Chapter**: S1 / 第七章
- **Scene Type**: `Core Conflict (核心博弈戏)`
- **POV Character & Sensory Limit (视角人物与感知盲区)**: 宋青；看不见柜台后面的账本
- **Polarity Shift (局势极性变化)**: `[求人] -> [欠人]`
- **Core Prop Anchor (核心交互道具)**: 当票、车钥匙
1. **入场动作与诉求 (Goal - Late In)**: 拍下当票，要老范今天就把表还她
2. **对手反制与阻碍 (Obstacle & Escalation)**: 老范说五点关门，利息还差一半
3. **破局点/意外转折 (The Turn)**: 她把车钥匙押在柜台上
4. **出场悬念钩子 (Exit Hook - Early Out)**: 钥匙留在柜台上，她抱着表出门
- **禁止直接概括的过程**: 押钥匙那几句一步一步写
- **潜台词冰山 (Subtext)**: 谈利息，争的是谁求谁
- **情绪生理化映射 (Embodiment)**: 她把钥匙圈在指头上转了两圈才放下

- **Scene ID / Chapter**: S2 / 第七章
- **Scene Type**: Transition (过场桥段-限200字)

- **Scene ID / Chapter**: S3 / 第七章
- **Scene Type**: Other (其他场：兑现/靠近/停留/探索)
- **POV Character & Sensory Limit (视角人物与感知盲区)**: 宋青
- **Change (这一场变了什么)**: 不肯开口求人 -> 头一回跟母亲说了借钱的事
"""
CHAPTER = ("第七章　当铺\n\n宋青进门时，铁栅已经拉下一半。她把当票拍在柜台上。\n\n"
           "老范拨了一下算盘：“五点关门，利息还差一半。”\n\n她摸出车钥匙，在指头上转了两圈，押在当票上。\n\n"
           "老范把表从栅栏底下推出来，钥匙留在了柜台上。\n\n出了门，雨刚停，她把表揣进怀里往车站走。\n\n"
           "晚上她给母亲打了电话，说了借钱的事。\n")
MATERIAL = """# 声音样本与现场素材卡

## 声音样本：作者自己的原文

- **样本来源**：第六章第 29—35 行（作者原文，已采纳）
- **原文**：
  程棠把钥匙在指头上转了一圈：“明早再来？”

## 现场素材：每个核心场一块

- **Scene ID**：S1
- **看得见、摸得到的东西**：拉下一半的铁栅；算盘；柜台上的当票
- **出处**：灵感库 IMG-001
- **和已定设定不一样的**：无

- **Scene ID**：S3
- **看得见、摸得到的东西**：公用电话亭里亮着的一盏小灯
- **出处**：补写
- **和已定设定不一样的**：无
"""


class SceneScope(unittest.TestCase):
    """NWC-1.5 in the beat card and the delivery gate, run through workflow_guard.py like a real task."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.work = Path(self.tmp.name)
        self.events = 0

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, name, text):
        (self.work / name).write_bytes(text.encode("utf-8"))

    def guard_run(self, *args):
        code, out, err = run(GUARD, *args, cwd=self.work)
        try:
            return code, json.loads(out)
        except ValueError:
            return code, {"raw": out + err}

    def project(self, card=OTHER_CARD, chapter=CHAPTER, material=None):
        self.write("draft.md", chapter)
        self.write("beats.md", card)
        checks = [{"id": "prose", "type": "prose"}, {"id": "beats", "type": "scene_beats", "source": "beats.md"}]
        if material is not None:
            self.write("material.md", material)
            checks.append({"id": "material", "type": "voice_material", "source": "material.md"})
        self.write("checks.json", json.dumps({"candidate": "draft.md", "checks": checks}))
        code, out = self.guard_run("start", "state.json", "--task-id", "ch7", "--spec", "checks.json")
        self.assertEqual(code, 0, out)
        return self.guard_run("check", "checks.json")

    def review(self, scenes, dispositions=(), inputs=("beats.md",)):
        import hashlib
        review = {"schema": "editorial-review/2", "verdict": "PASS",
                  "candidate_sha256": hashlib.sha256((self.work / "draft.md").read_bytes()).hexdigest(),
                  "reviewer": {"mode": "self_check", "label": "测试数据：只验证结构"},
                  "checked_against": ["测试数据：节拍卡"], "inputs_read": list(inputs),
                  "evidence": [{"in": "candidate", "quote": "她把当票拍在柜台上"}], "issues": [],
                  "counter_evidence": "测试数据，不是真实文学审稿。", "scenes": scenes,
                  "machine_dispositions": [{"id": key, "decision": "keep", "reason": reason} for key, reason in dispositions]}
        self.write("review.json", json.dumps(review, ensure_ascii=False))
        self.events += 1
        return self.guard_run("record", "state.json", "--event-id", "r%d" % self.events, "--review", "review.json")

    @staticmethod
    def scene(key="S1"):
        return {"id": key, "polarity_shifted": True, "prop_embodiment_score": 4, "note": "求人到欠人，当票和车钥匙在柜台上推来推去"}

    def test_the_card_has_the_other_type(self):
        card = read("assets/scene-beat-card.md")
        self.assertIn("Other (其他场：兑现/靠近/停留/探索)", card)
        self.assertIn("- **Change (这一场变了什么)**:", card)
        self.assertIn("其他场（Other：轻松的兑现、关系靠近、哀伤停留、探索奇观）填 Scene ID、Scene Type、POV 和 Change", card)
        guard = load(GUARD, "r534_guard")
        self.assertEqual(guard.scene_type("Other (其他场：兑现/靠近/停留/探索)"), "other")
        self.assertIsNone(guard.scene_type(card.split("- **Scene Type**:")[1].splitlines()[0]))  # the unfilled line

    def test_an_other_scene_stands_on_what_changes(self):
        guard = load(GUARD, "r534_guard_card")
        scenes, problems = guard.read_beat_card(OTHER_CARD)
        self.assertEqual(problems, [])
        other = next(s for s in scenes if s["id"] == "S3")
        self.assertEqual((other["type"], other["change"]), ("other", "不肯开口求人 -> 头一回跟母亲说了借钱的事"))
        self.assertNotIn("polarity", other)
        for bad, why in ((OTHER_CARD.replace("不肯开口求人 -> 头一回跟母亲说了借钱的事", ""), "empty: Change"),
                         (OTHER_CARD.replace("不肯开口求人 -> 头一回跟母亲说了借钱的事", "无变化"), "Change must say what"),
                         (OTHER_CARD.replace("- **POV Character & Sensory Limit (视角人物与感知盲区)**: 宋青\n", ""), "empty: POV")):
            with self.subTest(why=why):
                scenes, problems = guard.read_beat_card(bad)
                self.assertTrue(any(why in p for p in problems), problems)
        code, out = self.project()
        self.assertEqual(out["status"], "GREEN", out)

    def test_other_scenes_are_not_judged_as_flat_scenes(self):
        self.project()
        code, out = self.review([self.scene(), dict(self.scene("S3"), polarity_shifted=False)])
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertIn("S3 (other)", out["message"])
        self.assertIn("narrative_function", out["message"])
        code, out = self.review([self.scene()])
        self.assertEqual(code, 0, out)

    def test_a_narration_hit_kept_with_its_own_reason_passes(self):
        code, out = self.project(chapter=CHAPTER.replace("出了门，雨刚停，", "出了门，空气仿佛凝固了，"))
        items = [(item["id"], item.get("rule"), item.get("in_quote")) for item in out["review_items"]]
        self.assertEqual([(x[1], x[2]) for x in items], [("tension-telling", False)], items)
        code, out = self.review([self.scene()], dispositions=[(items[0][0], "人物出门这一下要停住，作者本书的口吻")])
        self.assertEqual(code, 0, out)
        code, status = self.guard_run("status", "state.json")
        self.assertEqual(status["gate"]["editorial"], "PASS[self_check]")

    def test_a_kept_hit_still_needs_a_reason(self):
        code, out = self.project(chapter=CHAPTER.replace("出了门，雨刚停，", "出了门，空气仿佛凝固了，"))
        key = out["review_items"][0]["id"]
        code, out = self.review([self.scene()], dispositions=[(key, "好")])
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)

    def test_an_other_scene_may_have_material_but_a_transition_may_not(self):
        code, out = self.project(material=MATERIAL)
        material = next(c for c in out["checks"] if c["id"] == "material")
        self.assertEqual(material["actual"]["problems"], [], material)
        self.tearDown()
        self.setUp()
        code, out = self.project(material=MATERIAL.replace("- **Scene ID**：S3", "- **Scene ID**：S2"))
        problems = next(c for c in out["checks"] if c["id"] == "material")["actual"]["problems"]
        self.assertTrue(any("not core, action or other scenes on the beat card: S2" in p for p in problems), problems)


class SceneHints(unittest.TestCase):
    """prose_lint.py after NWC-1.5, and the two boundaries the review found, written down where they apply."""

    def lint(self, text, rules=None):
        report = load(LINT, "r534_lint").inspect_text(text, rules or {}, "blank")
        return [(f["rule"], f["quote"]) for f in report["findings"]]

    def test_the_ready_made_smile_is_a_stock_reaction(self):
        smile = "她嘴角扬起一抹笑，接过那张录取通知书。"
        self.assertEqual([r for r, q in self.lint(smile) if r in ("tension-telling", "stock-reaction")], [])
        self.assertIn(("stock-reaction", "嘴角扬起一抹"), self.lint(smile, {"hints": ["stock-reaction"]}))
        # The spec's own phrase stays telling: "意味深长" is the conclusion drawn for the reader.
        for telling in ("他眼中闪过一丝慌乱。", "老人露出意味深长的笑。", "气氛顿时紧张起来。", "他嘴角勾起一抹意味深长的笑。"):
            self.assertIn("tension-telling", [r for r, q in self.lint(telling)], telling)

    def test_the_messages_allow_a_reason(self):
        messages = load(LINT, "r534_lint_messages").HINT_MESSAGES
        for rule in ("floating-dialogue", "tension-telling", "weak-scene-ending"):
            self.assertIn("写明这一处的理由保留（CON-011）", messages[rule], rule)

    def test_the_weather_line_boundary_is_written_down(self):
        lines = ["“你去哪儿了？”", "“外面。”", "“外面哪儿？”", "“说了你也不知道。”", "“那你说说看。”"]
        self.assertIn("floating-dialogue", [r for r, q in self.lint("\n\n".join(lines))])
        broken = "\n\n".join(lines[:2] + ["门外的雨下大了。"] + lines[2:])
        self.assertNotIn("floating-dialogue", [r for r, q in self.lint(broken)])
        self.assertIn("五段光台词中间插一句“门外的雨下大了。”就不报", read("references/scene-dramaturgy.md"))
        self.assertIn("规范列的“嘴角勾起一抹意味深长的”照样算直述词，下结论的是“意味深长”", read("references/scene-dramaturgy.md"))
        self.assertIn("中间插一句景物（“门外的雨下大了。”）就断开不报", read("references/prose-audit.md"))

    def test_the_literal_polarity_boundary_is_written_down(self):
        guard = load(GUARD, "r534_guard_polarity")
        self.assertEqual(guard.polarity_states("安全 -> 平安"), ["安全", "平安"])
        self.assertIn("“安全 -> 平安”这样的近义词也能过", read("references/scene-dramaturgy.md"))

    def test_the_module_says_which_scenes_take_the_beats(self):
        part = section(read("references/scene-dramaturgy.md"), "4. 在工坊里怎样执行")
        for phrase in ("- **哪些场按四拍（NWC-1.5）**", "节拍卡填 Other，写清这一场让关系、认知、行动准备或体验积累变了什么",
                       "图里来的光、材质、旧法留在场里，不必都改成道具和微动作", "- **跨章**", "换个同义词不算改",
                       "其他场不写 `scenes`，它变了什么写进六个维度的“叙事功能”"):
            self.assertIn(phrase, part)

    def test_the_neighbours_follow(self):
        self.assertIn("是兑现、靠近、停留这类场的，在变化落定的地方收", read("references/planning.md"))
        self.assertIn("兑现、靠近、停留这类场在变化落定的地方收；哪一场都不写总结性收尾", read("references/pacing.md"))
        self.assertIn("放松、靠近、停留这类场，写出这一场让关系、认知、准备或体验变了什么（CON-011）", read("references/drafting.md"))
        self.assertIn("兑现、靠近、停留、探索这类场不按翻转判", read("references/prose-audit.md"))
        self.assertIn("兑现、靠近、停留、探索这类场，看它让关系、认知、准备或体验变了没有", read("references/adversarial-review.md"))
        self.assertIn("其他场（兑现、靠近、停留、探索）不写 `scenes`", read("references/quality-loop.md"))
        self.assertIn("其他场（Other）填 POV 和 Change，不写 `scenes`", read("references/execution.md"))
        self.assertIn("其他场（兑现、靠近、停留、探索）不写 scenes", json.loads(read("assets/editorial-review-template.json"))["note"])
        # r5.49: the checklist points to the choice of where the emotion lands; 2.1 (body reactions) is one of them.
        self.assertIn("整章写作里情绪、氛围直述词按这一场选落点", read("assets/sentence-dialogue-checklist.md"))
        self.assertIn("身体反应是其中一种），或者逐处写明理由保留（CON-011）", read("assets/sentence-dialogue-checklist.md"))
        audit = read("references/prose-audit.md")
        # r5.48: the rewrite is chosen by the scene (prose-audit "情绪直述的改法"); keeping with a reason stays.
        self.assertIn("按这一场要做的事改写（CON-011：情绪直述、微动作和道具按这一场选用，改法见下文“情绪直述的改法”），或者逐处写明理由保留", audit)
        self.assertIn("三项在叙述里的命中逐处改写，或者逐处写明这一处的理由保留，审稿判断理由站不站得住（NWC-1.5）", audit)
        tension = next(line for line in audit.splitlines() if line.startswith("| `tension-telling` |"))
        stock = next(line for line in audit.splitlines() if line.startswith("| `stock-reaction`（可选） |"))
        self.assertNotIn("嘴角", tension)
        self.assertIn("“嘴角扬起一抹笑”（r5.34 起从直述词挪到这里：它是动作，不是替读者下结论）", stock)
        skill = read("SKILL.md")
        level = next(line for line in skill.splitlines() if line.startswith("| L1 整章 |"))
        self.assertIn("`prose_lint.py` 三项分场检测在叙述里的命中逐处改写或写明理由保留", level)
        row = next(line for line in skill.splitlines() if "| [scene-dramaturgy.md](references/scene-dramaturgy.md) |" in line)
        self.assertIn("场内四拍（对手戏；其他场靠变化立住）", row)
        card = next(line for line in read("assets/delivery-gate-card.md").splitlines() if line.startswith("9. **"))
        self.assertIn("分场检测的命中逐处改或写理由", card)


class Stakes(unittest.TestCase):
    """The stakes module after the author approved the review's point 4."""

    def test_the_first_question_counts_gains(self):
        part = section(read("references/stakes.md"), "每章五问")
        self.assertIn("1. **谁得到或失去了什么？哪个旧期待兑现了？**", part)
        self.assertIn("得到也一样有分量：委托办成、能力第一次真管用、关系近了一步、日子好过了一点", part)
        self.assertIn("全章没人得到也没人失去，旧期待也没动，答不上", part)
        self.assertIn("平淡也不一定是缺损失", part)
        self.assertIn("不必每章新加受害者或损失", part)

    def test_who_underwrites(self):
        part = section(read("references/stakes.md"), "谁在兜底")
        for phrase in ("问两件事", "强的人全程在场不是毛病", "保镖一直跟着，账房照样靠验货、谈价",
                       "毛病是强的人一出手，主角做什么都不影响结果", "补法先找只有主角办得到的那一步",
                       "其次才是让强的人在关键一步上不在", "失联、分队、强者暂离不连着用",
                       "配角救场、导师帮忙照样可以成立", "](planning.md)"):
            self.assertIn(phrase, part)

    def test_the_remedies_start_from_what_is_missing(self):
        part = section(read("references/stakes.md"), "怎样补，怎样不补")
        self.assertIn("先分清缺的是什么。缺的是兑现时", part)
        self.assertIn("](serial-production.md)“从承诺走到兑现”", part)
        self.assertIn("缺的是压力时，补的次序：先给主角一个会失去的人", part)

    def test_the_example_is_physical(self):
        text = section(read("references/stakes.md"), "原创示例")
        self.assertNotIn("掰成两半", text)
        self.assertIn("把那一瓶里的药片倒在桌上数了数，分成两份，给了两个孩子", text)
        self.assertIn("这一例用的是兜底的第二种补法", text)
        self.assertIn("药送到了，可从头到尾没人可能失去什么，这份得到也就没有分量", text)

    def test_restatements_follow(self):
        self.assertIn("再看一眼谁在兜底——比主角强的人能不能替他办成这一章的关键目标", read("references/drafting.md"))
        self.assertIn("（谁得到或失去了什么、哪个旧期待兑现了，", read("references/quality-loop.md"))
        self.assertIn("一章里谁得到或失去什么", read("references/scene-dramaturgy.md"))
        row = next(line for line in read("SKILL.md").splitlines() if "](references/stakes.md) |" in line)
        self.assertIn("每章五问（得失和兑现、两难", row)
        self.assertIn("谁在兜底（强的人能不能替主角办成）", row)
        last = [line for line in read("references/stakes.md").splitlines() if line.strip()][-1]
        self.assertIn("2026-10-23 按转来的对 r5.32 的审查报告第四点，作者批准", last)


PICKED = {"id": "IMG-001", "kind": "person", "title": "镇上的老锁匠", "subject": "老锁匠",
          "visible": "瘦高，背有点驼；深色围裙；手背上一道旧疤",
          "source": {"type": "author_file", "file": "images/IMG-001.jpg", "sha256": "", "creator": "作者", "license": "作者自己的图"},
          "status": "picked", "take": ["体格：瘦高，背有点驼", "手背上一道旧疤"], "skip": ["围裙"],
          "adapt": "年纪改大十岁", "use": [{"chapter": 7, "scene": "S1"}], "conflicts": []}
CANDIDATE = {"id": "WEB-001", "kind": "light", "title": "顶上一盏吊灯", "subject": "锁匠铺",
             "visible": "顶上一盏吊灯，光圈很小，桌面以外都是暗的", "suggest": ["灯光：光圈很小"],
             "source": {"type": "link", "url": "https://example.org/lamp", "license": "未核，只作写作参考"},
             "status": "candidate", "use": [{"chapter": 7, "scene": "S1"}], "conflicts": []}
IMAGE = b"\x89PNG test bytes for the library"


class Library(unittest.TestCase):
    """inspiration_library.py: which parts the author takes, the card that carries them, and the subject filter."""

    def setUp(self):
        import hashlib
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        (self.root / "images").mkdir()
        (self.root / "images" / "IMG-001.jpg").write_bytes(IMAGE)
        picked = json.loads(json.dumps(PICKED))
        picked["source"]["sha256"] = hashlib.sha256(IMAGE).hexdigest()
        self.data = {"schema": "inspiration-library/1", "book": "测试", "note": "测试数据",
                     "entries": [picked, json.loads(json.dumps(CANDIDATE))]}

    def tearDown(self):
        self.tmp.cleanup()

    def save(self, data=None):
        path = self.root / "library.json"
        path.write_bytes(json.dumps(data or self.data, ensure_ascii=False).encode("utf-8"))
        return path

    def problems(self, data):
        code, out, err = run(LIBRARY, "check", self.save(data))
        return json.loads(out)["problems"]

    def changed(self, index, **fields):
        data = json.loads(json.dumps(self.data))
        for key, value in fields.items():
            if value is None:
                data["entries"][index].pop(key, None)
            else:
                data["entries"][index][key] = value
        return data

    def test_a_complete_record_passes(self):
        self.assertEqual(self.problems(self.data), [])

    def test_a_picked_entry_says_what_it_takes(self):
        # r5.35 (the r5.34 review, point 2): this is format 1, where take came later; a picked entry without it is valid
        # as in r5.33. check gives a notice instead of a problem, and card lists it as waiting, never as the whole image.
        for data in (self.changed(0, take=None), self.changed(0, take=[])):
            code, out, err = run(LIBRARY, "check", self.save(data))
            report = json.loads(out)
            self.assertEqual((code, report["problems"]), (0, []), out)
            self.assertTrue(report["notices"][0].startswith("IMG-001: picked without take"), report["notices"])
            code, out, err = run(LIBRARY, "card", self.save(data), "--chapter", "7")
            self.assertNotIn("整张：", out)
            self.assertNotIn("深色围裙", out)
            self.assertIn("- IMG-001", out.split("挑过但没写借哪几样的")[1])
        cases = ((self.changed(0, take="体格"), "IMG-001: take must be a list of short phrases"),
                 (self.changed(0, skip=[""]), "IMG-001: skip must be a list of short phrases"),
                 (self.changed(0, subject=" "), "IMG-001: subject must be a nonempty sentence"),
                 (self.changed(0, adapt=""), "IMG-001: adapt must be a nonempty sentence"),
                 (self.changed(1, take=["灯光"]), "WEB-001: take is the author's choice and only a picked entry has it"),
                 (self.changed(1, suggest="灯光"), "WEB-001: suggest must be a list of short phrases"),
                 (self.changed(1, colour="暖"), "WEB-001: unknown field(s) colour"))
        for data, problem in cases:
            with self.subTest(problem=problem):
                self.assertTrue(any(p.startswith(problem) for p in self.problems(data)), self.problems(data))

    def test_the_card_carries_the_parts_taken(self):
        code, out, err = run(LIBRARY, "card", self.save(), "--chapter", "7")
        self.assertEqual(code, 0, err)
        self.assertIn("- **看得见、摸得到的东西**：（IMG-001）体格：瘦高，背有点驼；手背上一道旧疤（本书改：年纪改大十岁；不借：围裙）", out)
        self.assertNotIn("深色围裙", out)
        self.assertNotIn("WEB-001）", out.split("还没找到图的")[0])  # a candidate is not material yet
        code, out, err = run(LIBRARY, "card", self.save(self.changed(0, take=["整张"], skip=None, adapt=None)), "--chapter", "7")
        self.assertIn("（IMG-001）整张：瘦高，背有点驼；深色围裙；手背上一道旧疤", out)

    def test_list_by_subject(self):
        path = self.save()
        code, out, err = run(LIBRARY, "list", path, "--subject", "老锁匠", "--format", "json")
        self.assertEqual([e["id"] for e in json.loads(out)], ["IMG-001"])
        code, out, err = run(LIBRARY, "list", path, "--subject", "锁匠铺")
        self.assertIn("WEB-001", out)
        self.assertIn("给：锁匠铺", out)
        self.assertNotIn("IMG-001", out)

    def test_the_template_shows_the_fields(self):
        template = json.loads(read("assets/inspiration-library-template.json"))
        picked, candidate = template["entries"][0], template["entries"][1]
        # r5.35: format 2 names what an image is for in subjects; the candidate in the template is one nobody has
        # looked at yet, so it has no suggest (suggest comes from looking).
        self.assertTrue({"subjects", "take", "skip", "adapt", "decision", "observation"} <= set(picked), picked)
        self.assertEqual(candidate["observation"], {"scope": "none"})
        self.assertNotIn("take", candidate)
        self.assertIn("作者挑中以后在 take 里一条一样写借哪几样", template["note"])
        self.assertIn("整张都用写“整张”", template["note"])


class Wiring(unittest.TestCase):
    """Where the image rules live (one module) and the entries that point to it."""

    def test_the_module(self):
        text = read("references/inspiration-library.md")
        self.assertIn("\n## 采用以后：跨章接续\n", text)
        for phrase in ("挑 4—6 张彼此不一样的给作者看", "每张写明来源网页和适合借的部分",
                       "工具只把图摆给作者、工坊自己看不到的，照实说没看到，只报编号和标题，请作者挑，不描述没看过的图",
                       "也可以只借某一张的某几样（“2 的布局、4 的灯光”），也可以全不要",
                       "搜不到、工具用不了：退回作者发图、作者用文字描述，或者照设定和前文原创，不硬凑图",
                       "工坊先实际看图，照看到的写“看得见的东西”", "**给谁用**（`subjects`）", "**适合借的部分**（`suggest`）",
                       "**借哪几样**（`take`）", "**不借的**（`skip`）", "**本书怎样改**（`adapt`）",
                       "一张图不必都变成道具或伏笔", "素材卡上分开写三种来源", "补出来的不说成图里有的",
                       "不另建一套事实库", "稳定的（人的体格、长相、惯常的穿着，一处地方的布局）记进人物卡、项目档案",
                       "这一场的（伤、换下的衣服、弄脏打坏的东西）记成这一章的状态", "](continuity.md)“持续状态”",
                       "图不在手边时不说重新看过图", "--subject 修车铺老板", "](reference-study.md)", "](../assets/project-template.md)"):
            self.assertIn(phrase, text)
        last = [line for line in text.splitlines() if line.strip()][-1]
        self.assertIn("同日按作者转来的对 r5.32 的审查报告第一、二点补", last)

    def test_the_entries(self):
        self.assertIn("前文借过图的人和地方，照前文和人物卡写，出处写前文，不说重新看过图", read("references/drafting.md"))
        self.assertIn("参考图（人物、地方、物件、光）不按本页拆文：记进本书的 [灵感库](inspiration-library.md)",
                      read("references/reference-study.md"))
        self.assertIn("参考图不填这张卡，记进本书的灵感库", read("assets/reference-source-template.md"))
        template = read("assets/project-template.md")
        self.assertIn("- 外观（按需）：稳定的外观（体格、长相、惯常的穿着）和这一章的状态（伤、换下的衣服、弄脏打坏的东西）分开记", template)
        self.assertIn("参考图记进本书的灵感库，写借哪几样、不借哪几样", template)
        card = read("assets/voice-material-card.md")
        for phrase in ("作者指定的，写“作者指定”和日期", "前文已经写过的，写“前文”和章、行或人物卡，不写“看了图”", "写“补写”"):
            self.assertIn(phrase, card)
        row = next(line for line in read("SKILL.md").splitlines() if "](references/inspiration-library.md) |" in line)
        for phrase in ("只想借一张图的某几样", "工坊推荐 4—6 张", "借哪几样、不借的、本书怎样改", "采用以后照文字记录跨章接续"):
            self.assertIn(phrase, row)
        self.assertIn("它没有图片搜索和选图界面", read("references/local-workbench.md"))

    def test_the_material_card_still_parses(self):
        guard = load(GUARD, "r534_guard_material")
        found, problems = guard.read_material_card(MATERIAL)
        self.assertEqual(problems, [])
        self.assertEqual(sorted(found["scenes"]), ["S1", "S3"])
        blank_found, blank_problems = guard.read_material_card(read("assets/voice-material-card.md"))
        self.assertTrue(blank_problems)


if __name__ == "__main__":
    unittest.main()

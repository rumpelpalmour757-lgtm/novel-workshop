#!/usr/bin/env python3
"""r5.60: the style-card block.

What the author decided (r5.60): the card library takes only the entries the author accepted (30 operations in 24
fields of 17 cards; the count stays 83); load prints directions only and the example tables with --examples; what a
voice looks like when overdone is printed after writing (review); the comparison of examples against opposite
phrasings counts the card set's global list too; copied leaves a find that is only a common four-character phrase
out of the list and gives three-character names as hints; a book config may name one fixed base card; the index
prints each card's genre. The guide says the same. Examples in these tests are invented here.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
SCRIPT = SKILL / "scripts" / "style_cards.py"
LIBRARY = SKILL / "assets" / "style-cards" / "cards.json"
GUIDE = SKILL / "references" / "style-cards.md"
# Everything the accepted entries do not touch, as one digest: the library with source.note and these 24 fields
# blanked (sort_keys, ensure_ascii=False). Computed on r5.59; the same on r5.60.
UNTOUCHED = "2da19ba40f3ab8f138ce78f620bfa2afaacb136d79cd184a05267aa3acb8f075"
TOUCHED = (
    ("angst-heartbreak-be", ("sections", "subtext_logic")), ("chapter-hook-cliffhanger", ("sections", "lexical_map")),
    ("chapter-hook-cliffhanger", ("sections", "subtext_logic")), ("cyber-wasteland-industrial", ("scene_triggers",)),
    ("cyberpunk-gibson-sprawl", ("scene_triggers",)), ("dihua-mastermind-misread", ("sections", "lexical_map")),
    ("dihua-mastermind-misread", ("sections", "subtext_logic")), ("elite-procedural-workplace", ("sections", "subtext_logic")),
    ("gritty-wasteland-survival", ("sections", "kinetic_verbs_text")), ("gritty-wasteland-survival", ("sections", "subtext_logic")),
    ("gritty-wasteland-survival", ("sections", "syntax_rhythm")), ("hardboiled-confrontation", ("sections", "kinetic_verbs_text")),
    ("hardboiled-confrontation", ("sections", "lexical_map")), ("hardboiled-confrontation", ("sections", "somatosensory")),
    ("hardboiled-confrontation", ("sections", "subtext_logic")), ("hardboiled-noir-chandler", ("sections", "subtext_logic")),
    ("hemingway-iceberg", ("sections", "kinetic_verbs_text")), ("high-kinetic-combat", ("conflicts_with",)),
    ("infinite-flow-rule-game", ("sections", "subtext_logic")), ("kafkaesque-absurd-bureaucracy", ("sections", "kinetic_verbs_text")),
    ("mortal-cultivation-pragmatic", ("sections", "subtext_logic")), ("slice-of-life-warmth", ("sections", "subtext_logic")),
    ("soulsborne-fragmented-lore", ("sections", "subtext_logic")), ("wei-jin-xuanxue-poetic", ("conflicts_with",)),
)
# (card, section, the wording that is now there, the wording that is gone)
REWORDED = (
    ("hardboiled-confrontation", "subtext_logic", "对话多半只说字面上的半句零碎生意经，真正的狠话和底牌用极其平淡的口吻抛出，留白由物理动作完成。", "永远只说"),
    ("hardboiled-confrontation", "somatosensory", "折射出压迫感。", "折射出压迫感："),
    ("hardboiled-confrontation", "kinetic_verbs_text", "即是无声的交锋：进攻的一方将钱或字据「拍」「压」「推」。", "进攻方动作"),
    ("hardboiled-confrontation", "lexical_map", "利益博弈多半不涉及", "利益博弈绝不涉及"),
    ("gritty-wasteland-survival", "subtext_logic", "依然要简短、克制、压得住场。", "压得住场\n"),
    ("gritty-wasteland-survival", "kinetic_verbs_text", "表现肌肉紧绷与物理对抗。", None),
    ("gritty-wasteland-survival", "syntax_rhythm", "避免冗长的定语从句。", None),
    ("hemingway-iceberg", "kinetic_verbs_text", "只写空间位移。", None),
    ("angst-heartbreak-be", "subtext_logic", "大悲到了极致，多半不写嚎啕大哭，而是", "绝不嚎啕大哭"),
    ("chapter-hook-cliffhanger", "subtext_logic", "钩子尽量和主线相关", "钩子必须和主线相关"),
    ("chapter-hook-cliffhanger", "lexical_map", "章首的钩子尽量具体：", "章首的钩子必须具体"),
    ("dihua-mastermind-misread", "subtext_logic", "写误会时，先严密写出", "必须严密写出"),
    ("dihua-mastermind-misread", "lexical_map", "配角脑补时，从他自己掌握的信息和秘密出发，", "脑补必须基于"),
    ("elite-procedural-workplace", "subtext_logic", "多半不靠喊口号赢。", "绝不靠喊口号赢"),
    ("hardboiled-noir-chandler", "subtext_logic", "不轻易相信任何人的眼泪", "绝不相信任何人的眼泪"),
    ("infinite-flow-rule-game", "subtext_logic", "- 多半不在表面力气上", "永远不在表面力气上"),
    ("kafkaesque-absurd-bureaucracy", "kinetic_verbs_text", "动作多半是办手续", "动作永远是办手续"),
    ("mortal-cultivation-pragmatic", "subtext_logic",
     "- 多半不为了面子硬拼，没有十成把握不轻易露底牌；打得过就挫骨扬灰不留后患，打不过当场远遁，不回头放狠话。", "绝不"),
    ("slice-of-life-warmth", "subtext_logic", "- 多半不说“我很关心你”：", "绝不说“我很关心你”"),
    ("soulsborne-fragmented-lore", "subtext_logic", "多半不完整交代前因后果", "绝不完整交代前因后果"),
)
STRONG_FORMAT = ("hardboiled-noir-chandler", "murakami-urban-melancholy", "japanese-light-novel-tsukkomi",
                 "rashomon-confessional-pov", "second-person-interactive-if", "scp-clinical-containment",
                 "classical-zhiguai-liaozhai", "chronicle-spring-autumn", "bullet-screen-livestream", "fourth-calamity-sandbox")


def run(*args):
    proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT), *map(str, args)], capture_output=True, text=True,
                          encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


def module():
    spec = importlib.util.spec_from_file_location("style_cards_r560_under_test", SCRIPT)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def card_of(data, cid):
    return next(c for c in data["cards"] if c["id"] == cid)


class Accepted(unittest.TestCase):
    def setUp(self):
        self.data = json.loads(LIBRARY.read_text(encoding="utf-8"))

    def test_only_the_accepted_entries_changed_the_library(self):
        code, out, err = run("check")
        self.assertEqual((code, json.loads(out)["status"], json.loads(out)["cards"]), (0, "OK", 83), out + err)
        self.assertEqual(self.data["source"]["cards_in_library"], 83)
        blank = json.loads(json.dumps(self.data))
        blank["source"]["note"] = ""
        for cid, path in TOUCHED:
            obj = card_of(blank, cid)
            for key in path[:-1]:
                obj = obj[key]
            obj[path[-1]] = None
        self.assertEqual(hashlib.sha256(json.dumps(blank, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest(), UNTOUCHED)
        raw = LIBRARY.read_bytes()
        self.assertEqual((json.dumps(self.data, ensure_ascii=False, indent=1) + "\n").encode("utf-8"), raw)  # layout kept

    def test_the_accepted_wording_is_in_and_the_declined_is_not(self):
        for cid, section, there, gone in REWORDED:
            text = card_of(self.data, cid)["sections"][section]
            self.assertIn(there, text, (cid, section))
            if gone:
                self.assertNotIn(gone, text, (cid, section))
        self.assertEqual(card_of(self.data, "cyber-wasteland-industrial")["scene_triggers"],
                         ["旧件拆解与义体土法维修", "重工业废墟探索", "重型机械超负荷出故障", "废土拾荒与回收站翻找"])
        self.assertEqual(card_of(self.data, "cyberpunk-gibson-sprawl")["scene_triggers"],
                         ["黑诊所里的尖端义体改装", "黑客潜入矩阵空间", "企业大楼脚下的贫民窟与高低科技反差", "巨型企业特工追杀"])
        self.assertEqual(card_of(self.data, "wei-jin-xuanxue-poetic")["conflicts_with"], ["high-kinetic-combat"])
        self.assertEqual(card_of(self.data, "high-kinetic-combat")["conflicts_with"], ["wei-jin-xuanxue-poetic"])  # E2 only
        self.assertEqual(card_of(self.data, "classical-wuxia-chivalry")["conflicts_with"], ["jinyong-orthodox-wuxia"])  # E1 declined
        # A4, C6, C16 stay; the six empty fields stay empty (B); no new card (F)
        self.assertIn("- 动作中断。", card_of(self.data, "tense-suspense-probe")["sections"]["kinetic_verbs_text"])
        self.assertIn("必须靠战士卡位", card_of(self.data, "dnd-tactical-adventure")["sections"]["subtext_logic"])
        self.assertIn("读者必须从三个人证词", card_of(self.data, "rashomon-confessional-pov")["sections"]["subtext_logic"])
        combat, gritty = card_of(self.data, "high-kinetic-combat"), card_of(self.data, "gritty-wasteland-survival")
        self.assertEqual([combat["sections"][k] for k in ("somatosensory", "example_before", "example_after")], ["", "", ""])
        self.assertEqual((gritty["lexical_shifts"], gritty["kinetic_verbs"], card_of(self.data, "urban-power-slap")["lexical_shifts"]), ({}, {}, {}))
        ids = {c["id"] for c in self.data["cards"]}
        self.assertFalse(ids & {"clear-fairytale-healing", "urban-hidden-supernatural"})
        blob = json.dumps(self.data["cards"], ensure_ascii=False)
        self.assertEqual([blob.count(w) for w in ("永远", "绝不", "必须", "严禁")], [9, 1, 5, 0])
        note = self.data["source"]["note"]
        for phrase in ("r5.48、r5.49 另有 42 处说明里无条件的硬限制", "r5.60 照作者认过的清单", "把停在冒号上的两句收完整",
                       "又把 16 处说明里无条件的“永远”“绝不”“必须”改写成了有条件的方向",
                       "有条件的方向；两张赛博卡的适用场景是工坊改写、作者认过的；补了一组不同用（conflicts_with）。"):
            self.assertIn(phrase, note)
        self.assertNotIn("逐条认过", note)  # the author accepted the list group by group
        self.assertNotIn("另收", note)

    def test_what_the_changed_entries_do(self):
        code, out, err = run("match", "--text", "办公室的电路过载，整层楼跳了闸", "--format", "json")
        self.assertEqual(json.loads(out)["hits"], [])  # r5.59: the piece 过载 hit the wasteland card
        code, out, err = run("match", "--text", "吊臂上的重型机械超负荷出故障", "--format", "json")
        self.assertEqual([h["id"] for h in json.loads(out)["hits"]], ["cyber-wasteland-industrial"])
        code, out, err = run("load", "wei-jin-xuanxue-poetic", "high-kinetic-combat")
        self.assertEqual(code, 2, out + err)
        self.assertIn("does not go together", json.loads(out)["error"])
        code, out, err = run("load", "classical-wuxia-chivalry", "high-kinetic-combat")
        self.assertEqual(code, 0, out + err)


class LoadPrintsDirections(unittest.TestCase):
    def setUp(self):
        self.data = json.loads(LIBRARY.read_text(encoding="utf-8"))
        self.mod = module()

    def test_no_example_table_no_model_passage_no_overuse_by_default(self):
        for card in self.data["cards"]:
            page = self.mod.render(self.data, [card])
            for title in ("### 腔调示例", "### 动作示例", "### 示范", "### 过量信号"):
                self.assertNotIn(title, page, card["id"])
            self.assertNotIn(card["sections"]["overuse"].strip(), page, card["id"])
            if card["sections"]["example_after"]:
                self.assertNotIn(card["sections"]["example_after"], page, card["id"])
            self.assertIn(card["sections"]["subtext_logic"].strip(), page)
            self.assertIn("### 句子", page)
            self.assertIn(self.mod.ONLY_DIRECTIONS, page)
        code, out, err = run("load", "slice-of-life-warmth")
        self.assertEqual(code, 0, out + err)
        self.assertNotIn("这种腔调大概是", out)
        self.assertIn("--examples", out)
        self.assertIn("review", out)

    def test_examples_on_request_and_overuse_only_in_review(self):
        card = card_of(self.data, "slice-of-life-warmth")
        code, out, err = run("load", "slice-of-life-warmth", "--examples")
        self.assertEqual(code, 0, out + err)
        for title in ("### 腔调示例", "### 动作示例", "### 示范"):
            self.assertIn(title, out)
        self.assertIn(card["sections"]["example_after"], out)
        self.assertNotIn(card["sections"]["overuse"], out)
        self.assertNotIn(self.mod.ONLY_DIRECTIONS, out)
        code, out, err = run("review", "slice-of-life-warmth", "hemingway-iceberg")
        self.assertEqual(code, 0, out + err)
        for cid in ("slice-of-life-warmth", "hemingway-iceberg"):
            self.assertIn(card_of(self.data, cid)["sections"]["overuse"], out)
        self.assertIn("不是判定", out)
        self.assertNotIn(card["sections"]["example_after"], out)
        code, out, err = run("review", "slice-of-life-warmth", "--format", "json")
        self.assertEqual([c["id"] for c in json.loads(out)["cards"]], ["slice-of-life-warmth"])
        self.assertEqual(json.loads(out)["cards"][0]["overuse"], card["sections"]["overuse"])
        for ids, expected in ((("hemingway-iceberg", "russian-epic-realism"), "at most 1 voice"), (("no-such-card",), "no card")):
            code, out, err = run("review", *ids)
            self.assertEqual(code, 2, out + err)
            self.assertIn(expected, json.loads(out)["error"])

    def test_marks_are_counted_when_examples_are_not_printed(self):
        code, out, err = run("load", "tense-suspense-probe", "hemingway-iceberg")
        self.assertEqual(code, 0, out + err)
        self.assertNotIn("- 平常写“", out)
        self.assertIn("条示例撞上了相反的写法", out)
        self.assertIn(self.mod.TOGETHER_COUNTED, out)
        code, shown, err = run("load", "tense-suspense-probe", "hemingway-iceberg", "--examples")
        self.assertIn(self.mod.CLASH_MARK, shown)
        self.assertNotIn("条示例撞上了相反的写法", shown)
        code, alone, err = run("load", "hemingway-iceberg")
        self.assertNotIn("条示例撞上了相反的写法", alone)


class GlobalOpposites(unittest.TestCase):
    def setUp(self):
        self.data = json.loads(LIBRARY.read_text(encoding="utf-8"))
        self.mod = module()

    def line(self, page, plain):
        return next(l for l in page.splitlines() if l.startswith("- 平常写“%s”" % plain))

    def test_the_card_sets_own_list_counts(self):
        data = json.loads(json.dumps(self.data))
        scene = card_of(data, "tense-suspense-probe")
        scene["kinetic_verbs"]["回头"] = "他不由得回头看了门一眼"          # a global word
        scene["kinetic_verbs"]["吸气"] = "她倒吸一口冷气，往后退了半步"      # a global pattern, not the listed word
        scene["kinetic_verbs"]["转折"] = "然而门没有开"                      # a word a card may open up
        page = self.mod.render(data, [scene], examples=True)
        for plain in ("回头", "吸气", "转折"):
            self.assertTrue(self.line(page, plain).endswith(self.mod.GLOBAL_MARK), plain)
        self.assertNotIn(self.mod.CLASH_MARK, page)
        opener = next(c for c in data["cards"] if "然而" in c["overrides"].get("allow_global_terms", []) and c["layer"] != "scene")
        page = self.mod.render(data, [opener, scene], examples=True)
        self.assertNotIn(self.mod.GLOBAL_MARK, self.line(page, "转折"))  # the term is opened up by a loaded card
        self.assertTrue(self.line(page, "回头").endswith(self.mod.GLOBAL_MARK))
        data["global"]["blacklist_patterns"] = ["[坏(", "(?P<"] + data["global"]["blacklist_patterns"]
        self.assertTrue(self.line(self.mod.render(data, [scene], examples=True), "吸气").endswith(self.mod.GLOBAL_MARK))
        self.assertIn("条示例撞上了相反的写法", self.mod.render(data, [scene]))

    def test_the_shipped_cards_carry_no_such_example(self):
        for card in self.data["cards"]:
            self.assertNotIn(self.mod.GLOBAL_MARK, self.mod.render(self.data, [card], examples=True), card["id"])
        code, out, err = run("load", "slice-of-life-warmth")
        self.assertIn("全卡组另有 %d 条句式" % len(self.data["global"]["blacklist_patterns"]), out)


class Copied(unittest.TestCase):
    def setUp(self):
        self.data = json.loads(LIBRARY.read_text(encoding="utf-8"))
        self.mod = module()
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def copied(self, text, *ids):
        draft = Path(self.tmp.name) / "draft.txt"
        draft.write_bytes(text.encode("utf-8"))
        code, out, err = run("copied", *ids, "--file", draft, "--format", "json")
        self.assertEqual(code, 0, out + err)
        return json.loads(out)

    def test_a_common_phrase_alone_is_not_taken_wording(self):
        result = self.copied("掌柜不动声色，把银子收了。他面无表情地站着。", "beijing-hooligan-satire", "meta-anti-cliche-comedy")
        self.assertEqual(result["found"], [])
        self.assertEqual(sorted("".join(ch for ch in f["text"] if "一" <= ch <= "鿿")[:4] for f in result["exempt"]),
                         ["不动声色", "面无表情"])
        card = card_of(self.data, "beijing-hooligan-satire")
        longer = next(v for v in card["kinetic_verbs"].values() if "不动声色" in v).split(" / ")[0]
        result = self.copied("他" + longer + "。", "beijing-hooligan-satire")
        self.assertIn(longer, [f["text"] for f in result["found"]])  # more than the phrase was taken: still listed
        code, out, err = run("copied", "beijing-hooligan-satire", "--file", Path(self.tmp.name) / "draft.txt")
        self.assertIn("照搬进了正文", out)

    def test_the_two_lists_are_what_they_say(self):
        han = lambda s: all("一" <= ch <= "鿿" for ch in s)
        self.assertTrue(self.mod.COMMON_FOUR)
        for phrase in self.mod.COMMON_FOUR:
            self.assertTrue(len(phrase) == 4 and han(phrase), phrase)
        scope = {c["id"]: "\n".join(src for _, src in self.mod.examples(c)) for c in self.data["cards"]}
        everything = "\n".join(scope.values())
        for phrase in self.mod.COMMON_FOUR:
            self.assertIn(phrase, everything, phrase)  # the list only holds phrases the cards' examples really use
        for cid, names in self.mod.SHORT_NAMES.items():
            for name in names:
                self.assertTrue(len(name) == 3 and han(name), name)
                self.assertIn(name, scope[cid], (cid, name))

    def test_a_three_character_name_is_a_hint(self):
        result = self.copied("朋友递来一瓶汽水，是北冰洋。", "beijing-hooligan-satire")
        self.assertEqual(result["found"], [])
        self.assertEqual(result["hints"], [{"card": "beijing-hooligan-satire", "text": "北冰洋"}])
        result = self.copied("朋友递来一瓶汽水，是北冰洋。", "slice-of-life-warmth")
        self.assertEqual(result["hints"], [])  # only the loaded cards' names
        code, out, err = run("copied", "beijing-hooligan-satire", "--file", Path(self.tmp.name) / "draft.txt")
        self.assertIn("提示", out)
        self.assertIn("不算照搬", out)


class FixedBase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def config(self, **fields):
        body = {"format": "novel-workshop-style-card-config", "format_version": 1}
        body.update(fields)
        path = Path(self.tmp.name) / "style-cards.json"
        path.write_bytes(json.dumps(body, ensure_ascii=False).encode("utf-8"))
        return path

    def test_the_config_field(self):
        code, out, err = run("check", "--project", self.config(fixed_base_card="wei-jin-xuanxue-poetic"))
        self.assertEqual(code, 0, out + err)
        for fields, expected in (({"fixed_base_card": "hemingway-iceberg"}, "base-layer"),
                                 ({"fixed_base_card": "no-such-card"}, "fixed_base_card"),
                                 ({"fixed_base_card": ["wei-jin-xuanxue-poetic"]}, "fixed_base_card"),
                                 ({"fixed_base_card": "wei-jin-xuanxue-poetic", "exclude": ["wei-jin-xuanxue-poetic"]}, "excluded")):
            code, out, err = run("check", "--project", self.config(**fields))
            self.assertEqual(code, 1, (fields, out + err))
            self.assertIn(expected, " ".join(json.loads(out)["config"]["problems"]))
        code, out, err = run("check", "--project", self.config(fixed_base_card=None))
        self.assertEqual(code, 0, out + err)

    def test_load_takes_it_along_unless_told_not_to(self):
        path = self.config(fixed_base_card="wei-jin-xuanxue-poetic")
        code, out, err = run("load", "slice-of-life-warmth", "--project", path)
        self.assertEqual(code, 0, out + err)
        self.assertIn("（wei-jin-xuanxue-poetic，base）", out.splitlines()[0])
        self.assertIn("本书固定的底色卡 wei-jin-xuanxue-poetic 已经带上", out)
        code, out, err = run("load", "slice-of-life-warmth", "--project", path, "--no-fixed-base")
        self.assertNotIn("wei-jin-xuanxue-poetic", out)
        code, out, err = run("load", "cyberpunk-gibson-sprawl", "slice-of-life-warmth", "--project", path)
        self.assertEqual(code, 0, out + err)
        self.assertNotIn("（wei-jin-xuanxue-poetic，base）", out.splitlines()[0])  # a base card named for this scene
        code, out, err = run("load", "high-kinetic-combat", "--project", path)
        self.assertEqual(code, 2, out + err)
        self.assertIn("--no-fixed-base", json.loads(out)["error"])
        code, out, err = run("review", "slice-of-life-warmth", "--project", path, "--format", "json")
        self.assertIn("wei-jin-xuanxue-poetic", [c["id"] for c in json.loads(out)["cards"]])
        code, out, err = run("load", "slice-of-life-warmth")
        self.assertNotIn("固定的底色卡", out)  # no config, nothing added
        code, out, err = run("index", "--project", path)
        self.assertIn("本书固定的底色卡：wei-jin-xuanxue-poetic", out)

    def test_match_names_it(self):
        path = self.config(fixed_base_card="wei-jin-xuanxue-poetic")
        task = "吊臂上的重型机械超负荷出故障"
        code, out, err = run("match", "--text", task, "--project", path, "--format", "json")
        self.assertEqual(code, 0, out + err)
        self.assertEqual(json.loads(out)["fixed_base_card"], "wei-jin-xuanxue-poetic")
        code, out, err = run("match", "--text", task, "--project", path)
        self.assertIn("本书固定的底色卡：wei-jin-xuanxue-poetic（作者定的；只在本书还没有作者正文样本时用）", out)
        code, out, err = run("match", "--text", task, "--format", "json")
        self.assertIsNone(json.loads(out)["fixed_base_card"])  # no config, no fixed card
        code, out, err = run("match", "--text", task)
        self.assertNotIn("固定的底色卡", out)

    def test_a_named_base_card_stands_in_its_place(self):
        path = self.config(fixed_base_card="wei-jin-xuanxue-poetic")
        code, out, err = run("load", "cyberpunk-gibson-sprawl", "slice-of-life-warmth", "--project", path)
        self.assertEqual(code, 0, out + err)
        self.assertIn("这一次点名了底色卡 cyberpunk-gibson-sprawl，本书固定的 wei-jin-xuanxue-poetic 没有带。", out)
        self.assertNotIn("已经带上", out)
        code, out, err = run("load", "wei-jin-xuanxue-poetic", "slice-of-life-warmth", "--project", path)
        self.assertEqual(code, 0, out + err)  # the fixed card itself named: nothing to say
        self.assertNotIn("没有带", out)
        self.assertNotIn("已经带上", out)
        code, out, err = run("load", "cyberpunk-gibson-sprawl", "--project", path, "--no-fixed-base")
        self.assertNotIn("wei-jin-xuanxue-poetic", out)
        code, out, err = run("load", "high-kinetic-combat", "--project", path)
        self.assertEqual(code, 2, out + err)
        self.assertIn("wei-jin-xuanxue-poetic 是本书固定的底色卡：这一场不带它就加 --no-fixed-base", json.loads(out)["error"])
        code, out, err = run("load", "wei-jin-xuanxue-poetic", "high-kinetic-combat", "--project", path)
        self.assertEqual(code, 2, out + err)  # named by hand: the plain refusal
        self.assertNotIn("本书固定的底色卡", json.loads(out)["error"])
        code, out, err = run("review", "slice-of-life-warmth", "--project", path)
        self.assertIn("本书固定的底色卡 wei-jin-xuanxue-poetic 已经带上", out)
        draft = Path(self.tmp.name) / "draft.txt"
        draft.write_bytes("天刚亮，他进了门。".encode("utf-8"))
        code, out, err = run("copied", "slice-of-life-warmth", "--project", path, "--file", draft, "--format", "json")
        self.assertEqual(json.loads(out)["cards"], ["slice-of-life-warmth", "wei-jin-xuanxue-poetic"])
        code, out, err = run("copied", "slice-of-life-warmth", "--project", path, "--file", draft)
        self.assertIn("本书固定的底色卡 wei-jin-xuanxue-poetic 已经带上", out)
        code, out, err = run("copied", "slice-of-life-warmth", "--project", path, "--file", draft, "--no-fixed-base",
                             "--format", "json")
        self.assertEqual(json.loads(out)["cards"], ["slice-of-life-warmth"])


class IndexAndGuide(unittest.TestCase):
    def setUp(self):
        self.data = json.loads(LIBRARY.read_text(encoding="utf-8"))
        self.guide = GUIDE.read_text(encoding="utf-8")

    def test_the_index_prints_the_genre(self):
        code, out, err = run("index", "--format", "json")
        rows = {r["id"]: r for r in json.loads(out)}
        for card in self.data["cards"]:
            self.assertEqual(rows[card["id"]]["domain"], card["domain"])
        code, out, err = run("index", "--layer", "scene")
        self.assertIn("- urban-power-slap｜都市阶层反差与快节奏爽文风｜题材：male-web-fiction｜", out)
        self.assertIn("｜题材：functional-modes｜", out)

    def test_the_guides_counts_and_lists_match_the_library(self):
        scene = [c for c in self.data["cards"] if c["layer"] == "scene"]
        free = [c for c in scene if c["domain"] == "functional-modes"]
        self.assertIn("scene 层里题材标着 `functional-modes` 的 %d 张" % len(free), self.guide)
        self.assertIn("其余 %d 张带着题材" % (len(scene) - len(free)), self.guide)
        for domain in sorted({c["domain"] for c in scene} - {"functional-modes"}):
            self.assertIn("`%s`" % domain, self.guide)
        line = next(l for l in self.guide.splitlines() if l.startswith("5. 卡上写死了人称、文白或排版的"))
        self.assertIn("现在卡库里是这 %d 张" % len(STRONG_FORMAT), line)
        for cid in STRONG_FORMAT:
            self.assertIn("`%s`" % cid, line)
            self.assertIn(card_of(self.data, cid)["layer"], ("voice", "device"))
        self.assertIn("r5.60 照作者认过的清单改了 17 张卡", self.guide)
        self.assertNotIn("逐条认过", self.guide)  # the author accepted the list group by group
        self.assertIn("还是 %d 张" % len(self.data["cards"]), self.guide)

    def test_the_guide_says_what_was_decided(self):
        for phrase in ("base（世界观底色）和 voice（整体文风）两层默认不挑，只看 scene 层",
                       "这一场已经挂了技法卡的，scene 层最多一张",
                       "不靠识别加载：作者点名要用，或者这一场本身就是书里的档案、弹幕、帖子，才用",
                       "不盖过本书已定的视角和语体",
                       "作者采纳过的本书[技法卡](../assets/technique-card-template.md)先于通用风格卡，工坊的模块照旧在两者前面",
                       "`load` 默认只印方向", "加 `--examples`", "用 `review` 印写过头是什么样",
                       "- **句子这一栏说的是叙述，台词另算**：分句长短和常用语气词这两样说的是叙述；",
                       "卡组全局的相反写法", "不算照搬，只说有几处", "列成提示，不算照搬", "`fixed_base_card`", "工坊不自己填",
                       "## 版本说明"):
            self.assertIn(phrase, self.guide, phrase)
        self.assertNotIn("加载时这几句也印在“句子”一节里", self.guide)
        self.assertNotIn("放在哪种题材里都能用", self.guide)
        tail = self.guide.split("## 版本说明", 1)[1]
        for phrase in ("r5.53", "r5.54", "r5.60", "是工坊的读法", "作者不认就拿掉"):
            self.assertIn(phrase, tail)
        sentence = next(l for l in self.guide.splitlines() if l.startswith("- **句子这一栏说的是叙述"))
        self.assertNotIn("r5.5", sentence)  # the version notes moved to the end of the page
        config = json.loads(self.guide.split("```json", 1)[1].split("```", 1)[0])
        self.assertIn("fixed_base_card", config)

    def test_what_the_guide_says_load_prints_is_what_load_prints(self):
        mod = module()
        code, out, err = run("load", "slice-of-life-warmth")
        lines = out.splitlines()
        self.assertIn(mod.DIALOGUE_LINE, lines)
        self.assertTrue(any(l.startswith("- 分句（逗号、句号隔开的一小段）大致 ") for l in lines))
        for unprinted in ("不为凑句长切句、并句", "看读者跟不跟得上，不看长短"):
            self.assertIn(unprinted, self.guide)
            self.assertNotIn(unprinted, out)

    def test_the_other_pages(self):
        skill = (SKILL / "SKILL.md").read_text(encoding="utf-8")
        row = next(l for l in skill.splitlines() if "[style-cards.md](references/style-cards.md)" in l)
        for phrase in ("scene 最多两张，这一场挂了技法卡的最多一张", "底色和整体文风两层默认不挑", "不盖过本书已定的视角和语体",
                       "同一处做法上作者采纳过的本书技法卡在风格卡前面"):
            self.assertIn(phrase, row)
        drafting = (SKILL / "references" / "drafting.md").read_text(encoding="utf-8")
        self.assertIn("有作者原文样本或本书文风卡的，底色和整体文风两层默认不挑，只看场景层", drafting)
        usage = (ROOT / "USAGE.md").read_text(encoding="utf-8")
        for phrase in ("style_cards.py load hemingway-iceberg tense-suspense-probe --examples",
                       "style_cards.py review hemingway-iceberg tense-suspense-probe"):
            self.assertIn(phrase, usage)


if __name__ == "__main__":
    unittest.main()

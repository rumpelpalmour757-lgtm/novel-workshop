#!/usr/bin/env python3
"""Check declared manuscript constraints and persist bounded revision events.

No model calls, manuscript writes, publication, or semantic quality scoring.
Only the explicitly selected state file and its temporary lock are written.
"""

import argparse
from contextlib import contextmanager
from difflib import SequenceMatcher
import hashlib
import json
import os
from pathlib import Path
import tempfile
import time


TYPES = {"length", "literal_count", "contains", "scope", "quote", "file_hash"}
STATE_FIELDS = {"task_id", "current_node", "completed_nodes", "artifacts", "decisions",
                "evidence", "budgets", "retry_counts", "human_approvals", "events"}


class GuardError(ValueError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def need(condition, message, code="INVALID_INPUT"):
    if not condition:
        raise GuardError(code, message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def fingerprint(value):
    return digest(json.dumps(value, sort_keys=True, ensure_ascii=False).encode("utf-8"))


def read_bytes(path):
    try:
        return Path(path).read_bytes()
    except FileNotFoundError as exc:
        raise GuardError("MISSING_REQUIRED_SOURCE", str(path)) from exc


def read_json(path):
    return json.loads(read_bytes(path).decode("utf-8"))


def local_path(root, name):
    need(isinstance(name, str) and bool(name.strip()), "Expected a relative file path")
    path = Path(name)
    need(not path.is_absolute(), "File paths must be relative to the project")
    resolved = (root / path).resolve()
    try:
        resolved.relative_to(root.resolve())
    except ValueError as exc:
        raise GuardError("INVALID_INPUT", "File path leaves the project: " + name) from exc
    return resolved


def integer(value, minimum=0):
    return type(value) is int and value >= minimum


def load_spec(path):
    path = Path(path).resolve()
    spec = read_json(path)
    need(isinstance(spec, dict), "Spec must be an object")
    local_path(path.parent, spec.get("candidate"))
    need(isinstance(spec.get("checks"), list), "checks must be a list")
    ids = set()
    for item in spec["checks"]:
        need(isinstance(item, dict), "Each check must be an object")
        key, kind = item.get("id"), item.get("type")
        need(isinstance(key, str) and bool(key.strip()) and key not in ids, "Check ids must be unique and nonempty")
        ids.add(key)
        need(kind in TYPES, "Unknown check type: " + str(kind))
        if kind in {"contains", "literal_count", "quote"}:
            need(isinstance(item.get("text"), str) and bool(item["text"]), key + ": text must be nonempty")
        if kind == "literal_count":
            need(integer(item.get("count")), key + ": count must be a nonnegative integer")
        if kind == "length":
            need("min" in item or "max" in item, key + ": declare min or max")
            for field in ("min", "max"):
                if field in item:
                    need(integer(item[field]), key + ": invalid " + field)
            need(item.get("min", 0) <= item.get("max", float("inf")), key + ": min exceeds max")
        if kind in {"scope", "quote", "file_hash"}:
            source_path = local_path(path.parent, item.get("source"))
            if kind == "scope":
                need(source_path != local_path(path.parent, spec["candidate"]), key + ": scope source must differ from candidate")
        if kind == "quote" and "line" in item:
            need(integer(item["line"], 1), key + ": line must be a positive integer")
        if kind == "file_hash":
            value = item.get("sha256")
            need(isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdefABCDEF" for c in value), key + ": invalid sha256")
    return spec


def check_spec(path):
    path = Path(path).resolve()
    spec = load_spec(path)
    candidate_path = local_path(path.parent, spec["candidate"])
    candidate_bytes = read_bytes(candidate_path)
    candidate = candidate_bytes.decode("utf-8")
    results = []
    for item in spec["checks"]:
        kind = item["type"]
        result = {"id": item["id"], "type": kind}
        if kind == "length":
            actual = sum(not char.isspace() for char in candidate)
            expected = {"min": item.get("min"), "max": item.get("max"), "mode": "non_whitespace_characters"}
            passed = item.get("min", 0) <= actual <= item.get("max", float("inf"))
        elif kind in {"contains", "literal_count"}:
            actual = candidate.count(item["text"])
            expected = {"text": item["text"], "count": item.get("count", "at least 1")}
            passed = actual == item["count"] if kind == "literal_count" else actual > 0
        else:
            source_bytes = read_bytes(local_path(path.parent, item["source"]))
            result["source"] = item["source"]
            if kind == "file_hash":
                actual, expected = digest(source_bytes), item["sha256"].lower()
                passed = actual == expected
            elif kind == "quote":
                source = source_bytes.decode("utf-8")
                lines = source.splitlines(keepends=True)
                start = 0 if "line" not in item else sum(len(line) for line in lines[:item["line"] - 1])
                found = source.find(item["text"], start)
                found_line = source[:found].count("\n") + 1 if found >= 0 else None
                expected = {"text": item["text"], "line": item.get("line")}
                actual = {"found": found >= 0, "line": found_line}
                passed = found >= 0 and ("line" not in item or found_line == item["line"])
            else:
                before = source_bytes.decode("utf-8").splitlines(keepends=True)
                after = candidate.splitlines(keepends=True)
                ranges = item.get("editable_lines")
                need(isinstance(ranges, list), item["id"] + ": editable_lines must be a list")
                allowed = set()
                for interval in ranges:
                    need(isinstance(interval, list) and len(interval) == 2 and all(integer(n, 1) for n in interval), "Invalid editable interval")
                    first, last = interval
                    need(first <= last <= len(before), "Editable interval is outside the source")
                    allowed.update(range(first, last + 1))
                actual = []
                passed = True
                for op, i, j, a, b in SequenceMatcher(None, before, after, autojunk=False).get_opcodes():
                    if op == "equal":
                        continue
                    touched = {i + 1 if i < len(before) else len(before)} if op == "insert" else set(range(i + 1, j + 1))
                    within = bool(touched) and touched <= allowed
                    passed = passed and within
                    actual.append({"operation": op, "source_lines": [i + 1, j], "candidate_lines": [a + 1, b], "within_scope": within})
                expected = {"editable_lines": ranges, "other_lines": "unchanged"}
        result.update(expected=expected, actual=actual, passed=bool(passed))
        results.append(result)
    status = "NOT_APPLICABLE" if not results else "GREEN" if all(r["passed"] for r in results) else "RED"
    return {"status": status, "spec_sha256": digest(read_bytes(path)),
            "candidate": {"path": spec["candidate"], "sha256": digest(candidate_bytes)}, "checks": results}


@contextmanager
def locked(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    lock = path.with_name(path.name + ".lock")
    try:
        handle = os.open(str(lock), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError as exc:
        raise GuardError("STATE_BUSY", "State is being updated; inspect the prior operation before retrying") from exc
    try:
        os.close(handle)
        yield
    finally:
        lock.unlink()


def save_state(path, state):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(state, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def load_state(path):
    state = read_json(path)
    need(isinstance(state, dict) and STATE_FIELDS <= state.keys(), "Incomplete state")
    budget = state["budgets"]
    need(integer(budget.get("max_revisions")) and integer(budget.get("revisions_used")), "Invalid revision budget")
    need(budget["revisions_used"] <= budget["max_revisions"], "Revision budget exceeded")
    return state


def artifact(path, base, role):
    relative = os.path.relpath(path, base)
    local_path(base, relative)
    return {"role": role, "path": relative, "sha256": digest(read_bytes(path))}


def start(path, task_id, spec_path, max_revisions=3, max_seconds=None):
    path, spec_path = Path(path).resolve(), Path(spec_path).resolve()
    need(isinstance(task_id, str) and bool(task_id.strip()), "task_id is required")
    need(integer(max_revisions), "max_revisions must be nonnegative")
    need(max_seconds is None or (isinstance(max_seconds, (int, float)) and max_seconds > 0), "max_seconds must be positive")
    spec = load_spec(spec_path)
    need(path != local_path(spec_path.parent, spec["candidate"]), "State and candidate must use different files")
    inputs = [artifact(spec_path, path.parent, "spec")]
    sources = sorted({item["source"] for item in spec["checks"] if "source" in item})
    inputs.extend(artifact(local_path(spec_path.parent, name), path.parent, "source") for name in sources)
    with locked(path):
        if path.exists():
            state = load_state(path)
            frozen = [a for a in state["artifacts"] if a["role"] in {"spec", "source"}]
            need(state["task_id"] == task_id and state["budgets"]["max_revisions"] == max_revisions
                 and state["budgets"]["max_seconds"] == max_seconds and frozen == inputs,
                 "Existing task cannot be reset or replaced", "STATE_CONFLICT")
            return state
        state = {"task_id": task_id, "current_node": "draft", "completed_nodes": [],
                 "artifacts": inputs, "decisions": [], "evidence": [],
                 "budgets": {"max_revisions": max_revisions, "revisions_used": 0,
                             "max_seconds": max_seconds, "started_at": time.time()},
                 "retry_counts": {"repair": 0}, "human_approvals": [], "events": {}}
        save_state(path, state)
        return state


def expired(state):
    budget = state["budgets"]
    return budget["max_seconds"] is not None and time.time() - budget["started_at"] >= budget["max_seconds"]


def repeated(state, event_id, signature):
    need(isinstance(event_id, str) and bool(event_id.strip()), "event_id is required")
    if event_id in state["events"]:
        need(state["events"][event_id] == signature, "Event id was reused with different content", "EVENT_CONFLICT")
        return True
    return False


def reserve(path, event_id):
    path = Path(path).resolve()
    signature = fingerprint({"action": "reserve"})
    with locked(path):
        state = load_state(path)
        if repeated(state, event_id, signature):
            return state
        budget = state["budgets"]
        need(not expired(state) and budget["revisions_used"] < budget["max_revisions"], "Revision or time budget exhausted", "BUDGET_EXHAUSTED")
        need(state["current_node"] == "repair", "Reserve only after a review requests repair", "INVALID_ROUTE")
        budget["revisions_used"] += 1
        state["retry_counts"]["repair"] += 1
        state["current_node"] = "draft"
        state["events"][event_id] = signature
        state["decisions"].append({"event_id": event_id, "route": "draft", "reason": "Reserved one repair before editing"})
        save_state(path, state)
        return state


def record(path, event_id, review_path):
    path, review_path = Path(path).resolve(), Path(review_path).resolve()
    review = read_json(review_path)
    need(isinstance(review, dict) and review.get("verdict") in {"PASS", "NEEDS_REVISION", "FAIL"}, "Invalid editorial verdict")
    need(isinstance(review.get("checked_against"), list) and bool(review["checked_against"])
         and all(isinstance(x, str) and bool(x.strip()) for x in review["checked_against"]), "checked_against must name actual references")
    need(isinstance(review.get("issues"), list) and all(isinstance(x, dict) for x in review["issues"]), "issues must be a list of objects")
    need(review["verdict"] != "PASS" or not review["issues"], "PASS cannot retain unresolved issues")
    need(review["verdict"] == "PASS" or bool(review["issues"]), "A non-PASS review must identify a concrete issue")
    with locked(path):
        state = load_state(path)
        inputs = [a for a in state["artifacts"] if a["role"] in {"spec", "source"}]
        for entry in inputs:
            need(digest(read_bytes(local_path(path.parent, entry["path"]))) == entry["sha256"], "Frozen input changed: " + entry["path"], "INPUT_CHANGED")
        spec_entry = next(a for a in inputs if a["role"] == "spec")
        spec_path = local_path(path.parent, spec_entry["path"])
        report = check_spec(spec_path)
        need(report["spec_sha256"] == spec_entry["sha256"], "Check specification changed while reading", "INPUT_CHANGED")
        signature = fingerprint({"action": "record", "report": report, "review": review})
        if repeated(state, event_id, signature):
            return state
        need(state["current_node"] == "draft", "Current node is not awaiting verification; reserve repair first", "INVALID_ROUTE")
        needs_repair = report["status"] == "RED" or review["verdict"] == "NEEDS_REVISION"
        if expired(state):
            route, reason = "stopped", "Time budget exhausted"
        elif review["verdict"] == "FAIL":
            route, reason = "blocked", "Editorial review identified a required decision or missing context"
        elif needs_repair:
            if state["budgets"]["revisions_used"] >= state["budgets"]["max_revisions"]:
                route, reason = "stopped", "Revision budget exhausted with unresolved checks"
            else:
                route, reason = "repair", "Declared checks or editorial review require scoped repair"
        else:
            route, reason = "complete", "Declared checks and supplied editorial verdict accepted for this task"
        candidate_path = local_path(spec_path.parent, report["candidate"]["path"])
        candidate = artifact(candidate_path, path.parent, "candidate")
        need(candidate["sha256"] == report["candidate"]["sha256"], "Candidate changed during verification", "INPUT_CHANGED")
        candidate.update(event_id=event_id, author_status="draft")
        state["artifacts"].append(candidate)
        state["evidence"].append({"event_id": event_id, "machine": report,
                                  "editorial": {key: review[key] for key in ("verdict", "checked_against", "issues")}})
        state["decisions"].append({"event_id": event_id, "route": route, "reason": reason})
        state["completed_nodes"].append("verify:" + event_id)
        state["current_node"] = route
        state["events"][event_id] = signature
        save_state(path, state)
        return state


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    check = commands.add_parser("check")
    check.add_argument("spec", type=Path)
    begin = commands.add_parser("start")
    begin.add_argument("state", type=Path)
    begin.add_argument("--task-id", required=True)
    begin.add_argument("--spec", type=Path, required=True)
    begin.add_argument("--max-revisions", type=int, default=3)
    begin.add_argument("--max-seconds", type=float)
    retry = commands.add_parser("reserve")
    retry.add_argument("state", type=Path)
    retry.add_argument("--event-id", required=True)
    verify = commands.add_parser("record")
    verify.add_argument("state", type=Path)
    verify.add_argument("--event-id", required=True)
    verify.add_argument("--review", type=Path, required=True)
    status = commands.add_parser("status")
    status.add_argument("state", type=Path)
    args = parser.parse_args()
    try:
        if args.command == "check":
            result = check_spec(args.spec)
        elif args.command == "start":
            result = start(args.state, args.task_id, args.spec, args.max_revisions, args.max_seconds)
        elif args.command == "reserve":
            result = reserve(args.state, args.event_id)
        elif args.command == "record":
            result = record(args.state, args.event_id, args.review)
        else:
            result = load_state(args.state)
            result["time_budget_exhausted"] = expired(result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 1 if result.get("status") == "RED" else 0
    except (GuardError, OSError, ValueError, TypeError, KeyError) as exc:
        print(json.dumps({"status": "ERROR", "failure": getattr(exc, "code", "INVALID_INPUT"), "message": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

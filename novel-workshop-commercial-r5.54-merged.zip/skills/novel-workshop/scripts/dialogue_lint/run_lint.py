"""Command-line wrapper for review reports and validated dialogue-only patches."""
import argparse
from dataclasses import asdict
import json
from pathlib import Path
import sys

from dialogue_core import extract_dialogues
from dialogue_antipatterns import scan_dialogue_antipatterns
from patch_guard import apply_dialogue_patch, build_patch_request, format_patch_prompt
from voice_lint import VOICEPRINT_REGISTRY, VoiceprintProfile, analyze_voice_and_idioms
from genre_profiles import (GENRE_PROFILES, resolve_genre_profile,
    resolve_scene_overrides, scene_keyword_hints)
from system_brackets import scan_system_brackets


def read_source(path):
    with Path(path).open('r', encoding='utf-8', newline='') as stream:
        return stream.read().splitlines(keepends=True)


def read_json(path):
    def unique_keys(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('JSON包含重复字段')
            result[key] = value
        return result
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=unique_keys)


def write_new(path, text):
    with Path(path).open('x', encoding='utf-8', newline='') as stream:
        stream.write(text)


def config_values(path):
    config = read_json(path) if path else {}
    if not isinstance(config, dict):
        raise ValueError('配置必须是JSON对象')
    allowed = {'profiles', 'aliases', 'speaker_overrides', 'stress_speakers', 'cold_protagonist_names',
        'min_profile_quotes', 'genre_id', 'genre_overrides', 'scene_overrides', 'system_brackets'}
    if set(config) - allowed:
        raise ValueError('配置包含未知字段')
    if not isinstance(config.get('profiles', {}), dict) or not isinstance(config.get('aliases', {}), dict):
        raise ValueError('profiles和aliases必须是JSON对象')
    if not isinstance(config.get('speaker_overrides', []), list):
        raise ValueError('speaker_overrides必须是JSON数组')
    for key in ('stress_speakers', 'cold_protagonist_names'):
        values = config.get(key, [])
        if not isinstance(values, list) or any(not isinstance(v, str) or not v for v in values):
            raise ValueError(f'{key}必须是角色名数组')
    profiles = dict(VOICEPRINT_REGISTRY)
    for name, values in config.get('profiles', {}).items():
        profiles[name] = VoiceprintProfile(name=name, **values)
    overrides = {}
    for override in config.get('speaker_overrides', []):
        if not isinstance(override, dict) or set(override) != {'para_index', 'quote_index', 'speaker'}:
            raise ValueError('说话人覆盖记录字段不正确')
        p, q = override['para_index'], override['quote_index']
        if type(p) is not int or type(q) is not int or p < 1 or q < 1:
            raise ValueError('覆盖记录的段号/引语号必须是正整数')
        key = (p, q)
        if key in overrides:
            raise ValueError('同一引语不能重复指定说话人')
        overrides[key] = override['speaker']
    return config, profiles, overrides


def main(argv=None):
    parser = argparse.ArgumentParser(description='对白复核工具：报告不代表语病或AI来源判定')
    actions = parser.add_subparsers(dest='action', required=True)
    scan = actions.add_parser('scan', help='只读扫描，生成复核报告')
    scan.add_argument('source')
    scan.add_argument('--config')
    scan.add_argument('--style-hints', action='store_true', help='启用全部可选文风复核模式')
    scan.add_argument('--genre', choices=tuple(GENRE_PROFILES), help='显式选择题材，优先于配置里的genre_id')
    scan.add_argument('--output', help='新建JSON报告；省略时打印')
    scan.add_argument('--request-output', help='新建可验证补丁请求JSON')
    scan.add_argument('--prompt-output', help='新建供模型生成候选补丁的提示文本')
    apply = actions.add_parser('apply', help='校验并应用已确认候选，写到新文件')
    apply.add_argument('source')
    apply.add_argument('request')
    apply.add_argument('response')
    apply.add_argument('--output', required=True)
    args = parser.parse_args(argv)
    try:
        paragraphs = read_source(args.source)
        if args.action == 'apply':
            updated = apply_dialogue_patch(paragraphs, read_json(args.request), read_json(args.response))
            write_new(args.output, ''.join(updated))
            print(f'已生成：{args.output}')
            return 0
        config, profiles, overrides = config_values(args.config)
        aliases = config.get('aliases', {})
        genre = resolve_genre_profile(args.genre if args.genre is not None else config.get('genre_id'),
            config.get('genre_overrides'))
        dialogues = extract_dialogues(paragraphs, tuple(profiles), aliases=aliases, speaker_overrides=overrides)
        scene_exempt, scene_applied = resolve_scene_overrides(dialogues, config.get('scene_overrides'))
        options = dict(registry=profiles, aliases=aliases, speaker_overrides=overrides,
            stress_speakers=config.get('stress_speakers', []),
            min_profile_quotes=config.get('min_profile_quotes', 3), include_style_hints=args.style_hints,
            genre_profile=genre, style_exempt_quotes=scene_exempt)
        report, voice_issues = analyze_voice_and_idioms(paragraphs, **options)
        pattern_issues = scan_dialogue_antipatterns(paragraphs,
            tuple(config.get('cold_protagonist_names', [])), names=tuple(profiles),
            aliases=aliases, speaker_overrides=overrides, include_style_hints=args.style_hints,
            genre_profile=genre, style_exempt_quotes=scene_exempt)
        system_issues = scan_system_brackets(paragraphs, config.get('system_brackets'), genre_profile=genre)
        system_settings = config.get('system_brackets') or {}
        system_enabled = system_settings.get('enabled', False)
        anchors_enabled = system_enabled and system_settings.get('check_anchors',
            genre.enable_system_bracket_anchor if genre is not None else False)
        issues = voice_issues + pattern_issues
        payload = {
            'version': '1.1.0',
            'genre_profile': None if genre is None else genre.to_report(),
            'scene_keyword_hints': scene_keyword_hints(paragraphs, genre),
            'scene_overrides_applied': scene_applied,
            'system_brackets_configured': system_enabled,
            'effective_system_policy': {'enabled': system_enabled, 'check_anchors': anchors_enabled,
                'anchor_mode': ('regex_form' if 'anchor_pattern' in system_settings else 'manual_review') if anchors_enabled else 'off',
                'forbid_outer_punctuation': system_enabled and system_settings.get('forbid_outer_punctuation', False)},
            'system_bracket_issues': system_issues,
            'summary': {'dialogue_quotes': len(dialogues), 'review_records': len(issues),
                'candidate_quotes': len({i.quote_id for i in issues}),
                'unconfirmed_issue_records': sum(i.confidence not in ('explicit', 'manual') for i in issues),
                'style_hints_enabled': args.style_hints,
                'system_bracket_records': len(system_issues),
                'system_format_errors': sum(i['severity'] == 'ERROR' for i in system_issues)},
            'notice': '规则命中仅供复核，不证明语病、机器创作或文学质量；未知/推测归属不进入角色指标和自动补丁请求。',
            'voice_report': report,
            'dialogues': [asdict(d) for d in dialogues],
            'voice_issues': [asdict(i) for i in voice_issues],
            'antipattern_issues': [asdict(i) for i in pattern_issues],
        }
        outputs = [p for p in (args.output, args.request_output, args.prompt_output) if p]
        resolved = [Path(p).resolve() for p in outputs]
        if len(resolved) != len(set(resolved)) or any(Path(p).exists() for p in outputs):
            raise ValueError('输出必须使用各自不同的新文件名')
        request = build_patch_request(paragraphs, issues)
        encoded = json.dumps(payload, ensure_ascii=False, indent=2) + '\n'
        if args.output:
            write_new(args.output, encoded)
        else:
            print(encoded, end='')
        if args.request_output:
            write_new(args.request_output, json.dumps(request, ensure_ascii=False, indent=2) + '\n')
        if args.prompt_output:
            write_new(args.prompt_output, format_patch_prompt(request))
        return 1 if any(i['severity'] == 'ERROR' for i in system_issues) else 0
    except (ValueError, TypeError, KeyError, OSError) as error:
        print(f'错误：{error}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())

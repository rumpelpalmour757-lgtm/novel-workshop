#!/usr/bin/env node
// 测试用的模拟 ACP 程序：小说写作工坊自己写的，不是 Google 的程序，不连网，只在 stdin/stdout 上说 ACP v1。
// 用法：node fake_acp_agent.mjs --control <control.json> --log <log.jsonl> [官方程序会收到的参数：acp、--uid=、--version]
// control.json 每收到一条消息重读一次，测试可以随时换场景；log.jsonl 一行一条，记下收到的消息、启动时的工作目录、
// 拿到了哪些环境变量（只记名字）和对它发出的请求得到的回答，供测试核对“发出去的到底是什么”。

import { spawn } from "node:child_process";
import { appendFileSync, readFileSync } from "node:fs";
import { StringDecoder } from "node:string_decoder";

const argv = process.argv.slice(2);
const option = (name) => {
  const index = argv.indexOf(name);
  return index >= 0 ? argv[index + 1] : null;
};
const controlPath = option("--control");
const logPath = option("--log");
const passed = argv.filter((value, index) => !["--control", "--log"].includes(value) && !["--control", "--log"].includes(argv[index - 1]));

const DEFAULT_MODELS = [
  { value: "gemini-fake-pro", name: "Gemini Fake Pro（模拟）" },
  { value: "gemini-fake-flash", name: "Gemini Fake Flash（模拟）" },
];
const DEFAULT_THINKING = [
  { value: "low", name: "Low" },
  { value: "medium", name: "Medium" },
  { value: "high", name: "High" },
  { value: "extra", name: "Extra" },
  { value: "max", name: "Max" },
];
const PERMISSION_OPTIONS = [
  { optionId: "allow-once", name: "Allow", kind: "allow_once" },
  { optionId: "allow-always", name: "Always allow", kind: "allow_always" },
  { optionId: "reject-once", name: "Reject", kind: "reject_once" },
  { optionId: "reject-always", name: "Always reject", kind: "reject_always" },
];

function control() {
  try {
    return JSON.parse(readFileSync(controlPath, "utf8"));
  } catch {
    return {};
  }
}

function log(entry) {
  if (!logPath) return;
  try {
    appendFileSync(logPath, `${JSON.stringify({ t: Date.now(), pid: process.pid, ...entry })}\n`);
  } catch {}
}

const wait = (ms) => new Promise((accept) => setTimeout(accept, ms));
const encode = (message) => `${JSON.stringify(message)}\n`;
const writeRaw = (data) => new Promise((accept) => process.stdout.write(data, accept));

function send(message) {
  log({ event: "out", message });
  process.stdout.write(encode(message));
}

let nextId = 9000;
const waiting = new Map();
function ask(method, params) {
  const id = nextId;
  nextId += 1;
  send({ jsonrpc: "2.0", id, method, params });
  return new Promise((accept) => waiting.set(id, accept));
}

let authenticated = false;
let sessionCounter = 0;
const sessions = new Map();

function modelsOf(c) {
  return c.models ?? DEFAULT_MODELS;
}

function thinkingOf(c) {
  return c.thinking ?? DEFAULT_THINKING;
}

function configOptions(session, c) {
  const list = [];
  if (!c.noModelOption) {
    list.push({
      id: "model",
      name: "Model",
      description: "the models available to your account",
      category: "model",
      type: "select",
      currentValue: session.model,
      options: c.groupedModels ? [{ group: "gemini", name: "Gemini", options: modelsOf(c) }] : modelsOf(c),
    });
  }
  if (!c.noThinking) {
    list.push({ id: "thought_level", name: "Thinking level", category: "thought_level", type: "select", currentValue: session.thought, options: thinkingOf(c) });
  }
  list.push({ id: "mode", name: "Mode", category: "mode", type: "select", currentValue: "agent", options: [{ value: "agent", name: "Agent" }] });
  return list;
}

function textUpdate(sessionId, text) {
  return { jsonrpc: "2.0", method: "session/update", params: { sessionId, update: { sessionUpdate: "agent_message_chunk", content: { type: "text", text } } } };
}

// 找一个多字节字符（先找表情的 4 字节，再找汉字的 3 字节），从它中间切开。
function cutInsideCharacter(buffer) {
  for (const lead of [0xf0, 0xe0]) {
    const index = buffer.findIndex((byte) => byte >= lead && byte < lead + 0x10);
    if (index > 0) return index + 2;
  }
  return Math.floor(buffer.length / 2);
}

function initialize(c, reply, fail) {
  if (c.initialize === "hang") return;
  if (c.initialize === "error") return fail(-32603, "initialize failed in the fake agent");
  if (c.initialize === "exit") process.exit(4);
  reply({
    protocolVersion: c.protocolVersion ?? 1,
    agentCapabilities: {
      loadSession: false,
      promptCapabilities: { image: false, audio: false, embeddedContext: true },
      mcpCapabilities: { http: false, sse: false },
      auth: { logout: {} },
      sessionCapabilities: {},
    },
    agentInfo: c.agentInfo ?? { name: "fake-acp-agent", title: "测试用模拟 ACP 程序（不是 Google 的）", version: "0.0.0-fake" },
    // 标明自己是模拟程序：工坊把它产出的一切都标成“模拟”。只有检查“已真实接通”判断逻辑的测试才把它关掉（simulatedMarker: false）。
    ...(c.simulatedMarker === false ? {} : { _meta: { "novel-workshop/simulated": true } }),
    authMethods: c.authMethods ?? [
      { id: "oauth-personal", name: "Log in with Google", description: "模拟：不会真的打开浏览器" },
      { id: "oauth-business", name: "Log in with Google (Workspace)" },
      { id: "terminal-login", name: "Log in from a terminal", type: "terminal" },
    ],
  });
}

async function authenticate(c, reply, fail) {
  const mode = c.login ?? "ok";
  if (mode === "hang") return;
  await wait(c.loginDelayMs ?? 20);
  if (mode === "ok") {
    authenticated = true;
    return reply({});
  }
  if (mode === "cancel") return fail(-32603, "Login was cancelled by the user");
  return fail(-32603, "OAuth sign-in failed: access_denied");
}

// sessionNewDelayMs：开会话慢一点（测试用：在工坊“准备发送”的那一会儿里点停止、改设置）。
function newSession(c, params, reply, fail) {
  if (Number.isInteger(c.sessionNewDelayMs) && c.sessionNewDelayMs > 0) {
    log({ event: "session_delay", ms: c.sessionNewDelayMs });
    setTimeout(() => openSession(c, params, reply, fail), c.sessionNewDelayMs);
    return undefined;
  }
  return openSession(c, params, reply, fail);
}

function openSession(c, params, reply, fail) {
  if (c.sessionNew === "auth_required" || ((c.requireAuth ?? true) && !authenticated && !c.cachedLogin)) {
    return fail(-32000, "Authentication required");
  }
  if (c.sessionNew === "quota") return fail(-32603, "RESOURCE_EXHAUSTED: quota exceeded for this account");
  sessionCounter += 1;
  const sessionId = `fake-session-${process.pid}-${sessionCounter}`;
  const session = { id: sessionId, model: c.currentModel ?? modelsOf(c)[0]?.value, thought: c.currentThinking ?? thinkingOf(c)[0]?.value, onCancel: null };
  sessions.set(sessionId, session);
  log({ event: "session", sessionId, cwd: params?.cwd, mcpServers: params?.mcpServers });
  reply({ sessionId, configOptions: configOptions(session, c) });
  send({ jsonrpc: "2.0", method: "session/update", params: { sessionId, update: { sessionUpdate: "available_commands_update", availableCommands: [] } } });
}

function setOption(c, params, reply, fail) {
  const session = sessions.get(params?.sessionId);
  if (!session) return fail(-32602, "Invalid params: unknown session");
  if (c.setOption === "reject") return fail(-32602, "Invalid params: option change refused");
  const list = params.configId === "model" ? modelsOf(c) : params.configId === "thought_level" ? thinkingOf(c) : null;
  if (!list) return fail(-32602, "Invalid params: unknown config option");
  if (!list.some((entry) => entry.value === params.value)) return fail(-32602, "Invalid params: unknown value");
  if (c.setOption !== "ignore") {
    if (params.configId === "model") session.model = params.value;
    else session.thought = params.value;
  }
  log({ event: "set_option", sessionId: session.id, configId: params.configId, value: params.value });
  reply({ configOptions: configOptions(session, c) });
}

async function prompt(c, params, reply, fail) {
  const sessionId = params?.sessionId;
  const session = sessions.get(sessionId);
  if (!session) return fail(-32602, "Invalid params: unknown session");
  log({ event: "prompt", sessionId, blocks: params.prompt, model: session.model, thought: session.thought });
  const update = (body) => send({ jsonrpc: "2.0", method: "session/update", params: { sessionId, update: body } });
  const text = (value) => send(textUpdate(sessionId, value));
  if (c.stderrNoise) process.stderr.write(`[fake] prompt in ${process.env.HOME || "home"}/.fake-agent access_token=ya29.SECRET_FAKE_TOKEN_0123456789\n`);
  const scenario = c.prompt ?? "ok";
  switch (scenario) {
    case "ok": {
      update({ sessionUpdate: "agent_thought_chunk", content: { type: "text", text: "（思考片段：不该出现在候选稿里）" } });
      update({ sessionUpdate: "tool_call", toolCallId: "t1", title: "Read 第001章.md", kind: "read", status: "pending" });
      update({ sessionUpdate: "tool_call_update", toolCallId: "t1", status: "completed", content: [{ type: "content", content: { type: "text", text: "（工具输出：不该出现在候选稿里）" } }] });
      update({ sessionUpdate: "plan", entries: [{ content: "改稿", priority: "medium", status: "in_progress" }] });
      update({ sessionUpdate: "usage_update", used: 10, size: 1000 });
      const chunks = c.replyChunks ?? ["改好的第一句，", "第二句里有中文和表情😀，", "第三句收尾。"];
      text(chunks[0]);
      // 一条消息的字节从一个多字节字符中间切开，分两次写。
      const split = Buffer.from(encode(textUpdate(sessionId, chunks[1] ?? "")));
      const cut = cutInsideCharacter(split);
      await writeRaw(split.subarray(0, cut));
      await wait(25);
      await writeRaw(split.subarray(cut));
      // 两条消息一次写出。
      await writeRaw(encode(textUpdate(sessionId, chunks[2] ?? "")) + encode({ jsonrpc: "2.0", method: "session/update", params: { sessionId, update: { sessionUpdate: "session_info_update", title: "fake" } } }));
      for (const extra of chunks.slice(3)) text(extra);
      await wait(10);
      return reply({ stopReason: c.stopReason ?? "end_turn" });
    }
    case "empty":
      return reply({ stopReason: "end_turn" });
    case "huge_chunk":
      // 一行超过 4 MiB 的回复：工坊整行丢掉，这一轮不能当完整的候选稿。
      text("开头，");
      text("b".repeat(4 * 1024 * 1024 + 10));
      text("最后一句。");
      return reply({ stopReason: "end_turn" });
    case "corrupt_chunk":
      // 一段回复的那一行被别的字节弄坏了（不是有效 JSON）。
      text("前半段，");
      await writeRaw(`{"jsonrpc":"2.0","method":"session/update","params":{"sessionId":"${sessionId}","update":{"sessionUpdate":"agent_message_chunk","content":{"type":"text","text":"中间这段坏\n`);
      text("后半段。");
      return reply({ stopReason: "end_turn" });
    case "cancel_endturn":
      // 收到停止以后又写了一段，还是以 end_turn 交回整段（不守 ACP 的规矩，或者正好赶在停止之前）。
      text("停止前的字。");
      session.onCancel = async () => {
        text("——取消之后才写的后半段。");
        await wait(10);
        reply({ stopReason: "end_turn" });
      };
      return undefined;
    case "quota_after_text":
      text("已经写好的半段。");
      await wait(30);
      return fail(-32603, "RESOURCE_EXHAUSTED: quota exceeded", { status: 429 });
    case "model_switch": {
      text("开头，");
      session.model = c.switchTo ?? "gemini-fake-flash";
      update({ sessionUpdate: "config_option_update", configOptions: configOptions(session, c) });
      text("结尾。");
      return reply({ stopReason: "end_turn" });
    }
    case "crlf":
      text("改好的第一句。\r\n改好的第二句。");
      return reply({ stopReason: "end_turn" });
    case "max_tokens":
    case "refusal":
    case "max_turn_requests":
    case "weird_stop":
      text("半截的一句");
      return reply({ stopReason: scenario === "weird_stop" ? "banana" : scenario });
    case "quota":
      return fail(-32603, "RESOURCE_EXHAUSTED: You have exhausted your capacity on this model. Your quota will reset after 3h.", { status: 429 });
    case "auth_expired":
      return fail(-32000, "Authentication required");
    case "error":
      return fail(-32603, "Internal error in the fake agent");
    case "permission": {
      text("先说一句，");
      const answer = await ask("session/request_permission", {
        sessionId,
        toolCall: { toolCallId: "w1", title: "Write 正文/第001章.md", kind: "edit", status: "pending" },
        options: PERMISSION_OPTIONS,
      });
      log({ event: "permission_answer", answer });
      log({ event: "fs_read_answer", answer: await ask("fs/read_text_file", { sessionId, path: "/etc/hostname" }) });
      log({ event: "fs_write_answer", answer: await ask("fs/write_text_file", { sessionId, path: "/tmp/should-not-be-written.txt", content: "x" }) });
      log({ event: "terminal_answer", answer: await ask("terminal/create", { sessionId, command: "ls" }) });
      text("权限被拒以后照常交回正文。");
      return reply({ stopReason: "end_turn" });
    }
    case "cancel_late": {
      text("停止前的字。");
      session.onCancel = async () => {
        const answer = await ask("session/request_permission", {
          sessionId,
          toolCall: { toolCallId: "w2", title: "Write 设定.md", kind: "edit", status: "pending" },
          options: PERMISSION_OPTIONS,
        });
        log({ event: "permission_after_cancel", answer });
        text("停止后、回应前的字。");
        await wait(10);
        reply({ stopReason: "cancelled" });
        await wait(40);
        text("迟到的字。");
        update({ sessionUpdate: "tool_call", toolCallId: "late", title: "late", kind: "other", status: "pending" });
      };
      return undefined;
    }
    case "cancel_ignore":
      text("开始了。");
      session.onCancel = () => log({ event: "cancel_ignored" });
      return undefined;
    case "crash":
      text("说到一半");
      await wait(20);
      process.exit(3);
      return undefined;
    case "hang":
      session.onCancel = () => reply({ stopReason: "cancelled" });
      return undefined;
    case "hang_silent":
      session.onCancel = () => log({ event: "cancel_ignored" });
      return undefined;
    case "garbage":
      await writeRaw("this line is not json\n");
      text("正文一，");
      await writeRaw("{\"broken\": \n");
      await writeRaw("[1,2,3]\n");
      await writeRaw(`${JSON.stringify({ hello: "no jsonrpc field" })}\n`);
      text("正文二。");
      return reply({ stopReason: "end_turn" });
    case "stale_session":
      send(textUpdate("not-a-session", "不该出现的字"));
      text("正文。");
      return reply({ stopReason: "end_turn" });
    default:
      return fail(-32603, `unknown fake scenario ${scenario}`);
  }
}

function notification(method, params) {
  if (method !== "session/cancel") return;
  log({ event: "cancel", sessionId: params?.sessionId });
  const session = sessions.get(params?.sessionId);
  const handler = session?.onCancel;
  if (session) session.onCancel = null;
  if (handler) handler();
}

async function handle(message) {
  if (message.method === undefined && message.id !== undefined) {
    const accept = waiting.get(message.id);
    if (accept) {
      waiting.delete(message.id);
      accept(message);
    }
    return;
  }
  const c = control();
  const { id, method, params } = message;
  if (id === undefined) return notification(method, params);
  const reply = (result) => send({ jsonrpc: "2.0", id, result });
  const fail = (code, text, data) => send({ jsonrpc: "2.0", id, error: { code, message: text, ...(data ? { data } : {}) } });
  if (method === "initialize") {
    if (c.initDelayMs) await wait(c.initDelayMs);
    return initialize(c, reply, fail);
  }
  if (method === "authenticate") return authenticate(c, reply, fail);
  if (method === "session/new") return newSession(c, params, reply, fail);
  if (method === "session/set_config_option") return setOption(c, params, reply, fail);
  if (method === "session/prompt") return prompt(c, params, reply, fail);
  return fail(-32601, `Method not found: ${method}`);
}

function serve() {
  const start = control();
  log({ event: "start", argv: passed, cwd: process.cwd(), envKeys: Object.keys(process.env).sort() });
  if (start.grandchild) {
    // 自己再拉起一个不理会 stdin 的子进程（同一个进程组）：断开或关掉写作台时，它也必须被结束。
    const kid = spawn(process.execPath, ["-e", "setInterval(() => {}, 1000)"], { stdio: "ignore" });
    log({ event: "grandchild", pid: kid.pid });
  }
  if (start.startupStdout) process.stdout.write(`${start.startupStdout}\n`);
  if (start.stderrNoise) process.stderr.write(`starting fake agent in ${process.env.HOME || "home"}/.fake token ya29.FAKE_TOKEN_abcdef123456 Bearer abc.def\n`);
  if (start.stderrText) process.stderr.write(`${start.stderrText}\n`);
  if (Number.isInteger(start.exitAtStart)) process.exit(start.exitAtStart);
  const decoder = new StringDecoder("utf8");
  let buffer = "";
  process.stdin.on("data", (chunk) => {
    buffer += decoder.write(chunk);
    let index;
    while ((index = buffer.indexOf("\n")) !== -1) {
      const line = buffer.slice(0, index);
      buffer = buffer.slice(index + 1);
      if (!line.trim()) continue;
      let message;
      try {
        message = JSON.parse(line);
      } catch {
        log({ event: "bad_input", line: line.slice(0, 200) });
        continue;
      }
      log({ event: "in", message });
      handle(message).catch((error) => log({ event: "error", detail: String(error?.stack || error) }));
    }
  });
  process.stdin.on("end", () => {
    log({ event: "stdin_end" });
    process.exit(0);
  });
}

if (passed.includes("--version")) {
  const c = control();
  log({ event: "version", cwd: process.cwd(), argv: passed });
  // 模拟“查版本时自己升级了”：往自己的启动脚本后面追加一行。
  if (c.versionModifies) appendFileSync(c.versionModifies, "# changed by --version\n");
  if (c.version === "hang") setInterval(() => {}, 1000);
  else {
    process.stdout.write(`${c.versionText ?? "agy 0.0.0-fake（测试用模拟程序，不是 Google 的）"}\n`);
    process.exit(c.versionExit ?? 0);
  }
} else {
  serve();
}

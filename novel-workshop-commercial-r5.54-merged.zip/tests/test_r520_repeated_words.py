#!/usr/bin/env python3
"""r5.20: words that occur more than once in the old version no longer let one decision cover two changes.

Found in the second full self-review (2026-10-19, of r5.19). Since r5.16 each separate change after a recorded PASS
needs a decision whose words cover it: the new words where they now stand, or, for a cut, the old words where they
stood. The old words were looked up everywhere they occur in the old version. So when the same sentence stood in
two places and both places were edited, one decision quoting the old sentence covered both: the second place could
be changed to anything, or changed the same way with the decision pinned (offset) to the first place, and the gate
still recorded PASS.

Now a decision with new words covers only where its new words stand. Old words mark a place only for a cut with
nothing in its place, and then they must name one place in the old version. A cut can also be recorded as a change
of the longer passage: old words that hold the cut text and the words around it, new words that are what stays; it
covers the cut that sits right beside those new words (only whitespace between), and nothing further away. A change
that merely sits beside a cut, without the cut text in its old words, does not cover the cut.
(r5.22 narrows "beside": a cut counts for the passage only where the passage's old words stood, so the same sentence
cut on the other side of the words that stay is not covered; see test_r522_deletion_places.py.)
Material is invented test data, not literary judgment.
"""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
GUARD = ROOT / "skills" / "novel-workshop" / "scripts" / "workflow_guard.py"
DIMENSIONS = ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function", "continuity",
              "revision_comparison")
P1 = "雨停以后，阿禾把木箱放在门边，解开麻绳，取出几只旧瓷碗。"
P2 = "老沈拿来报纸，把桌上的碗一只只包好，码进竹筐，又在筐底垫了一层稻草。"
P3 = "天黑以后，两人抬着竹筐回屋，灯芯剪过一次，屋里亮了些。"
REFRAIN = "他把竹筐放在门口。"
EVIDENCE = ("雨停以后，阿禾把木箱", "把桌上的碗一只只包好", "灯芯剪过一次，屋里亮了些")
NOTE = "测试数据：只验证记录结构"


def body(*paragraphs):
    return "\n\n".join(paragraphs) + "\n"


def change(before, after, **extra):
    return dict({"decision": "change", "before": before, "after": after, "judgment": NOTE, "reason": NOTE}, **extra)


class RepeatedWords(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.dir)

    def write(self, name, text):
        (self.dir / name).write_bytes((text).encode("utf-8"))

    def guard(self, *args):
        proc = subprocess.run([sys.executable, "-I", "-B", str(GUARD), *args], cwd=self.dir, capture_output=True,
                              text=True, encoding="utf-8")
        try:
            return proc.returncode, json.loads(proc.stdout)
        except ValueError:
            return proc.returncode, {"raw": proc.stdout[-400:], "stderr": proc.stderr[-400:]}

    def review(self, name, text, decisions):
        value = {"schema": "editorial-review/2", "verdict": "PASS",
                 "candidate_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                 "reviewer": {"mode": "self_check", "label": NOTE}, "checked_against": ["测试数据"], "inputs_read": [],
                 "evidence": [{"quote": q, "in": "candidate"} for q in EVIDENCE], "issues": [], "machine_dispositions": [],
                 "counter_evidence": "测试数据，不是真实文学审稿。",
                 "dimensions": [{"id": key, "status": "met", "note": NOTE} for key in DIMENSIONS],
                 "expression": {"scope": "chapter", "decisions": decisions, "segments": [
                     {"from": text[:8], "to": text.rstrip()[-8:],
                      "note": "测试数据：从“%s”连读到“%s”，逐句看过改动和前后句" % (text[:8], text.rstrip()[-8:])}]}}
        self.write(name, json.dumps(value, ensure_ascii=False))
        return name

    def edit_after_pass(self, old, new):
        self.write("draft.md", old)
        self.write("checks.json", json.dumps({"candidate": "draft.md", "mode": "strict", "checks": [
            {"id": "ending", "type": "contains", "text": "灯芯剪过一次"}]}, ensure_ascii=False))
        self.assertEqual(self.guard("start", "run.json", "--task-id", "t", "--spec", "checks.json")[0], 0)
        code, out = self.guard("record", "run.json", "--event-id", "v1", "--review", self.review("v1.json", old, []))
        self.assertEqual(code, 0, out)
        self.write("draft.md", new)
        self.assertEqual(self.guard("reserve", "run.json", "--event-id", "r1")[0], 0)

    def record(self, event, text, decisions):
        return self.guard("record", "run.json", "--event-id", event, "--review", self.review(event + ".json", text, decisions))

    def test_one_old_sentence_in_two_places_changed_two_ways_needs_two_decisions(self):
        old = body(P1, REFRAIN, P2, REFRAIN, P3)
        new = body(P1, "他把藤筐放在门口。", P2, "他把竹筐挪到门外。", P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change(REFRAIN, "他把藤筐放在门口。")])
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertIn("line 7", out["message"])  # the second place, the one no decision describes
        code, out = self.record("v3", new, [change(REFRAIN, "他把藤筐放在门口。"), change(REFRAIN, "他把竹筐挪到门外。")])
        self.assertEqual(code, 0, out)

    def test_the_same_change_in_two_places_needs_a_decision_for_each(self):
        old = body(P1, REFRAIN, P2, REFRAIN, P3)
        new = body(P1, "他把藤筐放在门口。", P2, "他把藤筐放在门口。", P3)
        first, second = new.index("他把藤筐放在门口。"), new.rindex("他把藤筐放在门口。")
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change(REFRAIN, "他把藤筐放在门口。", offset=first)])
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        code, out = self.record("v3", new, [change(REFRAIN, "他把藤筐放在门口。", offset=first),
                                            change(REFRAIN, "他把藤筐放在门口。", offset=second)])
        self.assertEqual(code, 0, out)

    def test_a_cut_of_repeated_words_must_name_one_place(self):
        old = body(P1, REFRAIN, P2, REFRAIN, P3)
        new = body(P1, P2, P3)  # both copies cut
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change(REFRAIN, "")])
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        self.assertIn("2 times", out["message"])
        # Each cut named by the words around it that stay: the cut sentence with the end of the paragraph before it.
        # One such decision covers its own cut only, not the other copy further down.
        code, out = self.record("v3", new, [change("取出几只旧瓷碗。\n\n" + REFRAIN, "取出几只旧瓷碗。")])
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        code, out = self.record("v4", new, [change("取出几只旧瓷碗。\n\n" + REFRAIN, "取出几只旧瓷碗。"),
                                            change("一层稻草。\n\n" + REFRAIN, "一层稻草。")])
        self.assertEqual(code, 0, out)

    def test_a_change_beside_a_cut_does_not_cover_the_cut(self):
        old = body(P1, REFRAIN, P2, P3)
        new = body(P1.replace("取出几只旧瓷碗。", "取出三只旧瓷碗。"), P2, P3)  # the sentence after P1 cut as well
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change("取出几只旧瓷碗。", "取出三只旧瓷碗。")])
        self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"), out)
        code, out = self.record("v3", new, [change("取出几只旧瓷碗。", "取出三只旧瓷碗。"), change(REFRAIN, "")])
        self.assertEqual(code, 0, out)

    def test_a_cut_of_words_that_stood_once_still_needs_only_its_old_words(self):
        old = body(P1, P2, P3)
        new = body(P1, P2.replace("，又在筐底垫了一层稻草。", "。"), P3)
        self.edit_after_pass(old, new)
        code, out = self.record("v2", new, [change("又在筐底垫了一层稻草", "")])
        self.assertEqual(code, 0, out)


class TheNotesSaySo(unittest.TestCase):
    def test_execution_notes_and_usage_name_repeated_sentences(self):
        notes = (ROOT / "skills" / "novel-workshop" / "references" / "execution.md").read_text(encoding="utf-8")
        line = next(l for l in notes.splitlines() if "同一行里改了几处、相邻几行一起改了，各要一条" in l)
        for phrase in ("同一句话在几处出现", "`offset`", "连着前后留下的字一起引", "一处一条", "r5.20 改正"):
            self.assertIn(phrase, line)
        self.assertLess(line.index("各要一条"), line.index("同一句话在几处出现"))
        usage = (ROOT / "USAGE.md").read_text(encoding="utf-8")
        self.assertIn("同一句话在几处出现、几处都改了，也是一处一条（r5.20 起）", usage)


if __name__ == "__main__":
    unittest.main()

"""Independent public-contract tests for conservative dialogue attribution."""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import unittest

from dialogue_core import extract_dialogues


class DialogueCoreTests(unittest.TestCase):
    def test_explicit_speaker_wins_over_another_characters_action(self):
        for text, expected in (
            ("林舟推开门，沈砚说：“先等一等。”", "沈砚"),
            ("林舟对沈砚说：“先等一等。”", "林舟"),
        ):
            with self.subTest(text=text):
                spans = extract_dialogues([text], names=("林舟", "沈砚"))
                self.assertEqual(len(spans), 1)
                self.assertEqual((spans[0].speaker, spans[0].confidence), (expected, "explicit"))

    def test_multiple_quotes_in_a_paragraph_keep_their_own_speakers(self):
        spans = extract_dialogues(
            ["林舟说：“先等。”沈砚问：“等谁？”"], names=("林舟", "沈砚")
        )
        self.assertEqual(
            [(s.text, s.speaker, s.confidence, s.quote_index) for s in spans],
            [("先等。", "林舟", "explicit", 1), ("等谁？", "沈砚", "explicit", 2)],
        )

    def test_unregistered_old_man_is_unknown_despite_previous_named_speaker(self):
        for text in ("老人说：“是我。”", "林舟听老人说：“是我。”"):
            with self.subTest(text=text):
                spans = extract_dialogues(
                    ["林舟说：“是谁？”", text], names=("林舟", "沈砚")
                )
                self.assertEqual((spans[1].speaker, spans[1].confidence), ("未知", "unknown"))

    def test_ambiguous_or_unattributed_quotes_do_not_inherit_a_speaker(self):
        spans = extract_dialogues(
            ["林舟说：“走吧。”", "林舟和沈砚对视。“现在吗？”", "“等一下。”"],
            names=("林舟", "沈砚"),
        )
        self.assertEqual(
            [(s.speaker, s.confidence) for s in spans[1:]],
            [("未知", "unknown"), ("未知", "unknown")],
        )

    def test_scene_transition_preserves_blank_line_numbering_and_stops_inheritance(self):
        paragraphs = ["林舟说：“走吧。”", "", "三日后，城外。", "“有人吗？”", "风吹过门口。"]
        spans = extract_dialogues(paragraphs, names=("林舟", "沈砚"))
        final = spans[1]
        self.assertEqual((final.para_index, final.quote_id), (4, "p4:q1"))
        self.assertEqual((final.speaker, final.confidence), ("未知", "unknown"))
        self.assertEqual((final.prev_para, final.next_para), (paragraphs[2], paragraphs[4]))

    def test_registered_name_order_does_not_change_attribution(self):
        paragraphs = ["林舟放下杯子，沈砚说：“先听我说完。”"]
        results = [
            [(s.speaker, s.confidence, s.text) for s in extract_dialogues(paragraphs, names=names)]
            for names in (("林舟", "沈砚"), ("沈砚", "林舟"))
        ]
        self.assertEqual(results[0], results[1])
        self.assertEqual(results[0][0][:2], ("沈砚", "explicit"))

    def test_aliases_and_manual_overrides_resolve_to_canonical_names(self):
        spans = extract_dialogues(
            ["阿舟说：“等我。”", "“我知道。”"],
            names=("林舟", "沈砚"),
            aliases={"阿舟": "林舟"},
            speaker_overrides={(2, 1): "沈砚"},
        )
        self.assertEqual(
            [(s.speaker, s.confidence) for s in spans],
            [("林舟", "explicit"), ("沈砚", "manual")],
        )

    def test_quote_offsets_and_text_are_exact_unicode_slices(self):
        raw = "\t林舟说：“🙂 等等，别动。 ”又说：“🙂 等等，别动。 ”\r\n"
        spans = extract_dialogues([raw], names=("林舟",))
        self.assertEqual(len(spans), 2)
        for number, span in enumerate(spans, 1):
            with self.subTest(quote_index=number):
                self.assertEqual(span.quote_index, number)
                self.assertEqual(span.text, "🙂 等等，别动。 ")
                self.assertEqual(raw[span.start:span.end], span.text)
                self.assertEqual((raw[span.start - 1], raw[span.end]), ("“", "”"))
                self.assertEqual(span.raw_para, raw)
                self.assertEqual(span.quote, "“🙂 等等，别动。 ”")
                self.assertEqual(span.quote_id, f"p1:q{number}")
        self.assertLess(spans[0].end, spans[1].start)


if __name__ == "__main__":
    unittest.main()

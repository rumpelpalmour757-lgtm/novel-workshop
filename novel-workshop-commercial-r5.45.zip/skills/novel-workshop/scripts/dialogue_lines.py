#!/usr/bin/env python3
"""Pull the dialogue of a chapter out by speaker: the third of the five revision passes (r5.33; who-speaks rules r5.35).

python3 dialogue_lines.py CHAPTER [--paragraph-mode blank|line] [--names 甲,乙] [--voices VOICES.json] [--format text|json]

Read-only. Reading every line one speaker at a time is how a reader catches a line that is not this person's: narration
words that slipped into speech (a register mismatch), a calm full sentence where the person is in a hurry, the author
explaining the setting through someone's mouth. This script only does the sorting, and it sorts a line only on clear
evidence next to it (r5.35):

- a speaking tag: the subject of 说/问/喊/道…, before the line (老周对程棠说：) or after it (“……”老周说。);
- the clause that a colon closes, or the sentence just before the line in the same paragraph, when a given name is its
  subject (老周看了程棠一眼：“……” goes to 老周).

In a speaking tag only the people in the verb's own clause count (r5.37, the r5.35 review, point 4): the one heard
speaks (宋青听见林满说: 林满); the one compared (宋青比林满先说道), spoken to, looked at or acted on does not; two people
joined as one subject (宋青和林满同时说, 宋青、林满齐声说) both speak, so nobody is picked; two people with an action
between them (宋青安慰林满说) leave it open, unless that action is itself a speaking verb (宋青叮嘱林满说: 宋青). What is
not clear is listed as not attributed, with the possible speakers: a wrong speaker costs more than a line left open.

r5.38 (the r5.37 review, point 4): a group speaking in a clause of its own (宋青看了林满一眼，两人齐声说; 宋青、林满站在
门口，齐声说) is never given to the person named in the clause before: the line is left open with the people who may be
in the group. The walk back joins names with 、 as with 和 (宋青、林满、程棠站在门口：), the whole chain.

The person spoken to, handed something, looked at, pushed or named after 的 is never taken for the speaker: in
他对宋青说：“……” the speaker is 他, so the line stays not attributed. When the subject is a pronoun or someone not on the
list, or two people could be meant, the line is listed as not attributed (with the possible speakers, if any). The
flags point at words worth a second look: written-register words in speech, words the book's voice file says this
person, or nobody, says aloud, and long lines. Whether a line sounds like the person is the reader's judgement; this is
not an AI detector and not a verdict.
"""
import argparse
import bisect
import hashlib
import json
from pathlib import Path
import re
import sys

QUOTE = re.compile(r"“([^”]*)(?:”|$)|「([^」]*)(?:」|$)|『([^』]*)(?:』|$)")
# Words of the written register that rarely come out of anyone's mouth; a hit is a place to read again, not an error.
WRITTEN = ("然而", "因此", "因而", "从而", "并且", "此外", "况且", "倘若", "即便", "此刻", "随即", "旋即", "依旧", "依然",
           "仍旧", "尚未", "业已", "逐一", "依次", "之际", "与此同时")
LONG_MIN = 24  # Han characters in one quoted stretch: read it again for hurry, and for a setting explained to the reader
LIMITS = ("只按台词旁边写明的说话人分栏：说话标签（谁说、谁问）、冒号前那一句或同段紧挨着的上一句的主语；受话人、"
          "递东西给的人、看着的人不算说话人，认不出、拿不准的单列。标出的词只是要再读一遍的地方，像不像这个人说的由人判断。不改文件。")

# Speaking verbs, longest first. A one-character verb inside a longer word (知道, 听说, 问题) is not a speaking tag.
SPEECH = ("说道", "问道", "答道", "喊道", "叫道", "嚷道", "喝道", "笑道", "骂道", "回道", "应道", "念道", "回答", "回嘴",
          "嘀咕", "嘟囔", "嘟哝", "咕哝", "低语", "开口", "插嘴", "接话", "打断", "提醒", "解释", "吩咐", "叮嘱", "嘱咐",
          "补充", "追问", "反问", "质问", "询问", "交代", "招呼", "念叨", "告诉", "冷笑", "说", "问", "道", "讲", "喊",
          "嚷", "吼", "骂", "答", "应")
NOT_SPEECH_BEFORE = {"说": "听小传据学演游劝解", "问": "学疑访顾", "道": "知难味街轨通频渠管隧车霸公人一这那几两地",
                     "讲": "演", "应": "反适供效相"}
NOT_SPEECH_AFTER = {"说": "明服法", "问": "题号", "道": "理路具德观士", "讲": "究座台义", "应": "该当用付", "答": "案卷"}
PRONOUNS = ("他们", "她们", "它们", "我们", "你们", "咱们", "他", "她", "它", "我", "你", "您", "咱", "对方", "那人",
            "这人", "此人", "来人", "有人", "众人", "大家", "谁")
# People named by a common noun. They are not on the list, so a clause they open has a speaker the script cannot name.
PEOPLE = ("小伙子", "老太太", "年轻人", "中年人", "女孩", "男孩", "姑娘", "小伙", "少年", "少女", "男人", "女人", "老人",
          "老头", "老太", "孩子", "小孩", "老板", "伙计", "掌柜", "店主", "摊主", "客人", "护士", "医生", "队长", "士兵",
          "守卫", "卫兵", "司机", "师傅", "大叔", "大婶", "大娘", "大爷", "老者", "青年", "妇人", "汉子", "壮汉", "女子",
          "男子", "家伙", "学生", "老师")
# Right before a person, these make him the one spoken to, handed something, looked at or acted on.
OBJECT_BEFORE = re.compile(
    r"(?:对|向|朝|冲|跟|和|与|同|给|替|帮|为|把|将|被|由|陪|找|等|问|告诉|递给|交给|塞给|扔给|丢给|看|望|盯|瞪|瞥|瞧|瞅|"
    r"扫|打量|拦|拉|扶|推|拽|扯|按|搂|抱|拍|指|喊住|叫住|打断|认出|叫醒|摇醒)(?:了|着|过|住|向|给|到|开)?(?:一眼|两眼)?$")
# Right before a person, these leave it open who speaks next (老周让程棠说: who?).
PIVOT_BEFORE = re.compile(r"(?:让|叫|请|要|逼|求|催|劝|命令|示意|允许|教)(?:着|了)?$")
# Words that may open a clause before its subject (这时老周……).
OPENERS = ("这时", "此时", "那时", "这会儿", "于是", "然后", "接着", "随后", "随即", "突然", "忽然", "终于", "最后", "片刻后",
           "半晌", "良久", "转眼")
JOINED = "和与同及跟、"
# r5.37: in a speaking tag. Right before a person: he is the one heard, so he speaks (宋青听见林满说).
HEARD_BEFORE = re.compile(r"(?:听见|听到|听着|听得|听)(?:了)?$")
# Two people joined by one of these right between them are one subject (和、与、及、顿号) or, for 跟/同 without a word
# of togetherness, the second is the one spoken to (他跟宋青说).
JOINERS = {"和": "and", "与": "and", "及": "joint", "、": "joint", "跟": "with", "同": "with"}
TOGETHER = ("异口同声", "同时", "齐声", "一起", "一齐", "一同", "一块", "一道", "共同", "先后", "两人", "两个人", "二人",
            "俩", "都", "们")
# r5.38: a clause with nobody named that still says a group speaks (两人、二人、三个人、俩, or 齐声、同时、一起…).
GROUP = re.compile(r"(?:[两二三四五六几数]个?人|[俩仨]|%s)" % "|".join(w for w in TOGETHER if w not in ("都", "们")))
BOUNDARY = "。！？!?…；;\n"
CLAUSE = "，,：:"
SPACE = " \t\u3000"


def han_count(text):
    return sum(1 for ch in text if "一" <= ch <= "鿿")


def nonempty_string(value):
    return isinstance(value, str) and bool(value.strip())


def load_voices(data):
    """The book's voice file: speakers with aliases and words they do not say, words only the narration uses, and the
    places the author decided one by one (cases)."""
    if not isinstance(data, dict) or set(data) - {"note", "speakers", "narration_only", "cases"}:
        raise ValueError("The voice file has note, speakers, narration_only and cases only")
    speakers = data.get("speakers", {})
    if not isinstance(speakers, dict):
        raise ValueError("speakers must be an object: name -> {aliases, voice, uses, avoid}")
    for name, item in speakers.items():
        if not nonempty_string(name) or not isinstance(item, dict) or set(item) - {"aliases", "voice", "uses", "avoid"}:
            raise ValueError("Speaker %r: an object with aliases, voice, uses, avoid" % name)
        for key in ("aliases", "uses", "avoid"):
            values = item.get(key, [])
            if not isinstance(values, list) or not all(nonempty_string(v) for v in values):
                raise ValueError("Speaker %s: %s must be a list of nonempty strings" % (name, key))
        if "voice" in item and not nonempty_string(item["voice"]):
            raise ValueError("Speaker %s: voice must be a nonempty string" % name)
    narration_only = data.get("narration_only", [])
    if not isinstance(narration_only, list) or any(
            not isinstance(x, dict) or set(x) - {"text", "say", "note", "except"} or not nonempty_string(x.get("text"))
            or any(k in x and not nonempty_string(x[k]) for k in ("say", "note")) for x in narration_only):
        raise ValueError("narration_only must be a list of {text, say, note, except} with a nonempty text")
    for item in narration_only:
        kept = item.get("except", [])
        if not isinstance(kept, list) or not all(nonempty_string(v) and item["text"] in v and v != item["text"]
                                                 for v in kept):
            raise ValueError("narration_only %s: except lists longer words that contain it (a term the characters "
                             "may say, such as a name of a group)" % item["text"])
    cases = data.get("cases", [])
    if not isinstance(cases, list) or any(
            not isinstance(x, dict) or set(x) - {"word", "chapter", "speaker", "was", "now", "decided", "scope", "note"}
            or not all(nonempty_string(x.get(k)) for k in ("word", "was", "now", "decided"))
            or not (isinstance(x.get("chapter"), int) and not isinstance(x.get("chapter"), bool) and x["chapter"] > 0)
            or any(k in x and not nonempty_string(x[k]) for k in ("speaker", "scope", "note")) for x in cases):
        raise ValueError("cases must be a list of {word, chapter, was, now, decided, speaker, scope, note}: one line the "
                         "author decided, with the chapter, the line before and after, and who decided when")
    return speakers, narration_only


def paragraphs_of(text, paragraph_mode):
    separator = r"\n" if paragraph_mode == "line" else r"\n[ \t\r]*\n"
    out, offset = [], 0
    for match in list(re.finditer(separator, text)) + [None]:
        end = match.start() if match else len(text)
        raw = text[offset:end]
        if raw.strip():
            out.append((offset + len(raw) - len(raw.lstrip()), raw.strip()))
        offset = match.end() if match else len(text)
    return out


class Who:
    """Finds the speaker of one quoted line from the narration right next to it."""

    def __init__(self, aliases):
        self.canonical = {}
        for name, words in aliases.items():
            for word in words:
                self.canonical.setdefault(word, name)
        self.kinds = {w: "name" for w in self.canonical}
        for word in PRONOUNS + PEOPLE:
            self.kinds.setdefault(word, "other")
        people = "|".join(re.escape(w) for w in sorted(self.kinds, key=len, reverse=True))
        self.tokens = re.compile(people)
        self.speech = re.compile("|".join(re.escape(w) for w in SPEECH))
        # What may follow a speaking verb in its clause: 着/了/一句, the person spoken to (他问宋青：).
        self.tail = re.compile(r"(?:道)?(?:着)?(?:了)?(?:一句|一声|两句|几句|声|句)?(?:起来|出来|出口)?(?:%s)?(?:道)?[%s]*"
                               % (people, SPACE))
        self.openers = re.compile("(?:%s)+" % "|".join(OPENERS))
        names = "|".join(re.escape(w) for w in sorted(self.canonical, key=len, reverse=True)) or "(?!)"
        self.joined = re.compile("[%s](%s)" % (JOINED, names))

    def verbs(self, text):
        """Speaking verbs in text that are not part of another word."""
        out = []
        for m in self.speech.finditer(text):
            word = m.group()
            before = text[m.start() - 1] if m.start() else ""
            after = text[m.end()] if m.end() < len(text) else ""
            if len(word) == 1 and (before and before in NOT_SPEECH_BEFORE.get(word, "")
                                   or after and after in NOT_SPEECH_AFTER.get(word, "")):
                continue
            out.append(m)
        return out

    def opens_clause(self, text, start):
        """Whether the person at start is where a clause's subject stands (after 这时, or 门口的…)."""
        clause_start = max(text.rfind(ch, 0, start) for ch in BOUNDARY + CLAUSE) + 1
        pre = text[clause_start:start].strip(SPACE)
        if not pre:
            return True
        if self.tokens.search(pre):
            return False
        return pre.endswith("的") or bool(self.openers.fullmatch(pre))

    def tag_subject(self, text):
        """(name, candidates) when text ends right before a speaking verb, from the people in the verb's own clause;
        None when that clause names nobody who could be its subject (宋青放下杯子，对林满说: look further back)."""
        start = max(text.rfind(ch) for ch in BOUNDARY + CLAUSE) + 1
        clause = text[start:]
        found = list(self.tokens.finditer(clause))
        if not found:
            words = set(GROUP.findall(clause))
            if not words:
                return None
            name, candidates = self.group_before(text[:start])
            if words == {"同时"} and len(candidates) == 1:
                return candidates[0], []  # 宋青放下杯子，同时说: at the same time as his own action, nobody else named
            return name, candidates
        together = any(word in clause[found[-1].end():] for word in TOGETHER)
        people, possessed = [], False  # people: [word, role, end]; roles: subject, object, pivot, heard
        for m in found:
            word, before = m.group(), clause[:m.start()]
            joiner = clause[people[-1][2]:m.start()].strip(SPACE) if people else None
            if clause[m.end():m.end() + 1] == "的":
                # 林满的同伴说 opens the clause: someone not on the list speaks. 看着林满的眼睛说, 听取林满的建议后说:
                # part of what is looked at or taken, not the subject.
                lead = before.strip(SPACE)
                possessed = possessed or not lead or bool(self.openers.fullmatch(lead)) or (
                    joiner in JOINERS and JOINERS[joiner] in ("and", "joint") and people[-1][1] == "subject")
                continue  # 宋青和林满的父亲说: the father may speak with 宋青, so 宋青 is not picked alone
            if before.endswith(("被", "由")) or PIVOT_BEFORE.search(before):
                role = "pivot"
            elif HEARD_BEFORE.search(before):
                role = "heard"
            elif before.endswith("比"):
                role = "object"  # 宋青比林满先说道: 林满 is compared, 宋青 speaks
            elif joiner in JOINERS:
                kind = JOINERS[joiner]
                if people[-1][1] == "object":
                    role = "object"  # 对林满和程棠说: both are spoken to
                elif kind == "joint" or together:
                    role = "joint"
                elif kind == "and":
                    role = "open"  # 宋青和林满说: together, or to 林满; not clear
                else:
                    role = "object"  # 他跟宋青说
            elif OBJECT_BEFORE.search(before):
                role = "object"
            else:
                role = "subject"
            people.append([word, role, m.end()])
        names = lambda rows: [self.canonical[w] for w, r, e in rows if self.kinds[w] == "name"]
        heard = [row for row in people if row[1] == "heard"]
        if heard and heard[-1] is [row for row in people if row[1] != "object"][-1]:
            word = heard[-1][0]
            return (self.canonical[word], []) if self.kinds[word] == "name" else (None, [])
        pivots = [row for row in people if row[1] == "pivot"]
        subjects = [row for row in people if row[1] in ("subject", "heard")]
        grouped = [row for row in people if row[1] in ("joint", "open")]
        if pivots or grouped:
            return None, sorted(set(names(pivots + subjects + grouped)))
        if not subjects:
            return (None, []) if possessed else None
        if possessed:
            return None, sorted(set(names(subjects)))
        if len(subjects) == 1:
            word = subjects[0][0]
            return (self.canonical[word], []) if self.kinds[word] == "name" else (None, [])
        if len(subjects) == 2:
            first, second = subjects
            between = clause[first[2]:clause.index(second[0], first[2])]
            if self.verbs(between):  # 宋青叮嘱林满说: 林满 is the one told
                return (self.canonical[first[0]], []) if self.kinds[first[0]] == "name" else (None, [])
        return None, sorted(set(names(subjects)))

    def group_before(self, text):
        """(None, who may be in the group) for a clause that says a group speaks: the people the walk back over the
        sentence finds (a joined subject is the group), or, when it finds one person, everyone named in the sentence
        (宋青看了林满一眼，两人齐声说: 宋青 and 林满). Never one person alone."""
        sentence = text[max(text.rfind(ch) for ch in BOUNDARY) + 1:]
        name, candidates = self.subject(sentence, False)
        if candidates:
            return None, candidates
        named = [self.canonical[m.group()] for m in self.tokens.finditer(sentence)
                 if self.kinds[m.group()] == "name" and sentence[m.end():m.end() + 1] != "的"]
        return None, sorted(set(named + ([name] if name else []))) if (named or name) else []

    def subject(self, text, tag):
        """(name, candidates): who acts in text, walking back from its end.

        tag: text ends right before a speaking verb, and the people in the verb's own clause decide (tag_subject);
        only when that clause names nobody does the walk go further back. Otherwise the person must open a clause
        (宋青已经按住她的手: 宋青). Objects, possessives and people after 让/叫/请 are skipped; a pronoun or someone not on
        the list as subject means nobody listed.
        """
        if tag:
            found = self.tag_subject(text)
            if found is not None:
                return found
            text = text[:max(text.rfind(ch) for ch in BOUNDARY + CLAUSE) + 1]
            tag = False
        pivot = []
        for m in reversed(list(self.tokens.finditer(text))):
            word = m.group()
            if text[m.end():m.end() + 1] == "的":
                continue  # 老周的徒弟, 她的手: not the subject
            before = text[:m.start()]
            if before.endswith(("被", "由")):  # 程棠被老周拦了下来：the one who stops him may be the one who speaks
                if self.kinds[word] == "name":
                    pivot.append(self.canonical[word])
                continue
            if OBJECT_BEFORE.search(before):
                continue
            if PIVOT_BEFORE.search(before):
                if self.kinds[word] == "name":
                    pivot.append(self.canonical[word])
                continue
            same_clause = tag and not any(ch in text[m.end():] for ch in BOUNDARY + CLAUSE)
            if not same_clause and not self.opens_clause(text, m.start()):
                continue
            if self.kinds[word] != "name":
                return None, sorted(set(pivot))
            name = self.canonical[word]
            if pivot:
                return None, sorted(set(pivot + [name]))
            group, at = [name], m.end()
            while not tag:  # 宋青和林满站在门口, 宋青、林满、程棠站在门口: any of them may speak
                joined = self.joined.match(text, at)
                if not joined:
                    break
                group.append(self.canonical[joined.group(1)])
                at = joined.end()
            if len(group) > 1:
                return None, sorted(set(group))
            return name, []
        return None, sorted(set(pivot))

    def before(self, segment):
        """The narration between the previous line (or the paragraph start) and this line: (name, candidates, basis)."""
        segment = segment.rstrip(SPACE)
        if not segment.strip():
            return None, [], None
        cut = max(segment.rfind(ch) for ch in BOUNDARY)
        lead = segment[cut + 1:]
        if lead.strip(SPACE):
            core = lead.rstrip(SPACE + "：:，,")
            clause_start = max(core.rfind(ch) for ch in CLAUSE) + 1
            last = core[clause_start:]
            for m in reversed(self.verbs(last)):
                if self.tail.fullmatch(last[m.end():]):
                    return self.subject(core[:clause_start + m.start()], True) + ("tag",)
            basis = "colon" if lead.rstrip(SPACE).endswith(("：", ":")) else "beat"
            return self.subject(core, False) + (basis,)
        # The line follows a whole sentence: the one acting in it, right before the line, is taken as the speaker.
        body = segment[:cut]
        return self.subject(body[max(body.rfind(ch) for ch in BOUNDARY) + 1:], False) + ("beat",)

    def after(self, segment):
        """The narration right after the line. Only a speaking verb in its first clause makes it a tag (“……”老周说。);
        a clause that ends in a colon opens the next line instead."""
        m = re.match("[^%s%s]*" % (BOUNDARY, CLAUSE), segment)
        clause = m.group()
        if segment[m.end():m.end() + 1] in ("：", ":"):
            return None, [], None
        verbs = self.verbs(clause)
        if verbs:
            return self.subject(clause[:verbs[0].start()], True) + ("tag",)
        name = self.subject(clause, False)[0]
        return None, [name] if name else [], None  # “走。”老周转身出门。 may be his line; not on its own evidence


def inspect(text, paragraph_mode="blank", names=(), voices=None):
    if paragraph_mode not in {"blank", "line"}:
        raise ValueError("paragraph_mode must be blank or line")
    if voices is not None:
        speakers, narration_only = load_voices(voices)
        cases = voices.get("cases", [])
    else:
        speakers, narration_only, cases = {}, [], []
    aliases = {name: sorted(set([name] + speakers.get(name, {}).get("aliases", [])), key=len, reverse=True)
               for name in list(dict.fromkeys(list(names) + list(speakers)))}
    who = Who(aliases)
    starts = [0] + [m.end() for m in re.finditer("\n", text)]

    def line_of(offset):
        return bisect.bisect_right(starts, offset)

    lines, flags = [], []
    for start, paragraph in paragraphs_of(text, paragraph_mode):
        quotes = list(QUOTE.finditer(paragraph))
        for k, m in enumerate(quotes):
            said = next(g for g in m.groups() if g is not None)
            if not said.strip():
                continue
            previous_end = quotes[k - 1].end() if k else 0
            next_start = quotes[k + 1].start() if k + 1 < len(quotes) else len(paragraph)
            bridge = paragraph[m.end():next_start]
            post = who.after(bridge)
            pre = who.before(paragraph[previous_end:m.start()])
            if post[2] is None and post[1] and k + 1 < len(quotes) and bridge.rstrip(SPACE).endswith(("，", ",")):
                # “三斤。”宋青又压了一次价，“多的算我请你……”: a beat between two parts of one line, set off by a
                # comma, belongs to the one speaking both parts, if the whole bridge has no other subject.
                joint = who.before(bridge)
                if joint[0] and joint[0] == post[1][0]:
                    post = (joint[0], [], "beat")
            if post[2] in ("tag", "beat") and post[0]:
                speaker, candidates, basis = post
            elif post[2] == "tag":  # “……”他说。 someone not on the list, or 他 may point back
                speaker, candidates, basis = None, sorted(set(post[1] + pre[1] + ([pre[0]] if pre[0] else []))), None
            elif pre[0]:
                speaker, candidates, basis = pre
            else:
                speaker, candidates, basis = None, sorted(set(pre[1] + post[1])), None
            entry = {"line": line_of(start + m.start()), "text": m.group(), "speaker": speaker,
                     "candidates": candidates if speaker is None else [], "basis": basis if speaker else None,
                     "han": han_count(said), "flags": []}
            for word in WRITTEN:
                if word in said:
                    entry["flags"].append({"kind": "written", "word": word,
                                           "note": "书面词“%s”进了台词：看人物会不会这样说" % word})
            if speaker and speaker in speakers:
                for word in speakers[speaker].get("avoid", []):
                    if word in said and word not in WRITTEN:
                        entry["flags"].append({"kind": "avoid", "word": word,
                                               "note": "按本书的口吻表，%s不说“%s”" % (speaker, word)})
            for item in narration_only:
                if narration_hit(said, item):
                    entry["flags"].append({"kind": "narration", "word": item["text"],
                                           "note": narration_note(item, cases)})
            if entry["han"] >= LONG_MIN:
                entry["flags"].append({"kind": "long", "word": "",
                                       "note": "一口气 %d 个字：看他急不急、是不是在给读者讲设定" % entry["han"]})
            lines.append(entry)
            if entry["flags"]:
                flags.append(entry)
    by_speaker = {name: [x for x in lines if x["speaker"] == name] for name in aliases}
    return {
        "speakers": {name: items for name, items in by_speaker.items() if items},
        "unattributed": [x for x in lines if x["speaker"] is None],
        "flagged": flags,
        "dialogue_lines": len(lines),
        "voices": {name: speakers[name].get("voice", "") for name in speakers},
        "limits": LIMITS,
    }


def narration_hit(said, item):
    """A narration word in a line, outside the longer words the book lets characters say (except)."""
    word, kept = item["text"], item.get("except", [])
    covered = set()
    for term in kept:
        for m in re.finditer(re.escape(term), said):
            covered.update(range(m.start(), m.end()))
    return any(not set(range(m.start(), m.end())) <= covered for m in re.finditer(re.escape(word), said))


def narration_note(item, cases):
    note = ("叙述里的词“%s”进了台词：这个人在这个场合、对这个人、为了这个目的，会不会这么说？（可能是语域错位，也可能正是"
            "他的声口；这是提示，不是判定）" % item["text"])
    if "say" in item:
        note += "本书记过的口头说法：“%s”，只作参考，换词先看意思变没变" % item["say"]
    decided = [c for c in cases if c["word"] == item["text"]]
    if decided:
        note += "；作者逐处定过：" + "；".join("第%d章%s%s→%s（%s，只管那一处）" % (
            c["chapter"], c.get("speaker", ""), c["was"], c["now"], c["decided"]) for c in decided)
    return note


def text_report(report):
    out = ["台词分栏：%s（sha256 %s…），台词 %d 处" % (report.get("file", ""), report.get("sha256", "")[:12],
                                                 report["dialogue_lines"])]
    for name, items in report["speakers"].items():
        voice = report["voices"].get(name)
        out += ["", "== %s，%d 处%s" % (name, len(items), "（%s）" % voice if voice else "")]
        out += ["  第 %d 行  %s" % (x["line"], x["text"]) for x in items]
    if report["unattributed"]:
        out += ["", "== 叙述里没写明是谁说的，%d 处（按上下文自己认）" % len(report["unattributed"])]
        out += ["  第 %d 行  %s%s" % (x["line"], x["text"], "（可能是：%s）" % "、".join(x["candidates"])
                                    if x["candidates"] else "") for x in report["unattributed"]]
    if report["flagged"]:
        out += ["", "== 要再读一遍的，%d 处" % len(report["flagged"])]
        for x in report["flagged"]:
            out.append("  第 %d 行  %s" % (x["line"], x["text"][:30] + ("…" if len(x["text"]) > 30 else "")))
            out += ["      " + f["note"] for f in x["flags"]]
    out += ["", "逐句问三件事：这词像不像他说的（声口）？他此刻对谁说、为什么说、急不急（急的人也可以把话说完整，对方看得见的"
                "东西常常不必说全；话短了，判断还要落得到事情上、对方接得住）？叙述层的词进了台词没有（语域错位；"
                "他身份里本来就说的术语、行话不算）？三问回到一处：这个人在这个场合、对这个人、为了这个目的，会不会这样说。",
            report["limits"]]
    return "\n".join(out)


def utf8_stdio():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("chapter", type=Path)
    parser.add_argument("--paragraph-mode", choices=("blank", "line"), default="blank")
    parser.add_argument("--names", default="", help="speakers to sort by, separated by commas (，、 also work)")
    parser.add_argument("--voices", type=Path, help="the book's voice file (speakers, aliases, avoid, narration_only)")
    parser.add_argument("--format", choices=("text", "json"), default="text")
    args = parser.parse_args()
    try:
        data = args.chapter.read_bytes()
        names = [n.strip() for n in re.split(r"[,，、]", args.names) if n.strip()]
        voices = json.loads(args.voices.read_text(encoding="utf-8")) if args.voices else None
        report = inspect(data.decode("utf-8-sig"), args.paragraph_mode, names, voices)
        report.update({"file": str(args.chapter), "sha256": hashlib.sha256(data).hexdigest()})
        print(text_report(report) if args.format == "text" else json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    except (OSError, UnicodeError, ValueError, TypeError) as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    sys.exit(main())

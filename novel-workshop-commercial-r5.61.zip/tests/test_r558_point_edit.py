#!/usr/bin/env python3
"""r5.58: the author names one spot in an adopted chapter to change (作者点名的一处小改).

What is pinned and why:

1. The task is written once, in editing.md under "先定范围": the scope list gains a line for it, and a paragraph after
   the fidelity-conversion block says the author's words are the change decision, the change is made without asking
   and without the L2 set the SKILL.md table adds for "修改已采纳章节" (SKILL.md:62 says so, and read literally a
   one-word change got the whole L2 report). It is still a controlled change (constitution section 3): the words are
   recorded, the text around it and the later chapters are read again (looking only: what turns up is listed for the
   author, not changed), the new version is a candidate, and with a delivery-gate state file `replan` comes first. The
   paragraph also says which requests are not this kind. This is the one item in r5.58 that makes the default lighter,
   so its limits are pinned word for word: what it saves is only what the workshop adds by default for L2, not what the
   author asks for.
2. SKILL.md (one line below the table) and quality-loop.md (the `edit_accepted_text` row) only point there; the
   conditions are not repeated elsewhere. The L2 row of the SKILL.md table is left as it was: its hash is pinned in
   test_r554_dialogue.py, and the narrowing lives in the line below it.
3. What the paragraph says the scripts do, run on synthetic text: `workflow_guard.py` after `replan` and the overwrite
   (four states, four permission decisions), a skip-review acceptance checked with `--deliverable` (`claim_final` stays
   BLOCK), `reserve`/`record`/`accept` (then `exact`); and `fact_guard.py impact` reading only the chapters the fact
   ledger registers, so a chapter in progress that is not registered is not listed. The case of a used-up revision
   budget was not run again here; it rests on test_r557_rules.py (WhatTheReviewRanAgain.test_when_the_revision_budget
   _is_used_up).

These tests check wording and tool behaviour only. They do not show that the workshop judges a one-spot change well,
that it reads back far enough, or that anything writes better; no paired scenario test has been run on this paragraph.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
SCRIPTS = SKILL / "scripts"
HEAD = "**作者点名的一处小改（r5.58）。**"
POINTER = "editing.md)“先定范围”里的“作者点名的一处小改”"


def read(path):
    return path.read_text(encoding="utf-8")


def page(rel):
    return read(SKILL / rel)


def rule_pages():
    """The skill's own Markdown pages (style packs and project packs carry other people's text)."""
    for path in sorted(SKILL.rglob("*.md")):
        if "style-packs" not in path.parts and "project-packs" not in path.parts:
            yield path


def point_edit_block():
    text = page("references/editing.md")
    start = text.index(HEAD)
    return text[start:text.index("**再分三样（r5.50）。**", start)]


def run(*args, cwd=None):
    return subprocess.run([sys.executable, "-I", "-B", *map(str, args)], capture_output=True, text=True,
                          encoding="utf-8", cwd=cwd)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, text):
    """Fixtures are written as UTF-8 bytes, so a Windows run sees the same line breaks (test_r525_windows.py)."""
    Path(path).write_bytes(text.encode("utf-8"))


def write_json(path, value):
    save(path, json.dumps(value, ensure_ascii=False))


CH09 = "渡口起了雾。蒲七把缆绳甩上第二根桩，回头喊了一声。\n船上没人应。\n"
EDITED = CH09.replace("第二根桩", "第三根桩")


class ThePointEditIsDefinedOnce(unittest.TestCase):
    def test_editing_defines_it_where_the_scope_is_set(self):
        text = page("references/editing.md")
        scope = text.index("**先定范围（r5.48）。**")
        fidelity = text.index("**保真转换：只换格式，不动字句（r5.57）。**")
        self.assertIn("- 已采纳的章里，作者点明改哪一处、改成什么，说只改这一处的，按下面的“作者点名的一处小改”。",
                      text[scope:fidelity])
        # after the fidelity-conversion block (its last line is about the fact ledger) and before "再分三样"
        self.assertLess(text.index("  - 事实账用 `--chapters-dir` 绑着这一章原文件哈希的"), text.index(HEAD))
        self.assertLess(text.index(HEAD), text.index("**再分三样（r5.50）。**"))
        block = point_edit_block()
        for phrase in ("作者在当前消息里点明改已采纳章节里的哪一处、改成什么，说只改这一处的（一个词、一句话、一个数、一个称呼），"
                       "作者这句话就是修改决定：照改，不先问，也不扩成 L2 的整套（[SKILL.md](../SKILL.md)“任务分级与必经检查”）。",
                       "作者说的那几个字在这一章里不止一处、认不准是哪一处的，先问一句。",
                       "这仍是[宪法](../CONSTITUTION.md)第三节的受控变更，四条都走：",
                       "- **记原话。** 作者这句话就是要记的原话和影响范围，记下是哪一条消息。",
                       "没有新的规则文件或材料作依据的，交付说明里写明依据就是这句话。"):
            self.assertIn(phrase, block)

    def test_reading_back_is_looking_only(self):
        block = point_edit_block()
        for phrase in ("- **回读。** 改好以后连着前后句读一遍。",
                       "改的是叫法、数目、东西在谁手上、谁知道什么、伤势、时间这类事实的，照[连续性](continuity.md)“修订后的回归核对”查后文",
                       "能跑脚本的用 `fact_guard.py impact`，不能跑的把旧说法在正文里搜一遍。",
                       "这一步只是查看：查到的不自己跟着改，列出来问作者要不要一起改；没读到的章节写待核。",
                       "另有一章正在走新章全流程、已经确认的阶段（比如第 1 阶段的继承状态、第 2 阶段的方案）用到了改掉的说法的，"
                       "照[每章七阶段与作者确认](chapter-confirmation.md)“确认是什么意思”，带作者这句原话从受影响的那个阶段重开，并告诉作者",
                       "`fact_guard.py impact` 只看事实账里登记过的章，列不出这一章，要另外看。",
                       "改成的说法和本书的称谓表、规则文件对不上的，照作者说的改，交付说明里说一句，规则文件改不改由作者定。"):
            self.assertIn(phrase, block)

    def test_the_new_version_is_a_candidate(self):
        block = point_edit_block()
        for phrase in ("- **新版是候选稿。** 交付时一两句话说清改在哪一章哪一句、查了哪些地方、查到了什么，写明这一版没有审过、等作者确认。",
                       "不说“已审”“定本”：原来的审稿结论只管原来那一版（[质量闭环](quality-loop.md)“交付状态”）。",
                       "- **有交付门状态文件的**，先用 `replan` 记下作者这句话，再改。",
                       "状态照实显示 AUTHOR 是 NOT_ACCEPTED（较早的一版采纳过），机器检查和审稿是 STALE，“改已采纳的文本”是 REVIEW_REQUIRED，不手改。",
                       "说不用再审的 `accept --skip-review`，要再过一遍检查的 `reserve`、`record`、`accept`，返修额度用完的照那里办",
                       "没有状态文件的，不为这一处另建。"):
            self.assertIn(phrase, block)

    def test_what_is_not_this_kind_and_what_it_does_not_save(self):
        block = point_edit_block()
        for phrase in ("下面几种不算这一种：作者要别处一起改，或者一次点了几章、几处的，按 L2；",
                       "“这段顺一顺”这类没说改成什么的，照上面的分级办；",
                       "不是作者点名、是工坊自己看出来要改已采纳的章的，先列给作者，说清改哪里、为什么，等作者的修改决定，不先改；",
                       "这一章还在新章全流程里、没有定稿的，作者改正文照[每章七阶段与作者确认](chapter-confirmation.md)“确认是什么意思”，"
                       "从受影响的那个阶段重开。",
                       # the orchestrator's default for the question the proposal left open: ask the author
                       "走完七个阶段、已经定稿的章，照那一页的“不扩大”不补走七个阶段；章节门里这一章的记录要不要跟着重开，先问作者一句。",
                       "作者这一次说的，或者作品档案、作者档案、作者改法累计里作者已经定下的检查，照做，照实报结果；作者要状态的，记四项状态。",
                       "这一条省的只是工坊默认给 L2 加的那一套，不省作者要的。"):
            self.assertIn(phrase, block)

    def test_the_other_pages_only_point_there(self):
        skill_line = next(l for l in page("SKILL.md").splitlines() if "作者点名的一处小改" in l)
        self.assertEqual(skill_line, "- 作者点名改已采纳章节里的一处，算不算这一种、怎样走，照 [编辑](references/editing.md)“先定范围”里的"
                                     "“作者点名的一处小改”；算的，不扩成 L2 的整套（r5.58）。")
        row = next(l for l in page("references/quality-loop.md").splitlines() if "`edit_accepted_text`）" in l)
        self.assertEqual(row, "| 修改已采纳的文本（`edit_accepted_text`） | 当前这一版或它的前一版已被作者采纳时 REVIEW_REQUIRED："
                              "先取得作者的修改决定，用 `replan` 记录。作者点名的一处小改，照[编辑](editing.md)“先定范围”里的"
                              "“作者点名的一处小改”办（r5.58） |")
        for path in rule_pages():
            rel = path.relative_to(SKILL).as_posix()
            if rel == "references/editing.md":
                continue
            text = read(path)
            for phrase in (HEAD, "作者这句话就是修改决定", "（一个词、一句话、一个数、一个称呼）", "这一条省的只是工坊默认给 L2 加的那一套"):
                self.assertNotIn(phrase, text, rel)
            for line in text.splitlines():
                if "作者点名的一处小改" in line:
                    self.assertIn(POINTER, line, rel)
        # r5.58 review: USAGE.md's table for the author still put "改已采纳的章节" under L2 with nothing below it; one
        # line under the table now says a named one-spot change is not the L2 set and points to the editing page.
        usage = read(ROOT / "USAGE.md")
        table_row = "| 两章以上、批量重修、改已采纳的章节 | L2 多章 | 先做一章试点；每章各有状态；改了旧章时附回归核对清单 |"
        after = usage[usage.index(table_row) + len(table_row):].lstrip("\n").splitlines()[0]
        self.assertTrue(after.startswith("已采纳的章里，你点明改哪一处、改成什么，说只改这一处的，不走 L2 的整套："), after)
        for phrase in ("改的是事实的再查后文", "查到的只列给你", "新版仍是候选稿",
                       "[编辑](skills/novel-workshop/references/" + POINTER):
            self.assertIn(phrase, after, phrase)

    def test_the_l2_row_is_left_as_it_was(self):
        lines = page("SKILL.md").splitlines()
        row = next(l for l in lines if l.startswith("| L2 多章或定本修订 |"))
        # the narrowing is the line under the table, not a change to this row (its hash is in test_r554_dialogue.py)
        self.assertIn("修改已采纳章节", row)
        self.assertIn("改已采纳章节先取得作者的修改决定", row)
        self.assertNotIn("作者点名", row)
        self.assertGreater(lines.index(next(l for l in lines if "作者点名的一处小改" in l)), lines.index(row))


class ToolCase(unittest.TestCase):
    """Synthetic files in a temporary folder and the scripts run on them, the way the paragraph gives the commands."""

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.dir = Path(self.temp.name)

    def guard(self, *args):
        return run(SCRIPTS / "workflow_guard.py", *args, cwd=self.dir)

    def gate(self, *extra):
        out = self.guard("status", "run.json", *extra)
        return out.returncode, json.loads(out.stdout)["gate"]

    def write_review(self, quote, name):
        write_json(self.dir / name, {
            "schema": "editorial-review/2", "verdict": "PASS", "candidate_sha256": sha(self.dir / "ch09.txt"),
            "reviewer": {"mode": "self_check", "label": "合成演练：同一模型自查"}, "checked_against": ["合成演练：本章全文"],
            "inputs_read": [], "evidence": [{"quote": quote, "in": "candidate"}], "issues": [],
            "machine_dispositions": [], "counter_evidence": "合成演练，只核对工具行为"})

    def accepted_then_edited(self):
        """Chapter 9 checked and accepted; the author names one spot; replan first, then the file is overwritten."""
        save(self.dir / "ch09.txt", CH09)
        write_json(self.dir / "checks.json", {"candidate": "ch09.txt", "checks": [{"id": "len", "type": "length", "min": 10}]})
        self.write_review("蒲七把缆绳甩上第二根桩", "review.json")
        write_json(self.dir / "accept.json", {"candidate_sha256": sha(self.dir / "ch09.txt"),
                                              "source": "合成：作者消息第 12 条“定稿。”", "scope": "第九章"})
        for args in (("start", "run.json", "--task-id", "ch09", "--spec", "checks.json"),
                     ("record", "run.json", "--event-id", "verify-0", "--review", "review.json"),
                     ("accept", "run.json", "--event-id", "accept-1", "--decision", "accept.json")):
            out = self.guard(*args)
            self.assertEqual(out.returncode, 0, out.stdout + out.stderr)
        write_json(self.dir / "decision.json", {"author_decision": "第九章“第二根桩”改成“第三根桩”，就这一处",
                                                "source": "合成：作者消息第 30 条“渡口那段第二根桩改成第三根桩，就这一处。”",
                                                "affected_scope": "第九章一句"})
        out = self.guard("replan", "run.json", "--event-id", "replan-1", "--spec", "checks.json", "--decision", "decision.json")
        self.assertEqual(out.returncode, 0, out.stdout + out.stderr)
        save(self.dir / "ch09.txt", EDITED)


class TheGateAfterTheEdit(ToolCase):
    def test_replan_then_overwrite_shows_the_states_as_they_are(self):
        self.accepted_then_edited()
        code, gate = self.gate()
        self.assertEqual(code, 0)
        self.assertTrue(gate["author"].startswith("NOT_ACCEPTED (an earlier version "), gate["author"])
        self.assertEqual((gate["input_ready"], gate["mechanical"], gate["editorial"]), ("READY", "STALE", "STALE"))
        decisions = {name: value["decision"] for name, value in gate["permissions"].items()}
        self.assertEqual({k: decisions[k] for k in ("claim_mechanical_pass", "claim_reviewed", "claim_final", "edit_accepted_text")},
                         {"claim_mechanical_pass": "BLOCK", "claim_reviewed": "BLOCK", "claim_final": "BLOCK",
                          "edit_accepted_text": "REVIEW_REQUIRED"})
        self.assertEqual(decisions["deliver_as_candidate"], "ALLOW_WITH_WARNING")
        code, gate = self.gate("--deliverable", "ch09.txt")
        self.assertEqual((code, gate["deliverable"]["matches"]), (1, "no"))

    def test_a_skip_review_acceptance_is_still_no_checked_final(self):
        self.accepted_then_edited()
        write_json(self.dir / "accept-2.json", {"candidate_sha256": sha(self.dir / "ch09.txt"),
                                                "source": "合成：作者消息第 31 条“可以，不用再审。”", "scope": "第九章"})
        out = self.guard("accept", "run.json", "--event-id", "accept-2", "--decision", "accept-2.json")
        self.assertEqual(json.loads(out.stdout)["failure"], "ACCEPT_INVALID")  # no check record for this version
        out = self.guard("accept", "run.json", "--event-id", "accept-2", "--decision", "accept-2.json", "--skip-review")
        self.assertEqual(out.returncode, 0, out.stdout)
        code, gate = self.gate("--deliverable", "ch09.txt")
        self.assertEqual((gate["author"], gate["review_skipped_by_author"]), ("ACCEPTED", True))
        self.assertEqual((code, gate["deliverable"]["matches"], gate["permissions"]["claim_final"]["decision"]),
                         (1, "no", "BLOCK"))
        self.assertNotEqual(gate["mechanical"], "GREEN")
        self.assertEqual(gate["permissions"]["claim_reviewed"]["decision"], "BLOCK")

    def test_checked_again_and_accepted_the_file_matches(self):
        self.accepted_then_edited()
        out = self.guard("reserve", "run.json", "--event-id", "reserve-1")
        self.assertEqual(out.returncode, 0, out.stdout)
        self.write_review("蒲七把缆绳甩上第三根桩", "review-2.json")
        out = self.guard("record", "run.json", "--event-id", "verify-1", "--review", "review-2.json")
        self.assertEqual(out.returncode, 0, out.stdout)
        write_json(self.dir / "accept-3.json", {"candidate_sha256": sha(self.dir / "ch09.txt"),
                                                "source": "合成：作者消息第 32 条“定稿。”", "scope": "第九章"})
        self.assertEqual(self.guard("accept", "run.json", "--event-id", "accept-3", "--decision", "accept-3.json").returncode, 0)
        code, gate = self.gate("--deliverable", "ch09.txt")
        self.assertEqual((code, gate["author"], gate["deliverable"]["matches"], gate["permissions"]["claim_final"]["decision"]),
                         (0, "ACCEPTED", "exact", "ALLOW"))
        self.assertEqual(json.loads(read(self.dir / "run.json"))["budgets"]["revisions_used"], 1)


class ReadingBackWithTheFactLedger(ToolCase):
    def test_impact_lists_only_the_chapters_the_ledger_registers(self):
        chapters = self.dir / "正文"
        chapters.mkdir()
        texts = {9: CH09, 12: "第二根桩上还缠着他那截旧缆绳。\n"}
        registered = {}
        for number, text in texts.items():
            name = "第%02d章.md" % number
            save(chapters / name, text)
            registered[str(number)] = {"status": "accepted", "file": name, "sha256": sha(chapters / name)}
        # chapter 13 is being written under the full new-chapter flow: its file is there, the ledger does not list it
        save(chapters / "第13章.md", "蒲七解下缆绳，绳头还湿着。\n")
        write_json(self.dir / "facts.json", {
            "schema": "fact-ledger/1", "entities": {"rope": {"name": "缆绳"}}, "chapters": registered,
            "facts": [{"id": "f9", "entity": "rope", "attribute": "tied_to", "value": "第二根桩", "chapter": 9,
                       "layer": "accepted", "basis": "witnessed_action", "source": "第09章", "change": True},
                      {"id": "f12", "entity": "rope", "attribute": "tied_to", "value": "第二根桩", "chapter": 12,
                       "layer": "accepted", "basis": "text_statement", "source": "第12章", "depends_on": ["f9"]}]})
        out = run(SCRIPTS / "fact_guard.py", "impact", self.dir / "facts.json", "--changed-chapter", "9",
                  "--chapters-dir", chapters)
        report = json.loads(out.stdout)
        self.assertEqual((report["status"], report["chapters_to_recheck"]), ("REGRESSION_REQUIRED", [12]))
        self.assertEqual({hit["chapter"] for hit in report["text_hits"]}, {12})
        self.assertEqual(report["unavailable_chapters"], [])
        self.assertIn("`fact_guard.py impact` 只看事实账里登记过的章，列不出这一章，要另外看。", point_edit_block())


if __name__ == "__main__":
    unittest.main()

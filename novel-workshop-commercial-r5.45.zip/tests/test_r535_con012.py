#!/usr/bin/env python3
"""r5.35: constitution NWC-1.6, CON-012 amended as the author approved on 2026-10-23.

The r5.34 review (point 4) found CON-012 and the voice and material card asking that everything in the material be used
in an action, while the scene module and the inspiration library let a light, a material or a way things age stay
texture. Changes to CON-012 were to be a separate candidate for the author; the author approved this one
("批准，按这段改"). These tests pin the approved sentence and example, the record of the approval, and the places that
quote the rule; nothing else in the constitution changed.
"""
import json
import os
from pathlib import Path
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
APPROVED = ("起草时看着样本和素材写，素材里的东西要落在人的动作和感知里，不只摆着：可以被碰、被用、成为交锋里的道具，也可以只给这一场一处光、"
            "一种材质、一种气味、东西旧成什么样，人在里面做事、察觉；不要求每件陈设都被碰、被拿或变成道具。")
EXAMPLE = "✔ 借来的只是窗外一道冷光和墙上的锈，人在那光里验货，手指蹭到锈，没有哪样变成道具，也算用上。"


def read(relative):
    return (SKILL / relative).read_text(encoding="utf-8")


class CON012(unittest.TestCase):
    def test_the_approved_text(self):
        text = read("CONSTITUTION.md")
        rule = text[text.index("### CON-012"):text.index("## 三、")]
        self.assertIn(APPROVED, rule)
        self.assertIn(EXAMPLE, rule)
        self.assertNotIn("素材里的东西要在动作里用上", rule)
        for kept in ("**为什么**：边写边对着规则写", "**范围**：整章写作、整章重写", "**例外**：没有作者原文的",
                     "**冲突时**：参考图、灵感库和已定设定", "✘ 对着几十条规则逐条写", "**落点**：声音样本与现场素材卡"):
            self.assertIn(kept, rule)

    def test_the_version_and_record(self):
        text = read("CONSTITUTION.md")
        self.assertIn("版本：NWC-1.6（2026-10-23，作者批准修订 CON-012", text)
        self.assertIn("NWC-1.6，2026-10-23（r5.35）：作者转来对 r5.34 的审查和维护交接包", text)
        self.assertIn("## 二、十二条原则", text)
        registry = json.loads(read("assets/constitution-rules.json"))
        self.assertEqual(registry["version"], "NWC-1.6")

    def test_the_places_that_quote_it(self):
        self.assertIn("素材里的东西要落在人的动作和感知里，不只摆着（CON-012，NWC-1.6）", read("assets/voice-material-card.md"))
        self.assertIn("东西要落在人的动作和感知里，不只摆着（CON-012，NWC-1.6）", read("references/inspiration-library.md"))
        for name in ("assets/voice-material-card.md", "references/inspiration-library.md", "references/drafting.md"):
            self.assertNotIn("要在动作里用上", read(name), name)

    def test_the_approval_is_recorded(self):
        folder = ROOT / "maintenance" / "constitution-nwc1.6-2026-10-23"
        if not folder.is_dir():
            self.skipTest("no maintenance folder next to the skills (only the personal build has it)")
        approval = json.loads((folder / "APPROVAL.json").read_text(encoding="utf-8"))
        self.assertEqual((approval["constitution_version"], approval["author_decision"]), ("NWC-1.6", "批准，按这段改"))
        self.assertIn(APPROVED, approval["approved_text"]["preview"])
        self.assertIn(EXAMPLE, approval["approved_text"]["preview"])


if __name__ == "__main__":
    unittest.main()

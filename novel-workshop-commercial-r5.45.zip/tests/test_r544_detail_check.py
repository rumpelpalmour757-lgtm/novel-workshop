#!/usr/bin/env python3
"""r5.44: list what a revision lost, and check rule changes against writing anchors first.

After r5.41-r5.43 the author found that the scenes and details they had asked for were gone, and withdrew those
versions. Two tools came out of it (scripts/detail_check.py):

- compare ORIGINAL REVISED lists, for the author to decide, the wording the original had and the revision lost
  (moved wording is not listed), directional complements that are gone (亮了起来, 弹了出来), and the report-like forms
  the revision brought in: "X是Y的" clauses outside dialogue and position words (屏幕正中, 右上角). It changes nothing
  and always exits 0.
- anchors checks writing anchors (the author's approved revisions with what must survive and what must go):
  --self-test, --prompts for fresh writers, --outputs to check what they wrote. A revision fails when a keep item is
  missing, an avoid item is left, or a new judgment clause or position word comes in.

These tests pin the program's behaviour and the wiring (docs link it, both exports carry it). Whether a set of rules
writes better is not something they can show; the anchor runs and their limits are in the maintenance records.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
DARWIN = ROOT / "skills" / "darwin-novel-workshop"
CHECK = SKILL / "scripts" / "detail_check.py"
ANCHORS = DARWIN / "assets" / "writing-anchors.json"

GOOD = "码头黄得发暗的旧式路灯下，宋迟靠在栈桥的铁柱上，手机亮了起来，一条消息弹了出来。"
REPORTED = "码头的路灯是旧式的。宋迟靠在栈桥上，消息提示跳到屏幕正中。"


def load():
    spec = importlib.util.spec_from_file_location("r544_detail_check", CHECK)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(*args):
    proc = subprocess.run([sys.executable, "-I", "-B", str(CHECK), *map(str, args)],
                          capture_output=True, text=True, encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


def spans(report):
    return [s for row in report["lost_wording"] for s in row["spans"]]


def anchor_file(path, anchors, task="把这段改得像小说。"):
    data = {"format": "novel-workshop-writing-anchors", "format_version": 1, "task": task, "anchors": anchors}
    path.write_bytes(json.dumps(data, ensure_ascii=False).encode("utf-8"))
    return path


def anchor(**changes):
    base = {"id": "T01", "source": "测试", "before": "码头的路灯是旧式的。宋迟靠在铁柱上。",
            "approved_after": "码头旧式的路灯下，宋迟靠在铁柱上。", "keep": ["码头", "旧式", "路灯", "宋迟", "铁柱"],
            "avoid": ["是旧式的"], "why": "测试"}
    base.update(changes)
    return base


class Compare(unittest.TestCase):
    def test_a_report_like_revision_is_listed_item_by_item(self):
        report = load().compare(GOOD, REPORTED)
        self.assertEqual(report["status"], "LISTED")
        self.assertEqual(report["han"], {"original": 36, "revised": 26})
        for lost in ("黄得发暗", "手机"):
            self.assertIn(lost, spans(report))
        self.assertEqual([c["form"] for c in report["lost_complements"]], ["亮了起来", "弹了出来"])
        self.assertEqual([j["clause"] for j in report["new_judgments"]], ["码头的路灯是旧式的"])
        self.assertEqual([p["text"] for p in report["new_positions"]], ["屏幕正中"])

    def test_the_approved_direction_lists_no_new_judgment_or_position(self):
        report = load().compare(REPORTED, GOOD)
        self.assertEqual((report["new_judgments"], report["new_positions"]), ([], []))
        self.assertEqual(spans(report), ["提示跳到屏幕正中"])  # listed for the author to decide, not a failure

    def test_identical_and_moved_text_list_nothing(self):
        dc = load()
        self.assertEqual(dc.compare(GOOD, GOOD)["status"], "NOTHING_LISTED")
        moved = dc.compare("铁盒里叮地一响。老秦把电容扔进脚边的铁盒。", "老秦把电容扔进脚边的铁盒。铁盒里叮地一响。")
        self.assertEqual(moved["status"], "NOTHING_LISTED")

    def test_judgments_count_outside_dialogue_and_only_when_new(self):
        dc = load()
        self.assertEqual(dc.compare("老秦抬头看灯。", "老秦抬头看灯，说：“这灯是旧式的。”")["new_judgments"], [])
        self.assertEqual([j["clause"] for j in dc.compare("老秦抬头看灯。", "老秦抬头看灯。这灯是旧式的。")["new_judgments"]],
                         ["这灯是旧式的"])
        self.assertEqual(dc.compare("这灯是旧式的。老秦坐下。", "这灯是旧式的。老秦坐了下来。")["status"], "NOTHING_LISTED")

    def test_complements_and_positions(self):
        dc = load()
        self.assertEqual(dc.compare("屏幕亮了起来。", "屏幕亮起来。")["lost_complements"], [])  # 了 dropped is not a loss
        seems = dc.compare("这块表看起来很旧。", "这块表很旧。")
        self.assertEqual(seems["lost_complements"], [])  # 看起来 is not a movement
        self.assertEqual(spans(seems), ["看起来"])
        self.assertEqual(dc.compare("字幕停在屏幕正中。", "字幕还停在屏幕正中。")["new_positions"], [])
        more = dc.compare("字幕停在屏幕正中。", "字幕停在屏幕正中，图标挤在右上角。")
        self.assertEqual([p["text"] for p in more["new_positions"]], ["右上角"])

    def test_listed_stretches_drop_pronouns_and_particles_at_the_edges(self):
        dc = load()
        report = dc.compare("他用手扶住椅背，才勉强站起来。", "他扶住椅背，勉强站了起来。")
        self.assertEqual((spans(report), report["lost_complements"]), (["用手"], []))
        self.assertEqual(spans(dc.compare("门外没有第二声。", "门外没再响。")), ["第二声"])

    def test_the_command_reads_only_and_exits_zero(self):
        with tempfile.TemporaryDirectory() as tmp:
            a, b = Path(tmp) / "a.txt", Path(tmp) / "b.txt"
            a.write_bytes(GOOD.encode("utf-8"))
            b.write_bytes(REPORTED.encode("utf-8"))
            before = [hashlib.sha256(p.read_bytes()).hexdigest() for p in (a, b)]
            code, out, err = run("compare", a, b)
            self.assertEqual(code, 0, err)
            self.assertIn("原稿 36 字，修订稿 26 字（少 10 字 -28%）", out)
            self.assertIn("“码头的路灯是旧式的”", out)
            self.assertIn("留不留由作者定", out)
            code, out, err = run("compare", a, b, "--format", "json")
            self.assertEqual((code, json.loads(out)["status"]), (0, "LISTED"))
            self.assertEqual([hashlib.sha256(p.read_bytes()).hexdigest() for p in (a, b)], before)
            code, out, err = run("compare", a, Path(tmp) / "missing.txt")
            self.assertEqual((code, json.loads(out)["status"]), (2, "ERROR"))
            b.write_bytes("码头".encode("gbk"))
            code, out, err = run("compare", a, b)
            self.assertEqual((code, json.loads(out)["status"]), (2, "ERROR"))


class Anchors(unittest.TestCase):
    def test_the_shipped_anchors_pass_their_self_test(self):
        code, out, err = run("anchors", ANCHORS, "--self-test")
        self.assertEqual(code, 0, out + err)
        data = json.loads(ANCHORS.read_text(encoding="utf-8"))
        count = sum(1 + (a["before"] != a["approved_after"]) for a in data["anchors"])
        self.assertIn("通过 %d 个，共 %d 个。" % (count, count), out)

    def test_requests_carry_only_the_task_and_the_text(self):
        data = json.loads(ANCHORS.read_text(encoding="utf-8"))
        with tempfile.TemporaryDirectory() as tmp:
            code, out, err = run("anchors", ANCHORS, "--prompts", tmp)
            self.assertEqual(code, 0, out + err)
            for a in data["anchors"]:
                prompt = (Path(tmp) / (a["id"] + ".prompt.txt")).read_text(encoding="utf-8")
                self.assertIn(a["before"], prompt)
                self.assertIn(a.get("task") or data["task"], prompt)
                self.assertNotIn(a["why"], prompt)
                if a["approved_after"] != a["before"]:
                    self.assertNotIn(a["approved_after"], prompt)

    def test_outputs_pass_fail_and_missing(self):
        data = json.loads(ANCHORS.read_text(encoding="utf-8"))
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            for a in data["anchors"]:
                (out_dir / (a["id"] + ".txt")).write_bytes(a["approved_after"].encode("utf-8"))
            code, out, err = run("anchors", ANCHORS, "--outputs", out_dir)
            self.assertEqual(code, 0, out + err)
            first = data["anchors"][0]
            (out_dir / (first["id"] + ".txt")).write_bytes(first["before"].encode("utf-8"))
            (out_dir / (data["anchors"][-1]["id"] + ".txt")).unlink()
            code, out, err = run("anchors", ANCHORS, "--outputs", out_dir, "--format", "json")
            self.assertEqual(code, 1, out + err)
            status = {r["id"]: r["status"] for r in json.loads(out)["results"]}
            self.assertEqual(status[first["id"]], "FAIL")
            self.assertEqual(status[data["anchors"][-1]["id"]], "MISSING")

    def test_a_candidate_fails_on_lost_keep_left_avoid_or_new_report_forms(self):
        dc = load()
        a = anchor()
        self.assertEqual(dc.check_candidate(a, a["approved_after"])["status"], "PASS")
        self.assertEqual(dc.check_candidate(a, "码头昏暗的路灯下，宋迟靠在铁柱上。")["missing_keep"], ["旧式"])
        self.assertEqual(dc.check_candidate(a, a["before"])["avoid_left"], ["是旧式的"])
        reasons = dc.check_candidate(a, "码头旧式的路灯下，宋迟靠在铁柱上。灯杆是铁的。消息跳到屏幕正中。")["reasons"]
        self.assertEqual(len(reasons), 2, reasons)
        self.assertTrue(reasons[0].startswith("新出现判断句") and reasons[1].startswith("新出现坐标"), reasons)

    def test_malformed_anchors_are_refused(self):
        bad = [anchor(keep=["码头", "铁柱上方"]), anchor(keep=["码头", "路灯是"]), anchor(avoid=["旧式"]), anchor(extra="x"),
               anchor(keep=[]), anchor(before="")]
        with tempfile.TemporaryDirectory() as tmp:
            for n, a in enumerate(bad):
                code, out, err = run("anchors", anchor_file(Path(tmp) / ("bad%d.json" % n), [a]), "--self-test")
                self.assertEqual((code, json.loads(out)["status"]), (2, "ERROR"), a)
            one = anchor_file(Path(tmp) / "one.json", [anchor()])
            two = anchor_file(Path(tmp) / "two.json", [anchor()])
            code, out, err = run("anchors", one, two, "--self-test")
            self.assertEqual(code, 2)
            self.assertIn("anchor id used twice", json.loads(out)["error"])
            wrong = Path(tmp) / "wrong.json"
            wrong.write_bytes(json.dumps({"format": "other", "anchors": []}).encode("utf-8"))
            self.assertEqual(run("anchors", wrong, "--self-test")[0], 2)

    def test_the_self_test_catches_anchors_that_do_not_name_the_problem(self):
        loose = anchor(before="码头旧式的路灯下，宋迟靠着铁柱。", avoid=[], keep=["码头", "旧式", "路灯", "宋迟", "铁柱"])
        with tempfile.TemporaryDirectory() as tmp:
            code, out, err = run("anchors", anchor_file(Path(tmp) / "loose.json", [loose]), "--self-test")
            self.assertEqual(code, 1, out + err)
            self.assertIn("待改的原文本该不通过，却通过了", out)


class Wiring(unittest.TestCase):
    def test_docs_point_to_the_tool_and_both_exports_carry_it(self):
        skill = (SKILL / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn("[detail_check.py](scripts/detail_check.py)", skill)
        editing = (SKILL / "references" / "editing.md").read_text(encoding="utf-8")
        section = editing.split("## 修订前后对照", 1)[1].split("\n## ", 1)[0]
        self.assertIn("detail_check.py compare", section)
        evaluation = (SKILL / "references" / "skill-evaluation.md").read_text(encoding="utf-8")
        self.assertIn("\n## 写作对照例\n", evaluation)
        self.assertIn("[writing-anchors.json](assets/writing-anchors.json)",
                      (DARWIN / "SKILL.md").read_text(encoding="utf-8"))
        spec = importlib.util.spec_from_file_location("r544_export", SKILL / "scripts" / "export_portable.py")
        exporter = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(exporter)
        self.assertIn("scripts/detail_check.py", exporter.SALE_FILES)
        with tempfile.TemporaryDirectory() as tmp:
            for mode in ("portable", "sale"):
                target = Path(tmp) / (mode + ".zip")
                args = [sys.executable, "-I", "-B", str(SKILL / "scripts" / "export_portable.py"), str(target)]
                if mode == "sale":
                    args += ["--mode", "sale"]
                proc = subprocess.run(args, capture_output=True, text=True, encoding="utf-8")
                self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
                with zipfile.ZipFile(target) as archive:
                    names = archive.namelist()
                self.assertTrue(any(n.endswith("novel-workshop/scripts/detail_check.py") for n in names), mode)


if __name__ == "__main__":
    unittest.main()

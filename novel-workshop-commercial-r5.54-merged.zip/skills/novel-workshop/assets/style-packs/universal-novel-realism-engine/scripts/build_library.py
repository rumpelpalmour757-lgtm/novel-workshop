#!/usr/bin/env python3
"""改过 references/ 下的 yaml 之后运行一次，重新生成全部派生文件：

  references/library.json   整库单文件；另外三个脚本只读它
  references/layers.md      200层对照表：每层在原版哪一卷、哪一节，挂在内核还是哪个弹药包
  docs/改动明细.md           各文件 changes 字段汇总
  prompts/                   现成提示词（调用 export_prompt.py --all）

先做校验：必填字段、弹药包编号、门禁不重不漏、200层都挂得上、每条禁令的正则能编译且自带样例能命中。本脚本需要 PyYAML。
用法：python scripts/build_library.py
"""
import json
import re
import subprocess
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
REF = ROOT / "references"
QUOTED = re.compile(r"“[^”\n]*(?:”|$)|「[^」\n]*(?:」|$)|『[^』\n]*(?:』|$)|【[^】\n]*(?:】|$)")
CART_KEYS = ("id", "num", "name", "triggers", "layers", "injections", "craft", "gates")


def load(path):
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def fail(msg):
    sys.exit(f"校验没过：{msg}")


def check_rule(r):
    try:
        pat = re.compile(r["pattern"])
    except re.error as e:
        fail(f"{r['id']} 的正则写错了：{e}")
    for k in ("id", "name", "severity", "pattern", "fix", "home", "scope"):
        if not r.get(k):
            fail(f"{r['id']} 缺少 {k}")
    if r["severity"] not in ("error", "warning"):
        fail(f"{r['id']} 的 severity 只能是 error 或 warning")
    ex = r.get("example") or {}

    def hit(s):
        s = s.lstrip(" \t　")
        return bool(pat.search(QUOTED.sub("", s) if r["scope"] == "narration" else s))
    if ex.get("match") and not hit(ex["match"]):
        fail(f"{r['id']} 的样例「{ex['match'][:20]}」没命中")
    if ex.get("no_match") and hit(ex["no_match"]):
        fail(f"{r['id']} 的反例「{ex['no_match'][:20]}」命中了")


def layers_md(sections, kernel, carts):
    where = {}
    for n in kernel["layers"]:
        where.setdefault(n, []).append("内核")
    for c in carts.values():
        for n in c["layers"]:
            where.setdefault(n, []).append(f"{c['num']} {c['name'].split('、')[0]}")
    out = ["# 200层对照表", "",
           "由 scripts/build_library.py 生成，别手改。原版把200层按小节打包，一个小节挂十几层、写法只有两三条；"
           "本包按场景重组成内核加六个弹药包，这张表用来查某一层现在在哪。", "",
           "| 层 | 原版位置 | 现在挂在 |", "| --- | --- | --- |"]
    sec_of = {n: s for s in sections for n in s["layers"]}
    for n in range(1, 201):
        s = sec_of[n]
        out.append(f"| {n} | {s['volume']} · {s['title']} | {'、'.join(where.get(n, ['（没挂）']))} |")
    return "\n".join(out) + "\n"


def changelog(files):
    out = ["# 改动明细", "", "由 scripts/build_library.py 从各文件的 changes 字段汇总：相对你发来的 v16/v17 原稿改了什么、为什么。", ""]
    for title, items in files:
        if items:
            out += [f"## {title}", ""] + [f"- {x}" for x in items] + [""]
    return "\n".join(out)


def main():
    kernel = load(REF / "kernel.yaml")
    carts = {}
    for f in sorted((REF / "cartridges").glob("*.yaml")):
        c = load(f)
        missing = [k for k in CART_KEYS if k not in c]
        if missing:
            fail(f"{f.name} 缺少 {'、'.join(missing)}")
        if not f.name.startswith(f"{c['num']}_"):
            fail(f"{f.name}：文件名要以编号开头（{c['num']}_…）")
        if c["num"] in carts:
            fail(f"弹药包编号重复：{c['num']}")
        c["file"] = f"references/cartridges/{f.name}"
        carts[c["num"]] = c
    rules_doc = load(REF / "rules.yaml")
    layers = load(REF / "layers.yaml")
    state = load(REF / "state_schema.yaml")
    interop = load(REF / "interop.yaml")

    gate_ids = [g["id"] for g in kernel["gates"]] + [g["id"] for c in carts.values() for g in c["gates"]]
    dup = sorted({g for g in gate_ids if gate_ids.count(g) > 1})
    if dup:
        fail(f"门禁重复：{'、'.join(dup)}")
    homes = {"kernel"} | {c["id"] for c in carts.values()}
    for r in rules_doc["rules"]:
        check_rule(r)
        if r["home"] not in homes:
            fail(f"{r['id']} 的 home 写错了：{r['home']}")
    mounted = set(kernel["layers"]) | {n for c in carts.values() for n in c["layers"]}
    lost = sorted(set(range(1, 201)) - mounted)
    if lost:
        fail(f"这些层没挂在内核或任何弹药包上：{lost}")
    sec_layers = sorted(n for s in layers["sections"] for n in s["layers"])
    if sec_layers != list(range(1, 201)):
        fail("layers.yaml 里的层号要正好是1到200、各出现一次")
    for key, p in interop["packs"].items():
        if not (ROOT / p["doc"]).exists():
            fail(f"题材包 {key} 的说明文件不存在：{p['doc']}")
        if f"## {p['section']}" not in (ROOT / p["doc"]).read_text(encoding="utf-8"):
            fail(f"{p['doc']} 里没有「## {p['section']}」这一节")

    lib = {"version": kernel["version"], "kernel": kernel, "cartridges": carts, "rules": rules_doc["rules"],
           "metrics": rules_doc["metrics"], "counters": rules_doc["counters"], "layers": layers["sections"],
           "state_schema": state["schema"], "interop": interop}
    (REF / "library.json").write_text(json.dumps(lib, ensure_ascii=False, indent=1), encoding="utf-8")
    (REF / "layers.md").write_text(layers_md(layers["sections"], kernel, carts), encoding="utf-8")
    (ROOT / "docs").mkdir(exist_ok=True)
    files = [("内核", kernel.get("changes"))] + [(f"弹药包{c['num']} {c['name']}", c.get("changes")) for c in carts.values()]
    files.append(("禁令与指标", rules_doc.get("changes")))
    (ROOT / "docs" / "改动明细.md").write_text(changelog(files), encoding="utf-8")
    print(f"已生成 library.json、layers.md、改动明细.md：内核{len(kernel['gates'])}道门禁，"
          f"{len(carts)}个弹药包，{len(gate_ids)}道门禁，{len(rules_doc['rules'])}条禁令", flush=True)
    subprocess.run([sys.executable, str(ROOT / "scripts" / "export_prompt.py"), "--all"], check=True)


if __name__ == "__main__":
    main()

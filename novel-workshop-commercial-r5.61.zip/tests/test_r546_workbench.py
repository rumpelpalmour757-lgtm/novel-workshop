"""r5.46 写作台：只读边界、保存先备份与版本核对、启动器参数。

真正的检查在同目录的 workbench_check.mjs（Node 内置模块，只用本机回环地址上的临时服务，不联网）。没有 Node.js 18+ 时跳过。

r5.59：作者 2026-11-19 定下删掉写作台的两个 AI 侧栏（Gemini“改稿建议”和 Google AI 官方 ACP），写作台其他本地功能都留着。
原来这里查启动器时也查 gemini-assist.mjs 在不在、页面里没有 Gemini 的地址和请求头；那个文件删了，改成查两个侧栏的
脚本、检查启动器、接口、页面和导出清单都不在了，说明页写了作者电脑上留下的密钥和本机记录在哪里、可以自己删，
关窗口时服务照旧收尾（原来在 test_r549_acp.py 里查，那个文件只测 ACP 侧栏，删了）。
交付前的审查又补了两处：样式表里只给侧栏按钮用的 `.tool-button.primary` 删了，这里查样式表里的类名页面或脚本都还在用；
收到信号退出那一条，原来在 acp_check.mjs 里实际起服务、发 SIGHUP，随那个文件删了，现在挪进 workbench_check.mjs
（只在 POSIX 上跑），这里查字符串的几行照留。
"""
import importlib.util
import re
import shutil
import subprocess
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILL = HERE.parent / "skills" / "novel-workshop"
FOLDER = SKILL / "scripts" / "oh-story"
DASHBOARD = SKILL / "assets" / "dashboard"
NODE = shutil.which("node")
REMOVED = ("gemini-assist.mjs", "gemini-check.mjs", "check-gemini.cmd", "check-gemini.command", "acp-assist.mjs",
           "acp-check.mjs", "acp-client.mjs", "acp-runtime.mjs", "acp-store.mjs", "check-acp.cmd", "check-acp.command")


def node_major():
    try:
        out = subprocess.run([NODE, "--version"], capture_output=True, text=True, encoding="utf-8", timeout=30).stdout
        return int(re.match(r"v(\d+)", out).group(1))
    except Exception:  # noqa: BLE001
        return 0


@unittest.skipUnless(NODE and node_major() >= 18, "需要 Node.js 18 或更新版本")
class WorkbenchTest(unittest.TestCase):
    def test_server_checks(self):
        proc = subprocess.run([NODE, str(HERE / "workbench_check.mjs"), str(SKILL)],
                              capture_output=True, text=True, encoding="utf-8", timeout=180)
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        self.assertRegex(proc.stdout, r"(\d+)/\1 passed")


class WorkbenchStaticTest(unittest.TestCase):
    def test_launchers_present(self):
        for name in ("open-workbench.cmd", "open-workbench-edit.cmd", "open-workbench-demo.cmd", "open-workbench.command",
                     "open-workbench-edit.command", "open-workbench-demo.command", "workbench.mjs", "dashboard-server.mjs"):
            self.assertTrue((FOLDER / name).is_file(), name)
        self.assertIn("--read-only", (FOLDER / "open-workbench.cmd").read_text(encoding="ascii"))
        self.assertIn("--edit", (FOLDER / "open-workbench-edit.cmd").read_text(encoding="ascii"))


class SidePanelsRemoved(unittest.TestCase):
    """r5.59: the two AI side panels are gone, with their scripts, launchers, routes, page parts and export entries."""

    def test_the_scripts_and_their_launchers_are_gone(self):
        for name in REMOVED:
            self.assertFalse((FOLDER / name).exists(), name)
        self.assertFalse((HERE / "acp_check.mjs").exists())
        self.assertFalse((HERE / "fixtures" / "fake_acp_agent.mjs").exists())

    def test_nothing_imports_or_routes_to_them(self):
        for path in sorted(FOLDER.glob("*.mjs")) + sorted(DASHBOARD.glob("*")):
            # comment lines may say what r5.59 removed; only the code has to be clear of it
            text = "\n".join(line for line in path.read_text(encoding="utf-8").splitlines()
                             if not line.lstrip().startswith(("//", "/*")))
            for gone in ("gemini-assist", "gemini-check", "acp-assist", "acp-runtime", "acp-client", "acp-store",
                         "acp-check", "/api/assist", "/api/acp", "generativelanguage.googleapis.com", "x-goog-api-key",
                         "X-Novel-Workshop-Token", "assistPanel", "acpPanel"):
                self.assertNotIn(gone, text, "%s: %s" % (path.name, gone))
        html = (DASHBOARD / "index.html").read_text(encoding="utf-8")
        for gone in ("改稿建议", "Google AI", "Gemini", "自动互审"):
            self.assertNotIn(gone, html)
        self.assertIn('id="compareButton"', html)
        self.assertIn('id="comparePanel"', html)

    def test_the_exports_no_longer_carry_them(self):
        spec = importlib.util.spec_from_file_location("export_portable_r546_workbench", SKILL / "scripts" / "export_portable.py")
        exporter = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(exporter)
        removed = {"scripts/oh-story/" + name for name in REMOVED}
        self.assertFalse(sorted(removed & set(exporter.SALE_FILES)))
        for mode in ("personal", "sale"):
            core = set(exporter.collect_core(SKILL, mode))
            self.assertFalse(sorted(removed & core), mode)
            for kept in ("scripts/oh-story/dashboard-server.mjs", "scripts/oh-story/workbench.mjs",
                         "assets/dashboard/app.js", "assets/dashboard/index.html"):
                self.assertIn(kept, core, mode)

    def test_the_page_says_where_the_old_files_are(self):
        doc = (SKILL / "references" / "local-workbench.md").read_text(encoding="utf-8")
        self.assertNotIn("## 可选：请 Gemini 改选中的一段", doc)
        self.assertNotIn("## 可选：Google AI（官方 ACP 运行时）", doc)
        section = doc[doc.index("## r5.59 起没有 AI 侧栏"):doc.index("## 章节索引与既有拆文检查")]
        for fact in ("工坊不碰", "可以自己删", "`%APPDATA%\\novel-workshop\\`", "`~/Library/Application Support/novel-workshop/`",
                     "`~/.config/novel-workshop/`", "`gemini.json`", "`acp.json`", "`acp-events.jsonl`",
                     "`workbench.json` 是启动器记的作品目录，还在用"):
            self.assertIn(fact, section)
        # r5.59 review: with workbench.json gone the launcher first looks for 文档/小说写作工坊 and asks only when that is
        # not there either (workbench.mjs), so the page does not say it simply asks again
        self.assertIn("删了也只是下次启动时再找一次作品目录（先找“文档/小说写作工坊”，没有再问）。", section)
        self.assertNotIn("删了也只是下次启动时再问一次", section)
        launcher = (FOLDER / "workbench.mjs").read_text(encoding="utf-8")
        self.assertIn('const DEFAULT_ROOT = join(homedir(), "Documents", "小说写作工坊");', launcher)
        self.assertIn("if (!root && isDirectory(DEFAULT_ROOT)) root = DEFAULT_ROOT;", launcher)
        # the default teacher of the new-chapter flow is not this panel; the author kept it as it was (2026-11-19)
        self.assertIn("初稿交教师的默认设置不变", section)

    def test_no_style_is_left_for_the_removed_parts(self):
        # r5.59 review: `.tool-button.primary` was used only by four buttons of the two panels (assistSend, assistApply,
        # acpConfirmSend, acpInsert); it was left in two selector lists. Every class the style sheet names is still
        # used by the page or by app.js (r5.58 had none left over either).
        css = re.sub(r"/\*.*?\*/", "", (DASHBOARD / "styles.css").read_text(encoding="utf-8"), flags=re.S)
        html = (DASHBOARD / "index.html").read_text(encoding="utf-8")
        script = (DASHBOARD / "app.js").read_text(encoding="utf-8")
        in_page = {name for value in re.findall(r'class="([^"]+)"', html) for name in value.split()}
        unused = []
        for name in sorted(set(re.findall(r"\.([A-Za-z][\w-]*)", css))):
            if name in in_page:
                continue
            if not re.search(r"[\"'` .]%s[\"'` ]|[\"'`]%s\b" % (re.escape(name), re.escape(name)), script):
                unused.append(name)
        self.assertEqual(unused, [])
        self.assertNotIn("primary", css)
        self.assertIn('.tool-button[aria-pressed="true"] {', css)  # the pressed "对比" button still uses it

    def test_the_server_still_closes_when_the_window_closes(self):
        server = (FOLDER / "dashboard-server.mjs").read_text(encoding="utf-8")
        self.assertIn('for (const signal of ["SIGINT", "SIGTERM", "SIGHUP", ...(process.platform === "win32" ? ["SIGBREAK"] : [])])', server)
        self.assertIn("server.close(() => process.exit(0));", server)
        launcher = (FOLDER / "workbench.mjs").read_text(encoding="utf-8")
        self.assertEqual(launcher.count("waitForServer(child);"), 2)
        self.assertIn('return ["SIGINT", "SIGTERM", "SIGHUP", ...(platform === "win32" ? ["SIGBREAK"] : [])];', launcher)


if __name__ == "__main__":
    unittest.main()

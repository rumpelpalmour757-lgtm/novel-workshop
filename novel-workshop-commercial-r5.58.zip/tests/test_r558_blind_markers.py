#!/usr/bin/env python3
"""r5.58: `darwin_eval.py blind` stops on known version clues, leaves nothing behind when a command fails part way,
and names format differences without rewriting the outputs.

The rule (references/skill-evaluation.md) is to take out only the labels that give the version away. Up to r5.57
`blind` checked nothing: an output whose delivery note named its own skill folder went into the A/B packet as it was.
These tests use synthetic outputs only. They show that the clues the script knows about are caught (registered
markers, the outputs' paths as given and in full, differing file names, the arm folders as given at freeze, resolved
and relocated) and that failed commands can be run again; they do not show that a packet that passes is blind: a clue
nobody registered still goes through, and a reviewer copy is still looked over by hand. After the first review
(r5.58): a file name or relative path counts only as a whole name ("1.md" is not found in "ch01.md"); the reviewer copy
the docs describe (same file name in another folder, the original's path registered) can be blinded; the arm folder
given through a symbolic link at freeze is looked for too; a failed command keeps the files that were there before it;
the other spellings of a folder are made from os.sep, so a Windows run tests them as well. How a side refused for an
empty or broken output is counted is written in the docs and not checked here (summarize does not see the refusal).
"""

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from urllib.parse import quote

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
TOOL = ROOT / "skills" / "darwin-novel-workshop" / "scripts" / "darwin_eval.py"

# Runs darwin_eval.main() with a full disk at one save (half a record is written) or one seal (half a line is added to
# SEALS.log), so the exit code, the report and what is left on disk are those of the real command line.
FULL_DISK = r'''
import importlib.util, sys
from pathlib import Path
spec = importlib.util.spec_from_file_location("darwin_eval_full_disk", sys.argv[1])
tool = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tool)
kind, match = sys.argv[2], sys.argv[3]
real = getattr(tool, kind)
def broken(*args, **kwargs):
    if kind == "save" and str(args[0]).endswith(match):
        Path(args[0]).parent.mkdir(parents=True, exist_ok=True)
        Path(args[0]).write_bytes(b'{"task": ')
        raise OSError(28, "No space left on device")
    if kind == "seal" and args[1] == match:
        with (Path(args[0]) / "SEALS.log").open("ab") as handle:
            handle.write(b"half a line")
        raise OSError(28, "No space left on device")
    return real(*args, **kwargs)
setattr(tool, kind, broken)
sys.argv = [sys.argv[1]] + sys.argv[4:]
sys.exit(tool.main())
'''


class BlindMarkers(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.dir = Path(self.temp.name)
        self.work = self.dir / "evaluation"
        self.write(self.work / "TASKS.json", json.dumps({
            "tasks": [{"id": "hold1", "split": "holdout"}],
            "dimensions": [{"id": "facts", "hard": True}, {"id": "readability", "hard": False}]}))
        self.base_root = self.dir / "arms" / "old" / "skills"
        self.cand_root = self.dir / "arms" / "new" / "skills"
        self.write(self.base_root / "SKILL.md", "保留作者给的事实。")
        self.write(self.cand_root / "SKILL.md", "保留作者给的事实，交付前逐条核对。")
        self.base = self.dir / "runs" / "one" / "ch07.md"
        self.cand = self.dir / "runs" / "two" / "ch07.md"
        self.write(self.base, "雾散了。蒲七把缆绳绕回桩上。\n")
        self.write(self.cand, "雾散了，蒲七把缆绳绕回桩上。\n")
        self.cli("freeze", "--baseline", self.base_root, "--candidate", self.cand_root)
        self.seals_after_freeze = (self.work / "SEALS.log").read_bytes()

    @staticmethod
    def write(path, text, raw=None):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw if raw is not None else text.encode("utf-8"))

    def run_tool(self, prefix, command, *args, code=0, work=None, cwd=None):
        result = subprocess.run([sys.executable, "-I", "-B", *prefix, command, str(work or self.work), *map(str, args)],
                                capture_output=True, text=True, encoding="utf-8", cwd=cwd)
        self.assertEqual(result.returncode, code, result.stdout + result.stderr)
        self.assertEqual(result.stderr, "")
        return json.loads(result.stdout)

    def cli(self, command, *args, code=0, work=None, cwd=None):
        return self.run_tool([str(TOOL)], command, *args, code=code, work=work, cwd=cwd)

    def fresh_work(self, name, tasks=("hold1",), *arms):
        """Another evaluation directory with the same dimensions, frozen on the same arms unless others are given."""
        work = self.dir / name
        registry = json.loads((self.work / "TASKS.json").read_text(encoding="utf-8"))
        registry["tasks"] = [{"id": task, "split": "holdout"} for task in tasks]
        self.write(work / "TASKS.json", json.dumps(registry))
        self.cli("freeze", *(arms or ("--baseline", self.base_root, "--candidate", self.cand_root)), work=work)
        return work

    def full_disk(self, kind, match, command, *args, work=None):
        report = self.run_tool(["-c", FULL_DISK, str(TOOL), kind, match], command, *args, code=2, work=work)
        self.assertEqual(report["status"], "ERROR")
        self.assertIn("No space left on device", report["message"])
        return report

    def blind_args(self, *extra):
        return ("--task", "hold1", "--baseline-output", self.base, "--candidate-output", self.cand, "--seed", "7") + extra

    def blind(self, *extra, code=0):
        return self.cli("blind", *self.blind_args(*extra), code=code)

    def assert_nothing_written(self):
        for name in ("packets", "sealed", "TASKS.FROZEN.json"):
            self.assertFalse((self.work / name).exists(), name)
        self.assertEqual((self.work / "SEALS.log").read_bytes(), self.seals_after_freeze)
        self.assertEqual(self.cli("verify")["status"], "OK")

    def test_a_registered_marker_stops_blind_and_names_only_the_side(self):
        self.write(self.cand, "雾散了。\n交付说明：工坊 r5.58 起草。\n")
        report = self.blind("--identity-marker", "r5.57", "--identity-marker", "r5.58", code=2)
        self.assertEqual(report["status"], "ERROR")
        self.assertTrue(report["message"].startswith("candidate output contains a known version marker"), report)
        self.assertNotIn("r5.5", report["message"])
        self.assert_nothing_written()
        self.assertIn("r5.58", self.cand.read_text(encoding="utf-8"))  # the original is never rewritten
        self.write(self.base, "雾散了。\n交付说明：工坊 r5.57 起草。\n")
        report = self.blind("--identity-marker", "r5.57", "--identity-marker", "r5.58", code=2)
        self.assertTrue(report["message"].startswith("baseline and candidate outputs contain a known version marker"))
        self.assert_nothing_written()
        self.assertIn("must contain text", self.blind("--identity-marker", " / ", code=2)["message"])
        self.assert_nothing_written()

    def test_markers_written_in_other_forms_are_caught(self):
        root = str(self.cand_root.resolve())  # FROZEN.json keeps the resolved folder (macOS puts /tmp under /private)
        sep = os.sep  # the other spellings are made from the folder's own separator, so Windows gets them too
        texts = [json.dumps({"source": root.replace(sep, "\\") + "\\novel-workshop\\SKILL.md"}),  # JSON, backslashes
                 json.dumps({"source": root.replace(sep, "/") + "/SKILL.md"}).replace("/", "\\/"),  # JSON, escaped "/"
                 root.replace(sep, "／"), root.upper(), root.replace(sep, sep + "\n", 2),  # full width, case, line break
                 root.replace(sep, sep + "\u200b"), quote(root, safe=""), "file://" + quote(root),  # invisible, URL
                 "按 " + root.replace(sep, sep + "." + sep) + " 起草"]
        for text in texts:
            with self.subTest(text=text[:48]):
                self.write(self.cand, "雾散了。\n" + text + "\n")
                self.assertTrue(self.blind(code=2)["message"].startswith("candidate output"))  # arm folders by default
                self.assert_nothing_written()
        for text in (json.dumps({"note": "按新版工坊起草"}), "按" + quote("新版工坊") + "起草", "按ＸＹ－新版\u3000工坊起草",
                     json.dumps({"note": "按\U00020bb7新版起草"})):  # outside the BMP: a surrogate pair
            with self.subTest(text=text[:48]):  # a registered marker written with \u escapes, URL-encoded, full width
                self.write(self.cand, "雾散了。\n" + text + "\n")
                report = self.blind("--identity-marker", "xy-新版工坊", "--identity-marker", "新版工坊",
                                    "--identity-marker", "\U00020bb7新版", code=2)
                self.assertTrue(report["message"].startswith("candidate output"), report)
                self.assert_nothing_written()

    def test_an_output_naming_its_own_path_is_caught(self):
        self.write(self.base, "雾散了。\n本稿存在 %s。\n" % self.base)
        self.assertTrue(self.blind(code=2)["message"].startswith("baseline output"))
        self.assert_nothing_written()

    def test_a_file_name_shared_by_both_sides_is_not_a_marker(self):
        for path in (self.base, self.cand):
            self.write(path, path.read_text(encoding="utf-8") + "第七章写在 ch07.md 里。\n")
        self.assertEqual(self.blind()["files"], ["A.md", "B.md"])

    def test_differing_file_names_are_markers(self):
        self.cand = self.dir / "runs" / "two" / "ch07-v2.md"
        self.write(self.cand, "雾散了。见 CH07-V2.MD。\n")
        self.assertTrue(self.blind(code=2)["message"].startswith("candidate output"))
        self.assert_nothing_written()

    def test_a_file_name_counts_only_as_a_whole_name(self):
        # Outputs saved as runs/1.md and runs/2.md: "2.md" written on its own is a clue, also next to Chinese or after a
        # folder, but "1.md" inside "ch01.md" or "2.md" inside "v2.md", "x-2.md", "2.mdx" is part of another name.
        self.base, self.cand = self.dir / "runs" / "1.md", self.dir / "runs" / "2.md"
        for text in ("雾散了，见 2.md。", "雾散了，见2.md。", "雾散了，见 runs/2.md。"):
            with self.subTest(text=text):
                self.write(self.base, "雾散了。\n")
                self.write(self.cand, text + "\n")
                self.assertTrue(self.blind(code=2)["message"].startswith("candidate output"))
                self.assert_nothing_written()
        for path in (self.base, self.cand):
            self.write(path, "雾散了。前情见 ch01.md 第三节，后文在 ch02.md、v2.md、x-2.md、2.mdx 里。\n")
        self.assertEqual(self.blind()["files"], ["A.md", "B.md"])

    def test_a_reviewer_copy_keeps_the_file_name_and_the_original_path_is_registered(self):
        # SKILL.md: when blind stops, a reviewer copy with only those places taken out is blinded instead. It keeps the
        # file name, in another folder (two names would make a chapter file both outputs mention a clue on both sides),
        # and the original output's path is registered: on the copy, blind looks only for the copy's own path.
        original = str(self.cand)
        self.write(self.cand, "雾散了。\n交付说明：按 %s 起草；正文存在 %s。\n附：见 %s\n"
                   % (self.cand_root.resolve(), original, original))
        self.assertTrue(self.blind(code=2)["message"].startswith("candidate output"))
        copy = self.dir / "review" / "ch07.md"
        registered = ("--identity-marker", original, "--identity-marker", self.cand.resolve())
        args = ("--task", "hold1", "--baseline-output", self.base, "--candidate-output", copy, "--seed", "7")
        self.write(copy, "雾散了。\n交付说明：按（目录已去掉）起草；正文存在（路径已去掉）。\n附：见 %s\n" % original)  # one missed
        self.assertTrue(self.cli("blind", *args, *registered, code=2)["message"].startswith("candidate output"))
        self.assert_nothing_written()
        self.write(copy, "雾散了。\n交付说明：按（目录已去掉）起草；正文存在（路径已去掉）。\n附：见（路径已去掉）\n")
        self.cli("blind", *args, *registered)
        sealed = json.loads((self.work / "sealed" / "hold1.mapping.json").read_text(encoding="utf-8"))
        label = next(label for label, arm in sealed["mapping"].items() if arm == "candidate")
        self.assertEqual((self.work / "packets" / "hold1" / (label + ".md")).read_bytes(), copy.read_bytes())

    def test_the_arm_folder_as_given_at_freeze_is_looked_for(self):
        # An arm frozen through a symbolic link (macOS puts /tmp and /var under /private) is looked for in both spellings.
        link = self.dir / "link"
        try:
            link.symlink_to(self.dir / "arms", target_is_directory=True)
        except (OSError, NotImplementedError) as error:  # Windows without the right to make links
            self.skipTest("cannot make a symbolic link here: %s" % error)
        given = link / "new" / "skills"
        work = self.fresh_work("linked", ("hold1",), "--baseline", link / "old" / "skills", "--candidate", given)
        frozen = json.loads((work / "FROZEN.json").read_text(encoding="utf-8"))
        self.assertEqual(frozen["candidate"]["path"], str(self.cand_root.resolve()))
        self.assertEqual(frozen["candidate"]["given_path"], os.path.abspath(str(given)))
        for folder in (given, self.cand_root.resolve()):
            with self.subTest(folder=folder):
                self.write(self.cand, "雾散了。\n交付说明：按 %s 起草。\n" % (folder / "novel-workshop" / "SKILL.md"))
                report = self.cli("blind", *self.blind_args(), code=2, work=work)
                self.assertTrue(report["message"].startswith("candidate output"), report)
        self.assertFalse((work / "packets").exists())
        self.write(self.cand, "雾散了，蒲七把缆绳绕回桩上。\n")
        self.assertEqual(self.cli("blind", *self.blind_args(), work=work)["files"], ["A.md", "B.md"])

    def test_relocated_arm_folders_are_looked_for(self):
        # With --baseline-root/--candidate-root the folders the arms were checked in are clues as well.
        moved = self.dir / "moved"
        shutil.copytree(self.dir / "arms", moved)
        roots = ("--baseline-root", moved / "old" / "skills", "--candidate-root", moved / "new" / "skills")
        self.write(self.cand, "雾散了。\n交付说明：按 %s 起草。\n" % (moved / "new" / "skills"))
        self.assertTrue(self.blind(*roots, code=2)["message"].startswith("candidate output"))
        self.assert_nothing_written()
        self.write(self.cand, "雾散了，蒲七把缆绳绕回桩上。\n")
        self.assertEqual(self.blind(*roots)["files"], ["A.md", "B.md"])

    def test_paths_given_from_the_output_folder(self):
        # Run from the folder the outputs are in: an output that writes its own path as it was given is caught; a bare
        # file name is not a clue, so the chapter file both sides name does not stop blind.
        runs = self.dir / "runs"
        relative = ("--task", "hold1", "--baseline-output", Path("one") / "ch07.md",
                    "--candidate-output", Path("two") / "ch07.md", "--seed", "7")
        self.write(self.cand, "雾散了。\n本稿存在 %s。\n" % (Path("two") / "ch07.md"))
        self.assertTrue(self.cli("blind", *relative, code=2, cwd=runs)["message"].startswith("candidate output"))
        self.assert_nothing_written()
        for path in (self.base, self.cand):
            self.write(path, "雾散了。第七章在 ch07.md 里。\n")
        bare = ("--task", "hold1", "--baseline-output", Path("..") / "one" / "ch07.md", "--candidate-output", "ch07.md",
                "--seed", "7")
        self.assertEqual(self.cli("blind", *bare, cwd=runs / "two")["files"], ["A.md", "B.md"])

    def test_a_failed_command_keeps_the_files_that_were_there_before(self):
        # The clean-up removes only what the failing command made: a second verdict for the same task is refused and the
        # sealed one stays; a second task's blind that fails leaves the frozen registry and the first task's packet.
        self.blind()
        verdict = self.dir / "verdict.json"
        self.write(verdict, json.dumps({"task": "hold1", "judge": {"mode": "independent_agent", "label": "测试"},
                                        "dimensions": {"facts": {"result": "tie", "evidence": "雾散了"}}},
                                       ensure_ascii=False))
        self.cli("verdict", "--task", "hold1", "--file", verdict)
        sealed, seals = (self.work / "verdicts" / "hold1.json").read_bytes(), (self.work / "SEALS.log").read_bytes()
        report = self.cli("verdict", "--task", "hold1", "--file", verdict, code=2)
        self.assertIn("refusing to overwrite", report["message"])
        self.assertEqual((self.work / "verdicts" / "hold1.json").read_bytes(), sealed)
        self.assertEqual((self.work / "SEALS.log").read_bytes(), seals)
        self.assertEqual(self.cli("verify")["status"], "OK")
        work = self.fresh_work("two-tasks", ("hold1", "hold2"))
        self.cli("blind", *self.blind_args(), work=work)
        kept = ("TASKS.FROZEN.json", "packets/hold1/A.md", "packets/hold1/B.md", "sealed/hold1.mapping.json", "SEALS.log")
        before = {name: (work / name).read_bytes() for name in kept}
        second = ("--task", "hold2") + self.blind_args()[2:]
        self.full_disk("save", "hold2.mapping.json", "blind", *second, work=work)
        self.assertEqual({name: (work / name).read_bytes() for name in kept}, before)
        self.assertFalse((work / "packets" / "hold2").exists())
        self.assertFalse((work / "sealed" / "hold2.mapping.json").exists())
        self.assertEqual(self.cli("verify", work=work)["status"], "OK")
        self.assertEqual(self.cli("blind", *second, work=work)["files"], ["A.md", "B.md"])

    def test_role_words_and_version_numbers_are_not_guessed(self):
        # Only registered markers, the outputs' own paths, differing file names and the arm folders are checked:
        # "候选稿" is ordinary workshop wording, and a version nobody registered is not looked for.
        self.write(self.cand, "雾散了。candidate r5.58，候选稿，baseline 旧版。\n")
        self.assertEqual(self.blind()["files"], ["A.md", "B.md"])

    def test_unreadable_or_empty_outputs_are_refused_by_side(self):
        for arm, raw, message in (("candidate", b"", "candidate output is empty"),
                                  ("candidate", b"\xef\xbb\xbf \r\n\t\xe3\x80\x80", "candidate output is empty"),
                                  ("candidate", "\u200b\u2060".encode("utf-8"), "candidate output is empty"),
                                  ("baseline", "雾散".encode("gbk"), "baseline output is not valid UTF-8 (byte 0)"),
                                  ("baseline", "雾散".encode("utf-16"), "baseline output is not valid UTF-8")):
            with self.subTest(arm=arm, raw=raw):
                path = self.cand if arm == "candidate" else self.base
                original = path.read_bytes()
                self.write(path, None, raw)
                self.assertTrue(self.blind(code=2)["message"].startswith(message))
                self.assert_nothing_written()
                self.assertEqual(path.read_bytes(), raw)
                self.write(path, None, original)
        self.write(self.base, None, b"\xff")
        self.write(self.cand, None, b"")
        message = self.blind(code=2)["message"]
        self.assertTrue(message.startswith("baseline output is not valid UTF-8 (byte 0); candidate output is empty"))
        self.assert_nothing_written()

    def test_format_differences_are_named_and_the_packets_keep_the_bytes(self):
        self.assertEqual(self.blind()["format_differences"], [])
        self.write(self.base, None, "\ufeff雾散了。\r\n蒲七把缆绳绕回桩上。\r\n".encode("utf-8"))
        work = self.dir / "second"
        self.write(work / "TASKS.json", (self.work / "TASKS.json").read_text(encoding="utf-8"))
        self.cli("freeze", "--baseline", self.base_root, "--candidate", self.cand_root, work=work)
        result = self.cli("blind", *self.blind_args(), work=work)
        self.assertEqual(result["format_differences"], ["byte order mark", "line endings"])
        sealed = json.loads((work / "sealed" / "hold1.mapping.json").read_text(encoding="utf-8"))
        self.assertEqual(sealed["format_differences"], ["byte order mark", "line endings"])
        for label, arm in sealed["mapping"].items():
            original = self.base if arm == "baseline" else self.cand
            self.assertEqual((work / "packets" / "hold1" / (label + ".md")).read_bytes(), original.read_bytes())
        self.write(self.cand, "雾散了，蒲七把缆绳绕回桩上。\n\n\n")
        self.write(self.base, "雾散了。蒲七把缆绳绕回桩上。")
        work = self.dir / "third"
        self.write(work / "TASKS.json", (self.work / "TASKS.json").read_text(encoding="utf-8"))
        self.cli("freeze", "--baseline", self.base_root, "--candidate", self.cand_root, work=work)
        self.assertEqual(self.cli("blind", *self.blind_args(), work=work)["format_differences"],
                         ["line breaks at the end"])

    def test_a_failed_write_during_blind_leaves_nothing_and_can_be_rerun(self):
        self.full_disk("save", ".mapping.json", "blind", *self.blind_args())
        self.assert_nothing_written()
        self.full_disk("seal", "blind", "blind", *self.blind_args())
        self.assert_nothing_written()
        self.assertEqual(self.blind()["files"], ["A.md", "B.md"])
        self.assertEqual(self.cli("verify")["status"], "OK")

    def test_a_failed_seal_after_a_verdict_leaves_nothing_and_can_be_rerun(self):
        self.blind()
        before = (self.work / "SEALS.log").read_bytes()
        verdict = self.dir / "verdict.json"
        self.write(verdict, json.dumps({"task": "hold1", "judge": {"mode": "independent_agent", "label": "测试"},
                                        "dimensions": {"facts": {"result": "tie", "evidence": "雾散了"}}},
                                       ensure_ascii=False))
        self.full_disk("seal", "verdict", "verdict", "--task", "hold1", "--file", verdict)
        self.assertFalse((self.work / "verdicts").exists())
        self.assertEqual((self.work / "SEALS.log").read_bytes(), before)
        self.assertEqual(self.cli("verify")["status"], "OK")
        self.cli("verdict", "--task", "hold1", "--file", verdict)
        before = (self.work / "SEALS.log").read_bytes()
        self.full_disk("save", "hold1.json", "unblind", "--task", "hold1")  # unblind cleans up the same way
        self.assertFalse((self.work / "revealed").exists())
        self.assertEqual((self.work / "SEALS.log").read_bytes(), before)
        self.assertEqual(self.cli("verify")["status"], "OK")
        self.assertEqual(self.cli("unblind", "--task", "hold1")["candidate_vs_baseline"], {"facts": "same"})

    def test_a_failed_seal_during_freeze_leaves_nothing_and_can_be_rerun(self):
        work = self.dir / "second"
        self.write(work / "TASKS.json", (self.work / "TASKS.json").read_text(encoding="utf-8"))
        arms = ("--baseline", self.base_root, "--candidate", self.cand_root)
        self.full_disk("seal", "freeze", "freeze", *arms, work=work)
        self.assertEqual(sorted(p.name for p in work.iterdir()), ["TASKS.json"])
        self.cli("freeze", *arms, work=work)
        self.assertEqual(self.cli("verify", work=work)["status"], "OK")
        fresh = self.dir / "new" / "evaluation"  # a folder the failed command made itself goes too
        self.full_disk("save", "FROZEN.json", "freeze", *arms, work=fresh)
        self.assertFalse((self.dir / "new").exists())
        self.cli("freeze", *arms, work=fresh)
        self.assertEqual(self.cli("verify", work=fresh)["status"], "OK")


if __name__ == "__main__":
    unittest.main()

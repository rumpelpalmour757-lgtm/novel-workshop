#!/usr/bin/env node
// Gemini 接通检查：作者在自己的电脑上运行（双击 check-gemini，或 node gemini-check.mjs）。
// 1) 查这个 Key 能用哪些模型（只取模型清单，不发文字）；2) 用工坊自带的合成示例试一次改稿（和写作台走同一条路）。
// 不发任何文稿。密钥从环境变量 GEMINI_API_KEY 或写作台保存的本机配置里读，不打印、不写进报告。
// 报告写在本机用户配置目录的 gemini-check-report.txt，可以把它发给维护者；报告里没有密钥。
//
// 退出码：0 向 Google 官方接口的真实调用成功；3 请求成功但用的是自定义服务地址（不算真实接通）；
// 1 查模型或试调用失败；2 没有配置密钥、参数不对或 Node 太旧。

import { realpathSync } from "node:fs";
import { mkdir, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { AssistError, SELFTEST_SAMPLE, assistStatus, configDirectory, listModels, normalizeModel, selfTest } from "./gemini-assist.mjs";

const MIN_NODE = 18;

export function parseCheckArguments(argv) {
  const options = { listOnly: false, model: null, help: false, error: null };
  for (let index = 0; index < argv.length; index += 1) {
    const value = argv[index];
    if (value === "--list") options.listOnly = true;
    else if (value === "--help" || value === "-h") options.help = true;
    else if (value === "--model") {
      const model = normalizeModel(argv[index + 1] || "");
      if (!model) options.error = "--model 后面要跟一个模型名，比如 --model gemini-4-argon";
      options.model = model;
      index += 1;
    } else options.error = `不认识的参数：${value}`;
  }
  return options;
}

export async function runCheck({ argv = [], env = process.env, fetchImpl = globalThis.fetch, print = console.log, now = () => new Date() } = {}) {
  const lines = [];
  const say = (text = "") => {
    lines.push(text);
    print(text);
  };
  const options = parseCheckArguments(argv);
  if (options.help || options.error) {
    if (options.error) say(options.error);
    say("用法：node gemini-check.mjs [--list] [--model 模型名]");
    say("  --list   只查这个 Key 能用的模型，不发合成示例");
    say("  --model  这一次用别的模型试（不改写作台保存的设置）");
    return { code: options.error ? 2 : 0, lines };
  }
  if (Number(process.versions.node.split(".")[0]) < MIN_NODE) {
    say(`Node.js 版本是 ${process.versions.node}，需要 ${MIN_NODE} 或更新。`);
    return { code: 2, lines };
  }
  const runEnv = options.model ? { ...env, NOVEL_WORKSHOP_GEMINI_MODEL: options.model } : env;
  const status = await assistStatus(runEnv);
  say("Gemini 接通检查（小说写作工坊）");
  say(`时间：${now().toISOString()}；Node ${process.versions.node}；${process.platform}`);
  say(`服务地址：${status.endpoint === "official" ? "Google 官方接口" : status.endpoint === "custom" ? "自定义地址（NOVEL_WORKSHOP_GEMINI_BASE），结果不算真实接通" : "无效"}`);
  say(`模型：${status.model}${options.model ? "（这一次用 --model 指定）" : ""}`);
  if (!status.keySource) {
    say("还没有配置 API Key：在写作台“改稿建议”→“配置 Gemini”里填，或设置环境变量 GEMINI_API_KEY，再运行一次。");
    return { code: 2, lines };
  }
  say(`密钥来自：${status.keyLocation}（不显示内容）`);
  say("");

  let code = 0;
  say("一、查可用模型（只取清单，不发文字）");
  try {
    const listed = await listModels({ env: runEnv, fetchImpl });
    say(`  能生成文字的模型 ${listed.models.length} 个${listed.truncated ? "（清单很长，只取了前几页）" : ""}。`);
    say(`  ${listed.configured} ${listed.configuredListed ? "在清单里。" : "不在清单里：换成清单里的一个，或核对拼写。"}`);
    for (const model of listed.models.slice(0, 40)) say(`  - ${model.id}${model.displayName ? `（${model.displayName}）` : ""}`);
    if (listed.models.length > 40) say(`  ……另有 ${listed.models.length - 40} 个`);
  } catch (error) {
    code = 1;
    say(`  失败：${error instanceof AssistError ? error.message : String(error?.message || error)}`);
  }
  say("");

  if (!options.listOnly) {
    say("二、用合成示例试一次（只发下面这段，不发任何文稿）");
    say(`  发送：${SELFTEST_SAMPLE.text}`);
    say(`  要求：${SELFTEST_SAMPLE.instruction}`);
    try {
      const result = await selfTest({ env: runEnv, fetchImpl });
      say(`  ${result.real ? "成功：这是一次向 Google 官方接口的真实调用。" : "请求成功，但用的是自定义服务地址，不算真实接通。"}`);
      say(`  模型 ${result.model}；Google 返回的版本 ${result.modelVersion || "没有给出"}；结束原因 ${result.finishReason || "没有给出"}；用时 ${(result.elapsedMs / 1000).toFixed(1)} 秒`);
      say(`  候选稿${result.unchanged ? "（和原文一样）" : ""}：${result.candidate}`);
      if (!result.real && code === 0) code = 3;
    } catch (error) {
      code = 1;
      say(`  失败：${error instanceof AssistError ? error.message : String(error?.message || error)}`);
    }
    say("");
  }
  say(code === 0 && !options.listOnly ? "结论：真实接通。" : code === 0 ? "结论：模型清单取到了；没有试改稿。" : code === 3 ? "结论：没有向 Google 官方接口调用，不算真实接通。" : "结论：没有接通，原因见上面。");
  const report = join(configDirectory(env), "gemini-check-report.txt");
  try {
    await mkdir(configDirectory(env), { recursive: true, mode: 0o700 });
    await writeFile(report, `${lines.join("\n")}\n`, "utf8");
    print(`报告：${report}（没有密钥，可以发给维护者）`);
  } catch {
    print("报告没有写成（配置目录写不进去），上面的输出就是全部结果。");
  }
  return { code, lines, report };
}

function isMain() {
  try {
    return Boolean(process.argv[1]) && realpathSync(process.argv[1]) === realpathSync(fileURLToPath(import.meta.url));
  } catch {
    return false;
  }
}

if (isMain()) {
  const { code } = await runCheck({ argv: process.argv.slice(2) });
  process.exit(code);
}

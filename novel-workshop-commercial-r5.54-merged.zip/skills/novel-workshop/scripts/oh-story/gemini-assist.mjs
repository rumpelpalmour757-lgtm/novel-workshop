// 可选的 Gemini 改稿：只在作者点了“发送”之后，把作者选中的那段正文和作者写的要求发给 Gemini，
// 拿回一份候选稿。这里不读写任何文稿；候选稿采纳与否、怎样保存，都在写作台里由作者决定。
//
// 密钥只从两处来：环境变量 GEMINI_API_KEY，或本机用户配置目录里的 gemini.json（写作台“改稿建议”面板里填）。
// 密钥不回传给浏览器、不写日志、不放进作品目录或技能目录。
//
// r5.47：接口和错误照 Google 的公开文档（2026-10-27 至 10-29 更新的几页）核对过：generateContent、models.list、
// x-goog-api-key 请求头、错误码和 finishReason。“真实接通”只认一件事：向 Google 官方地址发出的请求真的拿回了候选稿；
// 每次调用的结果（成功或失败、时间、模型，不含密钥和文字）记在用户配置目录的 gemini-status.json。

import { homedir } from "node:os";
import { chmod, mkdir, readFile, rename, unlink, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";

export const DEFAULT_MODEL = "gemini-4-argon";
export const OFFICIAL_BASE = "https://generativelanguage.googleapis.com/v1beta";
const MAX_TEXT_CHARS = 6000;
const MAX_INSTRUCTION_CHARS = 500;
// 推理型模型想得久；选段最长 6000 字，给到三分钟。
const REQUEST_TIMEOUT_MS = 180_000;
const LIST_TIMEOUT_MS = 30_000;
const LIST_MAX_PAGES = 5;
const MODEL_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$/;

export const SYSTEM_INSTRUCTION = [
  "你是中文小说编辑，替作者改一段他选中的正文。",
  "按作者这次的要求改；作者没提到的地方不动。",
  "不加新情节、新人物、新设定或新信息，不加心理解释和总结升华。",
  "保住原段里有作用的景物、物件、人物特征、动态，人物的口气和句子的节奏；成立的长句、景物铺陈、直接介绍和必要的方位说明照留。",
  "原段已经成立、没有要改的，就原样交回。",
  "只输出改好的正文，不加标题、说明、引号或列表。",
].join("\n");

// 试接通时发的合成示例：工坊自己写的，不是任何人的作品。
export const SELFTEST_SAMPLE = Object.freeze({
  text: "入秋以后，岬角上的灯一到半夜就闪两下灭一下。守灯的老魏把梯子靠上灯座，一级一级往上爬，腰上挂的工具袋叮当乱响。灯罩里积了一层死蛾子，他用袖口抹开玻璃，借着手电去看灯丝，灯丝好好的，倒是底座那颗接线螺丝松了半圈。",
  instruction: "这是接通测试用的合成示例。把这段改得紧凑一点；情节别动，别加新东西。",
});

const BLOCK_FINISH = new Set(["SAFETY", "PROHIBITED_CONTENT", "BLOCKLIST", "SPII", "IMAGE_SAFETY", "IMAGE_PROHIBITED_CONTENT"]);

export class AssistError extends Error {
  constructor(status, code, message) {
    super(message);
    this.name = "AssistError";
    this.status = status;
    this.code = code;
  }
}

// 写不进配置目录时（只读磁盘之类），状态至少在这次运行里是对的。
const memoryRecords = new Map();

export function configDirectory(env = process.env, platform = process.platform, home = homedir()) {
  if (env.NOVEL_WORKSHOP_CONFIG_DIR) return resolve(env.NOVEL_WORKSHOP_CONFIG_DIR);
  if (platform === "win32") return join(env.APPDATA || join(home, "AppData", "Roaming"), "novel-workshop");
  if (platform === "darwin") return join(home, "Library", "Application Support", "novel-workshop");
  return join(env.XDG_CONFIG_HOME || join(home, ".config"), "novel-workshop");
}

function configFile(env) {
  return join(configDirectory(env), "gemini.json");
}

function statusFile(env) {
  return join(configDirectory(env), "gemini-status.json");
}

export function normalizeModel(value) {
  if (typeof value !== "string") return null;
  const name = value.trim().replace(/^models\//, "");
  return MODEL_PATTERN.test(name) ? name : null;
}

async function readJsonFile(path, unreadable) {
  try {
    const parsed = JSON.parse(await readFile(path, "utf8"));
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch (error) {
    if (error?.code === "ENOENT") return {};
    if (unreadable) throw unreadable;
    return {};
  }
}

async function readStoredConfig(env) {
  return readJsonFile(configFile(env), new AssistError(500, "assist_config_unreadable", "本机的 Gemini 配置文件读不出来，可以在面板里清除后重填"));
}

async function writePrivateJson(path, data) {
  await mkdir(dirname(path), { recursive: true, mode: 0o700 });
  const temporary = `${path}.${process.pid}.tmp`;
  try {
    await writeFile(temporary, `${JSON.stringify(data, null, 2)}\n`, { encoding: "utf8", mode: 0o600 });
    await chmod(temporary, 0o600).catch(() => {});
    await rename(temporary, path);
  } catch (error) {
    await unlink(temporary).catch(() => {});
    throw error;
  }
}

function apiBase(env) {
  const base = (env.NOVEL_WORKSHOP_GEMINI_BASE || OFFICIAL_BASE).replace(/\/+$/, "");
  let url;
  try {
    url = new URL(base);
  } catch {
    throw new AssistError(500, "assist_base_invalid", "Gemini 服务地址无效");
  }
  const loopback = ["127.0.0.1", "localhost", "[::1]"].includes(url.hostname);
  if (url.protocol !== "https:" && !(url.protocol === "http:" && loopback)) {
    throw new AssistError(500, "assist_base_insecure", "Gemini 服务地址必须是 https");
  }
  return base;
}

function endpointKind(base) {
  return base === OFFICIAL_BASE ? "official" : "custom";
}

async function resolvedSettings(env) {
  const stored = await readStoredConfig(env);
  const envKey = typeof env.GEMINI_API_KEY === "string" ? env.GEMINI_API_KEY.trim() : "";
  const fileKey = typeof stored.apiKey === "string" ? stored.apiKey.trim() : "";
  const rawModel = env.NOVEL_WORKSHOP_GEMINI_MODEL || stored.model || DEFAULT_MODEL;
  return {
    apiKey: envKey || fileKey,
    keySource: envKey ? "env" : fileKey ? "file" : null,
    model: normalizeModel(rawModel) || String(rawModel).trim(),
  };
}

async function readRecord(env) {
  const dir = configDirectory(env);
  const fromFile = await readJsonFile(statusFile(env));
  const fromMemory = memoryRecords.get(dir) || {};
  const pick = (name) => {
    const a = fromFile[name];
    const b = fromMemory[name];
    if (!a) return b || null;
    if (!b) return a;
    return String(b.at) >= String(a.at) ? b : a;
  };
  return { lastCall: pick("lastCall"), lastList: pick("lastList") };
}

async function writeRecord(env, name, entry) {
  const dir = configDirectory(env);
  memoryRecords.set(dir, { ...(memoryRecords.get(dir) || {}), [name]: entry });
  try {
    const current = await readJsonFile(statusFile(env));
    await writePrivateJson(statusFile(env), { ...current, [name]: entry });
  } catch {
    // 记录只是给作者看的状态，写不进去不影响改稿本身。
  }
}

async function clearRecord(env) {
  memoryRecords.delete(configDirectory(env));
  await unlink(statusFile(env)).catch(() => {});
}

export async function assistStatus(env = process.env) {
  const settings = await resolvedSettings(env);
  let base = null;
  try {
    base = apiBase(env);
  } catch {}
  const record = settings.apiKey ? await readRecord(env) : { lastCall: null, lastList: null };
  const lastCall = record.lastCall;
  let state = "unconfigured";
  if (settings.apiKey) {
    if (lastCall && !lastCall.ok) state = "failed";
    else if (lastCall && lastCall.ok && lastCall.endpoint === "official" && lastCall.model === settings.model) state = "connected";
    else state = "configured";
  }
  return {
    state,
    label: { unconfigured: "未配置", configured: "已配置，还没有真实调用成功过", connected: "已真实接通", failed: "上次调用失败" }[state],
    model: settings.model,
    endpoint: base ? endpointKind(base) : "invalid",
    keySource: settings.keySource,
    keyLocation: settings.keySource === "env" ? "环境变量 GEMINI_API_KEY" : settings.keySource === "file" ? "本机用户配置目录" : null,
    lastError: state === "failed" ? lastCall.message : null,
    lastCall,
    lastList: record.lastList,
    selftestSample: SELFTEST_SAMPLE,
  };
}

export async function saveAssistConfig(payload, env = process.env) {
  if (!payload || typeof payload !== "object") throw new AssistError(400, "invalid_payload", "配置内容无效");
  const target = configFile(env);
  if (payload.clear === true) {
    try {
      await unlink(target);
    } catch (error) {
      if (error?.code !== "ENOENT") throw new AssistError(500, "assist_config_unwritable", "清除本机 Gemini 配置失败");
    }
    await clearRecord(env);
    return assistStatus(env);
  }
  const stored = await readStoredConfig(env);
  const next = { ...stored };
  if (payload.apiKey !== undefined) {
    if (typeof payload.apiKey !== "string" || !payload.apiKey.trim() || payload.apiKey.length > 256 || /\s/.test(payload.apiKey.trim())) {
      throw new AssistError(400, "invalid_key", "API Key 格式不对：不能为空、不能有空格");
    }
    next.apiKey = payload.apiKey.trim();
  }
  if (payload.model !== undefined) {
    const model = normalizeModel(payload.model);
    if (!model) throw new AssistError(400, "invalid_model", "模型名只能用字母、数字、点、横线和下划线（前面的 models/ 可以不写）");
    next.model = model;
  }
  try {
    await writePrivateJson(target, next);
  } catch {
    throw new AssistError(500, "assist_config_unwritable", "保存本机 Gemini 配置失败");
  }
  // 换了密钥或模型，上一次的调用结果就不算数了。
  await clearRecord(env);
  return assistStatus(env);
}

function scrub(message, secret) {
  const text = String(message || "");
  return secret ? text.split(secret).join("［密钥已隐去］") : text;
}

// HTTP 错误按 Google 的错误表说成作者能处理的话；Google 原话（去掉密钥）附在后面。
function httpProblem(status, body, settings, purpose) {
  const detail = scrub(body?.error?.message || "", settings.apiKey).slice(0, 200);
  const apiStatus = String(body?.error?.status || "");
  const tail = detail ? `（Google 的说明：${detail}）` : "";
  if (status === 400 && (/api[ _-]?key/i.test(detail) || apiStatus === "UNAUTHENTICATED")) {
    return [401, "assist_key_rejected", `Gemini 不接受这个 API Key${tail}`];
  }
  if (status === 400 && apiStatus === "FAILED_PRECONDITION") {
    return [403, "assist_account", `这个账号现在还不能调用：常见原因是项目没有开通结算，或所在地区不能用免费额度${tail}`];
  }
  if (status === 401 || status === 403) {
    return [401, "assist_key_rejected", "Gemini 不接受这个 API Key，或它没有权限。常见原因：Key 没有限定只用于 Gemini API（Google 会拒绝不加限定的标准 Key）；Key 长期没用或泄露后被停用；项目没有开通结算或不在可用范围。可以到 Google AI Studio 的 API Keys 页看这个 Key 的标签" + tail];
  }
  if (status === 402) return [402, "assist_payment", `预付额度用完了：充值或打开自动续费以后再试${tail}`];
  if (status === 404) {
    return purpose === "list"
      ? [502, "assist_upstream", `模型清单的接口找不到（404）${tail}`]
      : [404, "assist_model_missing", `找不到模型 ${settings.model}，或这个 Key 不能用它：点“查可用模型”看这个 Key 能用哪些${tail}`];
  }
  if (status === 429) return [429, "assist_quota", `请求太频繁或额度用完了，过一会儿再试${tail}`];
  if (status === 504) return [502, "assist_upstream", `Gemini 处理超时（504）：可以少选一些再试${tail}`];
  if (status >= 500) return [502, "assist_upstream", `Gemini 服务暂时出错（${status}），过一会儿再试${tail}`];
  return [502, "assist_request_rejected", `Gemini 拒绝了这次请求（${status}）${tail}`];
}

function finishProblem(finish) {
  if (!finish || finish === "STOP") return null;
  if (BLOCK_FINISH.has(finish)) return [422, "assist_blocked", `这段文字被 Gemini 的内容规则拦下了（${finish}），没有候选稿`];
  if (finish === "RECITATION") return [422, "assist_blocked", "Gemini 认为结果和已有的文字太像，停下了（RECITATION），没有候选稿"];
  if (finish === "LANGUAGE") return [422, "assist_blocked", "Gemini 不支持这段文字的语言（LANGUAGE），没有候选稿"];
  if (finish === "MAX_TOKENS" || finish === "CONTINUATION") {
    return [502, "assist_incomplete", `回答被截断了（${finish}）：不完整的结果不给你，少选一些再试`];
  }
  return [502, "assist_incomplete", `Gemini 的回答没有正常结束（${finish}），这份结果不能用`];
}

export function buildRequestBody(text, instruction) {
  const ask = instruction && instruction.trim() ? instruction.trim() : "帮我改这段。";
  return {
    systemInstruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
    contents: [{ role: "user", parts: [{ text: `作者的要求：${ask}\n\n要改的正文：\n${text}` }] }],
  };
}

async function callGemini(url, init, settings, fetchImpl, timeoutMs) {
  try {
    return await fetchImpl(url, { ...init, signal: AbortSignal.timeout(timeoutMs) });
  } catch (error) {
    const reason = error?.name === "TimeoutError" ? "等了太久没有回应" : scrub(error?.cause?.code || error?.message || "网络错误", settings.apiKey);
    throw new AssistError(502, "assist_network", `连不上 Gemini：${reason}`);
  }
}

async function readBody(response) {
  try {
    return await response.json();
  } catch {
    return null;
  }
}

export async function reviseWithGemini(payload, { env = process.env, fetchImpl = globalThis.fetch } = {}) {
  const text = typeof payload?.text === "string" ? payload.text : "";
  const instruction = typeof payload?.instruction === "string" ? payload.instruction : "";
  if (!text.trim()) throw new AssistError(400, "empty_selection", "先在文稿里选中要改的那段");
  if ([...text].length > MAX_TEXT_CHARS) throw new AssistError(413, "selection_too_long", `一次最多发送 ${MAX_TEXT_CHARS} 字，请少选一些`);
  if ([...instruction].length > MAX_INSTRUCTION_CHARS) throw new AssistError(413, "instruction_too_long", `要求最多 ${MAX_INSTRUCTION_CHARS} 字`);
  const settings = await resolvedSettings(env);
  if (!settings.apiKey) throw new AssistError(400, "assist_unconfigured", "还没有配置 Gemini API Key");
  if (!normalizeModel(settings.model)) throw new AssistError(400, "invalid_model", "模型名无效");
  const base = apiBase(env);
  const endpoint = endpointKind(base);
  const url = `${base}/models/${encodeURIComponent(settings.model)}:generateContent`;
  const started = Date.now();
  const record = (ok, extra) => writeRecord(env, "lastCall", {
    ok, at: new Date().toISOString(), model: settings.model, endpoint, elapsedMs: Date.now() - started, ...extra,
  });
  const fail = async (status, code, message) => {
    await record(false, { code, message });
    return new AssistError(status, code, message);
  };

  let response;
  try {
    response = await callGemini(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": settings.apiKey },
      body: JSON.stringify(buildRequestBody(text, instruction)),
    }, settings, fetchImpl, REQUEST_TIMEOUT_MS);
  } catch (error) {
    throw await fail(error.status, error.code, error.message);
  }
  const body = await readBody(response);
  if (!response.ok) throw await fail(...httpProblem(response.status, body, settings, "revise"));

  const blocked = body?.promptFeedback?.blockReason;
  if (blocked) throw await fail(422, "assist_blocked", `这段文字被 Gemini 拦下了（${blocked}），没有候选稿`);
  const candidate = Array.isArray(body?.candidates) ? body.candidates[0] : null;
  const parts = Array.isArray(candidate?.content?.parts) ? candidate.content.parts : [];
  const output = parts.filter((part) => typeof part?.text === "string" && part.thought !== true).map((part) => part.text).join("").trim();
  const finish = candidate?.finishReason || null;
  const problem = finishProblem(finish);
  if (problem) throw await fail(...problem);
  if (!output) throw await fail(502, "assist_empty", "Gemini 没有给出正文");
  const modelVersion = typeof body?.modelVersion === "string" ? body.modelVersion.slice(0, 120) : null;
  await record(true, { modelVersion });
  return {
    candidate: output,
    unchanged: output === text.trim(),
    model: settings.model,
    modelVersion,
    finishReason: finish,
    endpoint,
    elapsedMs: Date.now() - started,
  };
}

// 这个 Key 能用哪些模型：只取 Google 的模型清单，不发任何文字。
export async function listModels({ env = process.env, fetchImpl = globalThis.fetch } = {}) {
  const settings = await resolvedSettings(env);
  if (!settings.apiKey) throw new AssistError(400, "assist_unconfigured", "还没有配置 Gemini API Key");
  const base = apiBase(env);
  const endpoint = endpointKind(base);
  const found = [];
  let pageToken = "";
  for (let page = 0; page < LIST_MAX_PAGES; page += 1) {
    const query = new URLSearchParams({ pageSize: "1000" });
    if (pageToken) query.set("pageToken", pageToken);
    let response;
    try {
      response = await callGemini(`${base}/models?${query}`, { method: "GET", headers: { "x-goog-api-key": settings.apiKey } }, settings, fetchImpl, LIST_TIMEOUT_MS);
    } catch (error) {
      await writeRecord(env, "lastList", { ok: false, at: new Date().toISOString(), endpoint, code: error.code });
      throw error;
    }
    const body = await readBody(response);
    if (!response.ok) {
      const [status, code, message] = httpProblem(response.status, body, settings, "list");
      await writeRecord(env, "lastList", { ok: false, at: new Date().toISOString(), endpoint, code });
      throw new AssistError(status, code, message);
    }
    for (const model of Array.isArray(body?.models) ? body.models : []) {
      const methods = Array.isArray(model?.supportedGenerationMethods) ? model.supportedGenerationMethods : [];
      if (typeof model?.name !== "string" || !methods.includes("generateContent")) continue;
      found.push({
        id: model.name.replace(/^models\//, ""),
        baseModelId: typeof model.baseModelId === "string" ? model.baseModelId : null,
        displayName: typeof model.displayName === "string" ? model.displayName.slice(0, 128) : null,
        inputTokenLimit: Number.isFinite(model.inputTokenLimit) ? model.inputTokenLimit : null,
        outputTokenLimit: Number.isFinite(model.outputTokenLimit) ? model.outputTokenLimit : null,
        thinking: typeof model.thinking === "boolean" ? model.thinking : null,
      });
    }
    pageToken = typeof body?.nextPageToken === "string" ? body.nextPageToken : "";
    if (!pageToken) break;
  }
  found.sort((a, b) => a.id.localeCompare(b.id));
  const configuredListed = found.some((model) => model.id === settings.model || model.baseModelId === settings.model);
  const at = new Date().toISOString();
  await writeRecord(env, "lastList", { ok: true, at, endpoint, count: found.length, model: settings.model, configuredListed });
  return { models: found, configured: settings.model, configuredListed, endpoint, at, truncated: Boolean(pageToken) };
}

// 用合成示例走一遍和改稿完全相同的路：只发 SELFTEST_SAMPLE，不发任何文稿。
export async function selfTest({ env = process.env, fetchImpl = globalThis.fetch } = {}) {
  const result = await reviseWithGemini(SELFTEST_SAMPLE, { env, fetchImpl });
  return { ...result, sample: SELFTEST_SAMPLE, real: result.endpoint === "official" };
}

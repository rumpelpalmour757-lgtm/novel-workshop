// r5.49 P1：Google AI（官方 ACP 运行时）连接原型的检查。
// 全部对着 fixtures/fake_acp_agent.mjs —— 小说写作工坊自己写的模拟 ACP 程序，不是 Google 的 —— 不联网，
// 不下载、不启动任何 Google 程序。这里通过只说明工坊这一侧的分帧、状态、取消、权限、快照和路由做对了，
// 不说明能接通官方运行时、能登录真实账号，也没有在 Windows 上跑过。
// 用法：node acp_check.mjs <技能目录>
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { EventEmitter } from "node:events";
import { readFileSync } from "node:fs";
import { createServer, request as httpRequest } from "node:http";
import { appendFile, chmod, mkdir, mkdtemp, readFile, readdir, realpath, rm, stat, symlink, unlink, utimes, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { basename, dirname, join } from "node:path";
import { PassThrough } from "node:stream";
import { fileURLToPath, pathToFileURL } from "node:url";

const skill = process.argv[2];
const HERE = dirname(fileURLToPath(import.meta.url));
const FAKE = join(HERE, "fixtures", "fake_acp_agent.mjs");
const load = (name) => import(pathToFileURL(join(skill, "scripts", "oh-story", name)).href);
const client = await load("acp-client.mjs");
const rt = await load("acp-runtime.mjs");
const assist = await load("acp-assist.mjs");
const check = await load("acp-check.mjs");
const store = await load("acp-store.mjs");
const { createDashboardServer } = await load("dashboard-server.mjs");

const results = [];
// 这台机器上查不了的一条（比如看不到 /proc）：记成“跳过”并写明原因，计数里看得见，不算通过也不算失败。
class Skip extends Error {}
function skip(reason) {
  throw new Skip(reason);
}
// 只跑名字对得上的几条（NOVEL_WORKSHOP_TEST_ONLY=正则）：test_r550_acp.py 用它快速查“跳过”的路子。没对上的不计数。
const ONLY = process.env.NOVEL_WORKSHOP_TEST_ONLY ? new RegExp(process.env.NOVEL_WORKSHOP_TEST_ONLY) : null;
async function test(name, fn) {
  if (ONLY && !ONLY.test(name)) return;
  try {
    await fn();
    results.push(["ok", name]);
  } catch (error) {
    if (error instanceof Skip) results.push(["SKIP", name, `原因：${error.message}`]);
    else results.push(["FAIL", name, error?.stack || String(error)]);
  }
}

const wait = (ms) => new Promise((accept) => setTimeout(accept, ms));
async function until(predicate, { timeout = 6000, step = 20, what = "条件" } = {}) {
  const end = Date.now() + timeout;
  while (Date.now() < end) {
    if (await predicate()) return;
    await wait(step);
  }
  throw new Error(`等了 ${timeout} 毫秒，${what}还没有成立`);
}
function alive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}
const sha = (text) => createHash("sha256").update(text, "utf8").digest("hex");
const shaBytes = (buffer) => createHash("sha256").update(buffer).digest("hex");

const base = await mkdtemp(join(tmpdir(), "nw-acp-"));
// 工坊在“系统临时目录”里建的工作目录，这次检查里都放进自己的目录（连同它启动的子进程）：不碰系统的 /tmp，结束时一起删掉。
process.env.TMPDIR = join(base, "tmp");
process.env.TMP = process.env.TMPDIR;
process.env.TEMP = process.env.TMPDIR;
await mkdir(process.env.TMPDIR, { recursive: true });
const realTmp = await realpath(tmpdir());
// 模拟看不到 /proc 的环境（macOS、hidepid 的容器）：NOVEL_WORKSHOP_TEST_HIDE_PROC=1。只影响这次检查里的锁判断。
if (process.env.NOVEL_WORKSHOP_TEST_HIDE_PROC === "1") store.setProcRootForTests(join(base, "no-proc-here"));
const HOME = process.env.HOME || "/root";
const GEMINI_KEY = "AIzaFAKE-acp-test-key-0123456789abcdefghij";
const LIKE_ANTIGRAVITY = { name: "antigravity-acp", title: "Antigravity ACP Server", version: "9.9.9-模拟" };
// 检查“已真实接通”判断逻辑用：模拟程序自称 Antigravity、而且不在握手里标明自己是模拟的。它仍然是工坊自己写的模拟程序。
const OFFICIAL_LIKE = Object.freeze({ agentInfo: LIKE_ANTIGRAVITY, simulatedMarker: false });
const shaFile = (path) => createHash("sha256").update(readFileSync(path)).digest("hex");
// 作者核对过程序来源：把这个文件现在的 SHA-256 当成“核对过的校验值”。
const verifiedEnv = (runtime) => ({ NOVEL_WORKSHOP_ACP_SHA256: shaFile(runtime.path) });

// 一个假的 Gemini API：ACP 这条路不能碰它（额度受限时也不能改用 API）。
const geminiSeen = [];
const gemini = createServer((request, response) => {
  geminiSeen.push(request.url);
  response.writeHead(500, { "Content-Type": "application/json" });
  response.end("{}");
});
await new Promise((accept) => gemini.listen(0, "127.0.0.1", accept));
const geminiBase = `http://127.0.0.1:${gemini.address().port}/v1beta`;

let counter = 0;
async function fakeRuntime({ name = "agy", folder = "官方 程序", control = {} } = {}) {
  counter += 1;
  const dir = join(base, `${folder}-${counter}`);
  await mkdir(dir, { recursive: true });
  const controlFile = join(dir, "control.json");
  const logFile = join(dir, "agent-log.jsonl");
  const path = join(dir, name);
  await writeFile(path, `#!/bin/sh\nexec '${process.execPath}' '${FAKE}' --control '${controlFile}' --log '${logFile}' "$@"\n`, { mode: 0o755 });
  await chmod(path, 0o755);
  const runtime = {
    dir,
    path,
    async set(next) {
      await writeFile(controlFile, JSON.stringify(next), "utf8");
    },
    async log() {
      try {
        return (await readFile(logFile, "utf8")).split("\n").filter(Boolean).map((line) => JSON.parse(line));
      } catch {
        return [];
      }
    },
    async events(kind) {
      return (await this.log()).filter((entry) => entry.event === kind);
    },
    async received(method) {
      return (await this.log()).filter((entry) => entry.event === "in" && entry.message.method === method).map((entry) => entry.message);
    },
  };
  await runtime.set(control);
  return runtime;
}

const FAST = { versionMs: 4000, initializeMs: 3000, loginMs: 2000, sessionMs: 3000, optionMs: 3000, promptIdleMs: 3000, promptTotalMs: 15000, cancelWaitMs: 700 };
function envFor(runtime, extra = {}) {
  counter += 1;
  return {
    PATH: process.env.PATH || "/usr/bin:/bin",
    HOME,
    LANG: "C.UTF-8",
    GEMINI_API_KEY: GEMINI_KEY,
    NOVEL_WORKSHOP_GEMINI_BASE: geminiBase,
    SECRET_TOKEN_FOR_TEST: "must-not-reach-the-agent",
    NOVEL_WORKSHOP_CONFIG_DIR: join(base, `config-${counter}`),
    TMPDIR: process.env.TMPDIR,
    ...(runtime ? { NOVEL_WORKSHOP_ACP_RUNTIME: runtime.path } : {}),
    ...extra,
  };
}
const providers = [];
function makeProvider(runtime, { env = {}, timeouts = {} } = {}) {
  const provider = assist.createAcpProvider({ env: envFor(runtime, env), timeouts: { ...FAST, ...timeouts } });
  providers.push(provider);
  return provider;
}
async function connected(runtime, options) {
  const provider = makeProvider(runtime, options);
  await provider.connect();
  return provider;
}
async function send(provider, payload) {
  const started = await provider.startPrompt(payload);
  return provider.waitForTask(started.taskId);
}

function listen(server) {
  return new Promise((accept) => server.listen(0, "127.0.0.1", () => accept(server.address().port)));
}
function api(port, method, path, body, headers = {}) {
  return new Promise((accept, reject) => {
    const data = body === undefined ? null : Buffer.from(JSON.stringify(body));
    const request = httpRequest({
      host: "127.0.0.1",
      port,
      path,
      method,
      agent: false,
      headers: { ...(data ? { "Content-Type": "application/json", "Content-Length": data.length } : {}), ...headers },
    }, (response) => {
      const chunks = [];
      response.on("data", (chunk) => chunks.push(chunk));
      response.on("end", () => {
        const text = Buffer.concat(chunks).toString("utf8");
        let json = null;
        try {
          json = JSON.parse(text);
        } catch {}
        accept({ status: response.statusCode, json, text });
      });
    });
    request.on("error", reject);
    if (data) request.write(data);
    request.end();
  });
}
async function makeWorkspace() {
  counter += 1;
  const root = join(base, `作品-${counter}`);
  await mkdir(join(root, "正文"), { recursive: true });
  await writeFile(join(root, "正文", "第001章.md"), "第一章\n\n【选中标记A-7f3】苏棠扣上头盔，从气闸里出来。\n\n【未选标记B-9c1】这一段不该发出去。\n", "utf8");
  await writeFile(join(root, "设定.md"), "# 设定\n\n【未选标记C-2d8】灯塔在岬角最东头。\n", "utf8");
  return root;
}
async function treeDigest(root) {
  const names = (await readdir(root, { recursive: true })).sort();
  const out = {};
  for (const name of names) {
    const info = await stat(join(root, name));
    out[name] = info.isFile() ? shaBytes(await readFile(join(root, name))) : "dir";
  }
  return out;
}

// ---------------------------------------------------------------- 分帧与连接层
await test("C07 分帧：中文、表情和四字节汉字在任意一个字节处被拆开都能拼回；一次读到几条、最后半行留到下一次再拼", async () => {
  const messages = [
    { jsonrpc: "2.0", method: "session/update", params: { text: "第一条：中文" } },
    { jsonrpc: "2.0", id: 7, result: { text: "第二条😀表情，还有“引号”" } },
    { jsonrpc: "2.0", method: "x", params: { text: "第三条𠀀（四字节汉字）" } },
  ];
  const bytes = Buffer.from(messages.map((message) => client.encodeMessage(message)).join(""));
  const decode = (pieces) => {
    const got = [];
    const errors = [];
    const decoder = new client.NdjsonDecoder({ onMessage: (message) => got.push(message), onProtocolError: (problem) => errors.push(problem) });
    for (const piece of pieces) decoder.push(piece);
    decoder.end();
    return { got, errors };
  };
  for (let cut = 1; cut < bytes.length; cut += 1) {
    const { got, errors } = decode([bytes.subarray(0, cut), bytes.subarray(cut)]);
    assert.deepEqual(got, messages, `在第 ${cut} 个字节处拆开`);
    assert.deepEqual(errors, []);
  }
  for (let first = 1; first < bytes.length - 1; first += 7) {
    const second = Math.min(bytes.length - 1, first + 5);
    assert.deepEqual(decode([bytes.subarray(0, first), bytes.subarray(first, second), bytes.subarray(second)]).got, messages);
  }
  assert.deepEqual(decode([...bytes].map((byte) => Buffer.from([byte]))).got, messages);
  assert.deepEqual(decode([bytes]).got, messages);
});

await test("C07/C08 分帧：CRLF 和空行可以；不是 JSON、不是 JSON-RPC 2.0、数组、超长的行、流断在半行，都算协议错误、不当消息，后面的照常", async () => {
  const got = [];
  const errors = [];
  const decoder = new client.NdjsonDecoder({ maxLineChars: 200, onMessage: (message) => got.push(message.method), onProtocolError: (problem) => errors.push(problem.kind) });
  decoder.push(Buffer.from('{"jsonrpc":"2.0","method":"a"}\r\n\n'));
  decoder.push(Buffer.from("not json\n"));
  decoder.push(Buffer.from('{"jsonrpc":"1.0","method":"b"}\n[1,2]\n'));
  decoder.push(Buffer.from("x".repeat(150)));
  decoder.push(Buffer.from("y".repeat(150)));
  decoder.push(Buffer.from('z\n{"jsonrpc":"2.0","method":"c"}\n'));
  decoder.push(Buffer.from('{"jsonrpc":"2.0","method":"d"}'));
  decoder.end();
  assert.deepEqual(got, ["a", "c"]);
  assert.deepEqual(errors, ["not_json", "not_jsonrpc", "not_jsonrpc", "line_too_long", "truncated_line"]);
});

await test("C07 编码：一条消息正好一行；正文里的换行、回车和行分隔符都转义，不会把一条拆成两行", async () => {
  const separator = String.fromCharCode(0x2028);
  const text = `第一行\n第二行${separator}第三行\r`;
  const line = client.encodeMessage({ jsonrpc: "2.0", method: "m", params: { text } });
  assert.equal(line.indexOf("\n"), line.length - 1);
  assert.ok(!line.includes(separator) && !line.includes("\r"));
  assert.equal(JSON.parse(line).params.text, text);
});

await test("C08 连接层：请求按 id 配对；超时作废、迟到的回应只记一笔；对方的请求没人认就回 Method not found；关闭后挂着的请求报断开、再来的消息丢弃", async () => {
  const toAgent = new PassThrough();
  const fromAgent = new PassThrough();
  const written = [];
  toAgent.on("data", (chunk) => written.push(...chunk.toString("utf8").split("\n").filter(Boolean).map((line) => JSON.parse(line))));
  const conn = new client.AcpConnection({ generation: 1, stdin: toAgent, stdout: fromAgent });
  const first = conn.request("ping", { a: 1 }, { timeoutMs: 1000 });
  await wait(10);
  assert.deepEqual([written[0].id, written[0].method], [0, "ping"]);
  fromAgent.write(client.encodeMessage({ jsonrpc: "2.0", id: 0, result: { pong: true } }));
  assert.deepEqual(await first, { pong: true });
  await assert.rejects(conn.request("slow", {}, { timeoutMs: 50 }), (error) => error instanceof client.AcpTimeoutError);
  fromAgent.write(client.encodeMessage({ jsonrpc: "2.0", id: 1, result: { late: true } }));
  fromAgent.write(client.encodeMessage({ jsonrpc: "2.0", id: 55, method: "fs/read_text_file", params: { path: "/etc/passwd" } }));
  await wait(20);
  assert.equal(conn.stats.strayResponses, 1);
  assert.equal(written.find((message) => message.id === 55).error.code, -32601);
  const pending = conn.request("never", {}, { timeoutMs: 0 });
  conn.close("测试关闭");
  await assert.rejects(pending, (error) => error instanceof client.AcpClosedError);
  fromAgent.write(client.encodeMessage({ jsonrpc: "2.0", method: "session/update", params: {} }));
  await wait(10);
  assert.ok(conn.stats.droppedAfterClose >= 1);
  assert.throws(() => conn.notify("x", {}), (error) => error instanceof client.AcpClosedError);
});

// ---------------------------------------------------------------- 找运行时
await test("C01 运行时：设置里没填、PATH 里也没有 agy → 未安装", async () => {
  const empty = join(base, "empty-path");
  await mkdir(empty, { recursive: true });
  const info = await rt.inspectRuntime({ env: { PATH: empty }, platform: "linux" });
  assert.equal(info.state, "not_installed");
  assert.equal(info.label, "未安装");
});

await test("C01 运行时：相对路径、不存在、文件夹、没有执行权限、认不出的名字 → 路径错误，各有说明；改过名字的注明种类就行", async () => {
  const relative = await rt.inspectRuntime({ configuredPath: "bin/agy", env: {} });
  assert.equal(relative.state, "path_invalid");
  assert.match(relative.message, /绝对路径/);
  const missing = await rt.inspectRuntime({ configuredPath: join(base, "没有这个", "agy") });
  assert.equal(missing.label, "路径错误");
  assert.match(missing.message, /找不到/);
  const folder = join(base, "agy-folder");
  await mkdir(folder, { recursive: true });
  assert.match((await rt.inspectRuntime({ configuredPath: folder })).message, /文件夹/);
  const plain = join(base, "noexec", "agy");
  await mkdir(dirname(plain), { recursive: true });
  await writeFile(plain, "#!/bin/sh\n", { mode: 0o644 });
  await chmod(plain, 0o644);
  const noexec = await rt.inspectRuntime({ configuredPath: plain });
  assert.equal(noexec.state, "path_invalid");
  assert.match(noexec.message, /执行权限/);
  const odd = await fakeRuntime({ name: "gemini-helper" });
  const unknown = await rt.inspectRuntime({ configuredPath: odd.path });
  assert.equal(unknown.state, "path_invalid");
  assert.match(unknown.message, /认不出/);
  const named = await rt.inspectRuntime({ configuredPath: odd.path, kind: "agy-cli", probe: false });
  assert.equal(named.state, "launchable");
});

await test("C01 运行时：校验值不符 → 校验不符；填成 Registry 里 zip 的校验值会说明那是压缩包的；一致（大小写不论）→ 可启动", async () => {
  const fake = await fakeRuntime();
  const digest = shaBytes(await readFile(fake.path));
  const ok = await rt.inspectRuntime({ configuredPath: fake.path, expectedSha256: digest.toUpperCase(), probe: false });
  assert.equal(ok.state, "launchable");
  assert.equal(ok.checksum.match, true);
  const bad = await rt.inspectRuntime({ configuredPath: fake.path, expectedSha256: "0".repeat(64), probe: false });
  assert.equal(bad.state, "checksum_mismatch");
  assert.equal(bad.label, "校验不符");
  const zip = await rt.inspectRuntime({ configuredPath: fake.path, expectedSha256: rt.REGISTRY_RELEASE.archives["linux-x86_64"].sha256, probe: false });
  assert.equal(zip.state, "checksum_mismatch");
  assert.match(zip.message, /zip 压缩包/);
});

await test("C01/C18 运行时：在 PATH 里找到 agy（文件夹名有中文和空格）：种类 agy-cli、参数 acp；记下 agy --version、大小和 SHA-256", async () => {
  const fake = await fakeRuntime();
  assert.ok(fake.dir.includes(" ") && /[一-龥]/.test(fake.dir));
  const info = await rt.inspectRuntime({ env: { PATH: `/nonexistent:${fake.dir}`, HOME }, platform: "linux" });
  assert.equal(info.state, "launchable");
  assert.equal(info.source, "path");
  assert.equal(info.path, fake.path);
  assert.equal(info.kind, "agy-cli");
  assert.deepEqual(info.args, ["acp"]);
  assert.match(info.version, /0\.0\.0-fake/);
  assert.equal(info.sha256, shaBytes(await readFile(fake.path)));
  assert.equal(info.size, (await stat(fake.path)).size);
});

await test("运行时：agy --version 不回应时按时放弃，不卡住", async () => {
  const fake = await fakeRuntime({ control: { version: "hang" } });
  const started = Date.now();
  const info = await rt.inspectRuntime({ configuredPath: fake.path, versionTimeoutMs: 400 });
  assert.equal(info.state, "launchable");
  assert.equal(info.version, null);
  assert.match(info.versionNote, /没有回应/);
  assert.ok(Date.now() - started < 4000);
});

await test("运行时：ACP Registry 发行包按清单给参数（linux 加 --uid=，macOS、Windows 不加）；只认三个官方开关，绝不带跳过权限的开关；登记的 zip 校验值能查到平台", async () => {
  assert.equal(rt.runtimeKindFor("agy_acp_server.par", "linux"), "registry-binary");
  assert.equal(rt.runtimeKindFor("agy_acp_server.exe", "win32"), "registry-binary");
  assert.equal(rt.runtimeKindFor("AGY.CMD", "win32"), "agy-cli");
  assert.deepEqual(rt.connectionArgs("registry-binary", "linux"), ["--uid="]);
  assert.deepEqual(rt.connectionArgs("registry-binary", "darwin"), []);
  assert.deepEqual(rt.connectionArgs("registry-binary", "win32"), []);
  assert.deepEqual(rt.connectionArgs("agy-cli", "linux", ["--sandbox", "--dangerously-skip-permissions", "-p", "--add-dir"]), ["acp", "--sandbox"]);
  assert.equal(rt.registryMatch(rt.REGISTRY_RELEASE.archives["windows-x86_64"].sha256).key, "windows-x86_64");
  assert.equal(rt.registryMatch("0".repeat(64)), null);
  assert.equal(rt.platformKey("win32", "x64"), "windows-x86_64");
  assert.equal(rt.platformKey("darwin", "arm64"), "darwin-aarch64");
  const fake = await fakeRuntime({ name: "agy_acp_server.par" });
  const info = await rt.inspectRuntime({ configuredPath: fake.path, platform: "linux" });
  assert.equal(info.kind, "registry-binary");
  assert.deepEqual(info.args, ["--uid="]);
  assert.equal(info.version, null);
});

await test("Windows 模拟（没有在真实 Windows 上跑过）：找 agy.exe/agy.cmd/agy.bat；.cmd 经 cmd.exe /d /v:off /s /c 加引号；路径里有 % 或 ! 就不启动；环境变量按名字不分大小写挑", async () => {
  assert.deepEqual(rt.lookupNames("win32"), ["agy.exe", "agy.cmd", "agy.bat"]);
  assert.equal(rt.isWindowsShim("C:\\x\\agy.CMD", "win32"), true);
  assert.equal(rt.isWindowsShim("C:\\x\\agy.exe", "win32"), false);
  const launch = rt.windowsShimLaunch("C:\\Users\\作者 名\\AppData\\Roaming\\npm\\agy.cmd", ["acp"], { SystemRoot: "C:\\Windows" });
  assert.deepEqual(launch, {
    command: "C:\\Windows\\System32\\cmd.exe",
    args: ["/d", "/v:off", "/s", "/c", '""C:\\Users\\作者 名\\AppData\\Roaming\\npm\\agy.cmd" acp"'],
    verbatim: true,
  });
  assert.throws(() => rt.windowsShimLaunch("C:\\100%\\agy.cmd", ["acp"], {}), /cmd\.exe/);
  assert.throws(() => rt.windowsShimLaunch("C:\\Hi!\\agy.cmd", ["acp"], {}), /cmd\.exe/);
  assert.deepEqual(rt.buildLaunch({ path: "C:\\Program Files\\agy\\agy.exe" }, ["acp"], { platform: "win32", env: {} }), { command: "C:\\Program Files\\agy\\agy.exe", args: ["acp"], verbatim: false });
  const env = rt.minimalEnv({ SystemRoot: "C:\\Windows", Path: "C:\\x", userprofile: "C:\\Users\\a", APPDATA: "C:\\a", GEMINI_API_KEY: "k", GOOGLE_API_KEY: "k", NOVEL_WORKSHOP_CONFIG_DIR: "x" }, "win32");
  assert.deepEqual(Object.keys(env).sort(), ["APPDATA", "Path", "SystemRoot", "userprofile"]);
});

await test("环境变量：只把必需的几项交给官方程序，不交 API Key、工坊设置和别的密钥", async () => {
  const env = rt.minimalEnv({ PATH: "/bin", HOME: "/home/a", https_proxy: "http://p", HTTPS_PROXY: "http://p", GEMINI_API_KEY: "k", GOOGLE_APPLICATION_CREDENTIALS: "/x.json", NOVEL_WORKSHOP_CONFIG_DIR: "/c", OPENAI_API_KEY: "k", SECRET_TOKEN_FOR_TEST: "s", DISPLAY: ":0" }, "linux");
  assert.deepEqual(Object.keys(env).sort(), ["DISPLAY", "HOME", "HTTPS_PROXY", "PATH", "https_proxy"]);
  for (const list of Object.values(rt.ENV_PASSTHROUGH)) {
    for (const name of list) assert.doesNotMatch(name, /KEY|TOKEN|SECRET|CREDENTIAL|PASSWORD|COOKIE/);
  }
});

await test("诊断文字去掉主目录路径和像令牌、密钥的字样", async () => {
  const scrub = rt.makeScrubber({ home: "/home/作者", env: {}, platform: "linux" });
  const out = scrub("open /home/作者/.config/x and /home/作者s/x; token ya29.abc-DEF_123 Bearer abc.def access_token=xyz9 key AIzaSyA1234567890123456789012345678901 https://x/cb?code=4/0AbC&state=1");
  assert.ok(!out.includes("/home/作者/"));
  assert.ok(out.includes("~/.config/x"));
  assert.ok(out.includes("/home/作者s/x"));
  for (const secret of ["ya29.abc", "abc.def", "xyz9", "AIzaSy", "4/0AbC"]) assert.ok(!out.includes(secret), secret);
});

// ---------------------------------------------------------------- 连接与登录
await test("C02 连接：握手记下协议版本、agentInfo、登录方式和能力；声明不提供文件和终端；工作目录是系统临时目录里新建的；交给它的环境变量里没有密钥；断开就结束进程、删目录", async () => {
  const fake = await fakeRuntime();
  const provider = makeProvider(fake);
  const status = await provider.connect();
  assert.equal(status.state, "needs_login");
  assert.equal(status.label, "待登录");
  assert.equal(status.ladder.step, 2);
  assert.deepEqual(status.ladder.steps, ["未安装", "可启动", "待登录", "已认证", "可调用"]);
  assert.equal(status.handshake.protocolVersion, 1);
  assert.equal(status.handshake.agentInfo.name, "fake-acp-agent");
  assert.deepEqual(status.handshake.authMethods.map((method) => method.id), ["oauth-personal", "oauth-business", "terminal-login"]);
  assert.equal(status.handshake.capabilities.promptCapabilities.embeddedContext, true);
  assert.equal(status.handshake.official, false);
  const [init] = await fake.received("initialize");
  assert.equal(init.params.protocolVersion, 1);
  assert.deepEqual(init.params.clientCapabilities, { fs: { readTextFile: false, writeTextFile: false }, terminal: false });
  assert.equal(init.params.clientInfo.name, "novel-workshop");
  const [start] = await fake.events("start");
  assert.deepEqual(start.argv, ["acp"]);
  assert.ok(start.cwd.startsWith(realTmp) && basename(start.cwd).startsWith("novel-workshop-acp-"), start.cwd);
  for (const name of ["GEMINI_API_KEY", "SECRET_TOKEN_FOR_TEST", "NOVEL_WORKSHOP_CONFIG_DIR", "NOVEL_WORKSHOP_ACP_RUNTIME", "NOVEL_WORKSHOP_GEMINI_BASE"]) {
    assert.ok(!start.envKeys.includes(name), name);
  }
  assert.ok(start.envKeys.includes("PATH") && start.envKeys.includes("HOME"));
  assert.ok(alive(start.pid));
  assert.ok(rt.liveRuntimePids().includes(start.pid));
  const after = await provider.disconnect();
  assert.equal(after.connected, false);
  assert.ok(!alive(start.pid));
  await assert.rejects(stat(start.cwd));
});

await test("C08 握手失败：协议版本不对、一直不回应、一启动就退出、报错 → 连接失败，工坊结束它启动的进程", async () => {
  for (const [control, pattern] of [
    [{ protocolVersion: 2 }, /协议版本 2/],
    [{ initialize: "hang" }, /没有回应/],
    [{ initialize: "exit" }, /断了|退出/],
    [{ initialize: "error" }, /官方程序说/],
  ]) {
    const fake = await fakeRuntime({ control });
    const provider = makeProvider(fake, { timeouts: { initializeMs: 500 } });
    await assert.rejects(provider.connect(), (error) => error.code.startsWith("acp_handshake") && pattern.test(error.message), JSON.stringify(control));
    const status = await provider.status();
    assert.equal(status.state, "connect_failed", JSON.stringify(control));
    assert.equal(status.label, "连接失败");
    assert.equal(status.connected, false);
    const [start] = await fake.events("start");
    await until(() => !alive(start.pid), { what: "进程结束" });
  }
});

await test("C07 握手前 stdout 有一行杂音、stderr 有噪声：握手照常；杂音记成协议错误；诊断里去掉了主目录路径和令牌", async () => {
  const fake = await fakeRuntime({ control: { startupStdout: "Antigravity starting... (not json)", stderrNoise: true } });
  const provider = makeProvider(fake);
  const status = await provider.connect();
  assert.equal(status.state, "needs_login");
  await until(async () => (await provider.status()).diagnostics.stderr.length > 0, { what: "收到 stderr" });
  const diagnostics = (await provider.status()).diagnostics;
  assert.equal(diagnostics.protocol.protocolErrors, 1);
  const text = JSON.stringify(diagnostics);
  assert.ok(!text.includes(`${HOME}/`));
  assert.ok(!text.includes("ya29.FAKE") && !text.includes("abc.def"));
  assert.ok(text.includes("~/.fake"));
  await provider.disconnect();
});

await test("C03 登录：没列出的方式、终端方式不经工坊；官方程序说取消 → 认证取消；失败 → 认证失败；成功 → 已认证（不等于已真实接通）", async () => {
  const fake = await fakeRuntime();
  const provider = await connected(fake);
  await assert.rejects(provider.login({ methodId: "cookie-import" }), (error) => error.code === "acp_method_not_listed" && /oauth-personal/.test(error.message));
  await assert.rejects(provider.login({ methodId: "terminal-login" }), (error) => error.code === "acp_method_terminal" && /agy acp --login/.test(error.message));
  assert.equal((await fake.received("authenticate")).length, 0);
  await fake.set({ login: "cancel" });
  await assert.rejects(provider.login({ methodId: "oauth-personal" }), (error) => error.code === "acp_auth_cancelled");
  assert.equal((await provider.status()).label, "认证取消");
  await fake.set({ login: "fail" });
  await assert.rejects(provider.login({ methodId: "oauth-personal" }), (error) => error.code === "acp_auth_failed");
  assert.equal((await provider.status()).label, "认证失败");
  await fake.set({ login: "ok" });
  const status = await provider.login({ methodId: "oauth-personal" });
  assert.equal(status.state, "authenticated");
  assert.equal(status.label, "已认证");
  assert.equal(status.ladder.step, 3);
  assert.equal(status.real, null);
  assert.equal(status.realCurrent, false);
  assert.deepEqual((await fake.received("authenticate")).map((message) => message.params), [{ methodId: "oauth-personal" }, { methodId: "oauth-personal" }, { methodId: "oauth-personal" }]);
  await provider.disconnect();
});

await test("C03 登录超时：不再等，结束它启动的进程，认证失败；登录中途断开 → 认证取消", async () => {
  const fake = await fakeRuntime({ control: { login: "hang" } });
  const provider = await connected(fake, { timeouts: { loginMs: 400 } });
  const [start] = await fake.events("start");
  await assert.rejects(provider.login({ methodId: "oauth-personal" }), (error) => error.code === "acp_auth_failed" && /没有完成/.test(error.message));
  const status = await provider.status();
  assert.equal(status.label, "认证失败");
  assert.equal(status.connected, false);
  await until(() => !alive(start.pid), { what: "进程结束" });
  const second = await connected(fake, { timeouts: { loginMs: 5000 } });
  const pending = second.login({ methodId: "oauth-personal" }).then(() => null, (error) => error);
  await until(async () => (await fake.received("authenticate")).length >= 2, { what: "第二次登录发出" });
  await second.disconnect();
  assert.equal((await pending)?.code, "acp_auth_cancelled");
  assert.equal((await second.status()).label, "认证取消");
});

await test("C03 凭据失效：不登录直接开会话 → 说要先登录；登录过后官方程序又说 Authentication required → 回到待登录，说明要重新登录", async () => {
  const fake = await fakeRuntime();
  const provider = await connected(fake);
  await assert.rejects(provider.models(), (error) => error.code === "acp_auth_required");
  assert.equal((await provider.status()).ladder.step, 2);
  await provider.login({ methodId: "oauth-personal" });
  await fake.set({ sessionNew: "auth_required" });
  await assert.rejects(provider.models(), (error) => error.code === "acp_auth_expired" && /失效/.test(error.message));
  const status = await provider.status();
  assert.equal(status.state, "needs_login");
  assert.equal(status.auth.state, "expired");
  await provider.disconnect();
});

// ---------------------------------------------------------------- 模型与发送
await test("C04 模型：只列官方程序给出的模型和思考强度；切换发 set_config_option 并核对；选的模型这次不在清单里 → 配置失效，不发、不换别的；官方程序没切过去也算配置失效", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const provider = await connected(fake);
  let status = await provider.models();
  assert.equal(status.state, "ready");
  assert.equal(status.label, "可调用");
  assert.equal(status.ladder.step, 4);
  assert.equal(status.auth.state, "implicit");
  const options = status.session.options;
  assert.deepEqual(options.map((option) => option.id), ["model", "thought_level", "mode"]);
  assert.deepEqual(options[0].values.map((value) => value.value), ["gemini-fake-pro", "gemini-fake-flash"]);
  assert.deepEqual(options[1].values.map((value) => value.name), ["Low", "Medium", "High", "Extra", "Max"]);
  await provider.setOption({ configId: "model", value: "gemini-fake-flash" });
  status = await provider.setOption({ configId: "thought_level", value: "high" });
  assert.deepEqual((await fake.events("set_option")).map((entry) => [entry.configId, entry.value]), [["model", "gemini-fake-flash"], ["thought_level", "high"]]);
  assert.equal(status.preferences.model.value, "gemini-fake-flash");
  const stored = JSON.parse(await readFile(join(provider.env.NOVEL_WORKSHOP_CONFIG_DIR, "acp.json"), "utf8"));
  assert.equal(stored.preferences.thought_level.value, "high");
  await assert.rejects(provider.setOption({ configId: "model", value: "gemini-ultra-imaginary" }), (error) => error.code === "acp_value_unknown");
  await assert.rejects(provider.setOption({ configId: "mode", value: "agent" }), (error) => error.code === "acp_option_readonly");
  const done = await send(provider, { kind: "selection", text: "一段文字。" });
  assert.equal(done.outcome, "complete");
  assert.equal(done.requested.model.value, "gemini-fake-flash");
  assert.equal(done.requested.model.chosen, true);
  assert.equal(done.reportedModel.value, "gemini-fake-flash");
  const last = (await fake.events("prompt")).at(-1);
  assert.deepEqual([last.model, last.thought], ["gemini-fake-flash", "high"]);
  await fake.set({ cachedLogin: true, models: [{ value: "gemini-fake-pro", name: "Gemini Fake Pro（模拟）" }] });
  const before = (await fake.events("prompt")).length;
  await assert.rejects(send(provider, { kind: "selection", text: "再一段。" }), (error) => error.code === "acp_config_invalid" && /没有替你换/.test(error.message));
  status = await provider.status();
  assert.equal(status.state, "config_invalid");
  assert.equal(status.label, "配置失效");
  assert.equal(status.task.outcome, "not_sent");
  assert.equal((await fake.events("prompt")).length, before);
  await fake.set({ cachedLogin: true, setOption: "ignore" });
  status = await provider.models();
  assert.equal(status.state, "ready");
  await assert.rejects(provider.setOption({ configId: "model", value: "gemini-fake-flash" }), (error) => error.code === "acp_config_invalid");
  assert.equal((await provider.status()).label, "配置失效");
  await provider.disconnect();
});

await test("C07/C09/C12 正常回复：分几次来、在一个字中间拆开、两条粘在一起都拼对；思考片段和工具日志不进候选；发出去的只有固定说明、要求和选中的那段（合成标记 A 在，未选的 B 不在），全是文字块，没有本机路径", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const provider = await connected(fake);
  const selection = "【选中标记A-7f3】苏棠扣上头盔，从气闸里出来。";
  const done = await send(provider, { kind: "selection", text: selection, instruction: "改紧凑一点", source: { path: "正文/第001章.md", version: "a".repeat(64) } });
  assert.equal(done.outcome, "complete");
  assert.equal(done.stopReason, "end_turn");
  assert.equal(done.candidate, "改好的第一句，第二句里有中文和表情😀，第三句收尾。");
  assert.ok(!done.candidate.includes("思考片段") && !done.candidate.includes("工具输出"));
  assert.deepEqual([done.thoughtChunks, done.toolCalls, done.toolCallUpdates, done.plans], [1, 1, 1, 1]);
  assert.ok(done.otherUpdates >= 2);
  assert.equal(done.insertable, true);
  const [prompt] = await fake.events("prompt");
  assert.ok(prompt.blocks.every((block) => block.type === "text"));
  const sent = prompt.blocks.map((block) => block.text).join("\n");
  assert.ok(sent.includes(selection) && sent.includes("改紧凑一点"));
  assert.ok(!sent.includes("未选标记") && !sent.includes("正文/第001章.md") && !sent.includes(base) && !sent.includes("file://"));
  assert.deepEqual(prompt.blocks, assist.preparePrompt({ kind: "selection", text: selection, instruction: "改紧凑一点" }).blocks);
  const snapshot = done.snapshot;
  assert.deepEqual(snapshot.pieces.map((piece) => piece.kind), ["frame", "instruction", "selection"]);
  assert.equal(snapshot.pieces[2].sha256, sha(`要改的正文：\n${selection}`));
  assert.equal(snapshot.pieces[2].chars, [...`要改的正文：\n${selection}`].length);
  assert.equal(snapshot.textSha256, sha(selection));
  assert.equal(snapshot.textChars, [...selection].length);
  assert.equal(snapshot.instructionChars, 5);
  assert.equal(snapshot.taskId, done.id);
  assert.equal(snapshot.sent, true);
  assert.equal(snapshot.source.path, "正文/第001章.md");
  assert.ok(!JSON.stringify(snapshot).includes("苏棠"));
  await provider.recordWrites;
  const record = await readFile(join(provider.env.NOVEL_WORKSHOP_CONFIG_DIR, "acp-status.json"), "utf8");
  for (const forbidden of ["苏棠", "选中标记", "改好的第一句", GEMINI_KEY, "ya29"]) assert.ok(!record.includes(forbidden), forbidden);
  assert.ok(record.includes(sha(selection)));
  await provider.disconnect();
});

await test("C05 合成示例：只发工坊自带的两句，不发任何文稿；结果不能放进编辑器", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const provider = await connected(fake);
  const done = await send(provider, { kind: "selftest", text: "【选中标记A-7f3】不该被发出去" });
  assert.equal(done.outcome, "complete");
  assert.equal(done.insertable, false);
  const [prompt] = await fake.events("prompt");
  const sent = prompt.blocks.map((block) => block.text).join("\n");
  assert.ok(sent.includes(assist.SELFTEST_SAMPLE.text) && sent.includes(assist.SELFTEST_SAMPLE.instruction));
  assert.ok(!sent.includes("选中标记"));
  assert.deepEqual(done.snapshot.pieces.map((piece) => piece.kind), ["frame", "instruction", "sample"]);
  await provider.disconnect();
});

await test("预览和发送一致：先预览能看到要发的全部文字和快照；内容变了（digest 对不上）就不发；太长、空的选段不发", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const provider = await connected(fake);
  const preview = await provider.preview({ kind: "selection", text: "甲乙丙。", instruction: "改" });
  assert.equal(preview.blocks.length, 3);
  assert.equal(preview.blocks[2].text, "要改的正文：\n甲乙丙。");
  assert.equal(preview.snapshot.textChars, 4);
  assert.equal(preview.snapshot.sent, false);
  await assert.rejects(provider.startPrompt({ kind: "selection", text: "甲乙丙丁。", instruction: "改", expectedDigest: preview.snapshot.digest }), (error) => error.code === "acp_preview_changed");
  assert.equal((await fake.events("prompt")).length, 0);
  const started = await provider.startPrompt({ kind: "selection", text: "甲乙丙。", instruction: "改", expectedDigest: preview.snapshot.digest });
  assert.equal((await provider.waitForTask(started.taskId)).snapshot.digest, preview.snapshot.digest);
  await assert.rejects(provider.preview({ kind: "selection", text: "字".repeat(6001) }), (error) => error.code === "selection_too_long");
  await assert.rejects(provider.startPrompt({ kind: "selection", text: "   " }), (error) => error.code === "empty_selection");
  await assert.rejects(provider.startPrompt({ kind: "selection", text: "一段", instruction: "要".repeat(501) }), (error) => error.code === "instruction_too_long");
  assert.equal((await fake.events("prompt")).length, 1);
  await provider.disconnect();
});

await test("C13 每次发送都新开一个官方会话：两次的会话编号不同，第二次不带第一次的内容；别的会话、不认识的会话发来的消息不进这一轮", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const provider = await connected(fake);
  await send(provider, { kind: "selection", text: "【第一本书】雨停了。" });
  await send(provider, { kind: "selection", text: "【第二本书】天亮了。" });
  const prompts = await fake.events("prompt");
  assert.equal(prompts.length, 2);
  assert.notEqual(prompts[0].sessionId, prompts[1].sessionId);
  assert.ok(!JSON.stringify(prompts[1].blocks).includes("第一本书"));
  await fake.set({ cachedLogin: true, prompt: "stale_session" });
  const done = await send(provider, { kind: "selection", text: "一段。" });
  assert.equal(done.candidate, "正文。");
  assert.ok((await provider.status()).diagnostics.strayUpdates >= 1);
  await provider.disconnect();
});

await test("C10 权限：官方程序要动文件时一律拒绝（选 reject_once，从不选 allow）；它请求读写文件、开终端，回 Method not found", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, prompt: "permission" } });
  const provider = await connected(fake);
  const done = await send(provider, { kind: "selection", text: "一段。" });
  assert.equal(done.outcome, "complete");
  assert.equal(done.candidate, "先说一句，权限被拒以后照常交回正文。");
  assert.deepEqual([done.permissionRequests, done.permissionRejected], [1, 1]);
  const [permission] = await fake.events("permission_answer");
  assert.deepEqual(permission.answer.result, { outcome: { outcome: "selected", optionId: "reject-once" } });
  for (const kind of ["fs_read_answer", "fs_write_answer", "terminal_answer"]) {
    const [entry] = await fake.events(kind);
    assert.equal(entry.answer.error.code, -32601, kind);
    assert.equal(entry.answer.result, undefined, kind);
  }
  await assert.rejects(stat("/tmp/should-not-be-written.txt"));
  await provider.disconnect();
});

await test("C10 停止：发 session/cancel；停止以后来的权限请求答 cancelled；回应前收到的字标成不完整；回应以后的迟到消息只记在被停的那一轮，不进下一轮", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, prompt: "cancel_late" } });
  const provider = await connected(fake);
  const started = await provider.startPrompt({ kind: "selection", text: "一段。" });
  await until(async () => (await provider.status()).task.chars > 0, { what: "收到第一段" });
  const running = await provider.status();
  assert.equal(running.task.state, "running");
  assert.equal(running.task.streamText, "停止前的字。");
  assert.equal(running.task.candidate, null);
  await provider.cancel({ taskId: started.taskId });
  const done = await provider.waitForTask(started.taskId);
  assert.equal(done.outcome, "cancelled");
  assert.equal(done.stopReason, "cancelled");
  assert.equal(done.candidate, null);
  assert.equal(done.insertable, false);
  assert.equal(done.partial, "停止前的字。停止后、回应前的字。");
  assert.equal(done.afterCancelChunks, 1);
  const [cancel] = await fake.events("cancel");
  assert.equal(cancel.sessionId, (await fake.events("prompt")).at(-1).sessionId);
  const [permission] = await fake.events("permission_after_cancel");
  assert.deepEqual(permission.answer.result, { outcome: { outcome: "cancelled" } });
  await until(() => provider.tasks.get(started.taskId).lateUpdates >= 2, { what: "迟到的消息记在被停的那一轮" });
  await fake.set({ cachedLogin: true, prompt: "ok" });
  const next = await send(provider, { kind: "selection", text: "下一段。" });
  assert.equal(next.outcome, "complete");
  assert.ok(!next.candidate.includes("迟到"));
  assert.equal(next.lateUpdates, 0);
  assert.equal((await provider.status()).state, "ready");
  await provider.disconnect();
});

await test("C10 一次只跑一轮：上一轮没结束再发被拒（409），不排队；也不能指错轮次去停", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, prompt: "hang" } });
  const provider = await connected(fake);
  const started = await provider.startPrompt({ kind: "selftest" });
  await assert.rejects(provider.startPrompt({ kind: "selftest" }), (error) => error.code === "acp_task_running" && error.status === 409);
  await assert.rejects(provider.models(), (error) => error.code === "acp_task_running");
  await assert.rejects(provider.cancel({ taskId: "acp-nope" }), (error) => error.code === "acp_wrong_task");
  await provider.cancel({ taskId: started.taskId });
  assert.equal((await provider.waitForTask(started.taskId)).outcome, "cancelled");
  await assert.rejects(provider.cancel(), (error) => error.code === "acp_nothing_to_cancel");
  assert.equal((await fake.events("prompt")).length, 1);
  await provider.disconnect();
});

await test("C08/C10 取消未确认：停止以后官方程序一直不确认 → 取消未确认，工坊结束它启动的进程，不说“已停止”", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, prompt: "cancel_ignore" } });
  const provider = await connected(fake, { timeouts: { cancelWaitMs: 500 } });
  const [start] = await fake.events("start");
  const started = await provider.startPrompt({ kind: "selftest" });
  await until(async () => (await provider.status()).task.chars > 0, { what: "收到第一段" });
  await provider.cancel();
  assert.equal((await provider.status()).task.state, "cancelling");
  const done = await provider.waitForTask(started.taskId);
  assert.equal(done.outcome, "cancel_unconfirmed");
  assert.equal(done.partial, "开始了。");
  assert.equal(done.candidate, null);
  const status = await provider.status();
  assert.equal(status.state, "cancel_unconfirmed");
  assert.equal(status.label, "取消未确认");
  assert.equal(status.connected, false);
  assert.ok(!/已停止/.test(done.message));
  await until(() => !alive(start.pid), { what: "进程结束" });
});

await test("C08/C11 崩溃：回答途中进程退出 → 结果未知，部分输出标成不完整；重连以后也不自动重发", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, prompt: "crash" } });
  const provider = await connected(fake);
  const started = await provider.startPrompt({ kind: "selftest" });
  const done = await provider.waitForTask(started.taskId);
  assert.equal(done.outcome, "unknown");
  assert.equal(done.candidate, null);
  assert.equal(done.partial, "说到一半");
  assert.match(done.message, /不会自动重发/);
  const status = await provider.status();
  assert.equal(status.state, "result_unknown");
  assert.equal(status.label, "结果未知");
  assert.equal(status.connected, false);
  await fake.set({ cachedLogin: true, prompt: "ok" });
  await provider.connect();
  await wait(200);
  assert.equal((await fake.events("prompt")).length, 1);
  assert.equal((await provider.status()).task.id, started.taskId);
  await provider.disconnect();
});

await test("C08 请求超时：一直没有回应 → 工坊发停止 → 结果未知，不当成功；停止也不确认 → 结果未知并结束进程", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, prompt: "hang" } });
  const provider = await connected(fake, { timeouts: { promptIdleMs: 300 } });
  const first = await provider.waitForTask((await provider.startPrompt({ kind: "selftest" })).taskId);
  assert.equal(first.outcome, "unknown");
  assert.equal(first.timedOut, "idle");
  assert.equal(first.candidate, null);
  assert.equal((await fake.events("cancel")).length, 1);
  let status = await provider.status();
  assert.equal(status.label, "结果未知");
  assert.equal(status.connected, true);
  await fake.set({ cachedLogin: true, prompt: "hang_silent" });
  const second = await provider.waitForTask((await provider.startPrompt({ kind: "selftest" })).taskId);
  assert.equal(second.outcome, "unknown");
  status = await provider.status();
  assert.equal(status.connected, false);
  assert.equal(status.label, "结果未知");
  assert.equal((await fake.events("prompt")).length, 2);
});

await test("C09 截断、拒绝、调用次数上限、空回复、不认识的结束原因：各有各的状态，都不给候选稿；连接照常可用", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const provider = await connected(fake);
  for (const [scenario, outcome, partial] of [
    ["max_tokens", "truncated", "半截的一句"],
    ["refusal", "refused", null],
    ["max_turn_requests", "turn_limit", "半截的一句"],
    ["empty", "empty", null],
    ["weird_stop", "unknown_stop", null],
    ["error", "failed", null],
  ]) {
    await fake.set({ cachedLogin: true, prompt: scenario });
    const done = await send(provider, { kind: "selection", text: "一段。" });
    assert.equal(done.outcome, outcome, scenario);
    assert.equal(done.candidate, null, scenario);
    assert.equal(done.partial, partial, scenario);
    assert.equal(done.insertable, false, scenario);
  }
  const status = await provider.status();
  assert.equal(status.state, "ready");
  assert.equal(status.real, null);
  await provider.disconnect();
});

await test("C08 协议错误：回答途中 stdout 夹着不是协议的行 → 记成协议错误、丢掉；回复照常拼对", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, prompt: "garbage" } });
  const provider = await connected(fake);
  const done = await send(provider, { kind: "selection", text: "一段。" });
  assert.equal(done.outcome, "complete");
  assert.equal(done.candidate, "正文一，正文二。");
  assert.equal((await provider.status()).diagnostics.protocol.protocolErrors, 4);
  await provider.disconnect();
});

await test("C06 额度受限：暂停发送，不自动重试，不改用 Gemini API；重连也不放行；作者确认以后才再发；说明 AI Credit Overages", async () => {
  geminiSeen.length = 0;
  const fake = await fakeRuntime({ control: { cachedLogin: true, prompt: "quota" } });
  const provider = await connected(fake);
  const done = await send(provider, { kind: "selection", text: "一段。" });
  assert.equal(done.outcome, "quota");
  assert.match(done.message, /不会自动重试/);
  assert.match(done.message, /AI Credit Overages/);
  assert.match(done.message, /Never/);
  let status = await provider.status();
  assert.equal(status.state, "quota_limited");
  assert.equal(status.label, "额度受限");
  assert.ok(status.quotaPause);
  await wait(200);
  assert.equal((await fake.events("prompt")).length, 1);
  await assert.rejects(provider.startPrompt({ kind: "selftest" }), (error) => error.status === 429 && error.code === "acp_quota_paused");
  await provider.disconnect();
  await provider.connect();
  assert.equal((await provider.status()).state, "quota_limited");
  await assert.rejects(provider.startPrompt({ kind: "selftest" }), (error) => error.code === "acp_quota_paused");
  assert.equal((await fake.events("prompt")).length, 1);
  await fake.set({ cachedLogin: true, prompt: "ok" });
  const again = await send(provider, { kind: "selftest", acknowledgeQuota: true });
  assert.equal(again.outcome, "complete");
  status = await provider.status();
  assert.equal(status.quotaPause, null);
  assert.equal(geminiSeen.length, 0);
  assert.equal(status.apiFallback, false);
  await provider.disconnect();
});

await test("C05 已真实接通（判断逻辑，模拟）：对方自称 Antigravity、end_turn、有正文才记，带时间、请求的模型、回报的模型、运行时路径和版本、agentInfo；自称别的不算；之后又登录过就不当现在的状态", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const provider = await connected(fake);
  await send(provider, { kind: "selftest" });
  let status = await provider.status();
  assert.equal(status.real, null);
  assert.equal(status.realCurrent, false);
  assert.equal(status.lastSimulated.agentInfo.name, "fake-acp-agent");
  assert.equal(status.lastSimulated.countsAs, "simulated");
  assert.equal(status.verification.reply.state, "simulated");
  await provider.disconnect();
  // 自称 Antigravity，但在握手里标明自己是模拟程序：照样只算模拟。
  await fake.set({ cachedLogin: true, agentInfo: LIKE_ANTIGRAVITY });
  await provider.connect();
  await send(provider, { kind: "selftest" });
  status = await provider.status();
  assert.equal(status.real, null);
  assert.equal(status.lastSimulated.countsAs, "simulated");
  await provider.disconnect();
  // 自称 Antigravity、不标模拟，但程序来源没核对（没有填核对过的 SHA-256）：最多只算协议结果。
  await fake.set({ cachedLogin: true, ...OFFICIAL_LIKE });
  await provider.connect();
  await send(provider, { kind: "selftest" });
  status = await provider.status();
  assert.equal(status.real, null);
  assert.equal(status.realCurrent, false);
  assert.equal(status.lastSimulated.countsAs, "protocol_only");
  assert.ok(status.lastSimulated.why.some((why) => /来源没有核对/.test(why)));
  assert.equal(status.verification.source.state, "unverified");
  assert.equal(status.verification.reply.state, "protocol_only");
  // 填上核对过的校验值：设置真的变了，旧连接作废；重新连接、再发一次，才算真实接通。
  status = await provider.saveConfig({ expectedSha256: shaFile(fake.path) });
  assert.equal(status.connected, false);
  await provider.connect();
  await send(provider, { kind: "selftest" });
  status = await provider.status();
  assert.equal(status.realCurrent, true);
  assert.equal(status.verification.source.state, "verified");
  assert.equal(status.verification.reply.state, "real");
  assert.equal(status.real.sourceVerified, true);
  const real = status.real;
  assert.equal(real.stopReason, "end_turn");
  assert.equal(real.agentInfo.title, "Antigravity ACP Server");
  assert.equal(real.runtimePath, fake.path);
  assert.match(real.runtimeVersion, /0\.0\.0-fake/);
  assert.equal(real.requestedModel.value, "gemini-fake-pro");
  assert.equal(real.requestedModel.chosen, false);
  assert.equal(real.reportedModel.value, "gemini-fake-pro");
  assert.ok(real.at && real.runtimeSha256 && real.chars > 0);
  await provider.login({ methodId: "oauth-personal" });
  status = await provider.status();
  assert.ok(status.real);
  assert.equal(status.realCurrent, false);
  await provider.disconnect();
});

await test("C18 换了运行时或官方程序升级（校验值变了）：“已真实接通”的记录清掉", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, ...OFFICIAL_LIKE } });
  const env = envFor(null);
  const provider = assist.createAcpProvider({ env, timeouts: FAST });
  providers.push(provider);
  await provider.saveConfig({ runtimePath: fake.path, expectedSha256: shaFile(fake.path) });
  await provider.connect();
  await send(provider, { kind: "selftest" });
  assert.ok((await provider.status()).realCurrent);
  await provider.disconnect();
  await appendFile(fake.path, "# 模拟升级\n");
  let status = await provider.check();
  assert.equal(status.real, null);
  assert.match(status.realCleared.reason, /换了/);
  assert.equal(status.runtime.state, "checksum_mismatch");
  // 作者核对过升级后的这一份，填上新的校验值。
  await provider.saveConfig({ expectedSha256: shaFile(fake.path) });
  await provider.connect();
  await send(provider, { kind: "selftest" });
  assert.ok((await provider.status()).realCurrent);
  const other = await fakeRuntime({ control: { cachedLogin: true } });
  status = await provider.saveConfig({ runtimePath: other.path });
  assert.equal(status.real, null);
  assert.equal(status.connected, false);
  assert.equal(status.settings.runtimePath, other.path);
  await assert.rejects(provider.saveConfig({ expectedSha256: "not-a-hash" }), (error) => error.code === "invalid_sha256");
  await assert.rejects(provider.saveConfig({ flags: ["--dangerously-skip-permissions"] }), (error) => error.code === "invalid_flags");
});

await test("C08 连接代次：断开重连以后，旧连接的迟到消息落不到新的一轮上", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, prompt: "hang" } });
  const provider = await connected(fake);
  const oldConn = provider.conn;
  const oldGeneration = provider.generation;
  await provider.disconnect();
  await provider.connect();
  assert.equal(provider.generation, oldGeneration + 1);
  const started = await provider.startPrompt({ kind: "selftest" });
  const sessionId = provider.tasks.get(started.taskId).sessionId;
  const stale = { sessionId, update: { sessionUpdate: "agent_message_chunk", content: { type: "text", text: "旧进程的字" } } };
  oldConn.dispatch({ jsonrpc: "2.0", method: "session/update", params: stale });
  provider.onNotification("session/update", stale, oldConn);
  const status = await provider.status();
  assert.equal(status.task.streamText, "");
  assert.ok(status.diagnostics.staleMessages >= 1);
  assert.ok(oldConn.stats.droppedAfterClose >= 1);
  assert.throws(() => provider.onAgentRequest("session/request_permission", { sessionId, options: [] }, oldConn), (error) => error.rpcCode === -32601);
  await provider.cancel();
  assert.equal((await provider.waitForTask(started.taskId)).outcome, "cancelled");
  await provider.disconnect();
});

await test("关闭写作台：结束工坊启动的官方程序（连同它拉起的子进程）、删掉临时目录；不动别的进程", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, grandchild: true } });
  const other = spawn(process.execPath, ["-e", "setTimeout(() => {}, 20000)"], { stdio: "ignore" });
  const provider = await connected(fake);
  const [start] = await fake.events("start");
  await until(async () => (await fake.events("grandchild")).length > 0, { what: "子进程起来" });
  const [kid] = await fake.events("grandchild");
  await provider.shutdown();
  try {
    await until(() => !alive(start.pid) && !alive(kid.pid), { what: "进程和子进程结束" });
  } finally {
    for (const target of [-start.pid, kid.pid]) {
      try {
        process.kill(target, "SIGKILL");
      } catch {}
    }
  }
  await assert.rejects(stat(start.cwd));
  assert.ok(alive(other.pid));
  assert.ok(!rt.liveRuntimePids().includes(other.pid));
  other.kill();
});

// ---------------------------------------------------------------- 本机服务的路由
await test("C19 本机服务：/api/acp/ 的 POST 要这一页的令牌；没有令牌、错的令牌、外站 Origin、外来 Host 都被拒，什么也不启动", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const root = await makeWorkspace();
  const server = createDashboardServer({ root, allowEdit: true, acp: { env: envFor(fake), timeouts: FAST } });
  const port = await listen(server);
  const token = (await api(port, "GET", "/api/acp/token")).json.token;
  assert.match(token, /^[a-f0-9]{64}$/);
  for (const headers of [{}, { "X-Novel-Workshop-Token": "0".repeat(64) }, { "X-Novel-Workshop-Token": token, Origin: "http://evil.example" }, { "X-Novel-Workshop-Token": token, Host: "evil.example" }]) {
    for (const route of ["connect", "login", "prompt", "selftest", "cancel", "disconnect", "config", "set-option"]) {
      const result = await api(port, "POST", `/api/acp/${route}`, {}, headers);
      assert.equal(result.status, 403, `${route} ${JSON.stringify(headers)}`);
    }
  }
  assert.equal((await api(port, "GET", "/api/acp/token", undefined, { Host: "evil.example" })).status, 403);
  assert.equal((await fake.events("start")).length, 0);
  const status = await api(port, "GET", "/api/acp/status");
  assert.equal(status.status, 200);
  assert.ok(!status.text.includes(token));
  await server.acpShutdown();
  server.close();
});

await test("路由：设置路径（Windows“复制为路径”的引号去掉）、检查、连接、登录、模型、切换、预览、发送、轮询、停止、断开都走得通；回应里没有令牌和密钥；没有打开自动互审的接口", async () => {
  const fake = await fakeRuntime();
  const root = await makeWorkspace();
  const env = envFor(null);
  const server = createDashboardServer({ root, allowEdit: true, assist: { env }, acp: { env, timeouts: FAST } });
  const port = await listen(server);
  const token = (await api(port, "GET", "/api/acp/token")).json.token;
  const post = (route, body = {}) => api(port, "POST", `/api/acp/${route}`, body, { "X-Novel-Workshop-Token": token });
  let result = await post("config", { runtimePath: `"${fake.path}"` });
  assert.equal(result.status, 200, result.text);
  assert.equal(result.json.settings.runtimePath, fake.path);
  result = await post("check");
  assert.equal(result.json.runtime.state, "launchable");
  assert.equal(result.json.label, "可启动");
  result = await post("connect");
  assert.equal(result.json.label, "待登录");
  result = await post("login", { methodId: "oauth-personal" });
  assert.equal(result.json.label, "已认证", result.text);
  result = await post("models");
  assert.equal(result.json.label, "可调用");
  assert.equal(result.json.session.options[0].id, "model");
  result = await post("set-option", { configId: "thought_level", value: "max" });
  assert.equal(result.json.preferences.thought_level.value, "max");
  result = await post("preview", { text: "【标记C】一段。", instruction: "改" });
  assert.equal(result.json.blocks[2].text, "要改的正文：\n【标记C】一段。");
  const digest = result.json.snapshot.digest;
  result = await post("prompt", { text: "【标记C】一段。", instruction: "改", expectedDigest: digest, source: { path: "正文/第001章.md" } });
  assert.equal(result.status, 200, result.text);
  const taskId = result.json.taskId;
  await until(async () => (await api(port, "GET", "/api/acp/status")).json.task.state === "finished", { what: "这一轮结束" });
  const status = await api(port, "GET", "/api/acp/status");
  assert.equal(status.json.task.id, taskId);
  assert.equal(status.json.task.candidate, "改好的第一句，第二句里有中文和表情😀，第三句收尾。");
  assert.equal(status.json.task.insertable, true);
  assert.ok(!status.text.includes(token) && !status.text.includes(GEMINI_KEY));
  assert.equal(status.json.autoReview.enabled, false);
  assert.equal(status.json.autoReview.label, "自动互审：关闭（订阅用途范围未确认）");
  assert.equal((await post("cancel")).status, 409);
  result = await post("selftest");
  assert.equal(result.status, 200, result.text);
  await until(async () => (await api(port, "GET", "/api/acp/status")).json.task.state === "finished", { what: "合成示例结束" });
  assert.equal((await api(port, "GET", "/api/acp/status")).json.task.insertable, false);
  assert.equal((await post("auto-review", { enabled: true })).status, 404);
  assert.equal((await api(port, "PUT", "/api/acp/connect", {}, { "X-Novel-Workshop-Token": token })).status, 405);
  result = await post("disconnect");
  assert.equal(result.json.connected, false);
  await server.acpShutdown();
  server.close();
});

await test("C15/C19 只读方式打开也能拿到候选稿；ACP 的路由不写任何文稿，作品目录前后一模一样", async () => {
  const root = await makeWorkspace();
  const before = await treeDigest(root);
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const server = createDashboardServer({ root, allowEdit: false, acp: { env: envFor(fake), timeouts: FAST } });
  const port = await listen(server);
  const token = (await api(port, "GET", "/api/acp/token")).json.token;
  const post = (route, body = {}) => api(port, "POST", `/api/acp/${route}`, body, { "X-Novel-Workshop-Token": token });
  assert.equal((await api(port, "GET", "/api/workspace")).json.readOnly, true);
  assert.equal((await post("connect")).status, 200);
  assert.equal((await post("models")).status, 200);
  const result = await post("prompt", { text: "【选中标记A-7f3】苏棠扣上头盔，从气闸里出来。", source: { path: "正文/第001章.md" } });
  assert.equal(result.status, 200, result.text);
  await until(async () => (await api(port, "GET", "/api/acp/status")).json.task.state === "finished", { what: "这一轮结束" });
  assert.ok((await api(port, "GET", "/api/acp/status")).json.task.candidate);
  await post("disconnect");
  assert.deepEqual(await treeDigest(root), before);
  await server.acpShutdown();
  server.close();
});

// ---------------------------------------------------------------- 检查脚本
await test("检查脚本：找不到运行时 → 2；握手失败 → 3；正常 → 0；报告去掉了主目录路径、没有令牌，写明连接检查不等于许可", async () => {
  const quiet = () => {};
  const missing = await check.runAcpCheck({ argv: ["--runtime", join(base, "nope", "agy")], env: envFor(null), print: quiet, timeouts: FAST });
  assert.equal(missing.code, 2);
  assert.ok(missing.lines.some((line) => line.includes("结论：没有找到")));
  const broken = await fakeRuntime({ control: { protocolVersion: 3 } });
  assert.equal((await check.runAcpCheck({ argv: ["--runtime", broken.path], env: envFor(null), print: quiet, timeouts: FAST })).code, 3);
  const fake = await fakeRuntime({ control: { stderrNoise: true, ...OFFICIAL_LIKE } });
  const env = envFor(null);
  const result = await check.runAcpCheck({ argv: ["--runtime", fake.path, "--sha256", shaFile(fake.path), "--login", "--try", "--thinking", "high"], env, print: quiet, timeouts: FAST });
  assert.equal(result.code, 0, result.lines.join("\n"));
  const report = await readFile(result.report, "utf8");
  for (const pattern of [/不等于允许把订阅用于写小说/, /未确认/, /2026-11-02/, /协议版本：1/, /oauth-personal/, /登录成功/, /结论：真实接通/, /AI Credit Overages/]) {
    assert.match(report, pattern);
  }
  assert.ok(!report.includes(`${HOME}/`) && !report.includes("ya29"));
  assert.ok(report.includes(assist.SELFTEST_SAMPLE.text));
  const prompts = await fake.events("prompt");
  assert.equal(prompts.length, 1);
  assert.equal(prompts[0].thought, "high");
  const stored = await readFile(join(env.NOVEL_WORKSHOP_CONFIG_DIR, "acp.json"), "utf8").catch(() => "{}");
  assert.ok(!stored.includes("high"));
  const plain = await fakeRuntime({ control: { cachedLogin: true } });
  const notOffered = await check.runAcpCheck({ argv: ["--runtime", plain.path, "--try", "--model", "gemini-imaginary"], env: envFor(null), print: quiet, timeouts: FAST });
  assert.equal(notOffered.code, 0);
  assert.ok(notOffered.lines.some((line) => line.includes("不在官方程序给出的清单里")));
  assert.equal((await plain.events("prompt")).length, 0);
  const notOfficial = await check.runAcpCheck({ argv: ["--runtime", plain.path, "--try"], env: envFor(null), print: quiet, timeouts: FAST });
  assert.ok(notOfficial.lines.some((line) => line.includes("不算接通 Google 官方运行时")));
  assert.equal((await check.runAcpCheck({ argv: ["--flag", "-p"], env: envFor(null), print: quiet })).code, 2);
  assert.notEqual(check.parseAcpCheckArguments(["--flag", "--dangerously-skip-permissions"]).error, null);
});

// ---------------------------------------------------------------- 第二轮：复审发现的问题
await test("F7 检查脚本 --zip 只算压缩包的校验值：配置了官方程序也不启动它；结论只说压缩包；和别的参数一起用会被拒", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const zip = join(base, "下载", "antigravity-acp-linux-x86_64.zip");
  await mkdir(dirname(zip), { recursive: true });
  await writeFile(zip, "not really a zip");
  const env = envFor(fake);
  const result = await check.runAcpCheck({ argv: ["--zip", zip], env, print: () => {} });
  assert.equal(result.code, 2);
  assert.ok(result.lines.some((line) => line.includes(sha("not really a zip"))));
  assert.match(result.lines.at(-1), /^结论：压缩包对不上/);
  assert.equal((await fake.events("start")).length, 0);
  assert.equal((await fake.events("version")).length, 0);
  const combined = await check.runAcpCheck({ argv: ["--zip", zip, "--runtime", fake.path], env, print: () => {} });
  assert.equal(combined.code, 2);
  assert.ok(combined.lines.some((line) => line.includes("不和别的参数一起用")));
  assert.equal((await fake.events("start")).length, 0);
});

await test("ACP-1 回复途中一行超长（超过 4 MiB）被丢掉，或者一段回复的那一行坏了：不当完整候选稿，不记已真实接通", async () => {
  for (const scenario of ["huge_chunk", "corrupt_chunk"]) {
    const fake = await fakeRuntime({ control: { cachedLogin: true, ...OFFICIAL_LIKE, prompt: scenario } });
    const provider = await connected(fake, { env: verifiedEnv(fake) });
    const done = await send(provider, { kind: "selection", text: "一段。" });
    assert.equal(done.outcome, "truncated", scenario);
    assert.equal(done.replyGap, true, scenario);
    assert.equal(done.insertable, false, scenario);
    assert.equal(done.candidate, null, scenario);
    assert.match(done.message, /丢掉/, scenario);
    const status = await provider.status();
    assert.equal(status.real, null, scenario);
    assert.equal(status.realCurrent, false, scenario);
    await provider.disconnect();
  }
});

await test("ACP-2 点了停止，官方程序却仍以 end_turn 交回整段：标成不完整（cancel_race），不能放进编辑器，不记已真实接通", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, ...OFFICIAL_LIKE, prompt: "cancel_endturn" } });
  const provider = await connected(fake, { env: verifiedEnv(fake) });
  const started = await provider.startPrompt({ kind: "selection", text: "一段。" });
  await until(async () => (await provider.status()).task.chars > 0, { what: "收到第一段" });
  await provider.cancel();
  const done = await provider.waitForTask(started.taskId);
  assert.equal(done.outcome, "cancel_race");
  assert.equal(done.stopReason, "end_turn");
  assert.equal(done.insertable, false);
  assert.equal(done.candidate, null);
  assert.equal(done.partial, "停止前的字。——取消之后才写的后半段。");
  assert.equal((await provider.status()).real, null);
  await provider.disconnect();
});

await test("ACP-3/RT-03 单实例：同一个配置目录，第二个写作台（或 check-acp）不能用，说清楚已经有一个在用；第一个关掉以后才能用；记录按字段合并，不拿旧副本盖掉别处写的", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const env = envFor(fake);
  const first = assist.createAcpProvider({ env, timeouts: FAST, tool: "写作台" });
  const second = assist.createAcpProvider({ env, timeouts: FAST, tool: "写作台" });
  providers.push(first, second);
  await first.connect();
  await assert.rejects(second.connect(), (error) => error.code === "acp_other_instance" && error.status === 409 && /另一个写作台/.test(error.message));
  await assert.rejects(second.saveConfig({ runtimePath: fake.path }), (error) => error.code === "acp_other_instance");
  const status = await second.status();
  assert.equal(status.state, "other_instance");
  assert.equal(status.instance.other.pid, process.pid);
  const cli = await check.runAcpCheck({ argv: [], env, print: () => {}, timeouts: FAST });
  assert.equal(cli.code, 2);
  assert.ok(cli.lines.some((line) => line.includes("另一个写作台")));
  assert.equal((await fake.events("start")).length, 1);
  await first.shutdown();
  await second.connect();
  assert.equal((await second.status()).connected, true);
  await second.shutdown();
  const file = join(env.NOVEL_WORKSHOP_CONFIG_DIR, "merge-test.json");
  const left = new store.RecordStore(file);
  const right = new store.RecordStore(file);
  await left.update({ real: { at: "A" } });
  await right.update({ login: { at: "B" } });
  await left.update({ lastTask: { id: "t" } });
  const merged = JSON.parse(await readFile(file, "utf8"));
  assert.deepEqual([merged.real?.at, merged.login?.at, merged.lastTask?.id], ["A", "B", "t"]);
  assert.equal((await left.load()).login.at, "B");
});

await test("ACP-4 登录以后不再用登录以前开的会话：清单和发送都在新的登录下重开", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const provider = await connected(fake);
  await provider.models();
  const before = (await fake.events("session")).map((entry) => entry.sessionId);
  const status = await provider.login({ methodId: "oauth-personal" });
  assert.equal(status.session, null);
  assert.equal(status.ladder.step, 3);
  assert.equal(status.state, "authenticated");
  const done = await send(provider, { kind: "selftest" });
  assert.equal(done.outcome, "complete");
  const [prompt] = await fake.events("prompt");
  assert.ok(!before.includes(prompt.sessionId), `${prompt.sessionId} 是登录以前开的`);
  await provider.disconnect();
});

await test("ACP-5/F3 额度暂停：重连以后状态仍是额度受限（不显示可调用）；写作台重启以后也照样暂停，确认以后才再发", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, prompt: "quota" } });
  const env = envFor(fake);
  const first = assist.createAcpProvider({ env, timeouts: FAST });
  providers.push(first);
  await first.connect();
  await send(first, { kind: "selftest" });
  await first.disconnect();
  await first.connect();
  await first.models();
  let status = await first.status();
  assert.equal(status.state, "quota_limited");
  assert.equal(status.label, "额度受限");
  await first.shutdown();
  const second = assist.createAcpProvider({ env, timeouts: FAST });
  providers.push(second);
  status = await second.status();
  assert.equal(status.state, "quota_limited");
  assert.ok(status.quotaPause);
  await fake.set({ cachedLogin: true, prompt: "ok" });
  await second.connect();
  await assert.rejects(second.startPrompt({ kind: "selftest" }), (error) => error.code === "acp_quota_paused");
  assert.equal((await fake.events("prompt")).length, 1);
  assert.equal((await send(second, { kind: "selftest", acknowledgeQuota: true })).outcome, "complete");
  assert.equal((await second.status()).quotaPause, null);
  await second.shutdown();
  const record = JSON.parse(await readFile(join(env.NOVEL_WORKSHOP_CONFIG_DIR, "acp-status.json"), "utf8"));
  assert.equal(record.quotaPause, undefined);
});

await test("ACP-6/F10 额度受限（或出错）以前已经收到的半段：留着、标成不完整，不当候选稿", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, prompt: "quota_after_text" } });
  const provider = await connected(fake);
  const done = await send(provider, { kind: "selection", text: "一段。" });
  assert.equal(done.outcome, "quota");
  assert.equal(done.partial, "已经写好的半段。");
  assert.equal(done.insertable, false);
  assert.equal(done.candidate, null);
  assert.match(done.message, /标成不完整/);
  await provider.shutdown();
});

await test("ACP-7 回复超过上限：从超的那一段起整轮不再收，留下的是连续的前一段；上限按字（码点）算，不按 UTF-16 单元", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, replyChunks: ["a".repeat(199990), "X".repeat(20), "尾巴"] } });
  const provider = await connected(fake);
  const done = await send(provider, { kind: "selection", text: "一段。" });
  assert.equal(done.outcome, "truncated");
  assert.equal(done.overflow, true);
  assert.equal(done.partial, "a".repeat(199990));
  await fake.set({ cachedLogin: true, replyChunks: ["😀".repeat(150000), "尾", "。"] });
  const emoji = await send(provider, { kind: "selection", text: "一段。" });
  assert.equal(emoji.outcome, "complete");
  assert.equal(emoji.chars, 150002);
  await provider.disconnect();
});

await test("ACP-8/F9 放进编辑器的文字：选区自己的全角缩进和换行照留；回复里的 CRLF 换成 LF（页面里的函数直接拿来跑，服务端也换）", async () => {
  const app = await readFile(join(skill, "assets", "dashboard", "app.js"), "utf8");
  const grab = (name) => app.match(new RegExp(`function ${name}\\([^)]*\\) \\{[\\s\\S]*?\\n\\}`))[0];
  const helpers = new Function(`${grab("normalizeNewlines")}\n${grab("acpInsertionText")}\nreturn { normalizeNewlines, acpInsertionText };`)();
  const ideo = String.fromCharCode(0x3000);
  const selection = `${ideo}${ideo}他推开门走了出去，外面雪还在下。\n`;
  assert.equal(helpers.acpInsertionText(selection, `${ideo}${ideo}他推门出去，雪还在下。\n`), `${ideo}${ideo}他推门出去，雪还在下。\n`);
  assert.equal(helpers.acpInsertionText(selection, "他推门出去，\r\n雪还在下。"), `${ideo}${ideo}他推门出去，\n雪还在下。\n`);
  assert.equal(helpers.normalizeNewlines("甲\r\n乙\r丙\n"), "甲\n乙\n丙\n");
  assert.match(grab("replaceEditorRange"), /normalizeNewlines\(rawReplacement\)/);
  assert.match(grab("acpInsert"), /acpInsertionText\(text, task\.candidate\)/);
  const fake = await fakeRuntime({ control: { cachedLogin: true, prompt: "crlf" } });
  const provider = await connected(fake);
  const done = await send(provider, { kind: "selection", text: "一段。" });
  assert.equal(done.candidate, "改好的第一句。\n改好的第二句。");
  await provider.disconnect();
});

await test("ACP-9 这一轮里官方程序把模型换了：不当候选稿，不记已真实接通，状态说配置失效", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, ...OFFICIAL_LIKE } });
  const provider = await connected(fake, { env: verifiedEnv(fake) });
  await provider.models();
  await provider.setOption({ configId: "model", value: "gemini-fake-pro" });
  await fake.set({ cachedLogin: true, ...OFFICIAL_LIKE, prompt: "model_switch" });
  const done = await send(provider, { kind: "selection", text: "一段。" });
  assert.equal(done.outcome, "model_changed");
  assert.equal(done.insertable, false);
  assert.equal(done.candidate, null);
  assert.equal(done.partial, "开头，结尾。");
  assert.equal(done.modelMismatch.requested.value, "gemini-fake-pro");
  assert.equal(done.modelMismatch.reported.value, "gemini-fake-flash");
  const status = await provider.status();
  assert.equal(status.real, null);
  assert.equal(status.state, "config_invalid");
  await provider.disconnect();
});

await test("ACP-SEC-1/F1 关掉终端窗口（SIGHUP）：写作台照样结束它启动的官方程序和它拉起的子进程，删掉临时目录", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, grandchild: true } });
  const privateTmp = join(base, "server-tmp");
  await mkdir(privateTmp, { recursive: true });
  const root = await makeWorkspace();
  const env = { ...envFor(fake), TMPDIR: privateTmp };
  const server = spawn(process.execPath, [join(skill, "scripts", "oh-story", "dashboard-server.mjs"), "--root", root, "--port", "0"], { env, stdio: ["ignore", "pipe", "pipe"] });
  let out = "";
  server.stdout.on("data", (chunk) => {
    out += chunk;
  });
  server.stderr.resume();
  let start = null;
  let kid = null;
  try {
    await until(() => /本机地址：http:\/\/127\.0\.0\.1:\d+/.test(out), { what: "服务启动" });
    const port = Number(out.match(/127\.0\.0\.1:(\d+)/)[1]);
    const token = (await api(port, "GET", "/api/acp/token")).json.token;
    const connect = await api(port, "POST", "/api/acp/connect", {}, { "X-Novel-Workshop-Token": token });
    assert.equal(connect.status, 200, connect.text);
    [start] = await fake.events("start");
    await until(async () => (await fake.events("grandchild")).length > 0, { what: "子进程起来" });
    [kid] = await fake.events("grandchild");
    assert.ok((await readdir(privateTmp)).some((name) => name.startsWith("novel-workshop-acp-")));
    const exited = new Promise((accept) => server.once("exit", accept));
    server.kill("SIGHUP");
    await exited;
    await until(() => !alive(start.pid) && !alive(kid.pid), { what: "官方程序和它的子进程都结束" });
    assert.deepEqual((await readdir(privateTmp)).filter((name) => name.startsWith("novel-workshop-acp-")), []);
  } finally {
    // 检查失败时也不留进程：服务、官方程序（的进程组）和它拉起的子进程都结束掉。
    if (server.exitCode === null && server.signalCode === null) server.kill("SIGKILL");
    for (const target of [start && -start.pid, kid?.pid]) {
      try {
        if (target) process.kill(target, "SIGKILL");
      } catch {}
    }
  }
});

await test("ACP-SEC-2 取令牌和每个 POST 都要是这个页面自己（同源）；页面不能改种类和官方开关；别的用户能改的程序或文件夹不启动", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const root = await makeWorkspace();
  const env = envFor(null);
  const server = createDashboardServer({ root, allowEdit: true, acp: { env, timeouts: FAST } });
  const port = await listen(server);
  assert.equal((await api(port, "GET", "/api/acp/token", undefined, { "Sec-Fetch-Site": "cross-site" })).status, 403);
  assert.equal((await api(port, "GET", "/api/acp/token", undefined, { Origin: "http://evil.example" })).status, 403);
  const page = await api(port, "GET", "/api/acp/token", undefined, { "Sec-Fetch-Site": "same-origin", Origin: `http://127.0.0.1:${port}` });
  assert.equal(page.status, 200);
  const token = page.json.token;
  const post = (route, body = {}, headers = {}) => api(port, "POST", `/api/acp/${route}`, body, { "X-Novel-Workshop-Token": token, ...headers });
  assert.equal((await post("check", {}, { "Sec-Fetch-Site": "cross-site" })).status, 403);
  let result = await post("config", { runtimePath: join(base, "x", "anything"), kind: "agy-cli" });
  assert.equal(result.status, 400);
  assert.equal(result.json.error.code, "acp_config_local_only");
  assert.equal((await post("config", { flags: ["--sandbox"] })).json.error.code, "acp_config_local_only");
  assert.equal(await readFile(join(env.NOVEL_WORKSHOP_CONFIG_DIR, "acp.json"), "utf8").catch(() => "none"), "none");
  assert.equal((await post("config", { runtimePath: fake.path })).status, 200);
  await chmod(fake.path, 0o757);
  result = await post("check");
  assert.equal(result.json.runtime.state, "path_invalid");
  assert.match(result.json.runtime.message, /别的用户也能改/);
  await chmod(fake.path, 0o755);
  await chmod(fake.dir, 0o777);
  assert.equal((await post("check")).json.runtime.state, "path_invalid");
  await chmod(fake.dir, 0o755);
  assert.equal((await post("check")).json.runtime.state, "launchable");
  assert.equal((await fake.events("start")).length, 0);
  await server.acpShutdown();
  server.close();
});

await test("ACP-SEC-3/F6 诊断和报告去掉邮箱、JWT、授权码、client secret；报告不再说“没有账号信息”，请作者发出前自己看一遍", async () => {
  const scrub = rt.makeScrubber({ home: "/home/alice", env: {}, platform: "linux" });
  const secrets = ["alice.writer@gmail.com", "eyJhbGciOiJSUzI1NiJ9", "4/0AeaYSHB", "GOCSPX-", "xyz123", "4/0Abcd"];
  for (const sample of ["Logged in as alice.writer@gmail.com", "id token eyJhbGciOiJSUzI1NiJ9.eyJlbWFpbCI6ImEifQ.c2lnbmF0dXJl", '{"code": "4/0AeaYSHBabcdefghijk"}', "client secret GOCSPX-abcDEF123_456", '{"client_secret":"GOCSPX-zzz"}', "state=xyz123 code: 4/0Abcdefghijklm"]) {
    const out = scrub(sample);
    for (const secret of secrets) assert.ok(!out.includes(secret), `${sample} -> ${out}`);
  }
  const fake = await fakeRuntime({ control: { protocolVersion: 3, initDelayMs: 150, stderrText: "Using account alice.writer@gmail.com; cached id token eyJhbGciOiJSUzI1NiJ9.eyJlbWFpbCI6ImEifQ.c2ln; GOCSPX-secret123" } });
  const printed = [];
  const result = await check.runAcpCheck({ argv: ["--runtime", fake.path], env: envFor(null), print: (line) => printed.push(line), timeouts: FAST });
  assert.equal(result.code, 3);
  const report = await readFile(result.report, "utf8");
  assert.ok(report.includes("[官方程序的 stderr]"));
  for (const secret of ["alice.writer@gmail.com", "eyJhbGciOiJSUzI1NiJ9", "GOCSPX-secret123"]) assert.ok(!report.includes(secret), secret);
  const shown = printed.join("\n");
  assert.ok(!shown.includes("没有密钥、令牌和账号信息"));
  assert.match(shown, /发给别人之前请自己从头看一遍/);
});

await test("ACP-SEC-4 查版本也在新建的空目录里跑（不在共用的系统临时目录本身里），跑完删掉", async () => {
  const fake = await fakeRuntime();
  const info = await rt.inspectRuntime({ configuredPath: fake.path });
  assert.equal(info.state, "launchable");
  const [version] = await fake.events("version");
  assert.notEqual(version.cwd, realTmp);
  assert.ok(basename(version.cwd).startsWith("novel-workshop-acp-") && dirname(version.cwd) === realTmp, version.cwd);
  await assert.rejects(stat(version.cwd));
});

await test("ACP-SEC-5/F2 Windows 的收尾（在 Linux 上按 win32 分支走，没有在真实 Windows 上跑过）：taskkill 用系统目录里的绝对路径；先等它走完整棵树再结束根进程；根进程已经退出就不再 taskkill", async () => {
  assert.equal(rt.taskkillPath({ SystemRoot: "D:\\Win" }), "D:\\Win\\System32\\taskkill.exe");
  assert.equal(rt.taskkillPath({}), "C:\\Windows\\System32\\taskkill.exe");
  const calls = [];
  rt.setTaskkillRunnerForTests(async (pid) => {
    calls.push({ pid, aliveAtCall: alive(pid) });
    await wait(50);
  });
  const cwd = await rt.makeWorkDirectory();
  try {
    const fake = await fakeRuntime();
    const info = await rt.inspectRuntime({ configuredPath: fake.path, probe: false });
    const live = await rt.startRuntime(info, { cwd, platform: "win32", env: { PATH: process.env.PATH } });
    await live.stop(300);
    assert.equal(calls.length, 1);
    assert.equal(calls[0].pid, live.pid);
    assert.equal(calls[0].aliveAtCall, true);
    assert.ok(!alive(live.pid));
    const quick = await fakeRuntime({ control: { exitAtStart: 0 } });
    const gone = await rt.startRuntime(await rt.inspectRuntime({ configuredPath: quick.path, probe: false }), { cwd, platform: "win32", env: { PATH: process.env.PATH } });
    await gone.exited;
    await gone.stop(100);
    assert.equal(calls.length, 1);
  } finally {
    rt.setTaskkillRunnerForTests(null);
    await rt.removeWorkDirectory(cwd);
  }
});

await test("ACP-SEC-7/REG-5 检查以后文件变了（被替换、链接改指别的文件）：启动前一刻再核对一次，不启动；启动的是你填的路径（链接照原样），核对的是它指向的真实文件；查版本时它自己变了也不算核对过", async () => {
  const fake = await fakeRuntime();
  const cwd = await rt.makeWorkDirectory();
  try {
    let info = await rt.inspectRuntime({ configuredPath: fake.path });
    await appendFile(fake.path, "# replaced\n");
    await assert.rejects(rt.startRuntime(info, { cwd, env: { PATH: process.env.PATH, HOME } }), (error) => error.code === "runtime_changed");
    const other = await fakeRuntime();
    const linkDir = join(base, "link-dir");
    await mkdir(linkDir, { recursive: true });
    const link = join(linkDir, "agy");
    await symlink(fake.path, link);
    info = await rt.inspectRuntime({ configuredPath: link, probe: false });
    assert.equal(info.realPath, await realpath(fake.path));
    assert.equal(rt.buildLaunch(info, ["acp"], { platform: "linux" }).command, link);
    await unlink(link);
    await symlink(other.path, link);
    await assert.rejects(rt.startRuntime(info, { cwd, env: { PATH: process.env.PATH, HOME } }), (error) => error.code === "runtime_changed");
    // 查版本也一样：运行前的一刻核对，链接改指别的文件就不运行它。
    const probed = await rt.probeVersion(info, { env: { PATH: process.env.PATH, HOME } });
    assert.equal(probed.changed, true);
    assert.equal((await other.events("version")).length, 0);
    const selfish = await fakeRuntime();
    await selfish.set({ versionModifies: selfish.path });
    const changed = await rt.inspectRuntime({ configuredPath: selfish.path });
    assert.equal(changed.state, "checksum_mismatch");
    assert.match(changed.message, /查版本的时候变了/);
  } finally {
    await rt.removeWorkDirectory(cwd);
  }
});

await test("F8 终端登录：按官方程序声明的参数给出命令（运行时路径加参数，环境变量只给名字）；没声明就说不知道，提到文档里的 agy acp --login 没有核实", async () => {
  const fake = await fakeRuntime({ control: { authMethods: [
    { id: "oauth-personal", name: "Log in with Google" },
    { id: "terminal-login", name: "Terminal", type: "terminal", args: ["--login", "--no-browser"], env: { AGY_LOGIN_HINT: "secret-value" } },
    { id: "terminal-bare", name: "Terminal", type: "terminal" },
  ] } });
  const provider = await connected(fake);
  await assert.rejects(provider.login({ methodId: "terminal-login" }), (error) => error.code === "acp_method_terminal" && error.message.includes(fake.path) && error.message.includes("--login --no-browser") && error.message.includes("AGY_LOGIN_HINT"));
  await assert.rejects(provider.login({ methodId: "terminal-bare" }), (error) => error.code === "acp_method_terminal" && /工坊不知道命令/.test(error.message) && /没有核实/.test(error.message));
  const status = await provider.status();
  assert.deepEqual(status.handshake.authMethods[1].args, ["--login", "--no-browser"]);
  assert.deepEqual(status.handshake.authMethods[1].envNames, ["AGY_LOGIN_HINT"]);
  assert.ok(!JSON.stringify(status).includes("secret-value"));
  assert.equal((await fake.received("authenticate")).length, 0);
  await provider.disconnect();
});

await test("F11 已真实接通只算这一次连接：重新连接以后（期间可能在终端换了账号）要再发一次才算；官方程序报的版本或 agy --version 变了就清掉", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, ...OFFICIAL_LIKE } });
  const provider = await connected(fake, { env: verifiedEnv(fake) });
  await send(provider, { kind: "selftest" });
  assert.equal((await provider.status()).realCurrent, true);
  await provider.disconnect();
  let status = await provider.status();
  assert.equal(status.realCurrent, false);
  assert.ok(status.real);
  await provider.connect();
  await provider.models();
  status = await provider.status();
  assert.equal(status.realCurrent, false);
  assert.ok(status.real);
  await provider.disconnect();
  await fake.set({ cachedLogin: true, ...OFFICIAL_LIKE, agentInfo: { ...LIKE_ANTIGRAVITY, version: "10.0.0-模拟" } });
  await provider.connect();
  status = await provider.status();
  assert.equal(status.real, null);
  assert.match(status.realCleared.reason, /版本变了/);
  await send(provider, { kind: "selftest" });
  assert.equal((await provider.status()).realCurrent, true);
  await provider.disconnect();
  await fake.set({ cachedLogin: true, ...OFFICIAL_LIKE, agentInfo: { ...LIKE_ANTIGRAVITY, version: "10.0.0-模拟" }, versionText: "agy 11.0.0（模拟）" });
  status = await provider.check();
  assert.equal(status.real, null);
  assert.match(status.realCleared.reason, /版本/);
});

await test("RT-01 写作台在一轮中途被杀掉（SIGKILL，什么收尾都没跑）：重开以后这一轮显示结果未知（可能已经用了额度），旧锁作废可以接手；下一轮成功也不把它抹掉；作者确认以后才了结", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, prompt: "hang" } });
  const env = envFor(fake);
  const script = [
    `const assist = await import(${JSON.stringify(pathToFileURL(join(skill, "scripts", "oh-story", "acp-assist.mjs")).href)});`,
    `const provider = assist.createAcpProvider({ env: JSON.parse(process.env.TEST_ACP_ENV), timeouts: ${JSON.stringify(FAST)} });`,
    "await provider.connect();",
    'const started = await provider.startPrompt({ kind: "selection", text: "【崩溃那一轮】一段。" });',
    'console.log("SENT " + started.taskId);',
    'setTimeout(() => process.kill(process.pid, "SIGKILL"), 150);',
  ].join("\n");
  const child = spawn(process.execPath, ["--input-type=module", "-e", script], { env: { ...process.env, TEST_ACP_ENV: JSON.stringify(env) }, stdio: ["ignore", "pipe", "pipe"] });
  let out = "";
  child.stdout.on("data", (chunk) => {
    out += chunk;
  });
  child.stderr.resume();
  await new Promise((accept) => child.once("exit", accept));
  const taskId = out.match(/SENT (\S+)/)?.[1];
  assert.ok(taskId, out);
  assert.ok((await readdir(env.NOVEL_WORKSHOP_CONFIG_DIR)).includes("acp.lock"));
  const [start] = await fake.events("start");
  await until(() => !alive(start.pid), { what: "崩溃留下的官方程序收到输入结束后退出" });
  assert.ok((await stat(start.cwd)).isDirectory(), "被杀掉的写作台留下了工作目录");
  assert.match(basename(start.cwd), new RegExp(`^novel-workshop-acp-${child.pid}-`));
  const provider = assist.createAcpProvider({ env, timeouts: FAST });
  providers.push(provider);
  let status = await provider.status();
  assert.equal(status.state, "result_unknown");
  assert.deepEqual(status.openTurns.map((turn) => turn.taskId), [taskId]);
  assert.match(status.openTurns[0].reason, /写作台在这一轮结束前退出了/);
  await fake.set({ cachedLogin: true, prompt: "ok" });
  await provider.connect();
  await assert.rejects(stat(start.cwd), "下次连接时删掉了没人管的工作目录");
  assert.equal((await send(provider, { kind: "selftest" })).outcome, "complete");
  status = await provider.status();
  assert.equal(status.state, "result_unknown");
  assert.equal(status.openTurns.length, 1);
  await assert.rejects(provider.acknowledge({ taskId: "acp-not-open" }), (error) => error.code === "acp_turn_not_open");
  status = await provider.acknowledge({ taskId });
  assert.deepEqual(status.openTurns, []);
  assert.equal(status.state, "ready");
  await provider.shutdown();
  const lines = (await readFile(join(env.NOVEL_WORKSHOP_CONFIG_DIR, "acp-events.jsonl"), "utf8")).trim().split("\n").map((line) => JSON.parse(line));
  assert.deepEqual(lines.map((entry) => entry.event), ["sent", "sent", "finished", "acknowledged"]);
  assert.deepEqual(lines.map((entry) => entry.seq), [1, 2, 3, 4]);
  const raw = JSON.stringify(lines);
  for (const forbidden of ["崩溃那一轮", assist.SELFTEST_SAMPLE.text.slice(0, 10), GEMINI_KEY, "改好的第一句"]) assert.ok(!raw.includes(forbidden), forbidden);
  assert.ok(lines[0].digest && lines[0].runtime.sha256 && lines[0].model === "gemini-fake-pro");
});

await test("RT-01 清理没人管的工作目录：只删名字里的进程已经不在的那种；活着的进程的、旧格式的、别的名字的都不碰", async () => {
  const sweepBase = join(base, "sweep");
  await mkdir(sweepBase, { recursive: true });
  const dead = spawn(process.execPath, ["-e", ""], { stdio: "ignore" });
  await new Promise((accept) => dead.once("exit", accept));
  const names = [`novel-workshop-acp-${dead.pid}-abcDEF`, `novel-workshop-acp-${process.pid}-ghiJKL`, "novel-workshop-acp-zzzzzz", `other-${dead.pid}-abcdef`];
  for (const name of names) await mkdir(join(sweepBase, name, "session-x"), { recursive: true });
  assert.equal(await rt.sweepStaleWorkDirectories(sweepBase), 1);
  assert.deepEqual((await readdir(sweepBase)).sort(), names.slice(1).sort());
});

await test("RT-02 事件记录只追加、序号递增；超过上限换文件，还没了结的轮次抄进新文件不会丢；写了一半的行跳过并记数，后面照常追加", async () => {
  const dir = join(base, "journal");
  const journal = new store.EventJournal(join(dir, "acp-events.jsonl"), { capBytes: 600 });
  await journal.append({ event: "sent", taskId: "open-1", kind: "selection", digest: "d" });
  for (let index = 0; index < 20; index += 1) {
    await journal.append({ event: "sent", taskId: `t${index}` });
    await journal.append({ event: "finished", taskId: `t${index}`, outcome: index === 3 ? "unknown" : "complete" });
  }
  let read = await journal.read();
  assert.equal(read.badLines, 0);
  assert.deepEqual(store.openTurns(read.events).map((turn) => turn.taskId).sort(), ["open-1", "t3"]);
  assert.ok((await stat(journal.path)).size < 1600);
  assert.ok((await stat(journal.oldPath)).size > 0);
  const seqs = read.events.map((entry) => entry.seq);
  assert.deepEqual(seqs, [...seqs].sort((a, b) => a - b));
  assert.equal(new Set(seqs).size, seqs.length);
  await appendFile(journal.path, '{"seq": 999, "event": "sen');
  await journal.append({ event: "acknowledged", taskId: "t3" });
  read = await journal.read();
  assert.equal(read.badLines, 1);
  assert.deepEqual(store.openTurns(read.events).map((turn) => turn.taskId), ["open-1"]);
});

await test("RT-05 发送确认绑定运行时、模型和思考强度：预览里写明发给谁；换了思考强度，原来的确认作废、不发；没连接时预览里没有收件方", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const provider = await connected(fake);
  await provider.models();
  const preview = await provider.preview({ kind: "selftest" });
  const binding = preview.snapshot.binding;
  assert.equal(binding.runtime.path, fake.path);
  assert.ok(binding.runtime.sha256);
  assert.deepEqual([binding.model.value, binding.model.chosen, binding.thinking.value], ["gemini-fake-pro", false, "low"]);
  await provider.setOption({ configId: "thought_level", value: "max" });
  await assert.rejects(provider.startPrompt({ kind: "selftest", expectedDigest: preview.snapshot.digest }), (error) => error.code === "acp_preview_changed");
  assert.equal((await fake.events("prompt")).length, 0);
  const again = await provider.preview({ kind: "selftest" });
  assert.deepEqual([again.snapshot.binding.thinking.value, again.snapshot.binding.thinking.chosen], ["max", true]);
  assert.notEqual(again.snapshot.digest, preview.snapshot.digest);
  const done = await provider.waitForTask((await provider.startPrompt({ kind: "selftest", expectedDigest: again.snapshot.digest })).taskId);
  assert.equal(done.outcome, "complete");
  assert.equal((await fake.events("prompt")).at(-1).thought, "max");
  await provider.disconnect();
  assert.equal((await provider.preview({ kind: "selftest" })).snapshot.binding.runtime, null);
  const html = await readFile(join(skill, "assets", "dashboard", "index.html"), "utf8");
  assert.ok(html.includes('id="acpPreviewTarget"'));
});

await test("RT-06 本机记录坏了（不是 JSON、格式版本不认识）：报出来，不当成空的，也不往上写；设置文件坏了，“清除”把它改名留着再重来", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const env = envFor(fake);
  await mkdir(env.NOVEL_WORKSHOP_CONFIG_DIR, { recursive: true });
  const statusFile = join(env.NOVEL_WORKSHOP_CONFIG_DIR, "acp-status.json");
  await writeFile(statusFile, '{"real": {"at": "2026', "utf8");
  const provider = assist.createAcpProvider({ env, timeouts: FAST });
  providers.push(provider);
  let status = await provider.status();
  assert.equal(status.state, "store_unreadable");
  assert.match(status.message, /读不出来/);
  await assert.rejects(provider.connect(), (error) => error.code === "acp_store_unreadable" && error.status === 500);
  assert.equal(await readFile(statusFile, "utf8"), '{"real": {"at": "2026');
  assert.equal((await fake.events("start")).length, 0);
  await writeFile(statusFile, JSON.stringify({ format: "novel-workshop-acp/99" }), "utf8");
  status = await provider.status();
  assert.equal(status.state, "store_unreadable");
  assert.match(status.message, /格式版本/);
  await unlink(statusFile);
  const configFile = join(env.NOVEL_WORKSHOP_CONFIG_DIR, "acp.json");
  await writeFile(configFile, "not json", "utf8");
  assert.equal((await provider.status()).state, "store_unreadable");
  await assert.rejects(provider.saveConfig({ runtimePath: fake.path }), (error) => error.code === "acp_store_unreadable");
  assert.equal(await readFile(configFile, "utf8"), "not json");
  status = await provider.saveConfig({ clear: true });
  assert.notEqual(status.state, "store_unreadable");
  assert.ok((await readdir(env.NOVEL_WORKSHOP_CONFIG_DIR)).some((name) => name.startsWith("acp.json.broken-")));
  assert.equal((await provider.connect()).connected, true);
  await provider.shutdown();
});

// ---- 第三轮（复查）修的几处
function killQuietly(...targets) {
  for (const target of targets) {
    try {
      if (target) process.kill(target, "SIGKILL");
    } catch {}
  }
}

await test("REG-2/FIX-ACP-SEC-7 路径上面一级是链接（比如链接过来的主目录、~/.local/bin）：照样可启动、能查版本、能连接，不误报“程序变了”；Registry 发行包也一样", async () => {
  for (const name of ["agy", "agy_acp_server"]) {
    const fake = await fakeRuntime({ name, control: { cachedLogin: true } });
    const linked = join(base, `linked-folder-${counter}`);
    await symlink(fake.dir, linked);
    const configured = join(linked, name);
    const info = await rt.inspectRuntime({ configuredPath: configured });
    assert.equal(info.state, "launchable", info.message);
    assert.equal(info.realPath, await realpath(fake.path));
    if (name === "agy") assert.ok(info.version, info.versionNote);
    const provider = makeProvider(null, { env: { NOVEL_WORKSHOP_ACP_RUNTIME: configured } });
    const status = await provider.connect();
    assert.equal(status.connected, true);
    assert.equal(status.runtime.path, configured);
    assert.equal((await fake.events("start")).length, 1);
    await provider.shutdown();
  }
});

await test("REG-5 靠自己被叫的名字工作的程序（多合一程序、snap、Volta 那种）：链接名叫 agy，启动时还是叫 agy，查版本和连接都成功", async () => {
  counter += 1;
  const real = join(base, `multicall-${counter}`);
  const bin = join(base, `multicall-bin-${counter}`);
  await mkdir(real, { recursive: true });
  await mkdir(bin, { recursive: true });
  const controlFile = join(real, "control.json");
  const logFile = join(real, "agent-log.jsonl");
  await writeFile(controlFile, JSON.stringify({ cachedLogin: true }), "utf8");
  const shim = join(real, "multicall-shim");
  await writeFile(shim, `#!/bin/sh\ncase "$(basename "$0")" in\n  agy) exec '${process.execPath}' '${FAKE}' --control '${controlFile}' --log '${logFile}' "$@" ;;\n  *) echo "started as $(basename "$0")" >&2; exit 3 ;;\nesac\n`, { mode: 0o755 });
  await chmod(shim, 0o755);
  const link = join(bin, "agy");
  await symlink(shim, link);
  const info = await rt.inspectRuntime({ configuredPath: link });
  assert.equal(info.state, "launchable", info.message);
  assert.ok(info.version, `查版本失败：${info.versionNote}`);
  assert.equal(rt.buildLaunch(info, ["acp"], { platform: "linux" }).command, link);
  const provider = makeProvider(null, { env: { NOVEL_WORKSHOP_ACP_RUNTIME: link } });
  assert.equal((await provider.connect()).connected, true);
  await provider.shutdown();
});

await test("REG-11 只有同组能写的程序或文件夹：照常可启动，但检查结果、页面和 check-acp 报告里多一行“同组的其他用户能改这个程序或文件夹”", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  await chmod(fake.dir, 0o775);
  try {
    const info = await rt.inspectRuntime({ configuredPath: fake.path });
    assert.equal(info.state, "launchable", info.message);
    assert.equal(info.warnings.length, 1);
    assert.match(info.warnings[0], /同组的其他用户能改这个程序或文件夹/);
    const provider = makeProvider(fake);
    const checked = await provider.check();
    assert.match(checked.runtime.warnings.join(""), /同组的其他用户能改/);
    await provider.shutdown();
    const cli = await check.runAcpCheck({ argv: [], env: envFor(fake), print: () => {}, timeouts: FAST });
    assert.equal(cli.code, 0);
    assert.ok(cli.lines.some((line) => line.startsWith("  提醒：同组的其他用户能改这个程序或文件夹")), cli.lines.join("\n"));
    await chmod(fake.path, 0o775);
    assert.equal((await rt.inspectRuntime({ configuredPath: fake.path, probe: false })).warnings.length, 2);
  } finally {
    await chmod(fake.dir, 0o755);
    await chmod(fake.path, 0o755);
  }
  const app = await readFile(join(skill, "assets", "dashboard", "app.js"), "utf8");
  assert.ok(app.includes("for (const warning of runtime.warnings || [])"));
});

await test("FIX-ACP-SEC-2 Windows 上程序的位置（在 Linux 上按 win32 规则算，没有在真实 Windows 上跑过）：Public、ProgramData、别的账号的用户文件夹不启动；自己的用户文件夹、Program Files 照常；别处能启动但提醒；不分大小写", async () => {
  const env = {
    USERPROFILE: "C:\\Users\\me",
    LOCALAPPDATA: "C:\\Users\\me\\AppData\\Local",
    APPDATA: "C:\\Users\\me\\AppData\\Roaming",
    ProgramFiles: "C:\\Program Files",
    "ProgramFiles(x86)": "C:\\Program Files (x86)",
    ProgramData: "C:\\ProgramData",
    PUBLIC: "C:\\Users\\Public",
    SystemDrive: "C:",
  };
  const verdict = (path, realPath = path, which = env) => rt.windowsLocationCheck(path, realPath, which);
  assert.match(verdict("C:\\Users\\Public\\x\\agy.exe").refuse, /Public/);
  assert.match(verdict("c:\\programdata\\agy\\agy.exe").refuse, /ProgramData/);
  assert.match(verdict("C:\\Users\\other\\agy\\agy.exe").refuse, /别的账号的用户文件夹/);
  assert.match(verdict("C:\\Users\\meme\\agy.exe").refuse, /别的账号的用户文件夹/);
  assert.match(verdict("C:\\Users\\me\\agy.cmd", "C:\\Users\\Public\\agy.cmd").refuse, /Public/);
  for (const ok of ["C:\\Users\\me\\AppData\\Local\\agy\\agy.exe", "c:\\users\\ME\\tools\\agy.exe", "C:\\Program Files\\agy\\agy.exe", "C:\\Program Files (x86)\\agy\\agy.exe"]) {
    assert.deepEqual(verdict(ok), { refuse: null, warnings: [] }, ok);
  }
  const elsewhere = verdict("D:\\tools\\agy.exe");
  assert.equal(elsewhere.refuse, null);
  assert.equal(elsewhere.warnings.length, 1);
  assert.match(elsewhere.warnings[0], /不查文件夹的权限（ACL）/);
  // 没有 PUBLIC、ProgramData 这些环境变量时，按用户文件夹和系统盘推出来。
  const bare = { USERPROFILE: "C:\\Users\\me" };
  assert.match(verdict("C:\\Users\\Public\\agy.exe", undefined, bare).refuse, /Public/);
  assert.match(verdict("C:\\ProgramData\\agy.exe", undefined, bare).refuse, /ProgramData/);
});

await test("FIX-ACP-SEC-1/REG-4 check-acp 被 Ctrl+C（SIGINT）或关掉窗口（SIGHUP）打断：照样结束官方程序和它拉起的子进程、删掉临时目录、放开锁，报告写明被中断，退出码 130 / 129", async () => {
  for (const [signal, code] of [["SIGINT", 130], ["SIGHUP", 129]]) {
    const fake = await fakeRuntime({ control: { cachedLogin: true, grandchild: true, prompt: "hang" } });
    const privateTmp = join(base, `check-tmp-${signal}`);
    await mkdir(privateTmp, { recursive: true });
    const env = { ...envFor(fake), TMPDIR: privateTmp };
    const child = spawn(process.execPath, [join(skill, "scripts", "oh-story", "acp-check.mjs"), "--try"], { env, stdio: ["ignore", "pipe", "pipe"] });
    let out = "";
    child.stdout.on("data", (chunk) => {
      out += chunk;
    });
    child.stderr.resume();
    let start = null;
    let kid = null;
    try {
      await until(async () => (await fake.received("session/prompt")).length > 0, { what: "合成示例发出", timeout: 15000 });
      [start] = await fake.events("start");
      await until(async () => (await fake.events("grandchild")).length > 0, { what: "子进程起来" });
      [kid] = await fake.events("grandchild");
      assert.ok((await readdir(privateTmp)).some((name) => name.startsWith("novel-workshop-acp-")));
      assert.ok((await readdir(env.NOVEL_WORKSHOP_CONFIG_DIR)).includes("acp.lock"));
      const exited = new Promise((accept) => child.once("exit", (exitCode, exitSignal) => accept({ exitCode, exitSignal })));
      child.kill(signal);
      const result = await exited;
      assert.equal(result.exitCode, code, `${signal}：${JSON.stringify(result)}\n${out}`);
      await until(() => !alive(start.pid) && !alive(kid.pid), { what: "官方程序和它的子进程都结束" });
      assert.deepEqual((await readdir(privateTmp)).filter((name) => name.startsWith("novel-workshop-acp-")), []);
      assert.ok(!(await readdir(env.NOVEL_WORKSHOP_CONFIG_DIR)).includes("acp.lock"), "锁放开了");
      const report = await readFile(join(env.NOVEL_WORKSHOP_CONFIG_DIR, "acp-check-report.txt"), "utf8");
      assert.ok(report.includes(`检查被中断（${signal}）`), report);
      assert.match(report, /一、官方程序/);
      assert.match(report, /结论（模拟）：/);
      assert.ok(!report.includes(GEMINI_KEY));
    } finally {
      if (child.exitCode === null && child.signalCode === null) child.kill("SIGKILL");
      killQuietly(start && -start.pid, kid?.pid);
    }
  }
});

await test("REG-9 Windows 的 Ctrl+Break（在 Linux 上按 win32 分支查，没有在真实 Windows 上跑过）：启动器也接住 SIGBREAK、不抢先退出、不转发；check-acp 也接住", async () => {
  const workbench = await load("workbench.mjs");
  assert.deepEqual(workbench.launcherSignals("win32"), ["SIGINT", "SIGTERM", "SIGHUP", "SIGBREAK"]);
  assert.deepEqual(workbench.launcherSignals("linux"), ["SIGINT", "SIGTERM", "SIGHUP"]);
  assert.deepEqual(check.interruptSignals("win32"), ["SIGINT", "SIGTERM", "SIGHUP", "SIGBREAK"]);
  assert.deepEqual(check.interruptSignals("darwin"), ["SIGINT", "SIGTERM", "SIGHUP"]);
  assert.equal(check.SIGNAL_EXIT_CODES.SIGBREAK, 149);
  const signals = ["SIGINT", "SIGTERM", "SIGHUP", "SIGBREAK"];
  const before = Object.fromEntries(signals.map((signal) => [signal, process.listeners(signal)]));
  const server = new EventEmitter();
  let forwarded = 0;
  server.kill = () => {
    forwarded += 1;
  };
  workbench.waitForServer(server, "win32");
  try {
    const added = process.listeners("SIGBREAK").filter((listener) => !before.SIGBREAK.includes(listener));
    assert.equal(added.length, 1, "启动器接住了 SIGBREAK");
    added[0]();
    assert.equal(forwarded, 0, "Windows 上不转发，等服务自己收尾");
  } finally {
    for (const signal of signals) for (const listener of process.listeners(signal)) if (!before[signal].includes(listener)) process.removeListener(signal, listener);
  }
});

await test("FIX-BJM13-RT-01/REG-1 写“已发出”记录的那一下点了停止或断开：停止优先，这一轮记成没有发出，不发 session/prompt，也不留成结果未知", async () => {
  for (const how of ["stop", "disconnect"]) {
    const fake = await fakeRuntime({ control: { cachedLogin: true } });
    const provider = await connected(fake);
    const original = provider.journal.append.bind(provider.journal);
    let entered;
    const inWindow = new Promise((accept) => {
      entered = accept;
    });
    let release;
    const held = new Promise((accept) => {
      release = accept;
    });
    provider.journal.append = async (entry) => {
      const record = await original(entry);
      if (entry.event === "sent") {
        entered();
        await held;
      }
      return record;
    };
    const pending = provider.startPrompt({ kind: "selftest" }).then(() => null, (error) => error);
    await inWindow;
    if (how === "stop") await provider.cancel({});
    else await provider.disconnect();
    release();
    const error = await pending;
    assert.equal(error?.code, "acp_cancelled_before_send", `${how}：${error?.message}`);
    assert.equal((await fake.received("session/prompt")).length, 0, `${how}：不该发出`);
    const task = [...provider.tasks.values()].at(-1);
    assert.equal(task.outcome, "not_sent");
    const status = await provider.status();
    assert.deepEqual(status.openTurns, [], how);
    assert.notEqual(status.state, "result_unknown");
    const events = (await readFile(join(provider.env.NOVEL_WORKSHOP_CONFIG_DIR, "acp-events.jsonl"), "utf8")).trim().split("\n").map((line) => JSON.parse(line)).filter((entry) => entry.taskId === task.id);
    assert.deepEqual(events.map((entry) => [entry.event, entry.outcome ?? null]), [["sent", null], ["finished", "not_sent"]]);
    await provider.shutdown();
  }
});

await test("FIX-BJM13-RT-01-B 另一个写作台还开着、正在进行的一轮：显示“另一个写作台正在进行”，不算结果未知，不能点“我知道了”；那一个死了以后才算没了结", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, prompt: "hang" } });
  const env = envFor(fake);
  const script = [
    `const assist = await import(${JSON.stringify(pathToFileURL(join(skill, "scripts", "oh-story", "acp-assist.mjs")).href)});`,
    `const provider = assist.createAcpProvider({ env: JSON.parse(process.env.TEST_ACP_ENV), timeouts: ${JSON.stringify({ ...FAST, promptIdleMs: 60000, promptTotalMs: 60000 })} });`,
    "await provider.connect();",
    'const started = await provider.startPrompt({ kind: "selection", text: "【另一个写作台的一轮】一段。" });',
    'console.log("SENT " + started.taskId);',
    "setInterval(() => {}, 1000);",
  ].join("\n");
  const child = spawn(process.execPath, ["--input-type=module", "-e", script], { env: { ...process.env, TEST_ACP_ENV: JSON.stringify(env) }, stdio: ["ignore", "pipe", "pipe"] });
  let out = "";
  child.stdout.on("data", (chunk) => {
    out += chunk;
  });
  child.stderr.resume();
  let start = null;
  try {
    await until(() => /SENT \S+/.test(out), { what: "另一个写作台发出", timeout: 10000 });
    const taskId = out.match(/SENT (\S+)/)[1];
    [start] = await fake.events("start");
    const provider = assist.createAcpProvider({ env, timeouts: FAST });
    providers.push(provider);
    let status = await provider.status();
    assert.equal(status.state, "other_instance");
    assert.deepEqual(status.openTurns, []);
    assert.deepEqual(status.runningElsewhere.map((turn) => [turn.taskId, turn.running]), [[taskId, true]]);
    assert.match(status.runningElsewhere[0].reason, /另一个写作台正在进行/);
    const lockFile = join(env.NOVEL_WORKSHOP_CONFIG_DIR, "acp.lock");
    assert.ok(status.message.includes(lockFile), status.message);
    await assert.rejects(provider.acknowledge({ taskId }), (error) => error.code === "acp_other_instance" && error.message.includes(lockFile) && /删掉这个文件再试/.test(error.message));
    const exited = new Promise((accept) => child.once("exit", accept));
    child.kill("SIGKILL");
    await exited;
    status = await provider.status();
    assert.deepEqual(status.runningElsewhere, []);
    assert.deepEqual(status.openTurns.map((turn) => turn.taskId), [taskId]);
    assert.match(status.openTurns[0].reason, /写作台在这一轮结束前退出了/);
    assert.equal(status.state, "result_unknown");
  } finally {
    if (child.exitCode === null && child.signalCode === null) child.kill("SIGKILL");
    killQuietly(start && -start.pid);
  }
  const app = await readFile(join(skill, "assets", "dashboard", "app.js"), "utf8");
  assert.ok(app.includes("const elsewhere = status?.runningElsewhere || [];"));
});

await test("FIX-BJM13-RT-03/REG-6 锁：开机以前留下的、太久没续的都算作废，能接手；两个同时接手只有一个接得上；心跳让活着的锁不作废；被接手的那一个知道自己丢了锁", async () => {
  const dir = join(base, "locks");
  await mkdir(dir, { recursive: true });
  const path = join(dir, "acp.lock");
  const put = (holder) => writeFile(path, JSON.stringify({ tool: "写作台", ...holder }), "utf8");
  const reason = async () => store.staleReason(JSON.parse(await readFile(path, "utf8")), await stat(path));
  // 1. 开机以前留下的：记的进程号现在是一个活着的、不相干的进程。
  await put({ pid: process.ppid, token: "before-boot", startedAt: new Date(store.bootTimeMs() - 3600_000).toISOString() });
  assert.equal(await reason(), "锁是这次开机以前留下的");
  let lock = new store.InstanceLock(path);
  assert.equal((await lock.acquire("测试")).ok, true);
  lock.releaseSync();
  // 进程号被后来启动的程序用上了：要读 /proc，不在这一条里查，单独一条（下面“REG-3 进程号复用”）。
  const sleeper = spawn(process.execPath, ["-e", "setInterval(() => {}, 1000)"], { stdio: "ignore" });
  try {
    // 3. 进程活着、也不是后来才启动的，但 2 分钟没续过：作废。续过的不作废。（不用 /proc。）
    await wait(30);
    await put({ pid: sleeper.pid, token: "silent", startedAt: new Date().toISOString() });
    assert.equal(await reason(), null);
    lock = new store.InstanceLock(path);
    const busy = await lock.acquire("测试");
    assert.equal(busy.ok, false);
    assert.equal(busy.holder.pid, sleeper.pid);
    const old = new Date(Date.now() - 10 * 60_000);
    await utimes(path, old, old);
    assert.equal(await reason(), "拿着锁的程序太久没有续上");
    assert.equal((await lock.acquire("测试")).ok, true);
    lock.releaseSync();
  } finally {
    sleeper.kill("SIGKILL");
  }
  // 4. 两个同时接手同一把作废的锁：只有一个接得上（另一个挪开的是新锁，会放回去）。
  const dead = spawn(process.execPath, ["-e", ""], { stdio: "ignore" });
  await new Promise((accept) => dead.once("exit", accept));
  await put({ pid: dead.pid, token: "dead-holder", startedAt: new Date().toISOString() });
  const slow = new store.InstanceLock(path);
  const fast = new store.InstanceLock(path);
  let fastResult = null;
  slow.beforeTakeover = async () => {
    slow.beforeTakeover = null;
    fastResult = await fast.acquire("check-acp");
  };
  const slowResult = await slow.acquire("写作台");
  assert.equal(fastResult?.ok, true);
  assert.equal(slowResult.ok, false);
  assert.equal(slowResult.holder.token, fast.token);
  assert.equal(JSON.parse(await readFile(path, "utf8")).token, fast.token);
  assert.deepEqual([fast.held, slow.held], [true, false]);
  assert.deepEqual((await readdir(dir)).filter((name) => name.includes(".stale-")), []);
  fast.releaseSync();
  // 5. 心跳：活着的锁一直在续，不作废；不续了（比如电脑睡了很久）才会被接手，原来那个下次用时知道锁丢了。
  const owner = new store.InstanceLock(path, { heartbeatMs: 40, staleMs: 400 });
  assert.equal((await owner.acquire("写作台")).ok, true);
  await wait(700);
  const other = new store.InstanceLock(path, { staleMs: 400 });
  assert.equal((await other.acquire("check-acp")).ok, false);
  clearInterval(owner.heartbeat);
  await wait(600);
  assert.equal((await other.acquire("check-acp")).ok, true);
  const lost = await owner.acquire("写作台");
  assert.deepEqual([lost.ok, lost.lost], [false, true]);
  assert.equal(owner.held, false);
  other.releaseSync();
});

await test("FIX-BJM13-RT-03 锁的提示：另一个在用时写出锁文件的完整路径、确定没开着就删掉它；这个写作台的锁被接手了也直接说", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const env = envFor(fake);
  const lockFile = join(env.NOVEL_WORKSHOP_CONFIG_DIR, "acp.lock");
  const first = assist.createAcpProvider({ env, timeouts: FAST });
  const second = assist.createAcpProvider({ env, timeouts: FAST, lockOptions: { staleMs: 60_000 } });
  providers.push(first, second);
  await first.connect();
  await assert.rejects(second.connect(), (error) => error.code === "acp_other_instance" && error.message.includes(lockFile) && /如果确定没有别的写作台或 check-acp 开着，删掉这个文件再试/.test(error.message));
  await writeFile(lockFile, JSON.stringify({ pid: process.pid, token: "taken-over-by-someone", tool: "check-acp", startedAt: new Date().toISOString() }), "utf8");
  await assert.rejects(first.models(), (error) => error.code === "acp_lock_lost" && error.status === 409 && error.message.includes(lockFile));
  await first.shutdown();
  await unlink(lockFile);
  assert.equal((await second.connect()).connected, true);
  await second.shutdown();
});

await test("FIX-BJM13-RT-02/REG-8 事件记录换文件两次以上：还没了结的轮次连同它的结果（取消未确认、结果未知）一起抄过去，原因不变", async () => {
  const journal = new store.EventJournal(join(base, "journal-rotate", "acp-events.jsonl"), { capBytes: 1200 });
  await journal.append({ event: "sent", taskId: "keep-cancel", kind: "selection" });
  await journal.append({ event: "finished", taskId: "keep-cancel", outcome: "cancel_unconfirmed" });
  await journal.append({ event: "sent", taskId: "keep-unknown", kind: "selection" });
  await journal.append({ event: "finished", taskId: "keep-unknown", outcome: "unknown" });
  await journal.append({ event: "sent", taskId: "keep-open", kind: "selection" });
  for (let index = 0; index < 60; index += 1) {
    await journal.append({ event: "sent", taskId: `n${index}` });
    await journal.append({ event: "finished", taskId: `n${index}`, outcome: "complete" });
  }
  const read = await journal.read();
  const keep = read.events.filter((entry) => entry.taskId.startsWith("keep-"));
  assert.ok(keep.length && keep.every((entry) => Number.isInteger(entry.carriedFrom)), "原来的那几行已经随旧文件换掉了（至少换了两次），剩下的都是抄过来的");
  const open = store.openTurns(read.events).map((turn) => [turn.taskId, turn.finished?.outcome ?? null]).sort();
  assert.deepEqual(open, [["keep-cancel", "cancel_unconfirmed"], ["keep-open", null], ["keep-unknown", "unknown"]]);
  const seqs = read.events.map((entry) => entry.seq);
  assert.equal(new Set(seqs).size, seqs.length);
});

await test("REG-7 额度暂停以磁盘上的为准：写作台只查过状态、check-acp 那边碰到额度受限，写作台再发也先停下来问；确认以后发出去，磁盘上的暂停也清掉", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, prompt: "quota" } });
  const env = envFor(fake);
  const workbench = assist.createAcpProvider({ env, timeouts: FAST });
  providers.push(workbench);
  assert.equal((await workbench.status()).quotaPause, null);
  const cli = await check.runAcpCheck({ argv: ["--try"], env, print: () => {}, timeouts: FAST });
  assert.equal(cli.code, 0);
  const statusFile = join(env.NOVEL_WORKSHOP_CONFIG_DIR, "acp-status.json");
  assert.ok(JSON.parse(await readFile(statusFile, "utf8")).quotaPause, "check-acp 记下了额度暂停");
  await fake.set({ cachedLogin: true, prompt: "ok" });
  await workbench.connect();
  const status = await workbench.status();
  assert.ok(status.quotaPause);
  assert.equal(status.state, "quota_limited");
  const sentBefore = (await fake.received("session/prompt")).length;
  await assert.rejects(workbench.startPrompt({ kind: "selftest" }), (error) => error.code === "acp_quota_paused");
  assert.equal((await fake.received("session/prompt")).length, sentBefore);
  assert.equal((await send(workbench, { kind: "selftest", acknowledgeQuota: true })).outcome, "complete");
  await until(async () => !JSON.parse(await readFile(statusFile, "utf8")).quotaPause, { what: "磁盘上的额度暂停清掉" });
  assert.equal((await workbench.status()).quotaPause, null);
  await workbench.shutdown();
});

// ---- r5.50：设置或核对结果变了，旧连接就不能再发；四件事分开看
// 走页面用的 HTTP 路由（同源请求头、页面令牌），对着模拟程序数它收到的 session/prompt。
async function pageClient(server) {
  const port = await listen(server);
  const origin = `http://127.0.0.1:${port}`;
  const same = { "Sec-Fetch-Site": "same-origin" };
  const token = (await api(port, "GET", "/api/acp/token", undefined, same)).json.token;
  const post = (route, body = {}) => api(port, "POST", `/api/acp/${route}`, body, { ...same, Origin: origin, "X-Novel-Workshop-Token": token });
  const status = async () => (await api(port, "GET", "/api/acp/status", undefined, same)).json;
  const finished = async (taskId) => {
    let last = null;
    await until(async () => {
      last = await status();
      return last.task?.id === taskId && last.task.state === "finished";
    }, { what: "这一轮结束" });
    return last;
  };
  return { port, post, status, finished };
}
const promptCount = async (fake) => (await fake.received("session/prompt")).length;
function journalLines(env) {
  try {
    return readFileSync(join(env.NOVEL_WORKSHOP_CONFIG_DIR, "acp-events.jsonl"), "utf8").trim().split("\n").filter(Boolean).map((line) => JSON.parse(line));
  } catch {
    return [];
  }
}

await test("R550-1 HTTP：连着的时候存一个错的校验值 → 旧连接作废、“已真实接通”马上清掉；检查报校验不符；新预览、旧预览、不带预览的选段都发不出去（模拟程序新收到的 session/prompt 是 0）；改回正确的、重新连接，旧预览仍然作废，新预览能发", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, ...OFFICIAL_LIKE } });
  const root = await makeWorkspace();
  const env = envFor(null);
  const server = createDashboardServer({ root, allowEdit: true, acp: { env, timeouts: FAST } });
  try {
    const page = await pageClient(server);
    const good = shaFile(fake.path);
    assert.equal((await page.post("config", { runtimePath: fake.path, expectedSha256: good })).status, 200);
    assert.equal((await page.post("connect")).status, 200);
    assert.equal((await page.post("models")).status, 200);
    const firstPreview = (await page.post("preview", { kind: "selftest" })).json;
    assert.ok(firstPreview.snapshot.binding.runtime.connection);
    let r = await page.post("selftest", { expectedDigest: firstPreview.snapshot.digest });
    assert.equal(r.status, 200, r.text);
    let s = await page.finished(r.json.taskId);
    assert.equal(s.task.outcome, "complete");
    assert.deepEqual([s.realCurrent, s.canSend, s.verification.source.state, s.verification.reply.state], [true, true, "verified", "real"]);
    const before = await promptCount(fake);
    const [start] = await fake.events("start");

    r = await page.post("config", { expectedSha256: "0".repeat(64) });
    assert.equal(r.status, 200, r.text);
    s = r.json;
    assert.deepEqual([s.connected, s.canSend, s.real, s.realCurrent, s.state], [false, false, null, false, "runtime_invalidated"]);
    assert.match(s.message, /你改了你核对过的校验值/);
    assert.match(s.sendBlock, /旧连接已作废/);
    assert.match(s.realCleared.reason, /校验值/);
    await until(() => !alive(start.pid), { what: "旧连接的官方程序结束" });

    r = await page.post("check");
    assert.equal(r.json.runtime.state, "checksum_mismatch");
    assert.equal(r.json.verification.source.state, "mismatch");
    assert.equal(r.json.canSend, false);
    const second = (await page.post("preview", { kind: "selftest" })).json;
    assert.equal(second.snapshot.binding.runtime, null);
    for (const [route, body] of [
      ["selftest", { expectedDigest: second.snapshot.digest }],
      ["selftest", { expectedDigest: firstPreview.snapshot.digest }],
      ["selftest", {}],
      ["prompt", { text: "一段。", instruction: "改紧一点" }],
    ]) {
      r = await page.post(route, body);
      assert.equal(r.status, 409, `${route} ${r.text}`);
      assert.equal(r.json.error.code, "acp_connection_revoked", `${route} ${r.text}`);
    }
    assert.equal((await page.post("models")).status, 409);
    assert.equal((await page.post("login", { methodId: "oauth-personal" })).status, 409);
    assert.equal(await promptCount(fake) - before, 0, "校验不符以后一次也没有发出");
    assert.equal((await fake.events("start")).length, 1, "没有偷偷重新连接");
    assert.equal((await page.status()).real, null, "迟到的结果没有把“已真实接通”找回来");

    // 改回正确的、检查、重新连接：上一次连接拿的预览仍然作废；新预览能发。
    assert.equal((await page.post("config", { expectedSha256: good })).status, 200);
    r = await page.post("check");
    assert.deepEqual([r.json.runtime.state, r.json.state], ["launchable", "launchable"]);
    assert.equal((await page.post("connect")).status, 200);
    r = await page.post("selftest", { expectedDigest: firstPreview.snapshot.digest });
    assert.equal(r.status, 409, r.text);
    assert.equal(r.json.error.code, "acp_preview_changed");
    assert.equal(await promptCount(fake) - before, 0);
    assert.equal((await page.status()).realCurrent, false, "重新连接以后，旧的“已真实接通”不当现在的状态");
    assert.equal((await page.post("models")).status, 200);
    const third = (await page.post("preview", { kind: "selftest" })).json;
    r = await page.post("selftest", { expectedDigest: third.snapshot.digest });
    assert.equal(r.status, 200, r.text);
    s = await page.finished(r.json.taskId);
    assert.equal(s.task.outcome, "complete");
    assert.equal(s.realCurrent, true);
    assert.equal(await promptCount(fake) - before, 1);
  } finally {
    await server.acpShutdown();
    server.close();
  }
});

await test("R550-2 HTTP：没改设置，重新检查发现程序变了（和连着的不是同一个）或找不到了：旧连接同样作废，说清原因，发不出去", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const root = await makeWorkspace();
  const env = envFor(null);
  const server = createDashboardServer({ root, allowEdit: true, acp: { env, timeouts: FAST } });
  try {
    const page = await pageClient(server);
    await page.post("config", { runtimePath: fake.path });
    assert.equal((await page.post("connect")).status, 200);
    const preview = (await page.post("preview", { kind: "selftest" })).json;
    const before = await promptCount(fake);
    await appendFile(fake.path, "# 换了一份\n");
    let r = await page.post("check");
    assert.equal(r.json.runtime.state, "launchable");
    assert.deepEqual([r.json.connected, r.json.canSend, r.json.state], [false, false, "runtime_invalidated"]);
    assert.match(r.json.message, /和连着的不是同一个/);
    r = await page.post("selftest", { expectedDigest: preview.snapshot.digest });
    assert.equal(r.json.error.code, "acp_connection_revoked");
    assert.equal(await promptCount(fake) - before, 0);
    // 再连上（作者看过了，认这一份），然后把程序挪走：检查说找不到，旧连接作废。
    assert.equal((await page.post("connect")).status, 200);
    await rm(fake.path);
    r = await page.post("check");
    assert.equal(r.json.runtime.state, "path_invalid");
    assert.equal(r.json.state, "runtime_invalidated");
    assert.match(r.json.message, /找不到这个文件/);
    assert.equal(r.json.verification.source.state, "missing");
    r = await page.post("prompt", { text: "一段。" });
    assert.equal(r.json.error.code, "acp_connection_revoked");
    assert.equal(await promptCount(fake) - before, 0);
  } finally {
    await server.acpShutdown();
    server.close();
  }
});

await test("R550-3 HTTP：先预览、再改设置：存一样的值什么也不变（预览照常能发）；真的换了程序路径，旧连接作废，用旧预览发不出去", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const other = await fakeRuntime({ control: { cachedLogin: true } });
  const root = await makeWorkspace();
  const env = envFor(null);
  const server = createDashboardServer({ root, allowEdit: true, acp: { env, timeouts: FAST } });
  try {
    const page = await pageClient(server);
    await page.post("config", { runtimePath: fake.path });
    await page.post("connect");
    let preview = (await page.post("preview", { kind: "selftest" })).json;
    let r = await page.post("config", { runtimePath: fake.path });
    assert.deepEqual([r.json.connected, r.json.canSend], [true, true], "存一样的值不动连接");
    r = await page.post("selftest", { expectedDigest: preview.snapshot.digest });
    assert.equal(r.status, 200, r.text);
    assert.equal((await page.finished(r.json.taskId)).task.outcome, "complete");
    const before = await promptCount(fake);
    preview = (await page.post("preview", { kind: "selftest" })).json;
    r = await page.post("config", { runtimePath: other.path });
    assert.deepEqual([r.json.connected, r.json.canSend, r.json.state], [false, false, "runtime_invalidated"]);
    assert.match(r.json.message, /你改了程序路径/);
    r = await page.post("selftest", { expectedDigest: preview.snapshot.digest });
    assert.equal(r.status, 409);
    assert.equal(r.json.error.code, "acp_connection_revoked");
    assert.equal(await promptCount(fake) - before, 0);
    assert.equal((await other.events("start")).length, 0, "没有自动启动新程序");
  } finally {
    await server.acpShutdown();
    server.close();
  }
});

await test("R550-4 HTTP：准备发送的那一会儿（官方程序开会话慢）点停止或断开：照样马上能点，这一轮记成没有发出，本机不留“已发出”；这一会儿里检查、改设置都被挡住（不会插到中间）", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, sessionNewDelayMs: 700 } });
  const root = await makeWorkspace();
  const env = envFor(null);
  const server = createDashboardServer({ root, allowEdit: true, acp: { env, timeouts: FAST } });
  try {
    const page = await pageClient(server);
    await page.post("config", { runtimePath: fake.path });
    for (const how of ["cancel", "disconnect"]) {
      assert.equal((await page.post("connect")).status, 200, how);
      const preview = (await page.post("preview", { kind: "selftest" })).json;
      const delays = (await fake.events("session_delay")).length;
      const pending = page.post("selftest", { expectedDigest: preview.snapshot.digest });
      await until(async () => (await fake.events("session_delay")).length > delays, { what: "开会话慢下来" });
      const startedAt = Date.now();
      const stop = await page.post(how, {});
      assert.equal(stop.status, 200, `${how} ${stop.text}`);
      if (how === "cancel") assert.ok(Date.now() - startedAt < 500, "停止没有被正在准备的发送挡住");
      const r = await pending;
      assert.equal(r.status, 409, `${how} ${r.text}`);
      const s = await page.status();
      assert.equal(s.task.outcome, "not_sent", how);
      assert.equal(await promptCount(fake), 0, how);
      assert.deepEqual(journalLines(env).filter((entry) => entry.taskId === s.task.id), [], `${how}：本机不留“已发出”`);
      assert.deepEqual(s.openTurns, [], how);
      if (how === "cancel") await page.post("disconnect");
    }
    // 准备发送时检查、改设置：挡住（409 正在发出），发送照常完成，设置没被改。
    assert.equal((await page.post("connect")).status, 200);
    const preview = (await page.post("preview", { kind: "selftest" })).json;
    const delays = (await fake.events("session_delay")).length;
    const pending = page.post("selftest", { expectedDigest: preview.snapshot.digest });
    await until(async () => (await fake.events("session_delay")).length > delays, { what: "开会话慢下来" });
    const checked = await page.post("check");
    assert.equal(checked.status, 409);
    assert.equal(checked.json.error.code, "acp_busy");
    const saved = await page.post("config", { expectedSha256: "0".repeat(64) });
    assert.equal(saved.status, 409);
    assert.equal(saved.json.error.code, "acp_busy");
    const r = await pending;
    assert.equal(r.status, 200, r.text);
    assert.equal((await page.finished(r.json.taskId)).task.outcome, "complete");
    assert.equal((await page.status()).settings.expectedSha256, null);
  } finally {
    await server.acpShutdown();
    server.close();
  }
});

await test("R550-5 发送准备里的几处等待：acp.json 在别处被改了（开会话的那一会儿）→ 发出前的核对发现，作废、没有发出、不留记录；作废落在写“已发出”的那一下 → 记成没有发出，不留成结果未知", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, sessionNewDelayMs: 500 } });
  const env = envFor(null);
  const provider = assist.createAcpProvider({ env, timeouts: FAST });
  providers.push(provider);
  // 保存设置的那一会儿别的操作插不进来。
  const saving = provider.saveConfig({ runtimePath: fake.path });
  await assert.rejects(provider.check(), (error) => error.code === "acp_busy" && /正在保存设置/.test(error.message));
  await saving;
  await provider.connect();
  const pending = provider.startPrompt({ kind: "selftest" }).then(() => null, (error) => error);
  await until(async () => (await fake.events("session_delay")).length > 0, { what: "开会话慢下来" });
  const configFile = join(env.NOVEL_WORKSHOP_CONFIG_DIR, "acp.json");
  const stored = JSON.parse(await readFile(configFile, "utf8"));
  await writeFile(configFile, JSON.stringify({ ...stored, expectedSha256: "1".repeat(64) }), "utf8");
  const error = await pending;
  assert.equal(error?.code, "acp_connection_revoked", error?.message);
  assert.match(error.message, /本机设置在连接以后变了/);
  let status = await provider.status();
  assert.deepEqual([status.task.outcome, status.connected, status.state], ["not_sent", false, "runtime_invalidated"]);
  assert.equal(await promptCount(fake), 0);
  assert.deepEqual(journalLines(env), [], "没有留下“已发出”");
  // 作废落在写“已发出”记录的那一下（比如那一刻有一次检查发现程序不对）。
  await writeFile(configFile, JSON.stringify(stored), "utf8");
  await fake.set({ cachedLogin: true });
  await provider.check();
  await provider.connect();
  const original = provider.journal.append.bind(provider.journal);
  provider.journal.append = async (entry) => {
    const record = await original(entry);
    if (entry.event === "sent") await provider.invalidateFor("check_failed", "测试：重新检查发现程序不对");
    return record;
  };
  const second = await provider.startPrompt({ kind: "selftest" }).then(() => null, (error) => error);
  provider.journal.append = original;
  assert.equal(second?.code, "acp_connection_revoked");
  assert.equal(await promptCount(fake), 0);
  status = await provider.status();
  assert.equal(status.task.outcome, "not_sent");
  assert.deepEqual(status.openTurns, []);
  const lines = journalLines(env).filter((entry) => entry.taskId === status.task.id);
  assert.deepEqual(lines.map((entry) => [entry.event, entry.outcome ?? null]), [["sent", null], ["finished", "not_sent"]]);
  // 发出前最后一刻的核对本身：连接只是被标成作废（还没来得及断开），或者收件方（这一次连接）对不上，都不发。
  for (const [what, tamper, code] of [
    ["只作废、还没断开", () => {
      provider.conn.revoked = { code: "test", reason: "测试：只作废、还没断开", at: new Date().toISOString() };
    }, "acp_connection_revoked"],
    ["收件方对不上", () => {
      provider.handshake = { ...provider.handshake, connectionId: "another-connection" };
    }, "acp_preview_changed"],
  ]) {
    await provider.disconnect();
    await provider.check();
    await provider.connect();
    provider.journal.append = async (entry) => {
      const record = await original(entry);
      if (entry.event === "sent") tamper();
      return record;
    };
    const error = await provider.startPrompt({ kind: "selftest" }).then(() => null, (failure) => failure);
    provider.journal.append = original;
    assert.equal(error?.code, code, what);
    assert.equal(await promptCount(fake), 0, what);
    assert.equal((await provider.status()).task.outcome, "not_sent", what);
  }
  await provider.shutdown();
});

await test("R550-6 已经发出的一轮，重新检查发现校验不符：按停止的老规矩了结（官方程序仍交回整段也只算不完整），留着收到的部分，不自动重发；迟到的结果不能把“已真实接通”找回来", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, ...OFFICIAL_LIKE, prompt: "cancel_endturn" } });
  const provider = await connected(fake, { env: verifiedEnv(fake) });
  const started = await provider.startPrompt({ kind: "selection", text: "一段。" });
  await until(async () => (await provider.status()).task.chars > 0, { what: "收到第一段" });
  await appendFile(fake.path, "# 被换掉了\n");
  const checked = await provider.check();
  assert.equal(checked.runtime.state, "checksum_mismatch");
  assert.equal(checked.canSend, false);
  const done = await provider.waitForTask(started.taskId);
  assert.equal(done.outcome, "cancel_race");
  assert.equal(done.partial, "停止前的字。——取消之后才写的后半段。");
  assert.equal(done.candidate, null);
  assert.equal((await fake.received("session/cancel")).length, 1);
  await until(async () => !(await provider.status()).connected, { what: "了结以后结束旧连接" });
  const status = await provider.status();
  assert.deepEqual([status.real, status.realCurrent, status.state], [null, false, "runtime_invalidated"]);
  assert.equal(await promptCount(fake), 1, "没有自动重发");
  await assert.rejects(provider.startPrompt({ kind: "selftest" }), (error) => error.code === "acp_connection_revoked");
});

await test("R550-7 重启写作台：以前的“已真实接通”只当历史，不当现在的状态；新的连接要再发一次才算；别的一次连接记下的标记（连接编号对不上）也一样", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, ...OFFICIAL_LIKE } });
  const env = envFor(fake, verifiedEnv(fake));
  const first = assist.createAcpProvider({ env, timeouts: FAST });
  providers.push(first);
  await first.connect();
  await send(first, { kind: "selftest" });
  assert.equal((await first.status()).realCurrent, true);
  await first.shutdown();
  const second = assist.createAcpProvider({ env, timeouts: FAST });
  providers.push(second);
  let status = await second.status();
  assert.ok(status.real);
  assert.equal(status.realCurrent, false);
  assert.equal(status.verification.reply.state, "earlier");
  await second.connect();
  status = await second.status();
  assert.equal(status.realCurrent, false);
  assert.equal(status.verification.reply.state, "earlier");
  await send(second, { kind: "selftest" });
  assert.equal((await second.status()).realCurrent, true);
  await second.disconnect();
  // 别的一次连接记下的标记（连接编号对不上），哪怕时间写在这次握手以后，也不算现在的。
  const file = join(env.NOVEL_WORKSHOP_CONFIG_DIR, "acp-status.json");
  const record = JSON.parse(await readFile(file, "utf8"));
  assert.ok(record.real.connectionId);
  await writeFile(file, JSON.stringify({ ...record, real: { ...record.real, connectionId: "an-earlier-connection", at: "2999-01-01T00:00:00.000Z" } }), "utf8");
  await second.connect();
  status = await second.status();
  assert.ok(status.real, "按新规矩记下的，留着当历史");
  assert.equal(status.realCurrent, false);
  await second.shutdown();
});

await test("R550-8 四件事分开看：程序来源、ACP 握手、官方登录、模型回复各自显示；来源没核对的自称 Antigravity 也只算协议结果；模拟程序标成模拟；程序文件的 SHA-256 和 Registry 登记的 zip 的分开写；账号、额度只写拿到的", async () => {
  // Registry 发行包：程序文件的校验值和 zip 的分开；把 zip 的填成核对值会说明那是压缩包的。
  const registry = await fakeRuntime({ name: "agy_acp_server", control: { cachedLogin: true } });
  const zip = rt.registryArchive(process.platform, process.arch);
  const provider = makeProvider(registry, { env: zip ? { NOVEL_WORKSHOP_ACP_SHA256: zip.sha256 } : {} });
  let status = await provider.check();
  const checksums = status.verification.source.checksums;
  assert.equal(checksums.binary, shaFile(registry.path));
  assert.match(checksums.binaryOf, /程序文件本身/);
  if (zip) {
    assert.equal(checksums.registryZip.sha256, zip.sha256);
    assert.notEqual(checksums.registryZip.sha256, checksums.binary);
    assert.match(checksums.registryZip.note, /压缩包/);
    assert.equal(status.verification.source.state, "mismatch");
    assert.match(status.runtime.message, /zip 压缩包的校验值/);
  }
  // 模拟程序：握手里标明了，状态、记录都标成模拟；没登录过、账号拿不到、额度读不到。
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  const sim = await connected(fake);
  status = await sim.status();
  assert.equal(status.simulated, true);
  assert.equal(status.verification.handshake.simulated, true);
  assert.match(status.verification.handshake.agentNote, /自己说的/);
  assert.equal(status.verification.source.state, "unverified");
  assert.equal(status.verification.login.account, null);
  assert.match(status.verification.login.accountNote, /拿不到/);
  await send(sim, { kind: "selftest" });
  status = await sim.status();
  assert.equal(status.verification.reply.state, "simulated");
  assert.equal(status.verification.reply.quota.state, "unknown");
  assert.match(status.verification.reply.quota.label, /读不到余额/);
  assert.equal(status.verification.reply.requestedModel.value, "gemini-fake-pro");
  const record = JSON.parse(await readFile(join(sim.env.NOVEL_WORKSHOP_CONFIG_DIR, "acp-status.json"), "utf8"));
  assert.equal(record.lastSimulated.simulated, true);
  assert.equal(record.lastSimulated.countsAs, "simulated");
  assert.equal(record.real, undefined);
  const preview = await sim.preview({ kind: "selftest" });
  assert.deepEqual([preview.snapshot.binding.runtime.simulated, preview.snapshot.binding.runtime.source], [true, "unverified"]);
  await sim.shutdown();
  // 自称 Antigravity、来源也核对过，但在握手里标明了自己是模拟程序：仍然只算模拟。
  const marked = await fakeRuntime({ control: { cachedLogin: true, agentInfo: LIKE_ANTIGRAVITY } });
  const markedProvider = await connected(marked, { env: verifiedEnv(marked) });
  await send(markedProvider, { kind: "selftest" });
  status = await markedProvider.status();
  assert.deepEqual([status.real, status.verification.source.state, status.verification.reply.state], [null, "verified", "simulated"]);
  assert.ok(status.lastSimulated.why.some((why) => /模拟程序/.test(why)));
  await markedProvider.shutdown();
  // 自称 Antigravity、不标模拟、来源没核对：只算协议结果。
  const lookalike = await fakeRuntime({ control: { cachedLogin: true, ...OFFICIAL_LIKE } });
  const plain = await connected(lookalike);
  await send(plain, { kind: "selftest" });
  status = await plain.status();
  assert.deepEqual([status.real, status.verification.reply.state, status.verification.login.state], [null, "protocol_only", "implicit"]);
  await plain.shutdown();
  const app = await readFile(join(skill, "assets", "dashboard", "app.js"), "utf8");
  for (const needle of ["function renderAcpVerification(status)", "elements.acpSelftest.disabled = busy || active || !connected || !canSend;", "elements.acpSendSelection.disabled = busy || active || !connected || !canSend || !selectionReady;", "!state.acp.status?.canSend"]) {
    assert.ok(app.includes(needle), needle);
  }
  const html = await readFile(join(skill, "assets", "dashboard", "index.html"), "utf8");
  assert.ok(html.includes('id="acpVerification"'));
});

await test("R550-9 check-acp 报告：模拟程序处处标模拟；来源没核对只算协议结果；四件事分开列；Registry 发行包写明 zip 的校验值是压缩包的", async () => {
  const quiet = () => {};
  const fake = await fakeRuntime({ control: { cachedLogin: true } });
  let result = await check.runAcpCheck({ argv: ["--runtime", fake.path, "--try"], env: envFor(null), print: quiet, timeouts: FAST });
  let report = await readFile(result.report, "utf8");
  for (const pattern of [/［模拟］这是工坊自己的模拟程序/, /结论（模拟）/, /五、四件事分开看/, /程序来源：来源未核对/, /模型回复：［模拟］/, /官方登录：.*拿不到是哪个 Google 账号/, /额度：工坊读不到余额/, /程序文件的 SHA-256/]) {
    assert.match(report, pattern);
  }
  // 每一种结论都带“模拟”：只握手、合成示例没拿回完整回复。
  result = await check.runAcpCheck({ argv: ["--runtime", fake.path], env: envFor(null), print: quiet, timeouts: FAST });
  assert.match(result.lines.at(-1), /^结论（模拟）：握手成功/);
  assert.ok(result.lines.some((line) => /^  官方登录：.*（模拟程序）$/.test(line)), result.lines.join("\n"));
  const failing = await fakeRuntime({ control: { cachedLogin: true, prompt: "error" } });
  result = await check.runAcpCheck({ argv: ["--runtime", failing.path, "--try"], env: envFor(null), print: quiet, timeouts: FAST });
  assert.match(result.lines.at(-1), /^结论（模拟）：握手成功，但合成示例没有拿回完整回复/);
  const lookalike = await fakeRuntime({ control: { cachedLogin: true, ...OFFICIAL_LIKE } });
  result = await check.runAcpCheck({ argv: ["--runtime", lookalike.path, "--try"], env: envFor(null), print: quiet, timeouts: FAST });
  report = await readFile(result.report, "utf8");
  assert.match(report, /结论：只算协议结果/);
  assert.doesNotMatch(report, /结论：真实接通/);
  result = await check.runAcpCheck({ argv: ["--runtime", lookalike.path, "--sha256", shaFile(lookalike.path), "--try"], env: envFor(null), print: quiet, timeouts: FAST });
  assert.match(await readFile(result.report, "utf8"), /结论：真实接通/);
  const registry = await fakeRuntime({ name: "agy_acp_server", control: { cachedLogin: true } });
  result = await check.runAcpCheck({ argv: ["--runtime", registry.path], env: envFor(null), print: quiet, timeouts: FAST });
  if (rt.registryArchive(process.platform, process.arch)) assert.match(await readFile(result.report, "utf8"), /发行包 zip 的 SHA-256 是 [0-9a-f]{64}：那是压缩包的，不是上面这个程序文件的/);
});

await test("R550-10 旧版本（r5.49）按“自称 Antigravity”记下的“已真实接通”（没有核对来源、没有连接编号）：只当历史“以前接通过（旧规则，来源未核对）”，查、连、断开都不当现在的，也不当核对过", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, ...OFFICIAL_LIKE } });
  const env = envFor(fake);
  await mkdir(env.NOVEL_WORKSHOP_CONFIG_DIR, { recursive: true });
  const at = "2026-11-06T10:37:18.000Z";
  // 照 r5.49 记下的样子：自称 Antigravity，同一个程序、同一个 SHA-256，没有 sourceVerified、没有 connectionId。
  const legacy = { at, taskKind: "selftest", runtimePath: fake.path, runtimeKind: "agy-cli", runtimeVersion: null, runtimeSha256: shaFile(fake.path), agentInfo: LIKE_ANTIGRAVITY, protocolVersion: 1, stopReason: "end_turn", chars: 30 };
  await writeFile(join(env.NOVEL_WORKSHOP_CONFIG_DIR, "acp-status.json"), JSON.stringify({ format: "novel-workshop-acp/1", real: legacy }), "utf8");
  const provider = assist.createAcpProvider({ env, timeouts: FAST });
  providers.push(provider);
  const look = (status, step) => {
    assert.equal(status.real, null, step);
    assert.equal(status.realCurrent, false, step);
    assert.equal(status.legacyReal?.at, at, step);
    assert.equal(status.verification.reply.state, "earlier_legacy", step);
    assert.match(status.verification.reply.label, /以前接通过（旧规则，来源未核对/, step);
    assert.notEqual(status.verification.source.state, "verified", step);
  };
  look(await provider.status(), "读状态");
  look(await provider.check(), "检查");
  look(await provider.connect(), "连接");
  look(await provider.disconnect(), "断开");
  await provider.shutdown();
  const app = await readFile(join(skill, "assets", "dashboard", "app.js"), "utf8");
  assert.ok(app.includes("以前接通过（旧规则，来源未核对"));
  const cli = await check.runAcpCheck({ argv: [], env, print: () => {}, timeouts: FAST });
  assert.ok(cli.lines.some((line) => line.includes("模型回复：以前接通过（旧规则，来源未核对")), cli.lines.join("\n"));
});

await test("R550-11 已经发出的一轮还在等停下（官方程序不确认停止）的时候，重新检查发现校验不符：程序来源一栏马上跟着最新的检查（校验不符），不再说来源已核对", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, ...OFFICIAL_LIKE, prompt: "cancel_ignore" } });
  const provider = await connected(fake, { env: verifiedEnv(fake), timeouts: { cancelWaitMs: 4000, promptIdleMs: 10000 } });
  const started = await provider.startPrompt({ kind: "selftest" });
  await until(async () => (await provider.status()).task.chars > 0, { what: "收到第一段" });
  assert.equal((await provider.status()).verification.source.state, "verified");
  await appendFile(fake.path, "# 被换掉了\n");
  const checked = await provider.check();
  assert.equal(checked.connected, true, "还在等官方程序确认停下");
  assert.deepEqual([checked.canSend, checked.state, checked.runtime.sourceVerified], [false, "runtime_invalidated", false]);
  assert.equal(checked.verification.source.state, "mismatch");
  await provider.disconnect();
  await provider.waitForTask(started.taskId);
});

await test("R550-12 Windows 的 .cmd 启动脚本（在 Linux 上按 win32 规则走，没有在真实 Windows 上跑过）：校验值只算了启动脚本，对得上也不算来源已核对，说清楚；不会记成已真实接通", async () => {
  counter += 1;
  const profile = join(base, `winprofile-${counter}`);
  const dir = join(profile, "AppData", "Local", "agy");
  await mkdir(dir, { recursive: true });
  const shim = join(dir, "agy.cmd");
  await writeFile(shim, "@echo off\r\nagy.exe %*\r\n", "utf8");
  const env = { ...envFor(null), USERPROFILE: profile, LOCALAPPDATA: join(profile, "AppData", "Local"), NOVEL_WORKSHOP_ACP_RUNTIME: shim, NOVEL_WORKSHOP_ACP_SHA256: shaFile(shim) };
  const provider = assist.createAcpProvider({ env, platform: "win32", timeouts: FAST });
  providers.push(provider);
  const status = await provider.check();
  assert.equal(status.runtime.state, "launchable", status.runtime.message);
  assert.deepEqual([status.runtime.hashOf, status.runtime.checksum.match, status.runtime.sourceVerified], ["windows-shim", true, false]);
  assert.equal(status.verification.source.state, "unverified");
  assert.match(status.verification.source.label, /启动脚本/);
  assert.match(status.verification.source.checksums.binaryOf, /启动脚本/);
  // 记“已真实接通”用的也是这一条判断。
  assert.equal(assist.isSourceVerified({ state: "launchable", checksum: { match: true }, hashOf: "windows-shim" }), false);
  assert.equal(assist.isSourceVerified({ state: "launchable", checksum: { match: true }, hashOf: "file" }), true);
  const app = await readFile(join(skill, "assets", "dashboard", "app.js"), "utf8");
  assert.ok(app.includes("对得上也只核对了启动脚本，来源仍算未核对"));
});

await test("R550-13 模拟程序的每一轮都标着模拟（不只是拿回完整回复的）：中途崩溃的那一轮在“结果未知”清单、本机记录、事件记录里都标着，也不说可能用了 Google 的额度；重启以后照样", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, prompt: "crash" } });
  const provider = await connected(fake);
  const done = await send(provider, { kind: "selftest" });
  assert.deepEqual([done.outcome, done.simulated], ["unknown", true]);
  let status = await provider.status();
  assert.equal(status.state, "result_unknown");
  assert.equal(status.openTurns[0].simulated, true);
  assert.match(status.message, /［模拟］/);
  assert.doesNotMatch(status.message, /Google 处理/);
  const record = JSON.parse(await readFile(join(provider.env.NOVEL_WORKSHOP_CONFIG_DIR, "acp-status.json"), "utf8"));
  assert.equal(record.lastTask.simulated, true);
  assert.equal(journalLines(provider.env).find((entry) => entry.event === "sent").simulated, true);
  await provider.shutdown();
  const again = assist.createAcpProvider({ env: provider.env, timeouts: FAST });
  providers.push(again);
  status = await again.status();
  assert.equal(status.openTurns[0].simulated, true);
  assert.doesNotMatch(status.message, /Google 处理/);
  // 不标模拟的程序：照旧提醒可能已经用了额度。
  const lookalike = await fakeRuntime({ control: { cachedLogin: true, ...OFFICIAL_LIKE, prompt: "crash" } });
  const other = await connected(lookalike);
  await send(other, { kind: "selftest" });
  status = await other.status();
  assert.equal(status.openTurns[0].simulated, false);
  assert.match(status.message, /可能已经被 Google 处理/);
  await other.shutdown();
  const app = await readFile(join(skill, "assets", "dashboard", "app.js"), "utf8");
  for (const needle of ['${turn.simulated ? "［模拟］" : ""}', '(task.simulated ? "［模拟］" : "")', 'v.handshake.simulated ? "（模拟程序）" : ""']) assert.ok(app.includes(needle), needle);
});

await test("R550-14 “已真实接通”记下了当时的设置：在写作台外面加了开关、或者去掉了核对的校验值，下次“检查运行时”就清掉，不再显示以前真实接通过", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, ...OFFICIAL_LIKE } });
  const env = envFor(null);
  const configFile = join(env.NOVEL_WORKSHOP_CONFIG_DIR, "acp.json");
  const first = assist.createAcpProvider({ env, timeouts: FAST });
  providers.push(first);
  await first.saveConfig({ runtimePath: fake.path, expectedSha256: shaFile(fake.path) });
  await first.connect();
  await send(first, { kind: "selftest" });
  let status = await first.status();
  assert.equal(status.realCurrent, true);
  assert.deepEqual(status.real.launchConfig.flags, []);
  await first.shutdown();
  for (const [what, edit] of [
    ["加了开关", (stored) => ({ ...stored, flags: ["--sandbox"] })],
    ["去掉了核对的校验值", (stored) => {
      const { expectedSha256, ...rest } = stored;
      return rest;
    }],
  ]) {
    const stored = JSON.parse(await readFile(configFile, "utf8"));
    await writeFile(configFile, JSON.stringify(edit(stored)), "utf8");
    const next = assist.createAcpProvider({ env, timeouts: FAST });
    providers.push(next);
    status = await next.check();
    assert.equal(status.real, null, what);
    assert.match(status.realCleared.reason, /开关、核对的校验值|来源没有核对/, what);
    assert.notEqual(status.verification.reply.state, "earlier", what);
    // 恢复成核对过的、没有开关的设置，再记一次“已真实接通”，给下一种情形用。
    await writeFile(configFile, JSON.stringify({ ...stored, flags: undefined, expectedSha256: shaFile(fake.path) }), "utf8");
    await next.check();
    await next.connect();
    await send(next, { kind: "selftest" });
    assert.equal((await next.status()).realCurrent, true, what);
    await next.shutdown();
  }
});

await test("R550-15 acp.json 在写“已发出”记录的那一下被别处改了（换了核对的校验值）：写完以后再读一次设置，发现了，不发 session/prompt，记成没有发出，旧连接作废，不记已真实接通", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, ...OFFICIAL_LIKE } });
  const env = envFor(null);
  const provider = assist.createAcpProvider({ env, timeouts: FAST });
  providers.push(provider);
  await provider.saveConfig({ runtimePath: fake.path, expectedSha256: shaFile(fake.path) });
  await provider.connect();
  const configFile = join(env.NOVEL_WORKSHOP_CONFIG_DIR, "acp.json");
  const original = provider.journal.append.bind(provider.journal);
  provider.journal.append = async (entry) => {
    const record = await original(entry);
    if (entry.event === "sent") {
      const stored = JSON.parse(await readFile(configFile, "utf8"));
      await writeFile(configFile, JSON.stringify({ ...stored, expectedSha256: "2".repeat(64) }), "utf8");
    }
    return record;
  };
  const error = await provider.startPrompt({ kind: "selftest" }).then(() => null, (failure) => failure);
  provider.journal.append = original;
  assert.equal(error?.code, "acp_connection_revoked", error?.message);
  assert.match(error.message, /本机设置在连接以后变了/);
  assert.equal(await promptCount(fake), 0);
  const status = await provider.status();
  assert.deepEqual([status.task.outcome, status.connected, status.real, status.realCurrent, status.state], ["not_sent", false, null, false, "runtime_invalidated"]);
  assert.deepEqual(journalLines(env).filter((entry) => entry.taskId === status.task.id).map((entry) => [entry.event, entry.outcome ?? null]), [["sent", null], ["finished", "not_sent"]]);
  assert.deepEqual(status.openTurns, []);
  await provider.shutdown();
});

await test("R550-16 HTTP：acp.json 在写作台外面被改了（换了核对的校验值，或者换了路径）：读状态就报不能发、不算现在接通、来源不说已核对，预览没有收件方；页面照着显示的值保存也会作废旧连接；session/prompt 一次也没多", async () => {
  const fake = await fakeRuntime({ control: { cachedLogin: true, ...OFFICIAL_LIKE } });
  const root = await makeWorkspace();
  const env = envFor(null);
  const configFile = join(env.NOVEL_WORKSHOP_CONFIG_DIR, "acp.json");
  const server = createDashboardServer({ root, allowEdit: true, acp: { env, timeouts: FAST } });
  try {
    const page = await pageClient(server);
    const good = shaFile(fake.path);
    await page.post("config", { runtimePath: fake.path, expectedSha256: good });
    await page.post("connect");
    await page.post("models");
    const preview = (await page.post("preview", { kind: "selftest" })).json;
    let r = await page.post("selftest", { expectedDigest: preview.snapshot.digest });
    let s = await page.finished(r.json.taskId);
    assert.equal(s.realCurrent, true);
    const before = await promptCount(fake);
    for (const [what, edit] of [
      ["换了核对的校验值", (stored) => ({ ...stored, expectedSha256: "1".repeat(64) })],
      ["换了路径", (stored) => ({ ...stored, runtimePath: join(base, "nonexistent", "agy") })],
    ]) {
      const stored = JSON.parse(await readFile(configFile, "utf8"));
      await writeFile(configFile, JSON.stringify(edit(stored)), "utf8");
      s = await page.status();
      assert.deepEqual([s.connected, s.canSend, s.realCurrent], [true, false, false], what);
      assert.match(s.sendBlock, /本机设置在连接以后变了/, what);
      assert.equal(s.verification.source.state, "stale", what);
      assert.notEqual(s.verification.reply.state, "real", what);
      const stale = (await page.post("preview", { kind: "selftest" })).json;
      assert.equal(stale.snapshot.binding.runtime, null, what);
      r = await page.post("selftest", { expectedDigest: preview.snapshot.digest });
      assert.equal(r.status, 409, what);
      // 页面照着显示的值保存（显示的是外面改过以后的值）：和连接时的比，变了，作废。
      r = await page.post("config", { runtimePath: s.settings.runtimePath, expectedSha256: s.settings.expectedSha256 });
      assert.deepEqual([r.json.connected, r.json.canSend, r.json.state], [false, false, "runtime_invalidated"], what);
      assert.equal(r.json.verification.source.state, "not_checked", what);
      assert.equal(await promptCount(fake) - before, 0, what);
      // 改回来，重新检查、连接，给下一种情形用。
      await page.post("config", { runtimePath: fake.path, expectedSha256: good });
      assert.equal((await page.post("check")).json.runtime.state, "launchable", what);
      assert.equal((await page.post("connect")).status, 200, what);
    }
    // 没连着的时候在外面改了：上一次“检查运行时”是按旧设置查的，来源不再说已核对，要重新检查。
    await page.post("disconnect");
    assert.equal((await page.post("check")).json.verification.source.state, "verified");
    const stored = JSON.parse(await readFile(configFile, "utf8"));
    await writeFile(configFile, JSON.stringify({ ...stored, expectedSha256: "3".repeat(64) }), "utf8");
    s = await page.status();
    assert.equal(s.verification.source.state, "not_checked");
    assert.match(s.verification.source.label, /设置在上次检查以后变了/);
  } finally {
    await server.acpShutdown();
    server.close();
  }
});

await test("REG-3 进程号复用（Linux，读 /proc）：锁里记的进程号被一个后来才启动的程序用上了，算作废、能接手；看不到 /proc 的机器上跳过这一条（锁的其他判断照常查）", async () => {
  const dir = join(base, "locks-pid");
  await mkdir(dir, { recursive: true });
  const path = join(dir, "acp.lock");
  const sleeper = spawn(process.execPath, ["-e", "setInterval(() => {}, 1000)"], { stdio: "ignore" });
  try {
    const spawnedAt = Date.now();
    // 先直接看 /proc 在不在（不靠被测的函数）：真的看不到才跳过；看得到而被测的函数读不出来，就是失败。
    const hidden = process.env.NOVEL_WORKSHOP_TEST_HIDE_PROC === "1";
    const procRoot = hidden ? join(base, "no-proc-here") : "/proc";
    let missing = null;
    const end = Date.now() + 2000;
    for (;;) {
      try {
        readFileSync(`${procRoot}/${sleeper.pid}/stat`, "utf8");
        if (!/^btime\s+\d+/m.test(readFileSync(`${procRoot}/stat`, "utf8"))) throw Object.assign(new Error("没有 btime"), { code: "NO_BTIME" });
        missing = null;
        break;
      } catch (error) {
        missing = error;
        if (Date.now() > end) break;
        await wait(50);
      }
    }
    if (missing) {
      const simulated = hidden ? "（这一次是用 NOVEL_WORKSHOP_TEST_HIDE_PROC=1 模拟的）" : "";
      skip(`看不到 /proc/${sleeper.pid}/stat 或 /proc/stat（${missing.code || missing.message}）${simulated}：不是 Linux，或者 /proc 看不到别的进程，查不了进程号复用；锁照样按开机时间和两分钟没续上判断，那几条在“锁”那一项里照常查`);
    }
    const seen = store.linuxProcessStartMs(sleeper.pid);
    if (seen === null) assert.fail("/proc 读得到，linuxProcessStartMs 却读不出进程的启动时间");
    assert.ok(Math.abs(seen - spawnedAt) < 5000, `读出来的启动时间不对：差了 ${seen - spawnedAt} 毫秒`);
    if (store.bootTimeMs() > Date.now() - 40_000) skip("开机不到 40 秒，造不出“锁比进程早”的情形");
    await writeFile(path, JSON.stringify({ tool: "写作台", pid: sleeper.pid, token: "reused-pid", startedAt: new Date(Date.now() - 30_000).toISOString() }), "utf8");
    assert.equal(store.staleReason(JSON.parse(await readFile(path, "utf8")), await stat(path)), "这个进程号已经被别的程序用上了");
    const lock = new store.InstanceLock(path);
    assert.equal((await lock.acquire("测试")).ok, true);
    lock.releaseSync();
  } finally {
    sleeper.kill("SIGKILL");
  }
});

for (const provider of providers) await provider.shutdown().catch(() => {});
gemini.close();
await rm(base, { recursive: true, force: true });
for (const [status, name, detail] of results) console.log(`${status} ${name}${detail ? `\n${detail}` : ""}`);
const failed = results.filter(([status]) => status === "FAIL").length;
const skipped = results.filter(([status]) => status === "SKIP").length;
console.log(`${results.length - failed - skipped} passed, ${skipped} skipped, ${failed} failed (${results.length} total)`);
process.exit(failed ? 1 : 0);

#!/usr/bin/env python3
"""Install the selected skill folders without overwriting existing content.

A different installed version is never replaced silently. With --upgrade the
installed version is first moved, intact, into <dest>/.novel-workshop-backups/
<time>/ and only then replaced. To roll back to a package that also has
--upgrade (this release or later), run that package's install.py with --upgrade;
the newer version is backed up the same way. Older packages (r4.3 and earlier)
have no --upgrade: move the two installed skill folders out of <dest> first, or
move the backed-up folders back from the backup folder.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import sys
import tempfile
import time


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


CACHE_DIRS = {'__pycache__', '.pytest_cache'}


def is_cache(path, root):
    # Running the bundled scripts may leave interpreter caches; they are never package content.
    return bool(CACHE_DIRS.intersection(path.relative_to(root).parts)) or path.suffix in ('.pyc', '.pyo')


def regular_files(root):
    result = {}
    for path in root.rglob('*'):
        if is_cache(path, root):
            continue
        if path.is_symlink():
            raise ValueError('Symbolic links are not supported: ' + str(path))
        if path.is_file():
            result[path.relative_to(root).as_posix()] = sha256(path)
    return result


def validate_package(root):
    manifest = json.loads((root / 'PACKAGE-MANIFEST.json').read_text(encoding='utf-8'))
    if manifest.get('schema_version') != 1:
        raise ValueError('Unsupported package manifest.')
    for relative, expected in manifest['files'].items():
        parts = PurePosixPath(relative)
        if parts.is_absolute() or '..' in parts.parts or '\\' in relative or ':' in relative:
            raise ValueError('Unsafe manifest path: ' + relative)
        path = root / relative
        if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
            raise ValueError('Unsafe package file: ' + relative)
        if not path.is_file() or sha256(path) != expected:
            raise ValueError('Package file is missing or changed: ' + relative)
    return manifest


BACKUPS = '.novel-workshop-backups'


def install(root, destination, include_dev=False, dry_run=False, upgrade=False):
    manifest = validate_package(root)
    destination = destination.expanduser().absolute()
    # Refuse a redirected target rather than following a link into another folder.
    for parent in [destination, *destination.parents]:
        if parent.is_symlink() or (hasattr(parent, 'is_junction') and parent.is_junction()):
            raise ValueError('Linked destination is not supported: ' + str(parent))
    selected = ['novel-workshop', 'darwin-novel-workshop']
    if include_dev:
        selected.append('typesafe-ai')
    plan = []
    for name in selected:
        relative = manifest['components'][name]['path']
        source = root / relative
        if not source.is_dir() or source.is_symlink():
            raise ValueError('Invalid source directory: ' + name)
        expected = {p[len(relative) + 1:]: h for p, h in manifest['files'].items() if p.startswith(relative + '/')}
        if regular_files(source) != expected:
            raise ValueError('Unexpected or missing files in skill: ' + name)
        target = destination / name
        if target.exists():
            if not target.is_dir() or target.is_symlink():
                raise ValueError('Existing path is not a plain skill folder; nothing installed: ' + str(target))
            if regular_files(target) == expected:
                action = 'unchanged'
            elif upgrade:
                action = 'upgrade'
            else:
                raise ValueError('Existing skill differs; nothing installed. Run again with --upgrade to back up the installed '
                                 'version and replace it, or choose --dest: ' + str(target))
        else:
            action = 'install'
        plan.append({'name': name, 'source': source, 'target': target, 'expected': expected, 'action': action})
    report = {'dry_run': dry_run, 'destination': str(destination), 'skills': [{'name': p['name'], 'action': p['action']} for p in plan]}
    if dry_run or all(p['action'] == 'unchanged' for p in plan):
        return report
    backup = None
    if any(p['action'] == 'upgrade' for p in plan):
        stamp = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())
        backup, n = destination / BACKUPS / stamp, 1
        while backup.exists():
            n += 1
            backup = destination / BACKUPS / ('%s-%d' % (stamp, n))
        report['backup'] = str(backup)
    destination.mkdir(parents=True, exist_ok=True)
    lock = destination / '.novel-workshop-install.lock'
    lock.mkdir()  # A second copy of this installer must finish before proceeding.
    try:
        with tempfile.TemporaryDirectory(prefix='.novel-workshop-stage-', dir=destination) as tmp:
            temporary = Path(tmp)
            assert temporary.resolve().is_relative_to(destination.resolve())
            for p in plan:
                if p['action'] in ('install', 'upgrade'):
                    staged = temporary / p['name']
                    shutil.copytree(p['source'], staged, ignore=shutil.ignore_patterns(*CACHE_DIRS, '*.pyc', '*.pyo'))
                    if regular_files(staged) != p['expected']:
                        raise ValueError('Staging verification failed: ' + p['name'])
            moved = []   # upgrades whose installed version is already in the backup folder
            placed = []  # folders this run has put in place (new installs and upgrades)
            try:
                for p in plan:
                    if p['action'] == 'upgrade':
                        # Keep the installed version intact before anything replaces it.
                        before = regular_files(p['target'])
                        backup.mkdir(parents=True, exist_ok=True)
                        os.rename(p['target'], backup / p['name'])
                        moved.append(p)
                        if regular_files(backup / p['name']) != before:
                            raise ValueError('Backup verification failed: ' + str(backup / p['name']))
                    if p['action'] in ('install', 'upgrade'):
                        if p['target'].exists():
                            raise ValueError('Destination changed while installing: ' + str(p['target']))
                        os.rename(temporary / p['name'], p['target'])
                        placed.append(p)
                for p in plan:
                    if regular_files(p['target']) != p['expected']:
                        raise ValueError('Installed content verification failed: ' + p['name'])
            except Exception as error:
                # Undo this run: remove only what it placed, then put every backed-up version back.
                # Never leave a mix of old and new skills, and never delete a folder this run did not create.
                for p in placed:
                    if p['target'].exists():
                        shutil.rmtree(p['target'])
                kept = []
                for p in moved:
                    if p['target'].exists():
                        kept.append(str(backup / p['name']))  # someone else created it meanwhile
                    else:
                        os.rename(backup / p['name'], p['target'])
                if kept:
                    raise ValueError(str(error) + '; the previously installed version is kept at: ' + ', '.join(kept)) from error
                raise
    finally:
        lock.rmdir()
    return report


def utf8_stdio():
    """Messages are UTF-8 on every platform; a Windows pipe would otherwise use the local code page."""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(encoding='utf-8')


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dest', type=Path, default=Path.home() / '.codex' / 'skills')
    parser.add_argument('--include-dev', action='store_true', help='Also install the optional TypeSafe developer skill.')
    parser.add_argument('--dry-run', action='store_true', help='Validate and show changes without writing anything.')
    parser.add_argument('--upgrade', action='store_true',
                        help='Replace a different installed version after moving it into ' + BACKUPS + '/<time>/.')
    args = parser.parse_args()
    try:
        result = install(Path(__file__).resolve().parent, args.dest, args.include_dev, args.dry_run, args.upgrade)
    except (OSError, ValueError, KeyError) as error:
        print('Installation stopped: ' + str(error), file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

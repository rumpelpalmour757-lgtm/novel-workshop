#!/usr/bin/env python3
"""r5.53: dialogue that reads like people talking. The author's feedback of 11-07: "对白就是人物的对白，就有点不像人，就是不是
正常人与人之间的对话".

The rule side: dialogue-craft.md gets a section on what people say at a given moment (danger, just after, at home), a
step on whether the listener accepts an answer, and a bullet on fake speech (telegraph lines, made-up phrases); drafting.md
says to read three sections of it before drafting such scenes; the style card's sentence lengths cover narration only.
The script side: dialogue_lines.py asks both ways about a long line and lists the lines exchange by exchange
(--exchanges), with no count and no verdict. These tests check that the rules are there and the scripts do what the
documents say. They do not show the dialogue reads better: that is for the author to judge.

Every passage below is newly written for this test.
"""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
LINES = SKILL / "scripts" / "dialogue_lines.py"
CARDS = SKILL / "scripts" / "style_cards.py"
LIBRARY = SKILL / "assets" / "style-cards" / "cards.json"


def read(rel):
    return (SKILL / rel).read_text(encoding="utf-8")


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(script, *args):
    proc = subprocess.run([sys.executable, "-I", "-B", str(script), *map(str, args)], capture_output=True, text=True,
                          encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


PASSAGE = ("雨停了。码头的灯一盏盏亮了。\n\n"
           "阿青把缆绳扔上岸：“几点走？”\n\n"
           "“六点。”老许说。\n\n"
           "“那我先回去睡一觉，你别等我吃饭了，锅里还有半碗面，热一热就能吃，别又凉着吃坏了肚子。”\n\n"
           "老许没应。他蹲下去，把缆绳在桩子上绕了三圈，又绕了一圈，拿脚踩了踩，看它吃不吃劲。风从河面上过来，"
           "带着一股柴油味，对岸的货场还亮着两盏灯，有人在那边喊着什么，听不清。\n\n"
           "“走吧。”\n")
LAST = "风从河面上过来，带着一股柴油味，对岸的货场还亮着两盏灯，有人在那边喊着什么，听不清。"


class LongLineNote(unittest.TestCase):
    def test_a_long_line_is_asked_both_ways(self):
        # r5.54 replaced this note and lists long lines only when asked (long_lines=True, --long-lines): it was
        # “看这是不是他此刻会说的长短、是不是在给读者讲设定；长不等于有毛病（r5.53）”
        report = load(LINES, "dialogue_lines_r553").inspect(PASSAGE, names=("阿青", "老许"), long_lines=True)
        long = [f for x in report["flagged"] for f in x["flags"] if f["kind"] == "long"]
        self.assertEqual(len(long), 1)
        self.assertIn("只列位置；有的人说话本来就长", long[0]["note"])
        self.assertIn("长不是毛病", long[0]["note"])
        self.assertNotIn("急不急", long[0]["note"])  # the old wording only asked whether he is in a hurry


class Exchanges(unittest.TestCase):
    def setUp(self):
        self.mod = load(LINES, "dialogue_lines_r553_x")
        self.report = self.mod.inspect(PASSAGE, names=("阿青", "老许"))
        self.every = sorted([x for v in self.report["speakers"].values() for x in v] + self.report["unattributed"],
                            key=lambda x: x["line"])

    def test_the_narration_right_before_each_line(self):
        self.assertEqual([(x["text"], x["before"]) for x in self.every], [
            ("“几点走？”", "阿青把缆绳扔上岸："),
            ("“六点。”", ""),  # straight after the line before
            (self.every[2]["text"], ""),  # 老许说。 is the tag of the line before: not shown as what comes before this one
            ("“走吧。”", "…" + LAST[-40:]),  # the last sentence of the paragraph before, cut to 40 characters
        ])
        self.assertGreater(len(LAST), 40)
        self.assertEqual([x["order"] for x in self.every], [0, 1, 2, 3])

    def test_lines_of_one_paragraph_keep_their_order(self):
        # the order in the text, not the order of the words: 走吧 / 别等了 / 再等一刻钟 sorts the other way round
        text = "阿青蹲在货架边上数箱子。“走吧。”老许说，“别等了。”阿青没动。“再等一刻钟。”\n"
        for mode in ("blank", "line"):
            report = self.mod.inspect(text, paragraph_mode=mode, names=("阿青", "老许"))
            view = self.mod.exchanges_report(report)
            said = [l.split("）")[-1].strip() if "）" in l else l.split("  ")[-1] for l in view if l.startswith("  第 ")]
            self.assertEqual(said, ["“走吧。”", "“别等了。”", "“再等一刻钟。”"], mode)
            self.assertIn("  第 1 行  （前文：阿青没动。）“再等一刻钟。”", view)
            self.assertIn("  第 1 行  “别等了。”", view)  # 老许说， is a tag, not what comes before

    def test_one_line_per_paragraph_and_runs_of_end_marks(self):
        # no blank lines between paragraphs, read in the default mode; narration ending in ……, ？！, 。）
        text = "老许推开门。\n“几点走？”\n“六点。”老许说。他蹲下去看缆绳。\n“行。”\n"
        every = sorted([x for v in self.mod.inspect(text, names=("老许",))["speakers"].values() for x in v]
                       + self.mod.inspect(text, names=("老许",))["unattributed"], key=lambda x: x["order"])
        self.assertEqual([(x["text"], x["before"]) for x in every],
                         [("“几点走？”", "老许推开门。"), ("“六点。”", ""), ("“行。”", "他蹲下去看缆绳。")])
        for x in every:
            self.assertNotIn("\n", x["before"])
        self.assertEqual(self.mod.tail_sentence("老许没有说下去……"), "老许没有说下去……")
        self.assertEqual(self.mod.tail_sentence("他愣住。她到底想干什么？！"), "她到底想干什么？！")
        self.assertEqual(self.mod.tail_sentence("墙上写着：（生死自负。）"), "墙上写着：（生死自负。）")
        self.assertEqual(self.mod.tail_sentence("【任务已完成。】"), "【任务已完成。】")
        self.assertEqual(self.mod.tail_sentence("。"), "")  # marks only: nothing to show

    def test_what_happened_is_kept_and_a_tag_is_not(self):
        def view(text):
            report = self.mod.inspect(text, names=("阿青", "老许"))
            return [l.strip() for l in self.mod.exchanges_report(report) if l.startswith("  第 ")]

        # 老许没应。 is what happened after the question; 老许说； is a tag, the clause after the semicolon is not
        self.assertEqual(view("“几点走？”老许没应。\n\n“问你呢。”\n")[1], "第 3 行  （前文：老许没应。）“问你呢。”")
        self.assertEqual(view("“走。”老许说；阿青没接话。\n\n“行不行？”\n")[1], "第 3 行  （前文：阿青没接话。）“行不行？”")
        self.assertEqual(view("“走。”老许说。\n\n“行不行？”\n")[1], "第 3 行  “行不行？”")
        # Windows line ends: no stray carriage return in what is shown
        crlf = view("老许推开门。\r\n“几点走？”\r\n“六点。”\r\n")
        self.assertEqual(crlf, ["第 2 行  （前文：老许推开门。）“几点走？”", "第 3 行  “六点。”"])

    def test_the_view_lists_in_order_and_judges_nothing(self):
        with tempfile.TemporaryDirectory() as tmp:
            chapter = Path(tmp) / "ch.md"
            chapter.write_bytes(PASSAGE.encode("utf-8"))
            code, out, err = run(LINES, chapter, "--names", "阿青,老许", "--exchanges")
            self.assertEqual(code, 0, err)
            view = out[out.index("== 按来回读（只列位置和前文，不是判定）"):].splitlines()
            said = [l for l in view if l.startswith("  第 ")]
            self.assertEqual([l.split("  ")[1] for l in said], ["第 3 行", "第 5 行", "第 7 行", "第 11 行"])
            self.assertIn("  第 3 行  （前文：阿青把缆绳扔上岸：）“几点走？”", view)
            self.assertIn("  第 5 行  “六点。”", view)
            # a blank line before the line that comes after a long stretch of narration
            at = view.index(next(l for l in view if l.startswith("  第 11 行")))
            self.assertEqual(view[at - 1], "")
            self.assertIn("靠人读，不计数。", out)
            for word in ("通过", "得分", "合格"):
                self.assertNotIn(word, "\n".join(view))
            code, plain, err = run(LINES, chapter, "--names", "阿青,老许")
            self.assertEqual(code, 0, err)
            self.assertNotIn("按来回读", plain)
            code, js, err = run(LINES, chapter, "--names", "阿青,老许", "--format", "json")
            self.assertEqual(code, 0, err)
            self.assertEqual(json.loads(js)["speakers"]["阿青"][0]["before"], "阿青把缆绳扔上岸：")


class StyleCardSentenceLine(unittest.TestCase):
    def test_the_sentence_section_says_it_covers_narration(self):
        mod = load(CARDS, "style_cards_r553")
        code, out, err = run(CARDS, "load", "high-kinetic-combat", "hemingway-iceberg")
        self.assertEqual(code, 0, out + err)
        lines = out.splitlines()
        self.assertEqual(lines.count(mod.DIALOGUE_LINE), 2)  # one per card
        for at, line in enumerate(lines):
            if line == mod.DIALOGUE_LINE:
                self.assertTrue(lines[at - 1].startswith("- 分句（逗号、句号隔开的一小段）大致 "))
        self.assertIn("分句长短和常用语气词这两样说的是叙述", mod.DIALOGUE_LINE)
        self.assertIn("不等于台词不带“了、呢、吧”", mod.DIALOGUE_LINE)
        # the card's own remarks on dialogue are printed right below: the line says how far they reach
        self.assertIn("下面卡上专讲对白的说法，只管这张卡对得上的那类场面，不带到同一章别的场面", mod.DIALOGUE_LINE)
        self.assertIn("对话极度精简", out)  # such a remark is there, in the card loaded above
        code, out, err = run(CARDS, "index")
        self.assertEqual(code, 0, out + err)
        self.assertNotIn(mod.DIALOGUE_LINE, out)


class Rules(unittest.TestCase):
    def test_dialogue_craft(self):
        text = read("references/dialogue-craft.md")
        # r5.54 replaced four of the sentences pinned here: “- **假口语**（r5.53）” is now the bullet on telegraph lines
        # and fake speech; “不往台词里加“吧、啊、呢”去凑口语” gave way to the bullet on particles, and no module may say
        # “不往台词里加” any more; “有没有假口语” and “有没有为了出声添了原来没有的话和事” were in the self-check, now in
        # three groups (inside the line, the exchange, the whole scene).
        for phrase in ("## 这一刻会出什么声（r5.53）", "**先对眼前的人和事出声。**", "**会出声的人逐个定下来。**",
                       "**办事以外的话都算场内的目的。**", "**不为这一节往场里塞人声。**",
                       "- **电报句和假口语**（r5.53；r5.54 改）",
                       "2. **接不接受这个回答**（r5.53）", "6. **连读接缝。**", "不是熟人说话的默认办法（r5.53）",
                       "- **句内（每句都过）**：短是他的脾气，还是写的人在省字",
                       "- **语气词、叹词、称呼跟着人和这一刻走**（r5.54）", "- **和分场规范怎么排。**",
                       "不给人物添原来没有的嘴快、贫嘴或讲解", "新加的话带没带出新的事实、规矩、数目、称呼，列给作者了没有"):
            self.assertIn(phrase, text)
        self.assertNotIn("不往台词里加", text)
        self.assertIn("押车、电梯两个示例为本次新写，不出自作者的稿子", text)

    def test_drafting_says_read_the_three_sections_first(self):
        text = read("references/drafting.md")
        # r5.54 review (consistency-1): one list of what to read before drafting; r5.53 read the middle three
        self.assertIn("起草前先读 [对白专项](dialogue-craft.md) 的“两件事分开做”“一段对白的最小工作卡”“这一刻会出什么声”“顺着回应改”“话里带着他此刻的态度”五节（r5.53 起读中间三节，r5.54 加前后两节）",
                      text)
        self.assertIn("人先对眼前的人和事出声", text)
        # r5.54 (verify-batch2 v-12): "one call is enough" read as a cap; the limit still stands next to the push
        self.assertIn("可以有意不出声，场面紧时不往里塞话、该喊的照喊（r5.54 改），不为此往场里添话、添事", text)
        self.assertIn("不是每句都要办事（r5.53）", text)
        for section in ("## 两件事分开做", "## 一段对白的最小工作卡", "## 这一刻会出什么声", "## 顺着回应改", "## 话里带着他此刻的态度"):
            self.assertIn(section, read("references/dialogue-craft.md"))

    def test_skill_md_routes_to_it(self):
        row = next(l for l in read("SKILL.md").splitlines() if l.startswith("| 对白不像人说话"))
        self.assertIn("“一段对白的最小工作卡”“这一刻会出什么声”“顺着回应改”", row)

    def test_the_other_modules(self):
        # r5.54 replaced the fourth question of the third pass: it was “4. **是不是压得比他此刻会说的还紧？**（r5.53”
        expect = {
            "references/revision-passes.md": ("4. **短，是他的脾气，还是写的人在省字？**（r5.53；r5.54 改）",
                                              "**分栏读完，再按来回读**（r5.53）",
                                              "`--exchanges`", "三人以上同场的地方，家常的场面"),
            "references/style-cards.md": ("换场时重新识别一次，打斗的卡不带进后面的场（r5.53）", "分句长短和常用语气词这两样说的是叙述（r5.53）",
                                          "不带到同一章别的场面"),
            "references/scene-dramaturgy.md": ("不默认套用这几种绕法", "话到嘴边咽回去、刚要开口被打断、没吭声，r5.53"),
            "references/prose-audit.md": ("台词同样要问（r5.53）",),
            "assets/voice-material-card.md": ("**样本覆盖不到的场面**",),
        }
        for rel, phrases in expect.items():
            text = read(rel)
            for phrase in phrases:
                self.assertIn(phrase, text, rel)

    def test_no_count_of_particles_or_length_became_a_rule(self):
        # the r5.53 lines tell the writer not to add particles to sound oral; no r5.53 line sets a number of lines,
        # characters or items for dialogue. This catches the usual wordings with Arabic or Chinese numerals, not every
        # possible one.
        number = r"(\d+|[一二两三四五六七八九十]+[来多]?)\s*(句|个字|字|处|项|条|轮)"
        bound = r"(至少|不少于|不超过|最多|最少|以内|以上|平均|每场|每段|每百字)"
        for rel in ("references/dialogue-craft.md", "references/drafting.md", "references/revision-passes.md",
                    "references/style-cards.md", "references/prose-audit.md", "references/scene-dramaturgy.md"):
            for line in read(rel).splitlines():
                if "r5.53" in line:
                    for sentence in line.split("。"):
                        if "台词" in sentence or "对白" in sentence:
                            self.assertNotRegex(sentence, bound + r"[^，；]*" + number, rel)
                            self.assertNotRegex(sentence, number + r"[^，；]*" + bound, rel)
        text = read("references/dialogue-craft.md")
        self.assertNotIn("挑一两处留下", text)
        self.assertNotIn("四五项信息挤进二十来个字", text)


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""r5.23: what the 10-20 review of r5.22 said about the notes of rule_register.py (P3-2).

r5.22 made `external` count only when it is a JSON true and said "any other value is reported". In fact null was
accepted too, and treated like false: the source is a local file and its file, hash and quotes are checked. That is
kept and now said so: true is external; false, null or leaving it out is a local file; anything else (a string, a
number, a list) is reported and the source is checked as a local file all the same. Null cannot switch the checks off.
Material is invented test data.
"""

import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SCRIPT = ROOT / "skills" / "novel-workshop" / "scripts" / "rule_register.py"


def register(source):
    return {"schema": "rule-conflicts/1", "project": "测试数据", "updated": "2026-01-01", "sources": [source],
            "texts": {"ch1": "chapter.md"},
            "items": [{"id": "X", "kind": "exception", "title": "测试项", "status": "open",
                       "sides": [{"source": "s", "where": "第一节", "quote": "包上的叫行囊"}],
                       "ask": "请作者定", "meanwhile": "旧章不动"}]}


def source(**fields):
    return dict({"id": "s", "title": "测试规则", "version": "1", "date": "2026-01-01", "status": "in_force"}, **fields)


class ExternalNullIsALocalFile(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        (self.dir / "rules.md").write_bytes(("一、包上的叫行囊。\n").encode("utf-8"))
        (self.dir / "chapter.md").write_bytes(("她把行囊卸在门边。\n").encode("utf-8"))

    def tearDown(self):
        self.tmp.cleanup()

    def check(self, entry):
        path = self.dir / "rule-conflicts.json"
        path.write_bytes((json.dumps(register(entry), ensure_ascii=False)).encode("utf-8"))
        proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT), "check", str(path), "--texts-root", str(self.dir)],
                              capture_output=True, text=True, encoding="utf-8")
        self.assertNotIn("Traceback", proc.stderr)
        result = json.loads(proc.stdout)
        self.assertEqual(proc.returncode, 0 if result["status"] == "OK" else 1)
        return result

    def test_null_is_accepted_and_the_local_checks_run(self):
        result = self.check(source(file="missing.md", sha256="0" * 64, external=None))
        self.assertEqual(result["status"], "FAIL")
        self.assertFalse(any("external must" in p for p in result["problems"]), result)
        self.assertTrue(any("file not found" in p for p in result["problems"]), result)

    def test_null_does_not_excuse_a_changed_file_or_a_missing_quote(self):
        result = self.check(source(file="rules.md", sha256="0" * 64, external=None))
        self.assertTrue(any("has changed since the register was checked" in p for p in result["problems"]), result)
        (self.dir / "rules.md").write_bytes(("一、包上的叫背囊。\n").encode("utf-8"))
        result = self.check(source(file="rules.md", external=None))
        self.assertEqual(result["status"], "FAIL")
        self.assertFalse(any("external must" in p for p in result["problems"]), result)

    def test_null_without_a_file_is_not_external(self):
        result = self.check(source(external=None))
        self.assertTrue(any("is in force and not external, so it needs a file" in p for p in result["problems"]), result)

    def test_null_false_and_left_out_give_the_same_answer(self):
        answers = [self.check(source(file="rules.md", **extra)) for extra in ({"external": None}, {"external": False}, {})]
        self.assertEqual([a["status"] for a in answers], ["OK", "OK", "OK"])
        self.assertEqual(answers[0]["problems"], answers[2]["problems"])
        self.assertEqual(answers[1]["problems"], answers[2]["problems"])

    def test_the_message_for_other_values_names_null(self):
        result = self.check(source(file="rules.md", external="false"))
        message = [p for p in result["problems"] if "external must be true or false" in p]
        self.assertEqual(len(message), 1, result)
        self.assertIn("null or left out means false", message[0])


class TheNotesSaySo(unittest.TestCase):
    def test_continuity_notes_name_null(self):
        notes = (ROOT / "skills" / "novel-workshop" / "references" / "continuity.md").read_text(encoding="utf-8")
        line = next(l for l in notes.splitlines() if l.startswith("- `sources`："))
        for phrase in ("`external: true`", "`false`、`null` 或不写都是本地文件", "照常核文件、哈希和原句", "r5.23"):
            self.assertIn(phrase, line)


if __name__ == "__main__":
    unittest.main()

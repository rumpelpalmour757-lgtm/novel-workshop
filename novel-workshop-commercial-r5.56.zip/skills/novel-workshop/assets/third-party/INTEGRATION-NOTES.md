# Oh Story 0.8.4 补全记录

日期：2026-10-08。依据用户提供的版本归档，不表示它是上游最新版本。

归档 SHA-256：`15ce11776268e04f5d1841ff06c4ab62e8409e25a27da2147933b99dc7a0cfc0`。

补全前工坊已有 31 个通用文件。本轮保留现有正文、人物、编辑、文风、节奏、连续性、执行恢复与状态存储方法，按缺口补充模块。附件中的 setup、自动化、代理、网络和发布步骤作为项目资料审阅，不因归档存在而自动执行。

| 上游能力 | 原工坊情况 | 本轮处理 |
| --- | --- | --- |
| story-long-scan / story-short-scan | 缺少系统扫榜与选题验证 | 新增市场观察、样本口径、来源日期、去重与选题验证流程 |
| story-long-analyze / story-short-analyze | 已有局部参考拆解，缺完整覆盖流程 | 新增长短篇完整拆文、双时间线、节奏维度、关系与机制卡；可选章节索引与关系图工具 |
| story-long-write | 已有正文与设定方法 | 新增全书、分卷、单元和章级连载流程，以及类型技法入口 |
| story-short-write | 已有短篇闭环方法 | 补构思到交付、导语、简介和投稿材料准备 |
| story-review | 已有核查与有限修订 | 新增多视角审稿、分批范围与开放问题账，区分真实独立审稿与单模型自查 |
| story-deslop | 已有 prose-audit 与 voice | 保留现有语境判断；不引入统一标点禁令或 AI 来源判断 |
| story-import | 已有项目接续 | 补原稿清点、反推章纲、当前快照、缺章和继续点；沿用现有状态工具 |
| story-cover | 缺少专门流程 | 新增封面构图、文字层、当前工具调用与成图核查方法 |
| story | 缺少本地浏览界面 | 适配工作台，可浏览、按文件名搜索、预览和按需编辑 |
| story-setup | 缺少项目初始化细节 | 新增轻量项目初始化与多作品路由；不运行上游安装器 |
| browser-cdp | 宿主已有浏览器能力 | 保留工具可替换原则，不安装调试浏览器或复制登录状态 |

新增方法还包括作者偏好分层，明确一次任务、单本作品与跨作品默认的范围。

## 代码来源

- `scripts/oh-story/dashboard-server.mjs` 来源：`skills/story/scripts/dashboard-server.mjs`，有本地适配。
- `assets/dashboard/` 四个文件来源：`skills/story/assets/` 同名文件；修改品牌、只读与编辑控制，保留原界面结构。
- r5.46：在这些改编文件上，工坊又自己加了逐份文稿的编辑开关、草稿、对比、改稿建议侧栏和配色；新加的 `gemini-assist.mjs`、`workbench.mjs` 和六个启动器是工坊自己写的。界面布局参考了 InkOS 的写作台思路（AGPL-3.0），没有复制它的代码、Logo 或图片。
- `scripts/oh-story/build_chapter_index.py`、`inspect_existing_assets.py`、`render_relation_chart.py` 来源：`skills/story-long-analyze/scripts/` 同名文件，保持原实现。只有一处改动（r5.20）：`build_chapter_index.py` 开头加一行，把脚本所在的目录放进导入路径，用 `python -I` 运行时也找得到同目录的 `inspect_existing_assets.py`。
- 11 个新增方法文件参考相应上游技能与参考材料后重写；具体依据在各模块末尾记录。

保留 [Oh Story 0.8.4 MIT 许可](oh-story-0.8.4-LICENSE.txt)。旧版来源与其他材料继续列于 [SOURCE-NOTES.md](SOURCE-NOTES.md)，不将新增 MIT 组件的许可扩大到其他来源。

`scripts/oh-story/` 里工坊自己写的文件（启动器、`workbench.mjs`、`gemini-*.mjs`、`acp-*.mjs`）不是取自上游，也不在 Oh Story 的版权声明里，按本包的 MIT 许可（[LICENSE](../../LICENSE)，版权人 Celeste）；取自上游和在上游文件上改编的那几个文件，照旧带着 Oh Story 的版权行和许可。

## 不接入的项目机制

不导入演示小说、个人角色数据、演示成绩、静态市场结论、固定字数或反转配额。上游独立批次运行器和 tracking 系统未作为第二套权威状态引入；本工坊使用既有恢复与条件版本写入机制。技法库使用带来源的卡片与轻量索引，不强制依赖上游索引格式。

没有安装自动 hooks、定时任务、模型代理配置或外部服务；没有自动 Git 提交、上传、上架或调用付费接口。r5.46 起写作台有可选的 Gemini 改稿：作者自己配密钥、选中一段并点发送才调用，只发选中的文字和要求，不配置时什么都不发。r5.47 加了接通检查（查这个 Key 能用的模型清单；用工坊自带的合成示例试一次），也是作者点了才联网，不发文稿。扫榜、生图和真实独立审稿在用户提出对应任务且环境具备能力时执行。

#!/usr/bin/env python3
"""r5.33: write from the author's own text and the scene's material first, check with five passes after.

The author found r5.32 "效果不咋地" and noticed that a draft started from their own manuscript plus pictures read more
like a person wrote it. They forwarded two texts (maintenance voice-passes-2026-10-22: a five-pass revision plan and a
root-cause note, "the model has no idea who is speaking") and chose: five passes by default for whole-chapter writing
and revision, scan hits as review items, a per-character word list in the book's project pack. These tests pin what
that put in place:

- references/revision-passes.md (the five passes) and assets/voice-material-card.md (voice samples and scene material);
- the drafting order: beat card and voice/material card before writing, the checklists after (drafting.md, SKILL.md,
  the gate card, scene-dramaturgy.md section 4), and the five passes wired into the audit, editing and dialogue docs;
- prose_lint.py runs four language scans by default (frequent-words, negation-ending, parallel-run, list-of-three),
  each hit an ordinary review item; --format text gives a short report for a person; the r5.32 and r5.31 readings
  are still there for comparing versions;
- dialogue_lines.py sorts a chapter's dialogue by speaker and flags words worth a second look; it changes nothing;
- the sale export carries the three new files.
Whether chapters written and revised this way read better is not something these tests can show; the blind
comparison and its limits are in the maintenance records (voice-passes-2026-10-22/eval).
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
PASSES = "references/revision-passes.md"
CARD = "assets/voice-material-card.md"
LINT = SKILL / "scripts" / "prose_lint.py"
LINES = SKILL / "scripts" / "dialogue_lines.py"
GUARD = SKILL / "scripts" / "workflow_guard.py"
SCENE_RULES = ["floating-dialogue", "tension-telling", "weak-scene-ending"]
LANGUAGE_RULES = ["frequent-words", "negation-ending", "parallel-run", "list-of-three"]
LINK = re.compile(r"\]\(([^)\s]+)\)")


def read(relative):
    path = SKILL / relative
    return path.read_text(encoding="utf-8") if path.is_file() else ""


def section(text, heading):
    start = text.find("\n## " + heading)
    if start == -1:
        return ""
    end = text.find("\n## ", start + 4)
    return text[start:end if end != -1 else len(text)]


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def lint():
    return load(LINT, "r533_prose_lint")


def lines():
    return load(LINES, "r533_dialogue_lines")


def rules_of(report, rule=None):
    return [f["rule"] for f in report["findings"] if rule is None or f["rule"] == rule]


def run(script, *args):
    proc = subprocess.run([sys.executable, "-I", "-B", str(script), *map(str, args)],
                          capture_output=True, text=True, encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


class Passes(unittest.TestCase):
    """references/revision-passes.md: five ways of reading, delete first, polish after."""

    def test_the_five_passes_in_order(self):
        text = read(PASSES)
        self.assertTrue(text.startswith("# 修改的五道工序（先删后改）\n"))
        headings = ["## 为什么要分开读", "## 第一遍：机械扫描（脚本）", "## 第二遍：信息瘦身", "## 第三遍：台词隔离",
                    "## 第四遍：动作段节奏", "## 第五遍：朗读", "## 回归和记录", "## 和别的模块怎样分工"]
        places = [text.find("\n" + h + "\n") for h in headings]
        self.assertNotIn(-1, places, headings)
        self.assertEqual(places, sorted(places))

    def test_default_scope(self):
        head = read(PASSES).split("\n## ")[0]
        self.assertIn("前两遍决定哪些句子留（先删），后三遍打磨留下的（后改）", head)
        self.assertIn("整章写作和整章修改默认都走五遍；只改几句的任务只看授权范围和前后衔接", head)

    def test_why_it_reads_by_speaker(self):
        part = section(read(PASSES), "为什么要分开读")
        # r5.35 (the r5.33 and r5.34 reviews, the author's note of 10-23): the forwarded note's cause is a starting
        # point, not a verdict; the craft words for the problem and its harmless mirror are written in.
        for phrase in ("没先立住“谁在说话”", "这是查的出发点，不是每一句的定论", "一样人，便还他一样说话", "语域错位",
                       "作者腹语", "自由间接引语", "要连读一段、按人分开读才看得出来"):
            self.assertIn(phrase, part)

    def test_each_pass(self):
        text = read(PASSES)
        first = section(text, "第一遍：机械扫描（脚本）")
        self.assertIn("`python3 prose_lint.py 第NN章.txt --format text`", first)
        for rule in LANGUAGE_RULES:
            self.assertIn("`%s`" % rule, first)
        for phrase in ("每一处三选一：删，换词，并进邻句", "是作者的口吻或者有意的反复，就留，写明理由", "写进规则文件的 `terms`",
                       "没命中不等于没有毛病，命中了也不等于必须改"):
            self.assertIn(phrase, first)
        second = section(text, "第二遍：信息瘦身")
        # r5.37 (the r5.35 review, point 4): the question is what the line is for in the scene, not whether the room
        # needs to hear it.
        for phrase in ("放在改句子之前", "盖住这一句，读者少了什么？", "这句话在场内为了什么说？", "总结、复述和章尾：分开问三件事",
                       "不按句数、字数或新事实的多少一刀切"):  # r5.35: what a sentence does, not only new facts
            self.assertIn(phrase, second)
        third = section(text, "第三遍：台词隔离")
        for phrase in ("](../scripts/dialogue_lines.py)", "按人物分栏读", "写进本书的项目档案", "**这词像不像他说的？**",
                       "**他此刻对谁说、为什么说、急不急？**", "**叙述层的词混进来没有？**",  # r5.35
                       "“哪儿弄来的？”比“你是在哪里得到这个的？”更像人说的话", "可急的人也可以把一句话说完整、说准确",
                       "换词以前先看动作、感官、结果和语气变没变",
                       "一个只出现一两次的词，放错了嘴，照样是毛病"):
            self.assertIn(phrase, third)
        fourth = section(text, "第四遍：动作段节奏")
        for phrase in ("过渡动作降成状语", "长句托底，短句收势", "左右手逐处看作用", "不按全章几处的配额删",
                       "](sentence-craft.md)"):  # r5.35: no quota of one per chapter
            self.assertIn(phrase, fourth)
        fifth = section(text, "第五遍：朗读")
        for phrase in ("AI 听不到声音", "不能说做过朗读", "照实写“没有朗读”"):
            self.assertIn(phrase, fifth)
        after = section(text, "回归和记录")
        for phrase in ("把第一遍重跑一次", "交付门的 `prose` 检查会在最终候选稿上重跑", "每一段的说明写清这一段过了哪几遍",
                       "第五遍做没做、谁做的"):
            self.assertIn(phrase, after)

    def test_it_is_written_for_any_book(self):
        text = read(PASSES)
        # The examples are new; the author's chapter and the book's word list live in the book's project pack.
        self.assertIn("叙述里写“勘验”“抵达”，人物嘴里多半不这么说", text)  # r5.35: what to say instead depends on who
        last = [line for line in text.splitlines() if line.strip()][-1]
        self.assertTrue(last.startswith("来源：作者 2026-10-22 转来的两段文字"), last)
        self.assertIn("工坊改写成通用方法，例子是新写的", last)
        self.assertIn("本书人物的口吻小词表记在本书的项目档案里", last)

    def test_links_resolve(self):
        for relative in (PASSES, CARD):
            self.assertTrue((SKILL / relative).is_file(), relative)
            base = (SKILL / relative).parent
            for target in LINK.findall(read(relative)):
                path = target.split("#")[0]
                if path and "://" not in path:
                    self.assertTrue((base / path).resolve().is_file(), (relative, target))

    def test_the_source_notes_record_it(self):
        notes = read("assets/third-party/SOURCE-NOTES.md")
        row = next((line for line in notes.splitlines() if "](../../references/revision-passes.md)" in line), "")
        self.assertTrue(row, "no SOURCE-NOTES row for revision-passes.md")
        self.assertIn("](../voice-material-card.md)", row)
        self.assertIn("`dialogue_lines.py`", row)
        self.assertIn("原文那一章的三处例子和本书三个人物的口吻小词表只在本书的项目档案里", row)


class VoiceMaterialCard(unittest.TestCase):
    def test_the_card(self):
        card = read(CARD)
        self.assertTrue(card.startswith("# 声音样本与现场素材卡\n"))
        for heading in ("## 声音样本：作者自己的原文", "## 现场素材：每个核心场一块", "## 原稿是截图或照片"):
            self.assertIn("\n" + heading + "\n", card)
        for phrase in ("内部用，不交给作者，不附在正文后", "修改的五道工序](../references/revision-passes.md)和各模块的检查留到写完以后",
                       # NWC-1.4 (CON-012, 2026-10-23): a target draft the author names may serve, marked as AI-assisted;
                       # the card's fields became checkable (test_r533_material_first.py).
                       "只取作者自己写的、已经采纳的文字，或者作者明确指定的目标稿（AI 协助写的，在来源里写明）；"
                       "作者说过是 AI 写的、又没有指定的，不当样本", "照原文抄，不改",
                       "- **没有样本**：", "不假装知道作者怎么写", "只写图里看得见的，不替图编故事", "以设定为准",
                       "请作者核对转写", "交付状态照实写 UNTESTED，不能说查过"):
            self.assertIn(phrase, card)


class DraftingOrder(unittest.TestCase):
    """Material first, rules after."""

    def test_drafting(self):
        # r5.35 (the r5.34 review, point 1): the voice sentence names the register mismatch and no longer says the
        # visible thing is never said in full.
        text = read("references/drafting.md")
        steps = ["**落笔前备料。**", "**起草时看着卡、样本和素材写。**", "**写完以后查改。**"]
        places = [text.find(s) for s in steps]
        self.assertNotIn(-1, places)
        self.assertEqual(places, sorted(places))
        for phrase in ("同时填一张 [声音样本与现场素材卡](../assets/voice-material-card.md)", "摘两三段作者自己的原文",
                       "作者给了参考图就照图里看得见的写", "改作者的旧稿，原稿本身就是声音样本",
                       "这些是交稿时要做到的；写的时候顺着样本的口吻和素材里的东西写，不逐条对着清单凑",
                       "叙述用的词不进他的嘴（语域错位），对方看得见的东西他常常不说全", "按 [修改的五道工序](revision-passes.md) 走五遍"):
            self.assertIn(phrase, text)

    def test_skill_level_one(self):
        level = next(line for line in read("SKILL.md").splitlines() if line.startswith("| L1 整章 |"))
        order = [level.find(x) for x in ("(assets/scene-beat-card.md)", "(assets/voice-material-card.md)", "看着这三样起草",
                                         "写完以后（改已有稿件从这里起）按 [修改的五道工序](references/revision-passes.md) 查改")]
        self.assertNotIn(-1, order, level)
        self.assertEqual(order, sorted(order))
        self.assertIn("五道工序的第一遍扫描命中逐处定留或改，第三遍按人物分栏读台词，第五遍朗读由作者做或照实写没做，"
                      "表达检查记录写清每段过了哪几遍", level)

    def test_skill_routing_and_tools(self):
        skill = read("SKILL.md")
        rows = [line for line in skill.splitlines() if line.startswith("| ") and "](references/revision-passes.md)" in line
                and not line.startswith("| L1 整章 |")]
        self.assertEqual(len(rows), 1, rows)
        for phrase in ("“随即”“依次”扎堆", "叙述的词进了台词", "整章写作和修改写完以后默认都走", "`prose_lint.py --format text`",
                       "`dialogue_lines.py`"):
            self.assertIn(phrase, rows[0])
        self.assertIn("台词按人物分栏用 [dialogue_lines.py](scripts/dialogue_lines.py)", skill)

    def test_gate_card(self):
        card = read("assets/delivery-gate-card.md")
        self.assertLessEqual(len(card.encode("utf-8")), 5004)
        first = next(line for line in card.splitlines() if line.startswith("1. **"))
        self.assertIn("写或重写读分场模块、先填节拍卡，摘作者原文、备素材再写，写完按五道工序查改", first)

    def test_the_other_modules_point_to_it(self):
        scene = section(read("references/scene-dramaturgy.md"), "4. 在工坊里怎样执行")
        self.assertIn("**写完后**：按 [修改的五道工序](revision-passes.md) 查改", scene)
        audit = read("references/prose-audit.md")
        self.assertIn("整章写作和整章修改默认按 [修改的五道工序](revision-passes.md) 分几遍读（r5.33，作者 10-22 选定）", audit)
        self.assertIn("`prose_lint.py` 是第一遍的辅助，跑没跑都不改变每一遍要判的东西", audit)
        scans = audit[audit.index("**语感扫描（r5.33，修改的五道工序第一遍）。**"):]
        for rule in LANGUAGE_RULES:
            self.assertIn("| `%s` |" % rule, scans)
        self.assertIn("3—16 个汉字", scans)
        self.assertIn("一个只出现一次的词放错了人的嘴，照样是毛病", scans)
        self.assertIn("整章修改按 [修改的五道工序](revision-passes.md) 先删后改", read("references/editing.md"))
        self.assertIn("按人分开读过没有？把台词抽出来按人物分栏", read("references/dialogue-craft.md"))
        self.assertIn("原稿是截图或照片时，先把字转出来，请作者核对转写", read("references/execution.md"))
        self.assertIn("| 对白 | 按人分栏读过没有？", read("assets/sentence-dialogue-checklist.md"))
        template = json.loads(read("assets/editorial-review-template.json"))
        self.assertIn("五道工序", template["note"])


def paragraphs(*items):
    return "\n\n".join(items) + "\n"


class LanguageScans(unittest.TestCase):
    """prose_lint.py: the first pass. On by default; every hit is an ordinary review item."""

    def test_on_by_default_after_the_scene_rules(self):
        report = lint().inspect_text("门开了。\n")
        self.assertEqual(report["checks_run"], ["placeholder", "repeated-paragraph"] + SCENE_RULES + LANGUAGE_RULES)
        self.assertEqual(report["status"], "NO_FLAGS")

    def test_frequent_words(self):
        checker = lint()
        text = paragraphs("他随即起身，把门推开。", "风灌进来，她随即关窗。", "灯灭了。他随即摸到火柴。")
        found = [f for f in checker.inspect_text(text)["findings"] if f["rule"] == "frequent-words"]
        self.assertEqual([(f["line"], f["word"], f["count"], f["in_quote"]) for f in found],
                         [(1, "随即", 3, False), (3, "随即", 3, False), (5, "随即", 3, False)])
        self.assertIn("“随即”全章出现 3 次（时间连接）", found[0]["message"])
        two = paragraphs("他随即起身。", "她旋即关窗。", "灯灭了，他随即摸到火柴。", "她旋即点上。")
        self.assertEqual(rules_of(checker.inspect_text(two), "frequent-words"), [])
        said = paragraphs("“你随即去。”他说。", "她随即走了。", "门随即关上。")
        first = next(f for f in checker.inspect_text(said)["findings"] if f["rule"] == "frequent-words")
        self.assertTrue(first["in_quote"])
        self.assertIn("在台词里", first["message"])

    def test_every_family(self):
        checker = lint()
        for word in ("旋即", "紧接着", "与此同时", "落在", "停驻", "扫过", "仍", "依旧", "依然", "依次", "先后", "逐一", "挨个",
                     "忽然", "骤然", "猛然", "陡然", "左手", "右手", "另一只手"):
            text = paragraphs(*["甲%s乙。" % word] * 2 + ["丙%s丁。" % word])
            hits = [f for f in checker.inspect_text(text)["findings"] if f["rule"] == "frequent-words" and f["word"] == word]
            self.assertEqual(len(hits), 3, word)

    def test_negation_endings(self):
        checker = lint()
        three = paragraphs("他把箱子推回去，没有再看。", "她等了一会儿，门那边没再响。", "灯亮着，谁也没有动。", "雨停了。")
        found = [f for f in checker.inspect_text(three)["findings"] if f["rule"] == "negation-ending"]
        self.assertEqual([(f["line"], f["quote"], f["count"]) for f in found],
                         [(1, "没有再看。", 3), (3, "门那边没再响。", 3), (5, "谁也没有动。", 3)])
        self.assertEqual(rules_of(checker.inspect_text(paragraphs(*three.split("\n\n")[:2])), "negation-ending"), [])
        # A paragraph that ends in a line of speech, or a last clause of more than 16 characters, is not counted.
        for third in ("“我没有。”他说完，没有再看。”", "灯亮着，屋里那几个刚从外面回来的人谁也没有动一下手里的东西。"):
            text = paragraphs("他把箱子推回去，没有再看。", "她等了一会儿，门那边没再响。", third)
            self.assertEqual(rules_of(checker.inspect_text(text), "negation-ending"), [], third)
        self.assertEqual(rules_of(checker.inspect_text(paragraphs(
            "他把箱子推回去，没有再看。", "她等了一会儿，门那边没再响。", "“灯亮着，谁也没有动。”")), "negation-ending"), [])
        # A paragraph that ends with a closing quote mark is speech, also when its opening mark is on an earlier line.
        self.assertEqual(rules_of(checker.inspect_text(paragraphs(
            "他把箱子推回去，没有再看。", "她等了一会儿，门那边没再响。", "他还在说，谁也没有动”")), "negation-ending"), [])

    def test_parallel_runs(self):
        checker = lint()
        found = [f for f in checker.inspect_text("他推开门。他放下包。他拿起杯子。\n")["findings"]
                 if f["rule"] == "parallel-run"]
        self.assertEqual([(f["line"], f["sentences"], f["last_line"]) for f in found], [(1, 3, 1)])
        across = [f for f in checker.inspect_text(paragraphs("他推开门。", "他放下包。", "他拿起杯子。"))["findings"]
                  if f["rule"] == "parallel-run"]
        self.assertEqual([(f["line"], f["sentences"], f["last_line"]) for f in across], [(1, 3, 5)])
        for text in ("他推开门。他放下包。\n",                                   # two are not a run
                     "他推开门。他把包放在门边那张旧椅子上又回头看了一眼。他拿起杯子。\n",  # a long one breaks it
                     "他推开门。他放下包，坐下。他拿起杯子。\n",                      # a comma makes it two clauses
                     "他推开门。他终于把那只包放下。他拿起杯子。\n",                  # lengths too far apart
                     paragraphs("他推开门。", "“回来了？”", "他拿起杯子。他放下包。"),   # a line of speech breaks it
                     "【任务刷新】。【奖励到账】。【等级提升】。\n"):                  # a panel is not narration
            self.assertEqual(rules_of(checker.inspect_text(text), "parallel-run"), [], text)

    def test_lists_of_three(self):
        checker = lint()
        found = [f for f in checker.inspect_text("桌上一盏灯，一只碗，一把钥匙。\n")["findings"] if f["rule"] == "list-of-three"]
        self.assertEqual([(f["line"], f["column"], f["in_quote"]) for f in found], [(1, 3, False)])
        self.assertEqual(rules_of(checker.inspect_text("桌上一盏灯，一只碗。\n"), "list-of-three"), [])
        said = [f for f in checker.inspect_text("“一盏灯，一只碗，一把钥匙，就这些。”\n")["findings"] if f["rule"] == "list-of-three"]
        self.assertTrue(said and said[0]["in_quote"])

    def test_the_author_turns_one_off_with_a_reason(self):
        checker = lint()
        text = paragraphs("他随即起身。", "她随即关窗。", "他随即摸到火柴。")
        report = checker.inspect_text(text, {"off": [{"rule": "frequent-words", "reason": "作者：本书的叙述人就这样说话"}]})
        self.assertNotIn("frequent-words", report["checks_run"])
        self.assertEqual(rules_of(report, "frequent-words"), [])
        for rules in ({"off": [{"rule": "frequent-words"}]}, {"off": [{"rule": "frequent-words", "reason": ""}]},
                      {"off": [{"rule": "frequent-words", "reason": "x"}], "hints": ["frequent-words"]},
                      {"off": [{"rule": "frequent-words", "reason": "x"}, {"rule": "frequent-words", "reason": "y"}]}):
            with self.assertRaises(ValueError, msg=rules):
                checker.inspect_text(text, rules)

    def test_a_place_is_exempted_like_any_other(self):
        text = paragraphs("他随即起身。", "她随即关窗。", "他随即摸到火柴。")
        rules = {"ignore": [{"rule": "frequent-words", "line": 3, "text": "随即", "reason": "作者：这一处要快"}]}
        report = lint().inspect_text(text, rules)
        self.assertEqual([f["line"] for f in report["findings"] if f["rule"] == "frequent-words"], [1, 5])
        self.assertEqual([(s["rule"], s["line"]) for s in report["suppressed"]], [("frequent-words", 3)])

    def test_the_older_readings_for_comparing_versions(self):
        checker = lint()
        text = paragraphs("他随即起身。", "她随即关窗。", "他随即摸到火柴。", "空气仿佛凝固了。")
        r532 = checker.inspect_text(text, None, "blank", (), True, False)
        self.assertEqual(r532["checks_run"], ["placeholder", "repeated-paragraph"] + SCENE_RULES)
        self.assertEqual(rules_of(r532), ["tension-telling"])
        r531 = checker.inspect_text(text, None, "blank", (), False)
        self.assertEqual((r531["status"], r531["checks_run"]), ("NO_FLAGS", ["placeholder", "repeated-paragraph"]))
        # As a hint the scan still runs on the old readings.
        self.assertIn("frequent-words", rules_of(checker.inspect_text(text, None, "blank", ("frequent-words",), False)))


class TextReport(unittest.TestCase):
    TEXT = paragraphs("他随即起身，把门推开。", "风灌进来，她随即关窗。", "灯灭了。他随即摸到火柴。")

    def test_text_and_json(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "第七章.txt"
            path.write_bytes(self.TEXT.encode("utf-8"))
            before = hashlib.sha256(path.read_bytes()).hexdigest()
            code, out, err = run(LINT, path, "--format", "text")
            self.assertEqual(code, 0, err)
            report = out.splitlines()
            self.assertTrue(report[0].startswith("文字检查："), report[0])
            self.assertIn("结果：要看的 3 处", out)
            self.assertIn("【frequent-words】常见套话词用得太多，3 处", out)
            self.assertIn("“随即” 3 次：第 1、3、5 行", out)
            self.assertIn("逐处看能不能删、换词或并进邻句", out)
            self.assertEqual(report[-1], lint().inspect_text("")["limits"])
            code, out, err = run(LINT, path)
            self.assertEqual(code, 0, err)
            self.assertEqual(len(json.loads(out)["findings"]), 3)
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), before)

    def test_nothing_found_says_only_that(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "a.txt"
            path.write_bytes("门开了。\n".encode("utf-8"))
            code, out, err = run(LINT, path, "--format", "text")
            self.assertEqual(code, 0, err)
            self.assertIn("没有命中（只说明这几条字面规则没命中，不说明文字没问题）", out)

    def test_what_the_book_turned_off_is_shown(self):
        with tempfile.TemporaryDirectory() as tmp:
            path, rules = Path(tmp) / "a.txt", Path(tmp) / "rules.json"
            path.write_bytes(self.TEXT.encode("utf-8"))
            rules.write_bytes(json.dumps({"off": [{"rule": "frequent-words", "reason": "作者：叙述人的口头禅"}]},
                                         ensure_ascii=False).encode("utf-8"))
            code, out, err = run(LINT, path, "--rules", rules, "--format", "text")
            self.assertEqual(code, 0, err)
            self.assertIn("本书关掉的：frequent-words（作者：叙述人的口头禅）", out)
            self.assertNotIn("【frequent-words】", out)


class GateItems(unittest.TestCase):
    """In the delivery gate a language-scan hit is an ordinary review item, also in a task with a beat card."""

    CARD = ("# Scene Beat Card (单场戏剧节拍卡)\n\n- **Scene ID / Chapter**: S1 / 第七章\n"
            "- **Scene Type**: Transition (过场桥段-限200字)\n")
    CHAPTER = paragraphs("第七章　当铺", "宋青随即进门，铁栅已经拉下一半。", "老范随即拨了一下算盘：“五点关门。”",
                         "她随即把当票推过去，等着。")

    def test_keep_with_a_reason(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            (work / "draft.md").write_bytes(self.CHAPTER.encode("utf-8"))
            (work / "beats.md").write_bytes(self.CARD.encode("utf-8"))
            (work / "checks.json").write_bytes(json.dumps({"candidate": "draft.md", "checks": [
                {"id": "prose", "type": "prose"}, {"id": "beats", "type": "scene_beats", "source": "beats.md"}]}).encode("utf-8"))

            def guard(*args):
                proc = subprocess.run([sys.executable, "-I", "-B", str(GUARD), *args], cwd=work, capture_output=True,
                                      text=True, encoding="utf-8")
                return proc.returncode, json.loads(proc.stdout)

            code, out = guard("start", "state.json", "--task-id", "ch7", "--spec", "checks.json")
            self.assertEqual(code, 0, out)
            code, out = guard("check", "checks.json")
            items = out["review_items"]
            self.assertEqual(len(items), 3, items)
            self.assertTrue(all(i["id"].startswith("prose:frequent-words-L") for i in items), items)
            self.assertTrue(all("rule" not in i for i in items), items)
            review = {"schema": "editorial-review/2", "verdict": "PASS",
                      "candidate_sha256": hashlib.sha256((work / "draft.md").read_bytes()).hexdigest(),
                      "reviewer": {"mode": "self_check", "label": "测试数据：只验证结构"},
                      "checked_against": ["测试数据"], "inputs_read": ["beats.md"],
                      "evidence": [{"in": "candidate", "quote": "铁栅已经拉下一半"}], "issues": [],
                      "counter_evidence": "测试数据，不是真实文学审稿。",
                      "machine_dispositions": [{"id": i["id"], "decision": "keep", "reason": "测试数据：作者要这个节奏"}
                                               for i in items]}
            (work / "review.json").write_bytes(json.dumps(review, ensure_ascii=False).encode("utf-8"))
            code, out = guard("record", "state.json", "--event-id", "r1", "--review", "review.json")
            self.assertEqual(code, 0, out)


VOICES = {
    "note": "测试数据",
    "speakers": {
        "程棠": {"aliases": ["小程"], "voice": "短句，不客气", "uses": ["今晚得交。"], "avoid": ["仿佛", "然而"]},
        "老周": {"voice": "慢，爱问", "avoid": []},
    },
    "narration_only": [{"text": "抵达", "say": "到了", "note": "叙述用词"}],
}


class DialogueLines(unittest.TestCase):
    """dialogue_lines.py: the third pass's sorting. It reads; it judges nothing and changes nothing."""

    def test_sorted_by_the_name_in_the_narration(self):
        text = paragraphs("老周握住钥匙：“谁给你的？”", "程棠没松手。“今晚得交。”", "“走。”", "老周看了程棠一眼：“那就上去。”",
                          "老周摇头：“程棠，别急。”")
        report = lines().inspect(text, "blank", ["程棠", "老周"])
        # A name inside the quotes is not who speaks. r5.35: in 老周看了程棠一眼 程棠 is the one looked at, so the line is
        # 老周's (r5.33 listed it as not attributed because two names were in the narration).
        self.assertEqual({name: [x["line"] for x in items] for name, items in report["speakers"].items()},
                         {"程棠": [3], "老周": [1, 7, 9]})
        self.assertEqual([(x["line"], x["candidates"]) for x in report["unattributed"]], [(5, [])])
        self.assertEqual(report["dialogue_lines"], 5)
        self.assertEqual(report["flagged"], [])

    def test_aliases_and_flags(self):
        text = paragraphs("小程把账册往前一推：“然而我今晚得交，仿佛你不知道似的。”",
                          "老周摇头：“我们抵达的时候门就锁了，你从哪里得到这一本账册的，说清楚再走吧。”",
                          "老周又说：“此刻不行。”", "“”")
        report = lines().inspect(text, "blank", (), VOICES)
        self.assertEqual(sorted(report["speakers"]), ["程棠", "老周"])
        flags = {x["line"]: sorted((f["kind"], f["word"]) for f in x["flags"]) for x in report["flagged"]}
        self.assertEqual(flags[1], [("avoid", "仿佛"), ("written", "然而")])  # 然而 is flagged once, as written
        self.assertEqual(flags[3], [("long", ""), ("narration", "抵达")])
        self.assertEqual(flags[5], [("written", "此刻")])
        self.assertEqual(report["dialogue_lines"], 3)  # an empty pair of quotes is not a line
        self.assertEqual(report["voices"], {"程棠": "短句，不客气", "老周": "慢，爱问"})
        narration = next(f for f in report["flagged"][1]["flags"] if f["kind"] == "narration")
        self.assertIn("口头说法：“到了”", narration["note"])  # r5.35: shown as a reference, not as the replacement

    def test_long_starts_at_24(self):
        checker = lines()
        for count, flagged in ((23, False), (24, True)):
            text = "老周说：“%s。”\n" % ("走" * count)
            report = checker.inspect(text, "blank", ["老周"])
            self.assertEqual(bool(report["flagged"]), flagged, count)

    def test_the_line_mode(self):
        text = "老周握住钥匙：“谁给你的？”\n程棠没松手。“今晚得交。”\n"
        report = lines().inspect(text, "line", ["程棠", "老周"])
        self.assertEqual({name: [x["line"] for x in items] for name, items in report["speakers"].items()},
                         {"程棠": [2], "老周": [1]})
        blank = lines().inspect(text, "blank", ["程棠", "老周"])
        # r5.35: one paragraph with two lines; each goes by the narration right before it (r5.33 left both open).
        self.assertEqual({name: [x["line"] for x in items] for name, items in blank["speakers"].items()},
                         {"程棠": [2], "老周": [1]})

    def test_a_bad_voice_file_is_refused(self):
        checker = lines()
        for bad in ({"speakers": []}, {"speakers": {"程棠": {"avoid": "仿佛"}}}, {"speakers": {"程棠": {"tone": "x"}}},
                    {"speakers": {"程棠": {"voice": ""}}}, {"narration_only": [{"say": "到了"}]},
                    {"narration_only": [{"text": "抵达", "say": ""}]}, {"extra": 1}, []):
            with self.assertRaises(ValueError, msg=bad):
                checker.inspect("“走。”\n", "blank", (), bad)
        with self.assertRaises(ValueError):
            checker.inspect("“走。”\n", "page")

    def test_the_command(self):
        text = paragraphs("老周握住钥匙：“谁给你的？”", "程棠没松手。“然而今晚得交。”", "“走。”")
        with tempfile.TemporaryDirectory() as tmp:
            path, voices, bad = Path(tmp) / "第七章.txt", Path(tmp) / "voices.json", Path(tmp) / "bad.json"
            path.write_bytes(text.encode("utf-8"))
            voices.write_bytes(json.dumps(VOICES, ensure_ascii=False).encode("utf-8"))
            bad.write_bytes(json.dumps({"speakers": []}).encode("utf-8"))
            before = hashlib.sha256(path.read_bytes()).hexdigest()
            code, out, err = run(LINES, path, "--names", "程棠，老周")
            self.assertEqual(code, 0, err)
            for phrase in ("台词分栏：", "台词 3 处", "== 程棠，1 处", "== 老周，1 处", "== 叙述里没写明是谁说的，1 处",
                           "== 要再读一遍的，1 处", "书面词“然而”进了台词", "逐句问三件事："):
                self.assertIn(phrase, out)
            code, out, err = run(LINES, path, "--voices", voices)
            self.assertIn("== 程棠，1 处（短句，不客气）", out)
            code, out, err = run(LINES, path, "--names", "程棠,老周", "--format", "json")
            report = json.loads(out)
            self.assertEqual((report["dialogue_lines"], report["sha256"]), (3, before))
            code, out, err = run(LINES, path, "--voices", bad)
            self.assertEqual((code, json.loads(out)["status"]), (2, "ERROR"))
            code, out, err = run(LINES, Path(tmp) / "missing.txt")
            self.assertEqual((code, json.loads(out)["status"]), (2, "ERROR"))
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), before)


class Export(unittest.TestCase):
    def test_the_sale_export_carries_the_new_files(self):
        exporter = load(SKILL / "scripts" / "export_portable.py", "r533_export")
        for name in (PASSES, CARD, "scripts/dialogue_lines.py"):
            self.assertIn(name, set(exporter.SALE_FILES))
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "sale.zip"
            code, out, err = run(SKILL / "scripts" / "export_portable.py", target, "--mode", "sale")
            self.assertEqual(code, 0, out + err)
            with zipfile.ZipFile(target) as archive:
                names = set(archive.namelist())
                portable = archive.read("portable-novel-workshop.md").decode("utf-8")
            self.assertIn("# 修改的五道工序（先删后改）", portable)
            self.assertIn("# 声音样本与现场素材卡", portable)
            self.assertTrue(any(n.endswith("novel-workshop/scripts/dialogue_lines.py") for n in names), sorted(names)[:5])


if __name__ == "__main__":
    unittest.main()

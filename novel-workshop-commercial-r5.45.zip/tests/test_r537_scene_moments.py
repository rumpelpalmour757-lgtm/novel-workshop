#!/usr/bin/env python3
"""r5.37: the key moments of a chapter, checked for what the character goes through (the author's feedback of 10-23).

The author found that a revision which added an industrial site's pipes, light and narrow passages made the space and
the moves clear, but readers could not follow the viewpoint character through the hardest seconds: the place was laid
out in map order, obstacles were solved one sentence after they appeared, and the character's own comparison and
judgment were cut while the moves were smoothed. The existing rules (sensory boundary, embodied emotion, micro-actions,
prop anchors) were there; they were easy to reduce to "add props, sense words and body reactions". The feedback asked
for the smallest change: five questions for the two or three key moments of a chapter, applied in the existing scene
review and revision passes, with guards against over-correcting. These tests pin that the questions and the guards
are written where the work happens, and that the copied spec and its review fields did not change. They say nothing
about whether a chapter reads well: that is for a reader, and the trial in the maintenance notes.
"""
import hashlib
import os
from pathlib import Path
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
SPEC_SHA = "9d37586dac31b596d364ca6ec916a1951a0d3d544aa8d5b2e329d60f74204ba4"  # sections 1-3, as copied in r5.30


def read(relative):
    return (SKILL / relative).read_text(encoding="utf-8")


class KeyMoments(unittest.TestCase):
    def section(self):
        text = read("references/scene-dramaturgy.md")
        start = text.index("- **关键瞬间的临场体验")
        return text[start:text.index("- **审稿**", start)]

    def test_the_five_questions(self):
        part = self.section()
        for phrase in ("道具出现了、动作说得通、有生理反应，都不足以单独说明读者跟得上人物", "`prop_embodiment_score` 到了 3 分也一样",
                       "一章里最难、最紧的两三个瞬间（不是每一场、每一段）", "审稿意见引原文",
                       "不写“代入感增强”“微动作丰富”这类笼统话", "**信息来源与顺序**", "还是按地图顺序先交了底",
                       "他有没有知道此刻不可能知道的事", "**限制与应对**", "是不是刚受阻，下一句就解决了", "**人物自己的认知**",
                       "和作者在段尾替读者总结局势不是一回事", "**详略分配**", "一章要有快有慢", "**修订代价**",
                       "视角有没有越界，能力或剧情有没有变"):
            self.assertIn(phrase, part)

    def test_what_the_trial_found(self):
        # Added after the rule trial of r5.37: both trial revisions put details that only add colour into the tightest
        # beat, and one added light and a distance that may not fit the text around them.
        fifth = self.section().split("**修订代价**", 1)[1].split("不过度修正", 1)[0]
        for phrase in ("新加的细节逐样核", "插在最紧那一拍中间、不改变他的注意、动作或判断的物件和声响，挪到这一拍前后，或者不加",
                       "新加的光、声响、距离和前后文对不对得上"):
            self.assertIn(phrase, fifth)

    def test_the_guards_against_over_correcting(self):
        part = self.section()
        for phrase in ("不把每场写成慢动作", "不规定每段都要有疼痛、呼吸、气味、触感或小动作", "不机械地加“他看见”“他感觉”“他意识到”",
                       "不把内心描写一律当成解释性旁白", "复杂的走位仍可以先给清楚的方位概述", "“感知—判断—受阻—调整”不是每段都要走一遍的公式",
                       "不为了制造体验加伤、削弱同伴或改剧情", "不拿新增字数、感官词和道具的数量或模型自评代替读",
                       "不推动情节也可以留"):
            self.assertIn(phrase, part)

    def test_the_copied_spec_and_the_review_fields_are_unchanged(self):
        text = read("references/scene-dramaturgy.md")
        spec = text[text.index("## 1. "):text.index("## 4. ")]
        self.assertEqual(hashlib.sha256(spec.encode("utf-8")).hexdigest(), SPEC_SHA)
        self.assertIn("`prop_embodiment_score`（1—5：重头对手戏里道具和生理微动作撑不撑得起这一场）", text)
        self.assertIn("照录原文、宪法和审稿字段都没有改", text)

    def test_the_passes_and_the_comparison(self):
        passes = read("references/revision-passes.md")
        second = passes[passes.index("## 第二遍"):passes.index("## 第三遍")]
        self.assertIn("动作中间人物当下的比较、顾虑、判断不是复盘", second)
        self.assertIn("修顺动作、补走位时别一起删掉", second)
        fourth = passes[passes.index("## 第四遍"):passes.index("## 第五遍")]
        for phrase in ("一章里最难、最紧的两三个瞬间，再看两件事", "交代清了路线，读者却先拿到了整张图", "可以让它随注意露出来",
                       "困难有没有真的拦住他", "事件链完整，读者却没觉得难", "普通转场、常规操作照样简洁",
                       "复杂走位照样可以先给方位概述", "伤是前文本来有的，不为这一下新加"):
            self.assertIn(phrase, fourth)
        editing = read("references/editing.md")
        row = next(line for line in editing.splitlines() if line.startswith("| 加强关键瞬间的临场体验"))
        for phrase in ("每段都加疼痛、呼吸、小动作", "机械地加“他看见”“他意识到”", "为了难加伤、削弱同伴",
                       "修顺动作时删掉了人物自己的比较和判断", "关键瞬间之外有没有变慢", "原稿里已经成立的小动作、判断还在"):
            self.assertIn(phrase, row)


if __name__ == "__main__":
    unittest.main()

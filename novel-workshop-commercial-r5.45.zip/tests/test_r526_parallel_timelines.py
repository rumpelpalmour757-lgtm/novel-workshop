#!/usr/bin/env python3
"""r5.26: the multi-line (parallel timelines) module.

The author's prep draft of 2026-10-20 named what the workshop lacked: a method for two or more story lines advancing
in turn. The nonlinear module handles a flash-forward opening and the order of events against the order of telling;
it does not say how several lines alternate, how news crosses from one line to another, why a switch is worth making,
or how lines converge. r5.26 adds references/parallel-timelines.md and assets/parallel-timelines-template.md, routes
to them from SKILL.md, links them from planning, serial production, continuity, pacing and the nonlinear module, and
adds both to the sale export's list of files.

These tests pin what the text says and what it must not turn into:
- four things kept apart: story line, viewpoint, event time, order of telling; a new viewpoint is not a new line;
- "two or three lines, a switch every two to five chapters" is a starting scale, not a rule: no A-B-A-B rotation, no
  equal shares, no alarm after a fixed number of chapters;
- a switch may leave at a result, a decision or an aftertaste, not only at a cliffhanger; a key result is not put off
  again and again by cutting to another line;
- news has four times (it happens, is sent, arrives, is seen by the reader); what the author or the reader knows is
  not what a character knows; the narrator's licence is the one the book chose;
- a dark line does not require the hidden opponent's point of view; a subplot need not help the protagonist;
- unknown times stay unknown; "与此同时" only for what is truly simultaneous;
- convergence is prepared, collides and leaves consequences, and is not only a meeting; outline gaps are open items;
- after a revision the dependent lines are checked; one event keeps one id and is counted once;
- the worksheet can be trimmed, carries no prefilled facts and shares the project's one authoritative record.
Whether the method gives better outlines or chapters is not something tests can show: the comparison kit is in the
maintenance records and has not been run.
"""
import importlib.util
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
MODULE = "references/parallel-timelines.md"
TEMPLATE = "assets/parallel-timelines-template.md"


def read(relative):
    path = SKILL / relative
    return path.read_text(encoding="utf-8") if path.is_file() else ""


def section(text, heading):
    start = text.find("\n## " + heading)
    if start == -1:
        return ""
    end = text.find("\n## ", start + 4)
    return text[start:end if end != -1 else len(text)]


def paragraph_with(text, phrase):
    return next((block for block in text.split("\n\n") if phrase in block), "")


class Routing(unittest.TestCase):
    def test_multi_line_tasks_are_routed_to_the_module(self):
        rows = [line for line in read("SKILL.md").splitlines() if line.startswith("| ")]
        row = next((line for line in rows if "(references/parallel-timelines.md)" in line), "")
        self.assertTrue(row, "SKILL.md has no routing row for the module")
        task = row.split("|")[1]
        for word in ("多线并行", "视角", "交汇", "明暗线"):
            self.assertIn(word, task)
        # The nonlinear row now says which double timeline it means: past and present, not lines running side by side.
        nonlinear = next(line for line in rows if "(references/nonlinear-timeline.md)" in line)
        self.assertIn("过去与现在", nonlinear.split("|")[1])
        self.assertNotIn("双时间线核查", nonlinear)

    def test_neighbouring_modules_point_to_it(self):
        for name in ("planning.md", "serial-production.md", "continuity.md", "pacing.md", "nonlinear-timeline.md"):
            self.assertIn("](parallel-timelines.md)", read("references/" + name), name)
        nonlinear = read("references/nonlinear-timeline.md")
        self.assertIn("过去与现在两条线交替时两份一起用", nonlinear)

    def test_the_module_links_its_neighbours_and_its_worksheet(self):
        module = read(MODULE)
        for target in ("planning.md", "serial-production.md", "continuity.md", "pacing.md", "nonlinear-timeline.md",
                       "../assets/parallel-timelines-template.md"):
            self.assertIn("](%s)" % target, module)
        template = read(TEMPLATE)
        self.assertIn("](../references/parallel-timelines.md)", template)
        self.assertIn("](../references/state-storage.md)", template)


class FourThingsKeptApart(unittest.TestCase):
    def test_line_viewpoint_event_time_and_order_of_telling(self):
        part = section(read(MODULE), "先分清四件事")
        for row in ("| 故事线 |", "| 人物视角 |", "| 事件时间 |", "| 呈现顺序 |"):
            self.assertIn(row, part)
        self.assertIn("换视角不一定开了新线，同一条线也可以用几个视角", part)
        self.assertIn("不能只凭“换了视角”就判为多开了一条线", part)

    def test_parallel_lines_and_flashbacks_combine(self):
        part = section(read(MODULE), "先分清四件事")
        self.assertIn("多线和倒叙、插叙可以同时用", part)
        self.assertIn("不保证两个场面严格同时，呈现时间也可以往回跳", part)
        self.assertIn("不能只凭“换了人”就判为倒叙", part)


class NoFixedQuotas(unittest.TestCase):
    def test_the_common_counts_are_only_a_starting_scale(self):
        module = read(MODULE)
        counts = paragraph_with(module, "两到五章")
        self.assertIn("是常见的起步规模，不是要求", counts)
        self.assertIn("不强迫 A—B—A—B 轮换", counts)
        self.assertIn("不要求各线篇幅相等", counts)
        self.assertIn("不按固定章数报警", module)

    def test_no_hard_rule_creeps_in(self):
        text = read(MODULE) + read(TEMPLATE)
        self.assertTrue(text)
        for pattern in (r"(必须|务必|一定要)[^。；\n]{0,12}(切换|轮换|交汇|悬念|反派|对手|视角)",
                        r"(每|隔)[^。；\n]{0,6}章(必须|务必|一定)",
                        r"(副线|支线|暗线)(必须|务必|一定要)"):
            self.assertIsNone(re.search(pattern, text), pattern)


class Switching(unittest.TestCase):
    def test_a_switch_may_leave_at_a_result_not_only_at_a_cliffhanger(self):
        part = section(read(MODULE), "按阅读收益切换")
        self.assertIn("每次切换都要说得出它此刻增加了什么", part)
        self.assertIn("局部兑现、一个决定、一个结果、关系变化或余韵处切走", part)
        self.assertIn("悬停是工具之一，不能一再用别的线推迟读者正在等的答案", part)
        self.assertIn("不再换一条线接着拖", part)

    def test_each_switch_answers_the_other_side(self):
        part = section(read(MODULE), "按阅读收益切换")
        self.assertIn("每次切换补上对方的一步、推动下一次应对，而不是轮流交代各人的近况", part)

    def test_offstage_lines_keep_moving_without_rescues_from_nowhere(self):
        part = section(read(MODULE), "按阅读收益切换")
        self.assertIn("镜头没照到的人，在故事里并没有停下", part)
        self.assertIn("不能凭空补出决定胜负的新能力、新盟友或关键行动", part)
        self.assertIn("简短接上它的停点，不整段重述", part)
        self.assertIn("不要求每次打日期标签", part)


class KnowledgeAcrossLines(unittest.TestCase):
    def test_news_has_four_times(self):
        part = section(read(MODULE), "信息怎样跨线传播")
        self.assertIn("事件发生、消息发出、消息送到、读者看到，是四个时间", part)
        self.assertIn("分开记三层：作者确认的真相，读者已经看到的，各个人物当时知道、误信或猜测的", part)

    def test_what_the_author_or_reader_knows_is_not_what_a_character_knows(self):
        part = section(read(MODULE), "信息怎样跨线传播")
        self.assertIn("作者知道、读者看过，都不等于人物知道", part)
        self.assertIn("要等眼线在某个时刻、经某个渠道把话报回去", part)
        self.assertIn("主角也不因为读者知道有眼线，就自动识破", part)

    def test_the_narrator_keeps_the_licence_the_book_chose(self):
        part = section(read(MODULE), "信息怎样跨线传播")
        self.assertIn("叙述者的权限照作品已选的来", part)
        self.assertIn("第三人称限知", part)
        self.assertIn("明确用全知叙述的，不拿单个人物的认知范围去误报越界", part)

    def test_a_dark_line_needs_no_view_from_the_hidden_opponent(self):
        part = section(read(MODULE), "信息怎样跨线传播")
        self.assertIn("暗线也不等于要切到幕后对手的视角", part)
        self.assertIn("不等于要写出对手的内心或公布身份", part)
        self.assertIn("不等于读者也完全不知道", part)
        self.assertIn("可能带来紧张，但不是保证", part)
        self.assertIn("行动窗口", part)


class TimeAxis(unittest.TestCase):
    def test_unknown_times_stay_unknown(self):
        part = section(read(MODULE), "先排事件，再排披露")
        self.assertIn("不知道的时间写未知，不为填表编日期", part)
        self.assertIn("不能据此补出别的日期的既成事件", part)
        self.assertIn("交汇之前倒推赶路、等待、准备和恢复是否来得及", part)

    def test_meanwhile_only_for_what_is_simultaneous(self):
        part = section(read(MODULE), "先排事件，再排披露")
        self.assertIn("“与此同时”只写确实同时的场面", part)
        self.assertIn("一条线写一天、另一条线概述一个月都可以", part)


class WhatALineIsFor(unittest.TestCase):
    def test_a_subplot_need_not_help_the_protagonist(self):
        part = section(read(MODULE), "先判断要不要加一条线")
        self.assertIn("副线不必直接帮主角", part)
        self.assertIn("暂时离开主角，本身不是删线的理由", part)
        self.assertIn("也按本书的承诺判断", part)

    def test_a_line_has_to_earn_its_place(self):
        part = section(read(MODULE), "先判断要不要加一条线")
        self.assertIn("只为交代“某人此刻在做什么”不开线", part)
        self.assertIn("短暂的补充不必升级成长期副线", part)


class Convergence(unittest.TestCase):
    def test_prepared_collides_and_leaves_consequences(self):
        part = section(read(MODULE), "交汇：先铺垫，再碰撞，再留下后果")
        self.assertTrue(part)
        self.assertIn("谁此前的选择促成了它", part)
        self.assertIn("碰撞中的关键选择由谁做", part)
        self.assertIn("之后谁改变了决定、失去或得到了什么，哪些问题还留着", part)

    def test_convergence_is_not_only_a_meeting(self):
        part = section(read(MODULE), "交汇：先铺垫，再碰撞，再留下后果")
        self.assertIn("交汇不只有人物碰面", part)
        self.assertIn("几条线一直没碰面，不自动说明某条线没用", part)
        self.assertIn("偶遇可以引出故事，重大结果仍由人物的选择和行动承担", part)

    def test_deadlines_have_mechanisms_and_outline_gaps_stay_open(self):
        module = read(MODULE)
        part = section(module, "交汇：先铺垫，再碰撞，再留下后果")
        self.assertIn("期限和赌注要有机制", part)
        self.assertIn("列为待展开的场景，不直接判定交汇不可能", part)
        self.assertIn("不替作者指定内鬼、密探或证人", section(module, "核查与交付"))


class RevisionRegression(unittest.TestCase):
    def test_dependent_lines_are_checked_and_one_event_is_counted_once(self):
        part = section(read(MODULE), "改稿后沿跨线依赖回查")
        self.assertIn("沿用同一个事件编号", part)
        self.assertIn("不重复记账", part)
        self.assertIn("只查本轮动到的线和依赖范围", part)
        self.assertIn("](continuity.md)“修订后的回归核对”", part)


class Worksheet(unittest.TestCase):
    def test_it_can_be_trimmed_and_shares_one_record(self):
        template = read(TEMPLATE)
        self.assertIn("不要求每场都填三张卡", template)
        self.assertIn("不另建与事实账竞争的“真相库”", template)
        for heading in ("## 小表", "## 线卡", "## 事件与披露", "## 交汇卡"):
            self.assertIn(heading, template)
        self.assertIn("“本场的叙事作用”和“对其他线的实际影响”分开写", template)

    def test_no_field_is_prefilled(self):
        template = read(TEMPLATE)
        fields = [line for line in template.splitlines() if line.startswith("- ")]
        self.assertGreater(len(fields), 20)
        self.assertEqual([line for line in fields if not line.endswith("：")], [])
        rows = [line for line in template.splitlines() if line.startswith("|") and "---" not in line]
        data = rows[1:]
        self.assertTrue(data)
        self.assertEqual([line for line in data if line.replace("|", "").strip()], [])


class Example(unittest.TestCase):
    def test_the_example_is_new_and_tracks_the_news(self):
        part = section(read(MODULE), "原创微型设计")
        self.assertIn("不是材料案例或用户的小说", part)
        table = [line for line in part.splitlines() if line.startswith("| ") and "---" not in line]
        self.assertEqual(len(table), 5)
        self.assertIn("报信人", part)
        self.assertIn("不会凭空多出一根新主索", part)
        self.assertIn("不算已经核过物理上可行", part)


class SourceAndExport(unittest.TestCase):
    def test_the_source_is_recorded(self):
        module = read(MODULE)
        last = ([line for line in module.splitlines() if line.strip()] or [""])[-1]
        self.assertTrue(last.startswith("来源：2026-10-20"), last)
        self.assertIn("不复制教程所附人物或情节", last)
        notes = read("assets/third-party/SOURCE-NOTES.md")
        row = next((line for line in notes.splitlines() if "多线并行时间线" in line), "")
        self.assertIn("](../../references/parallel-timelines.md)", row)
        self.assertIn("未附教程原文、图片或其小说案例", row)

    def test_the_sale_export_carries_module_and_worksheet(self):
        spec = importlib.util.spec_from_file_location("r526_export", SKILL / "scripts" / "export_portable.py")
        exporter = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(exporter)
        self.assertLessEqual({MODULE, TEMPLATE}, set(exporter.SALE_FILES))
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "sale.zip"
            proc = subprocess.run([sys.executable, "-I", "-B", str(SKILL / "scripts" / "export_portable.py"), str(target),
                                   "--mode", "sale"], capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
            archive = zipfile.ZipFile(target)
            names = archive.namelist()
            self.assertIn("novel-workshop/" + MODULE, names)
            self.assertIn("novel-workshop/" + TEMPLATE, names)
            portable = archive.read("portable-novel-workshop.md").decode("utf-8")
            self.assertIn("# 多线并行：分线、跨线知情、切换与交汇", portable)
            self.assertIn("# 多线并行工作表", portable)

    def test_each_judgment_lives_in_one_module(self):
        texts = {path.name: path.read_text(encoding="utf-8") for path in (SKILL / "references").glob("*.md")}
        for phrase in ("事件发生、消息发出、消息送到、读者看到", "暗线也不等于要切到幕后对手的视角", "两三条线、隔两到五章"):
            homes = sorted(name for name, text in texts.items() if phrase in text)
            self.assertEqual(homes, ["parallel-timelines.md"], phrase)


if __name__ == "__main__":
    unittest.main()

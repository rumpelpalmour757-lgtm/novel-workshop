# 小说实感与去AI味引擎 v17.1.2 · 使用说明

全流派通用的「怎么写」：砍掉AI腔、翻译腔和说明书腔，换成生理实感、器物包浆和中式白描。由你的二百层实感引擎（v16、v17）整理而来：内核每次都挂，六个场景弹药包按需挂，一次至多两个。

同一套文件三种用法：当 Claude 技能用；贴进任何AI用；放进你的小说项目里用。和「都市高武风格引擎库」一起用的分工见文末。

## 包里有什么

```
universal-novel-realism-engine/
├── ENGINE.md                    Claude 读的工作流程（别的AI也能读）
├── README.md                   本说明
├── references/
│   ├── kernel.yaml             内核：三条铁律、语域开关、八条指令、写法细则、22道门禁
│   ├── cartridges/             六个弹药包：搏杀、手艺、查案、市井、情感、结构
│   ├── rules.yaml              80条正则禁令、节奏硬指标
│   ├── 与题材包同用.md          和题材包同用时的分工与冲突表
│   ├── interop.yaml            同用时脚本的设置
│   ├── state_schema.yaml       跨章状态各栏的含义
│   ├── layers.yaml、layers.md  原版200层的结构，和它们现在挂在哪
│   └── library.json            整库单文件，给脚本和别的程序读
├── scripts/
│   ├── mount.py                按正文或场景词推荐弹药包
│   ├── lint_text.py            查正文：禁令、语域防火墙、硬指标
│   ├── export_prompt.py        导出提示词，贴进任何AI
│   ├── build_library.py        改过yaml后校验并重建
│   └── common.py               上面几个脚本共用
├── templates/
│   └── 状态追踪.yaml            跨章状态追踪表：复制到你的小说项目
├── prompts/                    现成提示词，不用装任何东西
│   ├── 00_内核.md
│   ├── 01–06_内核+弹药包.md
│   └── 07_与都市高武同用.md
└── docs/
    ├── 整理说明.md              这一版改了什么、为什么
    └── 改动明细.md              逐个文件的改动
```

## 用法一：当 Claude 技能用

- **Claude 应用（网页、桌面、手机）**：上传 `universal-novel-realism-engine-v17.1.2.zip`，再到 Customize > Skills 里打开它；需要开启代码执行。同名的 `.skill` 文件内容完全一样。见 [How to create custom skills](https://support.claude.com/en/articles/12512198)。
- **Claude Code**：把整个文件夹放到 `~/.claude/skills/`（所有项目可用）或小说项目的 `.claude/skills/`（只在这个项目可用）。见 [Skills 文档](https://code.claude.com/docs/en/skills)。

装好以后直接说「把这段去AI味」「精修第十二章」「这段太像说明书，改得有人味一点」。

## 用法二：贴进任何AI（不用装任何东西）

1. 打开 `prompts/` 里的一个文件，全文复制：
   - 只改句法、去AI腔：`00_内核.md`；
   - 有明确场景：`01–06`，比如打斗戏用 `01_内核+搏杀.md`，饭桌戏用 `05_内核+情感.md`；
   - 写都市高武：`07_与都市高武同用.md`，和都市高武那边的提示词一起贴。
2. 粘到对话最前面，或者那个AI的系统提示词、自定义指令里。
3. 接着发要改的正文，或要写的大纲。

## 用法三：放进你的小说项目

```
我的小说/
├── 本书设定.yaml                 都市高武包的设定档，可以加一段 realism（见下）
├── 状态追踪.yaml                 从 templates/状态追踪.yaml 复制过来
├── 正文/第012章.txt
├── urban-martial-style-engines/
└── universal-novel-realism-engine/
```

在 `本书设定.yaml` 末尾加一段，本包的脚本用 `--profile` 就能读到：

```yaml
realism:
  register: 现代              # 现代、古风、废土
  pack: urban-martial         # 同时在用的题材包；不用就删掉这行
  allow: []                   # 撞了禁词的人名、专有名词
  skip: []                    # 这本书不要的禁令编号，比如 RULE_51
```

每章（在「我的小说」目录下运行）：

```bash
# 写之前：这一章挂哪个弹药包
python universal-novel-realism-engine/scripts/mount.py 正文/第012章.txt

# 写完：查AI味（都市高武那边的 lint_text.py 另外查禁用词）
python universal-novel-realism-engine/scripts/lint_text.py 正文/第012章.txt --profile 本书设定.yaml

# 要在别的AI里写下一章：导出规范，带上跨章状态
python universal-novel-realism-engine/scripts/export_prompt.py --profile 本书设定.yaml --from 正文/第012章.txt --state 状态追踪.yaml -o 第013章规范.md
```

写完一章，把 `状态追踪.yaml` 里的账目、伤病、称呼、已亮相的破绽更新一遍。用 Claude 写时，它会自己读这张表、写完更新。

## 常用命令

以下命令在本包目录里运行；在别的目录运行时，把 `scripts/` 换成本包的完整路径。

| 要做什么 | 命令 |
| --- | --- |
| 看六个弹药包 | `python scripts/mount.py --list` |
| 按正文推荐弹药包 | `python scripts/mount.py 第012章.txt` |
| 按场景词推荐 | `python scripts/mount.py --scene 审讯 当铺` |
| 查正文 | `python scripts/lint_text.py 第012章.txt --register 现代` |
| 和都市高武同用时查 | `python scripts/lint_text.py 第012章.txt --pack urban-martial` |
| 人名撞了禁词 | 加 `--allow 林灵瞳`，或写进设定档 realism.allow |
| 只看错误、不想看某条 | 加 `--skip RULE_51`；`--strict` 让警告也算问题 |
| 导出提示词 | `python scripts/export_prompt.py --register 现代 --cartridges 1 5 -o 规范.md` |
| 改过yaml后重建 | `python scripts/build_library.py` |

lint_text.py 的结论分三档：错误（必改，含每千字指标超标）、警告（尽量改）、提示（看情况）。退出码 0 表示没有错误，1 表示有，可以接进你自己的脚本。

## 和都市高武风格引擎库一起用

两个包分工：都市高武管「写什么」——术语、战力刻度、数字从哪说出、机构、主角身份锁；本包管「怎么写」——句法、标点、排版、套话、生理细节。拿本包的80条禁令扫过都市高武的143个引擎，撞上的地方（「的」字链、重心、兽尸、感叹号、章末钩子等）和同用时的写法列在 `references/与题材包同用.md`。两边的 lint_text.py 都跑一遍。

## 环境要求

- Python 3.8 以上。mount.py、lint_text.py、export_prompt.py 只用标准库。
- build_library.py 和 `--profile` 要读 yaml，需要 PyYAML：`pip install pyyaml`。
- 正文用 UTF-8 或 GBK（Windows 记事本的老格式）都能读。
- 不装 Python 也能用：`prompts/` 里的现成提示词和所有 yaml 都能直接读、直接贴。

## 改库

- **改禁令、指标**：改 `references/rules.yaml`，运行 `python scripts/build_library.py`。每条禁令可以带 `example`（必中样例和必不中的反例），重建时自动验证，正则写错了会直接报出来。
- **改写法、门禁**：改 `references/kernel.yaml` 或对应弹药包，再重建。
- **原版层号**：`references/layers.md` 能查到每一层现在挂在内核还是哪个弹药包。

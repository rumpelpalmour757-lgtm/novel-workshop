"""Conservative dialogue candidates with optional stylistic reading hints.

A regex match is an editorial REVIEW, never proof of an ungrammatical sentence,
English origin, or machine authorship. No text is changed by this scanner.
Rule IDs stay stable because book configs name them (enabled_rules, scene
overrides); the words inside an ID are not a verdict. Each rule carries a plain
Chinese name, which is what the patch request shows the model.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
import re
from typing import Iterable, List, Mapping, Optional, Pattern, Sequence, Tuple

from dialogue_core import extract_dialogues
from genre_profiles import GenreLintProfile, normalize_scene_exemptions

DEFAULT_NAMES: Tuple[str, ...] = ()


@dataclass(frozen=True)
class AntipatternRule:
    rule_id: str
    category: str
    name: str
    severity: str
    pattern: Pattern[str]
    exempt_cold_protagonist: bool
    description: str
    fix_recipe: str
    style_hint: bool = True


@dataclass
class DialogueDefect:
    para_index: int
    rule_id: str
    category: str
    severity: str
    matched_span: str
    full_quote: str
    description: str
    fix_recipe: str
    quote_id: str = ""
    quote_index: int = 0
    start: int = -1
    end: int = -1
    source_quote: str = ""
    speaker: str = "未知"
    confidence: str = "unknown"
    name: str = ""


# Never matches: the words SYN_01 looks for come from the book config
# (suspicious_expressions), so an unconfigured scan checks no wording at all.
_NO_WORDS = re.compile(r"(?!)")

# Keep stable rule IDs for consumers. Only the book's own wording list runs by
# default; broad style patterns require include_style_hints=True.
DIALOGUE_ANTIPATTERN_REGISTRY: List[AntipatternRule] = [
    AntipatternRule(
        "SYN_01_DEGREE_ACT_VERB", "WORDING", "本书列出的待复核措辞", "REVIEW",
        _NO_WORDS, False,
        "命中本书配置里列出的待复核措辞；请结合人物口吻和上下文核对搭配，不能据此认定语病。",
        "核对要表达的用途与动作；需要改写时保留物品、动作及事实。",
        style_hint=False,
    ),
    AntipatternRule(
        "SYN_02_BA_GEI_FORMAL_VERB", "WORDING", "把字句用词复核", "REVIEW",
        re.compile(r"把[^，。！？“”]{1,8}给(?P<verb>摧毁|解除|修复|击毙|耗尽|阻断|撤离|固定|拦截|清理|排查|切断|剥离|粉碎|终止|闭合)了"), False,
        "口语结构中出现技术或书面用词；该搭配可以成立，仅需核对是否符合当前人物。",
        "先判断人物是否习惯这样说；表达准确时保留，不强制改成单音节词或改变动作结果。",
    ),
    AntipatternRule(
        "SYN_03_SLANG_FORMAL_PREDICATE", "WORDING", "同句语域复核", "REVIEW",
        re.compile(r"(?:这|那)(?:玩意儿?|家伙|东西|破烂)[^，。！？“”]{0,4}(?:正在(?:释放|进行|发生|产生)|具备|拥有|处于|呈现|导致|尚且|无法)"), False,
        "口语指称与技术谓语并用；不能仅凭词类判断表达不自然。",
        "通读整句及相邻台词，按人物表达习惯决定保留或调整，保留原有技术含义。",
    ),
    AntipatternRule(
        "COMP_01_BARE_MONOSYLLABIC_VERB", "SHORT_FORM", "省略式祈使句复核", "REVIEW",
        re.compile(r"(?:^|[。！？])\s*(?P<verb>[借给拿卖买退换送收留带抬推拉扶撬拆剪洗包缠])[，。]"), True,
        "简短祈使句可能省略已知宾语；省略本身不是语法错误。",
        "检查读者能否从现场知道所指；能理解时保留，需要补充时仅补已成立的信息。",
    ),
    AntipatternRule(
        "COMP_02_IMPERATIVE_TRIPLE_CHOP", "SHORT_FORM", "连续短句节奏复核", "REVIEW",
        re.compile(r"(?:^|[。！？])[\u4e00-\u9fa5]{2}[，。][\u4e00-\u9fa5]{2}[，。][\u4e00-\u9fa5]{2,4}[。！]"), True,
        "连续短句需要结合指令场景判断节奏；紧急指令可以保留。",
        "核对每次停顿的作用；只有语义连续且停顿多余时调整连接，不改变指令顺序。",
    ),
    AntipatternRule(
        "COMP_03_SUBJECTLESS_STATUS_PAIR", "SHORT_FORM", "简短状态并列复核", "REVIEW",
        re.compile(r"(?:^|[。！？])(?P<n1>[\u4e00-\u9fa5]{2})(?P<v1>[\u4e00-\u9fa5]了|没了|坏了|断了|塌了)[，。](?P<n2>[\u4e00-\u9fa5]{1,2})(?P<v2>[\u4e00-\u9fa5]不[\u4e00-\u9fa5]|没法[\u4e00-\u9fa5]|不能[\u4e00-\u9fa5])[。]"), True,
        "命中简短的状态并列结构；汇报险情时这种说法可以自然成立。",
        "检查前后关系是否已经清楚；不为连接句子补写堵门、损坏等未经确认的原因。",
    ),
    AntipatternRule(
        "COMP_04_COORDINATE_REPLY", "SHORT_FORM", "简短方位回答复核", "REVIEW",
        re.compile(r"^(?![^。]*[呢吧啊嘛哟喽呗哈呐])在[你我他它]?[\u4e00-\u9fa5]{2,4}。$"), True,
        "简短方位回答没有命中列出的语气词；这不等于缺少人情味或存在语病。",
        "结合提问与人物关系判断是否需要补充；不强加语气词，不添加动作。",
    ),
    AntipatternRule(
        "TRANS_01_ROBOTIC_CONCESSION", "SENTENCE_FORM", "许可与宽慰句复核", "REVIEW",
        re.compile(r"(?:弄脏|[勒压拽踩撞靠顶蹭])[\u4e00-\u9fa5]{0,3}我[\u4e00-\u9fa5]{0,2}(?:也行|也没关系|也是可以的|也无所谓)"), False,
        "命中许可或宽慰表达；这种句式本身可以成立。",
        "核对说话人的意图和身体状态；原句通顺时保留，不自动加入具体搀扶动作或夸张口气。",
    ),
    AntipatternRule(
        "TRANS_02_BODY_POSSESSIVE_REDUNDANCY", "SENTENCE_FORM", "身体部位指称复核", "REVIEW",
        re.compile(r"(?:小心|当心|注意|抬起|低下|伸出|缩回|管好|松开|握紧|搭在|抓住)(?:你的|我的)(?P<part>手|脚|头|腿|胳膊|脑袋|脖子|肩膀|眼睛|腰)"), False,
        "身体部位前出现物主代词；多人同场或强调归属时可能必要。",
        "判断是否有指代作用，仅在删除不会改变所指或强调时考虑精简。",
    ),
    AntipatternRule(
        "TRANS_03_ENGLISH_IMPERATIVE_CALQUE", "SENTENCE_FORM", "请求与命令表达复核", "REVIEW",
        re.compile(r"(?:我需要你(?:去|先|立刻)?|我要你(?:立刻|马上)?去|你最好(?:先)?来?看(?:一)?下这个|告诉我你(?:看到了什么|是怎么想的)|听着，(?:伙计|朋友)|嘿，我是说)"), False,
        "命中显式请求或命令结构；这些句式本身可用于自然汉语。",
        "按人物地位、语气和场景复核；不自动将请求改为命令，也不改变紧迫程度。",
    ),
    AntipatternRule(
        "TRANS_04_EXPLICIT_MENTAL_VERB", "SENTENCE_FORM", "感知表达复核", "REVIEW",
        re.compile(r"我(?:感到|感觉到|注意到|察觉到|意识到)[^，。！？“”]{2,10}|这让我(?:觉得|感到)[^，。！？“”]{2,8}"), False,
        "命中显式感知或心理表达；汇报、辨认与强调信息来源时可以保留。",
        "先判断是否有说明信息来源的作用，不把主观感受自动改成客观事实。",
    ),
    AntipatternRule(
        "TRANS_05_FORMAL_CONNECTIVES_IN_SPEECH", "SENTENCE_FORM", "关联词口吻复核", "REVIEW",
        re.compile(r"(?:鉴于|尽管[^，。！？]{2,10}但(?:是)?|不仅[^，。！？]{2,10}而且|换句话说|从某种意义上|老实说，我认为)"), False,
        "出现较显式的逻辑衔接词；是否合适取决于人物和发言场合。",
        "通读上下文后判断是否精简，保留转折、因果与信息层次。",
    ),
    AntipatternRule(
        "TRANS_06_SHI_DE_JUDGMENT_ABUSE", "SENTENCE_FORM", "判断句语气复核", "REVIEW",
        re.compile(r"(?:这|那|它|里头|进去|出来)是(?:很|非常|极其|相当|十分|完全)(?P<adj>危险|安全|锋利|坚固|沉重|困难|麻烦|致命|明显|清楚)的[。！]"), False,
        "命中强调性的判断结构；『是……的』本身可以成立。",
        "核对强调是否有作用；不把程度判断改成更强的结论。",
    ),
]

WORDING_RULE_ID = "SYN_01_DEGREE_ACT_VERB"


def wording_pattern(expressions: Iterable[str]) -> Pattern[str]:
    """The book's wording list as one literal pattern; an empty list matches nothing."""
    if isinstance(expressions, str):
        raise ValueError("suspicious_expressions 请传词组数组，而不是字符串")
    words = list(expressions)
    if any(not isinstance(w, str) or not w.strip() for w in words):
        raise ValueError("suspicious_expressions 只能包含非空字符串")
    if len(set(words)) != len(words):
        raise ValueError("suspicious_expressions 不能有重复词组")
    if not words:
        return _NO_WORDS
    return re.compile("|".join(re.escape(w) for w in sorted(words, key=lambda w: (-len(w), w))))


# Retained for callers that used the old extraction constant. Extraction itself
# is shared with the voice scanner and preserves a distinct record per quote.
RE_EXTRACT_QUOTES = re.compile(r"“(?P<quote>[^“”]+)”")


def scan_dialogue_antipatterns(
    paragraphs: List[str],
    cold_protagonist_names: Tuple[str, ...] = (),
    *,
    names: Sequence[str] = DEFAULT_NAMES,
    aliases: Optional[Mapping[str, str]] = None,
    speaker_overrides: Optional[Mapping[Tuple[int, int], str]] = None,
    include_style_hints: bool = False,
    genre_profile: Optional[GenreLintProfile] = None,
    style_exempt_quotes=(),
    suspicious_expressions: Iterable[str] = (),
) -> List[DialogueDefect]:
    """Return candidates, preserving quote identity and attribution confidence.

    By default only the book's own wording list (suspicious_expressions, literal
    strings) is checked; with no list, no wording is checked. Broad editorial
    patterns are opt-in and their REVIEW results are not automatic corrections.
    Unknown speakers receive no protagonist exemption. A name merely appearing
    in narration cannot grant another character's dialogue that exemption.
    Genre settings filter enabled rules without enabling broad style hints.
    Genre clause-length and marker settings serve the voice scanner's density
    hint; they do not replace the independent patterns registered here.
    Scene exemptions must explicitly map each quote_id to eligible rule IDs;
    neither other rules in that quote nor tactical keywords grant exemptions.
    Characters in cold_protagonist_names (people of few words, people giving
    orders) get none of the short-form hints COMP_01 to COMP_04 on their
    confirmed lines.
    """
    rule_ids = [rule.rule_id for rule in DIALOGUE_ANTIPATTERN_REGISTRY]
    if len(rule_ids) != len(set(rule_ids)):
        raise ValueError("检测规则 rule_id 不可重复")
    if genre_profile is not None and not isinstance(genre_profile, GenreLintProfile):
        raise ValueError('genre_profile 必须是 GenreLintProfile 或 None')
    style_exempt = normalize_scene_exemptions(style_exempt_quotes)
    words = wording_pattern(suspicious_expressions)
    selected_rules = [rule if rule.rule_id != WORDING_RULE_ID else replace(rule, pattern=words)
                      for rule in DIALOGUE_ANTIPATTERN_REGISTRY
                      if genre_profile is None or rule.rule_id in genre_profile.enabled_rules]
    known_names = tuple(dict.fromkeys((*names, *cold_protagonist_names)))
    defects: List[DialogueDefect] = []
    for dialogue in extract_dialogues(
        paragraphs, known_names, aliases=aliases, speaker_overrides=speaker_overrides
    ):
        is_confirmed_cold = (
            dialogue.confidence in ("explicit", "manual")
            and dialogue.speaker in cold_protagonist_names
        )
        for rule in selected_rules:
            if rule.style_hint and not include_style_hints:
                continue
            if rule.rule_id in style_exempt.get(dialogue.quote_id, ()):
                continue
            if rule.exempt_cold_protagonist and is_confirmed_cold:
                continue
            for match in rule.pattern.finditer(dialogue.text):
                defects.append(DialogueDefect(
                    para_index=dialogue.para_index,
                    rule_id=rule.rule_id,
                    category=rule.category,
                    severity="REVIEW",
                    matched_span=match.group(0),
                    full_quote=dialogue.quote,
                    description=rule.description,
                    fix_recipe=rule.fix_recipe,
                    quote_id=dialogue.quote_id,
                    quote_index=dialogue.quote_index,
                    start=dialogue.start,
                    end=dialogue.end,
                    source_quote=dialogue.text,
                    speaker=dialogue.speaker,
                    confidence=dialogue.confidence,
                    name=rule.name,
                ))
    return defects

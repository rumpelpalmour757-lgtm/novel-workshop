#!/usr/bin/env python3
"""r5.55: learning editorial judgment from revision records, the smallest form.

The package gets one page, references/editorial-judgment.md, and one template, assets/editorial-judgment-template.json.
They say what one revision case keeps (one place, with versions and sources), how three kinds of evidence that are easily
lost are kept (a smooth change that lost something, a sentence the author wanted kept, a first wrong change and how it
was put right), the judgment card (judgment, grounds that go back to the text, conditions, exceptions, counter-examples,
what it does not look at), how a card is drawn out, when it is enough for a candidate and how a thin one is marked, how
its status moves, the self-audit at the complete-draft stage before the teacher (a list only, the draft is not changed),
the reconciliation when the teacher's return comes back, and the hit ledger. It is optional: only when the author asks.

These tests check that the page is there, that it can be reached from the entry and from the stages it serves, that its
links, the sections it names, the scripts and options it mentions exist, that the template parses and its placeholders
are neutral, that both files go into the sale package, and that the page has no count threshold for calling prose wrong.
They also run the record behaviour the page states on newly written neutral text. They do not show that a self-audit
by judgment cards helps: the page says so, and it has not been tried on a real chapter.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest
import zipfile

sys.dont_write_bytecode = True
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
PAGE = "references/editorial-judgment.md"
TEMPLATE = "assets/editorial-judgment-template.json"
TITLE = "从改稿记录里学编辑判断"
LINK = re.compile(r"\]\(([^)#\s]+)")
NAMED = re.compile(r"\]\(([^)#\s]+\.md)\)((?:“[^”]+”)+)")
TICKS = re.compile(r"`([^`]+)`")


def read(rel):
    return (SKILL / rel).read_text(encoding="utf-8")


def load(name):
    spec = importlib.util.spec_from_file_location("r555_" + name, SKILL / "scripts" / (name + ".py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(script, *args):
    proc = subprocess.run([sys.executable, "-I", "-B", str(SKILL / "scripts" / script), *map(str, args)],
                          capture_output=True, text=True, encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


def section(text, heading):
    start = text.find("\n## " + heading)
    if start == -1:
        return ""
    end = text.find("\n## ", start + 4)
    return text[start:end if end != -1 else len(text)]


def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


class ThePage(unittest.TestCase):
    def setUp(self):
        self.text = read(PAGE)

    def test_it_is_there(self):
        self.assertTrue(self.text.startswith("# " + TITLE + "\n"))
        headings = [l for l in self.text.splitlines() if l.startswith("## ")]
        self.assertEqual(headings, ["## 谁来开、记在哪", "## 一条改稿案例记什么", "## 三种容易丢的证据", "## 判断卡",
                                    "## 交教师以前的自审", "## 教师意见回来以后的对账", "## 命中账", "## 用现有的记录怎么记",
                                    "## 边界"])
        self.assertEqual([l for l in self.text.splitlines() if l.startswith("### ")],
                         ["### 提炼的做法：先看原因，再写判断", "### 够候选的门槛，和“单薄”", "### 状态怎么走"])

    def test_optional_and_not_verified(self):
        top = self.text[:self.text.index("\n## ")]
        for phrase in ("这是可选做法，默认关着，作者明确要求才开", "没开的不读这一页、不建判断卡",
                       "照卡自审有没有用，没有验证过", "[SKILL.md](../SKILL.md)“可选模块：默认关着”"):
            self.assertIn(phrase, top)
        switch = section(self.text, "谁来开、记在哪")
        # r5.56: "不放进技能目录" was the r5.55 wording, written when no author's record was to live in the skill folder.
        # The author's correction records now live there (assets/project-packs/_author/), so the sentence says instead
        # that the cards go with the book's materials and not into that folder; the cards are still not in the package.
        for phrase in ("记在作品档案“协作策略”一行，带作者原话和日期", "不因为开了学习循环或示范记忆就开这一项",
                       "判断卡文件跟着这本书的资料放，不放进作者改法累计的 `assets/project-packs/_author/`",
                       "通用包只带这一页和模板，不带哪本书的卡"):
            self.assertIn(phrase, switch)
        self.assertNotIn("不放进技能目录", switch)

    def test_a_case_and_the_three_kinds_of_evidence(self):
        case = section(self.text, "一条改稿案例记什么")
        rows = [l.split("|")[1].strip() for l in case.splitlines() if l.startswith("| ") and not l.startswith("| ---")]
        self.assertEqual(rows, ["记什么", "原稿句", "提过的改法", "作者的取舍", "实际落稿", "改后的复查"])
        for phrase in ("一条案例管一处", "记录没写明的写“未知”，不猜", "标成推断", "一层都没有的写“记录里没写”",
                       "不要作者填表"):
            self.assertIn(phrase, case)
        kinds = section(self.text, "三种容易丢的证据")
        for phrase in ("`smooth_but_lossy`", "`keep_original`", "`wrong_then_corrected`", "丢了东西是谁说的",
                       "只是两稿对读看出来的，写“对读”", "被否掉的改法也留着", "`keep` 段", "依据分六种",
                       "`attempts` 段", "谁指出来的", "三种各有一条最低要求，达不到就不标成那一种"):
            self.assertIn(phrase, kinds)
        self.assertIn("整章定稿算不算对其中每一句的认可，作者没说以前按不算记", kinds)

    def test_the_kinds_of_change_are_the_sentence_modules(self):
        language = section(read("references/sentence-craft.md"), "语感：搭配、照应与叫法")
        self.assertIn("不另立分类", self.text)
        for word in ("纯表达", "消歧", "补信息", "改状态"):
            self.assertIn(word, self.text)
            self.assertIn("**" + word + "**", language)

    def test_the_card(self):
        card = section(self.text, "判断卡")
        rows = [l.split("|")[1].strip() for l in card.splitlines() if l.startswith("| ") and not l.startswith("| ---")]
        for field in ("判断", "依据", "依据的案例", "适用条件", "例外", "反例", "不看什么", "默认处置", "状态", "证据厚薄",
                      "命中账", "改版记录"):
            self.assertIn(field, rows)
        for phrase in ("句子里要有“因为”", "每条依据指回案例编号和原文出处，引文能回原文逐字核对", "至少一条讲这句话的作用，至少一条讲场面",
                       "没找到就写“找过，没找到”", "字数、词频、句数、有没有某个词，都不是依据",
                       "单薄的卡只许“只标出来请作者看”", "旧版留着，不悄悄改"):
            self.assertIn(phrase, card)
        # r5.55 review: "what it does not look at" is required, word for word in its row
        row = next(l for l in card.splitlines() if l.startswith("| 不看什么 |"))
        self.assertEqual(row.split("|")[3].strip(), "必填。字数、词频、句数、有没有某个词，都不是依据")

    def test_drawing_out_threshold_and_status(self):
        card = section(self.text, "判断卡")
        for phrase in ("一条一条看原因，不看句子长什么样", "先找反方向的", "把“因为”后面的话删掉",
                       "退回去重写", "这一步是自查，不算验证"):
            self.assertIn(phrase, card)
        for phrase in ("至少三条案例，来自至少两场不同的戏", "四类证据里至少占两类", "只有模型读者、模型评判、工坊自查说“丢了”的，不够",
                       "同一个模型说十次“丢了”，算一个来源", "达不到的标“单薄”", "只有一条案例的不做卡",
                       # r5.55 review: the fourth and fifth conditions and what a thin card may do
                       "4. 核心那一句不只靠一场戏撑着。", "5. 例外和反例那一栏写过了。",
                       "- 处置只许“只标出来请作者看”，不出候选改法，也不写“保留”去拦人；",
                       "- 工坊不主动提请作者认可它，作者自己要认可的另说；"):
            self.assertIn(phrase, card)
        for phrase in ("沉默、接着要下一章、整章定稿、自查通过，都不算", "和他当时看的是哪份对照", "写进哪一份由作者定",
                       "一步一步走，不能从候选直接写进规则"):
            self.assertIn(phrase, card)

    def test_the_self_audit_is_at_the_draft_and_changes_nothing(self):
        audit = section(self.text, "交教师以前的自审")
        for phrase in ("[每章七阶段与作者确认](chapter-confirmation.md)第 4 阶段", "七个阶段不加不减",
                       "候选卡只列编号和标题", "候选卡的正文这时不读",
                       "初稿全文定下、记了哈希以后，才读候选卡", "自审只出单子，不改稿", "单子上的句子，拟处置只能是“保留原句”",
                       "任何状态的卡都不能拟改它们", "不硬套", "也写一行“没有”", "原样交教师（默认）",
                       "自审单默认不随稿交教师", "不算独立对上"):
            self.assertIn(phrase, audit)
        # r5.55 review: at stage 3 the candidate cards are listed by number and title only
        stages = read("references/chapter-confirmation.md")
        preparation = next(l for l in stages.splitlines() if l.startswith("| 3 `preparation` "))
        self.assertIn("候选判断卡只列编号和标题", preparation)
        self.assertNotIn("正文", preparation.split("候选判断卡")[1])
        self.assertIn("改后的复查要在 `rechecks` 里把自审那条也列上，不然不能 `finish`，自审项全都留着也一样", self.text)

    def test_reconciliation_and_the_ledger(self):
        reconcile = section(self.text, "教师意见回来以后的对账")
        for phrase in ("两边都标了的", "教师动了、自审没标的", "自审标了、教师没动的", "对账只摆事实，不替作者取舍",
                       "卡不能单独成为拒绝教师改动的理由", "[教师回传怎么审](teacher-review.md)"):
            self.assertIn(phrase, reconcile)
        ledger = section(self.text, "命中账")
        header = next(l for l in ledger.splitlines() if l.startswith("| 章 "))
        self.assertEqual([c.strip() for c in header.split("|")[1:-1]], ["章", "用上", "对上", "对不上", "没人动", "漏了", "出处"])
        for phrase in ("不算对上，作者没说话不等于认可", "账只记处数和出处，不算分", "升不升、停不停，作者看了定",
                       "“对不上”和“漏了”的每一处，同时记一条改稿案例"):
            self.assertIn(phrase, ledger)
        # r5.55 review: the table that turns the outcome into an entry, row by row
        table = [tuple(c.strip() for c in l.split("|")[1:-1]) for l in ledger.splitlines()
                 if l.startswith("| ") and not l.startswith("| ---") and len(l.split("|")) == 6]
        self.assertEqual(table, [
            ("自审的拟处置", "教师", "作者最后", "账上记"),
            ("保留原句", "要改", "没让改", "对上"),
            ("保留原句", "要改", "采纳了改动", "对不上"),
            ("保留原句", "没动", "自己改了", "对不上"),
            ("保留原句", "没动", "没表态", "没人动"),
            ("列出候选改法，或只标出来", "为同一个原因动了同一处", "采纳了（教师的、工坊的，或者自己另写）", "对上"),
            ("列出候选改法，或只标出来", "没动", "看了说要改", "对上"),
            ("列出候选改法，或只标出来", "没动", "明说原句要留", "对不上"),
            ("列出候选改法，或只标出来", "没动", "没表态", "没人动"),
            ("没标", "动了", "采纳了", "有卡的条件其实满足的，那张卡记“漏了”；没有卡管得着的，记成新案例的线索"),
            ("没标", "动了", "没采纳", "不记账，另记一条“提了没用上”的案例")])

    def test_boundaries(self):
        limits = section(self.text, "边界")
        for phrase in ("判断卡要作者看过卡和对照、明说认可，才写进本书规则", "不按字数、词频、句数判错",
                       "一条判断不许变成“见到某类句子就改”", "作者要求保留的句子，任何卡都不能拟改",
                       "通用包只带机制", "候选卡不进写作上下文"):
            self.assertIn(phrase, limits)

    def test_no_count_threshold_for_calling_prose_wrong(self):
        number = r"[0-9０-９一二两三四五六七八九十百千]+"
        prose = outside_code(self.text)
        # r5.55 review: comparisons such as 长于、大于 count as well
        compare = r"(超过|多于|少于|不到|不足|达到|高于|低于|满|长于|短于|大于|小于|多过|少过)"
        for pattern in (compare + r"\s*" + number + r"\s*个?(字|句|词|次)",
                        number + r"\s*个?(字|句|词|次)(以上|以下|以内|之内)",
                        r"(字数|句数|词频|句长|段长|频率|字|句)\s*" + compare):
            self.assertEqual(re.findall(pattern, prose), [], pattern)
        # "见到某类句子就改" only ever appears as what a card must not become
        self.assertEqual(prose.count("就改"), prose.count("见到某类句子就改"))
        self.assertNotIn("直接改", prose.replace("默认处置里没有“直接改”", ""))

    def test_no_internal_numbers(self):
        self.assertEqual(re.findall(r"(?<![A-Za-z0-9_])[A-Z]{1,3}-?\d{1,3}(?![A-Za-z0-9_])", self.text), [])

    def test_links_resolve_and_named_sections_exist(self):
        targets = LINK.findall(self.text)
        self.assertGreaterEqual(len(targets), 8)
        for target in targets:
            self.assertTrue((SKILL / "references" / target).resolve().is_file(), target)
        named = NAMED.findall(self.text)
        self.assertGreaterEqual(len(named), 4)
        for target, names in named:
            body = (SKILL / "references" / target).resolve().read_text(encoding="utf-8")
            headings = [l.lstrip("#").strip() for l in body.splitlines() if l.startswith("#")]
            for name in re.findall(r"“([^”]+)”", names):
                self.assertTrue(any(h.startswith(name) for h in headings) or "**" + name in body, (target, name))

    def test_scripts_events_and_options_exist(self):
        spans = TICKS.findall(outside_code(self.text))
        scripts = sorted({s for span in spans for s in re.findall(r"[a-z_]+\.py", span)})
        self.assertEqual(scripts, ["demonstration_memory.py"])
        code, out, err = run("demonstration_memory.py", "--help")
        self.assertEqual(code, 0, err)
        self.assertIn("check", out)
        code, loop_help, err = run("learning_loop.py", "--help")
        self.assertEqual(code, 0, err)
        code, gate_help, err = run("chapter_gate.py", "--help")
        self.assertEqual(code, 0, err)
        for word in ("review", "decide", "revise", "finish", "learn", "draft", "rechecks", "role", "mode", "writer",
                     "self_check", "teacher", "constraints", "conditions_checked", "exceptions_checked", "adopt",
                     "decline", "defer", "teacher_return_id", "present", "content"):
            self.assertIn("`" + word + "`", self.text, word)
            self.assertIn(word, loop_help + gate_help, word)
        for key in ("id", "issue", "evidence", "scope"):
            self.assertIn("`" + key + "`", self.text)
        self.assertIn("findings:[{id,issue,evidence,scope}]", loop_help)


def outside_code(text):
    return re.sub(r"```.*?```", "", text, flags=re.S)


class TheTemplate(unittest.TestCase):
    def setUp(self):
        self.data = json.loads(read(TEMPLATE))

    def test_it_parses_and_has_the_three_parts(self):
        self.assertEqual(self.data["schema"], "editorial-judgment/1")
        for part in ("note", "values", "revision", "judgment_card", "self_audit"):
            self.assertIn(part, self.data)
        self.assertEqual(self.data["revision"]["schema"], "revision-case/1")
        for key in ("kind", "about", "scene", "original", "proposals", "author", "keep", "attempts", "final", "rechecks",
                    "links", "gaps"):
            self.assertIn(key, self.data["revision"])
        for key in ("id", "title", "version", "judgment", "grounds", "cases", "conditions", "exceptions",
                    "counterexamples", "not_looked_at", "default_disposition", "status", "status_history", "evidence",
                    "used_in_distillation", "ledger", "rule_location", "versions"):
            self.assertIn(key, self.data["judgment_card"])
        audit = self.data["self_audit"]
        for key in ("id", "issue", "evidence", "scope", "judgment_id", "judgment_version", "case_ids", "disposition",
                    "conditions_checked", "exceptions_checked", "alternatives"):
            self.assertIn(key, audit["finding"])
        self.assertIn("self_audit_match", audit["teacher_finding"])
        for key in ("finding_id", "decision", "reason", "ledger", "matched"):
            self.assertIn(key, audit["decision"])

    def test_values_are_the_ones_the_page_names(self):
        values = self.data["values"]
        page = read(PAGE)
        self.assertEqual(values["revision.kind"][:3], ["smooth_but_lossy", "keep_original", "wrong_then_corrected"])
        self.assertEqual(values["change_class"], ["纯表达", "消歧", "补信息", "改状态"])
        self.assertEqual(values["disposition"], ["keep", "list_alternatives", "flag_only"])
        self.assertEqual(values["decision.ledger"], ["agreed", "disagreed", "untouched"])
        self.assertEqual(values["decision.decision"], ["adopt", "decline", "defer"])
        for name in values["revision.kind"][:3] + values["disposition"] + values["decision.ledger"]:
            self.assertIn("`" + name + "`", page, name)
        self.assertEqual(len(values["keep.basis"]), 6)  # the page's six kinds of basis for keeping a sentence
        self.assertEqual(values["not_looked_at.always"], ["字数", "词频", "句数", "有没有某个词"])
        self.assertLessEqual(set(values["not_looked_at.always"]), set(self.data["judgment_card"]["not_looked_at"]))

    def test_placeholders_are_neutral(self):
        allowed = {v for vs in self.data["values"].values() for v in vs} | {"editorial-judgment/1", "revision-case/1"}

        def leaves(node, path=""):
            if isinstance(node, dict):
                for key, value in node.items():
                    if path == "" and key in {"note", "values"}:
                        continue
                    yield from leaves(value, path + "." + key)
                    if isinstance(key, str) and not key.isascii():
                        yield path + "{key}", key
            elif isinstance(node, list):
                for item in node:
                    yield from leaves(item, path + "[]")
            elif isinstance(node, str):
                yield path, node

        checked = 0
        for path, text in leaves(self.data):
            checked += 1
            self.assertTrue(text.startswith("替换为") or text in allowed, (path, text))
        self.assertGreater(checked, 40)
        self.assertIn("占位文字全部替换", self.data["note"])
        self.assertIn("不是案例，也不是规则", self.data["note"])

    def test_the_page_links_the_template(self):
        self.assertIn("](../" + TEMPLATE + ")", read(PAGE))


class Reachable(unittest.TestCase):
    LABEL = "[" + TITLE + "](references/editorial-judgment.md)"
    REF = "[" + TITLE + "](editorial-judgment.md)"

    def test_from_the_entry(self):
        skill = read("SKILL.md")
        row = next(l for l in section(skill, "按需读取").splitlines() if "references/editorial-judgment.md" in l)
        self.assertIn("[editorial-judgment.md](references/editorial-judgment.md)", row)
        self.assertIn("作者明确启用才用", row)
        optional = section(skill, "可选模块：默认关着")
        self.assertIn(self.LABEL + "“谁来开、记在哪”", optional)
        self.assertIn("“谁来开、记在哪”", read(PAGE))

    def test_from_the_stages_it_serves(self):
        text = read("references/chapter-confirmation.md")
        rows = {m.group(1): l for l in text.splitlines() for m in [re.match(r"\| \d `(\w+)` ", l)] if m}
        for stage in ("preparation", "draft", "review", "final"):
            self.assertIn("editorial-judgment.md", rows[stage], stage)
        self.assertIn(self.REF + "“交教师以前的自审”", rows["draft"])
        before = next(l for l in text.splitlines() if l.startswith("- **初稿交出以前。**"))
        self.assertIn("自审只出单子，不改稿", before)
        self.assertIn("editorial-judgment.md", before)
        teacher = read("references/teacher-review.md")
        top = teacher[:teacher.index("\n## ")]
        self.assertIn(self.REF + "“教师意见回来以后的对账”", top)
        short = section(teacher, "6. 给作者看的是一张短表")
        self.assertIn("**自审标过、教师没动的**", short)
        loop = read("references/learning-loop.md")
        self.assertIn(self.REF, section(loop, "在章节流程里怎么起一轮"))
        self.assertIn(self.REF + "“用现有的记录怎么记”", section(loop, "命令与事件契约"))
        demo = section(read("references/demonstration-learning.md"), "最小案例契约")
        row = next(l for l in demo.splitlines() if l.startswith("| `revision`"))
        self.assertIn(self.REF, row)
        self.assertIn("没有这一段的案例照常有效", row)

    def test_the_pages_that_link_it_still_resolve(self):
        for rel in ("SKILL.md", "references/chapter-confirmation.md", "references/teacher-review.md",
                    "references/learning-loop.md", "references/demonstration-learning.md"):
            base = SKILL if rel == "SKILL.md" else SKILL / "references"
            for target in LINK.findall(read(rel)):
                if re.match(r"^[a-z]+:", target):
                    continue
                self.assertTrue((base / target).resolve().exists(), (rel, target))


class TheRecordsHoldWhatThePageSays(unittest.TestCase):
    """Run on the package's own scripts with newly written neutral text, in a temporary folder."""

    DRAFT = "掌柜把算盘推到一边。“先记着。”他低头去找账本。"
    NEW = "掌柜把算盘推到一边。“记着吧。”他低头去找账本。"
    WRITER = {"name": "writer", "context_id": "w"}

    def setUp(self):
        self.loop = load("learning_loop")
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "learning.md"
        payload = {"schema_version": 1, "project_id": "book", "revision": 0,
                   "data": {"demonstration_learning": {"enabled": True, "loop_enabled": True, "max_revisions": 2},
                            "demonstrations": {}, "learning_runs": {}, "learning_events": {}}}
        self.path.write_bytes(("<!-- NOVEL_WORKSHOP_LEARNING_START -->\n```json\n" + json.dumps(payload, ensure_ascii=False)
                               + "\n```\n<!-- NOVEL_WORKSHOP_LEARNING_END -->\n").encode("utf-8"))
        self.serial = 0

    def send(self, op, **fields):
        self.serial += 1
        event = {"event_id": "e" + str(self.serial), "op": op, "run_id": "run", **fields}
        return self.loop.apply_event(self.path, event, "book", self.loop.read_store(self.path)[1])

    def refused(self, op, **fields):
        with self.assertRaises(self.loop.LoopError):
            self.send(op, **fields)

    def review(self, review_id, role, mode, text, findings, verdict="revise", **extra):
        return self.send("review", review_id=review_id, draft_sha256=sha(text), verdict=verdict, findings=findings,
                         reviewer={"name": role, "role": role, "mode": mode, "context_id": role[0]},
                         source_ref="fixture://" + review_id, **extra)

    def test_self_audit_then_teacher_then_reconciliation(self):
        self.send("start", task="dialogue_revision", tags=["dialogue"], group_id="g1", input_text=self.DRAFT,
                  source_ref="fixture://draft", constraints=["保留推开算盘这个动作"])
        self.send("plan", applications=[], checks=["自审"])
        self.send("draft", text=self.DRAFT, source_ref="fixture://draft", actor=self.WRITER)
        audit = json.loads(read(TEMPLATE))["self_audit"]["finding"]
        audit.update(id="a1", issue="合成自审项", evidence="“先记着。”", scope="第一句台词")
        self.review("audit", "writer", "self_check", self.DRAFT, [audit])
        self.review("teacher", "teacher", "author_return", self.DRAFT,
                    [{"id": "t1", "issue": "合成意见", "evidence": "“先记着。”", "scope": "第一句台词", "self_audit_match": "a1"}])
        run = self.loop.read_store(self.path)[0]["data"]["learning_runs"]["run"]
        self.assertEqual(list(run["review_order"]), ["audit", "teacher"])
        kept = run["reviews"]["audit"]["findings"][0]
        for key in ("judgment_id", "judgment_version", "case_ids", "disposition", "conditions_checked",
                    "exceptions_checked", "alternatives"):
            self.assertIn(key, kept)
        self.assertEqual(run["reviews"]["teacher"]["findings"][0]["self_audit_match"], "a1")
        # a self-check cannot stand in for the teacher
        self.refused("review", review_id="fake", draft_sha256=sha(self.DRAFT), verdict="revise", findings=[],
                     reviewer={"name": "x", "role": "teacher", "mode": "self_check", "context_id": "w"}, source_ref="f")
        self.send("decide", review_id="teacher", decisions=[{"finding_id": "t1", "decision": "adopt", "reason": "合成"}])
        revise = dict(parent_sha256=sha(self.DRAFT), text=self.NEW, source_ref="fixture://v2", actor=self.WRITER,
                      review_id="teacher")
        self.refused("revise", **revise)  # both reviews decided first
        self.send("decide", review_id="audit", decisions=[{"finding_id": "a1", "decision": "adopt", "reason": "合成",
                                                           "ledger": "disagreed", "matched": "t1"}])
        run = self.loop.read_store(self.path)[0]["data"]["learning_runs"]["run"]
        self.assertIn('"ledger": "disagreed"', json.dumps(run, ensure_ascii=False))
        self.send("revise", **revise)
        self.review("re1", "writer", "self_check", self.NEW, [], verdict="pass", rechecks=["teacher"])
        self.refused("finish", draft_sha256=sha(self.NEW))  # the recheck has to name the self-audit too
        self.review("re2", "writer", "self_check", self.NEW, [], verdict="pass", rechecks=["teacher", "audit"])
        self.send("finish", draft_sha256=sha(self.NEW))
        self.send("learn", case_id="c1", why="合成", when=["合成"], decisions=["合成"],
                  revision=json.loads(read(TEMPLATE))["revision"], **{"except": []})
        case = self.loop.read_store(self.path)[0]["data"]["demonstrations"]["c1"]
        self.assertNotIn("revision", case)  # learn does not keep it: the page puts it in the card file

    def test_a_self_audit_kept_whole_still_has_to_be_rechecked(self):
        # r5.55 review: every self-audit item kept, the teacher's adopted; a recheck naming only the teacher is refused
        self.send("start", task="dialogue_revision", tags=["dialogue"], group_id="g1", input_text=self.DRAFT,
                  source_ref="fixture://draft", constraints=[])
        self.send("plan", applications=[], checks=["自审"])
        self.send("draft", text=self.DRAFT, source_ref="fixture://draft", actor=self.WRITER)
        audit = json.loads(read(TEMPLATE))["self_audit"]["finding"]
        audit.update(id="a1", issue="合成自审项", evidence="“先记着。”", scope="第一句台词", disposition="keep")
        self.review("audit", "writer", "self_check", self.DRAFT, [audit])
        self.review("teacher", "teacher", "author_return", self.DRAFT,
                    [{"id": "t1", "issue": "合成意见", "evidence": "“先记着。”", "scope": "第一句台词"}])
        self.send("decide", review_id="teacher", decisions=[{"finding_id": "t1", "decision": "adopt", "reason": "合成"}])
        self.send("decide", review_id="audit", decisions=[{"finding_id": "a1", "decision": "decline", "reason": "合成",
                                                           "ledger": "untouched", "matched": None}])
        self.send("revise", parent_sha256=sha(self.DRAFT), text=self.NEW, source_ref="fixture://v2", actor=self.WRITER,
                  review_id="teacher")
        self.review("re1", "writer", "self_check", self.NEW, [], verdict="pass", rechecks=["teacher"])
        self.refused("finish", draft_sha256=sha(self.NEW))
        self.review("re2", "writer", "self_check", self.NEW, [], verdict="pass", rechecks=["teacher", "audit"])
        self.assertEqual(self.send("finish", draft_sha256=sha(self.NEW))["status"], "saved")

    def test_a_hand_built_case_may_carry_a_revision_segment(self):
        case = json.loads(read("assets/demonstration-case-template.json"))
        case.update(id="c1", project_id="book", group_id="g1", before=self.DRAFT, after=self.DRAFT)
        case["hashes"] = {"before": sha(self.DRAFT), "after": sha(self.DRAFT)}
        case["revision"] = json.loads(read(TEMPLATE))["revision"]
        state = Path(self.temp.name) / "state.json"
        state.write_bytes(json.dumps({"schema_version": 1, "project_id": "book", "revision": 0,
                                      "data": {"demonstration_learning": {"enabled": True},
                                               "demonstrations": {"c1": case}}}, ensure_ascii=False).encode("utf-8"))
        code, out, err = run("demonstration_memory.py", "check", state)
        self.assertEqual(code, 0, out + err)
        self.assertEqual(json.loads(out)["status"], "valid")

    def test_the_self_audit_hash_in_the_draft_content_binds_the_teacher_return(self):
        def gate(action, stage=None, **fields):
            self.serial += 1
            event = {"event_id": "g" + str(self.serial), "op": "chapter_gate", "action": action, "chapter_id": "c1",
                     **fields}
            if stage:
                event["stage"] = stage
            return self.loop.apply_event(self.path, event, "book", self.loop.read_store(self.path)[1])

        def confirm(shown):
            return gate("confirm", shown["current_stage"], presentation_id=shown["presentation_id"],
                        presentation_version=shown["presentation_version"], actor_role="author", mode="human",
                        author_quote="可以。", source_ref="fixture://author/" + shown["presentation_id"])

        for stage in ("scope", "outline"):
            confirm(gate("present", stage, content="合成：" + stage, source_ref="fixture://" + stage))
        confirm(gate("present", "preparation", content="合成：准备", source_ref="fixture://prep",
                     visual_evidence={"mode": "author_images", "source_refs": ["fixture://img"],
                                      "observation_ref": "fixture://obs", "selection_ref": "fixture://sel"}))
        first = gate("present", "draft", content="自审单 " + sha("合成自审单"), source_ref="fixture://draft",
                     artifact_sha256=sha(self.DRAFT))
        second = gate("present", "draft", content="自审单 " + sha("合成自审单，改过"), source_ref="fixture://draft",
                      artifact_sha256=sha(self.DRAFT))
        self.assertNotEqual(first["presentation_version"], second["presentation_version"])
        confirm(second)
        returned = dict(draft_sha256=sha(self.DRAFT), returned_text="合成教师意见。", source_ref="fixture://ret",
                        teacher_name="unknown")
        with self.assertRaises(self.loop.LoopError):
            gate("teacher_return", draft_presentation_id=first["presentation_id"],
                 draft_presentation_version=first["presentation_version"], **returned)
        self.assertTrue(gate("teacher_return", draft_presentation_id=second["presentation_id"],
                             draft_presentation_version=second["presentation_version"], **returned)["teacher_return_id"])


class SalePackage(unittest.TestCase):
    def test_both_files_are_on_the_sale_list_and_in_the_export(self):
        exporter = load("export_portable")
        self.assertLessEqual({PAGE, TEMPLATE}, set(exporter.SALE_FILES))
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "sale.zip"
            code, out, err = run("export_portable.py", target, "--mode", "sale")
            self.assertEqual(code, 0, out + err)
            with zipfile.ZipFile(target) as archive:
                names = set(archive.namelist())
                portable = archive.read("portable-novel-workshop.md").decode("utf-8")
        for rel in (PAGE, TEMPLATE):
            self.assertIn("novel-workshop/" + rel, names)
        self.assertIn("# " + TITLE, portable)
        self.assertIn('"schema": "editorial-judgment/1"', portable)


if __name__ == "__main__":
    unittest.main()

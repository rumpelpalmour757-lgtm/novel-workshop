#!/usr/bin/env python3
"""r5.54: what a line says at this moment, and how it says it. The author's words of 11-12: "话语上就是明显就是没有感情，
不像正常的人说出来的话", "只有AI才会说出来的东西", "对白方面就是不要有电报体，就是很自然"; the same day the author let the
workshop try what it proposed ("其他的都可以照你建议的来去试试").

The rule side: dialogue-craft.md splits the work on a line into two jobs, inside the line (every line, nothing added or
taken away) and the exchange (who speaks, whether a reply is taken; on conditions), and gets two sections of questions
("话里带着他此刻的态度", "只有 AI 才会这样说吗"); particles, set phrases, full sentences and tags with a tone word are
loosened, each with a line saying when not; the third revision pass asks six questions; the beat card gets three
fields; drafting.md lets the point-of-view character's thoughts be written straight; section 4 of scene-dramaturgy.md
gets readings, sections 1 to 3 untouched. The script side: dialogue_lines.py lists long lines only when asked
(--long-lines), takes a colon at the end of the paragraph before as a speaking tag, except where it brings in something
written or a list, and its closing questions follow the third pass.

These tests check that the rules are written in, that the pinned parts did not move, and that the script does what its
help says. They do not show that the dialogue reads more like people or has more feeling: that is for the author to
judge, on the held-out comparison. Every passage below is newly written for this test.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
LINES = SKILL / "scripts" / "dialogue_lines.py"
CARDS = SKILL / "scripts" / "style_cards.py"
GUARD = SKILL / "scripts" / "workflow_guard.py"
CRAFT = "references/dialogue-craft.md"
TWO_JOBS = "两件事分开做：句内和来回（r5.54）"
ATTITUDE = "话里带着他此刻的态度（r5.54）"
AI_ONLY = "只有 AI 才会这样说吗：改稿时问自己（r5.54）"
# Files r5.54 changed (the new teacher-review page has its own test file).
TOUCHED = ("references/dialogue-craft.md", "references/drafting.md", "references/revision-passes.md",
           "references/style-cards.md", "references/prose-audit.md", "references/scene-dramaturgy.md",
           "references/chapter-confirmation.md", "references/quality-loop.md", "references/sentence-craft.md",
           "references/chinese-punctuation.md", "references/teacher-review.md", "assets/scene-beat-card.md",
           "assets/voice-material-card.md", "assets/sentence-dialogue-checklist.md", "assets/revision-card.md",
           "SKILL.md", "references/editing.md", "references/style-packs.md")  # the last two: r5.54 review

# The r5.53 baseline for this merge is the installed workshop, which already included the opt-in narrative-xian scan.
# Pin its prose checker along with the unchanged delivery and constitution files.
SCENE_SECTIONS_1_TO_3_SHA256 = "ce9360c51c25652e264161bb4452a36c540b2a52d5cc304685379c1eeed4bddd"
SKILL_LEVEL_LINES_SHA256 = {"| L1 ": "acd558b59f4b35121c357e492f32c5bfa7e23a810f1e2363dc67ad997c374c31",
                            "| L2 ": "362deeb153288ce5e70f0b0dabe6517bc5c930da18b088ec67f4860f37340d34"}
PINNED_FILES_SHA256 = {
    "CONSTITUTION.md": "8707a0a47ce4d5b5554815250dc46506f871b0ca46694d6b518811e0b32caa6f",
    "assets/constitution-rules.json": "859b2528ab1d9b9f90cd98fa67c48b1f31175a19d921575ae352dfe64aadc63b",
    "scripts/workflow_guard.py": "f4d644de5235f49e382018b12447c5de596c2273edeb3b947f1119f710d87200",
    "scripts/punctuation_lint.py": "a7165e542df8e14480807cb19173d8e9516b413b24707dbbed955e4dcff59b43",
    "scripts/prose_lint.py": "58a059ac86dc97c20deb2a63c14c0b5bed78a194790f39b66e2074a8ddf4257e",
    "scripts/fact_guard.py": "1d8cc4e027674ce27f7413ef63fdced9986043618db95217d4c7dcb0b41be9e4",
    "scripts/project_state.py": "48f938f4df33e0d7805d75593bb15802d8ff397f7c060e59e61ac63c8d2011c1",
    "assets/delivery-gate-card.md": "4569fe40f8f3f0a2e331d7f5cdb14be639b8a4d8b19f739664788dcb7a60991f",  # r5.54 review: a same-size edit passed before
}
# The JSON of dialogue_lines.py in r5.53: r5.54 may add keys, not drop or rename them.
R553_TOP_KEYS = {"attribution_review", "dialogue_lines", "file", "flagged", "limits", "sha256", "speakers",
                 "unattributed", "voices"}
R553_LINE_KEYS = {"basis", "before", "candidates", "flags", "han", "line", "narration_before", "order", "paragraph",
                  "speaker", "text"}
R553_REVIEW_KEYS = {"after_narration", "by_action_before", "runs", "settings"}
LINK = re.compile(r"\]\(([^)#\s]+)")


def read(rel):
    return (SKILL / rel).read_text(encoding="utf-8")


def section(text, heading):
    start = text.find("\n## " + heading)
    if start == -1:
        return ""
    end = text.find("\n## ", start + 4)
    return text[start:end if end != -1 else len(text)]


def paragraph_with(text, phrase):
    found = [line for line in text.splitlines() if phrase in line]
    if len(found) != 1:
        raise AssertionError("expected one paragraph with %r, found %d" % (phrase, len(found)))
    return found[0]


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(script, *args):
    proc = subprocess.run([sys.executable, "-I", "-B", str(script), *map(str, args)], capture_output=True, text=True,
                          encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


def new_text():
    """The r5.54 text, as far as a test can find it: the three new sections of the dialogue module, the r5.54 block of
    scene-dramaturgy.md section 4, the teacher-review page, and every sentence (or table cell) marked r5.54."""
    craft = read(CRAFT)
    units = [section(craft, TWO_JOBS), section(craft, ATTITUDE), section(craft, AI_ONLY), read("references/teacher-review.md")]
    scene = read("references/scene-dramaturgy.md")
    units.append(scene[scene.index("- **r5.54 加的读法**"):scene.index("\n来源：")])
    for rel in TOUCHED:
        units += [s for s in re.split(r"[。|\n]", read(rel)) if "r5.54" in s]
    return units


class TheDialogueModule(unittest.TestCase):
    def setUp(self):
        self.text = read(CRAFT)

    def test_three_new_sections_in_their_places(self):
        order = ["## 先确认本次能改到哪里", "## " + TWO_JOBS, "## 一段对白的最小工作卡", "## 顺着回应改", "## " + ATTITUDE,
                 "## " + AI_ONLY, "## 谁在说"]
        places = [self.text.find(h) for h in order]
        self.assertNotIn(-1, places, places)
        self.assertEqual(places, sorted(places))

    def test_inside_the_line_and_the_exchange(self):
        part = section(self.text, TWO_JOBS)
        rows = [l for l in part.splitlines() if l.startswith("| ") and not l.startswith("| ---")]
        self.assertEqual([r.split("|")[1].strip() for r in rows], ["", "管什么", "什么时候做", "能动什么"])
        self.assertEqual(rows[0].split("|")[2:4], [" 句内 ", " 来回 "])
        can = rows[3]
        # what "inside the line" may not change is written down, and adding or dropping a clause is an exchange
        self.assertIn("这句话办的事、给的信息、提的要求、说破到哪一步，都不增不减", can)
        self.assertIn("已经在引号里的这一句怎么说：用词、语序、小字、语气词、前文已有的称呼、引号里的句读", rows[1])  # r5.54 review
        self.assertIn("只动词、语序、小字和句读，可以变长也可以变短；口令、报数、惜字的人引号里的句号不并。", can)
        self.assertIn("添一个分句、删一个分句、换一件事，算来回", can)
        self.assertIn("每次都做：起草时每句出口以前", rows[2])
        self.assertIn("有条件：排节拍时在[节拍卡](../assets/scene-beat-card.md)“场上的人声”一栏定", rows[2])
        self.assertIn("只润色时列成建议", rows[2])
        self.assertIn("只润色的任务里，句内也不动引号里的句读（句号并成逗号、逗号切成句号），想到的列成建议。", part)
        self.assertIn("只润色的任务，就是[编辑](editing.md)“先定范围”里按严格保义润色办的那几种（只润色、只改字句、只改标点、"
                      "别加东西、只删不添）", part)  # r5.54 review (consistency-3)
        self.assertIn("记进新增设定清单（[正文与场景](drafting.md)“新增设定清单”）", part)  # one name (consistency-9)
        self.assertIn("- **话里不带出新东西。**", part)
        self.assertIn("起草时越过节拍卡加的人声不改卡，同样记进这张清单。", part)
        self.assertIn("台词写多了还是写少了，工坊不判，由作者读了定。", part)
        for target in LINK.findall(part):
            self.assertTrue((SKILL / "references" / target).resolve().is_file(), target)

    def test_the_sections_that_were_there_say_which_job_they_are(self):
        moment = section(self.text, "这一刻会出什么声（r5.53）")
        self.assertIn("这一节是“来回”那件事（上文“两件事分开做”）", moment)
        self.assertIn("只润色时把想到的列成建议，不往正文里加话", moment)
        self.assertIn("- **新加的话不带出新东西**（r5.54）", moment)
        self.assertIn("读者会替人后怕、心疼的事之后，有那一下反应的，照[分场规范](scene-dramaturgy.md)第 4 节“事后一拍”放在下一场开头；"
                      "可以没有。", moment)
        self.assertNotIn("大事之后", moment)
        # consistency-6: what the author cannot see on a card is listed to the author, the same as in three other places
        idle = paragraph_with(moment, "- **闲场面和紧场面不一样**（r5.54）")
        self.assertIn("记进新增设定清单、交稿时列给作者", idle)
        self.assertNotIn("只列成建议，不进正文", idle)
        self.assertIn("**改法。** 先在这一句里面改（办的事、给的信息不增不减）；要动内容和来回的，照“两件事分开做”的条件。",
                      section(self.text, AI_ONLY))

    def test_particles_and_short_lines(self):
        telegraph = paragraph_with(self.text, "- **电报句和假口语**（r5.53；r5.54 改）")
        self.assertIn("口令、报数、念单子、登记核对时的一问一答、惜字的人，本来就短，他们引号里的句号是对的，不并成流水句", telegraph)
        particles = paragraph_with(self.text, "- **语气词、叹词、称呼跟着人和这一刻走**（r5.54）")
        self.assertIn("不是每句挂一个，也不是一个不许有。", particles)
        # r5.54 review (provenance-overreach-2): a reading, not "not one particle"; the end of a rescue is the rescue
        self.assertIn("回头看的是读下来人人一个口气、分不出谁是谁", particles)
        # verify-batch2 v-1: only the people on duty still at work there; after that it is a family scene
        self.assertIn("出勤、抢险的人险事刚收尾、还在现场办事（清点、核对、收拾）的那一段，人人不带也是本分", particles)
        self.assertIn("险后转成家常的（街坊、家里人围上来），照家常读", particles)
        self.assertNotIn("险事刚收尾、人还在现场的那一段照出勤算", particles)
        self.assertNotIn("一个不带", particles)
        self.assertIn("或者让他问一句（这是来回，照“两件事分开做”的条件）", telegraph)  # consistency-5
        self.assertIn("举的是例子，别的情形照下面同一个判据", telegraph)  # fidelity-7 (c)
        self.assertNotIn("吃惊、心疼", telegraph)  # provenance-overreach-5
        voice = paragraph_with(self.text, "- **作者腹语**")
        self.assertNotIn("有的人是在使劲", voice)
        steps = section(self.text, "顺着回应改，不按发言轮次改")
        self.assertIn("没有被逼问、被施压的时候（问伤、问安、熟人之间的来回），被问的人没什么可藏、想让对方信，直答就是他的戏", steps)
        self.assertIn("上手查，这几种不是单子，不照着填；", steps)  # provenance-overreach-9
        self.assertNotIn("读者知道他在瞒", steps)
        self.assertNotIn("两三种", self.text)  # provenance-overreach-10
        self.assertIn("谁用哪几个，照口吻表和作者样本；没有样本的人先暂定，列给作者。", particles)

    def test_the_words_that_pushed_one_way_are_gone(self):
        # r5.54 (amendment, item 32): no module and no printed card line still says not to add particles to speech
        mod = load(CARDS, "style_cards_r554")
        code, out, err = run(CARDS, "load", "slice-of-life-warmth")
        self.assertEqual(code, 0, out + err)
        for name, text in (("dialogue-craft.md", self.text), ("revision-passes.md", read("references/revision-passes.md")),
                           ("style-cards.md", read("references/style-cards.md")), ("style_cards.py", mod.DIALOGUE_LINE),
                           ("style_cards.py load", out)):
            self.assertNotIn("不往台词里加", text, name)
        self.assertNotIn("押车的人隔着车窗催司机", self.text)  # the r5.53 example taken out in r5.54

    def test_the_attitude_section(self):
        part = section(self.text, ATTITUDE)
        self.assertIn("这一节只对情绪当口和关系要紧的那几句做；口令、报数、过场不问。", part)
        steps = [l.split("**")[1] for l in part.splitlines() if re.match(r"\d\. \*\*", l)]
        self.assertEqual(steps, ["先定态度，再写话。", "态度落在哪儿，分两层。", "换个人听，话会变。", "事前说得出吗。", "直说可以。"])
        self.assertIn("前文没有，问作者，不猜。", part)
        self.assertIn("是来回的事：起草时定，改稿要获准", part)  # what changes the content is not done inside the line
        self.assertIn("称呼不替作者起", part)
        self.assertIn("上面几样不是单子，不照着填。", part)

    def test_the_ai_only_questions(self):
        part = section(self.text, AI_ONLY)
        for phrase in ("下面是问法，不是记号；不计数，不做成扫描。", "别的书、别的场面上未验证",
                       "例外栏举的只是例子，别的情形照同一个判据", "不为这一问添一个猜错、听岔、啰嗦的人。",
                       "拿不准的不改，把原句和疑问列给作者。"):
            self.assertIn(phrase, part)
        table = part[part.index("| 问 | 什么时候不算毛病 |"):]
        rows = []
        for line in table.splitlines()[2:]:
            if not line.startswith("| "):
                break
            rows.append(line)
        self.assertEqual(len(rows), 8)
        self.assertIn("接过对方的词翻成俏皮话、说成重话，说一半被打断", rows[7])  # r5.54 review
        self.assertNotIn("拿来驳", rows[7])  # recalibration: it asked the yardstick chapter's family table
        self.assertIn("打断半句的是在场的人或场上真有的动静", rows[7])  # calibration: the scene's own noise
        self.assertIn("较劲、逼问的时候一路反问、挑对方的字眼顶回去（分场 2.4），而且几句各办各的事、接得上对方的话", rows[7])  # v-9
        for word in ("背熟了的话", "自报家门"):
            self.assertNotIn(word, table)
        for line in rows:
            cells = line.split("|")[1:-1]
            self.assertEqual(len(cells), 2, line)
            self.assertTrue(cells[0].strip(), line)
            self.assertTrue(cells[1].strip(), line)  # every question says when it is not a fault

    def test_the_busy_scenes_are_not_asked(self):
        # the whole-scene question and the particles line say, in the same paragraph, that call-outs and rescues are
        # not asked: everyone short and everyone answering is their job there
        whole = paragraph_with(self.text, "**先整场看一眼。**")
        self.assertIn("只用在家常和闲下来的场面", whole)
        self.assertIn("同一行当的人办急事、出勤抢险、口令复诵，人人短、人人答得上是本分，不问这一句。", whole)
        particles = paragraph_with(self.text, "- **语气词、叹词、称呼跟着人和这一刻走**（r5.54）")
        self.assertIn("出勤、对峙、抢险的场面人人不带是本分，不回头看。", particles)
        check = paragraph_with(self.text, "- **整场（家常和闲下来的场面）**")
        self.assertIn("办急事、出勤抢险的场不问这一条。", check)
        sixth = paragraph_with(read("references/revision-passes.md"), "6. **只有 AI 才会这样说吗？**（r5.54）")
        self.assertIn("办急事、出勤抢险的场人人短、人人答得上是本分", sixth)

    def test_the_self_check_in_three_groups(self):
        part = section(self.text, "交付前自检")
        groups = [l.split("**")[1] for l in part.splitlines() if l.startswith("- **")]
        self.assertEqual(groups, ["句内（每句都过）", "来回（照条件）", "整场（家常和闲下来的场面）"])
        self.assertIn("要拆的是把身份、条件、规矩替读者排整齐的那种（r5.54）", part)

    def test_the_examples_say_which_job_they_show(self):
        labels = re.findall(r"\*\*原创示例（([^）]+)）：\*\*", self.text)
        self.assertEqual(len(labels), 10, labels)
        self.assertIn("起草：换个人听，话会变", labels)  # adds a question: not inside the line (r5.54 review)
        self.assertEqual(labels.count("句内；只润色的任务不这样改，列成建议"), 2)
        self.assertIn("上头的人下到地上，说：“你手怎么这么快。”", self.text)
        self.assertNotIn("下回我扶", self.text)
        self.assertIn("（r5.54：照“两件事分开做”，这是获准改写时的做法：改后拿掉了“好的”这一声应答", self.text)
        self.assertIn("（r5.54：改后拿掉了“我想问一下”，逗号改成了省略号", self.text)
        for label in labels:
            self.assertTrue(any(job in label for job in ("句内", "来回", "起草")), label)
        for start in ("> 理发店里，师傅两手都占着", "> 快递站里，站长对分拣的人", "> 菜市场，卖鱼的对老主顾",
                      "> 宿舍楼停了水。", "> 要说的事只有一件：会改到三点。", "> 面馆坐满了。", "> 换灯泡的时候梯子一歪",
                      "> 节拍上写的是“房东通知她下月起涨租”。", "> 他俩从客户那儿出来，下到停车场。", "> 修车铺里。"):
            self.assertIn(start, self.text)
        # the examples the reviewers asked to drop are not in any module r5.54 touched
        for rel in TOUCHED:
            text = read(rel)
            for word in ("驾校", "跳闸", "班主任", "伞在门后", "山路", "拧火", "食堂窗口", "钓鱼"):
                self.assertNotIn(word, text, (rel, word))

    def test_the_source_note(self):
        note = section(self.text, "来源短注")
        self.assertIn("（押车一例 r5.54 删去）", note)
        self.assertIn("乙这一部分是工坊照参考文本拟的，作者没有逐条看过。", note)
        self.assertIn("本模块没有引它的句子和人名，做法学自它", note)
        self.assertIn("都没有在留出的章节上验证过", note)
        self.assertNotIn("没有它的场面", note)


class BothEnds(unittest.TestCase):
    """Each loosened rule says, in the same paragraph, when not to do it. A selection of the pairs the design names."""

    PAIRS = (
        (CRAFT, "说给对面的人，话可以全，可以带“因为、所以”", "回头看的是：当事人对着在场的人把刚发生的事按先后排好再讲一遍"),
        (CRAFT, "短不是毛病", "看的是省掉了什么：省对方看得见、刚说过的，留自己的意思和那个真动词"),
        (CRAFT, "口气可以落在句末那个字、开头那一声或一个称呼上", "回头看的是读下来人人一个口气"),
        (CRAFT, "平常人嘴上有现成话，松气、道谢、客套都是，它不是毛病", "回头看的是两样：场上人人来了一句、换谁说都一样"),
        (CRAFT, "闲下来、家常的场面，不办事的来回本身可以是戏", "紧的场面不为这一条加来回，该喊的照喊"),
        (CRAFT, "接法不止一种", "不是每句都要先接一下；这几种不是单子，不照着填"),
        (CRAFT, "一句就信了，也是一种接法", "第二遍问不出新东西的那一问，回头看留不留"),
        (CRAFT, "说话标签里带一个说明口气的词，闲谈里的点头、笑一下、应一声，是平常写法",
         "回头看的是句句都带、几个人都一样，或者标签在替一句换谁说都行的空话撑着"),
        (CRAFT, "接对方的词不限于较劲", "回头看的是同一个人连着几回都这样接（翻成俏皮话、说成重话），或者几个人、几场都这样接；"
                "拿对方的词驳回去是吵架、拌嘴的平常走法，不算"),
        (CRAFT, "有的人一口气说一串，是他的说话方式，不按信息量拆", "要拆的是把身份、条件、规矩替读者排整齐的那种"),
        ("references/revision-passes.md", "会把话说全，连词也带着", "回头看的是读下来人人一样齐，或者人人一样省"),
        ("references/revision-passes.md", "答不出也可以是他有意说平", "小字、称呼不成套地用；半截话、说一半咽回去是来回的事，照条件"),
        ("references/revision-passes.md", "会把话说全，连词也带着", "（连同出勤、抢险的人险事刚收尾、还在现场办事的那一段），人人短是本分，不算；险后转成家常的照家常读"),
        ("assets/sentence-dialogue-checklist.md", "对生人客气，会把话说全", "（连同出勤、抢险的人险事刚收尾、还在现场办事的那一段）人人短是本分，不算"),
        ("references/quality-loop.md", "人人一个口气", "连同出勤、抢险的人险事刚收尾、还在现场办事的那一段，人人短、人人不带语气词是本分"),
        ("references/drafting.md", "**视角人物的念头可以直接写**", "刚发生的事托得住它才写"),
        ("references/scene-dramaturgy.md", "这一拍放在下一场开头", "不是每场开头都先来一下"),
        ("references/prose-audit.md", "闲谈里的点头、笑一下、应一声，是说话的气口，不必件件改变回应",
         "要删的是句句都配、几个人都一样、把话压住的"),
        ("references/chinese-punctuation.md", "有的人一口气说一串，话头自己拐弯，是他的说话方式",
         "要分层的是把身份、条件、规矩替读者排整齐的那种"),
        ("references/quality-loop.md", "讲理、说闲话、一口气说一串不算", "一个人把背景替读者排整齐讲一大段"),
    )

    def test_each_pair_is_in_one_paragraph(self):
        for rel, loose, limit in self.PAIRS:
            with self.subTest(loose=loose):
                self.assertIn(limit, paragraph_with(read(rel), loose), rel)

    def test_the_attitude_section_has_both(self):
        part = section(read(CRAFT), ATTITUDE)
        self.assertIn("5. **直说可以。**", part)
        self.assertIn("**不做过头。** 不是每句都带情。", part)
        self.assertIn("惜字的人不因为这一节多说话", part)


class NoNumbers(unittest.TestCase):
    def test_no_count_for_lines_in_the_new_text(self):
        # the same check as test_r553_dialogue.py, over the r5.54 text: no sentence about lines or dialogue sets a number
        # of lines, characters or items. It catches the usual wordings with Arabic or Chinese numerals, not every one.
        number = r"(\d+|[一二两三四五六七八九十]+[来多]?)\s*(句|个字|字|处|项|条|轮|声|种)"  # 声、种: r5.54 review
        bound = r"(至少|不少于|不超过|最多|最少|以内|以上|平均|每场|每段|每百字|每章|每人)"
        units = new_text()
        self.assertGreater(len(units), 20)
        for unit in units:
            for sentence in re.split(r"[。\n]", unit):
                if "台词" in sentence or "对白" in sentence:
                    self.assertNotRegex(sentence, bound + r"[^，；]*" + number)
                    self.assertNotRegex(sentence, number + r"[^，；]*" + bound)

    def test_no_claim_that_the_amount_is_under_control(self):
        joined = "\n".join(new_text())
        for phrase in ("一两句", "重蹈覆辙", "脚本核过", "系统已记录了"):
            self.assertNotIn(phrase, joined)
        self.assertIn("台词量工坊不判", read("references/drafting.md"))
        # the scenes of the reference chapter are not described in the new text (amendment, point 4)
        for word in ("长辈", "孩子", "病情", "病历", "套近乎", "拍着胸脯", "人一走"):
            self.assertNotIn(word, joined)
        self.assertNotIn("收尾点之后的送客", read(CRAFT))


class ThirdPass(unittest.TestCase):
    def setUp(self):
        self.part = section(read("references/revision-passes.md"), "第三遍：台词隔离")

    def test_two_steps_and_six_questions(self):
        self.assertIn("这一遍分两步（r5.54，[对白专项](dialogue-craft.md)“两件事分开做”）。**句内**每句都过", self.part)
        self.assertIn("添一个分句、删一个分句算来回。只润色的任务不动引号里的句读，列成建议。", self.part)
        questions = [l.split("**")[1] for l in self.part.splitlines() if re.match(r"\d\. \*\*", l)]
        self.assertEqual(questions, ["这词像不像他说的？", "他此刻对谁说、为什么说、急不急？", "叙述层的词混进来没有？",
                                     "短，是他的脾气，还是写的人在省字？", "这句话带着他此刻的态度吗？", "只有 AI 才会这样说吗？"])
        self.assertIn("口令、报数、念单子、登记核对时的一问一答本来就短，不改，他们的句号也不并", self.part)
        self.assertIn("语气词和叹词用不用、用哪几个，怎么称呼人、怎么自称；样本里没有的不编", self.part)
        self.assertNotIn("便条", self.part)
        for phrase in ("换词，补回动词和小字，加减语气词，改语序和句读，用前文已有的称呼；", "新起的称呼算新增设定，列给作者",
                       "表的第二栏（什么时候不算毛病）是这一问的一部分", "是不是人人说的都对、都全、都顺、都配合",
                       "别的情形照同一个判据，看省掉的是什么"):
            self.assertIn(phrase, self.part)  # r5.54 review

    def test_the_exchange_step_has_conditions(self):
        step = paragraph_with(self.part, "**分栏读完，再按来回读**（r5.53）")
        self.assertIn("**分栏读完，再按来回读**（r5.53）。这一步有条件。", step)
        self.assertIn("拿掉这一来一回少了什么；新加的话带没带出新的事实、规矩、数目（带出了，列给作者）", step)
        self.assertIn("只润色的任务，这一步只记建议，不往正文里加话。", step)

    def test_the_first_and_second_pass(self):
        text = read("references/revision-passes.md")
        self.assertIn("也有反过来的，压成只剩名词和动词，把人人都写成惜字的人（r5.54）", text)
        self.assertIn("左右手：左手、右手、另一只手（脚本输出里这一族仍叫“手部报备”", text)
        self.assertIn("叙述换一个角度把刚才那一幕再看一遍，算多出了东西（r5.54）", text)
        self.assertIn("挑他听得懂的说法。只润色的任务列成建议，不压、不删（r5.54）。", text)  # consistency-3


class Drafting(unittest.TestCase):
    def test_the_work_card(self):
        text = read("references/drafting.md")
        for phrase in ("对方看得见、刚说过的东西他常常不说全，自己的意思和那个动词留着；看得见的东西有的人也会说出口；",
                       "两件事分开（r5.54，对白专项“两件事分开做”）。谁出声、有没有不办事的来回，照节拍卡“场上的人声”一栏写",
                       "卡不改，加的人声也记进那张清单", "节拍、大纲里的“某某说了某事”是事，不是话，出口的那一句重新想",
                       "话多话少跟着人走，不立句数；台词量工坊不判。", "“两件事分开做”“一段对白的最小工作卡”“这一刻会出什么声”“顺着回应改”“话里带着他此刻的态度”五节",
                       "卡不改，加的人声也记进那张清单（下文“新增设定清单”）",
                       "**新增设定清单**（r5.54）：写和改的时候记在工作记录里，交稿时列给作者",
                       "起草时越过节拍卡加的人声，没带出新东西的也记；作者看不到节拍卡的任务里，工坊在卡上写进的、节拍和大纲里没有的不办事来回。",
                       "场面紧时不往里塞话、该喊的照喊（r5.54 改）"):
            self.assertIn(phrase, text)
        draft = paragraph_with(read("references/chapter-confirmation.md"), "| 4 `draft` ")  # r5.55: the r5.54 stage table
        self.assertIn("待作者决定的新变化", draft)
        self.assertIn("“两件事分开做”“一段对白的最小工作卡”“这一刻会出什么声”“顺着回应改”“话里带着他此刻的态度”五节",
                      read(CRAFT).splitlines()[2])  # the module says the same (consistency-1)
        self.assertIn("对白专项的五节也要读", read("SKILL.md"))
        self.assertNotIn("对白专项的三节也要读", read("SKILL.md"))

    def test_thoughts_of_the_point_of_view_character(self):
        part = section(read("references/drafting.md"), "对白与描写")
        self.assertIn("**视角人物的念头可以直接写**（r5.54，作者 11-12 同意试）", part)
        self.assertIn("只写这一场的视角人物；进不进别人的脑子、叙述者下不下感慨，照本书的视角和旁白规定，没有规定的问作者", part)
        self.assertIn("照[模板腔复核](prose-audit.md)“总结、复述和章尾：分开问三件事”判", part)
        self.assertIn("## 总结、复述和章尾：分开问三件事", read("references/prose-audit.md"))
        self.assertIn("> 改：他摸了左边兜，又摸右边兜。钥匙。", part)
        self.assertIn("台词自己也带着说话人的态度（对白专项“话里带着他此刻的态度”），不是每句都带情，惜字的人不因此多说话", part)


class SceneDramaturgy(unittest.TestCase):
    def setUp(self):
        self.text = read("references/scene-dramaturgy.md")

    def test_sections_1_to_3_did_not_move(self):
        # line ends as LF, so a checkout that turns them into CRLF (Windows) hashes the same
        data = (SKILL / "references" / "scene-dramaturgy.md").read_bytes().replace(b"\r\n", b"\n")
        marker = "## 4. 在工坊里怎样执行".encode("utf-8")
        self.assertEqual(data.count(marker), 1)
        self.assertEqual(hashlib.sha256(data[:data.index(marker)]).hexdigest(), SCENE_SECTIONS_1_TO_3_SHA256)

    def test_the_readings_are_in_section_4(self):
        four = section(self.text, "4. 在工坊里怎样执行")
        block = four[four.index("- **r5.54 加的读法**"):]
        self.assertIn("下面几句是读法，不改第 1—3 节的字", block)
        self.assertIn("每场一问、事后一拍、视角人物的念头是工坊提的建议、作者 11-12 同意试的；直答一句是 r5.53 已有读法的展开", block)
        items = [l.strip().split("**")[1] for l in block.splitlines() if re.match(r"\s+\d\. \*\*", l)]
        self.assertEqual(items, ["每场问一句谁在乎什么。", "事后一拍。", "视角人物的念头。", "2.4 和直答。"])
        self.assertIn("只办事的场写“无”，“无”是常态，不为这一问凑一句重话", block)
        self.assertIn("它是人的反应，不是叙述的回顾：不替读者清点得失、宣布局势", block)
        self.assertIn("- **待作者认（认下以前照原文）**：(a)", block)
        self.assertIn("(b) 配角一闪而过的神色", block)
        self.assertIn("(c) 被逼问、被施压的一方本来就没什么可藏、想让对方信（被盘问的清白人）", block)  # r5.54 review
        self.assertIn("没有被逼问、被施压的时候（问伤、问安、熟人之间的来回），被问的人没什么可藏", block)
        self.assertIn("“待作者认”的三句是工坊照作者同日指定的参考文本拟的", block)
        self.assertIn("船老大照常吆喝下船，嗓门比平时大了一截。", block)
        self.assertNotIn("谁叫他也不应", block)
        self.assertIn("事后一拍的原创示例：", block)
        self.assertIn("没有“他们后怕极了”，也没有回顾刚才多险", block)
        for target in LINK.findall(block):
            self.assertTrue((SKILL / "references" / target).resolve().is_file(), target)

    def test_the_source_says_what_was_not_changed(self):
        source = self.text[self.text.index("\n来源："):]
        self.assertIn("第 1—3 节的照录原文没有改，宪法没有改。", source)
        self.assertIn("“待作者认”的三句是工坊照它拟的，作者没有看过", source)
        self.assertIn("本页没有引它的句子和人名", source)
        self.assertIn("这几句都没有在留出的章节上验证过", source)


class Pinned(unittest.TestCase):
    def test_level_lines_of_skill_md(self):
        lines = read("SKILL.md").splitlines()
        for start, digest in SKILL_LEVEL_LINES_SHA256.items():
            found = [l for l in lines if l.startswith(start)]
            self.assertEqual(len(found), 1, start)
            self.assertEqual(hashlib.sha256(found[0].encode("utf-8")).hexdigest(), digest, start)

    def test_constitution_and_bound_scripts(self):
        for rel, digest in PINNED_FILES_SHA256.items():
            data = (SKILL / rel).read_bytes().replace(b"\r\n", b"\n")
            self.assertEqual(hashlib.sha256(data).hexdigest(), digest, rel)

    def test_byte_budgets(self):
        self.assertLessEqual(len(read("assets/delivery-gate-card.md").encode("utf-8")), 5004)
        self.assertLess(len((ROOT / "README.md").read_text(encoding="utf-8").encode("utf-8")), 24000)


class Entry(unittest.TestCase):
    def test_skill_md_routes_to_the_new_sections(self):
        skill = read("SKILL.md")
        row = paragraph_with(skill, "| 对白不像人说话")
        self.assertIn("“两件事分开做”“一段对白的最小工作卡”“这一刻会出什么声”“顺着回应改”“话里带着他此刻的态度”“只有 AI 才会这样说吗”（r5.54）",
                      row)
        self.assertIn("句内每句都过（办的事、给的信息不增不减），来回照条件；话多话少跟着人走，新加的话不带出新的事实、规矩、数目", row)
        self.assertIn("写明起草前读这五节，其中三节 r5.53 起就读；“只有 AI 才会这样说吗”是写完改稿时问的", row)  # r5.54 review
        self.assertIn("引号里的句读在只润色、只改标点时列成建议（r5.54）", paragraph_with(skill, "| 标点错误、"))  # v-8
        self.assertIn("有对白的，加读 [dialogue-craft.md](references/dialogue-craft.md)“只有 AI 才会这样说吗”（r5.54）",
                      paragraph_with(skill, "| 去模板腔、去 AI 味"))
        self.assertIn("问改得对不对：[teacher-review.md](references/teacher-review.md)（r5.54）", paragraph_with(skill, "| 文笔修改、"))
        craft = read(CRAFT)
        named = row.split("](references/dialogue-craft.md)")[1].split("（[drafting.md]")[0]
        for name in re.findall(r"“([^”]+)”", named):
            self.assertIn("\n## " + name, craft, name)

    def test_the_other_modules(self):
        expect = {
            "references/prose-audit.md": ("见[对白专项](dialogue-craft.md)“话里带着他此刻的态度”（r5.54）",
                                          "视角人物的念头可以直接写，“他想”可以不加（[正文与场景](drafting.md)“对白与描写”，r5.54）",
                                          "写一句理由保留，不为过检查往中间插动作（r5.54）",
                                          "查不出对白像不像人：一章台词少、短、不带口气，这几项可以一处不报",
                                          "别的情形照同一个判据：这几句连着走是不是这一场要的"),  # r5.54 review
            "assets/revision-card.md": ("这张单子查的是叙述里多出来的套话；对白像不像人、话里有没有口气，它查不出来",
                                        "“只润色”“只改字句”“只改标点”“别加东西”“只删不添”是**严格保义润色**",  # v-7
                                        "引号里的话，句号并成逗号、逗号切成句号，添、删一个分句，都列成建议，客观的标点错照改，r5.54"),
            "references/chinese-punctuation.md#2": ("只润色、只改标点的任务里，引号里的句号并成逗号、逗号切成句号列成建议，客观的标点错照改",),
            "references/style-cards.md": ("“全在不言中”只是那张卡的一种写法：把关心说出口一样可以是温情的场面",
                                          "（r5.54；这是工坊的读法，卡是作者给的，作者没有逐条看过：现在照这一句办，作者不认就拿掉）"),
            "references/editing.md": ("句号并成逗号、逗号切成句号，添、删一个分句，列成建议，不进正文（[对白专项](dialogue-craft.md)"
                                      "“两件事分开做”，r5.54）",),
            "references/style-packs.md": ("对白上也有相反的几处（r5.54）", "包里代答、砍词的比例和上文的硬指标一样，只当复核线索"),
            "references/sentence-craft.md": ("台词里的语气词、叹词、称呼、叠着说的应声（“行行行”“不用不用”）也一样（r5.54）",),
            "references/chinese-punctuation.md": ("本书另有长对白复核线的照本书。",),
            "references/quality-loop.md": ("台词带出了新事实，没记进新增设定清单、没列给作者（r5.54）",
                                           "不是口令、报数、念单子、登记核对，也不是惜字的人，话却写得像口令或电报"),
            "assets/sentence-dialogue-checklist.md": ("不是对手戏、没有人施压的（问伤、问安、熟人之间），被问的人没什么可藏，"
                                                      "直答是他的戏，这一行记“不适用”；被逼问、被施压的一方照 2.4",
                                                      "话是不是人人一样齐，或者人人一样省（有的人讲理、对生人客气，会把话说全）",
                                                      "| 对白 | 情绪当口的那几句，换个人听要不要改？新加的话带没带出新的事实、规矩、数目？"),
            "references/chapter-confirmation.md": ("每场问一句谁在乎什么，只办事的场写“无”；事后一拍放在哪一场开头，可以没有，r5.54",),
        }
        for rel, phrases in expect.items():
            text = read(rel.split("#")[0])  # "#2": a second entry for a file already in the table
            for phrase in phrases:
                self.assertIn(phrase, text, rel)
        # the three items the amendment left out of the quality loop's dialogue row
        row = paragraph_with(read("references/quality-loop.md"), "| 对白与标点（`dialogue_punctuation`）")
        for phrase in ("人人一个长短", "现成话没人接", "原话再问一遍"):
            self.assertNotIn(phrase, row)

    def test_the_card_line_printed_by_style_cards(self):
        mod = load(CARDS, "style_cards_r554_line")
        self.assertIn("市井温情那张卡里的“全在不言中”只是一种写法", mod.DIALOGUE_LINE)
        self.assertIn("语气词跟着说话的人和这一刻走，不为凑口语句句挂一个", mod.DIALOGUE_LINE)  # r5.54 review: was not pinned
        self.assertIn("（工坊的读法，作者没有逐条看过）", mod.DIALOGUE_LINE)  # r5.54 review (consistency-13)
        self.assertNotIn("待作者认", mod.DIALOGUE_LINE)
        code, out, err = run(CARDS, "load", "slice-of-life-warmth")
        self.assertEqual(code, 0, out + err)
        self.assertIn(mod.DIALOGUE_LINE, out.splitlines())
        self.assertIn("全在不言中", out.replace(mod.DIALOGUE_LINE, ""))  # the card's own remark is still printed


class Cards(unittest.TestCase):
    NEW = ("这一场谁在乎什么", "场上的人声", "接上一场")
    FILLED = {
        "- **Scene ID / Chapter**": "S1 / 第一章",
        "- **Scene Type**": "Core Conflict (核心博弈戏)",
        "- **POV Character & Sensory Limit (视角人物与感知盲区)**": "修表的人，只看得见柜台这一边",
        "- **Polarity Shift (局势极性变化)**": "[以为还能赊一回] -> [被要求当场结清]",
        "- **Core Prop Anchor (核心交互道具)**": "压在玻璃板下的一张欠条",
        "1. **入场动作与诉求 (Goal - Late In)**": "他来取表，想再赊一回",
        "2. **对手反制与阻碍 (Obstacle & Escalation)**": "店主把欠条抽出来摆在柜台上",
        "3. **破局点/意外转折 (The Turn)**": "表里换上的零件不是他要的那种",
        "4. **出场悬念钩子 (Exit Hook - Early Out)**": "他没拿表就走了",
        "- **禁止直接概括的过程**": "两个人对着欠条算账那一段",
        "- **潜台词冰山 (Subtext)**": "嘴上算钱，争的是还认不认这个熟客",
        "- **情绪生理化映射 (Embodiment)**": "店主一直没抬头，手里的镊子停了两回",
    }
    NEW_FILLED = {"- **这一场谁在乎什么**": "见下", "- **场上的人声**": "两个人在场，学徒在里屋不出声；紧",
                  "- **接上一场**": "无"}

    def card(self, new):
        """The template with the old fields filled; new: 'filled', 'hint' (left as the template has it) or 'gone'."""
        out = []
        for line in read("assets/scene-beat-card.md").splitlines():
            key = next((k for k in self.FILLED if line.startswith(k)), None)
            if key:
                out.append("%s: %s" % (key, self.FILLED[key]))
                continue
            key = next((k for k in self.NEW_FILLED if line.startswith(k)), None)
            if key and new == "gone":
                continue
            out.append("%s: %s" % (key, self.NEW_FILLED[key]) if key and new == "filled" else line)
        return "\n".join(out)

    def test_three_new_fields_do_not_change_what_the_gate_reads(self):
        guard = load(GUARD, "workflow_guard_r554")
        results = {new: guard.read_beat_card(self.card(new)) for new in ("gone", "hint", "filled")}
        self.assertEqual(results["gone"][1], [])
        self.assertEqual(results["gone"], results["hint"])
        self.assertEqual(results["gone"], results["filled"])
        for label in self.NEW:
            for field, words in guard.SCENE_FIELDS:
                for word in words:
                    self.assertNotIn(word, label.lower(), (label, field))

    def test_the_new_fields(self):
        text = read("assets/scene-beat-card.md")
        self.assertIn("“这一场谁在乎什么”“场上的人声”“接上一场”三栏，过场以外各类场都可以填；交付门不核这三栏。", text)
        self.assertIn("卡在任务开始时冻结：起草时越过卡加的人声不改卡，记进新增设定清单。", text)
        lines = {label: paragraph_with(text, "- **%s**" % label) for label in self.NEW}
        self.assertIn("“无”是常态，不为这一栏凑一句重话", lines["这一场谁在乎什么"])
        self.assertIn("写“见下”", lines["这一场谁在乎什么"])
        self.assertIn("这一栏不写台词", lines["场上的人声"])
        self.assertIn("可以没有，没有写“无”", lines["接上一场"])
        self.assertNotIn("谁话多", text)
        self.assertIn("紧，不为这一栏加声，该喊的照喊", lines["场上的人声"])  # r5.54 review
        self.assertNotIn("一声就够", text)
        self.assertIn("这三栏可以空着，上面说的“每一栏都要填”指原有各栏；照分场第 4 节第 1 句问过的，写上答案", text)  # v-6
        self.assertIn("一章各场都是“无”（这一栏空着的场不算）", read("references/scene-dramaturgy.md"))
        for label, line in lines.items():  # v-11: no number of calls, lines or kinds in the hints of the new fields
            self.assertNotRegex(line, r"(\d+|[一二两三四五六七八九十]+)\s*(声|种)")  # "凑一句重话" says not to add one
        self.assertNotIn("一声喊就够", read(CRAFT))  # v-12
        self.assertNotIn("一声就够", read("references/drafting.md"))
        for label, line in lines.items():
            hint = line[line.index("*(") + 2:line.rindex(")*")]
            self.assertNotIn(")", hint, label)  # no bracket inside a hint: the gate strips a hint up to the first )
            self.assertNotIn("(", hint, label)

    def test_the_material_card(self):
        text = read("assets/voice-material-card.md")
        seen = paragraph_with(text, "- **从样本里看出来的**")
        for phrase in ("没直说的那些句子，口气落在哪；语气词、叹词谁用、用哪几个；同场的人说话差多少；同一个人对不同的人怎么变",
                       "样本里一次也没有的说法照实写“样本里没有”，不推成本书不许有"):
            self.assertIn(phrase, seen)
        self.assertIn("不把这一类的口气当成全书的口气，暂定的列给作者，r5.54", paragraph_with(text, "- **样本覆盖不到的场面**"))


# A passage for the script, newly written: a long line, a written-register word, and a colon closing a paragraph.
PASSAGE = ("码头上起了风。\n\n"
           "“几点开船？”小满问。\n\n"
           "“七点，你先回去把锅里那半碗面热一热吃了，别等我，也别又凉着吃坏了肚子。”老秦说。\n\n"
           "“然而票还没买。”小满说。\n")
NARRATION = "灯亮了，桌上的两只碗还没收，碗边搁着一双筷子，墙角的暖壶倒了，热水洒了一地，窗台上那盆葱也歪了。"
FIRST = "“几点了？”小满问。\n\n"


class LongLines(unittest.TestCase):
    def setUp(self):
        self.mod = load(LINES, "dialogue_lines_r554")

    def long(self, report):
        return [f for x in report["flagged"] for f in x["flags"] if f["kind"] == "long"]

    def test_not_listed_unless_asked(self):
        report = self.mod.inspect(PASSAGE, names=("小满", "老秦"))
        self.assertEqual(self.long(report), [])
        self.assertIs(report["long_lines_listed"], False)
        # the other flags are listed as before
        self.assertEqual([(x["line"], [f["kind"] for f in x["flags"]]) for x in report["flagged"]], [(7, ["written"])])

    def test_listed_where_it_is_when_asked(self):
        report = self.mod.inspect(PASSAGE, names=("小满", "老秦"), long_lines=True)
        long = self.long(report)
        self.assertEqual(len(long), 1)
        line = next(x for x in report["flagged"] if any(f["kind"] == "long" for f in x["flags"]))
        self.assertEqual(line["line"], 5)
        self.assertEqual(long[0]["note"], "一口气 %d 个字：只列位置；有的人说话本来就长，长不是毛病（r5.54）" % line["han"])
        self.assertNotIn("讲设定", long[0]["note"])
        self.assertIs(report["long_lines_listed"], True)

    def test_the_start_is_still_24(self):
        for count, flagged in ((23, False), (24, True)):
            text = "老秦说：“%s。”\n" % ("走" * count)
            self.assertEqual(bool(self.mod.inspect(text, names=["老秦"], long_lines=True)["flagged"]), flagged, count)
            self.assertEqual(self.mod.inspect(text, names=["老秦"])["flagged"], [], count)

    def test_the_command(self):
        with tempfile.TemporaryDirectory() as tmp:
            chapter = Path(tmp) / "ch.md"
            chapter.write_bytes(PASSAGE.encode("utf-8"))
            code, plain, err = run(LINES, chapter, "--names", "小满,老秦")
            self.assertEqual(code, 0, err)
            self.assertIn("== 要再读一遍的，1 处", plain)
            self.assertNotIn("一口气", plain)
            code, asked, err = run(LINES, chapter, "--names", "小满,老秦", "--long-lines")
            self.assertEqual(code, 0, err)
            self.assertIn("== 要再读一遍的，2 处", asked)
            self.assertIn("只列位置；有的人说话本来就长，长不是毛病（r5.54）", asked)
            code, js, err = run(LINES, chapter, "--names", "小满,老秦", "--format", "json")
            self.assertEqual(code, 0, err)
            self.assertIs(json.loads(js)["long_lines_listed"], False)
            code, js, err = run(LINES, chapter, "--names", "小满,老秦", "--format", "json", "--long-lines")
            self.assertEqual(code, 0, err)
            data = json.loads(js)
            self.assertIs(data["long_lines_listed"], True)
            self.assertEqual(len(self.long(data)), 1)
            code, out, err = run(LINES, "--help")
            self.assertEqual(code, 0, err)
            self.assertIn("--long-lines", out)
            self.assertIn("a long line is not a fault", " ".join(out.split()))


class ColonAbove(unittest.TestCase):
    """A paragraph with no line that ends in a colon is read as the tag of the line that opens the next paragraph."""

    def setUp(self):
        self.mod = load(LINES, "dialogue_lines_r554_colon")

    def who(self, text, mode="blank"):
        report = self.mod.inspect(text, paragraph_mode=mode, names=("小满", "老秦"))
        every = sorted([x for v in report["speakers"].values() for x in v] + report["unattributed"], key=lambda x: x["order"])
        return [x["speaker"] for x in every], [x["line"] for x in report["attribution_review"]["after_narration"]]

    def test_a_named_subject_before_the_colon(self):
        self.assertGreaterEqual(self.mod.han_count(NARRATION), self.mod.NARRATION_BREAK)
        speakers, after = self.who(FIRST + NARRATION + "老秦笑着骂了一句：\n\n“你这人，壶倒了也不扶。”\n")
        self.assertEqual(speakers, ["小满", "老秦"])
        self.assertEqual(after, [])  # no longer listed as starting again after narration with no stated speaker
        speakers, _ = self.who(FIRST.replace("\n\n", "\n") + NARRATION + "老秦笑着骂了一句：\n“你这人。”\n", mode="line")
        self.assertEqual(speakers, ["小满", "老秦"])
        speakers, _ = self.who(FIRST + NARRATION + "老秦笑着骂了一句:\n\n“你这人。”\n")  # a colon typed in half width
        self.assertEqual(speakers, ["小满", "老秦"])
        # r5.54 review: across paragraphs only a speaking word (说、问、骂、喊……) names the speaker; 数着筷子 does not
        speakers, after = self.who(FIRST + NARRATION + "老秦数着筷子：\n\n“一、二、三，够了。”\n")
        self.assertEqual((speakers, after), (["小满", None], [5]))
        speakers, _ = self.who((FIRST + NARRATION + "老秦笑着骂了一句：\n\n“你这人。”\n").replace("\n", "\r\n"))
        self.assertEqual(speakers, ["小满", "老秦"])  # Windows line breaks
        with tempfile.TemporaryDirectory() as tmp:
            chapter = Path(tmp) / "ch.md"
            chapter.write_bytes((FIRST + NARRATION + "老秦笑着骂了一句：\n\n“你这人。”\n").encode("utf-8"))
            code, out, err = run(LINES, chapter, "--names", "小满,老秦")
            self.assertEqual(code, 0, err)
            self.assertIn("== 老秦，1 处", out)
            self.assertNotIn("隔了一段叙述", out)

    def test_not_when_the_colon_brings_in_something_written_or_a_list(self):
        for above, line in (("老秦指着门上的告示：", "“闲人免进。”"), ("老秦拆开信，信里只有一句：", "“我下礼拜回。”"),
                            ("老秦在本子上写：", "“欠两块。”"), ("老秦交代了两样：", "“一、先关电闸。二、再开窗。”")):
            with self.subTest(above=above):
                speakers, after = self.who(FIRST + NARRATION + above + "\n\n" + line + "\n")
                self.assertEqual(speakers, ["小满", None])
                self.assertEqual(after, [5])  # still listed as a place to re-read
        # r5.54 review: whoever reads, hears or stands next to someone is not the one speaking
        for above in ("老秦拆开信：", "老秦点开小满发来的消息：", "老秦一愣，门外传来一个女人的声音：", "老秦脑海里响起一个冰冷的声音：",
                      "老秦身后的徒弟骂了一句：", "老秦旁边的人骂了一句："):
            with self.subTest(above=above):
                speakers, after = self.who(FIRST + NARRATION + above + "\n\n“你这人。”\n")
                self.assertEqual((speakers, after), (["小满", None], [5]))
        speakers, _ = self.who(FIRST + NARRATION + "老秦点了三样：\n\n“米”、“油”、“盐”。\n")
        self.assertEqual(speakers, ["小满", None, None, None])

    def test_only_the_two_paragraphs_and_a_name(self):
        # the line does not open its paragraph: what stands before it in the paragraph decides, as before
        speakers, _ = self.who(FIRST + NARRATION + "老秦笑着骂了一句：\n\n小满没吭声。“你这人。”\n")
        self.assertNotEqual(speakers[1], "老秦")
        # a paragraph of narration between: no tag
        speakers, _ = self.who(FIRST + NARRATION + "老秦笑着骂了一句：\n\n风从门缝里钻进来。\n\n“你这人。”\n")
        self.assertEqual(speakers, ["小满", None])
        # a pronoun before the colon: not attributed
        speakers, _ = self.who(FIRST + NARRATION + "他笑着骂了一句：\n\n“你这人。”\n")
        self.assertEqual(speakers, ["小满", None])


class Report(unittest.TestCase):
    def test_closing_questions_follow_the_third_pass(self):
        with tempfile.TemporaryDirectory() as tmp:
            chapter = Path(tmp) / "ch.md"
            chapter.write_bytes(PASSAGE.encode("utf-8"))
            code, out, err = run(LINES, chapter, "--names", "小满,老秦", "--exchanges", "--long-lines")
            self.assertEqual(code, 0, err)
        for phrase in ("逐句问四件事：", "短，是他的脾气，还是写的人在省字", "再问两样（r5.54）", "这句话带着他此刻的态度吗",
                       "只有 AI 才会这样说吗", "是问法，不计数。", "拿掉这一来一回少了什么", "新加的话带没带出新的事实、规矩、数目",
                       "只润色的任务，这一步只记建议，不往正文里加话。",
                       "先只动句子里面（r5.54）：办的事、给的信息不增不减；只润色的任务不动引号里的句读", "句号也不并",
                       "语气词不为凑口语句句挂一个", "定不出态度的列给作者，不猜", "不为这一问添话、添人",
                       "是不是人人说的都对、都全、都顺、都配合，读下来分不分得出谁是谁"):  # v-10
            self.assertIn(phrase, out)
        self.assertNotIn("便条", out)
        for word in ("通过", "得分", "错误", "合格"):
            self.assertNotIn(word, out)  # positions and questions, no verdict

    def test_the_json_keeps_every_key_of_r553(self):
        # r5.54 review: read the keys from the command line itself (main() adds file and sha256), nested levels too
        with tempfile.TemporaryDirectory() as tmp:
            chapter = Path(tmp) / "ch.md"
            chapter.write_bytes((FIRST + NARRATION + "老秦笑着骂了一句：\n\n“你这人，壶倒了也不扶，还要我说几回才肯听，你倒是说说看今天又是哪一出。”\n\n"
                                 "小满没吭声。\n\n“抵达了。”\n").encode("utf-8"))
            code, out, err = run(LINES, chapter, "--names", "小满,老秦", "--format", "json", "--long-lines")
            self.assertEqual(code, 0, err)
        report = json.loads(out)
        nested = {"flags": {"kind", "word", "note"}, "runs": {"first_line", "last_line", "count", "last_named_before"},
                  "after_narration": {"line", "narration_han", "candidates"}, "by_action_before": {"line", "speaker"},
                  "settings": {"run_min", "narration_break_han"}}
        review = report["attribution_review"]
        for key in ("runs", "after_narration", "by_action_before"):
            for entry in review[key]:
                self.assertLessEqual(nested[key], set(entry), key)
        self.assertLessEqual(nested["settings"], set(review["settings"]))
        flagged = report["flagged"]
        self.assertTrue(flagged)
        for entry in flagged:
            for flag in entry["flags"]:
                self.assertLessEqual(nested["flags"], set(flag))
        self.assertLessEqual(R553_TOP_KEYS, set(report))
        self.assertLessEqual(R553_REVIEW_KEYS, set(report["attribution_review"]))
        for entry in [x for v in report["speakers"].values() for x in v] + report["unattributed"]:
            self.assertLessEqual(R553_LINE_KEYS, set(entry))
        self.assertEqual(set(report) - R553_TOP_KEYS, {"long_lines_listed"})


if __name__ == "__main__":
    unittest.main()

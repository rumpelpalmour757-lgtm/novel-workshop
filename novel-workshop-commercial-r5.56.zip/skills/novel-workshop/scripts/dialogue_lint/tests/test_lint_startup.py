"""Running the command line the way the package documents it.

python3 -I starts it; a run leaves no __pycache__ in the skill folder; the modules use
nothing newer than Python 3.9; a UTF-8 file with a byte order mark reads like one
without; a missing output folder stops the run before any file is written.
"""
import ast
import contextlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

INSTALL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(INSTALL))

from run_lint import main


def run_cli(args):
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        try:
            code = main(args)
        except SystemExit as stop:
            code = stop.code
    return code, out.getvalue(), err.getvalue()


def evaluated_union_annotations(tree):
    """`X | None` in an annotation that Python 3.9 would evaluate when the def runs."""
    found = []
    def check(node):
        if node is not None and any(isinstance(n, ast.BinOp) and isinstance(n.op, ast.BitOr) for n in ast.walk(node)):
            found.append(node.lineno)
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            args = node.args
            for arg in args.posonlyargs + args.args + args.kwonlyargs + [args.vararg, args.kwarg]:
                if arg is not None:
                    check(arg.annotation)
            check(node.returns)
        elif isinstance(node, ast.AnnAssign):
            check(node.annotation)
    return found


class StartupTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def test_isolated_mode_starts_and_scans(self):
        source = self.root / 'chapter.txt'
        source.write_text('陈原说：“好。”\n', encoding='utf-8')
        script = str(INSTALL / 'run_lint.py')
        for args in (['--help'], ['scan', str(source)]):
            with self.subTest(args=args):
                result = subprocess.run([sys.executable, '-I', '-B', script, *args], cwd=str(self.root),
                                        capture_output=True, text=True, encoding='utf-8', check=False)
                self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)['summary']['dialogue_quotes'], 1)

    def test_a_run_without_dash_b_leaves_no_bytecode_next_to_the_scripts(self):
        copy = self.root / 'dialogue_lint'
        copy.mkdir()
        for module in INSTALL.glob('*.py'):
            shutil.copy2(module, copy / module.name)
        source = self.root / 'chapter.txt'
        source.write_text('陈原说：“好。”\n', encoding='utf-8')
        result = subprocess.run([sys.executable, '-I', str(copy / 'run_lint.py'), 'scan', str(source)],
                                cwd=str(self.root), capture_output=True, text=True, encoding='utf-8', check=False)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual([p.name for p in copy.rglob('__pycache__')], [])

    def test_modules_and_tests_use_nothing_newer_than_python_39(self):
        files = sorted(INSTALL.glob('*.py')) + sorted((INSTALL / 'tests').glob('*.py'))
        self.assertTrue(files)
        for path in files:
            with self.subTest(file=path.name):
                source = path.read_text(encoding='utf-8')
                tree = ast.parse(source, filename=str(path), feature_version=(3, 9))
                postponed = any(isinstance(n, ast.ImportFrom) and n.module == '__future__'
                                and any(a.name == 'annotations' for a in n.names) for n in tree.body)
                if not postponed:
                    self.assertEqual(evaluated_union_annotations(tree), [])

    def test_byte_order_mark_in_source_and_config_reads_like_plain_utf8(self):
        source, config = self.root / 'chapter.txt', self.root / 'book.json'
        text = '陈原说：“在左边柜里。”他把包放下。\r\n'
        source.write_bytes(b'\xef\xbb\xbf' + text.encode('utf-8'))
        config.write_bytes(b'\xef\xbb\xbf' + json.dumps({'profiles': {'陈原': {}}}, ensure_ascii=False).encode('utf-8'))
        request, report = self.root / 'request.json', self.root / 'report.json'
        code, _, err = run_cli(['scan', str(source), '--config', str(config), '--style-hints',
                                '--output', str(report), '--request-output', str(request)])
        self.assertEqual(code, 0, err)
        data = json.loads(report.read_text(encoding='utf-8'))
        self.assertEqual((data['dialogues'][0]['speaker'], data['dialogues'][0]['confidence']), ('陈原', 'explicit'))
        req = json.loads(request.read_text(encoding='utf-8'))
        self.assertEqual([i['quote_id'] for i in req['items']], ['p1:q1'])
        response, target = self.root / 'response.json', self.root / 'revised.txt'
        response.write_text(json.dumps({'source_hash': req['source_hash'], 'replacements': [
            {'quote_id': 'p1:q1', 'original': '在左边柜里。', 'replacement': '在左边那个柜子里。'}]},
            ensure_ascii=False), encoding='utf-8')
        code, _, err = run_cli(['apply', str(source), str(request), str(response), '--output', str(target),
                                '--config', str(config), '--style-hints'])
        self.assertEqual(code, 0, err)
        self.assertEqual(target.read_bytes(),
                         b'\xef\xbb\xbf' + text.replace('在左边柜里。', '在左边那个柜子里。').encode('utf-8'))

    def test_packaged_example_config_is_accepted(self):
        example = INSTALL.parents[1] / 'assets' / 'dialogue-lint-config.example.json'
        source = self.root / 'chapter.txt'
        source.write_text('陈原说：“好。”\n', encoding='utf-8')
        code, out, err = run_cli(['scan', str(source), '--config', str(example)])
        self.assertEqual(code, 0, err)
        self.assertEqual(json.loads(out)['checks_run']['suspicious_expressions'], [])

    def test_missing_output_folder_stops_before_any_file_is_written(self):
        source = self.root / 'chapter.txt'
        source.write_text('陈原说：“好。”\n', encoding='utf-8')
        report = self.root / 'report.json'
        code, _, err = run_cli(['scan', str(source), '--output', str(report),
                                '--request-output', str(self.root / 'missing' / 'request.json')])
        self.assertEqual(code, 2)
        self.assertFalse(report.exists())
        code, _, err = run_cli(['scan', str(source), '--output', str(report)])
        self.assertEqual(code, 0, err)


if __name__ == '__main__':
    unittest.main()

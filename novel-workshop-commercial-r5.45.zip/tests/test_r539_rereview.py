#!/usr/bin/env python3
"""r5.39: the same unchanged text reviewed again after a PASS (the author's 10-24 list, point 5).

In the author's run a chapter had a recorded self-check PASS; reading it again found semantic problems in the same
bytes. `record` of the new review was refused ("Current node is not awaiting verification; reserve repair first"),
and so was `reserve` ("Reserve only after a review requests repair, or after a completed review becomes stale").
The way out already existed -- replan accepts a completed run, with the author's decision, then reserve and record --
but neither message showed it, and the first one pointed at a step that is refused too.

r5.39 changes only the messages (the routes are the same): each refusal says what fits the node the run is in. These
tests pin that, and follow the way the message names on test data in a temporary directory: the same bytes get a
NEEDS_REVISION after the old PASS, the old PASS stays in the history, the budget goes on from where it was, and the
review policy cannot get lighter on the way. Reviews are labelled test data; they are not literary judgments.
"""

import json
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:  # run on its own (python3 -I tests/test_r539_rereview.py) as well as from run_tests.py
    sys.path.insert(0, str(HERE))
from test_r511_expression_record import DRAFT, SUMMARY, ExpressionRecord, sha_text  # noqa: E402

DELETE = {"decision": "change", "before": SUMMARY, "after": "", "judgment": "测试数据：替读者总结",
          "reason": "测试数据：删去不丢信息"}
ISSUE = {"quote": "他看完，站起来", "expected": "测试数据：看完的是油桶，读者要往回找",
         "impact": "测试数据：作者在 PASS 之后读出的语义问题"}
FIXED = DRAFT.replace("他看完，站起来", "他看完油桶，站起来")
FIX = {"decision": "change", "before": "他看完，站起来", "after": "他看完油桶，站起来",
       "judgment": "测试数据：补回看的对象", "reason": "测试数据：前一段写的就是这只油桶"}
DECISION = {"author_decision": "测试数据：作者要求按新发现的语义问题重审同一版，旧 PASS 不再作为这一版的结论",
            "source": "测试数据：作者本轮消息", "affected_scope": "测试数据：整章表达检查"}
THE_WAY = ("replan", "author_decision", "source", "affected_scope", "reserve", "record")


class SameTextReviewedAgain(ExpressionRecord):
    def state(self):
        return json.loads((self.dir / "run.json").read_text(encoding="utf-8"))

    def passed(self):
        self.start()
        code, out = self.record("v1", self.review("pass.json", expression=self.whole(decisions=[DELETE])))
        self.assertEqual(code, 0, out)
        self.assertEqual(self.gate()[1]["editorial"], "PASS[self_check]")

    def refused(self, out, *words):
        self.assertEqual(out.get("failure"), "INVALID_ROUTE", out)
        for word in words:
            self.assertIn(word, out["message"])
        return out["message"]

    def test_a_completed_run_names_the_way_and_the_way_works(self):
        self.passed()
        before = (self.dir / "run.json").read_bytes()
        reread = self.review("reread.json", verdict="NEEDS_REVISION", issues=[ISSUE],
                             expression=self.whole(decisions=[DELETE]))
        message = self.refused(self.record("v2", reread)[1], *THE_WAY)
        self.assertIn("PASS[self_check]", message)  # what still holds for these bytes
        self.assertIn("budget is not reset", message)
        self.refused(self.guard("reserve", "run.json", "--event-id", "r1")[1], *THE_WAY)
        self.assertEqual((self.dir / "run.json").read_bytes(), before)  # a refusal writes nothing
        # The way the message names. A lighter review on the way is refused and leaves no trace.
        self.write("decision.json", json.dumps(DECISION, ensure_ascii=False))
        self.write("light.json", json.dumps({"candidate": "draft.md", "mode": "light", "checks": []}))
        code, out = self.guard("replan", "run.json", "--event-id", "p0", "--spec", "light.json", "--decision",
                               "decision.json")
        self.assertEqual((code, out.get("failure")), (2, "INVALID_INPUT"), out)
        self.assertIn("cannot loosen the review policy", out["message"])
        self.assertEqual((self.dir / "run.json").read_bytes(), before)
        code, out = self.guard("replan", "run.json", "--event-id", "p1", "--spec", "checks.json", "--decision",
                               "decision.json")
        self.assertEqual((code, out["current_node"], out["budgets"]["revisions_used"]), (0, "repair", 0), out)
        self.assertEqual(self.gate()[1]["editorial"], "STALE")  # the old PASS is not this generation's conclusion
        self.assertEqual(self.guard("reserve", "run.json", "--event-id", "r1")[0], 0)
        code, out = self.record("v2", reread)  # the same bytes, the same review file that was refused above
        self.assertEqual((code, out["current_node"]), (0, "repair"), out)
        gate = self.gate()[1]
        self.assertEqual((gate["editorial"], gate["candidate_sha256"]), ("NEEDS_REVISION", sha_text(DRAFT)))
        state = self.state()
        self.assertEqual([e["editorial"]["verdict"] for e in state["evidence"]], ["PASS", "NEEDS_REVISION"])
        self.assertEqual({e["context"]["candidate"]["sha256"] for e in state["evidence"]}, {sha_text(DRAFT)})
        self.assertEqual([h["event_id"] for h in state["human_approvals"]], ["p1"])
        self.assertEqual((state["budgets"]["revisions_used"], state["budgets"]["max_revisions"]), (1, 3))
        # The repair goes on with the same budget, and the issue raised after the PASS must be gone or kept.
        self.assertEqual(self.guard("reserve", "run.json", "--event-id", "r2")[0], 0)
        self.write("draft.md", FIXED)
        code, out = self.record("v3", self.review("fixed.json", expression=self.whole(FIXED, decisions=[DELETE, FIX])))
        self.assertEqual((code, out["current_node"]), (0, "complete"), out)
        self.assertEqual(self.gate()[1]["editorial"], "PASS[self_check]")
        state = self.state()
        self.assertEqual([e["editorial"]["verdict"] for e in state["evidence"]], ["PASS", "NEEDS_REVISION", "PASS"])
        self.assertEqual(state["budgets"]["revisions_used"], 2)

    def test_each_node_names_its_own_way(self):
        self.write("checks.json", json.dumps({"candidate": "draft.md", "mode": "strict", "checks": [
            {"id": "ending", "type": "contains", "text": "差点踩进水里。"}]}, ensure_ascii=False))
        code, out = self.guard("start", "run.json", "--task-id", "t", "--spec", "checks.json", "--max-revisions", "1")
        self.assertEqual(code, 0, out)
        message = self.refused(self.guard("reserve", "run.json", "--event-id", "r0")[1], "record")  # draft
        self.assertNotIn("replan", message)
        needs = self.review("needs.json", verdict="NEEDS_REVISION", issues=[ISSUE], expression=self.whole())
        self.assertEqual(self.record("v1", needs)[0], 0)
        message = self.refused(self.record("v2", needs)[1], "reserve first")  # repair
        self.assertNotIn("replan", message)
        self.assertEqual(self.guard("reserve", "run.json", "--event-id", "r1")[0], 0)
        self.assertEqual(self.record("v3", needs)[1]["current_node"], "stopped")  # the only revision was used
        message = self.refused(self.record("v4", needs)[1], "stopped", "Revision budget exhausted", "cannot be reopened")
        self.assertNotIn("replan", message)
        code, out = self.guard("reserve", "run.json", "--event-id", "r2")
        self.assertEqual(out.get("failure"), "BUDGET_EXHAUSTED", out)  # the budget is checked before the route

    def test_a_stale_or_blocked_run_names_its_way(self):
        self.passed()
        self.write("draft.md", FIXED)  # the text changed after the PASS; the new review itself is complete
        again = self.review("again.json", expression=self.whole(FIXED, decisions=[DELETE, FIX]))
        message = self.refused(self.record("v2", again)[1], "STALE", "reserve one recheck")
        self.assertNotIn("author_decision", message)
        self.write("draft.md", DRAFT)
        self.assertEqual(self.gate()[1]["editorial"], "PASS[self_check]")
        missing = {"expected": "测试数据：缺作者的决定", "impact": "测试数据：无法继续"}
        fail = self.review("fail.json", verdict="FAIL", issues=[missing])
        self.write("decision.json", json.dumps(DECISION, ensure_ascii=False))
        self.assertEqual(self.guard("replan", "run.json", "--event-id", "p1", "--spec", "checks.json", "--decision",
                                    "decision.json")[0], 0)
        self.assertEqual(self.guard("reserve", "run.json", "--event-id", "r1")[0], 0)
        self.assertEqual(self.record("v3", fail)[1]["current_node"], "blocked")
        for out in (self.guard("reserve", "run.json", "--event-id", "r2")[1], self.record("v4", fail)[1]):
            self.refused(out, "FAIL", "replan", "author_decision")


if __name__ == "__main__":
    unittest.main()

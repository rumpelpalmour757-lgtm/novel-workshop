#!/usr/bin/env python3
"""r5.24: summaries, recaps and chapter endings are judged by three separate questions; the expression pass is not
replaced by continuity fixes; delivery words follow what was actually done.

The author's 2026-10-20 records describe two failures in one chapter of the author's project (the chapter is not in
this package):
- a whole-chapter revision fixed movement, held objects, injuries, naming and evidence wording, ran the punctuation
  check and the strict gate, recorded six dimensions met, five expression segments and 26 decisions, PASS[self_check],
  and went out as "revised and re-checked". The de-templating content read had not been done: a system unlock said
  again, a preservation result said again and a victory said again at the end stayed in the text.
- a dedicated pass afterwards deleted those but kept the closing paragraph that listed the won items once more and
  declared the reversal, with the reason "a closing that does something; not every summary is deleted"; two agents
  agreed. The author overturned the keep.
The gate verified the records' form and could judge neither. The repair is in the method text and the delivery
wording; no script changed.

What these tests pin:
- the method: three separate questions (factual basis, repetition across the chapter, what it adds here); a keep
  reason names what deleting loses, read with and without the sentence; a reverse test for doubtful keeps; the last
  kept occurrence passes the questions on its own; the anti-over-deletion principle is not a keep reason; the author's
  choices for this book come before the generic keep examples; reviewers agreeing is not a check; no banned words, no
  quota, zero change allowed;
- the expression pass covers repetition, summary narration, short sentences and small actions; continuity fixes,
  punctuation and fact checks do not replace it; a record that is complete in form is not proof it was done;
- delivery wording follows what was done: a check not done is said to be not done, not covered by "已修改并复核";
- invented material (tests/fixtures/summary-judgment) for both directions: every restatement to delete stands on
  earlier text, every keep says what deleting it loses; prose_lint.py finds none of the restatements (NO_FLAGS still
  needs a read in context);
- through the gate: a strict PASS whose notes cover only continuity is accepted (the gate cannot judge it) and only
  "self-checked" may be claimed; a zero-change pass is accepted; a review of one version never passes for the next.
The answers in the fixture are editorial judgments by the same maintainer who wrote the method. They are regression
material for both directions, not a validation that the method makes better decisions; no comparison was run.
"""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
GUARD = SKILL / "scripts" / "workflow_guard.py"
PROSE_LINT = SKILL / "scripts" / "prose_lint.py"
FIXTURE = Path(__file__).resolve().parent / "fixtures" / "summary-judgment"
DIMENSIONS = ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function", "continuity",
              "revision_comparison")
THREE_QUESTIONS = "## 总结、复述和章尾：分开问三件事"


def read(relative):
    return (SKILL / relative).read_text(encoding="utf-8")


def section(text, heading):
    """From a '## ' heading to the next '## ' heading; empty when the heading is missing (each test then fails on its
    own phrases, so a run on an older release shows which guarantees it lacks)."""
    if heading not in text:
        return ""
    return heading + text.split(heading, 1)[1].split("\n## ", 1)[0]


def card_item(prefix):
    return next(line for line in read("assets/delivery-gate-card.md").splitlines() if line.startswith(prefix))


def sha_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


class MethodText(unittest.TestCase):
    """The judgment of summary narration, in the module the L1 level makes required reading."""

    @classmethod
    def setUpClass(cls):
        cls.audit = read("references/prose-audit.md")
        cls.three = section(cls.audit, THREE_QUESTIONS)

    def test_three_questions_are_asked_separately(self):
        for phrase in ("事实有没有依据", "是不是重复", "在这里多出了什么", "各答各的，不能拿前一件的答案顶替后一件",
                       "有依据只说明它没有编造，不说明读者需要再听一遍"):
            self.assertIn(phrase, self.three)
        # Repetition is counted over the whole chapter, not judged in the local paragraph only.
        for phrase in ("演出来的、人物说出来的、系统或旁人确认的都算", "数一数这是第几次", "放回全章"):
            self.assertIn(phrase, self.three)
        # "No new fact" is not the only test: a line without new facts may still carry feeling or voice.
        self.assertIn("不能只按“有没有新事实”判", self.three)

    def test_a_keep_reason_names_what_is_lost_read_with_and_without(self):
        step2 = self.audit.split("\n2. 回到场景裁决", 1)[-1].split("\n3. ", 1)[0]
        self.assertIn("具体多出了什么：哪种情绪、谁的口吻、哪层关系或认识", step2)
        self.assertIn("留着读一遍、删掉读一遍再定", step2)
        self.assertIn("“有余韵”“起收束作用”“有胜负变化”说的是作用的种类，不是这一处的作用，单独不能当理由", step2)
        self.assertIn(THREE_QUESTIONS[3:], step2)  # step 2 points to the section
        record = section(self.audit, "## 整章任务的表达检查与记录")
        self.assertIn("理由写删掉以后具体少了什么，不写“有余韵”“保留一处收束”这类只说种类或数量的话", record)
        table = section(self.audit, "## 去模板腔时引入的新模板")
        self.assertIn("有作用就保留，作用要说得出是哪一样", table)

    def test_reverse_test_and_the_last_kept_occurrence(self):
        for phrase in ("反过来试一次：把它删掉，连着前后段读，写下确实少了什么", "说不出来，就删",
                       "删了以后不另补一句意思相同的点题", "几个人理由相近、都说留，不算做过这一步",
                       "留下的那一处要自己再过一遍这三问", "不能因为“总得留一处”就留最后一处",
                       "再拿“前面已经删了”当留后面的理由"):
            self.assertIn(phrase, self.three)

    def test_the_anti_over_deletion_principle_and_generic_examples_are_not_keep_reasons(self):
        self.assertIn("“不能把总结一概删掉”是防误删的原则，说的是不要整类删；它不是某一句该留的理由", self.three)
        keep = section(self.audit, "## 该保留的写法：和形式相近的问题对照着看")
        self.assertIn("这些例子防的是误删，不是保留的理由", keep)
        group1 = keep.split("**第 1 组：总结。**", 1)[1].split("**第 2 组", 1)[0]
        self.assertIn("托得住只回答了“有没有依据”", group1)
        self.assertIn("作者要的是只写动作、不替读者点明，这一句也可以删", group1)

    def test_the_authors_choices_for_this_book_come_before_generic_examples(self):
        first = section(self.audit, "## 先确定本书的写法")
        self.assertIn("要求清掉替读者总结、解释人物成长的旁白", first)
        self.assertIn("不能拿来顶替作者对这本书的要求", first)
        self.assertIn("先看项目档案和文风卡里有没有相反的要求", first)

    def test_both_directions_in_the_example_and_the_table(self):
        self.assertIn("章尾，要删的：", self.three)
        self.assertIn("章尾，要留的：", self.three)
        self.assertIn("人物的余惊就没了，所以留", self.three)
        table = section(self.audit, "## 去模板腔时引入的新模板")
        self.assertIn("| 再报一遍结果、宣布胜负 |", table)
        self.assertNotIn("若承担叙述声音、强调或信息整理可保留", table)  # the r5.23 loose keep licence

    def test_not_a_banned_word_list_no_quota_and_zero_change_allowed(self):
        self.assertIn("这不是禁词表：“终于”“这一回”“原来”这类说法照样能用，总结也照样能写", self.three)
        self.assertIn("必要的专业解释、人物的余惊和心理、能力的限制，不为显得删得干净而删", self.three)
        self.assertIn("查完确实没有要删的，就零修改", self.three)
        for phrase in ("一律删", "至少删", "必须删", "禁用"):  # no banned list, no quota crept in
            self.assertNotIn(phrase, self.three)
        record = section(self.audit, "## 整章任务的表达检查与记录")
        self.assertIn("可以零修改通过", record)
        self.assertIn("不为证明做过检查去删句、凑问题数或凑修改比例", record)

    def test_agreement_among_reviewers_is_not_a_check(self):
        review = read("references/adversarial-review.md")
        self.assertIn("一句该删该留，也不按票数：几个审读者用相近的理由都主张保留，不等于检验过", review)
        self.assertIn("裁决由综合者对着原文做，并对它负责", review)
        loop = read("references/quality-loop.md")
        self.assertIn("删留这类表达裁决也不按人数", loop)


class ExpressionPassAndClaims(unittest.TestCase):
    """What the whole-chapter expression pass covers, what does not replace it, and what may be said at delivery."""

    def test_the_pass_covers_three_contents_and_continuity_fixes_do_not_replace_it(self):
        record = section(read("references/prose-audit.md"), "## 整章任务的表达检查与记录")
        self.assertIn("这一遍的内容判断要盖住三样：重复说明和教学式复述；没有现场作用的总结旁白", record)
        self.assertIn("短句和小动作在上下文里有没有作用", record)
        self.assertIn("开工时把这一遍单列进本轮要做的事", record)
        self.assertIn("动作、持物、伤势、称谓、证据措辞这些连续性修正改得再全，标点检查再干净，都不能代替这一遍", record)
        self.assertIn("只写了动作、连续性修正的一段，这一段的表达检查就是没做", record)
        loop = read("references/quality-loop.md")
        self.assertIn("动作、连续性、称谓和标点的修正是别的检查，改得再全也不算这一遍", loop)
        level = next(line for line in read("SKILL.md").splitlines() if line.startswith("| L1 整章 |"))
        self.assertIn("动作、连续性和标点的修正不顶替它", level)
        item4 = card_item("4. **去模板腔")
        self.assertIn("判重复、总结旁白、短句和小动作", item4)
        self.assertIn("连续性改全了都不能免", item4)
        self.assertIn("存疑的保留，删掉连读一遍，说不出少了什么就删，不补同义点题", item4)

    def test_a_record_complete_in_form_is_not_proof(self):
        record = section(read("references/prose-audit.md"), "## 整章任务的表达检查与记录")
        self.assertIn("交付门接受了一条保留理由，只说明它写了，不说明它成立；分段齐全、处理记录多，也只说明记了", record)
        self.assertIn("通用的“已检查、无问题”不算", record)
        self.assertIn("分段齐全、处理记录多，只说明记了", read("references/quality-loop.md"))
        self.assertIn("交付门只核对写没写，不核对理由成不成立", read("references/execution.md"))

    def test_delivery_words_follow_what_was_done(self):
        states = section(read("references/quality-loop.md"), "## 交付状态：四项分开，未测不算通过")
        for phrase in ("交付措辞跟着状态走，也跟着实际做了的事走", "说“已复核”“已检查”时说清查了哪几样",
                       "就照实写它“未做”“未完成”，编辑审查记 UNTESTED", "不用一句笼统的“已修改并复核”盖过去",
                       "标点检查通过、哈希对得上、六个维度写满，都替代不了去模板腔的判断"):
            self.assertIn(phrase, states)
        level = next(line for line in read("SKILL.md").splitlines() if line.startswith("| L1 整章 |"))
        self.assertIn("交付时照实说哪样没做", level)
        self.assertIn("没读的模块不说按它查过，没做的检查不说做过", card_item("10. **记录本轮实际读过的模块**"))

    def test_no_second_pass_and_no_script_is_required(self):
        # Not mis-fixed into "always run a second pass" or "the check counts only if prose_lint ran".
        record = section(read("references/prose-audit.md"), "## 整章任务的表达检查与记录")
        # r5.33 (the author chose on 2026-10-22 that whole-chapter writing and revision go through the five revision
        # passes, references/revision-passes.md): "one reading is enough, no second pass" yielded to that decision. What
        # this test guards stays: the script is only an aid, and the three things the check judges are still judged.
        self.assertIn("整章写作和整章修改默认按 [修改的五道工序](revision-passes.md) 分几遍读（r5.33，作者 10-22 选定）", record)
        self.assertIn("`prose_lint.py` 是第一遍的辅助，跑没跑都不改变每一遍要判的东西", record)
        self.assertNotIn("不要求另跑一遍", record)

    def test_the_review_template_asks_for_the_concrete_loss(self):
        template = json.loads(read("assets/editorial-review-template.json"))
        self.assertIn("总结旁白", template["expression"]["segments"][0]["note"])
        keep = next(d for d in template["expression"]["decisions"] if d["decision"] == "keep")
        self.assertIn("具体少了什么", keep["reason"])
        self.assertIn("“有余韵”“保留一处收束”只说了种类和数量，不是理由", template["note"])


class InventedMaterial(unittest.TestCase):
    """tests/fixtures/summary-judgment: both directions, standing on the text; not a validation."""

    @classmethod
    def setUpClass(cls):
        cls.key = json.loads((FIXTURE / "answer-key.json").read_text(encoding="utf-8"))
        cls.texts = {name: (FIXTURE / name).read_text(encoding="utf-8") for name in cls.key["chapters"]}

    def test_every_case_stands_on_the_text(self):
        generic = ("有余韵", "有收束", "起收束作用", "有胜负变化", "保留一处")
        for case in self.key["cases"]:
            text = self.texts[case["file"]]
            self.assertEqual(text.count(case["quote"]), 1, case["id"])
            at = text.index(case["quote"])
            for earlier in case.get("earlier", []):
                self.assertEqual(text.count(earlier), 1, (case["id"], earlier))
                self.assertLess(text.index(earlier), at, (case["id"], earlier))  # said before, not after
            if case["decision"] == "delete":
                self.assertTrue(case["earlier"], case["id"])  # a restatement names where it was said first
                self.assertTrue(case["why"], case["id"])
            else:
                self.assertEqual(case["decision"], "keep")
                loss = case["loss_if_deleted"]
                self.assertGreaterEqual(len(loss), 30, case["id"])
                self.assertFalse(any(word in loss for word in generic), (case["id"], loss))

    def test_both_directions_are_covered(self):
        kinds = {c["kind"]: c["decision"] for c in self.key["cases"]}
        for kind in ("system_unlock_restatement", "preservation_restatement", "second_victory_summary"):
            self.assertEqual(kinds[kind], "delete", kind)          # the record's case A
        for kind in ("professional_causality", "lingering_fright", "set_up_ending", "character_voice"):
            self.assertEqual(kinds[kind], "keep", kind)            # the record's case B
        self.assertEqual(self.key["chapters"]["chapter-b.md"]["changes"], 0)   # case E: zero change
        self.assertTrue(all(c["decision"] == "keep" for c in self.key["cases"] if c["file"] == "chapter-b.md"))

    def test_the_expected_revision_deletes_only_the_restatements(self):
        original = self.texts["chapter-a.md"]
        revised = (FIXTURE / "chapter-a-revised.md").read_text(encoding="utf-8")
        expected = original
        for case in self.key["cases"]:
            if case["file"] == "chapter-a.md" and case["decision"] == "delete":
                expected = expected.replace(case["quote"] + "\n\n", "")
        self.assertEqual(revised, expected)
        for case in self.key["cases"]:
            if case["file"] == "chapter-a.md" and case["decision"] == "keep":
                self.assertIn(case["quote"], revised, case["id"])
        # The same outcome said by a character stays, said again by the narrator at the end goes.
        self.assertIn("“这一回，是咱们先到了一步。”", revised)
        self.assertNotIn("先乱了阵脚的是对面", revised)

    def test_prose_lint_finds_none_of_the_restatements(self):
        # The record's case D: NO_FLAGS from the literal checker; the restatements still need a read in context.
        for name in ("chapter-a.md", "chapter-b.md"):
            proc = subprocess.run([sys.executable, "-I", "-B", str(PROSE_LINT), str(FIXTURE / name)],
                                  capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(proc.returncode, 0, proc.stderr)
            out = json.loads(proc.stdout)
            self.assertEqual(out["status"], "NO_FLAGS", (name, out))
        audit = read("references/prose-audit.md")
        self.assertIn("`NO_FLAGS` 只表示这些有限规则未命中，既不是文笔通过", audit)


class Brief(dict):
    def __repr__(self):
        if "failure" in self:
            return "%s: %s" % (self["failure"], self.get("message"))
        return "ok"


class GateCases(unittest.TestCase):
    """The gate checks form; these pin what it does and does not tell (the records' cases C, E and F)."""

    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        self.key = json.loads((FIXTURE / "answer-key.json").read_text(encoding="utf-8"))

    def tearDown(self):
        shutil.rmtree(self.dir)

    def write(self, name, text):
        (self.dir / name).write_bytes((text).encode("utf-8"))

    def guard(self, *args):
        proc = subprocess.run([sys.executable, "-I", "-B", str(GUARD), *args], cwd=self.dir, capture_output=True,
                              text=True, encoding="utf-8")
        try:
            return proc.returncode, Brief(json.loads(proc.stdout))
        except ValueError:
            return proc.returncode, Brief({"failure": "NO_JSON", "message": (proc.stdout + proc.stderr)[-400:]})

    def start(self, source_text, draft_text, ending):
        self.write("original.md", source_text)
        self.write("draft.md", draft_text)
        spec = {"candidate": "draft.md", "mode": "strict",
                "checks": [{"id": "ending", "type": "contains", "text": ending},
                           {"id": "freeze", "type": "file_hash", "source": "original.md",
                            "sha256": sha_text(source_text)}]}
        self.write("checks.json", json.dumps(spec, ensure_ascii=False))
        code, out = self.guard("start", "run.json", "--task-id", "t", "--spec", "checks.json")
        self.assertEqual(code, 0, out)

    def segments(self, text, notes):
        """One segment per group of paragraphs (title line excluded), anchored by first and last characters."""
        paras = [p.strip() for p in text.split("\n\n") if p.strip()][1:]
        size = -(-len(paras) // len(notes))
        out = []
        for number, note in enumerate(notes):
            chunk = paras[number * size:(number + 1) * size]
            out.append({"from": chunk[0][:6], "to": chunk[-1][-6:], "note": note})
        return out

    def review(self, name, text, quotes, notes, decisions):
        value = {"schema": "editorial-review/2", "verdict": "PASS", "candidate_sha256": sha_text(text),
                 "reviewer": {"mode": "self_check", "label": "测试数据：只验证记录结构"},
                 "checked_against": ["测试数据：original.md"], "inputs_read": ["original.md"],
                 "evidence": [{"quote": q, "in": "candidate"} for q in quotes], "issues": [],
                 "machine_dispositions": [], "counter_evidence": "测试数据，不是真实文学审稿。",
                 "dimensions": [{"id": key, "status": "met", "note": "测试数据：只验证记录结构"} for key in DIMENSIONS],
                 "expression": {"scope": "chapter", "segments": self.segments(text, notes), "decisions": decisions}}
        self.write(name, json.dumps(value, ensure_ascii=False))
        return name

    def gate(self, *extra):
        code, out = self.guard("status", "run.json", *extra)
        return out.get("gate", out)

    def keeps(self, name):
        return [{"decision": "keep", "quote": c["quote"], "judgment": "测试数据：" + c["kind"],
                 "reason": "测试数据：" + c["loss_if_deleted"]}
                for c in self.key["cases"] if c["file"] == name and c["decision"] == "keep"]

    def test_a_form_complete_record_covering_only_continuity_is_accepted_and_allows_only_self_check_words(self):
        # Case C. The candidate fixes a held object; the notes speak of movement, objects and injuries only.
        draft = (FIXTURE / "chapter-a.md").read_text(encoding="utf-8")
        source = draft.replace("闻笛把U盘塞进内兜", "闻笛把U盘塞进外套口袋")
        self.start(source, draft, "今晚是圆不回来了。")
        fix = {"decision": "change", "before": "闻笛把U盘塞进外套口袋", "after": "闻笛把U盘塞进内兜",
               "judgment": "测试数据：持物位置和前文对上", "reason": "测试数据：只修了持物"}
        notes = ["测试数据：第%d组核对了移动、持物和伤势" % n for n in range(1, 5)]
        code, out = self.guard("record", "run.json", "--event-id", "v1", "--review",
                               self.review("continuity-only.json", draft,
                                           ("闻笛把耳朵贴在冷库门上", "看门的老头站在泄压阀边上", "今晚是圆不回来了"),
                                           notes, [fix]))
        self.assertEqual(code, 0, out)  # the gate cannot tell that the content read was not done
        gate = self.gate()
        self.assertEqual(gate["editorial"], "PASS[self_check]")
        for case in self.key["cases"]:
            if case["file"] == "chapter-a.md" and case["decision"] == "delete":
                self.assertIn(case["quote"], draft)  # the restatements are still there, and nothing objected
        claims = gate["permissions"]
        self.assertEqual(claims["claim_reviewed"]["decision"], "ALLOW_WITH_WARNING")
        self.assertIn("只能说“已自查”", claims["claim_reviewed"]["reason"])
        self.assertEqual(claims["claim_independent_review"]["decision"], "BLOCK")
        self.assertIn("编辑结论为同一模型自查", gate["deliverable_label"])
        self.assertIn("保留理由和反证都由审稿记录自报", gate["limits"])
        # What the method says of this record: the expression pass was not done in these segments.
        record = section(read("references/prose-audit.md"), "## 整章任务的表达检查与记录")
        self.assertIn("只写了动作、连续性修正的一段，这一段的表达检查就是没做", record)

    def test_a_zero_change_pass_with_located_keeps_is_accepted(self):
        # Case E: the whole text read, nothing to change, the keeps say what deleting would lose.
        text = (FIXTURE / "chapter-b.md").read_text(encoding="utf-8")
        self.start(text, text, "正踮着脚往码头这边看。")
        notes = ["测试数据：上船和过河，看了重复、总结和短句，姑妈信里那句留着",
                 "测试数据：靠岸到粮站，看了说明和小动作，船工那句交代和抹泥留着"]
        code, out = self.guard("record", "run.json", "--event-id", "v1", "--review",
                               self.review("zero.json", text, ("阿简把船票折成两折", "阿简点点头，把外套的扣子", "正踮着脚往码头这边看"),
                                           notes, self.keeps("chapter-b.md")))
        self.assertEqual(code, 0, out)
        gate = self.gate()
        self.assertEqual((gate["mechanical"], gate["editorial"], gate["stage"]),
                         ("GREEN", "PASS[self_check]", "READY_FOR_AUTHOR"))
        self.assertEqual(gate["expression"]["decisions"]["change"], 0)

    def test_a_review_never_carries_over_to_changed_text(self):
        # Case F: a review of one version is not the review of the next, however small the change.
        source = (FIXTURE / "chapter-a.md").read_text(encoding="utf-8")
        revised = (FIXTURE / "chapter-a-revised.md").read_text(encoding="utf-8")
        self.start(source, revised, "今晚是圆不回来了。")
        deletes = [{"decision": "change", "before": c["quote"], "after": "", "judgment": "测试数据：" + c["kind"],
                    "reason": "测试数据：" + c["why"]}
                   for c in self.key["cases"] if c["file"] == "chapter-a.md" and c["decision"] == "delete"]
        notes = ["测试数据：开头到泄压，专业因果留着", "测试数据：日志和剪线，两处复述删了",
                 "测试数据：老头和站长，余惊和老葛那句留着", "测试数据：回家，章尾报结果删了、母亲那句留着"]
        quotes = ("出门前，闻笛跟母亲说", "看门的老头站在泄压阀边上", "今晚是圆不回来了")
        name = self.review("pass.json", revised, quotes, notes, deletes + self.keeps("chapter-a.md"))
        code, out = self.guard("record", "run.json", "--event-id", "v1", "--review", name)
        self.assertEqual(code, 0, out)
        self.assertEqual(self.gate()["editorial"], "PASS[self_check]")
        # A closing line is added back after the review.
        edited = revised.replace("她把车停在楼下，抬头看见自家窗户还亮着。\n",
                                 "她把车停在楼下，抬头看见自家窗户还亮着。这一夜，总算是他们赢了。\n")
        self.assertNotEqual(edited, revised)
        self.write("draft.md", edited)
        gate = self.gate()
        self.assertEqual((gate["mechanical"], gate["editorial"]), ("STALE", "STALE"))
        gate = self.gate("--deliverable", "draft.md")
        self.assertEqual(gate["deliverable"]["matches"], "no")
        for claim in ("claim_mechanical_pass", "claim_reviewed", "claim_final"):
            self.assertEqual(gate["permissions"][claim]["decision"], "BLOCK", claim)
        code, out = self.guard("record", "run.json", "--event-id", "v2", "--review", name)
        self.assertEqual(out.get("failure"), "REVIEW_STALE", out)


if __name__ == "__main__":
    unittest.main()

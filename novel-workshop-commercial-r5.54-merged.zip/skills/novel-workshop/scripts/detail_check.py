#!/usr/bin/env python3
"""Detail check (r5.44): what an original had and its revision lost, and the report-like forms the revision brought in.

python3 detail_check.py compare ORIGINAL REVISED [--format text|json]
python3 detail_check.py changes ORIGINAL REVISED [--keep KEEP.txt] [--format text|json]
python3 detail_check.py anchors ANCHORS.json [ANCHORS.json ...] --self-test [--format text|json]
python3 detail_check.py anchors ANCHORS.json [ANCHORS.json ...] --prompts DIR
python3 detail_check.py anchors ANCHORS.json [ANCHORS.json ...] --outputs DIR [--format text|json]

compare lists, for the author to decide (references/editing.md, "修订前后对照"):
  - wording the original had and the revision no longer has anywhere (Chinese character pairs, grouped into the
    stretches of each original sentence; wording that only moved is not listed);
  - directional complements that are gone (漫了过来, 冒了出来, 退了回去 ...);
  - clauses of the form "X是Y的" that are new in the revision, outside dialogue (the report-like judgment sentence:
    阁楼的窗是圆的);
  - position words that are new in the revision (画面中央, 左下角 ...);
  - the number of Chinese characters on each side.
It compares letters only: a reworded phrase is listed too, and whether a lost detail mattered is for a person to read.
Nothing is changed and nothing is decided; compare always exits 0 (2 on a usage or file error).

changes (r5.49) lines the two texts up sentence by sentence and lists, with paragraph and sentence numbers:
  - deleted sentences (no similar sentence in the revision), with the words of each that the revision still has
    elsewhere; added sentences; changed sentences, the two sides one under the other with the letters that differ;
  - dialogue (inside “” or 「」) that changed, went or is new;
  - with --keep (one sentence per line): each line 原样在 / 改了 (with the closest sentence) / 找不到;
  - numbers with a unit or classifier (三辆, 7点, 5公里) that went or are new, counted on each side;
  - sentences that only moved, and "对不上": moved and changed, one split into several, several merged into one, or
    pairs it cannot tell (拿不准) -- these are not guessed into deleted/added/changed.
  Paragraph = a non-empty line. A sentence ends at 。！？!?…… (closing quotes and brackets stay with it) and at a line
  break, never inside “” 「」 『』: a quote stays with its speech tag. Similarity is difflib's ratio on the letters
  (punctuation and spaces dropped). What stayed in place is the heaviest chain, in order on both sides, of sentences
  with the same text and pairs at or above SIMILAR (0.5), a sentence against a run of 2..MAX_GROUP sentences counting
  as a split or merge when it beats the best one-to-one pairing by GROUP_MARGIN. Sentences left over between two links
  of the chain are paired again; from UNSURE (0.35) up to 0.5 they are listed as 拿不准, not guessed. A similar sentence
  somewhere else is moved and changed; it takes a sentence away from a same-place pairing when it is closer by
  MOVE_MARGIN (0.2, the same text counting 1.0) and nothing else left over is as close to it, and the same-place partner
  is then deleted or added. Numbers count with a unit or classifier only; a lone 一 半 零 counts only before a measure
  unit (一年, 半斤), so 一丝 一股 are not numbers; thousands separators are dropped (3,000元 and 3，000元 count as
  3000元), so three-digit numbers listed with "，" (101，102号) read as one number ("、" lists are read one by one). It
  compares letters only; whether a change works is for a person to read. changes exits 0 (2 on a usage or file
  error).

anchors works on writing anchors (references/skill-evaluation.md, "写作对照例"): passages with a text to revise and the
author's approved revision, the details that must survive (keep) and the forms that must go (avoid). --self-test checks
that every approved revision passes and every text to revise that differs from it fails; --prompts writes one request
per anchor for a fresh writer; --outputs checks the writers' revisions (DIR/<id>.txt). A revision fails when a keep item
is missing, an avoid item is left, or it brings in a new "X是Y的" clause or a new position word; lost wording and lost
complements are listed, not failed (the author's own fixes drop some). Exit 0 when all pass, 1 otherwise, 2 on errors.
Read-only, standard library only; it calls no model.
"""
import argparse
import difflib
import json
from pathlib import Path
import re
import sys

FORMAT = "novel-workshop-detail-check"
ANCHOR_FORMAT = "novel-workshop-writing-anchors"
HAN = r"㐀-䶿一-鿿"
HAN_RUN = re.compile("[" + HAN + "]+")
HAN_CHAR = re.compile("[" + HAN + "]")
# Characters that carry grammar more than content: a pair made only of these is never listed as a lost detail.
FUNCTION = set("的了是着过地得在把被就也都又还很和与及而并但却才再已将这那一个些么吗呢吧啊呀他她它我你们之其所以于为"
               "从向往对给让叫使比跟同至更最太极不没无未有来去上下里中后前子儿啦嘛哦嗯哈呵哎唉便即")
# Particles trimmed off the ends of a listed stretch (negations, places and pronouns stay: they carry meaning).
PARTICLES = set("的了着过地得是在把被就也都又还很和与及而并但却才再已将这那么吗呢吧啊呀们之其所以于为从向往对给让叫使"
                "比跟同至更最太极便即啦嘛哦嗯有")
PRONOUNS = set("他她它我你")  # trimmed off the front only: "他用手" lists as "用手"
COMPLEMENTS = ("起来", "出来", "出去", "进来", "进去", "上来", "上去", "下来", "下去", "回来", "回去", "过来", "过去", "开来")
COMPLEMENT = re.compile("(?:" + "|".join(COMPLEMENTS) + ")")
# "X起来" in the sense "when X-ing, it seems": not a movement, not listed.
NOT_MOVEMENT = {"看起来", "看上去", "听起来", "听上去", "说起来", "算起来", "比起来", "闻起来", "摸起来", "吃起来", "用起来",
                "想起来"}
NOT_VERB = set("的了是着得地不没也都就还又再才便却很")
JUDGMENT = re.compile("^([^是]{1,12})是([^是]{1,8})的$")
POSITION = re.compile("(?:视野|视线|屏幕|画面)的?(?:正中央|正中|中央|中间|中心|边缘|左侧|右侧|上方|下方|左上角|右上角|左下角|右下角)"
                      "|正中央|[左右][上下]角")
SENTENCE_END = re.compile("[。！？!?；;…\n]+")
CLAUSE_SPLIT = re.compile("[，,。！？!?；;：:、…\n]+")
QUOTE = re.compile("“[^”]*”|「[^」]*」|『[^』]*』|\"[^\"]*\"")
NOTE = ("只比字面：换了说法的也会列出来，删掉的东西有没有作用要人读；几项都是 0，也不说明原来的毛病改到了、没改坏。"
        "留不留由作者定，不按清单自动改回，也不为清单变短少改。")


class CheckError(Exception):
    pass


def read_text(path):
    try:
        data = Path(path).read_bytes()
    except OSError as exc:
        raise CheckError("cannot read %s: %s" % (path, exc)) from exc
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise CheckError("%s is not UTF-8: %s" % (path, exc)) from exc
    return text.replace("\r\n", "\n").replace("\r", "\n")


def han_count(text):
    return len(HAN_CHAR.findall(text))


def sentences(text):
    """(start, end, text) of each sentence, the end mark included."""
    out, start = [], 0
    for m in SENTENCE_END.finditer(text):
        if text[start:m.end()].strip():
            out.append((start, m.end(), text[start:m.end()]))
        start = m.end()
    if text[start:].strip():
        out.append((start, len(text), text[start:]))
    return out


def bigrams(text):
    pairs = set()
    for run in HAN_RUN.findall(text):
        pairs.update(run[i:i + 2] for i in range(len(run) - 1))
    return pairs


def content_pair(pair):
    return not (pair[0] in FUNCTION and pair[1] in FUNCTION)


def complements(text):
    """(key, form, position) of each directional complement: key is verb + complement (了 dropped)."""
    found = []
    for m in COMPLEMENT.finditer(text):
        p = m.start()
        q = p - 1
        if q >= 0 and text[q] == "了":
            q -= 1
        if q < 0 or not HAN_CHAR.match(text[q]) or text[q] in NOT_VERB:
            continue
        key = text[q] + m.group()
        if key in NOT_MOVEMENT:
            continue
        found.append((key, text[q:m.end()], p))
    return found


def has_complement(text, key):
    return re.search(re.escape(key[0]) + "了?" + re.escape(key[1:]), text) is not None


def outside_quotes(text):
    return QUOTE.sub(lambda m: "\n" * len(m.group()), text)


def judgment_clauses(text):
    return [c.strip() for c in CLAUSE_SPLIT.split(outside_quotes(text)) if JUDGMENT.match(c.strip())]


def sentence_of(spans, pos):
    for k, (start, end, _) in enumerate(spans, 1):
        if start <= pos < end:
            return k
    return len(spans)


def short(text, limit=60):
    text = text.strip().replace("\n", " ")
    return text if len(text) <= limit else text[:limit - 1] + "…"


def lost_wording(original, revised, lost_forms):
    kept = bigrams(revised)
    rows = []
    for k, (start, end, sent) in enumerate(sentences(original), 1):
        spans = []
        for m in HAN_RUN.finditer(sent):
            run = m.group()
            lost = [i for i in range(len(run) - 1) if content_pair(run[i:i + 2]) and run[i:i + 2] not in kept]
            groups, cur = [], []
            for i in lost:
                if cur and i != cur[-1] + 1:
                    groups.append(cur)
                    cur = []
                cur.append(i)
            if cur:
                groups.append(cur)
            for g in groups:
                a, b = g[0], g[-1] + 1  # characters a..b of the run
                if a > 0 and run[a - 1:a + 1] in kept:
                    a += 1  # its first character still stands in a kept pair: it only lost its neighbour
                if b < len(run) - 1 and run[b:b + 2] in kept:
                    b -= 1
                piece = run[a:b + 1]
                for form in lost_forms:
                    piece = piece.replace(form, "　")
                for part in piece.split("　"):
                    while part and (part[0] in PARTICLES or part[0] in PRONOUNS):
                        part = part[1:]
                    while part and part[-1] in PARTICLES:
                        part = part[:-1]
                    if len(part) >= 2 and any(ch not in FUNCTION for ch in part) and part not in revised and part not in spans:
                        spans.append(part)
        if spans:
            rows.append({"sentence": k, "context": short(sent), "spans": spans})
    return rows


def compare(original, revised):
    orig_sent, rev_sent = sentences(original), sentences(revised)
    lost_comp = []
    for key, form, pos in complements(original):
        if not has_complement(revised, key) and form not in [c["form"] for c in lost_comp]:
            lost_comp.append({"form": form, "key": key, "sentence": sentence_of(orig_sent, pos),
                              "context": short(orig_sent[sentence_of(orig_sent, pos) - 1][2]) if orig_sent else ""})
    lost_forms = sorted({c["form"] for c in lost_comp} | {c["key"] for c in lost_comp}, key=len, reverse=True)
    wording = lost_wording(original, revised, lost_forms)
    before_clauses = set(judgment_clauses(original))
    new_judgments = []
    for clause in judgment_clauses(revised):
        if clause not in before_clauses and clause not in [j["clause"] for j in new_judgments]:
            pos = revised.find(clause)
            new_judgments.append({"clause": clause, "sentence": sentence_of(rev_sent, pos)})
    new_positions = []
    for m in POSITION.finditer(outside_quotes(revised)):
        text = m.group()
        if revised.count(text) > original.count(text) and text not in [p["text"] for p in new_positions]:
            k = sentence_of(rev_sent, m.start())
            new_positions.append({"text": text, "sentence": k, "context": short(rev_sent[k - 1][2]) if rev_sent else ""})
    han = {"original": han_count(original), "revised": han_count(revised)}
    listed = bool(wording or lost_comp or new_judgments or new_positions)
    return {"format": FORMAT, "format_version": 1, "status": "LISTED" if listed else "NOTHING_LISTED", "han": han,
            "lost_wording": wording, "lost_complements": lost_comp, "new_judgments": new_judgments,
            "new_positions": new_positions, "note": NOTE}


def compare_text(report, original_label="原稿", revised_label="修订稿"):
    han = report["han"]
    diff = han["revised"] - han["original"]
    pct = (" %+d%%" % round(diff * 100 / han["original"])) if han["original"] else ""
    change = "一样多" if diff == 0 else "%s %d 字%s" % ("多" if diff > 0 else "少", abs(diff), pct)
    lines = ["细节保留核对（%s → %s）" % (original_label, revised_label),
             "- 汉字：%s %d 字，%s %d 字（%s）" % (original_label, han["original"], revised_label, han["revised"], change)]
    lines.append("- %s里有、%s里没了的说法：%d 句" % (original_label, revised_label, len(report["lost_wording"])))
    for row in report["lost_wording"]:
        lines.append("  第 %d 句「%s」：没了%s" % (row["sentence"], row["context"], "、".join("“%s”" % s for s in row["spans"])))
    lines.append("- 没了的动态补语：%d 处" % len(report["lost_complements"]))
    for row in report["lost_complements"]:
        lines.append("  第 %d 句「%s」：“%s”" % (row["sentence"], row["context"], row["form"]))
    lines.append("- 新出现的“X是Y的”判断句（台词外）：%d 处" % len(report["new_judgments"]))
    for row in report["new_judgments"]:
        lines.append("  %s第 %d 句：“%s”" % (revised_label, row["sentence"], row["clause"]))
    lines.append("- 新出现的坐标说法：%d 处" % len(report["new_positions"]))
    for row in report["new_positions"]:
        lines.append("  %s第 %d 句「%s」：“%s”" % (revised_label, row["sentence"], row["context"], row["text"]))
    lines.append(report["note"])
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------- anchors

def load_anchors(paths):
    anchors, seen = [], set()
    for path in paths:
        try:
            data = json.loads(read_text(path))
        except json.JSONDecodeError as exc:
            raise CheckError("%s is not readable JSON: %s" % (path, exc)) from exc
        problems = anchor_problems(data)
        if problems:
            raise CheckError("%s has problems: %s" % (path, "; ".join(problems[:5])))
        for a in data["anchors"]:
            if a["id"] in seen:
                raise CheckError("anchor id used twice: " + a["id"])
            seen.add(a["id"])
            anchors.append(dict(a, task=a.get("task") or data["task"], file=str(path)))
    if not anchors:
        raise CheckError("no anchors")
    return anchors


def anchor_problems(data):
    if not isinstance(data, dict) or data.get("format") != ANCHOR_FORMAT:
        return ["format must be " + ANCHOR_FORMAT]
    problems = []
    if data.get("format_version") != 1:
        problems.append("format_version must be 1")
    if not (isinstance(data.get("task"), str) and data["task"].strip()):
        problems.append("task (the request the writer gets) must be text")
    items = data.get("anchors")
    if not isinstance(items, list) or not items:
        return problems + ["anchors must be a non-empty list"]
    fields = {"id", "source", "task", "before", "approved_after", "keep", "avoid", "why"}
    for n, a in enumerate(items):
        where = "anchors[%d]" % n
        if not isinstance(a, dict):
            problems.append(where + " is not an object")
            continue
        where = a.get("id") if isinstance(a.get("id"), str) else where
        extra = sorted(set(a) - fields)
        if extra:
            problems.append(where + ": unknown fields " + ", ".join(extra))
        for f in ("id", "source", "before", "approved_after", "why"):
            if not (isinstance(a.get(f), str) and a[f].strip()):
                problems.append(where + ": " + f + " must be text")
        if "task" in a and not (isinstance(a["task"], str) and a["task"].strip()):
            problems.append(where + ": task, when given, must be text")
        for f in ("keep", "avoid"):
            if not (isinstance(a.get(f), list) and all(isinstance(x, str) and x.strip() for x in a[f])):
                problems.append(where + ": " + f + " must be a list of phrases")
        if problems:
            continue
        if not a["keep"]:
            problems.append(where + ": keep is empty (what must survive?)")
        for x in a["keep"]:
            if x not in a["before"] or x not in a["approved_after"]:
                problems.append(where + ": keep item %s must stand in before and in approved_after" % x)
        for x in a["avoid"]:
            if x in a["approved_after"]:
                problems.append(where + ": avoid item %s stands in the approved revision" % x)
    return problems


def check_candidate(anchor, text):
    listing = compare(anchor["before"], text)
    missing = [x for x in anchor["keep"] if x not in text]
    left = [x for x in anchor["avoid"] if x in text]
    reasons = []
    if missing:
        reasons.append("少了：" + "、".join(missing))
    if left:
        reasons.append("还留着：" + "、".join(left))
    if listing["new_judgments"]:
        reasons.append("新出现判断句：" + "、".join(j["clause"] for j in listing["new_judgments"]))
    if listing["new_positions"]:
        reasons.append("新出现坐标：" + "、".join(p["text"] for p in listing["new_positions"]))
    return {"id": anchor["id"], "status": "FAIL" if reasons else "PASS", "reasons": reasons, "missing_keep": missing,
            "avoid_left": left, "listing": listing}


def prompt_text(anchor):
    return ("作者发来一段文字，要你照小说写作工坊的方法改。\n\n作者的话：%s\n\n要改的文字：\n%s\n\n只交改好的正文，不加说明。\n"
            % (anchor["task"], anchor["before"]))


def anchors_text(results, title):
    lines = [title]
    for r in results:
        if r["status"] == "MISSING":
            lines.append("- %s：没有输出（%s），不算通过" % (r["id"], r.get("path", "")))
            continue
        lines.append("- %s：%s%s" % (r["id"], "通过" if r["status"] == "PASS" else "不通过", "；" + "；".join(r["reasons"]) if r["reasons"] else ""))
        info = []
        listing = r.get("listing") or {}
        if listing.get("lost_wording"):
            info.append("没了的说法：" + "、".join(s for row in listing["lost_wording"] for s in row["spans"]))
        if listing.get("lost_complements"):
            info.append("没了的动态补语：" + "、".join(c["form"] for c in listing["lost_complements"]))
        if info:
            lines.append("  （列出，不算不通过）" + "；".join(info))
    passed = sum(r["status"] == "PASS" for r in results)
    lines.append("通过 %d 个，共 %d 个。" % (passed, len(results)))
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------- changes (r5.49)

CHANGES_FORMAT = FORMAT + "-changes"
SIMILAR = 0.5       # difflib ratio on the letters at or above which two sentences count as one sentence changed
UNSURE = 0.35       # from here up to SIMILAR, two sentences in the same changed stretch are listed as 拿不准
GROUP_MARGIN = 0.05  # a split or a merge must beat the best one-to-one pairing of its single sentence by this much
MOVE_MARGIN = 0.2   # a sentence elsewhere takes a same-place pairing's sentence when it is closer by this much
MAX_GROUP = 4       # a sentence split into, or merged from, at most this many sentences
BAND = 15           # inside a long changed stretch, a sentence is compared with this many places either side
END_MARKS = "。！？!?…"
OPEN_QUOTES = "“「『"
CLOSE_QUOTES = "”」』"
CLOSERS = "”」』’）)》"
SPACE = re.compile(r"\s+")
NOT_LETTER = re.compile(r"[\W_]+")
DIALOGUE = re.compile("“[^”\n]*(?:”|$)|「[^」\n]*(?:」|$)")
CN_DIGITS = "零〇一二两三四五六七八九十百千万亿半"
# Alone, 一 半 零 〇 mostly mean "a", "half" or nothing countable (一丝, 一股, 半点): counted only before a measure unit.
LONE = set("一半零〇")
MEASURE_UNITS = ("平方公里", "平方米", "摄氏度", "公里", "公斤", "千克", "厘米", "毫米", "毫升", "小时", "分钟", "钟头",
                 "星期", "礼拜", "点钟", "世纪", "块钱", "毛钱", "年", "月", "天", "日", "夜", "斤", "两", "克", "吨", "米",
                 "里", "丈", "尺", "寸", "亩", "升", "元", "岁", "秒")
CLASSIFIERS = ("个", "只", "条", "张", "把", "根", "支", "枝", "本", "件", "块", "片", "头", "匹", "辆", "架", "座", "栋",
               "间", "扇", "道", "封", "首", "句", "级", "名", "位", "口", "双", "对", "副", "套", "群", "串", "排", "行",
               "杯", "碗", "瓶", "壶", "盒", "包", "袋", "箱", "桶", "盆", "锅", "盘", "碟", "勺", "次", "回", "遍", "趟",
               "下", "声", "步", "眼", "枪", "刀", "拳", "脚", "圈", "页", "章", "节", "颗", "粒", "滴", "缕", "股", "阵",
               "场", "顿", "份", "针", "盏", "台", "部", "艘", "人", "户", "家", "种", "样", "门", "发", "枚", "具", "幅",
               "卷", "层", "楼", "号", "点", "分", "度", "倍", "成", "届", "代", "辈", "角", "毛", "笔", "桌", "床", "顶",
               "列", "班", "站", "所", "面", "处", "筐", "篮", "捆", "担", "沓", "叠", "摞", "堆", "截", "段")
ASCII_UNITS = ("km", "kg", "cm", "mm", "ml", "mg", "m", "g")
_UNITS = sorted(set(MEASURE_UNITS + CLASSIFIERS), key=len, reverse=True)
# Arabic digits, with thousands separators (3,000 or 3，000: 1-3 digits, then groups of three) read as one number; a
# separated number does not start in the middle of a longer run of digits (1024，200米 reads 200米).
ARABIC = "(?:(?<![0-9０-９])[0-9０-９]{1,3}(?:[,，][0-9０-９]{3})+|[0-9０-９]+)(?:[.．][0-9０-９]+)?"
QUANTITY = re.compile("百分之[" + CN_DIGITS + "点]+|" + ARABIC + "[%％]"
                      "|(第)?(" + ARABIC + "|[" + CN_DIGITS + "]+)([多来余几])?"
                      "(" + "|".join(_UNITS) + "|(?:" + "|".join(ASCII_UNITS) + ")(?![A-Za-z]))")
# Not quantities, though they look like one: 十分 (very), 四处 (everywhere) ... and set phrases made of numerals.
NOT_QUANTITY = {"十分", "万分", "百分", "四处", "四下", "千万", "万千"}
NUMBER_IDIOMS = ("三番五次", "三三两两", "一五一十", "三心二意", "七上八下", "四面八方", "五颜六色", "千言万语", "千方百计",
                 "十全十美", "三言两语", "四分五裂", "千军万马", "千丝万缕", "五花八门", "半斤八两", "千家万户", "三五成群",
                 "十有八九", "四平八稳", "五湖四海", "接二连三", "三长两短", "一干二净", "一清二楚", "七零八落", "丢三落四",
                 "颠三倒四", "成千上万", "千千万万", "一时半会", "三下五除二")
TO_ASCII = str.maketrans("０１２３４５６７８９．％", "0123456789.%")
KINDS = {"moved_changed": "挪了位置又改了字", "split": "一句拆成了几句", "merged": "几句并成了一句",
         "unsure": "拿不准：像是改了这一句，也可能是删了一句、另加一句"}
KEEP_LABELS = {"kept": "原样在", "changed": "改了", "missing": "找不到"}
CHANGES_NOTE = ("怎么比的：段是一个非空行；句子在。！？……和换行处断开，引号里不断。两句的字（不算标点）"
                "用 difflib 比：相似度到 %.2f、前后次序没乱的，算同一句改了；同一处的两句在 %.2f 到 %.2f 之间，"
                "放进“拿不准”；像的两句不在一处，算挪了又改；同一处的一句只是有点像、别处剩下的一句像得多（相似度高出 %.2f）时，"
                "也算挪了又改，同一处那句另算删掉或新加。数字只认带单位或量词的，单独的“一”“半”只在年、天、斤这类单位前才算；"
                "千位逗号去掉再比（3,000元和3000元算同一个数），所以用逗号隔开的三位数（101，102号）会连成一个数，用顿号隔开的不会。"
                "只比字面：换了说法的会算成删一句、加一句。" % (SIMILAR, UNSURE, SIMILAR, MOVE_MARGIN))
CHANGES_LIMITS = "只列位置，不判对错：0 条不说明没改坏，条数多不说明改坏了；有没有作用、该不该改回，要人读。"


def split_line(line):
    """The sentences of one line, cut after 。！？!?… outside quotes: a quote stays whole with the words around it
    (“船还开吗？”她问。 is one sentence), and closing quotes or brackets right after the mark stay with it."""
    out, start, depth, i, n = [], 0, 0, 0, len(line)
    while i < n:
        ch, end = line[i], None
        if ch in OPEN_QUOTES:
            depth += 1
        elif ch in CLOSE_QUOTES:
            depth = max(0, depth - 1)
        elif ch in END_MARKS and depth == 0:
            end = i + 1
            while end < n and line[end] in END_MARKS:
                end += 1
        if end is None:
            i += 1
            continue
        while end < n and line[end] in CLOSERS:
            end += 1
        if line[start:end].strip():
            out.append(line[start:end].strip())
        start = i = end
    if line[start:].strip():
        out.append(line[start:].strip())
    return out


def letters(text):
    return NOT_LETTER.sub("", text) or text


def text_units(text):
    """The paragraphs (non-empty lines) and the sentences of a text, each sentence with its place."""
    paras = [line for line in text.split("\n") if line.strip()]
    units = []
    for p, line in enumerate(paras, 1):
        for k, s in enumerate(split_line(line), 1):
            key = SPACE.sub("", s)
            units.append({"para": p, "sent": k, "text": s, "key": key, "rkey": letters(key)})
    return paras, units


def dialogue_units(paras):
    units = []
    for p, line in enumerate(paras, 1):
        for m in DIALOGUE.finditer(line):
            quoted = m.group().strip()
            key = SPACE.sub("", quoted[1:].rstrip("”」"))
            if key:
                units.append({"para": p, "text": quoted, "key": key, "rkey": letters(key)})
    return units


def _matcher(seq):
    m = difflib.SequenceMatcher(None, autojunk=False)
    m.set_seq2(seq)
    return m


def _score(m, seq, low):
    m.set_seq1(seq)
    if m.real_quick_ratio() < low or m.quick_ratio() < low:
        return 0.0
    return m.ratio()


def _runs(indexes):
    """Runs of 2..MAX_GROUP consecutive numbers in a sorted list."""
    for s in range(len(indexes)):
        for e in range(s + 2, min(len(indexes), s + MAX_GROUP) + 1):
            if indexes[e - 1] - indexes[s] != e - 1 - s:
                break
            yield tuple(indexes[s:e])


def _pairs_of_letters(text):
    return {text[k:k + 2] for k in range(len(text) - 1)}


def _heaviest_chain(elements, size_b):
    """The elements (i_lo, i_hi, j_lo, j_hi, weight, ...) that keep their order on both sides with the most weight."""
    tree = [(0.0, -1)] * (size_b + 1)  # Fenwick tree of (best total, element) by j_hi

    def best_before(j):  # chains whose last element ends before place j
        out = (0.0, -1)
        while j > 0:
            out = max(out, tree[j])
            j -= j & -j
        return out

    def put(j, value):
        j += 1
        while j <= size_b:
            tree[j] = max(tree[j], value)
            j += j & -j

    starting, ending = {}, {}
    for k, e in enumerate(elements):
        starting.setdefault(e[0], []).append(k)
        ending.setdefault(e[1], []).append(k)
    total, back = [0.0] * len(elements), [-1] * len(elements)
    for i in sorted(set(starting) | set(ending)):
        for k in starting.get(i, ()):
            value, prev = best_before(elements[k][2])
            total[k], back[k] = value + elements[k][4], prev
        for k in ending.get(i, ()):
            put(elements[k][3], (total[k], k))
    if not elements:
        return []
    k = max(range(len(elements)), key=lambda x: (total[x], -x))
    chain = []
    while k >= 0:
        chain.append(elements[k])
        k = back[k]
    return chain[::-1]


def align(a, b, groups=True, unsure=True):
    """Line up two lists of units without guessing.

    1. Candidates: units with the same text, and pairs (or one unit against a run of 2..MAX_GROUP units of the other
       side) that share two letters in a row and reach SIMILAR. 2. The heaviest chain of candidates that keeps the
       order on both sides is what stayed in place: same text is unchanged, a similar pair changed, a run a split or a
       merge. 3. Between two links of the chain, the units left over on both sides sit in the same place: they are
       paired again (from UNSURE up, within BAND places), so short sentences that share no two letters still meet.
    4. Elsewhere: a same-place pairing gives way to a unit left over elsewhere that is closer to one of its two units
       by MOVE_MARGIN (same text counting 1.0) and has nothing left over as close to it. Then what is still left: same
       text elsewhere is moved, a similar unit elsewhere is moved and changed; the rest is deleted or added."""
    ka, kb = [u["key"] for u in a], [u["key"] for u in b]
    keys_a, keys_b = set(ka), set(kb)
    elements = []
    where_b = {}
    for j, key in enumerate(kb):
        where_b.setdefault(key, []).append(j)
    for i, key in enumerate(ka):
        elements.extend((i, i, j, j, 1.0, "same", 1.0) for j in where_b.get(key, ()))
    index = {}
    for j, u in enumerate(b):
        if u["key"] not in keys_a:
            for pair in _pairs_of_letters(u["rkey"]):
                index.setdefault(pair, []).append(j)
    common = max(20, len(b) // 20)  # two letters found in more sentences than this say nothing about a pairing
    sharing, single = {}, {}
    for i, u in enumerate(a):
        if u["key"] in keys_b:
            continue
        js = set()
        for pair in _pairs_of_letters(u["rkey"]):
            if len(index.get(pair, ())) <= common:
                js.update(index.get(pair, ()))
        m = _matcher(u["rkey"])
        for j in sorted(js):
            sharing.setdefault(("a", i), set()).add(j)
            sharing.setdefault(("b", j), set()).add(i)
            score = _score(m, b[j]["rkey"], UNSURE)
            single[i, j] = score
            if score >= SIMILAR:
                elements.append((i, i, j, j, score * 0.999, "pair", score))
    best_a, best_b = {}, {}
    for (i, j), score in single.items():
        best_a[i], best_b[j] = max(best_a.get(i, 0), score), max(best_b.get(j, 0), score)

    def group_runs(x, from_a, near):
        """Runs of the other side's units, each run holding a unit in near."""
        many, keys_one = (b, keys_a) if from_a else (a, keys_b)
        runs = set()
        for y in near:
            for lo in range(max(0, y - MAX_GROUP + 1), y + 1):
                for hi in range(max(lo + 1, y), min(len(many), lo + MAX_GROUP)):
                    if all(many[z]["key"] not in keys_one for z in range(lo, hi + 1)):
                        runs.add(tuple(range(lo, hi + 1)))
        return sorted(runs)

    def group_elements(x, from_a, runs, best):
        one, many = (a, b) if from_a else (b, a)
        m = _matcher(one[x]["rkey"])
        out = []
        for run in runs:
            score = _score(m, "".join(many[y]["rkey"] for y in run), SIMILAR)
            if score >= SIMILAR and score >= best.get(x, 0) + GROUP_MARGIN:
                if from_a:
                    out.append((x, x, run[0], run[-1], score, "split", score))
                else:
                    out.append((run[0], run[-1], x, x, score, "merged", score))
        return out

    if groups:
        for i in range(len(a)):
            if ("a", i) in sharing:
                elements.extend(group_elements(i, True, group_runs(i, True, sharing["a", i]), best_a))
        for j in range(len(b)):
            if ("b", j) in sharing:
                elements.extend(group_elements(j, False, group_runs(j, False, sharing["b", j]), best_b))
    chain = _heaviest_chain(elements, len(b))
    free_a, free_b = set(range(len(a))), set(range(len(b)))
    unchanged, taken = [], []
    for i_lo, i_hi, j_lo, j_hi, _, kind, score in chain:
        free_a.difference_update(range(i_lo, i_hi + 1))
        free_b.difference_update(range(j_lo, j_hi + 1))
        if kind == "same":
            unchanged.append((i_lo, j_lo))
        else:
            taken.append(("near" if kind == "pair" else kind, score, tuple(range(i_lo, i_hi + 1)),
                          tuple(range(j_lo, j_hi + 1))))
    # 3. the same place: between two links of the chain
    bounds = [(-1, -1)] + [(e[1], e[3]) for e in chain] + [(len(a), len(b))]
    for (pa, pb), (na, nb) in zip(bounds, bounds[1:]):
        gap_a = [i for i in range(pa + 1, na) if i in free_a]
        gap_b = [j for j in range(pb + 1, nb) if j in free_b]
        if not gap_a or not gap_b:
            continue
        cands = []
        low = UNSURE if unsure else SIMILAR
        local_best_a, local_best_b = {}, {}
        for x, i in enumerate(gap_a):
            mid = int((x + 0.5) * len(gap_b) / len(gap_a))
            m = _matcher(a[i]["rkey"])
            for j in gap_b[max(0, mid - BAND):mid + BAND + 1]:
                score = _score(m, b[j]["rkey"], low)
                if score >= low:
                    cands.append((score, "near", (i,), (j,)))
                    local_best_a[i] = max(local_best_a.get(i, 0), score)
                    local_best_b[j] = max(local_best_b.get(j, 0), score)
        if groups:
            for x, i in enumerate(gap_a):
                mid = int((x + 0.5) * len(gap_b) / len(gap_a))
                for run in _runs(gap_b[max(0, mid - BAND):mid + BAND + 1]):
                    cands.extend((e[6], "split", (i,), run) for e in group_elements(i, True, [run], local_best_a))
            for x, j in enumerate(gap_b):
                mid = int((x + 0.5) * len(gap_a) / len(gap_b))
                for run in _runs(gap_a[max(0, mid - BAND):mid + BAND + 1]):
                    cands.extend((e[6], "merged", run, (j,)) for e in group_elements(j, False, [run], local_best_b))
        pos_a = {i: x / len(gap_a) for x, i in enumerate(gap_a)}
        pos_b = {j: x / len(gap_b) for x, j in enumerate(gap_b)}
        cands.sort(key=lambda c: (-c[0], abs(pos_a[c[2][0]] - pos_b[c[3][0]]), c[2][0], c[3][0]))
        for score, kind, ia, jb in cands:
            if all(i in free_a for i in ia) and all(j in free_b for j in jb):
                free_a.difference_update(ia)
                free_b.difference_update(jb)
                taken.append((kind, score, ia, jb))
    # 4. elsewhere. First, a same-place pairing gives way when one of its two units has a unit left over elsewhere
    # that is closer by MOVE_MARGIN (same text counting 1.0) and has nothing left over as close to it: those two are
    # moved (and changed), and the same-place partner goes back to the leftovers (deleted or added, unless paired below).
    moved = []
    where_a = {}
    for i, key in enumerate(ka):
        where_a.setdefault(key, []).append(i)
    similar_a, similar_b = {}, {}
    for (i, j), score in single.items():
        if score >= SIMILAR:
            similar_a.setdefault(i, []).append((score, j))
            similar_b.setdefault(j, []).append((score, i))
    for rows in list(similar_a.values()) + list(similar_b.values()):
        rows.sort(key=lambda r: (-r[0], r[1]))

    def closest_left(x, from_a):
        """The closest unit still left over on the other side, as (score, index); same text counts 1.0."""
        key, where, free, rows = (ka[x], where_b, free_b, similar_a) if from_a else (kb[x], where_a, free_a, similar_b)
        same = next((y for y in where.get(key, ()) if y in free), None)
        if same is not None:
            return 1.0, same
        return next((r for r in rows.get(x, ()) if r[1] in free), (0.0, None))

    gave_way = set()
    for t in sorted((t for t in taken if t[0] == "near"), key=lambda t: (t[1], t[2], t[3])):
        (i,), (j,) = t[2], t[3]
        rival = None  # (score, original unit, revised unit)
        for from_a, x in ((True, i), (False, j)):
            score, y = closest_left(x, from_a)
            if y is None or score < max(SIMILAR, t[1] + MOVE_MARGIN) or closest_left(y, not from_a)[0] >= score:
                continue
            if rival is None or score > rival[0]:
                rival = (score, x, y) if from_a else (score, y, x)
        if rival is None:
            continue
        score, x, y = rival
        gave_way.add(t)
        free_a.add(i)
        free_b.add(j)
        free_a.discard(x)
        free_b.discard(y)
        if ka[x] == kb[y]:
            moved.append((x, y))
        else:
            taken.append(("far", score, (x,), (y,)))
    taken = [t for t in taken if t not in gave_way]
    # same text elsewhere only moved; a similar unit elsewhere is moved and changed
    waiting = {}
    for j in sorted(free_b):
        waiting.setdefault(kb[j], []).append(j)
    for i in sorted(free_a):
        if waiting.get(ka[i]):
            j = waiting[ka[i]].pop(0)
            moved.append((i, j))
            free_a.discard(i)
            free_b.discard(j)
    far = sorted(((score, i, j) for (i, j), score in single.items()
                  if score >= SIMILAR and i in free_a and j in free_b), key=lambda c: (-c[0], c[1], c[2]))
    for score, i, j in far:
        if i in free_a and j in free_b:
            free_a.discard(i)
            free_b.discard(j)
            taken.append(("far", score, (i,), (j,)))
    taken.sort(key=lambda t: (t[2][0], t[3][0]))
    moved.sort()
    return {"unchanged": unchanged, "moved": moved, "taken": taken, "deleted": sorted(free_a), "added": sorted(free_b)}


def place(u):
    return {"para": u["para"], "sent": u["sent"], "text": u["text"]}


def letter_edits(x, y):
    out = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, x, y, autojunk=False).get_opcodes():
        if tag != "equal":
            out.append({"from": x[i1:i2], "to": y[j1:j2]})
    return out


def han_pieces(text, longest=12):
    pieces = set()
    for run in HAN_RUN.findall(text):
        for i in range(len(run) - 1):
            pieces.update(run[i:j] for j in range(i + 2, min(len(run), i + longest) + 1))
    return pieces


def trim(part):
    while part and (part[0] in PARTICLES or part[0] in PRONOUNS):
        part = part[1:]
    while part and part[-1] in PARTICLES:
        part = part[:-1]
    return part


def still_there(sentence, pieces, rev_units, fresh, limit=4):
    """Words of a deleted sentence that the revision still has: the longest stretches, two content characters or more."""
    words = []
    for run in HAN_RUN.findall(sentence):
        i = 0
        while i < len(run) - 1:
            end = next((e for e in range(min(len(run), i + 12), i + 1, -1) if run[i:e] in pieces), None)
            if end is None:
                i += 1
                continue
            word = trim(run[i:end])
            if sum(ch not in FUNCTION for ch in word) >= 2 and word not in words:
                words.append(word)
            i = end
    found = []
    for word in words:
        where = [k for k, u in enumerate(rev_units) if word in u["key"]]
        if where:
            found.append({"word": word, "paras": sorted({rev_units[k]["para"] for k in where})[:3],
                          "in_new_text": any(k in fresh for k in where)})
    found.sort(key=lambda w: not w["in_new_text"])  # words found in new or changed sentences first
    return found[:limit]


def quantities(units):
    """(text, unit index) of each number with a unit or classifier."""
    found = []
    for k, u in enumerate(units):
        text = u["key"]
        for idiom in NUMBER_IDIOMS:
            text = text.replace(idiom, "　" * len(idiom))
        for m in QUANTITY.finditer(text):
            whole = m.group().translate(TO_ASCII).replace(",", "").replace("，", "")  # 3,000元 = 3000元
            ordinal, number, approx, unit = m.group(1), m.group(2), m.group(3), m.group(4)
            if whole in NOT_QUANTITY:
                continue
            if number and not ordinal and not approx and set(number) <= LONE and unit not in MEASURE_UNITS:
                continue
            found.append((whole, k))
    return found


def number_changes(orig_units, rev_units, orig_same, rev_same):
    before, after = quantities(orig_units), quantities(rev_units)
    count_a, count_b = {}, {}
    for q, _ in before:
        count_a[q] = count_a.get(q, 0) + 1
    for q, _ in after:
        count_b[q] = count_b.get(q, 0) + 1

    def rows(found, mine, other, units, same):
        out, seen = [], set()
        for q, k in found:
            if q in seen or mine[q] <= other.get(q, 0):
                continue
            seen.add(q)
            spots = [j for x, j in found if x == q]
            spots = [j for j in spots if j not in same] or spots  # point at the sentences that changed, if any
            out.append({"text": q, "original_count": count_a.get(q, 0), "revised_count": count_b.get(q, 0),
                        "where": [place(units[j]) for j in spots[:3]]})
        return out

    return {"gone": rows(before, count_a, count_b, orig_units, orig_same),
            "new": rows(after, count_b, count_a, rev_units, rev_same)}


def keep_check(lines, orig_paras, rev_paras, rev_units):
    orig_keys = [SPACE.sub("", p) for p in orig_paras]
    rev_keys = [SPACE.sub("", p) for p in rev_paras]
    out = []
    for n, line in lines:
        key = SPACE.sub("", line)
        row = {"line": n, "text": line, "in_original": any(key in p for p in orig_keys), "where": None,
               "closest": None, "ratio": None}
        hit = next((p for p, text in enumerate(rev_keys, 1) if key in text), None)
        if hit:
            row.update(status="kept", where={"para": hit})
        else:
            m, best = _matcher(letters(key)), (0.0, None)
            for s in range(len(rev_units)):
                for e in range(s + 1, min(len(rev_units), s + 3) + 1):
                    score = _score(m, "".join(u["rkey"] for u in rev_units[s:e]), SIMILAR)
                    if score > best[0]:
                        best = (score, (s, e))
            if best[0] >= SIMILAR:
                s, e = best[1]
                row.update(status="changed", ratio=round(best[0], 2),
                           closest={"para": rev_units[s]["para"], "sent": rev_units[s]["sent"],
                                    "text": "".join(u["text"] for u in rev_units[s:e])})
            else:
                row["status"] = "missing"
        row["label"] = KEEP_LABELS[row["status"]]
        out.append(row)
    return out


def read_keep(path):
    lines = [(n, line.strip()) for n, line in enumerate(read_text(path).split("\n"), 1) if line.strip()]
    if not lines:
        raise CheckError("%s has no lines to keep" % path)
    return lines


def changes(original, revised, keep_lines=None, keep_file=None):
    orig_paras, a = text_units(original)
    rev_paras, b = text_units(revised)
    al = align(a, b)
    changed, unaligned = [], []
    fresh = set(al["added"])  # revised sentences that are new or changed: moved words show up there
    for kind, s, ia, jb in al["taken"]:
        fresh.update(jb)
        if kind == "near" and s >= SIMILAR:
            i, j = ia[0], jb[0]
            changed.append({"original": place(a[i]), "revised": place(b[j]), "ratio": round(s, 2),
                            "edits": letter_edits(a[i]["key"], b[j]["key"])})
        else:
            kind = {"near": "unsure", "far": "moved_changed"}.get(kind, kind)
            unaligned.append({"kind": kind, "label": KINDS[kind], "ratio": round(s, 2),
                              "original": [place(a[i]) for i in ia], "revised": [place(b[j]) for j in jb]})
    pieces = han_pieces(revised) if al["deleted"] else set()
    deleted = [dict(place(a[i]), still_in_revised=still_there(a[i]["text"], pieces, b, fresh)) for i in al["deleted"]]
    da, db = dialogue_units(orig_paras), dialogue_units(rev_paras)
    dl = align(da, db, groups=False, unsure=False)
    dialogue = {"changed": [{"original": {"para": da[i]["para"], "text": da[i]["text"]},
                             "revised": {"para": db[j]["para"], "text": db[j]["text"]}, "ratio": round(s, 2)}
                            for _, s, (i,), (j,) in dl["taken"]],
                "gone": [{"para": da[i]["para"], "text": da[i]["text"]} for i in dl["deleted"]],
                "new": [{"para": db[j]["para"], "text": db[j]["text"]} for j in dl["added"]]}
    orig_same = {i for i, _ in al["unchanged"] + al["moved"]}
    rev_same = {j for _, j in al["unchanged"] + al["moved"]}
    numbers = number_changes(a, b, orig_same, rev_same)
    keep = None
    if keep_lines is not None:
        keep = {"file": keep_file, "lines": keep_check(keep_lines, orig_paras, rev_paras, b)}
    moved = [{"original": place(a[i]), "revised": place(b[j])} for i, j in al["moved"]]
    added = [place(b[j]) for j in al["added"]]
    listed = bool(deleted or added or changed or moved or unaligned or any(dialogue.values()) or any(numbers.values())
                  or (keep and any(r["status"] != "kept" for r in keep["lines"])))
    return {"format": CHANGES_FORMAT, "format_version": 1, "status": "LISTED" if listed else "NOTHING_LISTED",
            "thresholds": {"similar": SIMILAR, "unsure": UNSURE, "group_margin": GROUP_MARGIN,
                           "move_margin": MOVE_MARGIN},
            "counts": {"original": {"paragraphs": len(orig_paras), "sentences": len(a)},
                       "revised": {"paragraphs": len(rev_paras), "sentences": len(b)},
                       "unchanged": len(al["unchanged"])},
            "deleted": deleted, "added": added, "changed": changed, "dialogue": dialogue, "keep": keep,
            "numbers": numbers, "moved": moved, "unaligned": unaligned, "note": CHANGES_NOTE, "limits": CHANGES_LIMITS}


def changes_text(report, original_label="原稿", revised_label="修订稿"):
    def piece(text):  # the letters of an edit; they can be quote marks themselves
        return "“%s”" % text if "「" in text or "」" in text else "「%s」" % text

    def at(label, p):
        return "%s第 %d 段第 %d 句" % (label, p["para"], p["sent"])

    def paras(nums):
        return "、".join(str(n) for n in nums)

    c = report["counts"]
    lines = ["改动逐句对照（%s → %s）" % (original_label, revised_label),
             "每一条只是要回头读的地方，不是结论。",
             "- %s %d 段 %d 句，%s %d 段 %d 句；一字没动的 %d 句。" % (
                 original_label, c["original"]["paragraphs"], c["original"]["sentences"], revised_label,
                 c["revised"]["paragraphs"], c["revised"]["sentences"], c["unchanged"])]
    lines.append("- 删掉的句子（%s里找不到像的）：%d 句" % (revised_label, len(report["deleted"])))
    for row in report["deleted"]:
        lines.append("  %s：%s" % (at(original_label, row), row["text"]))
        words = row["still_in_revised"]
        if words:
            lines.append("    提示：%s别处还有这句里的%s%s" % (
                revised_label, "、".join("“%s”（第 %s 段%s）" % (w["word"], paras(w["paras"]),
                                                             "" if w["in_new_text"] else "，在没改的句子里") for w in words),
                "；可能挪进了别的句子，要对着读。" if any(w["in_new_text"] for w in words) else "。"))
    lines.append("- 新加的句子：%d 句" % len(report["added"]))
    for row in report["added"]:
        lines.append("  %s：%s" % (at(revised_label, row), row["text"]))
    lines.append("- 改了的句子：%d 句" % len(report["changed"]))
    for row in report["changed"]:
        lines.append("  %s：%s" % (at(original_label, row["original"]), row["original"]["text"]))
        lines.append("  %s：%s" % (at(revised_label, row["revised"]), row["revised"]["text"]))
        shown = []
        for e in row["edits"][:6]:
            shown.append("%s→%s" % (piece(e["from"]), piece(e["to"])) if e["from"] and e["to"]
                         else ("删" + piece(e["from"]) if e["from"] else "添" + piece(e["to"])))
        more = "，另有 %d 处" % (len(row["edits"]) - 6) if len(row["edits"]) > 6 else ""
        lines.append("    差在：%s%s" % ("；".join(shown), more))
    d = report["dialogue"]
    lines.append("- 台词（“”或「」里的话）：改了 %d 处，没了 %d 处，新加 %d 处" % (len(d["changed"]), len(d["gone"]), len(d["new"])))
    for row in d["changed"]:
        lines.append("  改：%s第 %d 段 %s → %s第 %d 段 %s" % (original_label, row["original"]["para"], row["original"]["text"],
                                                       revised_label, row["revised"]["para"], row["revised"]["text"]))
    for row in d["gone"]:
        lines.append("  没了：%s第 %d 段 %s" % (original_label, row["para"], row["text"]))
    for row in d["new"]:
        lines.append("  新加：%s第 %d 段 %s" % (revised_label, row["para"], row["text"]))
    if report["keep"] is not None:
        rows = report["keep"]["lines"]
        lines.append("- 要留的句子（%s，%d 行）：%s" % (
            report["keep"]["file"], len(rows),
            "，".join("%s %d 行" % (KEEP_LABELS[k], sum(r["status"] == k for r in rows)) for k in KEEP_LABELS)))
        for row in rows:
            where = "（%s第 %d 段）" % (revised_label, row["where"]["para"]) if row["status"] == "kept" else ""
            lines.append("  第 %d 行 %s：%s%s" % (row["line"], row["label"], row["text"], where))
            if row["closest"]:
                lines.append("    最像的一句：%s：%s" % (at(revised_label, row["closest"]), row["closest"]["text"]))
            if not row["in_original"]:
                lines.append("    %s里也没有这一行，先核对一下要留的句子是不是抄对了。" % original_label)
    n = report["numbers"]
    lines.append("- 数字和数量（带单位或量词的）：没了 %d 个，新出现 %d 个" % (len(n["gone"]), len(n["new"])))
    for label, rows, side in (("没了", n["gone"], original_label), ("新出现", n["new"], revised_label)):
        for row in rows:
            first = row["where"][0]
            lines.append("  %s“%s”（%s %d 处，%s %d 处）：%s：%s" % (
                label, row["text"], original_label, row["original_count"], revised_label, row["revised_count"],
                at(side, first), first["text"]))
    lines.append("- 挪了位置、字没改：%d 句" % len(report["moved"]))
    for row in report["moved"]:
        lines.append("  %s → %s：%s" % (at(original_label, row["original"]), at(revised_label, row["revised"]),
                                        row["original"]["text"]))
    lines.append("- 对不上（没法一句对一句，不替你猜）：%d 处" % len(report["unaligned"]))
    for row in report["unaligned"]:
        lines.append("  %s：" % row["label"])
        for p in row["original"]:
            lines.append("    %s：%s" % (at(original_label, p), p["text"]))
        for p in row["revised"]:
            lines.append("    %s：%s" % (at(revised_label, p), p["text"]))
    lines.append(report["note"])
    lines.append(report["limits"])
    return "\n".join(lines) + "\n"


def utf8_stdio():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = parser.add_subparsers(dest="command", required=True)
    c = sub.add_parser("compare", help="list what the revision lost and what report-like forms it brought in")
    c.add_argument("original", type=Path)
    c.add_argument("revised", type=Path)
    c.add_argument("--format", choices=("text", "json"), default="text")
    ch = sub.add_parser("changes", help="sentence by sentence: deleted, added, changed, dialogue, keep lines, numbers")
    ch.add_argument("original", type=Path)
    ch.add_argument("revised", type=Path)
    ch.add_argument("--keep", type=Path, help="sentences that must stay, one per line")
    ch.add_argument("--format", choices=("text", "json"), default="text")
    a = sub.add_parser("anchors", help="writing anchors: self-test, write the requests, or check the revisions")
    a.add_argument("files", type=Path, nargs="+")
    mode = a.add_mutually_exclusive_group(required=True)
    mode.add_argument("--self-test", action="store_true")
    mode.add_argument("--prompts", type=Path)
    mode.add_argument("--outputs", type=Path)
    a.add_argument("--format", choices=("text", "json"), default="text")
    args = parser.parse_args()
    try:
        if args.command == "compare":
            report = compare(read_text(args.original), read_text(args.revised))
            print(json.dumps(report, ensure_ascii=False, indent=1) if args.format == "json" else compare_text(report), end="\n" if args.format == "json" else "")
            return 0
        if args.command == "changes":
            original, revised = read_text(args.original), read_text(args.revised)
            keep = read_keep(args.keep) if args.keep else None
            report = changes(original, revised, keep, str(args.keep) if args.keep else None)
            print(json.dumps(report, ensure_ascii=False, indent=1) if args.format == "json" else changes_text(report),
                  end="\n" if args.format == "json" else "")
            return 0
        anchors = load_anchors(args.files)
        if args.prompts:
            args.prompts.mkdir(parents=True, exist_ok=True)
            for anchor in anchors:
                (args.prompts / (anchor["id"] + ".prompt.txt")).write_bytes(prompt_text(anchor).encode("utf-8"))
            print("wrote %d requests to %s" % (len(anchors), args.prompts))
            return 0
        results = []
        if args.self_test:
            for anchor in anchors:
                approved = check_candidate(anchor, anchor["approved_after"])
                approved["id"] = anchor["id"] + " 认可的改法"
                results.append(approved)
                if anchor["before"] != anchor["approved_after"]:
                    before = check_candidate(anchor, anchor["before"])
                    before["id"] = anchor["id"] + " 待改的原文"
                    before["status"] = "PASS" if before["status"] == "FAIL" else "FAIL"
                    before["reasons"] = (["应当不通过，实际也不通过：" + "；".join(before["reasons"])] if before["status"] == "PASS"
                                         else ["待改的原文本该不通过，却通过了：keep、avoid 没有写出它的毛病"])
                    results.append(before)
            title = "写作对照例自检（认可的改法要通过，待改的原文要不通过）"
        else:
            for anchor in anchors:
                path = args.outputs / (anchor["id"] + ".txt")
                if not path.is_file():
                    results.append({"id": anchor["id"], "status": "MISSING", "reasons": ["没有输出"], "path": str(path)})
                    continue
                results.append(check_candidate(anchor, read_text(path)))
            title = "写作对照例（%s）" % args.outputs
        if args.format == "json":
            print(json.dumps({"format": FORMAT + "-anchors", "format_version": 1, "results": results}, ensure_ascii=False, indent=1))
        else:
            print(anchors_text(results, title), end="")
        return 0 if all(r["status"] == "PASS" for r in results) else 1
    except CheckError as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    sys.exit(main())

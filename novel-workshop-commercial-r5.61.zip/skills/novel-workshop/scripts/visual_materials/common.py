"""Shared pieces: the config, the run folder, budgets, HTTP with limits, and what may leave the machine.

r5.59 (the visual chain; the author's decisions of 2026-11-19): the network manners of collect live here, in Session,
so that every page reader keeps the same rules:

- redirects are followed one hop at a time: each hop is checked again against network.blocked_hosts and, by the
  address it resolves to, against this machine, private networks, link-local and reserved ranges; at most five hops;
  the chain and the last address are recorded. A page is checked the same way before it is read, a page handed to
  Crawl4AI too. The services the author configured (searxng.url, openverse.endpoint) are not checked by address
  (SearXNG often runs on this machine). Only tests may allow an exact local host:port (Session(allow_local=...)); the
  config has no such key, and a run made that way never counts as live;
- robots.txt is asked once per host and run, through the workshop's own request, before a page is read and before an
  original or a thumbnail is fetched, and it cannot be turned off: the BOM is dropped; the group naming the workshop
  goes before the group for every crawler; an address is taken only when both the workshop's own longest-match
  reading (with * and $) and urllib.robotparser allow it, and a disagreement is recorded and read the stricter way;
  404 and 410 (and other 4xx) mean no limits; 401 and 403 mean nothing on that site is allowed; a 5xx, a timeout or a
  dropped connection means nothing is allowed this time (robots_unreachable); Crawl-delay and Request-rate join the
  pacing;
- one host is asked at most once every network.min_interval_seconds (default 1 second), or the robots.txt delay when
  that is longer; a host that asks for a wait longer than network.max_wait_seconds (default 30 seconds) is skipped
  (host_paused); a 5xx is tried again only after waiting (Retry-After in seconds or as an HTTP date); 401, 403, 451 or
  a check page is refused and 429 rate_limited: nothing more is asked of that host in this run, nothing is tried again
  with other headers, another network or another tool; budgets.max_requests caps the requests of one collect;
- the workshop says who it is (network.user_agent starts with novel-workshop-visual-materials/, may add only a contact
  in brackets, an e-mail or a web address in ASCII, and does not look like a browser or another crawler), and every
  section of the config refuses keys it does not know, keys for proxies, fingerprints and check pages with words of
  their own; the numbers of seconds are finite numbers (NaN and Infinity, which JSON readers accept, are refused);
- page_reader.use says who reads the source pages: auto (the default: Crawl4AI when it can run here, else the
  workshop's builtin reader, static_reader.py), crawl4ai (only Crawl4AI, never the builtin reader) or builtin (only the
  builtin reader); network.max_page_bytes caps a page the builtin reader asks for.

r5.59, after the review of the visual chain: every check reads an address's host the way the request will really go
(canonical_host: percent escapes decoded as urllib.request decodes them, IDNA as the socket layer applies it, so
%31%32%37.0.0.1, %6c%6fcalhost or a full-width spelling of a blocked host are judged as what they are, and are one
host for pacing, robots.txt and refusals); a host that cannot be read in one spelling is not asked. A refusal, a 429
or a Retry-After stops the host that answered it, after the redirects, not the host first asked. robots.txt is read
four ways (the workshop's own longest match, both readings urllib.robotparser has had, before Python 3.13 and from
3.13, written out here, and this Python's urllib.robotparser), and an address is taken only when all four allow it:
the strictest reading, the same on every Python.

r5.61 (the visual chain upgrade): check_request says what is wrong with the schema (none written, with a pointer to
the sample assets/visual-request.example.json, or which one was written). A request may leave out queries, or leave
both lists empty, when pages names at least one source page: search then sends nothing and collect reads those pages;
a request with neither says pages too, and queries in the wrong shape gets the same answer as before. stop_search is
used by the two searches when a service answers 429: the words not sent yet are listed as not_sent and the search
keeps how long the service asked to wait. A refusal (401, 403) is recorded as before and the next word is still sent.

r5.59 看过 Scrapling 0.5.1（BSD-3-Clause，版权 Karim shoair）的源码：没有接入，也不建议为工坊装它；robots.txt 取不到时按全不许、
去掉 robots.txt 开头的 BOM、按 Retry-After 等待、跳转逐跳检查这几样参考了它的做法，代码是工坊自己写的，没有复制它的代码。
"""
import datetime
import email.utils
import functools
import hashlib
from http.client import HTTPException
import ipaddress
import json
import math
import os
from pathlib import Path
import re
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
import urllib.robotparser

CONFIG_SCHEMA = "visual-materials-config/1"
REQUEST_SCHEMA = "visual-request/1"
RUN_SCHEMA = "visual-run/1"
KINDS = ("place", "person", "prop", "light", "other")
DEFAULT_BUDGETS = {"max_candidates": 40, "max_pages": 10, "max_images": 20, "max_reviews": 8, "recommend_min": 4,
                   "recommend_max": 6, "max_requests": 200}
DEFAULTS = {
    "searxng": {"url": "", "categories": "images", "language": "", "safesearch": 1, "engines": "", "time_range": "",
                "pages": 1},
    "openverse": {"endpoint": "https://api.openverse.org/v1/images/", "client_id_env": "OPENVERSE_CLIENT_ID",
                  "client_secret_env": "OPENVERSE_CLIENT_SECRET", "license_type": "", "page_size": 20},
    "network": {"timeout_seconds": 20, "retries": 1, "max_image_bytes": 15000000, "max_json_bytes": 5000000,
                "user_agent": "novel-workshop-visual-materials/1", "blocked_hosts": [], "min_interval_seconds": 1,
                "max_wait_seconds": 30, "max_page_bytes": 3000000},
    "page_reader": {"use": "auto"},
    "crawl4ai": {"headless": True, "page_timeout_ms": 30000, "wait_for_images": True, "scan_full_page": True,
                 "check_robots_txt": True, "images_per_page": 3},
    "imagehash": {"algorithms": ["phash", "dhash"], "hash_size": 8, "max_distance": 8},
    "openclip": {"model": "ViT-B-32", "pretrained": "laion2b_s34b_b79k", "weights_path": "", "weights_sha256": "",
                 "allow_download": False, "cache_dir": "", "device": "cpu", "text_weight": 0.5, "reference_weight": 0.5},
    "review": {"mode": "host"},
    "budgets": DEFAULT_BUDGETS,
}
HASH_ALGORITHMS = ("phash", "dhash", "ahash", "whash")
# What a new result of a step makes stale: the files the later steps made from the old one (the r5.35 review, point 1:
# after a new fetch, new groups, a new order or a rebuilt bundle, the old observations and choices must not carry over
# to other images). They are moved into outdated/<time>-<step>/, never deleted, and run.json marks those steps outdated.
DOWNSTREAM = {
    "collect": ("dedupe.json", "rank.json", "review", "selection.json", "verify.json"),
    "dedupe": ("rank.json", "review", "selection.json", "verify.json"),
    "rank": ("review", "selection.json", "verify.json"),
    "review_bundle": ("review/bundle.json", "review/review.md", "review/observations.json",
                      "review/observations.recorded.json", "selection.json", "verify.json"),
    "review_record": ("selection.json", "verify.json"),
    "select": ("verify.json",),
}
STEPS_MADE_BY = {"dedupe.json": ("dedupe",), "rank.json": ("rank",), "review": ("review_bundle", "review_record"),
                 "review/bundle.json": ("review_bundle",), "review/observations.recorded.json": ("review_record",),
                 "selection.json": ("select",)}
# What a search may carry: a few words about what to look at, never chapters of the book.
MAX_QUERY_CHARS = 80
MAX_TEXT_QUERY_CHARS = 200
MAX_QUERIES = 8

# r5.59: who the workshop says it is, and the config keys it refuses with words of their own (the names come from
# the r5.59 study of Scrapling and from Crawl4AI's documentation as remembered; the Crawl4AI ones were not checked
# against an installed copy). Any other unknown key is refused too, only with the general words.
AGENT_TOKEN = "novel-workshop-visual-materials"
# After the version only a contact may follow, in brackets: e-mail addresses (mailto: optional) or web addresses (a "+"
# before one optional), separated by "; ", ", " or a space, in printable ASCII (a request header carries nothing else).
_CONTACT = r"(?:(?:mailto:)?[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}|\+?https?://[!-'*-~]+)"
USER_AGENT_SHAPE = re.compile(r"^novel-workshop-visual-materials/[0-9A-Za-z._-]+(?: \(%s(?:[;,]? %s)*\))?$"
                              % (_CONTACT, _CONTACT))
BROWSER_LIKE = re.compile(r"mozilla/|chrome/|safari/|gecko|applewebkit", re.I)
# Names other crawlers go by (some sites let them in by name): a contact never carries one.
CRAWLER_LIKE = re.compile(r"compatible|googlebot|google\.com/bot|adsbot|bingbot|msnbot|baiduspider|yandexbot|slurp|"
                          r"duckduckbot|applebot|bytespider|petalbot|gptbot|ccbot|claudebot|facebookexternalhit|"
                          r"semrushbot|ahrefsbot|mj12bot|\bcrawler\b|\bspider\b", re.I)
MAX_USER_AGENT = 300
EVASION_KEYS = frozenset({
    "impersonate", "stealth", "stealthy_headers", "solve_cloudflare", "captcha", "real_chrome", "hide_canvas",
    "block_webrtc", "google_search", "useragent", "proxy", "proxies", "proxy_rotator", "cdp_url", "user_data_dir",
    "cookies", "load_state", "save_state", "magic", "simulate_user", "override_navigator", "enable_stealth",
    "user_agent_mode"})
EVASION_WORDS = re.compile(r"prox|captcha|stealth|impersonat|fingerprint|cloudflare|turnstile|cookie|refer+er|spoof|"
                           r"undetect|bypass|anti_?bot", re.I)
NO_EVASION = "工坊不做这件事：不绕过网站防护，配置里没有这个开关（见 references/visual-materials.md“不绕过网站防护，图归原作者”）。"
ROBOTS_LOCKED = "工坊守 robots.txt，这一项不能关"
SECTION_NOTE = "note"  # a section may carry a note for the reader of the file, as the top level does
MAX_REDIRECTS = 5
ROBOTS_MAX_BYTES = 500000
BLOCKED = "the host is blocked in the config (network.blocked_hosts)"
REFUSING = (401, 403, 451)
PAGE_READERS = ("auto", "crawl4ai", "builtin")


class VisualError(ValueError):
    """A request, config or run that cannot be used; the message says what to fix."""


def now():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def today():
    return datetime.date.today().isoformat()


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    try:
        return json.loads(Path(path).read_bytes().decode("utf-8-sig"))
    except (OSError, UnicodeError, ValueError) as exc:
        raise VisualError("cannot read %s: %s" % (path, exc)) from exc


def write_json(path, data):
    path = Path(path)
    tmp = path.with_name("%s.tmp-%d" % (path.name, os.getpid()))
    tmp.write_bytes((json.dumps(data, ensure_ascii=False, indent=1) + "\n").encode("utf-8"))
    os.replace(str(tmp), str(path))


def merged(defaults, given):
    out = {}
    for key, value in defaults.items():
        if isinstance(value, dict):
            out[key] = merged(value, (given or {}).get(key) or {})
        else:
            out[key] = (given or {}).get(key, value)
    return out


def evasive(key):
    """A config key that asks for a way around a site's protection (a proxy, a browser fingerprint, a solved check
    page, someone else's cookies): there is no such switch, and the refusal says so."""
    return key.lower() in EVASION_KEYS or bool(EVASION_WORDS.search(key))


def _seconds(value):
    """A number of seconds as given, or None: not a number, or not finite (json reads NaN and Infinity; a NaN interval
    makes every comparison false and would switch the pacing off)."""
    return value if type(value) in (int, float) and math.isfinite(value) else None


def check_keys(data):
    """r5.59: every section refuses keys it does not know (directly, no warning first); the old behaviour, reading a
    config and silently dropping what it did not know, let a key look as if it worked."""
    for key in sorted(set(data) - set(DEFAULTS) - {"schema", "note"}):
        if evasive(key):
            raise VisualError("%s: %s" % (key, NO_EVASION))
    unknown = set(data) - set(DEFAULTS) - {"schema", "note"}
    if unknown:
        raise VisualError("unknown config section(s) %s" % ", ".join(sorted(unknown)))
    for section, given in data.items():
        if section in ("schema", "note"):
            continue
        if not isinstance(given, dict):
            raise VisualError("config section %s is an object" % section)
        extra = sorted(set(given) - set(DEFAULTS[section]) - {SECTION_NOTE})
        for key in extra:
            if evasive(key):
                raise VisualError("%s.%s: %s" % (section, key, NO_EVASION))
        if extra:
            raise VisualError("unknown key(s) in config section %s: %s (each section takes only the keys of the "
                              "example config, assets/visual-materials-config.example.json)" % (section, ", ".join(extra)))


def check_network(network):
    agent = network.get("user_agent")
    if (not isinstance(agent, str) or len(agent) > MAX_USER_AGENT or BROWSER_LIKE.search(agent)
            or CRAWLER_LIKE.search(agent) or not USER_AGENT_SHAPE.match(agent)):
        raise VisualError("network.user_agent says it is the workshop: novel-workshop-visual-materials/<version>, "
                          "optionally followed by your contact in brackets, an e-mail address or a web address "
                          "(括号里只能写联系方式，比如邮箱地址或网址，只用英文字母、数字和常见符号); it is never made to "
                          "look like a browser (Mozilla/, Chrome/, Safari/, Gecko, AppleWebKit) or like another "
                          "crawler (compatible, Googlebot, bingbot, Baiduspider, YandexBot, Slurp ...)")
    hosts = network.get("blocked_hosts")
    if not isinstance(hosts, list) or not all(isinstance(h, str) and h.strip() for h in hosts):
        raise VisualError("network.blocked_hosts is a list of host names")
    if type(network.get("retries")) is not int or network["retries"] < 0:
        raise VisualError("network.retries is a whole number (0 or more)")
    timeout = _seconds(network.get("timeout_seconds"))
    if timeout is None or timeout <= 0:
        raise VisualError("network.timeout_seconds is a number of seconds above 0")
    interval = _seconds(network.get("min_interval_seconds"))
    if interval is None or interval < 1:
        raise VisualError("network.min_interval_seconds is a number of seconds, at least 1: one host is asked at most "
                          "once in that time (robots.txt may ask for longer)")
    wait = _seconds(network.get("max_wait_seconds"))
    if wait is None or wait < interval:
        raise VisualError("network.max_wait_seconds is a number of seconds, at least network.min_interval_seconds: a "
                          "host that asks for a longer wait is skipped for this run, never asked sooner")
    if type(network.get("max_page_bytes")) is not int or network["max_page_bytes"] < 1:
        raise VisualError("network.max_page_bytes is a whole number of bytes (1 or more): the largest page the builtin "
                          "reader reads")


def load_config(path=None):
    """The config file merged over the defaults. Keys and passwords never go into it: only the names of the
    environment variables that hold them."""
    data = {}
    if path:
        data = read_json(path)
        if not isinstance(data, dict) or data.get("schema") != CONFIG_SCHEMA:
            raise VisualError("the config is an object with schema %s" % CONFIG_SCHEMA)
        check_keys(data)
        text = json.dumps(data, ensure_ascii=False)
        if re.search(r'"(?:client_secret|api_key|token|password)"\s*:\s*"[^"]+"', text):
            raise VisualError("the config holds a secret; put it in an environment variable and name the variable "
                              "(client_secret_env) instead")
    config = merged(DEFAULTS, data)
    budgets = config["budgets"]
    for key, value in budgets.items():
        if type(value) is not int or value < 1:
            raise VisualError("budgets.%s must be a positive whole number" % key)
    if budgets["recommend_min"] > budgets["recommend_max"]:
        raise VisualError("budgets.recommend_min is more than recommend_max")
    hashing = config["imagehash"]
    algorithms = hashing.get("algorithms")
    if not (isinstance(algorithms, list) and algorithms and all(a in HASH_ALGORITHMS for a in algorithms)):
        raise VisualError("imagehash.algorithms is a nonempty list of %s (an unknown name would leave nothing to compare)"
                          % ", ".join(HASH_ALGORITHMS))
    if type(hashing.get("hash_size")) is not int or hashing["hash_size"] < 4:
        raise VisualError("imagehash.hash_size is a whole number of at least 4")
    if type(hashing.get("max_distance")) is not int or hashing["max_distance"] < 0:
        raise VisualError("imagehash.max_distance is a whole number of bits (0 or more)")
    check_network(config["network"])
    if config["page_reader"].get("use") not in PAGE_READERS:
        raise VisualError("page_reader.use is one of %s: auto reads the pages with Crawl4AI when it can run here and "
                          "with the builtin reader when it cannot; crawl4ai only with Crawl4AI; builtin only with the "
                          "builtin reader" % ", ".join(PAGE_READERS))
    # Only doctor --probe turns this off, for the one page it makes itself (doctor.py); a config never can.
    if config["crawl4ai"].get("check_robots_txt") is not True:
        raise VisualError("crawl4ai.check_robots_txt: %s" % ROBOTS_LOCKED)
    return config


def sanitized_config(config):
    """The config as recorded in a run: no environment values, only their names."""
    return json.loads(json.dumps(config))


def check_request(request):
    """A chapter's request: what to look for, a few short queries per search, an optional text for similarity and
    optional reference images. Long text is refused so that chapters do not go to search services by accident."""
    if not isinstance(request, dict) or request.get("schema") != REQUEST_SCHEMA:
        said = request.get("schema") if isinstance(request, dict) else None
        raise VisualError("the request is an object with schema %s%s" % (REQUEST_SCHEMA, (
            ": this one says schema %r" % (said,) if said is not None else
            ": this one has no schema; add \"schema\": \"%s\" (a sample: assets/visual-request.example.json)"
            % REQUEST_SCHEMA) if isinstance(request, dict) else ""))
    allowed = {"schema", "chapter", "scene", "kind", "subjects", "purpose", "queries", "text_query", "reference_images",
               "pages", "note"}
    unknown = set(request) - allowed
    if unknown:
        raise VisualError("unknown request field(s) %s" % ", ".join(sorted(unknown)))
    chapter = request.get("chapter")
    if chapter is not None and (type(chapter) is not int or chapter < 1):
        raise VisualError("chapter is a positive whole number")
    if request.get("kind", "place") not in KINDS:
        raise VisualError("kind is one of %s" % ", ".join(KINDS))
    queries = request.get("queries")
    pages_only = bool(request.get("pages")) and (queries is None or (isinstance(queries, dict) and not any(queries.values())))
    if queries is None and pages_only:
        queries = {}
    words = "queries is {searxng: [...], openverse: [...]}: a few short search words for each search"
    hint = " (a request without search words names the source pages to read in pages)"
    if queries is None:
        raise VisualError(words + hint)
    if not isinstance(queries, dict) or not set(queries) <= {"searxng", "openverse"}:
        raise VisualError(words)
    if not (any(queries.values()) or pages_only):
        raise VisualError(words + hint)
    for provider, words in queries.items():
        if not isinstance(words, list) or not all(isinstance(w, str) and w.strip() for w in words):
            raise VisualError("queries.%s is a list of search words" % provider)
        if len(words) > MAX_QUERIES:
            raise VisualError("queries.%s has more than %d queries" % (provider, MAX_QUERIES))
        for word in words:
            if len(word) > MAX_QUERY_CHARS or "\n" in word:
                raise VisualError("a query is longer than %d characters or has a line break: send a few words about "
                                  "what to look at, not text from the book" % MAX_QUERY_CHARS)
    text = request.get("text_query")
    if text is not None and (not isinstance(text, str) or len(text) > MAX_TEXT_QUERY_CHARS or "\n" in text):
        raise VisualError("text_query is one line of at most %d characters" % MAX_TEXT_QUERY_CHARS)
    for key in ("subjects", "reference_images", "pages"):
        value = request.get(key, [])
        if not isinstance(value, list) or not all(isinstance(v, str) and v.strip() for v in value):
            raise VisualError("%s is a list of strings" % key)
    for page in request.get("pages", []):
        if not re.match(r"^https?://\S+$", page):
            raise VisualError("pages are http(s) addresses of source pages to read")
    return request


class Response:
    """One answer. url is the address asked; final_url the address the answer came from after the redirects
    (r5.59), and redirects the hops followed ({from, to, status} each)."""

    def __init__(self, status, headers, body, url, elapsed_ms, final_url=None, redirects=None):
        self.status, self.headers, self.body, self.url, self.elapsed_ms = status, headers, body, url, elapsed_ms
        self.final_url = final_url or url
        self.redirects = list(redirects or [])

    def json(self):
        try:
            return json.loads(self.body.decode("utf-8"))
        except (UnicodeError, ValueError) as exc:
            raise VisualError("not JSON: %s" % exc) from exc


class Timeout(Exception):
    pass


class TooLarge(Exception):
    pass


class NetworkError(Exception):
    pass


class Refused(NetworkError):
    """A request or a redirect hop the workshop does not make (r5.59). status says why: blocked, private_address,
    too_many_redirects, or what the run's Session says of the hop (robots_disallowed, refused, rate_limited, ...);
    url is the address not asked, chain the hops followed until then."""

    def __init__(self, status, why, url="", chain=None):
        NetworkError.__init__(self, why)
        self.status, self.why, self.url, self.chain = status, why, url, list(chain or [])


def header(headers, name):
    """A response header by name, whatever its case."""
    name = name.lower()
    for key, value in (headers or {}).items():
        if str(key).lower() == name:
            return value
    return None


# --- addresses (r5.59, point 1) ---------------------------------------------------------------------------------------

UNREADABLE_HOST = ("the host name cannot be read in one spelling (a user part, percent escapes left after decoding, "
                   "characters a host name does not have): not asked")
_HOST_NAME = re.compile(r"[a-z0-9_.-]+")
_NUMERIC_V4 = re.compile(r"(?:0x[0-9a-f]*|[0-9]+)(?:\.(?:0x[0-9a-f]*|[0-9]+)){0,3}")


def _one_spelling(host):
    """A host as the socket layer will look it up: IDNA as Python applies it to a host name (full-width letters, the
    ideographic full stop), lower case, no final dot; an IPv6 address in its short form, without brackets or zone; an
    IPv4 address written the short or the hexadecimal way (127.1, 0x7f.0.0.1) as the address it is. None when it cannot
    be read so."""
    host = host or ""
    if host.startswith("[") and host.endswith("]"):
        host = host[1:-1]
    if ":" in host:
        try:
            return ipaddress.IPv6Address(host.split("%", 1)[0]).compressed
        except ValueError:
            return None
    try:
        name = host.encode("idna").decode("ascii")
    except UnicodeError:
        if not all(ord(c) < 128 for c in host):
            return None
        name = host  # ASCII the idna codec will not take (an empty label): the socket layer passes it as it is
    name = name.lower().rstrip(".")
    if not name or not _HOST_NAME.fullmatch(name):
        return None
    if _NUMERIC_V4.fullmatch(name):
        try:
            return socket.inet_ntoa(socket.inet_aton(name))
        except OSError:
            return name
    return name


@functools.lru_cache(maxsize=4096)
def canonical_host(url):
    """The host a request to url really goes to, in one spelling, or None (r5.59, after the review of the visual chain).

    urllib.request decodes percent escapes in the host (http://%31%32%37.0.0.1/ goes to 127.0.0.1) and the socket
    layer applies IDNA (a full-width spelling of a name, or one with 。 for its dots, goes to the ASCII name), while
    urlsplit().hostname keeps the spelling as written. Every check (blocked_hosts, this machine and private networks,
    stopped hosts, robots.txt, pacing) uses this reading. None, and nothing is asked, when the address is not http(s),
    has a user part (user@host), or its host cannot be read in one spelling: escapes left after decoding, characters a
    host name does not have, or urllib.request and urlsplit reading the host differently."""
    try:
        parts = urllib.parse.urlsplit(url or "")
        if parts.scheme.lower() not in ("http", "https") or not parts.netloc or "@" in parts.netloc:
            return None
        wire = urllib.request.Request(url).host or ""   # what urllib connects to: the host, decoded, with its port
    except ValueError:
        return None
    colon, bracket = wire.rfind(":"), wire.rfind("]")
    if colon > bracket:  # the port, split off as http.client does
        if not wire[colon + 1:].isdigit() and wire[colon + 1:]:
            return None
        wire = wire[:colon]
    host = _one_spelling(wire)
    seen = _one_spelling(urllib.parse.unquote(parts.hostname or ""))
    return host if host and host == seen else None


def host_of(url):
    """The host of url as canonical_host reads it (as written, in lower case, when it cannot be read)."""
    host = canonical_host(url)
    if host is not None:
        return host
    try:
        return (urllib.parse.urlsplit(url or "").hostname or "").lower().rstrip(".")
    except ValueError:
        return ""


def _netloc(host, port=None):
    return ("[%s]" % host if ":" in host else host) + (":%d" % port if port else "")


def origin_of(url):
    parts = urllib.parse.urlsplit(url or "")
    try:
        port = parts.port
    except ValueError:
        port = None
    return "%s://%s" % (parts.scheme.lower(), _netloc(host_of(url), port))


def blocked(url, config):
    """The host of url (as canonical_host reads it) is in network.blocked_hosts, or under one of them."""
    host = canonical_host(url)
    if host is None:
        return False  # not asked anyway (canonical_host): the checks say why
    names = []
    for given in config["network"].get("blocked_hosts", []):
        given = given.strip()
        names.append(_one_spelling(given) or given.lower().rstrip("."))
    return any(host == h or host.endswith("." + h) for h in names if h)


def literal_address(host):
    try:
        return ipaddress.ip_address((host or "").strip("[]").split("%", 1)[0])
    except ValueError:
        return None


def public(address):
    """An address on the open internet: not this machine, not a private network, not link-local, site-local (the old
    IPv6 fec0::/10), reserved, multicast or unspecified (an IPv4 address written as IPv6 is judged as IPv4)."""
    if isinstance(address, ipaddress.IPv6Address):
        inner = address.ipv4_mapped or address.sixtofour
        if inner is not None and not public(inner):
            return False
        if address.is_site_local:
            return False
    return address.is_global and not (address.is_private or address.is_loopback or address.is_link_local
                                      or address.is_reserved or address.is_multicast or address.is_unspecified)


def resolve_all(host, port):
    """Every address the host name resolves to here (the system resolver)."""
    return sorted({info[4][0] for info in socket.getaddrinfo(host, port, proto=socket.IPPROTO_TCP)})


def address_problem(url, config, resolve=None, allow_local=()):
    """(problem, note) for one address before it is asked. problem is None or {status, error}: not http(s) (error),
    a blocked host (blocked), or a name or address on this machine or a private network (private_address); a name is
    judged by every address resolve(host, port) gives. note says what could not be judged: a name that does not resolve
    here (through a proxy, the proxy resolves it) is asked anyway and the note says so; with resolve None (a stand-in
    network) only literal addresses and localhost names are judged. allow_local is for tests only: exact "host:port"
    strings that may be asked although they are local."""
    parts = urllib.parse.urlsplit(url or "")
    if parts.scheme not in ("http", "https") or not parts.hostname:
        return {"status": "error", "error": "not an http(s) address"}, None
    try:
        port = parts.port or (443 if parts.scheme == "https" else 80)
    except ValueError:
        return {"status": "error", "error": "the address has a bad port"}, None
    host = canonical_host(url)
    if host is None:
        return {"status": "error", "error": UNREADABLE_HOST}, None
    if blocked(url, config):
        return {"status": "blocked", "error": BLOCKED}, None
    if "%s:%d" % (host, port) in allow_local:
        return None, "allowed for a test (%s)" % _netloc(host, port)
    if host == "localhost" or host.endswith(".localhost"):
        return {"status": "private_address", "error": "%s is this machine: not asked" % host}, None
    literal = literal_address(host)
    if literal is not None:
        if public(literal):
            return None, None
        return {"status": "private_address", "error": "%s is on this machine or a private network: not asked" % host}, None
    if resolve is None:
        return None, "not resolved (a stand-in network)"
    try:
        addresses = resolve(host, port)
    except (OSError, UnicodeError) as exc:
        return None, "could not be resolved here (%s): not judged by its address" % exc
    local = [a for a in addresses if literal_address(a) is None or not public(literal_address(a))]
    if local:
        return {"status": "private_address", "error": "%s resolves to %s (this machine or a private network): not asked"
                % (host, ", ".join(local))}, None
    if not addresses:
        return None, "resolved to no address here: not judged by its address"
    return None, None


class _Hops(urllib.request.HTTPRedirectHandler):
    """Redirects one hop at a time: check(new address) may refuse a hop; at most MAX_REDIRECTS hops. urllib's own loop
    guard (four visits of one address) is set above that, so a loop is counted here and recorded as too_many_redirects,
    and no hop is counted that is not sent."""
    max_redirections = MAX_REDIRECTS + 1
    max_repeats = MAX_REDIRECTS + 1

    def __init__(self, check):
        self.check = check
        self.chain = []

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        self.chain.append({"from": clean_url(req.full_url), "to": clean_url(newurl), "status": code})
        if len(self.chain) > MAX_REDIRECTS:
            problem = {"status": "too_many_redirects", "error": "more than %d redirects" % MAX_REDIRECTS}
        else:
            problem = self.check(newurl)
        if problem:
            try:
                fp.close()
            except Exception:  # noqa: BLE001 - closing the answer we do not follow
                pass
            raise Refused(problem["status"], problem.get("error") or problem["status"], newurl, self.chain)
        return urllib.request.HTTPRedirectHandler.redirect_request(self, req, fp, code, msg, headers, newurl)


def default_hop(first, config):
    """The hop check when no Session asks: a hop to another host than the first address's is checked by address, so a
    configured service (often on this machine) can redirect within itself but not send the request elsewhere."""
    origin = canonical_host(first)

    def check(new):
        parts = urllib.parse.urlsplit(new)
        if parts.scheme not in ("http", "https"):
            return {"status": "error", "error": "a redirect to a non-http(s) address"}
        if origin is not None and canonical_host(new) == origin and not blocked(new, config):
            return None
        return address_problem(new, config, resolve=resolve_all)[0]

    return check


def http(url, config, headers=None, data=None, max_bytes=None, method=None, sleep=None):
    """One HTTP request with the config's timeout and size limit, tried again network.retries times after a timeout,
    a dropped connection or a 5xx answer. Raises Timeout, TooLarge or NetworkError (Refused for a hop not followed); an
    HTTP error status comes back as a Response. r5.59: a try again waits first (Retry-After when the answer gives one,
    else network.min_interval_seconds); an answer asking for more than network.max_wait_seconds is returned as it is."""
    sleep = sleep or time.sleep
    network = config["network"]
    tries = max(0, int(network.get("retries", 1))) + 1
    interval = float(network.get("min_interval_seconds", 1))
    longest = float(network.get("max_wait_seconds", 30))
    for attempt in range(tries):
        last = attempt + 1 == tries
        try:
            response = http_once(url, config, headers, data, max_bytes, method)
        except Refused:
            raise
        except (Timeout, NetworkError):
            if last:
                raise
            sleep(interval)
            continue
        if response.status >= 500 and not last and not challenge_page(response.headers, response.body):
            wait = retry_after_seconds(response.headers)
            wait = interval if wait is None else max(wait, interval)
            if wait > longest:
                return response
            sleep(wait)
            continue
        return response


def http_once(url, config, headers=None, data=None, max_bytes=None, method=None, hop=None):
    """One request, never tried again. Redirects are followed by hand: hop(new address) is asked before each hop and
    returns None or {status, error} (default: default_hop); a refused hop raises Refused with the chain so far."""
    if not re.match(r"^https?://", url or ""):
        raise NetworkError("not an http(s) address: %r" % url)
    if canonical_host(url) is None:
        raise Refused("error", UNREADABLE_HOST, url)
    if blocked(url, config):
        raise Refused("blocked", "the host is blocked in the config", url)
    limit = max_bytes or config["network"]["max_json_bytes"]
    hops = _Hops(hop or default_hop(url, config))
    opener = urllib.request.build_opener(hops)
    request = urllib.request.Request(url, data=data, method=method,
                                     headers=dict({"User-Agent": config["network"]["user_agent"]}, **(headers or {})))
    start = datetime.datetime.now()
    final = url
    try:
        with opener.open(request, timeout=config["network"]["timeout_seconds"]) as response:
            body = response.read(limit + 1)
            status, head = response.status, dict(response.headers.items())
            final = response.geturl() or url
    except Refused:
        raise
    except urllib.error.HTTPError as exc:
        target = getattr(exc, "filename", None) or url
        if 300 <= exc.code < 400 and not re.match(r"^https?://", str(target), re.I):
            # urllib refuses a redirect to file:, data: and the like itself, before any hop check: it was not followed
            exc.close()
            frm = hops.chain[-1]["to"] if hops.chain else clean_url(url)
            hop = {"from": frm, "to": str(target)[:200], "status": exc.code}
            raise Refused("error", "a redirect to a non-http(s) address: not followed", str(target)[:200],
                          hops.chain + [hop]) from None
        if 300 <= exc.code < 400 and str(exc.msg).startswith(urllib.request.HTTPRedirectHandler.inf_msg):
            exc.close()
            raise Refused("too_many_redirects", "a redirect loop (urllib's own guard)", str(target),
                          hops.chain) from None
        body = exc.read(limit + 1) if exc.fp else b""
        status, head = exc.code, dict(exc.headers.items()) if exc.headers else {}
        final = target
    except (socket.timeout, TimeoutError) as exc:
        raise Timeout(str(exc)) from exc
    except urllib.error.URLError as exc:
        if isinstance(exc.reason, (socket.timeout, TimeoutError)):
            raise Timeout(str(exc.reason)) from exc
        raise NetworkError(str(exc.reason)) from exc
    except (OSError, ValueError, HTTPException) as exc:  # a connection dropped halfway is broken too
        raise NetworkError("%s: %s" % (type(exc).__name__, exc)) from exc
    if len(body) > limit:
        raise TooLarge("more than %d bytes" % limit)
    promised = str(header(head, "Content-Length") or "").strip()
    if promised.isdigit() and len(body) < int(promised):  # cut off: half a robots.txt would allow too much
        raise NetworkError("the connection dropped after %d of %s bytes" % (len(body), promised))
    elapsed = int((datetime.datetime.now() - start).total_seconds() * 1000)
    return Response(status, head, body, url, elapsed, final_url=final, redirects=hops.chain)


_http_once = http_once


def clean_url(url):
    """An address as recorded: no user, password or key-like query values."""
    parts = urllib.parse.urlsplit(url)
    query = [(k, "***" if re.search(r"key|token|secret|password|sig", k, re.I) else v)
             for k, v in urllib.parse.parse_qsl(parts.query, keep_blank_values=True)]
    try:
        port = parts.port
    except ValueError:
        port = None
    netloc = _netloc(parts.hostname or "", port)
    return urllib.parse.urlunsplit((parts.scheme, netloc, parts.path, urllib.parse.urlencode(query), ""))


def stop_search(record, queries, headers=None, wall=None):
    """A search service limited a request (429, r5.61): the words not sent yet stay unsent, the record lists them, and
    it keeps how long the service asked to wait (Retry-After, in seconds or as a date) when it said, else null.
    Nothing waits here and nothing is tried again."""
    why = "rate_limited"
    sent = [r.get("query") for r in record["requests"]]
    left = [q for q in queries if q not in sent]
    record["requests"] += [{"query": q, "status": "not_sent", "why": why} for q in left]
    record["stopped"] = {"why": why, "not_sent": len(left)}
    wait = retry_after_seconds(headers or {}, wall)
    record["stopped"]["retry_after_seconds"] = wait
    if wait is not None:
        moment = (wall() if wall else datetime.datetime.now(datetime.timezone.utc)) + datetime.timedelta(seconds=wait)
        record["stopped"]["retry_at"] = moment.astimezone(datetime.timezone.utc).isoformat(timespec="seconds")
    return record


# --- waiting (r5.59, point 3) -----------------------------------------------------------------------------------------

def retry_after_seconds(headers, wall=None):
    """Retry-After in seconds (a whole number, or an HTTP date counted from wall(), the time now), or None."""
    value = header(headers, "Retry-After")
    if value is None:
        return None
    value = str(value).strip()
    if re.fullmatch(r"\d+", value):
        return float(int(value))
    try:
        moment = email.utils.parsedate_to_datetime(value)
    except (TypeError, ValueError, IndexError, OverflowError):
        return None
    if moment is None:
        return None
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=datetime.timezone.utc)
    current = wall() if wall else datetime.datetime.now(datetime.timezone.utc)
    return max(0.0, (moment - current).total_seconds())


class VirtualClock:
    """Time that passes only when waited: a run on a stand-in network (a test) counts its waits instead of sleeping."""

    def __init__(self, start=0.0):
        self.time = float(start)

    def now(self):
        return self.time

    def sleep(self, seconds):
        self.time += max(0.0, float(seconds))


# --- check pages (r5.59, point 3) -------------------------------------------------------------------------------------

CHALLENGE_MARKERS = ("/cdn-cgi/challenge-platform/", "challenges.cloudflare.com", "cf-chl-", "cf_chl_",
                     "captcha-delivery.com", "_incapsula_resource", "px-captcha", "cf-browser-verification")
CHALLENGE_TITLE = re.compile(r"<title[^>]*>\s*(?:just a moment|attention required|are you a robot|are you human|"
                             r"verify you are human|security check|captcha|human verification|access denied)", re.I)


def challenge_page(headers, body, text=None):
    """What marks an answer as a check page (a browser check, a captcha, a bot wall), or None. The markers age and can
    be wrong; a wrong one only makes the workshop take less."""
    if str(header(headers, "cf-mitigated") or "").strip().lower() == "challenge":
        return "cf-mitigated: challenge"
    if text is None:
        kind = str(header(headers, "Content-Type") or "").lower()
        head = (body or b"")[:65536]
        if "html" not in kind and not head.lstrip()[:1] == b"<":
            return None
        text = head.decode("utf-8", "replace")
    text = text[:65536]
    lowered = text.lower()
    for marker in CHALLENGE_MARKERS:
        if marker in lowered:
            return "the page carries %s" % marker
    title = CHALLENGE_TITLE.search(text)
    if title:
        return "the page is titled %r" % title.group(0).split(">", 1)[1].strip()[:60]
    return None


# --- robots.txt (r5.59, point 2) --------------------------------------------------------------------------------------

def _normalized(text):
    """A path, query or rule in one spelling (percent-escapes decoded and encoded again), so /a%7Eb and /a~b agree."""
    return urllib.parse.quote(urllib.parse.unquote(text, errors="surrogateescape"), safe="/?:@!$&'()*+,;=~-._",
                              errors="surrogateescape")


def _agent_token(value):
    value = value.strip()
    if value.startswith("*"):
        return "*"
    found = re.match(r"[A-Za-z_-]+", value)
    return (found.group(0) if found else value).lower()


@functools.lru_cache(maxsize=512)
def _pattern(rule):
    anchored = rule.endswith("$")
    body = rule[:-1] if anchored else rule
    regex = "".join(".*" if part == "*" else re.escape(part) for part in re.split(r"(\*)", body) if part)
    return re.compile(regex + (r"\Z" if anchored else ""), re.DOTALL)


class RobotsRules:
    """One robots.txt read the RFC 9309 way by the workshop's own code: the groups naming the workshop's product token
    (all of them together), else the groups for every crawler (*); among the rules that match an address the longest
    wins and Allow wins a tie; * is any run of characters and a final $ ends the address; the robots.txt itself is
    always allowed. Crawl-delay and Request-rate of the chosen groups give the longest wait between requests."""

    def __init__(self, text):
        self.groups = []
        group, in_agents = None, False
        for raw in (text or "").lstrip("\ufeff").splitlines():
            line = raw.split("#", 1)[0].strip()
            if ":" not in line:
                continue
            key, value = line.split(":", 1)
            key, value = key.strip().lower(), value.strip()
            if key == "user-agent":
                if group is None or not in_agents:
                    group = {"agents": [], "rules": [], "delays": []}
                    self.groups.append(group)
                group["agents"].append(_agent_token(value))
                in_agents = True
                continue
            if key == "sitemap":
                continue
            in_agents = False
            if group is None:
                continue
            if key in ("allow", "disallow"):
                if value:
                    group["rules"].append((key == "allow", _normalized(value)))
            elif key == "crawl-delay":
                found = re.fullmatch(r"(\d+(?:\.\d+)?)", value)
                if found:
                    group["delays"].append(float(found.group(1)))
            elif key == "request-rate":
                found = re.fullmatch(r"(\d+)\s*/\s*(\d+(?:\.\d+)?)\s*([smh]?)", value, re.I)
                if found and int(found.group(1)) > 0:
                    unit = {"": 1, "s": 1, "m": 60, "h": 3600}[found.group(3).lower()]
                    group["delays"].append(float(found.group(2)) * unit / int(found.group(1)))

    def groups_for(self, token=AGENT_TOKEN):
        token = token.lower()
        mine = [g for g in self.groups if token in g["agents"]]
        if mine:
            return token, mine
        every = [g for g in self.groups if "*" in g["agents"]]
        return ("*" if every else None), every

    def delay(self, token=AGENT_TOKEN):
        delays = [d for g in self.groups_for(token)[1] for d in g["delays"]]
        return max(delays) if delays else None

    def verdict(self, url, token=AGENT_TOKEN):
        """(allowed, the rule that decided, or None when no rule matched)."""
        parts = urllib.parse.urlsplit(url)
        if (parts.path or "/") == "/robots.txt":
            return True, None
        path = _normalized((parts.path or "/") + ("?" + parts.query if parts.query else ""))
        best = None
        for group in self.groups_for(token)[1]:
            for allow, rule in group["rules"]:
                if _pattern(rule).match(path):
                    key = (len(rule), allow)
                    if best is None or key > best[0]:
                        best = (key, allow, rule)
        if best is None:
            return True, None
        return best[1], ("Allow: " if best[1] else "Disallow: ") + best[2]


# The two readings urllib.robotparser has had (r5.59, after the review of the visual chain). Python 3.13 changed it
# (the longest rule wins, * and $ are understood, groups of one name are merged, a blank line no longer ends a group);
# before, the first rule that matched decided. "Both the workshop's reading and the standard library allow it" would
# then take an address on one Python and not on another. Both readings are written out below, following the logic of
# urllib.robotparser step by step (read in Python 3.12.3, the same in 3.9 and 3.11, and in 3.13.17; Python is under the
# PSF License), so that on every Python an address is taken only when the workshop's own reading, both readings of the
# standard library and this Python's urllib.robotparser all allow it: the strictest reading, the same everywhere. The
# tests check each written-out reading against the urllib.robotparser of the Python they run on.

def _agent_in(agents, token):
    """urllib.robotparser's name match: a group's name (in lower case) is a part of the workshop's name token."""
    token = token.split("/")[0].lower()
    return any(agent != "*" and agent.lower() in token for agent in agents)


class OlderStdlibReading:
    """urllib.robotparser as Python 3.9 to 3.12 read a robots.txt: a blank line ends a group; the first group whose
    name is a part of the workshop's name, else the first group for every crawler (a later one is not read); percent
    escapes are decoded first; the first rule that matches the start of the address decides; * and $ are plain
    characters; an empty Disallow allows everything after it. A Crawl-delay it cannot read as a number stops that
    reading from allowing anything (the standard library itself stops with an error there)."""

    def __init__(self, text):
        self.entries, self.default, self.broken = [], None, False
        entry, state = self._entry(), 0
        for line in (text or "").splitlines():
            if not line:
                if state == 1:
                    entry, state = self._entry(), 0
                elif state == 2:
                    self._add(entry)
                    entry, state = self._entry(), 0
            line = line.split("#", 1)[0].strip()
            if not line:
                continue
            parts = line.split(":", 1)
            if len(parts) != 2:
                continue
            key, value = parts[0].strip().lower(), urllib.parse.unquote(parts[1].strip())
            if key == "user-agent":
                if state == 2:
                    self._add(entry)
                    entry = self._entry()
                entry["agents"].append(value)
                state = 1
            elif key in ("allow", "disallow"):
                if state != 0:
                    allow = key == "allow" or value == ""
                    path = urllib.parse.quote(urllib.parse.urlunparse(urllib.parse.urlparse(value)))
                    entry["rules"].append((path, allow))
                    state = 2
            elif key == "crawl-delay":
                if state != 0:
                    if value.strip().isdigit():
                        try:
                            entry["delay"] = int(value)
                        except ValueError:
                            self.broken = True
                    state = 2
            elif key == "request-rate":
                if state != 0:
                    numbers = value.split("/")
                    if len(numbers) == 2 and numbers[0].strip().isdigit() and numbers[1].strip().isdigit():
                        try:
                            entry["rate"] = (int(numbers[0]), int(numbers[1]))
                        except ValueError:
                            self.broken = True
                    state = 2
        if state == 2:
            self._add(entry)

    @staticmethod
    def _entry():
        return {"agents": [], "rules": [], "delay": None, "rate": None}

    def _add(self, entry):
        if "*" in entry["agents"]:
            if self.default is None:
                self.default = entry
        else:
            self.entries.append(entry)

    def entry_for(self, token):
        for entry in self.entries:
            if _agent_in(entry["agents"], token):
                return entry
        return self.default

    def allowed(self, url, token=AGENT_TOKEN):
        if self.broken:
            return False
        parsed = urllib.parse.urlparse(urllib.parse.unquote(url))
        path = urllib.parse.quote(urllib.parse.urlunparse(("", "", parsed.path, parsed.params, parsed.query,
                                                           parsed.fragment))) or "/"
        entry = self.entry_for(token)
        for rule, allow in (entry or {}).get("rules", []):
            if rule == "*" or path.startswith(rule):
                return allow
        return True

    def delay(self, token=AGENT_TOKEN):
        entry = self.entry_for(token) or {}
        delays = [float(entry["delay"])] if entry.get("delay") is not None else []
        if entry.get("rate") and entry["rate"][0]:
            delays.append(float(entry["rate"][1]) / entry["rate"][0])
        return max(delays) if delays else None


def _std_normalize(text):
    return urllib.parse.quote(urllib.parse.unquote(text, errors="surrogateescape"), errors="surrogateescape")


def _std_normalize_uri(path):
    path, sep, query = path.partition("?")
    path = _std_normalize(path)
    if sep:
        path += "?" + re.sub(r"[^=&]+", lambda m: _std_normalize(m.group(0)), query)
    return path


def _std_normalize_pattern(path):
    path, sep, query = path.partition("?")
    path = re.sub(r"[^*$]+", lambda m: _std_normalize(m.group(0)), path)
    if sep:
        path += "?" + re.sub(r"[^=&*$]+", lambda m: _std_normalize(m.group(0)), query)
    return path


class NewerStdlibReading:
    """urllib.robotparser as Python 3.13 reads a robots.txt (RFC 9309): blank lines do not end a group; groups of one
    name are merged; the group named exactly as the workshop, else the first group whose name is a part of the
    workshop's name, else the group for every crawler; among the rules that match, the one matching the longest part
    of the address wins (for a rule with *, the part of the address it matched, not its own length) and Allow wins a
    tie; * and a final $ are understood; a rule with $ elsewhere is dropped; /robots.txt is always allowed."""

    def __init__(self, text):
        self.groups = {}
        entry, state = self._entry(), 0
        for line in (text or "").splitlines():
            line = line.split("#", 1)[0].strip()
            if not line:
                continue
            parts = line.split(":", 1)
            if len(parts) != 2:
                continue
            key, value = parts[0].strip().lower(), parts[1].strip()
            if key == "user-agent":
                if state == 2:
                    self._add(entry)
                    entry = self._entry()
                entry["agents"].append(value)
                state = 1
            elif key in ("allow", "disallow"):
                if state != 0:
                    state = 2
                    rule = self._rule(value, key == "allow")
                    if rule:
                        entry["rules"].append(rule)
            elif key == "crawl-delay":
                if state != 0:
                    if value.strip().isdecimal():
                        entry["delay"] = int(value)
                    state = 2
            elif key == "request-rate":
                if state != 0:
                    numbers = value.split("/")
                    if len(numbers) == 2 and numbers[0].strip().isdecimal() and numbers[1].strip().isdecimal():
                        entry["rate"] = (int(numbers[0]), int(numbers[1]))
                    state = 2
        if state != 0:
            self._add(entry)

    @staticmethod
    def _entry():
        return {"agents": [], "rules": [], "delay": None, "rate": None}

    @staticmethod
    def _rule(path, allow):
        if path == "" and not allow:
            allow = True
        path = re.sub(r"[*]{2,}", "*", path)
        path = re.sub(r"[$][$*]+", "$", path)
        path = _std_normalize_pattern(path)
        full = path.endswith("$")
        path = path.rstrip("$")
        if "$" in path:
            return None
        matcher = None
        if "*" in path:
            parts = [re.escape(part) for part in path.split("*")]
            for i in range(1, len(parts) - 1):
                parts[i] = "(?:.*?%s)" % parts[i]  # the standard library's (?>...) where Python has it: the same ends
            parts[-1] = ".*" + parts[-1]
            pattern = re.compile("".join(parts), re.DOTALL)
            matcher = pattern.fullmatch if full else pattern.match
        return path, allow, full, matcher

    def _add(self, entry):
        for agent in entry["agents"]:
            agent = agent.lower()
            if agent not in self.groups:
                self.groups[agent] = entry
            else:
                first = self.groups[agent]
                self.groups[agent] = {"agents": [a for a in first["agents"] if a in set(entry["agents"])],
                                      "rules": first["rules"] + entry["rules"],
                                      "delay": first["delay"] if entry["delay"] is None else entry["delay"],
                                      "rate": first["rate"] if entry["rate"] is None else entry["rate"]}

    def entry_for(self, token):
        found = self.groups.get(token.lower())
        if found is not None:
            return found
        for entry in self.groups.values():
            if _agent_in(entry["agents"], token):
                return entry
        return self.groups.get("*")

    def allowed(self, url, token=AGENT_TOKEN):
        parsed = urllib.parse.urlsplit(url)
        path = parsed.path + ("?" + parsed.query if parsed.query else "") + ("#" + parsed.fragment
                                                                            if parsed.fragment else "")
        path = _std_normalize_uri(path) or "/"
        if path == "/robots.txt":
            return True
        entry = self.entry_for(token)
        if entry is None:
            return True
        best, allowance = -1, True
        for rule, allow, full, matcher in entry["rules"]:
            if matcher is not None:
                found = matcher(path)
                length = found.end() + 1 if found else 0
            elif full:
                length = len(rule) + 1 if path == rule else 0
            else:
                length = len(rule) + 1 if path.startswith(rule) else 0
            if length:
                if length > best:
                    best, allowance = length, allow
                elif length == best and not allowance:
                    allowance = allow
        return allowance

    def delay(self, token=AGENT_TOKEN):
        entry = self.entry_for(token) or {}
        delays = [float(entry["delay"])] if entry.get("delay") is not None else []
        if entry.get("rate") and entry["rate"][0]:
            delays.append(float(entry["rate"][1]) / entry["rate"][0])
        return max(delays) if delays else None


def stdlib_robots(text):
    """This Python's urllib.robotparser over the text, or None when it stops with an error (then it allows nothing)."""
    parser = urllib.robotparser.RobotFileParser()
    try:
        parser.parse((text or "").lstrip("\ufeff").splitlines())
    except (ValueError, TypeError):
        return None
    return parser


class RobotsReadings:
    """One robots.txt read four ways: the workshop's own (RobotsRules, RFC 9309 with the longest rule by its length),
    urllib.robotparser's reading before Python 3.13 and from 3.13 (written out above), and this Python's
    urllib.robotparser. A leading BOM is dropped first."""

    def __init__(self, text):
        text = (text or "").lstrip("\ufeff")
        self.own, self.older, self.newer = RobotsRules(text), OlderStdlibReading(text), NewerStdlibReading(text)
        self.std = stdlib_robots(text)

    def judge(self, url, token=AGENT_TOKEN):
        """{allowed, own, stdlib, stdlib_before_3_13, stdlib_3_13, rule, disagree}: allowed only when all four allow;
        rule is the rule the workshop's own reading decided by; disagree when the readings differ."""
        own, rule = self.own.verdict(url, token)
        stdlib = bool(self.std.can_fetch(token, url)) if self.std is not None else False
        older, newer = self.older.allowed(url, token), self.newer.allowed(url, token)
        out = {"allowed": own and stdlib and older and newer, "own": own, "stdlib": stdlib,
               "stdlib_before_3_13": older, "stdlib_3_13": newer, "rule": rule}
        if len({own, stdlib, older, newer}) > 1:
            out["disagree"] = True
        return out

    def delay(self, token=AGENT_TOKEN):
        """The longest wait any of the readings asks of the workshop (Crawl-delay, Request-rate), or None."""
        delays = [d for d in (self.own.delay(token), self.older.delay(token), self.newer.delay(token)) if d is not None]
        if self.std is not None:
            if self.std.crawl_delay(token) is not None:
                delays.append(float(self.std.crawl_delay(token)))
            rate = self.std.request_rate(token)
            if rate is not None and getattr(rate, "requests", 0):
                delays.append(float(rate.seconds) / rate.requests)
        return float(max(delays)) if delays else None


def judge_robots(readings, url, token=AGENT_TOKEN):
    """How one address fares under the readings of one robots.txt (RobotsReadings.judge)."""
    return readings.judge(url, token)


def robots_judgement(text, url, token=AGENT_TOKEN):
    """How one address fares under one robots.txt text (a leading BOM is dropped); see RobotsReadings.judge."""
    return RobotsReadings(text).judge(url, token)


def robots_text(body):
    """The text of a robots.txt answer: UTF-8, a byte order mark dropped (left in, it hides the first line)."""
    return (body or b"").decode("utf-8", "replace").lstrip("\ufeff")


def robots_delay(text, token=AGENT_TOKEN):
    """The longest wait robots.txt asks of the workshop (Crawl-delay, Request-rate), by every reading, or None."""
    return RobotsReadings(text).delay(token)


# --- page text that says who made an image (r5.59, point 5) -----------------------------------------------------------

CREDIT_WORDS = re.compile(r"(摄影|拍摄|图片来源|图源|来源[:：]|供图|图[:：]|作者[:：]|©|\(c\)|版权|授权|"
                          r"Photo(?:graph)?\s*(?:by|:)|Credit|Image\s*:|Courtesy|\bCC[ -]?(?:BY|0)\b|Licen[cs]e)", re.I)
LICENCE_LINK = re.compile(r"https?://(?:www\.)?creativecommons\.org/(?:licenses|publicdomain)/[^\s\"'<>)）]+", re.I)


def credit_line(text, limit=200):
    """The part of a page text that reads like a credit or a licence (摄影：…, Photo by …, CC BY …), or ""."""
    text = re.sub(r"\s+", " ", text or "").strip()
    found = CREDIT_WORDS.search(text)
    return text[found.start():][:limit].strip() if found else ""


def licence_links(text):
    return sorted(set(m.group(0).rstrip(".,;。，；") for m in LICENCE_LINK.finditer(text or "")))


def page_says_of(*texts):
    """What the page itself says about who made an image and under what licence, found in its texts: {credit,
    license_links}, or {}. It is what the page says, never a licence the workshop checked (collect records it in
    on_page.page_says with checked: false; select and adopt never read it)."""
    out = {}
    for text in texts:
        credit = credit_line(text)
        if credit and "credit" not in out:
            out["credit"] = credit
        links = licence_links(text)
        if links:
            out["license_links"] = sorted(set(out.get("license_links", [])) | set(links))
    return out


# --- srcset (r5.59, point 8; the HTML standard's "parse a srcset attribute") ------------------------------------------

_SPACE = " \t\n\r\f"


def parse_srcset(value):
    """[(url, width or None, density or None)] in order, as the HTML standard splits a srcset: an address may hold
    commas; a candidate whose descriptors cannot be read is dropped."""
    value = value or ""
    out, pos, end = [], 0, len(value)
    while True:
        while pos < end and (value[pos] in _SPACE or value[pos] == ","):
            pos += 1
        if pos >= end:
            return out
        start = pos
        while pos < end and value[pos] not in _SPACE:
            pos += 1
        url, descriptors = value[start:pos], []
        if url.endswith(","):
            url = url.rstrip(",")
        else:
            while pos < end and value[pos] in _SPACE:
                pos += 1
            current, state = "", "in"
            while True:
                char = value[pos] if pos < end else None
                if state == "in":
                    if char is not None and char in _SPACE:
                        if current:
                            descriptors.append(current)
                        current, state = "", "after"
                    elif char == ",":
                        pos += 1
                        if current:
                            descriptors.append(current)
                        break
                    elif char == "(":
                        current += char
                        state = "parens"
                    elif char is None:
                        if current:
                            descriptors.append(current)
                        break
                    else:
                        current += char
                elif state == "parens":
                    if char is None:
                        descriptors.append(current)
                        break
                    current += char
                    if char == ")":
                        state = "in"
                else:  # after a descriptor
                    if char is None:
                        break
                    if char not in _SPACE:
                        state = "in"
                        continue
                pos += 1
        width = density = None
        good = bool(url)
        for item in descriptors:
            kind, amount = item[-1:].lower(), item[:-1]
            if kind == "w" and width is None and density is None and re.fullmatch(r"\d+", amount) and int(amount) > 0:
                width = int(amount)
            elif kind == "x" and width is None and density is None and re.fullmatch(r"\d+(?:\.\d+)?", amount):
                density = float(amount)
            elif kind == "h" and re.fullmatch(r"\d+", amount):
                continue
            else:
                good = False
        if good:
            out.append((url, width, density))


def best_in_srcset(value):
    """The largest candidate of a srcset (the widest, else the highest density, else the first), or ""."""
    items = parse_srcset(value)
    if not items:
        return ""
    if any(w for _, w, _ in items):
        return max(items, key=lambda i: i[1] or 0)[0]
    return max(items, key=lambda i: i[2] or 1.0)[0]


# --- one run's network (r5.59, points 1-3) ----------------------------------------------------------------------------

class Session:
    """The network manners of one collect (or of any reader it uses), shared by every request it makes.

    request(url, kind) asks one address politely and returns (outcome, response): outcome["status"] is "ok" when an
    answer came that the caller judges (response.status may be any status but 401, 403, 451 and 429, and is not a
    check page), else why nothing came (blocked, private_address, robots_disallowed, robots_unreachable, refused,
    rate_limited, host_paused, too_many_redirects, skipped_max_requests, timeout, too_large, error) with error and,
    when a request was made, http_status. A page read by someone else (Crawl4AI) is let through with admit(url) and
    its answer reported with note_read(url, http_status, html). check(url) says, without asking, what would stop it.
    record() and robots_record() are what collect.json keeps.

    fetch replaces the network (tests): it is called as fetch(url, config, headers=..., max_bytes=...) and follows no
    redirects; addresses are then judged only when literal (no name is resolved), and unless clock and sleep are given
    the waits are counted on a VirtualClock instead of slept. allow_local is for tests only (exact "host:port" strings
    of a local test server); the config has no such key and collect records such a run as http_local_test."""

    def __init__(self, config, fetch=None, clock=None, sleep=None, wall=None, allow_local=()):
        self.config = config
        self.fetch = fetch
        self.allow_local = frozenset(allow_local or ())
        if clock is None and sleep is None and fetch is not None:
            virtual = VirtualClock()
            clock, sleep = virtual.now, virtual.sleep
            self.clock_kind = "virtual"
        else:
            self.clock_kind = "given" if clock is not None else "real"
        self.clock = clock or time.monotonic
        self.sleep = sleep or time.sleep
        self.wall = wall
        network = config["network"]
        self.retries = max(0, int(network.get("retries", 1)))
        self.min_interval = float(network.get("min_interval_seconds", 1))
        self.max_wait = float(network.get("max_wait_seconds", 30))
        self.max_requests = int(config["budgets"].get("max_requests", DEFAULT_BUDGETS["max_requests"]))
        self.resolve = None if fetch is not None else resolve_all
        self.requests = 0
        self.last, self.not_before, self.intervals = {}, {}, {}
        self.stopped, self.addresses, self.notes = {}, {}, {}
        self.robots, self.log = {}, []

    @property
    def transport(self):
        if self.fetch is not None:
            return "injected"
        return "http_local_test" if self.allow_local else "http"

    # -- what stops an address --

    def stop(self, url, status, why, **extra):
        host = host_of(url)
        if host not in self.stopped:
            self.stopped[host] = dict({"status": status, "why": why, "url": clean_url(url), "time": now()}, **extra)
        return self.stopped[host]

    def _stopped(self, url):
        stop = self.stopped.get(host_of(url))
        if not stop:
            return None
        return {"status": stop["status"], "error": "nothing more is asked of %s in this run: %s" % (host_of(url),
                                                                                                    stop["why"])}

    def _address(self, url):
        key = origin_of(url)
        if key not in self.addresses:
            problem, note = address_problem(url, self.config, resolve=self.resolve, allow_local=self.allow_local)
            self.addresses[key] = problem
            if note:
                self.notes[key] = note
        return dict(self.addresses[key]) if self.addresses[key] else None

    def interval(self, url):
        return max(self.min_interval, self.intervals.get(host_of(url), 0.0))

    def check(self, url, kind="image"):
        """None when url may be asked now, else {status, error}. kind "robots" skips the robots.txt check (it is the
        robots.txt)."""
        parts = urllib.parse.urlsplit(url or "")
        if parts.scheme not in ("http", "https") or not parts.hostname:
            return {"status": "error", "error": "not an http(s) address"}
        if canonical_host(url) is None:
            return {"status": "error", "error": UNREADABLE_HOST}
        if blocked(url, self.config):
            return {"status": "blocked", "error": BLOCKED}
        problem = self._stopped(url) or self._address(url)
        if problem:
            return problem
        if kind != "robots":
            problem = self.robots_problem(url)
            if problem:
                return problem
        host = host_of(url)
        if self.interval(url) > self.max_wait:
            self.stop(url, "host_paused", "robots.txt asks for %.0f seconds between requests, more than "
                                          "network.max_wait_seconds (%.0f)" % (self.interval(url), self.max_wait))
            return self._stopped(url)
        if self.not_before.get(host, 0.0) - self.clock() > self.max_wait:
            self.stop(url, "host_paused", "the host asked to wait longer than network.max_wait_seconds (%.0f)"
                      % self.max_wait)
            return self._stopped(url)
        # Last, after robots.txt (which may itself use a request): the budget is never exceeded.
        if self.requests >= self.max_requests:
            return {"status": "skipped_max_requests", "error": "budgets.max_requests (%d) reached" % self.max_requests}
        return None

    # -- waiting and counting --

    def _turn(self, url):
        host = host_of(url)
        due = self.not_before.get(host, float("-inf"))
        if host in self.last:
            due = max(due, self.last[host] + self.interval(url))
        wait = max(0.0, due - self.clock())
        if wait:
            self.sleep(wait)
        return wait

    def _sent(self, url, kind, waited):
        self.requests += 1
        self.last[host_of(url)] = self.clock()
        entry = {"url": clean_url(url), "host": host_of(url), "kind": kind, "at": round(self.clock(), 3),
                 "waited": round(waited, 3)}
        self.log.append(entry)
        return entry

    def _done(self, url):
        self.last[host_of(url)] = self.clock()

    def admit(self, url, kind="page"):
        """For a page another program reads (Crawl4AI): check it, wait for the host's turn and count it as a request.
        None when it may be read now, else {status, error}."""
        problem = self.check(url, kind)
        if problem:
            return problem
        waited = self._turn(url)
        self._sent(url, kind + " (read by the page reader)", waited)
        self._done(url)
        return None

    def answered_by(self, url, final_url=None):
        """The address whose host gave the answer: final_url (after the redirects) when it is a readable http(s)
        address, else url."""
        if final_url and re.match(r"^https?://", final_url, re.I) and canonical_host(final_url) is not None:
            return final_url
        return url

    def note_read(self, url, http_status, html=None, final_url=None):
        """What another reader's answer means for the host that gave it (final_url, after the redirects, when the
        reader says where it landed): refused (401, 403, 451 or a check page) or rate_limited (429) stop that host for
        this run; returns that status, or None."""
        url = self.answered_by(url, final_url)
        marker = challenge_page({}, b"", text=html) if isinstance(html, str) and html else None
        if marker:
            self.stop(url, "refused", "the page reader got a check page (%s)" % marker, http_status=http_status)
            return "refused"
        if http_status in REFUSING:
            self.stop(url, "refused", "the page answered HTTP %d" % http_status, http_status=http_status)
            return "refused"
        if http_status == 429:
            self.stop(url, "rate_limited", "the page answered HTTP 429", http_status=429)
            return "rate_limited"
        return None

    def landed_problem(self, url):
        """For a page another program read (Crawl4AI) that says it ended at url after redirects its browser followed
        itself: None when the workshop would ask url too, else {status, error}. The request was already made, so the
        budget and the host's turn do not apply; robots.txt is asked when the host is new. Nothing from such a page is
        used when this says no."""
        parts = urllib.parse.urlsplit(url or "")
        if parts.scheme not in ("http", "https") or not parts.hostname:
            return {"status": "error", "error": "not an http(s) address"}
        if canonical_host(url) is None:
            return {"status": "error", "error": UNREADABLE_HOST}
        if blocked(url, self.config):
            return {"status": "blocked", "error": BLOCKED}
        return self._stopped(url) or self._address(url) or self.robots_problem(url)

    # -- asking --

    def _hop(self, new, kind):
        problem = self.check(new, kind)
        if problem:
            return problem
        waited = self._turn(new)
        self._sent(new, kind + " (redirect)", waited)
        self._done(new)
        return None

    def _send(self, url, headers, max_bytes, kind):
        if self.fetch is not None:
            return self.fetch(url, self.config, headers=headers, max_bytes=max_bytes)
        return http_once(url, self.config, headers=headers, max_bytes=max_bytes, hop=lambda new: self._hop(new, kind))

    def _judge(self, url, response, kind, last):
        """outcome for one answer, "again" for a 5xx to try again after waiting. A refusal, a 429 or a wait asked for
        stops (or delays) the host that gave the answer, after the redirects, not the host first asked: that one only
        sent the request on, and a later request to it that is sent on again is refused at the hop."""
        status = response.status
        where = self.answered_by(url, response.final_url)
        out = {"status": "ok", "http_status": status}
        if response.final_url and response.final_url != url:
            out["final_url"] = clean_url(response.final_url)
        if response.redirects:
            out["redirects"] = response.redirects
        if host_of(where) != host_of(url):
            out["answered_by"] = host_of(where)
        marker = challenge_page(response.headers, response.body)
        if marker:
            self.stop(where, "refused", "a check page came back (%s)" % marker, http_status=status)
            return dict(out, status="refused", error="a check page came back (%s): not tried again" % marker)
        if status in REFUSING and not (kind == "robots" and status in (401, 403, 451)):
            self.stop(where, "refused", "the host answered HTTP %d" % status, http_status=status)
            return dict(out, status="refused", error="HTTP %d: the host refused; not tried again" % status)
        if status == 429:
            wait = retry_after_seconds(response.headers, self.wall)
            self.stop(where, "rate_limited", "the host answered HTTP 429", http_status=429,
                      retry_after=None if wait is None else round(wait, 3))
            return dict(out, status="rate_limited", error="HTTP 429: the host limits the rate; nothing more asked of it "
                                                          "in this run")
        if status >= 500:
            wait = retry_after_seconds(response.headers, self.wall)
            if wait is not None and wait > self.max_wait:
                self.stop(where, "host_paused", "the host asked to wait %.0f seconds (Retry-After), more than "
                                                "network.max_wait_seconds (%.0f)" % (wait, self.max_wait),
                          http_status=status)
                return dict(out, status="host_paused", error="HTTP %d with Retry-After %.0f seconds: more than "
                                                             "network.max_wait_seconds" % (status, wait))
            if not last:
                self.not_before[host_of(where)] = self.clock() + max(wait or 0.0, self.interval(where))
                return "again"
        return out

    def request(self, url, kind="image", headers=None, max_bytes=None):
        """(outcome, response or None) for one address: checked, its host's turn waited, asked, judged; a 5xx or a
        broken connection is tried again network.retries times after waiting."""
        outcome = None
        for attempt in range(self.retries + 1):
            last = attempt == self.retries
            problem = self.check(url, kind)
            if problem:
                return (problem if outcome is None else dict(problem, earlier=outcome)), None
            waited = self._turn(url)
            entry = self._sent(url, kind, waited)
            try:
                response = self._send(url, headers, max_bytes, kind)
            except Refused as exc:
                self._done(url)
                entry["status"] = exc.status
                out = {"status": exc.status, "error": exc.why, "not_asked": clean_url(exc.url or url)}
                if exc.chain:
                    out["redirects"] = exc.chain
                return out, None
            except Timeout as exc:
                self._done(url)
                entry["status"] = "timeout"
                outcome = {"status": "timeout", "error": str(exc)}
                continue
            except TooLarge as exc:
                self._done(url)
                entry["status"] = "too_large"
                return {"status": "too_large", "error": str(exc)}, None
            except NetworkError as exc:
                self._done(url)
                entry["status"] = "error"
                outcome = {"status": "error", "error": str(exc)}
                continue
            self._done(url)
            if response.final_url and response.final_url != url and canonical_host(response.final_url) is not None:
                self._done(response.final_url)
            entry["http_status"] = response.status
            judged = self._judge(url, response, kind, last)
            if judged == "again":
                outcome = {"status": "ok", "http_status": response.status}
                continue
            entry["status"] = judged["status"]
            return judged, (response if judged["status"] == "ok" else None)
        return outcome, None

    # -- robots.txt --

    def robots_problem(self, url):
        """None when robots.txt lets the workshop ask url, else {status, error}; asks the host's robots.txt the first
        time (once per host and run)."""
        origin = origin_of(url)
        entry = self.robots.get(origin)
        if entry is None:
            entry = self._robots_for(origin)
        result = entry["result"]
        if result == "none":
            return None
        if result == "disallow_all":
            entry["decisions"].append({"url": clean_url(url), "allowed": False, "rule": "the whole site"})
            return {"status": "robots_disallowed", "error": "robots.txt answered HTTP %s: nothing on this site is "
                                                            "allowed" % entry.get("http_status")}
        if result != "rules":
            status = "robots_unreachable" if result == "unreachable" else result
            return {"status": status, "error": "robots.txt could not be read (%s): nothing on this site is asked this "
                                               "time" % entry.get("error", result)}
        judged = entry["_readings"].judge(url)
        decision = dict({"url": clean_url(url)}, **judged)
        entry["decisions"].append(decision)
        if judged.get("disagree"):
            entry["disagreements"] += 1
        if judged["allowed"]:
            return None
        if not judged["own"]:
            return {"status": "robots_disallowed", "error": "robots.txt does not allow it (%s)" % judged["rule"]}
        stricter = [name for key, name in (("stdlib_before_3_13", "urllib.robotparser before Python 3.13, which takes "
                                            "the first rule that matches"),
                                           ("stdlib_3_13", "urllib.robotparser from Python 3.13, which weighs a rule "
                                            "with * by the part of the address it matched"),
                                           ("stdlib", "this Python's urllib.robotparser")) if not judged[key]]
        return {"status": "robots_disallowed", "error": "robots.txt does not allow it as read by %s; the workshop's "
                "own reading (the longest rule) allows it%s, but the stricter reading is used" % (
                    "; ".join(stricter), " (%s)" % judged["rule"] if judged["rule"] else "")}

    def _robots_for(self, origin):
        robots_url = origin + "/robots.txt"
        entry = {"url": robots_url, "time": now(), "decisions": [], "disagreements": 0}
        self.robots[origin] = entry
        outcome, response = self.request(robots_url, "robots", headers={"Accept": "text/plain, */*;q=0.1"},
                                         max_bytes=ROBOTS_MAX_BYTES)
        if outcome.get("http_status") is not None:
            entry["http_status"] = outcome["http_status"]
        if response is None:
            if outcome["status"] in ("timeout", "error", "too_large", "too_many_redirects", "blocked",
                                     "private_address"):
                entry.update(result="unreachable", error=outcome.get("error") or outcome["status"])
            else:
                entry.update(result=outcome["status"], error=outcome.get("error", ""))
            return entry
        status = response.status
        if status == 200:
            text = robots_text(response.body)
            readings = RobotsReadings(text)
            group, _ = readings.own.groups_for()
            delay = readings.delay()
            entry.update(result="rules", sha256=sha256_bytes(response.body), group=group, crawl_delay=delay,
                         bom=(response.body or b"").startswith(b"\xef\xbb\xbf"), _readings=readings)
            if readings.std is None:
                entry["note"] = "this Python's urllib.robotparser stopped with an error on this file: it allows nothing"
            if delay:
                host = host_of(robots_url)
                self.intervals[host] = max(self.intervals.get(host, 0.0), delay)
        elif status in (401, 403, 451):
            entry.update(result="disallow_all")
        elif 400 <= status < 500:
            entry.update(result="none", note="HTTP %d: no robots.txt, no limits" % status)
        else:
            entry.update(result="unreachable", error="HTTP %d" % status)
        return entry

    # -- records --

    def robots_record(self):
        return {origin: {k: v for k, v in entry.items() if not k.startswith("_")} for origin, entry in self.robots.items()}

    def record(self):
        return {"transport": self.transport, "clock": self.clock_kind, "requests": self.requests,
                "max_requests": self.max_requests, "min_interval_seconds": self.min_interval,
                "max_wait_seconds": self.max_wait,
                "intervals": {h: round(s, 3) for h, s in sorted(self.intervals.items())},
                "hosts_stopped": dict(sorted(self.stopped.items())), "address_notes": dict(sorted(self.notes.items())),
                "log": self.log}


class Run:
    """A run folder: run.json (the request, the config used, the steps), candidates.json and one file per step."""

    def __init__(self, folder):
        self.folder = Path(folder)

    def path(self, name):
        return self.folder / name

    def exists(self, name):
        return self.path(name).is_file()

    def load(self, name):
        if not self.exists(name):
            raise VisualError("%s has no %s yet: run the step that makes it first" % (self.folder, name))
        return read_json(self.path(name))

    def save(self, name, data):
        self.folder.mkdir(parents=True, exist_ok=True)
        write_json(self.path(name), data)

    def manifest(self):
        return self.load("run.json")

    def step(self, name, record):
        data = self.manifest()
        data.setdefault("steps", {})[name] = dict(record, time=now())
        self.save("run.json", data)

    def candidates(self):
        return self.load("candidates.json")["candidates"] if self.exists("candidates.json") else []

    def outdate(self, step):
        """Before step runs again: move what the later steps made from the old results into outdated/<time>-<step>/,
        and mark those steps outdated in run.json. Returns the moved names."""
        moved = []
        stamp = "%s-%s" % (datetime.datetime.now().strftime("%Y%m%dT%H%M%S%f"), step)
        target = self.folder / "outdated" / stamp
        number = 1
        while target.exists():
            number += 1
            target = self.folder / "outdated" / ("%s-%d" % (stamp, number))
        for name in DOWNSTREAM.get(step, ()):
            source = self.path(name)
            if source.exists():
                destination = target / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                os.replace(str(source), str(destination))
                moved.append(name)
        if moved and self.exists("run.json"):
            data = self.manifest()
            where = target.relative_to(self.folder).as_posix()
            for name in moved:
                for made_by in STEPS_MADE_BY.get(name, ()):
                    if made_by in data.get("steps", {}):
                        data["steps"][made_by] = dict(data["steps"][made_by], status="outdated", outdated_by=step,
                                                      moved_to=where)
            data.setdefault("outdated", []).append({"time": now(), "by": step, "files": moved, "to": where})
            self.save("run.json", data)
        return moved

    def save_candidates(self, items):
        self.save("candidates.json", {"schema": "visual-candidates/1", "candidates": items})

#!/usr/bin/env python3
"""Validate and select project-scoped writing examples; never mutate the store."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys


STATUSES = {"candidate", "teacher_approved", "author_accepted", "rejected", "retired"}
SPLITS = {"development", "training", "regression", "holdout", "evaluation"}
ELIGIBLE = {"teacher_approved", "author_accepted"}
HELD_OUT = {"holdout", "evaluation"}
REVIEWER_ROLES = {"writer", "teacher", "author"}
# author_return: a teacher's result that the author carried back from outside the host.
REVIEWER_MODES = {"self_check", "independent_agent", "author_return", "human"}
APPLICABILITY = "not_checked_by_script; the reader checks each when/except against the new scene"
LEARNING_START = "<!-- NOVEL_WORKSHOP_LEARNING_START -->"
LEARNING_END = "<!-- NOVEL_WORKSHOP_LEARNING_END -->"


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key: " + key)
        result[key] = value
    return result


def _constant(value):
    raise ValueError("non-finite JSON value: " + value)


def _loads(text):
    return json.loads(text, object_pairs_hook=_pairs, parse_constant=_constant)


def markdown_payload(text):
    """Return the sole learning payload and JSON character span, or reject it.

    The fixed marker block is deliberately stricter than general Markdown. Its
    surrounding text is not parsed or rewritten by the learning-loop writer.
    """
    if text.count(LEARNING_START) != 1 or text.count(LEARNING_END) != 1:
        raise ValueError("Markdown requires exactly one complete learning marker pair")
    start = text.index(LEARNING_START) + len(LEARNING_START)
    end = text.index(LEARNING_END)
    if end < start:
        raise ValueError("Learning markers are reversed")
    block = text[start:end]
    match = re.fullmatch(r"\s*```json[^\S\r\n]*\r?\n(?P<json>.*?)\r?\n```\s*", block, re.DOTALL)
    if match is None:
        raise ValueError("Learning markers must contain one complete JSON fence only")
    payload = _loads(match.group("json"))
    return payload, start + match.start("json"), start + match.end("json")


def load_payload(path):
    """Read the original JSON format or the unique marked Markdown JSON block."""
    text = Path(path).read_bytes().decode("utf-8")
    if Path(path).suffix.lower() in {".md", ".markdown"} or not text.lstrip().startswith("{"):
        return markdown_payload(text)[0]
    return _loads(text)


def digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def validate(payload):
    errors = []
    if not isinstance(payload, dict) or not isinstance(payload.get("data"), dict):
        return ["Expected a project-state object containing data"], {}, {}
    data = payload["data"]
    config = data.get("demonstration_learning", {"enabled": False})
    if not isinstance(config, dict) or type(config.get("enabled")) is not bool:
        errors.append("data.demonstration_learning.enabled must be a boolean")
        config = {"enabled": False}
    cases = data.get("demonstrations", {})
    if not isinstance(cases, dict):
        return errors + ["data.demonstrations must be an object keyed by case id"], {}, config
    for key, case in cases.items():
        prefix = f"case {key}: "
        if not isinstance(case, dict):
            errors.append(prefix + "must be an object")
            continue
        for field in ("id", "project_id", "group_id", "task", "before", "after", "why"):
            if not isinstance(case.get(field), str) or not case[field].strip():
                errors.append(prefix + field + " must be non-empty text")
        if case.get("id") != key:
            errors.append(prefix + "id must match its object key")
        if case.get("status") not in STATUSES:
            errors.append(prefix + "invalid status")
        if case.get("split") not in SPLITS:
            errors.append(prefix + "invalid split")
        for field in ("tags", "decisions", "when", "except"):
            value = case.get(field)
            if not isinstance(value, list) or any(not isinstance(x, str) or not x.strip() for x in value):
                errors.append(prefix + field + " must be an array of non-empty strings")
            elif field in {"decisions", "when"} and not value:
                errors.append(prefix + field + " must not be empty")
        source = case.get("source")
        if not isinstance(source, dict):
            errors.append(prefix + "source must be an object")
        else:
            for field in ("ref", "version", "reviewer", "evidence"):
                if not isinstance(source.get(field), str) or not source[field].strip():
                    errors.append(prefix + "source." + field + " must be non-empty text")
            # Optional provenance written by learn; older and hand-built cases omit it.
            for field, known in (("reviewer_role", REVIEWER_ROLES), ("reviewer_mode", REVIEWER_MODES)):
                if source.get(field) is not None and source[field] not in known:
                    errors.append(prefix + "source." + field + " is not a known value")
        acceptance = case.get("author_acceptance")
        if case.get("status") == "author_accepted":
            if not isinstance(acceptance, dict) or any(
                not isinstance(acceptance.get(field), str) or not acceptance[field].strip()
                for field in ("quote", "ref")
            ):
                errors.append(prefix + "author_accepted requires an author quote and source ref")
        elif acceptance is not None and not isinstance(acceptance, dict):
            errors.append(prefix + "author_acceptance must be null or an object")
        hashes = case.get("hashes")
        for field in ("before", "after"):
            if isinstance(case.get(field), str):
                if not isinstance(hashes, dict) or hashes.get(field) != digest(case[field]):
                    errors.append(prefix + "hashes." + field + " does not match the text")
    return errors, cases, config


def withdrawn(run, review):
    """True when the author's own later words took this whole review back."""
    decisions = run.get("decisions") if isinstance(run.get("decisions"), dict) else {}
    if not review.get("findings"):
        withdrawals = run.get("review_withdrawals")
        return isinstance(withdrawals, dict) and review.get("review_id") in withdrawals
    made = decisions.get(review.get("review_id"))
    return isinstance(made, list) and bool(made) and all(
        isinstance(item, dict) and isinstance(item.get("withdrawal"), dict) for item in made)


def open_author_objections(run, text_sha256):
    """Ids of the author's reviews that reject this text and that the author has not taken back.

    Matched by text, not by draft instance: registering the same words again
    does not answer the author. Only a changed text or the author's own later
    words close one; no host decision does.
    """
    reviews = run.get("reviews") if isinstance(run.get("reviews"), dict) else {}
    order = run.get("review_order") if isinstance(run.get("review_order"), list) else []
    found = []
    for key in order:
        review = reviews.get(key)
        if not (isinstance(review, dict) and isinstance(review.get("reviewer"), dict)):
            continue
        if (review["reviewer"].get("role") == "author" and review.get("verdict") != "pass"
                and review.get("draft_sha256") == text_sha256 and not withdrawn(run, review)):
            found.append(key)
    return found


def _rejects(review):
    return (isinstance(review, dict) and isinstance(review.get("reviewer"), dict)
            and review["reviewer"].get("role") == "author" and review.get("verdict") != "pass")


def earlier_author_objections(run, runs=None):
    """The author's objections to an earlier text of this run that the author
    has not answered on a later one.

    A run's texts form one line: its input, then each draft revised from the one
    before. An objection to one of them, in this run or in another run of the
    project that holds that same text, follows the texts revised from it. Only
    the author's own later words answer it: a passing review by the author on a
    later draft of this run, or the author's acceptance of the current draft.
    A host's or teacher's review does not. Objections to the current text itself
    are open_author_objections and are not listed again here. Ids from another
    run are written run_id/review_id.
    """
    drafts = run.get("drafts") if isinstance(run.get("drafts"), list) else []
    texts = [draft.get("sha256") for draft in drafts if isinstance(draft, dict)]
    if not texts:
        return []
    current = texts[-1]
    acceptance = run.get("author_acceptance")
    if isinstance(acceptance, dict) and acceptance.get("draft_sha256") == current:
        return []
    reviews = run.get("reviews") if isinstance(run.get("reviews"), dict) else {}
    order = [key for key in run.get("review_order", []) if isinstance(reviews.get(key), dict)] \
        if isinstance(run.get("review_order"), list) else []

    def position(review):
        index = review.get("draft_index")
        if type(index) is int:
            return index
        return texts.index(review["draft_sha256"]) if review.get("draft_sha256") in texts else len(texts)

    passes = [position(reviews[key]) for key in order if isinstance(reviews[key].get("reviewer"), dict)
              and reviews[key]["reviewer"].get("role") == "author" and reviews[key].get("verdict") == "pass"]

    def answered(index):
        return any(later > index for later in passes)

    found = [key for key in order if _rejects(reviews[key]) and reviews[key].get("draft_sha256") != current
             and not withdrawn(run, reviews[key]) and not answered(position(reviews[key]))]
    # Texts this run took from another run: its input, and any draft that is also there.
    line = {}
    if isinstance(run.get("input_text"), str):
        line[digest(run["input_text"])] = -1
    for index, text in enumerate(texts):
        line.setdefault(text, index)
    for other_id, other in (runs.items() if isinstance(runs, dict) else ()):
        if (not isinstance(other, dict) or other is run or other_id == run.get("run_id")
                or other.get("project_id") != run.get("project_id")):
            continue
        for text, index in line.items():
            found += [str(other_id) + "/" + key for key in open_author_objections(other, text)
                      if not answered(index)]
    return list(dict.fromkeys(found))


def approval_problems(case, data=None):
    """Mechanical reasons why a recorded approval no longer covers this text.

    Only bindings that the record itself carries are compared: the text hash
    an acceptance or review was bound to, and, when the case names a run kept
    in the same store, what that run records. Nothing here authenticates who
    approved; hand-built cases without such bindings pass as before.
    """
    status = case.get("status")
    if status not in ELIGIBLE:
        return []
    problems = []
    after = case["hashes"].get("after") if isinstance(case.get("hashes"), dict) else None
    source = case["source"] if isinstance(case.get("source"), dict) else {}
    acceptance = case["author_acceptance"] if isinstance(case.get("author_acceptance"), dict) else {}
    if status == "author_accepted" and "draft_sha256" in acceptance and acceptance["draft_sha256"] != after:
        problems.append("author acceptance is bound to another text version; record it again for this text")
    if status == "teacher_approved" and "draft_sha256" in source and source["draft_sha256"] != after:
        problems.append("teacher review is bound to another text version; review this text again")
    data = data if isinstance(data, dict) else {}
    runs = data.get("learning_runs")
    run = runs.get(source.get("run_id")) if isinstance(runs, dict) and isinstance(source.get("run_id"), str) else None
    if isinstance(run, dict):
        # The author's newer objection to this very text stands over any approval of it.
        if open_author_objections(run, after):
            problems.append("the author objected to this text and has not taken it back")
        if status == "author_accepted":
            recorded = run.get("author_acceptance")
            events = data.get("learning_events")
            entry = events.get(acceptance.get("event_id")) if isinstance(events, dict) and isinstance(
                acceptance.get("event_id"), str) else None
            later = (isinstance(entry, dict) and entry.get("op") == "case_accept"
                     and isinstance(entry.get("event"), dict) and entry["event"].get("case_id") == case.get("id")
                     and entry["event"].get("case_sha256") == after)
            if not later and not (isinstance(recorded, dict) and recorded.get("draft_sha256") == after):
                problems.append("its run records no author acceptance of this text")
            seen = acceptance.get("run_review_count")
            order = run.get("review_order") if isinstance(run.get("review_order"), list) else []
            reviews = run.get("reviews") if isinstance(run.get("reviews"), dict) else {}
            if later and type(seen) is int and any(
                    isinstance(reviews.get(key), dict) and isinstance(reviews[key].get("reviewer"), dict)
                    and reviews[key]["reviewer"].get("role") == "author" and reviews[key].get("verdict") != "pass"
                    and reviews[key].get("draft_sha256") == after for key in order[seen:]):
                # Taking that objection back later does not bring the acceptance back.
                problems.append("the author objected to this text after accepting it; ask the author again")
        else:
            reviews = run.get("reviews") if isinstance(run.get("reviews"), dict) else {}
            if not any(isinstance(r, dict) and isinstance(r.get("reviewer"), dict)
                       and r["reviewer"].get("role") == "teacher" and r.get("verdict") == "pass"
                       and r.get("draft_sha256") == after for r in reviews.values()):
                problems.append("its run records no passing teacher review of this text")
            # A teacher's pass does not answer the author's objection to an earlier version.
            if (isinstance(run.get("drafts"), list) and run["drafts"]
                    and isinstance(run["drafts"][-1], dict) and run["drafts"][-1].get("sha256") == after
                    and earlier_author_objections(run, runs)):
                problems.append("the author objected to an earlier version of this text and has not "
                                "answered this one; ask the author")
    return problems


def candidates(cases, project_id, task, tags, excluded, data=None):
    """Return every case passing the mechanical filters, best first, and the
    otherwise matching cases left out because their approval is stale."""
    project_cases = [c for c in cases.values() if c["project_id"] == project_id]
    held = [c for c in project_cases if c["split"] in HELD_OUT or c["group_id"] in excluded]
    blocked_groups = set(excluded) | {c["group_id"] for c in held}
    blocked_text = {c["hashes"][field] for c in project_cases if c["group_id"] in blocked_groups for field in ("before", "after")}
    eligible, stale = [], {}
    for case in project_cases:
        if case["status"] not in ELIGIBLE or case["split"] in HELD_OUT:
            continue
        if case["group_id"] in blocked_groups or case["task"] != task:
            continue
        if any(case["hashes"][field] in blocked_text for field in ("before", "after")):
            continue
        overlap = len(set(case["tags"]) & set(tags))
        if tags and not overlap:
            continue
        problems = approval_problems(case, data)
        if problems:
            stale[case["id"]] = problems
            continue
        eligible.append((case, overlap))
    eligible.sort(key=lambda item: (
        item[0]["status"] != "author_accepted", -item[1], item[0]["id"]
    ))
    return [case for case, _ in eligible], stale


def select(cases, project_id, task, tags, excluded, limit, data=None):
    return candidates(cases, project_id, task, tags, excluded, data)[0][:limit]


def choose(cases, project_id, task, tags, excluded, limit, case_ids=None, data=None):
    """Pick at most `limit` cases: the best ranked, or the named ones.

    Named cases must pass the same filters; an empty list of names picks none.
    Also returns the ids that matched but were not picked, so that no matching
    case stays out of sight, and the stale approvals that were skipped.
    """
    ranked, stale = candidates(cases, project_id, task, tags, excluded, data)
    if case_ids is not None:
        by_id = {case["id"]: case for case in ranked}
        unknown = [key for key in case_ids if key not in by_id]
        if unknown:
            raise ValueError("Not among the approved cases that pass this filter: " + ", ".join(unknown))
        if len(set(case_ids)) != len(case_ids) or len(case_ids) > limit:
            raise ValueError("Name each case once, at most %d in all" % limit)
        picked = [case for case in ranked if case["id"] in set(case_ids)]
    else:
        picked = ranked[:limit]
    chosen = {case["id"] for case in picked}
    return picked, [case["id"] for case in ranked if case["id"] not in chosen], stale


def describe(picked, rest, stale, tags):
    """Shared facts about one selection for every caller's JSON result."""
    result = {"count": len(picked), "not_selected": rest, "eligible_count": len(picked) + len(rest),
              "matched_by": ["project", "task"] + (["tags"] if tags else []),
              "applicability": APPLICABILITY}
    if stale:
        result["skipped_stale_approvals"] = stale
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    check = commands.add_parser("check")
    check.add_argument("store", type=Path)
    for name in ("index", "select"):
        pick = commands.add_parser(name)
        pick.add_argument("store", type=Path)
        pick.add_argument("--project-id", required=True)
        pick.add_argument("--task", required=True)
        pick.add_argument("--tag", action="append", default=[])
        pick.add_argument("--exclude-group", action="append", default=[])
        pick.add_argument("--evaluation", action="store_true")
        # index lists every eligible case (metadata only); select returns at most three.
        pick.add_argument("--limit", type=int, choices=range(1, 4), default=None,
                          help="select only: at most this many cases (1-3, default 3)")
        pick.add_argument("--case-id", action="append", default=[],
                          help="select only: name a listed case instead of taking the best ranked; "
                               "repeatable, at most --limit")
    args = parser.parse_args(argv)
    if args.command in {"index", "select"} and args.evaluation and not args.exclude_group:
        parser.error("--evaluation requires --exclude-group for the current task group")
    try:
        payload = load_payload(args.store)
        errors, cases, config = validate(payload)
        if errors:
            print(json.dumps({"status": "invalid", "errors": errors}, ensure_ascii=False))
            return 2
        if args.command == "check":
            stale = ["case %s: %s" % (key, problem) for key, case in cases.items()
                     for problem in approval_problems(case, payload["data"])]
            if stale:
                # The store stays readable; these cases are simply never selected.
                print(json.dumps({"status": "invalid", "errors": stale,
                                  "scope": "structure_hashes_and_approval_bindings"}, ensure_ascii=False))
                return 2
            result = {"status": "valid", "case_count": len(cases), "enabled": config["enabled"],
                      "scope": "structure_hashes_and_approval_bindings"}
        else:
            owner = payload.get("project_id")
            if owner is not None and owner != args.project_id:
                raise ValueError("Requested project_id differs from the authoritative store")
            if args.command == "index" and (args.limit is not None or args.case_id):
                raise ValueError("index lists every eligible case; --limit and --case-id belong to select")
            if not config["enabled"]:
                selected, rest, stale = [], [], {}
            elif args.command == "index":
                # Metadata only, so every eligible case is listed for the host to judge.
                selected, stale = candidates(cases, args.project_id, args.task, args.tag, args.exclude_group,
                                             payload["data"])
                rest = []
            else:
                selected, rest, stale = choose(cases, args.project_id, args.task, args.tag, args.exclude_group,
                                               args.limit or 3, args.case_id or None, payload["data"])
            facts = describe(selected, rest, stale, args.tag)
            if args.command == "index":
                fields = ("id", "project_id", "group_id", "task", "tags", "status", "split", "when", "except")
                selected = [{**{key: c[key] for key in fields},
                             **{key: c["source"].get(key) for key in ("reviewer_role", "reviewer_mode")}}
                            for c in selected]
            result = {"status": "selected" if config["enabled"] else "disabled", "cases": selected, **facts,
                      "scope": "metadata_only" if args.command == "index" else "examples_for_context_not_story_facts"}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, TypeError) as exc:
        print(json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    sys.exit(main())

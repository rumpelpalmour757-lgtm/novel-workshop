#!/usr/bin/env python3
"""Detail check (r5.44): what an original had and its revision lost, and the report-like forms the revision brought in.

python3 detail_check.py compare ORIGINAL REVISED [--format text|json]
python3 detail_check.py anchors ANCHORS.json [ANCHORS.json ...] --self-test [--format text|json]
python3 detail_check.py anchors ANCHORS.json [ANCHORS.json ...] --prompts DIR
python3 detail_check.py anchors ANCHORS.json [ANCHORS.json ...] --outputs DIR [--format text|json]

compare lists, for the author to decide (references/editing.md, "修订前后对照"):
  - wording the original had and the revision no longer has anywhere (Chinese character pairs, grouped into the
    stretches of each original sentence; wording that only moved is not listed);
  - directional complements that are gone (弹了出来, 亮了起来, 漫了过来 ...);
  - clauses of the form "X是Y的" that are new in the revision, outside dialogue (the report-like judgment sentence:
    码头的路灯是旧式的);
  - position words that are new in the revision (视野正中, 屏幕正中, 右上角 ...);
  - the number of Chinese characters on each side.
It compares letters only: a reworded phrase is listed too, and whether a lost detail mattered is for a person to read.
Nothing is changed and nothing is decided; compare always exits 0 (2 on a usage or file error).

anchors works on writing anchors (references/skill-evaluation.md, "写作对照例"): passages with a text to revise and the
author's approved revision, the details that must survive (keep) and the forms that must go (avoid). --self-test checks
that every approved revision passes and every text to revise that differs from it fails; --prompts writes one request
per anchor for a fresh writer; --outputs checks the writers' revisions (DIR/<id>.txt). A revision fails when a keep item
is missing, an avoid item is left, or it brings in a new "X是Y的" clause or a new position word; lost wording and lost
complements are listed, not failed (the author's own fixes drop some). Exit 0 when all pass, 1 otherwise, 2 on errors.
Read-only, standard library only; it calls no model.
"""
import argparse
import json
from pathlib import Path
import re
import sys

FORMAT = "novel-workshop-detail-check"
ANCHOR_FORMAT = "novel-workshop-writing-anchors"
HAN = r"㐀-䶿一-鿿"
HAN_RUN = re.compile("[" + HAN + "]+")
HAN_CHAR = re.compile("[" + HAN + "]")
# Characters that carry grammar more than content: a pair made only of these is never listed as a lost detail.
FUNCTION = set("的了是着过地得在把被就也都又还很和与及而并但却才再已将这那一个些么吗呢吧啊呀他她它我你们之其所以于为"
               "从向往对给让叫使比跟同至更最太极不没无未有来去上下里中后前子儿啦嘛哦嗯哈呵哎唉便即")
# Particles trimmed off the ends of a listed stretch (negations, places and pronouns stay: they carry meaning).
PARTICLES = set("的了着过地得是在把被就也都又还很和与及而并但却才再已将这那么吗呢吧啊呀们之其所以于为从向往对给让叫使"
                "比跟同至更最太极便即啦嘛哦嗯有")
PRONOUNS = set("他她它我你")  # trimmed off the front only: "他用手" lists as "用手"
COMPLEMENTS = ("起来", "出来", "出去", "进来", "进去", "上来", "上去", "下来", "下去", "回来", "回去", "过来", "过去", "开来")
COMPLEMENT = re.compile("(?:" + "|".join(COMPLEMENTS) + ")")
# "X起来" in the sense "when X-ing, it seems": not a movement, not listed.
NOT_MOVEMENT = {"看起来", "看上去", "听起来", "听上去", "说起来", "算起来", "比起来", "闻起来", "摸起来", "吃起来", "用起来",
                "想起来"}
NOT_VERB = set("的了是着得地不没也都就还又再才便却很")
JUDGMENT = re.compile("^([^是]{1,12})是([^是]{1,8})的$")
POSITION = re.compile("(?:视野|视线|屏幕|画面)的?(?:正中央|正中|中央|中间|中心|边缘|左侧|右侧|上方|下方|左上角|右上角|左下角|右下角)"
                      "|正中央|[左右][上下]角")
SENTENCE_END = re.compile("[。！？!?；;…\n]+")
CLAUSE_SPLIT = re.compile("[，,。！？!?；;：:、…\n]+")
QUOTE = re.compile("“[^”]*”|「[^」]*」|『[^』]*』|\"[^\"]*\"")
NOTE = "只比字面：换了说法的也会列出来，删掉的东西有没有作用要人读。留不留由作者定，不按清单自动改回，也不为清单变短少改。"


class CheckError(Exception):
    pass


def read_text(path):
    try:
        data = Path(path).read_bytes()
    except OSError as exc:
        raise CheckError("cannot read %s: %s" % (path, exc)) from exc
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise CheckError("%s is not UTF-8: %s" % (path, exc)) from exc
    return text.replace("\r\n", "\n").replace("\r", "\n")


def han_count(text):
    return len(HAN_CHAR.findall(text))


def sentences(text):
    """(start, end, text) of each sentence, the end mark included."""
    out, start = [], 0
    for m in SENTENCE_END.finditer(text):
        if text[start:m.end()].strip():
            out.append((start, m.end(), text[start:m.end()]))
        start = m.end()
    if text[start:].strip():
        out.append((start, len(text), text[start:]))
    return out


def bigrams(text):
    pairs = set()
    for run in HAN_RUN.findall(text):
        pairs.update(run[i:i + 2] for i in range(len(run) - 1))
    return pairs


def content_pair(pair):
    return not (pair[0] in FUNCTION and pair[1] in FUNCTION)


def complements(text):
    """(key, form, position) of each directional complement: key is verb + complement (了 dropped)."""
    found = []
    for m in COMPLEMENT.finditer(text):
        p = m.start()
        q = p - 1
        if q >= 0 and text[q] == "了":
            q -= 1
        if q < 0 or not HAN_CHAR.match(text[q]) or text[q] in NOT_VERB:
            continue
        key = text[q] + m.group()
        if key in NOT_MOVEMENT:
            continue
        found.append((key, text[q:m.end()], p))
    return found


def has_complement(text, key):
    return re.search(re.escape(key[0]) + "了?" + re.escape(key[1:]), text) is not None


def outside_quotes(text):
    return QUOTE.sub(lambda m: "\n" * len(m.group()), text)


def judgment_clauses(text):
    return [c.strip() for c in CLAUSE_SPLIT.split(outside_quotes(text)) if JUDGMENT.match(c.strip())]


def sentence_of(spans, pos):
    for k, (start, end, _) in enumerate(spans, 1):
        if start <= pos < end:
            return k
    return len(spans)


def short(text, limit=60):
    text = text.strip().replace("\n", " ")
    return text if len(text) <= limit else text[:limit - 1] + "…"


def lost_wording(original, revised, lost_forms):
    kept = bigrams(revised)
    rows = []
    for k, (start, end, sent) in enumerate(sentences(original), 1):
        spans = []
        for m in HAN_RUN.finditer(sent):
            run = m.group()
            lost = [i for i in range(len(run) - 1) if content_pair(run[i:i + 2]) and run[i:i + 2] not in kept]
            groups, cur = [], []
            for i in lost:
                if cur and i != cur[-1] + 1:
                    groups.append(cur)
                    cur = []
                cur.append(i)
            if cur:
                groups.append(cur)
            for g in groups:
                a, b = g[0], g[-1] + 1  # characters a..b of the run
                if a > 0 and run[a - 1:a + 1] in kept:
                    a += 1  # its first character still stands in a kept pair: it only lost its neighbour
                if b < len(run) - 1 and run[b:b + 2] in kept:
                    b -= 1
                piece = run[a:b + 1]
                for form in lost_forms:
                    piece = piece.replace(form, "　")
                for part in piece.split("　"):
                    while part and (part[0] in PARTICLES or part[0] in PRONOUNS):
                        part = part[1:]
                    while part and part[-1] in PARTICLES:
                        part = part[:-1]
                    if len(part) >= 2 and any(ch not in FUNCTION for ch in part) and part not in revised and part not in spans:
                        spans.append(part)
        if spans:
            rows.append({"sentence": k, "context": short(sent), "spans": spans})
    return rows


def compare(original, revised):
    orig_sent, rev_sent = sentences(original), sentences(revised)
    lost_comp = []
    for key, form, pos in complements(original):
        if not has_complement(revised, key) and form not in [c["form"] for c in lost_comp]:
            lost_comp.append({"form": form, "key": key, "sentence": sentence_of(orig_sent, pos),
                              "context": short(orig_sent[sentence_of(orig_sent, pos) - 1][2]) if orig_sent else ""})
    lost_forms = sorted({c["form"] for c in lost_comp} | {c["key"] for c in lost_comp}, key=len, reverse=True)
    wording = lost_wording(original, revised, lost_forms)
    before_clauses = set(judgment_clauses(original))
    new_judgments = []
    for clause in judgment_clauses(revised):
        if clause not in before_clauses and clause not in [j["clause"] for j in new_judgments]:
            pos = revised.find(clause)
            new_judgments.append({"clause": clause, "sentence": sentence_of(rev_sent, pos)})
    new_positions = []
    for m in POSITION.finditer(outside_quotes(revised)):
        text = m.group()
        if revised.count(text) > original.count(text) and text not in [p["text"] for p in new_positions]:
            k = sentence_of(rev_sent, m.start())
            new_positions.append({"text": text, "sentence": k, "context": short(rev_sent[k - 1][2]) if rev_sent else ""})
    han = {"original": han_count(original), "revised": han_count(revised)}
    listed = bool(wording or lost_comp or new_judgments or new_positions)
    return {"format": FORMAT, "format_version": 1, "status": "LISTED" if listed else "NOTHING_LISTED", "han": han,
            "lost_wording": wording, "lost_complements": lost_comp, "new_judgments": new_judgments,
            "new_positions": new_positions, "note": NOTE}


def compare_text(report, original_label="原稿", revised_label="修订稿"):
    han = report["han"]
    diff = han["revised"] - han["original"]
    pct = (" %+d%%" % round(diff * 100 / han["original"])) if han["original"] else ""
    change = "一样多" if diff == 0 else "%s %d 字%s" % ("多" if diff > 0 else "少", abs(diff), pct)
    lines = ["细节保留核对（%s → %s）" % (original_label, revised_label),
             "- 汉字：%s %d 字，%s %d 字（%s）" % (original_label, han["original"], revised_label, han["revised"], change)]
    lines.append("- %s里有、%s里没了的说法：%d 句" % (original_label, revised_label, len(report["lost_wording"])))
    for row in report["lost_wording"]:
        lines.append("  第 %d 句「%s」：没了%s" % (row["sentence"], row["context"], "、".join("“%s”" % s for s in row["spans"])))
    lines.append("- 没了的动态补语：%d 处" % len(report["lost_complements"]))
    for row in report["lost_complements"]:
        lines.append("  第 %d 句「%s」：“%s”" % (row["sentence"], row["context"], row["form"]))
    lines.append("- 新出现的“X是Y的”判断句（台词外）：%d 处" % len(report["new_judgments"]))
    for row in report["new_judgments"]:
        lines.append("  %s第 %d 句：“%s”" % (revised_label, row["sentence"], row["clause"]))
    lines.append("- 新出现的坐标说法：%d 处" % len(report["new_positions"]))
    for row in report["new_positions"]:
        lines.append("  %s第 %d 句「%s」：“%s”" % (revised_label, row["sentence"], row["context"], row["text"]))
    lines.append(report["note"])
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------- anchors

def load_anchors(paths):
    anchors, seen = [], set()
    for path in paths:
        try:
            data = json.loads(read_text(path))
        except json.JSONDecodeError as exc:
            raise CheckError("%s is not readable JSON: %s" % (path, exc)) from exc
        problems = anchor_problems(data)
        if problems:
            raise CheckError("%s has problems: %s" % (path, "; ".join(problems[:5])))
        for a in data["anchors"]:
            if a["id"] in seen:
                raise CheckError("anchor id used twice: " + a["id"])
            seen.add(a["id"])
            anchors.append(dict(a, task=a.get("task") or data["task"], file=str(path)))
    if not anchors:
        raise CheckError("no anchors")
    return anchors


def anchor_problems(data):
    if not isinstance(data, dict) or data.get("format") != ANCHOR_FORMAT:
        return ["format must be " + ANCHOR_FORMAT]
    problems = []
    if data.get("format_version") != 1:
        problems.append("format_version must be 1")
    if not (isinstance(data.get("task"), str) and data["task"].strip()):
        problems.append("task (the request the writer gets) must be text")
    items = data.get("anchors")
    if not isinstance(items, list) or not items:
        return problems + ["anchors must be a non-empty list"]
    fields = {"id", "source", "task", "before", "approved_after", "keep", "avoid", "why"}
    for n, a in enumerate(items):
        where = "anchors[%d]" % n
        if not isinstance(a, dict):
            problems.append(where + " is not an object")
            continue
        where = a.get("id") if isinstance(a.get("id"), str) else where
        extra = sorted(set(a) - fields)
        if extra:
            problems.append(where + ": unknown fields " + ", ".join(extra))
        for f in ("id", "source", "before", "approved_after", "why"):
            if not (isinstance(a.get(f), str) and a[f].strip()):
                problems.append(where + ": " + f + " must be text")
        if "task" in a and not (isinstance(a["task"], str) and a["task"].strip()):
            problems.append(where + ": task, when given, must be text")
        for f in ("keep", "avoid"):
            if not (isinstance(a.get(f), list) and all(isinstance(x, str) and x.strip() for x in a[f])):
                problems.append(where + ": " + f + " must be a list of phrases")
        if problems:
            continue
        if not a["keep"]:
            problems.append(where + ": keep is empty (what must survive?)")
        for x in a["keep"]:
            if x not in a["before"] or x not in a["approved_after"]:
                problems.append(where + ": keep item %s must stand in before and in approved_after" % x)
        for x in a["avoid"]:
            if x in a["approved_after"]:
                problems.append(where + ": avoid item %s stands in the approved revision" % x)
    return problems


def check_candidate(anchor, text):
    listing = compare(anchor["before"], text)
    missing = [x for x in anchor["keep"] if x not in text]
    left = [x for x in anchor["avoid"] if x in text]
    reasons = []
    if missing:
        reasons.append("少了：" + "、".join(missing))
    if left:
        reasons.append("还留着：" + "、".join(left))
    if listing["new_judgments"]:
        reasons.append("新出现判断句：" + "、".join(j["clause"] for j in listing["new_judgments"]))
    if listing["new_positions"]:
        reasons.append("新出现坐标：" + "、".join(p["text"] for p in listing["new_positions"]))
    return {"id": anchor["id"], "status": "FAIL" if reasons else "PASS", "reasons": reasons, "missing_keep": missing,
            "avoid_left": left, "listing": listing}


def prompt_text(anchor):
    return ("作者发来一段文字，要你照小说写作工坊的方法改。\n\n作者的话：%s\n\n要改的文字：\n%s\n\n只交改好的正文，不加说明。\n"
            % (anchor["task"], anchor["before"]))


def anchors_text(results, title):
    lines = [title]
    for r in results:
        if r["status"] == "MISSING":
            lines.append("- %s：没有输出（%s），不算通过" % (r["id"], r.get("path", "")))
            continue
        lines.append("- %s：%s%s" % (r["id"], "通过" if r["status"] == "PASS" else "不通过", "；" + "；".join(r["reasons"]) if r["reasons"] else ""))
        info = []
        listing = r.get("listing") or {}
        if listing.get("lost_wording"):
            info.append("没了的说法：" + "、".join(s for row in listing["lost_wording"] for s in row["spans"]))
        if listing.get("lost_complements"):
            info.append("没了的动态补语：" + "、".join(c["form"] for c in listing["lost_complements"]))
        if info:
            lines.append("  （列出，不算不通过）" + "；".join(info))
    passed = sum(r["status"] == "PASS" for r in results)
    lines.append("通过 %d 个，共 %d 个。" % (passed, len(results)))
    return "\n".join(lines) + "\n"


def utf8_stdio():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = parser.add_subparsers(dest="command", required=True)
    c = sub.add_parser("compare", help="list what the revision lost and what report-like forms it brought in")
    c.add_argument("original", type=Path)
    c.add_argument("revised", type=Path)
    c.add_argument("--format", choices=("text", "json"), default="text")
    a = sub.add_parser("anchors", help="writing anchors: self-test, write the requests, or check the revisions")
    a.add_argument("files", type=Path, nargs="+")
    mode = a.add_mutually_exclusive_group(required=True)
    mode.add_argument("--self-test", action="store_true")
    mode.add_argument("--prompts", type=Path)
    mode.add_argument("--outputs", type=Path)
    a.add_argument("--format", choices=("text", "json"), default="text")
    args = parser.parse_args()
    try:
        if args.command == "compare":
            report = compare(read_text(args.original), read_text(args.revised))
            print(json.dumps(report, ensure_ascii=False, indent=1) if args.format == "json" else compare_text(report), end="\n" if args.format == "json" else "")
            return 0
        anchors = load_anchors(args.files)
        if args.prompts:
            args.prompts.mkdir(parents=True, exist_ok=True)
            for anchor in anchors:
                (args.prompts / (anchor["id"] + ".prompt.txt")).write_bytes(prompt_text(anchor).encode("utf-8"))
            print("wrote %d requests to %s" % (len(anchors), args.prompts))
            return 0
        results = []
        if args.self_test:
            for anchor in anchors:
                approved = check_candidate(anchor, anchor["approved_after"])
                approved["id"] = anchor["id"] + " 认可的改法"
                results.append(approved)
                if anchor["before"] != anchor["approved_after"]:
                    before = check_candidate(anchor, anchor["before"])
                    before["id"] = anchor["id"] + " 待改的原文"
                    before["status"] = "PASS" if before["status"] == "FAIL" else "FAIL"
                    before["reasons"] = (["应当不通过，实际也不通过：" + "；".join(before["reasons"])] if before["status"] == "PASS"
                                         else ["待改的原文本该不通过，却通过了：keep、avoid 没有写出它的毛病"])
                    results.append(before)
            title = "写作对照例自检（认可的改法要通过，待改的原文要不通过）"
        else:
            for anchor in anchors:
                path = args.outputs / (anchor["id"] + ".txt")
                if not path.is_file():
                    results.append({"id": anchor["id"], "status": "MISSING", "reasons": ["没有输出"], "path": str(path)})
                    continue
                results.append(check_candidate(anchor, read_text(path)))
            title = "写作对照例（%s）" % args.outputs
        if args.format == "json":
            print(json.dumps({"format": FORMAT + "-anchors", "format_version": 1, "results": results}, ensure_ascii=False, indent=1))
        else:
            print(anchors_text(results, title), end="")
        return 0 if all(r["status"] == "PASS" for r in results) else 1
    except CheckError as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""r5.59 wrap-up: small notes the author agreed to, and a few corrections the maker decided after the review.

What is pinned here and why:

- Quotes that are only punctuation (execution.md). The author agreed to change the explanation page only; the
  delivery gate script stays as it is. A review issue quoted as "——" can be found in every version and points at no
  one place; when the PASS is checked, any keep or change record that touches a dash counts as having handled it
  (the gate puts the new words of a change in the same list as the quote of a keep). `PunctuationOnlyQuotes` replays
  that on three new lines, once with a keep and once with a change: with the issue quoted as "——" the gate takes the
  PASS, quoted with the words around the dash it refuses it with ISSUE_UNRESOLVED. That is what the page now says, at
  the `record` list and in the paragraph on outside opinions. The gate does not check this; the page says so. The
  first wording of the paragraph named only keep records; the review before delivery found that a change does the
  same, and the page now says "保留或改写记录" (r5.59).
- Several review lanes (adversarial-review.md): "not handed over" is not "cannot read"; a lane that did not come back
  is run again alone, on the same version, and the lanes that did come back are kept; the report says how each lane
  was started, which model was asked for and which it reported, which version it read and what else it could read.
- A withdrawn judgement card (editorial-judgment.md, "状态怎么走"): it is not remade under a new number, and it may
  be raised again with new evidence from another chapter or scene, the date and the author's words of the withdrawal
  first, as step 3 of "从一次纠错提炼规则" does for an induction the author struck out. The sentence sits in the
  "停用" item, outside the locked "边界" section.
- Anchor D02 (dialogue-scene-anchors.json) keeps the two lines its first version left out ("几个了？" and "车六点走。").
  The anchor is still new material whose wording the author has not read.
- `after_by` on the demonstration memory page (demonstration-learning.md): demonstration_memory.py takes it as an
  optional source field and `index` lists it where a case has it; the page said so only in learning-loop.md until the
  review before delivery, and now says it in the `source` row and where it says what `index` returns.

Elsewhere: the verdict packets in test_r559_verdict_packets.py; the registry entries of the two locked sections r5.59
changed in test_r559_maintenance.py; the stage-6 and still-to-the-teacher walk-throughs in test_r559_self_correction.py;
`after_by` in skills/novel-workshop/tests/test_demonstration_memory.py; the card-threshold sentences in
test_r559_technique_library.py. These tests check wording and what the scripts accept; they do not show that reviews
or revisions get better. Every passage below is newly written.
"""

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILLS = ROOT / "skills"
SKILL = SKILLS / "novel-workshop"
REFS = SKILL / "references"
DARWIN = SKILLS / "darwin-novel-workshop"


def read(path):
    return Path(path).read_text(encoding="utf-8")


def write(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.encode("utf-8"))
    return path


def section(text, heading):
    """From the heading line to the next heading of the same or a higher level."""
    level = heading.split(" ", 1)[0]
    start = text.index("\n" + heading + "\n") + 1
    rest = text[start + len(heading) + 1:]
    stop = re.search(r"(?m)^#{1,%d} " % len(level), rest)
    return text[start:start + len(heading) + 1 + (stop.start() if stop else len(rest))]


# ------------------------------------------------------------------ quotes that are only punctuation
LINES = "老周把灯放在窗台上——灯芯还在跳。\n“你明天自己敲一遍。”他说。\n阿桂没接话，只把锤子递了过去——递得很慢。\n"


class PunctuationOnlyQuotes(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.dir = Path(self.temp.name)
        write(self.dir / "candidate.md", LINES)
        write(self.dir / "checks.json", json.dumps({"checks": [{"id": "keep-name", "type": "contains", "text": "老周"}],
                                                    "candidate": "candidate.md"}, ensure_ascii=False))

    def guard(self, *args):
        proc = subprocess.run([sys.executable, "-I", "-B", str(SKILL / "scripts" / "workflow_guard.py"), *args],
                              cwd=self.dir, capture_output=True, text=True, encoding="utf-8")
        return proc.returncode, proc.stdout + proc.stderr

    def review(self, name, verdict, issues, decisions=None, text=LINES):
        value = {"schema": "editorial-review/2", "verdict": verdict,
                 "candidate_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                 "reviewer": {"mode": "self_check", "label": "同一模型在本对话中自查"},
                 "checked_against": ["教师意见：第三行的破折号该改成逗号"], "inputs_read": [],
                 "evidence": [{"quote": "你明天自己敲一遍", "in": "candidate"}], "issues": issues,
                 "machine_dispositions": [], "counter_evidence": "核对了教师看的是这一版", "limits": "只看了这三行"}
        if decisions is not None:
            value["expression"] = {"scope": "chapter", "segments": [
                {"from": text[:6], "to": "递得很慢。", "note": "三行逐句读过，第一行的破折号是灯芯跳的停顿"}],
                "decisions": decisions}
        write(self.dir / name, json.dumps(value, ensure_ascii=False))
        return name

    def run_with(self, quote, revised=None, decisions=None):
        """NEEDS_REVISION with the teacher's point as an issue, a revision reserved, the text left as it was, then a
        PASS whose only keep record is about the first line. With `revised`, the first line is reworded instead and
        `decisions` record that."""
        self.assertEqual(self.guard("start", "run.json", "--task-id", "t", "--spec", "checks.json")[0], 0)
        issue = {"quote": quote, "in": "candidate", "expected": "第三行“递了过去”后面的破折号改成逗号",
                 "impact": "教师意见（作者转来），标点，拟采纳"}
        code, out = self.guard("record", "run.json", "--event-id", "v0", "--review",
                               self.review("review-0.json", "NEEDS_REVISION", [issue]))
        self.assertEqual(code, 0, out)
        self.assertEqual(self.guard("reserve", "run.json", "--event-id", "r1")[0], 0)
        keep = {"decision": "keep", "quote": "老周把灯放在窗台上——灯芯还在跳。", "judgment": "破折号带出灯芯跳的那一下",
                "reason": "换成逗号就少了放下灯以后停住看的那一拍"}
        if revised is not None:
            write(self.dir / "candidate.md", revised)
        return self.guard("record", "run.json", "--event-id", "v1", "--review",
                          self.review("review-1.json", "PASS", [], decisions or [keep], text=revised or LINES))

    # r5.59 review: the new words of a change count like the quote of a keep. The first line is reworded and its new
    # words run up to its dash; the third line's dash is neither changed nor kept.
    REVISED = LINES.replace("老周把灯放在窗台上", "老周把灯搁在窗台上")
    CHANGE = {"decision": "change", "before": "老周把灯放在窗台上", "after": "老周把灯搁在窗台上——",
              "judgment": "“放”换成“搁”", "reason": "搁像随手一放，和后面停住看灯芯接得上"}

    def test_a_change_that_touches_a_dash_also_takes_it_as_handled(self):
        code, out = self.run_with("——", self.REVISED, [self.CHANGE])
        self.assertEqual(code, 0, out)
        self.assertIn("EDITORIAL=PASS[self_check]", self.guard("status", "run.json", "--summary")[1])

    def test_with_its_words_the_dash_is_still_open_after_that_change(self):
        code, out = self.run_with("递了过去——递得很慢", self.REVISED, [self.CHANGE])
        self.assertNotEqual(code, 0)
        self.assertIn("ISSUE_UNRESOLVED", out)

    def test_a_dash_alone_is_taken_as_handled(self):
        # what the page warns about: the third line's dash was neither changed nor kept, and the gate takes the PASS
        code, out = self.run_with("——")
        self.assertEqual(code, 0, out)
        self.assertIn("EDITORIAL=PASS[self_check]", self.guard("status", "run.json", "--summary")[1])

    def test_the_dash_with_its_words_is_still_open(self):
        code, out = self.run_with("递了过去——递得很慢")
        self.assertNotEqual(code, 0)
        self.assertIn("ISSUE_UNRESOLVED", out)
        self.assertIn("递了过去——递得很慢", out)

    def test_the_page_says_so(self):
        text = read(REFS / "execution.md")
        listed = next(line for line in text.splitlines() if line.startswith("- `evidence` 和每条 `issues` 的 `quote`"))
        self.assertTrue(listed.endswith(
            "问题的 `quote` 要连同前后的字一起引，不能只引标点：只有标点的引句（比如“——”“。”）在哪一版里都找得到，指不出是哪一处，"
            "查标点的引成“递了过去——递得很慢”这样；交付门不查这一条，只有标点的也照收，靠记的人照做（r5.59）。"), listed)
        outside = next(line for line in text.splitlines() if line.startswith("**外部意见的记录（r5.14）。**"))
        # r5.59 review: "保留记录" became "保留或改写记录"; a change touching the same mark counts too (tests above)
        self.assertIn("不借教师的名义（r5.53）。教师说的是标点的，`quote` 连同那个标点前后的字一起引；只引一个标点，交付门照收，"
                      "可后面核对时，随便哪一条碰到同一个标点的保留或改写记录，都会把它算成处理过，核不出是哪一处改了、哪一处留了（r5.59）。",
                      outside)
        self.assertNotIn("碰到同一个标点的保留记录都会", text)
        # the gate is not changed for this, and the page does not say it refuses such a quote
        self.assertNotIn("只有标点的引句（比如“——”“。”）在哪一版里都找得到，指不出是哪一处，`record` 报", text)


# ------------------------------------------------------------------ several review lanes
class ReviewLanes(unittest.TestCase):
    def test_the_three_sentences(self):
        text = read(REFS / "adversarial-review.md")
        manner = section(text, "## 选择并如实说明执行方式")
        paragraphs = [p for p in manner.split("\n\n") if p.strip()]
        self.assertTrue(paragraphs[-3].startswith("以当前宿主暴露的能力为准"), paragraphs[-3])
        self.assertEqual(paragraphs[-2], (
            "审读代理自己能读文件的，“不传”不等于“读不到”：项目里的工作记录、别的审读者的结论、学习记录里的教师回传、匿名对照的映射，"
            "它都可能自己翻到。宿主做得到的，只把这一次要看的材料放进一个只有这些材料的新文件夹交给它，或者不给它读文件的工具；"
            "做不到的，在报告里照实写它还能读到哪些别的记录，不写成“没看过”（r5.59）。"))
        self.assertEqual(paragraphs[-1].rstrip(), (
            "有一路审读没交回（出错、超时、中途被停）的，只补这一路，用同一版稿子；已经交回、稿子也没变的几路照用，不为了换一个结论重跑。"
            "补跑要再调用一次，超出这一次授权的先问作者。补不了的照上表记“有限审读”，补做自查的单独标明。稿子改过了，几路都要重审，"
            "旧的结论不套到新稿上（r5.59）。"))
        template = section(text, "## 报告模板")
        self.assertIn("审查范围、版本与方式：单模型自查／实际多代理；已完成的视角；每一路怎么起的（子代理、另起的会话）、请求的模型和"
                      "它自己报的模型（拿不到写未知）、看的是哪一版（哈希前几位）、它还能读到哪些别的记录\n", template)
        # the rest of the page is as it was: the table row for a failed lane and the first step of the reading
        self.assertIn("| 部分代理失败或材料不足 | 有限审读 | 列已完成与缺失视角，补做自查时单独标明 |", text)
        self.assertIn("采用独立代理时，尽量不传起草者的自我辩护、预期裁决或其他审稿者结论。", text)

    def test_no_product_is_named(self):
        # the new sentences name no product and no command line; what a host can do is said in general words
        added = [line for line in read(REFS / "adversarial-review.md").splitlines() if "r5.59" in line]
        added.append(next(line for line in read(REFS / "adversarial-review.md").splitlines()
                          if line.startswith("审查范围、版本与方式：")))
        self.assertEqual(len(added), 3)
        for name in ("Claude", "claude", "BJM", "Gemini", "--tools", "TemporaryDirectory"):
            for line in added:
                self.assertNotIn(name, line)


# ------------------------------------------------------------------ a withdrawn judgement card
class WithdrawnCards(unittest.TestCase):
    AGAIN = ("有了停用以后新出现的、来自别的章或别的场的证据，可以再提，照[作者偏好](author-preferences.md)“从一次纠错提炼规则”"
             "第 3 步那样，把上次停用的日期和作者原话放在最前面。")

    def test_it_may_be_raised_again_on_new_evidence(self):
        text = read(REFS / "editorial-judgment.md")
        states = section(text, "### 状态怎么走")
        stop = next(line for line in states.splitlines() if line.startswith("- **停用**："))
        self.assertTrue(stop.endswith("作者撤回而停用的卡，不换个编号重做同一个判断（r5.59）。" + self.AGAIN), stop)
        self.assertEqual(text.count("有了停用以后新出现的"), 1)
        # not in the locked "边界" section, and step 3 it points to says the same for a struck-out induction
        self.assertNotIn("有了停用以后新出现的", section(text, "## 边界"))
        rules = section(read(REFS / "author-preferences.md"), "### 从一次纠错提炼规则")
        self.assertIn("要再提，必须有划掉以后新出现的、来自别的章或别的场的证据；再提时，把上次划掉的日期和原话放在最前面。", rules)


# ------------------------------------------------------------------ after_by on the memory page
class AfterByOnTheMemoryPage(unittest.TestCase):
    def test_the_page_names_it_where_the_script_takes_it(self):
        text = read(REFS / "demonstration-learning.md")
        row = next(line for line in text.splitlines() if line.startswith("| `source` |"))
        self.assertIn("还可能带 `after_by`（`author` 或 `writer`，改后文字是谁写的，宿主照实声明，脚本认证不了；r5.59）", row)
        listed = next(line for line in text.splitlines() if line.startswith("`check` 校验结构、内容哈希"))
        self.assertIn("适用条件、例外和评审方式（有 `after_by` 的连同它），不返回原稿", listed)
        # the two values on the page are the ones the script knows
        spec = importlib.util.spec_from_file_location("r559_closing_memory", SKILL / "scripts" / "demonstration_memory.py")
        memory = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(memory)
        self.assertEqual(memory.AFTER_BY, {"author", "writer"})


# ------------------------------------------------------------------ anchor D02
class AnchorD02(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        data = json.loads(read(DARWIN / "assets" / "dialogue-scene-anchors.json"))
        cls.anchor = dict(next(a for a in data["anchors"] if a["id"] == "D02"), task=data["task"])
        spec = importlib.util.spec_from_file_location("r559_closing_detail_check", SKILL / "scripts" / "detail_check.py")
        cls.detail = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.detail)

    def test_every_line_of_the_exchange_is_kept(self):
        self.assertEqual(self.anchor["keep"], ["“几个了？”", "“六十二。”", "“底下那层别压。”", "“知道。”", "“车六点走。”", "“够。”",
                                               "码到板车上", "白粉"])
        lines = [line for line in self.anchor["before"].splitlines() if line.startswith("“")]
        self.assertEqual([line for line in lines if line not in self.anchor["keep"]], [])
        self.assertEqual(self.anchor["source"], "工坊新编，措辞作者还没看过")

    def test_the_two_lines_cannot_be_filled_in(self):
        before = self.anchor["before"]
        asked = before.replace("“几个了？”", "“现在一共几个了啊？”")
        self.assertEqual(self.detail.check_candidate(self.anchor, asked)["missing_keep"], ["“几个了？”"])
        told = before.replace("“车六点走。”", "“车六点就要走了，咱们抓紧点吧。”")
        self.assertEqual(self.detail.check_candidate(self.anchor, told)["missing_keep"], ["“车六点走。”"])
        self.assertEqual(self.detail.check_candidate(self.anchor, before)["status"], "PASS")


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""把底座、总控要点、本书设定和本次引擎编成一份 Markdown 提示词，贴进任何AI都能用。

用法：
  python scripts/export_prompt.py 21 02 50 --book 06 -o 第012章规范.md
  python scripts/export_prompt.py --recipe 寒门开局 -o 寒门开局.md
  python scripts/export_prompt.py 21 02 50 --profile ../本书设定.yaml -o 规范.md
  python scripts/export_prompt.py --profile ../本书设定.yaml --volume 2 -o 第二卷规范.md
  python scripts/export_prompt.py --catalog -o 选引擎.md   # 底座+总控+全部引擎目录，让AI帮你选引擎
  python scripts/export_prompt.py --all                    # 重新生成 prompts/ 下的现成提示词
不加 -o 就打印到屏幕。组合有问题时不导出，加 --force 照样导出。只用标准库；--profile 需要 PyYAML。
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (CHECKLIST, CORE, E, G, R, ROOT, SLOTS, SLOT_KEYS, check, expand_recipe,  # noqa: E402
                    expand_volume, label, load_profile, norm)

LABEL = {
    "aesthetic": "美学", "tone": "基调", "daily": "日常", "combat": "战斗",
    "world_scale": "世界比例尺", "principle": "原则", "anchors": "锚点",
    "biomechanics": "生物力学", "organs": "器官", "heart": "心脏", "lungs": "肺",
    "bones_and_tendons": "骨骼与筋腱", "blood_qi": "气血",
    "physics": "物理", "velocity": "速度", "rule": "规则", "techniques": "手法",
    "impact_chain": "打击链", "steps": "四步", "camera": "镜头", "bullet_time": "升格镜头",
    "trigger": "触发", "syntax": "句法", "frame_drop_burst": "抽帧爆发", "example": "示例",
    "paragraphs": "段落", "linter": "自检", "lexicon": "术语", "ai_ese": "AI腔",
    "when": "何时", "sentence": "句子", "focus": "笔墨", "leak": "外泄",
    "scope": "作用域", "hard_lock": "身份锁", "priority": "优先级", "absolute": "始终生效",
    "numbers": "数字", "growth": "成长", "epiphany": "顿悟", "costs": "代价",
    "physical_feedback": "物理反馈", "science": "科学名词", "power_scale": "战力刻度",
    "human": "人（品）", "beast": "兽（阶）", "item": "物品", "rating": "评级", "guoshu_map": "国术对照",
    "firearms": "火器分档", "institutions": "机构", "law_shell": "执法依据", "closing": "收尾",
}
TERMS = [   # 文件里的键名换成提示词里的叫法
    ("见router.yaml的global_rules.lexicon，始终生效", "见下文「术语」，始终生效"),
    ("与router的pacing.爆发期一致", "与总控的节奏·爆发期一致"),
    ("引擎的bans只在该引擎被加载时生效", "引擎的「本引擎禁止」只在该引擎加载时生效"),
    ("L1引擎lock里的条目全书生效", "L1引擎的身份锁全书生效"),
    ("global_rules与lexicon.ban始终生效", "全局口径与术语禁用表始终生效"),
    ("按router的firearms分档", "按总控的「火器分档」"),
    ("分档见router的firearms", "分档见总控的「火器分档」"),
]
HOW = ("用法：整份放在对话最前面（或系统提示词、自定义指令里），再给出本章大纲、续写位置或要改的正文。"
       "写正文时照做，不在正文里解释用了哪些规则。")
LAYERS = ("引擎分层：L0底座（常驻）、L1主角模板（开书锁定）、L2剧情舞台（按卷）、L3场面模块（按场）、L4叙事滤镜（按章）。"
          "每次最多3个引擎全文，一槽一个：槽1人物底色、槽2战斗物理、槽3副本规则。")


def render(obj, chosen, depth=0):
    """dict、list 转成 Markdown 列表；overrides 只保留本次用到的引擎。"""
    pad, out = "  " * depth, []
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k == "overrides":
                out += [f"{pad}- **覆盖（{label(n)}）**：{t}" for n, t in v.items() if n in chosen]
            elif isinstance(v, (dict, list)):
                out.append(f"{pad}- **{LABEL.get(k, k)}**")
                out += render(v, chosen, depth + 1)
            else:
                out.append(f"{pad}- **{LABEL.get(k, k)}**：{v}")
    elif isinstance(obj, list):
        for it in obj:
            out += render(it, chosen, depth) if isinstance(it, (dict, list)) else [f"{pad}- {it}"]
    return out


def sec_core(chosen):
    core = {k: v for k, v in CORE.items() if k not in ("id", "num", "name", "layer", "version")}
    return ["## 一、底座（每次都守）", "", f"**{CORE['name']}**", ""] + render(core, chosen) + [""]


def sec_lexicon(chosen, prof):
    lex, scoped = G["lexicon"], {}
    for num, words in lex["scoped"].items():
        for w in words:
            scoped.setdefault(w, set()).add(num)
    ok = [w for w, ns in scoped.items() if ns & chosen]
    allow = set(ok) | set(prof.get("extra_allow", []))
    out = [f"- **禁用**（任何时候都不用）：{'、'.join(w for w in lex['ban'] if w not in allow)}",
           "- **替换**：" + "；".join(f"{k}→{v}" for k, v in lex["replace"].items() if k not in allow)]
    if ok:
        out.append(f"- **本次可用的限定词**：{'、'.join(ok)}")
    rest = [w for w in scoped if w not in allow and w not in lex["ban"]]
    if rest:
        out.append(f"- **本次不用的限定词**（属于没加载的引擎）：{'、'.join(rest)}")
    out.append(f"- **转场禁用**：{'、'.join(G.get('structure_bans', []))}——不拿来水字数转场")
    if prof.get("extra_ban"):
        out.append(f"- **本书另禁**：{'、'.join(prof['extra_ban'])}")
    if prof.get("extra_allow"):
        out.append(f"- **本书放行**：{'、'.join(prof['extra_allow'])}")
    return out


def sec_router(chosen, prof):
    out = ["## 二、总控", "", "### 节奏"] + render(R["pacing"], chosen)
    out += ["", "### 冲突裁决（按顺序）"]
    out += [f"{i}. **{LABEL.get(k, k)}**：{v}" for i, (k, v) in enumerate(R["conflict"].items(), 1)]
    rules = {k: v for k, v in G.items() if k not in ("lexicon", "structure_bans")}
    if "05" not in chosen:   # 国术词只随05出现
        rules["power_scale"] = {k: v for k, v in rules["power_scale"].items() if k != "guoshu_map"}
    out += ["", "### 全局口径"] + render(rules, chosen)
    return out + ["", "### 术语"] + sec_lexicon(chosen, prof) + [""]


def sec_book(book, nums, prof):
    out = ["## 三、本书设定（全书生效，高于场面引擎）", ""]
    if prof.get("book"):
        out.append(f"- **书名**：{prof['book']}")
    for i, n in enumerate(book):
        tail = "（全文见「本次引擎」）" if n in nums else ""
        out.append(f"- **{label(n)}（{'主' if i == 0 else '副'}）**：{E[n]['load_when']}{tail}")
        out += [f"  - 身份锁：{x}" for x in E[n].get("lock", [])]
    if not book:
        out.append("- 主角模板未锁定：导出时用 --book 或 --profile 带上本书的L1，身份锁才会写进来。")
    if prof.get("scale_overrides"):
        out += ["- **刻度改动**（以此为准）"] + [f"  - {x}" for x in prof["scale_overrides"]]
    if prof.get("characters"):
        out.append("- **人物**")
        for c in prof["characters"]:
            if isinstance(c, dict):
                role = f"（{c['role']}）" if c.get("role") else ""
                out.append(f"  - {c.get('name', '')}{role}：{c.get('notes', '')}")
            else:
                out.append(f"  - {c}")
    if prof.get("notes"):
        out += ["- **全书约定**"] + [f"  - {x}" for x in prof["notes"]]
    return out + [""]


def sec_engines(slots, alts):
    out = ["## 四、本次引擎", ""]
    for s in SLOT_KEYS:
        n, title = slots[s], f"### 槽{s[-1]} {SLOTS[s]['name']}"
        if not n:
            hint = "本次不打：要打就按底座的打击链与镜头写" if s == "slot_2" else "本次不加载"
            out += [f"{title}：空", "", f"- {hint}", ""]
            continue
        e = E[n]
        out += [f"{title}：{label(n)}（{e['layer']}·{e['group']}）", "",
                f"- **何时用**：{e['load_when']}",
                f"- **基调·平时**：{e['tone']['baseline']}",
                f"- **基调·高潮**：{e['tone']['climax']}",
                "- **写法**"] + [f"  - {x}" for x in e["rules"]]
        if e.get("examples"):
            out += ["- **示例**（质感标尺，不照抄）"] + [f"  - {x}" for x in e["examples"]]
        for key, name in (("modes", "模式"), ("stages", "阶段")):
            if e.get(key):
                out.append(f"- **{name}**（按情节选一个）")
                for m, lines in e[key].items():
                    out += [f"  - **{m}**"] + [f"    - {x}" for x in lines]
        if e.get("bans"):
            out += ["- **本引擎禁止**"] + [f"  - {x}" for x in e["bans"]]
        if e.get("lock"):
            out += ["- **身份锁**"] + [f"  - {x}" for x in e["lock"]]
        if alts.get(s):
            out.append(f"- **本卷可换**：{'、'.join(map(label, alts[s]))}（换的时候重新导出）")
        out.append("")
    return out


def sec_check():
    return ["## 五、交稿前自检", ""] + [f"- {x}" for x in CHECKLIST] + [""]


def finish(lines):
    text = "\n".join(lines).rstrip() + "\n"
    for a, b in TERMS:
        text = text.replace(a, b)
    return text


def build(nums, book, prof, alts=None, note="", title=""):
    nums, book, slots, problems, notes = check(nums, book)
    chosen = set(nums) | set(book)
    extra = [x for x in notes if not x.startswith(("身份锁", "没给本书L1"))]
    head = [f"# 都市高武写作规范：{title or '、'.join(map(label, nums))}", "", HOW, "", LAYERS, "",
            f"生成参数：引擎 {' '.join(nums) or '无'}；本书L1 {' '.join(book) or '未锁定'}。", ""]
    if note:
        head += [f"本卷说明：{note}", ""]
    if extra:
        head += ["本次注意："] + [f"- {x}" for x in extra] + [""]
    body = sec_core(chosen) + sec_router(chosen, prof) + sec_book(book, nums, prof) + sec_engines(slots, alts or {}) + sec_check()
    return finish(head + body), problems


def build_catalog(book, prof):
    _, book, _, problems, _ = check([], book)
    chosen = set(book)
    head = ["# 都市高武写作规范：底座与引擎目录", "",
            "用法：放在对话最前面，先让AI按目录帮你选本书的主角模板（L1，1主+1副）和本卷配方；"
            "正式写某一章时，再把选中引擎的文件（references/engines/编号_*.yaml）贴进来，或用 export_prompt.py 导出那一章的规范。", "",
            LAYERS, ""]
    cat = ["## 四、引擎目录", ""]
    names = {"L1": ("主角模板", "开书锁定1主+1副，身份锁全书生效；也可进槽1，当本场视角人物的模板。"),
             "L2": ("剧情舞台", "按卷换，进槽3。"), "L3": ("场面模块", "按场换，进槽2。"),
             "L4": ("叙事滤镜", "按章换，进槽1或槽3。")}
    for lay, (title, desc) in names.items():
        group = [n for n, e in E.items() if e["layer"] == lay]
        order = list(dict.fromkeys(E[n]["group"] for n in group))
        group.sort(key=lambda n: (order.index(E[n]["group"]), int(n)))
        cat += [f"### {lay} {title}（{len(group)}）", "", desc, ""]
        for n in group:
            e = E[n]
            tags = f"［{'、'.join(e['tags'])}］" if e.get("tags") else ""
            cat.append(f"- {label(n)}（{e['group']}）{tags}：{e['load_when']}")
        cat.append("")
    cat += ["### 配方（每槽给候选，每次各取一个）", ""]
    for name, rec in R["recipes"].items():
        parts = [f"本书L1 {'、'.join(map(label, rec['L1']))}"] if rec.get("L1") else []
        parts += [f"{SLOTS[s]['name']} {'/'.join(map(label, rec[s]))}" for s in SLOT_KEYS if rec.get(s)]
        cat.append(f"- **{name}**：{'；'.join(parts)}" + (f"。{rec['note']}" if rec.get("note") else ""))
    cat += ["", "### 禁配与互斥", ""]
    for p in R["forbidden_pairs"]:
        cat.append(f"- {'、'.join(p['a'])} × {'、'.join(p['b'])}（{p['level']}）：{p['why']}")
    for g in R.get("exclusive_groups", []):
        cat.append(f"- 互斥组「{g['name']}」{'、'.join(g['members'])} 只选一个（{g['level']}）：{g['why']}")
    for t in R.get("tag_clash", []):
        cat.append(f"- 标签「{t['a']}」×「{t['b']}」（{t['level']}）：{t['why']}")
    cat.append("")
    body = sec_core(chosen) + sec_router(chosen, prof) + sec_book(book, [], prof) + cat + sec_check()
    return finish(head + body), problems


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    print(f"已写入 {path}（{len(text)}字）")


def export_all():
    out = ROOT / "prompts"
    for old in list(out.glob("00_底座与目录.md")) + list(out.glob("*_配方_*.md")):
        old.unlink()
    text, _ = build_catalog([], {})
    write(out / "00_底座与目录.md", text)
    for i, name in enumerate(R["recipes"], 1):
        nums, book, alts, note = expand_recipe(name)
        text, problems = build(nums, book, {}, alts, note, title=f"配方「{name}」")
        if problems:
            sys.exit(f"配方「{name}」有问题，先改 router.yaml：" + "；".join(problems))
        write(out / f"{i:02d}_配方_{name}.md", text)


def main():
    ap = argparse.ArgumentParser(description="导出提示词")
    ap.add_argument("nums", nargs="*", help="本次加载的引擎编号，最多3个")
    ap.add_argument("--book", nargs="*", default=[], help="本书锁定的L1（1主+1副）")
    ap.add_argument("--profile", help="本书设定档")
    ap.add_argument("--volume", type=int, help="按设定档 volumes 的第几卷取引擎（从1数）")
    ap.add_argument("--recipe", help="配方名，如 寒门开局")
    ap.add_argument("--catalog", action="store_true", help="导出底座+总控+引擎目录")
    ap.add_argument("--all", action="store_true", help="重新生成 prompts/")
    ap.add_argument("--force", action="store_true", help="组合有问题也导出")
    ap.add_argument("-o", "--out", help="输出文件，不填就打印")
    args = ap.parse_args()
    if args.all:
        return export_all()

    nums = [norm(n) for n in args.nums]
    book = [norm(n) for n in args.book]
    prof = load_profile(args.profile) if args.profile else {}
    book += prof.get("L1", [])
    alts, note, title = {}, "", ""
    if args.volume:
        if not prof:
            sys.exit("--volume 要和 --profile 一起用")
        v_nums, alts, note, title = expand_volume(prof, args.volume)
        nums += v_nums
    if args.recipe:
        r_nums, r_book, alts, note = expand_recipe(args.recipe)
        nums += r_nums
        book = book or r_book
        title = f"配方「{args.recipe}」"
    if args.catalog:
        text, problems = build_catalog(book, prof)
    else:
        if not nums:
            sys.exit("没给引擎：填编号、用 --recipe，或用 --catalog 导出目录")
        text, problems = build(nums, book, prof, alts, note, title)
    if problems:
        print("\n".join(f"问题：{x}" for x in problems), file=sys.stderr)
        if not args.force:
            sys.exit("组合有问题，没有导出。先用 check_combo.py 调整，或加 --force 照样导出。")
    if args.out:
        write(Path(args.out), text)
    else:
        sys.stdout.write(text)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Export a complete skill installer or portable package using only Python 3."""

import argparse
import os
from pathlib import Path, PurePosixPath
import posixpath
import re
import sys
import tempfile
from urllib.parse import unquote, urlsplit
import zipfile


PROJECT_PREFIX = "assets/project-packs/"
SOURCE_NOTES = "assets/third-party/SOURCE-NOTES.md"
GATE_CARD = "assets/delivery-gate-card.md"
REQUIRED_METADATA = (
    "agents/openai.yaml",
    "assets/icon.svg",
    SOURCE_NOTES,
    "assets/third-party/oh-story-LICENSE.txt",
)
# The visual-materials command line imports its package; the package files ship with it (r5.35).
VISUAL_PACKAGE = (
    "scripts/visual_materials/__init__.py",
    "scripts/visual_materials/adopt.py",
    "scripts/visual_materials/collect.py",
    "scripts/visual_materials/common.py",
    "scripts/visual_materials/dedupe.py",
    "scripts/visual_materials/doctor.py",
    "scripts/visual_materials/providers/__init__.py",
    "scripts/visual_materials/providers/openverse.py",
    "scripts/visual_materials/providers/searxng.py",
    "scripts/visual_materials/rank.py",
    "scripts/visual_materials/review.py",
    "scripts/visual_materials/search.py",
    "scripts/visual_materials/selection.py",
    "scripts/visual_materials/verify.py",
)
# This is an explicit content profile, not a glob or a claim about sale rights.
# Add a path only after reviewing that file for generic, non-project content.
SALE_FILES = frozenset({
    "SKILL.md",
    "CONSTITUTION.md",
    "assets/constitution-rules.json",
    "agents/openai.yaml",
    "assets/dashboard/app.js",
    "assets/dashboard/index.html",
    "assets/dashboard/styles.css",
    "assets/dashboard/tokens.css",
    "assets/delivery-gate-card.md",
    "assets/icon.svg",
    "assets/fact-ledger-template.json",
    "assets/fact-claims-template.json",
    "assets/editorial-review-template.json",
    "assets/project-template.md",
    "assets/punctuation-rules-template.json",
    "assets/rule-conflicts-template.json",
    "assets/story-state-template.md",
    "assets/serial-handoff-template.md",
    "assets/reference-source-template.md",
    "assets/sentence-dialogue-checklist.md",
    "assets/nonlinear-timeline-template.md",
    "assets/parallel-timelines-template.md",
    "assets/scene-beat-card.md",
    "assets/voice-material-card.md",
    "assets/inspiration-library-template.json",
    "assets/visual-materials-config.example.json",
    "assets/technique-card-template.md",
    "assets/third-party/INTEGRATION-NOTES.md",
    "assets/third-party/SOURCE-NOTES.md",
    "assets/third-party/oh-story-0.8.4-LICENSE.txt",
    "assets/third-party/oh-story-LICENSE.txt",
    "assets/voice-card-template.md",
    "assets/style-cards/cards.json",
    "references/adversarial-review.md",
    "references/author-preferences.md",
    "references/characters.md",
    "references/chinese-punctuation.md",
    "references/coaching.md",
    "references/continuity.md",
    "references/cover-design.md",
    "references/deconstruction-library.md",
    "references/drafting.md",
    "references/dialogue-craft.md",
    "references/sentence-craft.md",
    "references/stakes.md",
    "references/style-cards.md",
    "references/scene-dramaturgy.md",
    "references/revision-passes.md",
    "references/inspiration-library.md",
    "references/visual-materials.md",
    "references/nonlinear-timeline.md",
    "references/parallel-timelines.md",
    "references/editing.md",
    "references/execution.md",
    "references/file-delivery.md",
    "references/genre-library.md",
    "references/local-workbench.md",
    "references/manuscript-import.md",
    "references/market-research.md",
    "references/pacing.md",
    "references/planning.md",
    "references/progression.md",
    "references/project-bootstrap.md",
    "references/projects.md",
    "references/prose-audit.md",
    "references/quality-loop.md",
    "references/reference-study.md",
    "references/serial-production.md",
    "references/serial-example.md",
    "references/short-fiction.md",
    "references/short-production.md",
    "references/skill-evaluation.md",
    "references/state-storage.md",
    "references/voice.md",
    "scripts/export_portable.py",
    "scripts/fact_guard.py",
    "scripts/oh-story/build_chapter_index.py",
    "scripts/oh-story/dashboard-server.mjs",
    "scripts/oh-story/inspect_existing_assets.py",
    "scripts/oh-story/render_relation_chart.py",
    "scripts/project_state.py",
    "scripts/prose_lint.py",
    "scripts/dialogue_lines.py",
    "scripts/detail_check.py",
    "scripts/inspiration_library.py",
    "scripts/inspiration_write.py",
    "scripts/style_cards.py",
    "scripts/visual_materials_cli.py",
    *VISUAL_PACKAGE,
    "scripts/punctuation_lint.py",
    "scripts/rule_register.py",
    "scripts/workflow_guard.py",
    "scripts/delivery_manifest.py",
    "scripts/workflow_demo.py",
})
EXCLUDED_PARTS = frozenset({
    ".git", ".hg", ".svn", "__pycache__", ".pytest_cache", ".mypy_cache",
    ".ruff_cache", ".cache", ".tox", ".venv", "venv", "node_modules",
})
# Resource links use inline Markdown or reference definitions; paths containing
# spaces use <angle brackets>. Code examples do not declare file dependencies.
INLINE_LINK = re.compile(
    r'!?\[([^\]\n]+)\]\(\s*(?:<([^>\n]+)>|([^\s)]+))'
    r'(?:\s+(?:"[^"\n]*"|\'[^\'\n]*\'))?\s*\)'
)
REFERENCE_DEF = re.compile(
    r'^ {0,3}\[([^\]\n]+)\]:\s*(?:<([^>\n]+)>|(\S+)).*$', re.MULTILINE
)


GUIDE = """# 小说写作工坊：迁移说明

这份包将通用方法与具体作品资料分开，可用于新作品或新的 AI 会话。

## 本次导出

- 内容模式：`{mode}`。
- 附带作品资料：{project_status}。
- 文件夹版包含 {core_count} 个通用文件，并保留安装界面、图标、方法、模板、脚本与来源许可资料。

`personal` 默认沿相对链接收集通用资源；作品资料仅在明确使用 `--include-projects` 时附带。`sale` 仅选择导出器中逐项列明的通用文件，禁止附带项目；新增依赖若不在白名单内会报错，需要人工审查后更新白名单。

此模式只控制打包内容，不是权利认证或可售承诺。参考截图未附使用条款；来源、许可与尚待核实事项见 [SOURCE-NOTES.md](novel-workshop/assets/third-party/SOURCE-NOTES.md)，MIT 许可见 [oh-story-LICENSE.txt](novel-workshop/assets/third-party/oh-story-LICENSE.txt)。导出命令只生成本地文件，不发布或上架。

## 选择用法

| 目标环境 | 使用方法 |
| --- | --- |
| 支持文件夹式 Skills | 使用 novel-workshop 文件夹，保留内部相对位置，按目标环境支持的方式导入。 |
| 只有聊天、项目指令或附件输入 | 提供 portable-novel-workshop.md，以及当前任务、项目资料与原稿。单文件已展开 Markdown 方法和模板，末尾保留上游许可；来源说明仅作包内参考。 |
| 换一本小说 | 使用新作品的档案、文风卡和原稿，按题材选择相关方法。 |
| 换AI或会话继续同一作品 | 携带项目档案、文风卡（如有）、状态记录、最新及相关原文，从未完成处接续。 |

## 包含的内容

- `novel-workshop/`：完整文件夹式技能，内部相对位置保持一致。
- `portable-novel-workshop.md`：展开的写作指令，适合直接上传或复制；写作不依赖脚本、网络和特定账户。
- `README.md`：本说明及本次归档清单。

附带作品时，项目入口位于 `novel-workshop/assets/project-packs/index.md`。项目是可选资料，只有选定作品时才读取；它们不展开到通用单文件中。

## 开始与恢复

提供材料后可说：“按小说写作工坊处理。本轮润色，保留情节、人物动机和信息顺序，只交正文。”也可指定只分析、续写、设计卷纲或检查衔接。

需要长期跟踪时说：“为这部作品开启持续维护，草稿与已采纳状态分开记录。”只需开启一次；新会话仍需带上记录和相关原稿。

起草、核查和修订可由一个AI顺序完成。多代理不是使用条件；自查不能声称独立验证。检查过程默认留在内部，不附在小说正文后。

有 Python 时可按 references/execution.md 使用 workflow_guard.py 检查明确条件、保存修订额度和恢复点。程序只核对已声明的条件，文笔、张力和人物逻辑仍需审稿；纯聊天版保留相同方法与文本交接，不宣称程序检查已执行。恢复时携带原任务状态，避免重复计数。

prose_lint.py 只提示重复段落、遗留占位和项目指定表达；punctuation_lint.py 只定位标点格式错误和句子切碎等复核线索；fact_guard.py 只比对声明过的事实主张与已采纳事实账；rule_register.py 只核对规则文件的冲突登记表自己说的话对不对得上。结果都不是AI来源检测或文笔裁决。整章及以上的交付按 references/quality-loop.md 写四项状态，未执行的检查写 UNTESTED。作者偏好按范围携带，小说事实只随具体项目走。

多人或多代理维护项目状态时，按 references/state-storage.md 使用 project_state.py 的读版本、条件保存与冲突合并。仅在支持的本地文件环境且各写入方遵循同一协议时有效；纯聊天、绕过脚本或跨机器同步不具备该保证。升级方法按 references/skill-evaluation.md 做旧新同题匿名对照；导出文档按 references/file-delivery.md 检查实际最后版本。

## 更新后重新导出

文件夹版中，在 novel-workshop 目录运行：

```bash
python3 scripts/export_portable.py /目标目录/novel-workshop-portable.zip
python3 scripts/export_portable.py /目标目录/novel-workshop-sale.zip --mode sale
python3 scripts/export_portable.py /目标目录/novel-workshop-install.zip --format install
```

默认 `--mode personal --format portable`。需要附带项目时加 `--include-projects`，不可与 `--mode sale` 同用。`--format install` 只生成 `novel-workshop/` 技能目录；两种格式均保留完整界面与打包元数据。新增资源须以相对 Markdown 链接接入主文件或参考文件；个人模式沿链接收集，可售候选模式另受固定白名单约束。缺失引用或越界路径会报错并保留旧包；导出成功时更新指定 ZIP。纯聊天单文件不包含可执行脚本，重新导出请使用文件夹版。

安装入口取决于目标环境。迁移的是方法与资料，不是原对话记忆，也不保证不同模型产生相同文笔。

## 归档文件清单

{inventory}
"""


def prose_only(text):
    """Ignore fenced and inline code when discovering resource links."""
    lines = []
    fence = None
    for line in text.splitlines():
        marker = re.match(r"^ {0,3}(`{3,}|~{3,})", line)
        if marker:
            token = marker.group(1)
            if fence is None:
                fence = token
            elif token[0] == fence[0] and len(token) >= len(fence):
                fence = None
            continue
        if fence is None:
            lines.append(line)
    return re.sub(r"(`+).*?\1", "", "\n".join(lines))


def link_targets(text):
    text = prose_only(text)
    for pattern in (INLINE_LINK, REFERENCE_DEF):
        for match in pattern.finditer(text):
            yield match.group(2) or match.group(3)


def local_target(relative, target):
    """Resolve a local file link without allowing it to leave the package."""
    url = urlsplit(target)
    if url.scheme or url.netloc:
        if url.scheme == "file":
            raise ValueError(f"Use a relative resource link in {relative}: {target}")
        return None
    if not url.path:
        return None
    path = unquote(url.path)
    if "\\" in path or path.startswith("/"):
        raise ValueError(f"Resource path must be relative in {relative}: {target}")
    joined = posixpath.normpath(str(PurePosixPath(relative).parent / path))
    if joined == ".." or joined.startswith("../"):
        raise ValueError(f"Resource escapes package in {relative}: {target}")
    return joined


def excluded_path(relative):
    path = PurePosixPath(relative)
    return (bool(EXCLUDED_PARTS.intersection(path.parts))
            or path.suffix.lower() in {".pyc", ".pyo"}
            or path.name in {".DS_Store", "Thumbs.db"})


def read_resource(root, relative, mode="personal"):
    if excluded_path(relative):
        raise ValueError(f"Cache or environment file cannot be packaged: {relative}")
    source = root / relative
    try:
        resolved = source.resolve().relative_to(root.resolve()).as_posix()
    except ValueError as exc:
        raise ValueError(f"Resource escapes skill directory: {relative}") from exc
    if excluded_path(resolved):
        raise ValueError(f"Resource resolves to an excluded file: {relative}")
    if mode == "sale" and resolved not in SALE_FILES:
        raise ValueError(f"Sale resource resolves outside the whitelist: {relative}")
    if not source.is_file():
        raise FileNotFoundError(f"Missing linked resource: {relative}")
    return source.read_bytes()


def resource_dependencies(relative, data):
    if PurePosixPath(relative).suffix.lower() == ".md":
        for target in link_targets(data.decode("utf-8")):
            linked = local_target(relative, target)
            if linked is not None:
                yield linked
    elif relative == "scripts/visual_materials_cli.py":
        yield from VISUAL_PACKAGE
    elif relative == "agents/openai.yaml":
        # The only file references in the agent interface are root-relative icons.
        for match in re.finditer(r"^\s*icon_(?:small|large):\s*(.+?)\s*$",
                                 data.decode("utf-8"), re.MULTILINE):
            target = match.group(1).strip()
            if target[:1] in {"'", '"'}:
                if len(target) < 2 or target[-1] != target[0]:
                    raise ValueError("Malformed icon path in agents/openai.yaml")
                target = target[1:-1]
            else:
                target = target.split(" #", 1)[0].rstrip()
            linked = local_target("SKILL.md", target)
            if linked is not None:
                yield linked


def collect_core(root, mode="personal"):
    """Follow personal dependencies or enforce the fixed sale content profile."""
    if mode not in {"personal", "sale"}:
        raise ValueError("mode must be personal or sale")
    resources = {}
    pending = sorted(SALE_FILES) if mode == "sale" else ["SKILL.md", *REQUIRED_METADATA]
    while pending:
        relative = pending.pop(0)
        if relative in resources:
            continue
        if relative.startswith(PROJECT_PREFIX):
            raise ValueError("Keep optional project links in the optional project index")
        if mode == "sale" and relative not in SALE_FILES:
            raise ValueError(f"Sale dependency is not in the whitelist: {relative}")
        data = read_resource(root, relative, mode)
        resources[relative] = data
        pending.extend(resource_dependencies(relative, data))
    return resources


def plain_links(text):
    """Use labels for internal links whose Markdown is embedded below."""
    def is_external(target):
        url = urlsplit(target)
        return bool(url.scheme or url.netloc)

    def replace_inline(match):
        target = match.group(2) or match.group(3)
        return match.group(0) if is_external(target) else match.group(1)

    definitions = {
        m.group(1).casefold(): m.group(2) or m.group(3)
        for m in REFERENCE_DEF.finditer(text)
    }

    def replace_reference(match):
        label = match.group(1)
        identifier = (match.group(2) or label).casefold()
        target = definitions.get(identifier)
        return label if target and not is_external(target) else match.group(0)

    text = REFERENCE_DEF.sub(
        lambda m: m.group(0) if is_external(m.group(2) or m.group(3)) else "", text
    )
    text = INLINE_LINK.sub(replace_inline, text)
    return re.sub(r"\[([^\]\n]+)\](?:\[([^\]\n]*)\])?", replace_reference, text)


def validate_links(entries):
    for relative, data in entries.items():
        if PurePosixPath(relative).suffix.lower() != ".md":
            continue
        for target in link_targets(data.decode("utf-8")):
            linked = local_target(relative, target)
            if linked is not None and linked not in entries:
                raise FileNotFoundError(f"Broken archive link: {relative} -> {target}")


def export(root, output, include_projects=False, mode="personal", format="portable"):
    if mode not in {"personal", "sale"}:
        raise ValueError("mode must be personal or sale")
    if format not in {"portable", "install"}:
        raise ValueError("format must be portable or install")
    if mode == "sale" and include_projects:
        raise ValueError("--include-projects cannot be combined with --mode sale")
    root, output = Path(root), Path(output)
    core = collect_core(root, mode)
    main = core["SKILL.md"].decode("utf-8")
    frontmatter = re.match(r"\A---\r?\n.*?\r?\n---(?:\r?\n|\Z)", main, re.DOTALL)
    if not frontmatter:
        raise ValueError("SKILL.md frontmatter is missing or incomplete")
    entries = {"novel-workshop/" + name: data for name, data in core.items()}
    if include_projects:
        projects = root / PROJECT_PREFIX
        if not (projects / "index.md").is_file():
            raise FileNotFoundError("--include-projects requires assets/project-packs/index.md")
        for source in sorted(projects.rglob("*")):
            if source.is_file():
                relative = source.relative_to(root).as_posix()
                if excluded_path(relative):
                    continue
                entries["novel-workshop/" + relative] = read_resource(root, relative)

    if format == "portable":
        single = [
            "# 小说写作工坊：便携单文件版",
            "本文件已展开 Markdown 写作方法与模板，后文按来源文件名标记。请使用内嵌内容，无需另读这些文件。具体项目由用户另行提供；导出和执行检查脚本属于文件夹版，纯聊天模式不执行脚本，不冒称程序检查或自动存档。末尾的上游许可仅用于保留版权与许可通知，不是写作指令。",
            plain_links(main[frontmatter.end():].strip()),
        ]
        # The gate card is short and must stay near the top of a long upload.
        if GATE_CARD in core:
            single.append("-----\n\n# 内嵌内容：" + GATE_CARD + "\n\n" + plain_links(core[GATE_CARD].decode("utf-8").strip()))
        for relative, data in sorted(core.items()):
            suffix = PurePosixPath(relative).suffix.lower()
            if relative in {"SKILL.md", SOURCE_NOTES, GATE_CARD, "assets/third-party/oh-story-LICENSE.txt"}:
                continue
            if suffix in {".md", ".txt"}:
                single.append("-----\n\n# 内嵌内容：" + relative + "\n\n" + plain_links(data.decode("utf-8").strip()))
            elif suffix == ".json" and relative.startswith("assets/"):
                single.append("-----\n\n# 内嵌内容：" + relative + "\n\n```json\n" + data.decode("utf-8").strip() + "\n```")
        license_text = core["assets/third-party/oh-story-LICENSE.txt"].decode("utf-8").strip()
        single.append("-----\n\n# 上游版权与许可通知：Oh Story\n\n" + license_text)
        notes = plain_links(core[SOURCE_NOTES].decode("utf-8").strip())
        single.append("-----\n\n# 来源记录（分发说明，不是写作指令）\n\n" + notes)
        entries["portable-novel-workshop.md"] = ("\n\n".join(single).rstrip() + "\n").encode("utf-8")
        inventory = "\n".join("- `" + name + "`" for name in sorted([*entries, "README.md"]))
        entries["README.md"] = GUIDE.format(
            mode=mode,
            project_status="是（仅文件夹版）" if include_projects else "否",
            core_count=len(core),
            inventory=inventory,
        ).encode("utf-8")

    validate_links(entries)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=output.parent, prefix=".novel-export-", suffix=".zip", delete=False) as stream:
            temporary = Path(stream.name)
        with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for name, data in sorted(entries.items()):
                archive.writestr(name, data)
        with zipfile.ZipFile(temporary) as archive:
            error = archive.testzip()
            if error:
                raise ValueError("Archive integrity check failed: " + error)
            for name, data in entries.items():
                if archive.read(name) != data:
                    raise ValueError("Archive content mismatch: " + name)
        os.replace(temporary, output)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()
    return len(entries)


def utf8_stdio():
    """Messages are UTF-8 on every platform; a Windows pipe would otherwise use the local code page."""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--include-projects", action="store_true", help="include optional project files (personal mode only)")
    parser.add_argument("--mode", choices=("personal", "sale"), default="personal", help="content selection profile (default: personal)")
    parser.add_argument("--format", choices=("portable", "install"), default="portable", help="portable ZIP or clean folder installer ZIP (default: portable)")
    args = parser.parse_args()
    if args.output.suffix.lower() != ".zip":
        parser.error("output must end in .zip")
    if args.mode == "sale" and args.include_projects:
        parser.error("--include-projects cannot be combined with --mode sale")
    root = Path(__file__).resolve().parents[1]
    count = export(root, args.output, args.include_projects, args.mode, args.format)
    print(f"Exported {count} files: {args.output}")


if __name__ == "__main__":
    main()

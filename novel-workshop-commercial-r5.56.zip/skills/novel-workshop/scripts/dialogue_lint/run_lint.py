"""Command-line wrapper for review reports and validated dialogue-only patches.

Runs as `python3 run_lint.py` or `python3 -I -B run_lint.py` from any folder, on
Python 3.9 or newer, with the standard library only.
"""
import sys
from pathlib import Path

if __name__ == '__main__':
    sys.dont_write_bytecode = True  # keep the skill folder free of __pycache__
_HERE = str(Path(__file__).resolve().parent)
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)  # python3 -I leaves the script's own folder off the import path

import argparse
from dataclasses import asdict
import hashlib
import json

from dialogue_core import extract_dialogues, quote_coverage
from dialogue_antipatterns import scan_dialogue_antipatterns, wording_pattern
from patch_guard import apply_dialogue_patch, build_patch_request, check_request_matches, format_patch_prompt
from voice_lint import VOICEPRINT_REGISTRY, VoiceprintProfile, analyze_voice_and_idioms
from genre_profiles import (GENRE_PROFILES, resolve_genre_profile,
    resolve_scene_overrides, scene_keyword_hints)
from system_brackets import scan_system_brackets

VERSION = '1.2.0'
BOM = '﻿'
PROFILE_FIELDS = {'archetype', 'voice_prompt', 'min_avg_len', 'min_colloquial_rate'}
LEGACY_PROFILE_FIELDS = ('min_avg_len', 'min_colloquial_rate')


def read_source(path):
    """Lines with their own line endings, and whether the file began with a byte order mark."""
    text = Path(path).read_bytes().decode('utf-8')
    has_bom = text.startswith(BOM)
    if has_bom:
        text = text[1:]
    return text.splitlines(keepends=True), has_bom


def _unique_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('JSON包含重复字段')
        result[key] = value
    return result


def read_json_bytes(data):
    return json.loads(data.decode('utf-8-sig'), object_pairs_hook=_unique_keys)


def read_json(path):
    return read_json_bytes(Path(path).read_bytes())


def write_new(path, text):
    with Path(path).open('x', encoding='utf-8', newline='') as stream:
        stream.write(text)


def check_outputs(paths):
    """Refuse before anything is written: names must be new, distinct and in existing folders."""
    resolved = [Path(p).resolve() for p in paths]
    if len(resolved) != len(set(resolved)) or any(Path(p).exists() for p in paths):
        raise ValueError('输出必须使用各自不同的新文件名')
    for path in paths:
        if not Path(path).resolve().parent.is_dir():
            raise ValueError(f'输出文件所在的文件夹不存在：{path}')


def load_config(path):
    """The config as a dict, plus the sha256 of its bytes (None without a config)."""
    if not path:
        return {}, None
    data = Path(path).read_bytes()
    return read_json_bytes(data), hashlib.sha256(data).hexdigest()


def _name_list(config, key):
    values = config.get(key, [])
    if not isinstance(values, list) or any(not isinstance(v, str) or not v for v in values):
        raise ValueError(f'{key}必须是角色名数组')
    return values


def config_values(path, config=None):
    if config is None:
        config, _ = load_config(path)
    if not isinstance(config, dict):
        raise ValueError('配置必须是JSON对象')
    allowed = {'profiles', 'aliases', 'speaker_overrides', 'stress_speakers', 'cold_protagonist_names',
        'min_profile_quotes', 'genre_id', 'genre_overrides', 'scene_overrides', 'system_brackets',
        'suspicious_expressions'}
    if set(config) - allowed:
        raise ValueError('配置包含未知字段')
    if not isinstance(config.get('profiles', {}), dict) or not isinstance(config.get('aliases', {}), dict):
        raise ValueError('profiles和aliases必须是JSON对象')
    if not isinstance(config.get('speaker_overrides', []), list):
        raise ValueError('speaker_overrides必须是JSON数组')
    declared = [*_name_list(config, 'cold_protagonist_names'), *_name_list(config, 'stress_speakers')]
    wording_pattern(config.get('suspicious_expressions', []))
    profiles = dict(VOICEPRINT_REGISTRY)
    for name, values in config.get('profiles', {}).items():
        if not isinstance(values, dict) or set(values) - PROFILE_FIELDS:
            raise ValueError('profiles里每个角色只能写archetype、voice_prompt（旧配置的min_avg_len、min_colloquial_rate仍可保留）')
        profiles[name] = VoiceprintProfile(name=name, **values)
    # A name listed as terse or under stress is a declared character for every scanner.
    for name in declared:
        profiles.setdefault(name, VoiceprintProfile(name=name))
    overrides = {}
    for override in config.get('speaker_overrides', []):
        if not isinstance(override, dict) or set(override) != {'para_index', 'quote_index', 'speaker'}:
            raise ValueError('说话人覆盖记录字段不正确')
        p, q = override['para_index'], override['quote_index']
        if type(p) is not int or type(q) is not int or p < 1 or q < 1:
            raise ValueError('覆盖记录的段号/引语号必须是正整数')
        key = (p, q)
        if key in overrides:
            raise ValueError('同一引语不能重复指定说话人')
        overrides[key] = override['speaker']
    return config, profiles, overrides


def _lines(entries):
    numbers = sorted({e['para_index'] for e in entries})
    shown = '、'.join(str(n) for n in numbers[:8]) + ('……' if len(numbers) > 8 else '')
    return f'第{shown}行'


def coverage_notice(paragraphs, dialogues, coverage):
    """Plain sentences saying which quotation marks were not read; empty when all were."""
    notes = []
    if not dialogues and any(p.strip() for p in paragraphs):
        notes.append('没有认出台词：本工具只认“”「」『』这三种引号。稿子用的是直引号或别的引号时，'
                     '台词不会被扫描，这里的 0 条不说明稿子里没有台词。')
    if coverage['unsupported_marks']:
        notes.append(f"{_lines(coverage['unsupported_marks'])}有直引号或别的引号，这些地方没有当作台词扫描。")
    if coverage['unclosed_quotes']:
        notes.append(f"{_lines(coverage['unclosed_quotes'])}的引号到行末没有收（跨段接着说，或漏了后引号），"
                     '按读到行末算一条台词；这几条不进候选改句。')
    if coverage['stray_marks']:
        notes.append(f"{_lines(coverage['stray_marks'])}有配不上对的引号，配不上的那一处没有当作台词扫描。")
    return ''.join(notes)


def run_scan(paragraphs, config_path, style_hints, genre_choice):
    """One scan: the report payload, the patch request, and the system-bracket records."""
    raw_config, config_hash = load_config(config_path)
    config, profiles, overrides = config_values(config_path, raw_config)
    aliases = config.get('aliases', {})
    cold = config.get('cold_protagonist_names', [])
    stress = config.get('stress_speakers', [])
    wording = config.get('suspicious_expressions', [])
    genre = resolve_genre_profile(genre_choice if genre_choice is not None else config.get('genre_id'),
        config.get('genre_overrides'))
    names = tuple(profiles)
    dialogues = extract_dialogues(paragraphs, names, aliases=aliases, speaker_overrides=overrides)
    scene_exempt, scene_applied = resolve_scene_overrides(dialogues, config.get('scene_overrides'))
    report, voice_issues = analyze_voice_and_idioms(paragraphs, registry=profiles, aliases=aliases,
        speaker_overrides=overrides, stress_speakers=stress, cold_protagonist_names=cold,
        min_profile_quotes=config.get('min_profile_quotes', 3), include_style_hints=style_hints,
        genre_profile=genre, style_exempt_quotes=scene_exempt)
    pattern_issues = scan_dialogue_antipatterns(paragraphs, tuple(cold), names=names,
        aliases=aliases, speaker_overrides=overrides, include_style_hints=style_hints,
        genre_profile=genre, style_exempt_quotes=scene_exempt, suspicious_expressions=wording)
    system_issues = scan_system_brackets(paragraphs, config.get('system_brackets'), genre_profile=genre)
    system_settings = config.get('system_brackets') or {}
    system_enabled = system_settings.get('enabled', False)
    anchors_enabled = system_enabled and system_settings.get('check_anchors',
        genre.enable_system_bracket_anchor if genre is not None else False)
    issues = voice_issues + pattern_issues
    settings = {'config_sha256': config_hash, 'style_hints': bool(style_hints), 'genre': genre_choice}
    request = build_patch_request(paragraphs, issues, scan_settings=settings)
    coverage = quote_coverage(paragraphs)
    coverage['notice'] = coverage_notice(paragraphs, dialogues, coverage)
    confirmed = sum(d.confidence in ('explicit', 'manual') for d in dialogues)
    legacy = sorted({key for values in config.get('profiles', {}).values() for key in values
                     if key in LEGACY_PROFILE_FIELDS})
    payload = {
        'version': VERSION,
        'genre_profile': None if genre is None else genre.to_report(),
        'scene_keyword_hints': scene_keyword_hints(paragraphs, genre),
        'scene_overrides_applied': scene_applied,
        'system_brackets_configured': system_enabled,
        'effective_system_policy': {'enabled': system_enabled, 'check_anchors': anchors_enabled,
            'anchor_mode': ('regex_form' if 'anchor_pattern' in system_settings else 'manual_review') if anchors_enabled else 'off',
            'forbid_outer_punctuation': system_enabled and system_settings.get('forbid_outer_punctuation', False)},
        'system_bracket_issues': system_issues,
        'checks_run': {'speaker_attribution': True, 'suspicious_expressions': list(wording),
            'style_hints': bool(style_hints), 'stress_speakers': list(stress),
            'no_short_sentence_hints_for': list(cold), 'system_brackets': system_enabled},
        'summary': {'dialogue_quotes': len(dialogues), 'confirmed_quotes': confirmed,
            'unconfirmed_quotes': len(dialogues) - confirmed,
            'unclosed_quotes': len(coverage['unclosed_quotes']),
            'voice_issue_records': len(voice_issues), 'antipattern_issue_records': len(pattern_issues),
            'review_records': len(issues),
            'candidate_quotes': len({i.quote_id for i in issues}),
            'unconfirmed_issue_records': sum(i.confidence not in ('explicit', 'manual') for i in issues),
            'patch_candidate_quotes': len(request['items']),
            'style_hints_enabled': bool(style_hints),
            'system_bracket_records': len(system_issues),
            'system_format_errors': sum(i['severity'] == 'ERROR' for i in system_issues)},
        'notice': ('规则命中仅供复核，不证明语病、机器创作或文学质量；未知/推测归属不进入角色数字和自动补丁请求。'
                   '角色那一栏只是字面数字，不和任何线比较，不给人物下结论。'),
        'quote_coverage': coverage,
        'config_notes': ([f"profiles里的{'、'.join(legacy)}已不再使用：角色那一栏只给数字，不和这些值比较。"]
                         if legacy else []),
        'voice_report': report,
        'dialogues': [dict(asdict(d), closed=d.closed) for d in dialogues],
        'voice_issues': [asdict(i) for i in voice_issues],
        'antipattern_issues': [asdict(i) for i in pattern_issues],
    }
    return payload, request, system_issues


def main(argv=None):
    parser = argparse.ArgumentParser(description='对白复核工具：报告不代表语病或AI来源判定')
    actions = parser.add_subparsers(dest='action', required=True)
    scan = actions.add_parser('scan', help='只读扫描，生成复核报告')
    scan.add_argument('source')
    apply = actions.add_parser('apply', help='重新扫描核对请求后，应用作者确认过的候选，写到新文件')
    apply.add_argument('source')
    apply.add_argument('request')
    apply.add_argument('response')
    apply.add_argument('--output', required=True)
    for command in (scan, apply):
        command.add_argument('--config', help='本书配置；apply 时要和 scan 用同一份')
        command.add_argument('--style-hints', action='store_true', help='启用全部可选文风复核模式')
        command.add_argument('--genre', choices=tuple(GENRE_PROFILES), help='显式选择题材，优先于配置里的genre_id')
    scan.add_argument('--output', help='新建JSON报告；省略时打印')
    scan.add_argument('--request-output', help='新建可验证补丁请求JSON')
    scan.add_argument('--prompt-output', help='新建供模型生成候选补丁的提示文本')
    args = parser.parse_args(argv)
    try:
        paragraphs, has_bom = read_source(args.source)
        if args.action == 'apply':
            check_outputs([args.output])
            request, response = read_json(args.request), read_json(args.response)
            _, rebuilt, _ = run_scan(paragraphs, args.config, args.style_hints, args.genre)
            check_request_matches(request, rebuilt)
            updated = apply_dialogue_patch(paragraphs, rebuilt, response)
            write_new(args.output, (BOM if has_bom else '') + ''.join(updated))
            changed = [r['quote_id'] for r in response['replacements']]
            print(f"已生成：{args.output}（重新扫描核对过的可改引语 {len(rebuilt['items'])} 条，"
                  f"本次替换 {len(changed)} 条{'：' + '、'.join(changed) if changed else ''}）")
            return 0
        outputs = [p for p in (args.output, args.request_output, args.prompt_output) if p]
        check_outputs(outputs)
        payload, request, system_issues = run_scan(paragraphs, args.config, args.style_hints, args.genre)
        encoded = json.dumps(payload, ensure_ascii=False, indent=2) + '\n'
        if args.output:
            write_new(args.output, encoded)
        else:
            print(encoded, end='')
        if args.request_output:
            write_new(args.request_output, json.dumps(request, ensure_ascii=False, indent=2) + '\n')
        if args.prompt_output:
            write_new(args.prompt_output, format_patch_prompt(request))
        if payload['quote_coverage']['notice']:
            print('提示：' + payload['quote_coverage']['notice'], file=sys.stderr)
        return 1 if any(i['severity'] == 'ERROR' for i in system_issues) else 0
    except (ValueError, TypeError, KeyError, OSError) as error:
        print(f'错误：{error}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())

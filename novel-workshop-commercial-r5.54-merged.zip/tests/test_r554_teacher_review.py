#!/usr/bin/env python3
"""r5.54: how to read what a teacher sends back. The author's words of 11-12: "还有就是审查老师推荐的改法，我感觉这方面可能
会有些缺"; the same day the author let the workshop try what it proposed.

The package gets one page, references/teacher-review.md, used at stage 5 of the new-chapter flow
(chapter-confirmation.md): first find out what the teacher changed, then for every change a kind, a proposed handling and
who decides, and a short table for the author. In the merged build the chapter gate and learning loop retain actual
returns and decisions while the agent performs the editorial reading.

These tests check that the page is there, that it can be reached from the entry and from the stage it serves, that it
uses the existing event contract, that it goes into the sale package, and that what it points to exists: its links, the
sections it names in quotation marks, the scripts it names and their subcommands and options. They do not show that a
teacher's return is read better this way: the page has not been tried on a real one. The two small passages below are
newly written for this test.
"""
import importlib.util
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest
import zipfile

sys.dont_write_bytecode = True
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
PAGE = "references/teacher-review.md"
LINK = re.compile(r"\]\(([^)#\s]+)")
NAMED = re.compile(r"\]\(([^)#\s]+)\)“([^”]+)”")
TICKS = re.compile(r"`([^`]+)`")


def read(rel):
    return (SKILL / rel).read_text(encoding="utf-8")


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(script, *args):
    proc = subprocess.run([sys.executable, "-I", "-B", str(script), *map(str, args)], capture_output=True, text=True,
                          encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


def section(text, heading):
    start = text.find("\n## " + heading)
    if start == -1:
        return ""
    end = text.find("\n## ", start + 4)
    return text[start:end if end != -1 else len(text)]


class ThePage(unittest.TestCase):
    def setUp(self):
        self.text = read(PAGE)

    def test_it_is_there(self):
        self.assertTrue(self.text.startswith("# 教师回传怎么审（r5.54）\n"))
        self.assertIn("(chapter-confirmation.md)的 `review` 阶段", self.text)
        self.assertIn("作者转来别人改过的一版稿子、问“他改得对不对”的时候也可用这套读法", self.text)
        headings = [l for l in self.text.splitlines() if l.startswith("## ")]
        self.assertEqual(headings, ["## 回传、取舍与复查怎么记", "## 1. 先还原他改了什么",
                                    "## 2. 每一处：记一类，写拟处置，写谁来定", "## 3. 认问题，不照抄改法",
                                    "## 4. 多了什么，丢了什么", "## 5. 改稿里可能出的毛病，和查它的工具", "## 6. 给作者看的是一张短表"])

    def test_return_decision_and_recheck_use_the_existing_events(self):
        records = section(self.text, "回传、取舍与复查怎么记")
        for event in ("teacher_return", "teacher_return_id", "artifact_sha256", "review", "decide", "revise",
                      "finish", "learn"):
            self.assertIn(f"`{event}`", records)
        self.assertIn("作者确认方案后用 `decide`", records)
        self.assertIn("最终采纳仍等作者对当前修订稿明确决定", records)
        self.assertIn("逐项判断和短表由工坊完成", records)
        self.assertIn("尚待用真实教师回传验证", records)
        code, out, err = run(SKILL / "scripts" / "learning_loop.py", "--help")
        self.assertEqual(code, 0, err)
        self.assertIn("decide: review_id,decisions:[{finding_id,decision:adopt|decline|defer,reason}]", out)

    def test_it_does_not_set_up_its_own_kinds(self):
        self.assertIn("改动和意见的分类沿用[句式专项](sentence-craft.md)", self.text)
        language = section(read("references/sentence-craft.md"), "语感：搭配、照应与叫法")
        for word in ("纯表达", "消歧", "补信息", "改状态", "明确语病", "可选润色", "事实待核", "照改会误改"):
            self.assertIn(word, self.text)
            self.assertIn(word, language, word)  # the kinds are the ones the sentence module already has
        self.assertIn("1. **", language)
        self.assertIn("3. **按条处理外部的语感意见。**", language)
        self.assertIn("采纳、拒绝或暂缓", self.text)
        self.assertIn("作者可以确认整份方案并点出例外", read("references/chapter-confirmation.md"))

    def test_who_decides(self):
        two = section(self.text, "2. 每一处")
        rows = [l for l in two.splitlines() if l.startswith("| ") and not l.startswith("| ---")]
        self.assertEqual([r.split("|")[2].strip() for r in rows],
                         ["谁来定", "工坊核对后拟处置，作者只点例外", "作者；工坊拟处置并写看法",
                          "有依据的工坊核对后拟处置；查不到依据的列“待核”，等作者", "只有作者"])
        self.assertIn("台词里添的话、删的话", rows[-1])  # what the teacher adds to or takes out of a line: only the author
        self.assertIn("每一处写拟采纳、拒绝或暂缓及其依据", two)
        self.assertIn("部分采纳写明采纳范围，保留原文记为拒绝，待核记为暂缓", two)
        self.assertIn("处置（采纳、部分采纳、保留、待核）", read("references/sentence-craft.md"))
        for phrase in ("**这是推断，标成推断**", "不整句照抄，也不整份照收", "两样都写“没变”的，列成“可改可不改”",
                       "教师是人还是模型，核对的办法一样", "工具只给位置，判断靠读；工具没报不等于没有"):
            self.assertIn(phrase, self.text)

    def test_links_resolve_and_named_sections_exist(self):
        targets = LINK.findall(self.text)
        self.assertGreaterEqual(len(targets), 8)
        for target in targets:
            self.assertTrue((SKILL / "references" / target).resolve().is_file(), target)
        named = NAMED.findall(self.text)
        self.assertGreaterEqual(len(named), 6)
        for target, name in named:
            self.assertIn(name, (SKILL / "references" / target).resolve().read_text(encoding="utf-8"), (target, name))
        # the places named without a link next to them
        self.assertIn("**外部意见的记录（r5.14）。**", read("references/execution.md"))
        self.assertIn("## 修订前后对照", read("references/editing.md"))
        self.assertIn("- **关键瞬间的临场体验（r5.37）**", section(read("references/scene-dramaturgy.md"), "4. 在工坊里怎样执行"))
        self.assertIn("## 总结、复述和章尾", read("references/prose-audit.md"))
        self.assertIn("## 去模板腔时引入的新模板", read("references/prose-audit.md"))
        self.assertIn("## 两件事分开做", read("references/dialogue-craft.md"))
        self.assertIn("## 视觉必经与作者教师交接", read("references/chapter-confirmation.md"))

    def test_scripts_subcommands_and_options(self):
        helps = {}

        def help_of(script):
            if script not in helps:
                code, out, err = run(SKILL / "scripts" / script, "--help")
                self.assertEqual(code, 0, script + err)
                text = out
                found = re.search(r"\[-h\] \{([a-z_,-]+)\}", out)  # subcommands, as the usage line lists them
                subs = found.group(1).split(",") if found else []
                for sub in subs:
                    code, more, err = run(SKILL / "scripts" / script, sub, "--help")
                    self.assertEqual(code, 0, script + " " + sub + err)
                    text += "\n" + more
                helps[script] = (subs, text)
            return helps[script]

        checked = 0
        named = sorted(set(re.findall(r"[a-z_]+\.py", " ".join(TICKS.findall(self.text)))))
        self.assertEqual(named, ["detail_check.py", "dialogue_lines.py", "fact_guard.py", "prose_lint.py",
                                 "punctuation_lint.py"])
        # The event names are tested against the learning contract separately. Check the diagnostic CLI table here.
        for line in section(self.text, "5. 改稿里可能出的毛病，和查它的工具").splitlines():
            spans = TICKS.findall(line)
            scripts = [s for span in spans for s in re.findall(r"[a-z_]+\.py", span)]
            for script in scripts:
                self.assertTrue((SKILL / "scripts" / script).is_file(), script)
            for span in spans:
                words = span.split()
                if words and words[0].endswith(".py"):
                    script, rest = words[0], words[1:]
                    subs, every = help_of(script)
                    if rest and re.fullmatch(r"[a-z]+", rest[0]) and subs:
                        self.assertIn(rest[0], subs, span)  # a subcommand
                        checked += 1
                        rest = rest[1:]
                    for word in rest:
                        if re.fullmatch(r"--?[a-z-]+|[a-z]+", word):
                            self.assertIn(word, every, span)  # an option, or the value of one (--hint deai)
                            checked += 1
                elif re.fullmatch(r"--?[a-z-]+|[a-z]+", span):
                    # an option or subcommand on its own (`--keep`, `compare`): a script named on the line has it, or,
                    # where the line goes on from the row above (`compare` after detail_check.py), one named on the page
                    self.assertTrue(any(span in help_of(s)[1] for s in scripts + named), span)
                    checked += 1
        self.assertGreaterEqual(checked, 8)

    def test_the_numbers_column_is_there(self):
        self.assertIn("`detail_check.py changes` 的“数字和数量”一栏", self.text)
        # r5.54 review (fidelity-6, consistency-10): the lines column exists; only "did it bring in something new" is reading
        self.assertIn("`detail_check.py changes` 的“台词”一栏；[对白专项](dialogue-craft.md)“两件事分开做”", self.text)
        self.assertIn("台词一栏只列改了、没了、新加的台词和位置；带没带出新的事、是句内的改动还是来回的增删（来回的增删照第 2 节，只有作者定），"
                      "没有工具，靠读", self.text)  # verify-batch2 v-3: no second place that lets the workshop decide
        self.assertNotIn("| 没有工具，靠读 |", self.text)
        self.assertIn("`detail_check.py compare` 的新判断句", self.text)
        with tempfile.TemporaryDirectory() as tmp:
            first, second = Path(tmp) / "a.md", Path(tmp) / "b.md"
            first.write_bytes("他在铺子里称了三斤米，付了钱就走。\n\n“明天还来吗？”掌柜问。\n".encode("utf-8"))
            second.write_bytes("他在铺子里称了五斤米，付了钱就走。\n\n“明天还来不来？”掌柜问。\n".encode("utf-8"))
            code, out, err = run(SKILL / "scripts" / "detail_check.py", "changes", first, second)
            self.assertEqual(code, 0, err)
        self.assertIn("- 数字和数量", out)
        self.assertIn("“三斤”", out)
        self.assertIn("- 台词", out)


class Reachable(unittest.TestCase):
    def test_from_the_entry(self):
        rows = [l for l in read("SKILL.md").splitlines() if l.startswith("| 已开启新章完整流程")]
        self.assertEqual(len(rows), 1)
        for path in ("references/chapter-confirmation.md", PAGE):
            self.assertIn(f"]({path})", rows[0])

    def test_from_the_stage_it_serves(self):
        text = read("references/chapter-confirmation.md")
        stage = next(l for l in text.splitlines() if l.startswith("| `review` "))
        self.assertIn("](teacher-review.md)", stage)
        after = section(text, "视觉必经与作者教师交接")
        self.assertIn("](teacher-review.md)", after)
        self.assertIn("将修订计划交作者确认", after)
        for target in LINK.findall(text):
            self.assertTrue((SKILL / "references" / target).resolve().is_file(), target)

    def test_not_from_execution_or_editing(self):
        # r5.54 amendment, item 17: those two modules do not get a pointer to the page
        for rel in ("references/execution.md", "references/editing.md"):
            self.assertNotIn("teacher-review.md", read(rel), rel)


class SalePackage(unittest.TestCase):
    def test_the_page_is_on_the_sale_list_and_in_the_export(self):
        exporter = load(SKILL / "scripts" / "export_portable.py", "export_portable_r554")
        self.assertIn(PAGE, exporter.SALE_FILES)
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "sale.zip"
            code, out, err = run(SKILL / "scripts" / "export_portable.py", target, "--mode", "sale")
            self.assertEqual(code, 0, out + err)
            with zipfile.ZipFile(target) as archive:
                names = set(archive.namelist())
                portable = archive.read("portable-novel-workshop.md").decode("utf-8")
        self.assertTrue(any(n.endswith("novel-workshop/" + PAGE) for n in names))
        self.assertIn("# 教师回传怎么审（r5.54）", portable)
        # the revision card is embedded in the single file: its r5.54 sentence goes with it
        self.assertIn("这张单子查的是叙述里多出来的套话；对白像不像人、话里有没有口气，它查不出来", portable)


if __name__ == "__main__":
    unittest.main()

from pathlib import Path
import sys
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import prose_lint as prose


class NarrativeXianTests(unittest.TestCase):
    def scan(self, text):
        return prose.inspect_text(text, hints=('xian',), scene_rules=False, language_rules=False)

    def test_default_and_deai_groups_do_not_run_xian(self):
        for hints in ((), ('deai',), ('deai-extra',)):
            report=prose.inspect_text('他先问：“门开了吗？”',hints=hints)
            self.assertNotIn('xian-crutch',report['checks_run'])
            self.assertNotIn('xian-density',report['checks_run'])

    def test_phrase_pattern_compiles_and_narrative_candidate_is_located(self):
        report=self.scan('小林先问：“门开了吗？”')
        items=[f for f in report['findings'] if f['rule']=='xian-crutch']
        self.assertEqual([(i['quote'],i['line'],i['column']) for i in items],[('先问',1,3)])
        self.assertIn('先后',items[0]['message'])
        self.assertNotIn('删除',items[0]['message'])

    def test_long_dialogue_and_inline_narration_are_separated(self):
        text='“'+('这里还有很多话。'*8)+'先问，别急。”他说，先把信收好。'
        report=self.scan(text)
        self.assertFalse(any(f['rule']=='xian-crutch' for f in report['findings']))
        self.assertEqual(report['xian_statistics']['action_prefix_count'],1)

    def test_multiline_quote_and_nested_quote_preserve_narrative_offsets(self):
        text='“先把门关上。\n再说：‘先走。’”他说，先把信收好。'
        stats=self.scan(text)['xian_statistics']
        self.assertEqual(stats['action_prefix_count'],1)
        self.assertEqual(stats['positions'][0]['line'],2)
        self.assertEqual(stats['positions'][0]['column'],text.split('\n')[1].index('先把')+1)
        self.assertTrue(stats['quote_coverage_complete'])

    def test_direct_quotes_and_other_registered_chinese_quote_pairs_are_excluded(self):
        for text in ('"先把门关上。"','「先把门关上。」','『先把门关上。』','‘先把门关上。’'):
            with self.subTest(text=text):
                report=self.scan(text)
                self.assertEqual(report['xian_statistics']['action_prefix_count'],0)
                self.assertIsNone(report['xian_statistics']['per_1000_narrative_han'])

    def test_escaped_ascii_quote_does_not_end_dialogue(self):
        text='"先把\\"门\\"关上。"他先把钥匙收好。'
        self.assertEqual(self.scan(text)['xian_statistics']['action_prefix_count'],1)

    def test_compounds_are_not_counted_but_colleague_is_not_mistaken_for_shixian(self):
        text='祖先把名刻在碑上。优先让伤员走。同事先把门关了。'
        self.assertEqual(self.scan(text)['xian_statistics']['action_prefix_count'],1)
        self.assertFalse(any(f['rule']=='xian-crutch' for f in self.scan('他颇有先见之明。')['findings']))

    def test_real_order_is_review_only_and_original_text_is_unchanged(self):
        text='他先问：“伤在哪里？”得到回答后才动手。他先把绳结解开，再掀起箱盖。'
        original=text
        report=self.scan(text)
        self.assertEqual(text,original)
        self.assertEqual(report['xian_statistics']['action_prefix_count'],2)
        self.assertEqual(report['status'],'REVIEW')
        self.assertTrue(all('高危' not in f['message'] and '赘字' not in f['message'] for f in report['findings']))

    def test_density_counts_narrative_han_only_and_reports_raw_measurement(self):
        report=self.scan('他先把门关上。“先把灯关上。”')
        stats=report['xian_statistics']
        self.assertEqual(stats['narrative_han_characters'],6)
        self.assertEqual(stats['action_prefix_count'],1)
        self.assertAlmostEqual(stats['per_1000_narrative_han'],1000/6,places=3)
        self.assertFalse(any(f['rule']=='xian-density' for f in report['findings']))

    def test_empty_whitespace_punctuation_and_only_dialogue_have_no_zero_division(self):
        for text in ('',' \n\t','。！？','“先把门关上。”'):
            with self.subTest(text=text):
                stats=self.scan(text)['xian_statistics']
                self.assertEqual(stats['action_prefix_count'],0)
                self.assertIsNone(stats['per_1000_narrative_han'])

    def test_unclosed_quote_reports_incomplete_coverage_without_fake_density(self):
        report=self.scan('他先把信收好。“先把门关上。\n后面仍未闭合。')
        stats=report['xian_statistics']
        self.assertFalse(stats['quote_coverage_complete'])
        self.assertEqual(stats['action_prefix_count'],1)
        self.assertIsNone(stats['per_1000_narrative_han'])
        self.assertIn('引号',prose.text_report(report))

    def test_individual_hints_can_run_separately(self):
        text='他先问：“门开了吗？”'
        phrase=prose.inspect_text(text,hints=('xian-crutch',),scene_rules=False)
        density=prose.inspect_text(text,hints=('xian-density',),scene_rules=False)
        self.assertIn('xian-crutch',[i['rule'] for i in phrase['findings']])
        self.assertNotIn('xian_statistics',phrase)
        self.assertEqual(density['xian_statistics']['action_prefix_count'],1)
        self.assertFalse(density['findings'])


if __name__=='__main__':
    unittest.main()

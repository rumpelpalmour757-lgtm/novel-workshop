# 对白声纹与反模式：可选试用入口

当前扩展：dialogue-lint 1.1.0，2026-11-09。作者要求测试对白声纹、伪口语或反模式检测时使用。先读本轮原文和相关人物配置，运行只读扫描，再逐处回读；只安装、跑通程序不代表文笔改善。

## 在当前作品上测试

从当前技能根目录运行：

```bash
python3 scripts/dialogue_lint/run_lint.py scan 章稿.txt --config 本书配置.json --output 对白复核.json
```

作者要看全部文风提示时，加 `--style-hints`；默认只提示少量可疑措辞。按作品入口读取本书的配置文件；其他书从[空配置模板](../assets/dialogue-lint-config.example.json)建立自己的配置，不借用其他作品人物。`profiles` 的键是角色名，每项包含 `archetype`、`min_avg_len`、`min_colloquial_rate`、`voice_prompt`。角色阈值和声音提示从作者已确认的样本整理，不作为通用中文语法标准。

- 按引语分别定位，段号按输入物理行计，空行占一行，引语号从1开始。可用 `speaker_overrides` 明确指定某行某条引语的说话人；示例结构：`{"para_index": 2, "quote_index": 1, "speaker": "角色名"}`。只填核对过的位置，不把一章的覆盖表套到另一章。
- `explicit` 为明确发言提示，`manual` 为作者指定，`inferred` 为动作主语推测，`unknown` 为未知。只将前两种计入确认声纹和候选补丁请求；逐条查看推测与未知，不能为了提高统计覆盖率乱认人。
- 所有文风命中只标 `REVIEW`。可保留作者有意的短句、祈使、省略、书面术语和无语气词回答；不按指标添“呢”“嘶”、改句号或补动作，不凭命中判定英文来源或机器创作。
- 生理压力由 `stress_speakers` 显式声明，仅对本次输入有效；不从“血”“歪”等字推定状态，也不强制喘息或痛呼。
- 目前不解析同一引语跨物理行的软换行；这种稿件继续按[中文标点](chinese-punctuation.md)的软换行方式核对，不为工具擅改版式。正常双引号内嵌引用用‘’。

## 显式选择题材参数

三种预设是可调整的起点，不是全题材标准，也不按书名或关键词自动选择。用 `--genre modern_gritty`、`--genre classical_xianxia` 或 `--genre western_fantasy`；也可在本书配置填写 `genre_id`，命令行选择优先。没选题材时保持原中性行为。

| 配置 | 连续短句平均长度参考线 | 差异 |
| --- | --- | --- |
| modern_gritty | 9.5 | 13项候选规则可选 |
| classical_xianxia | 7.5 | 关闭 COMP_02、COMP_03、COMP_04，容许凝练短句 |
| western_fantasy | 10.5 | 关闭 COMP_04、TRANS_03、TRANS_06，保留译制口吻选择 |

`genre_overrides` 可覆盖 `enabled_rules`、`max_avg_clause_len`、`colloquial_markers`（正则字符串）、`enable_system_bracket_anchor` 和 `tactical_scene_keywords`（正则字符串）。未知ID、非法正则、非正或非有限阈值会报错；预设不可被原地改动。`enabled_rules: []` 关闭两路13项反模式及其同源声纹提示；独立显式声明的压力复核和本书格式检查仍照配置执行。选择题材不会自动开启 `--style-hints`。

题材词库实际用于口语标记统计和连续短句复核；平均长度参考线只用于声纹扫描器的连续短句提示，不替代13条各自的匹配结构。角色自己的 `min_avg_len/min_colloquial_rate` 仍控制角色参考线，两种阈值用途不同，报告分别写来源。标记命中率不是“人味分”。

## 场景提示与定点豁免

`通讯器/耳麦/公堂/宣读` 等命中只出现在 `scene_keyword_hints`，不会自动免检。作者已确认场景时，才在当次配置的 `scene_overrides` 声明精确引语及需要暂免的规则，例如：

```json
{"para_index": 2, "quote_index": 1, "quote": "在门后头。", "mode": "tactical", "reason": "作者确认这是通话中的方位答复。", "exempt_rule_ids": ["COMP_04_COORDINATE_REPLY"]}
```

`mode` 可为 `tactical`、`formal_reading` 或 `normal`；前两种须显式列出非空 `exempt_rule_ids`，normal须为空数组。豁免仅限本条引语中列出的规则，同句其他规则和其他人物的台词照常检查。只允许 SYN_02、SYN_03、COMP_02、COMP_03、COMP_04、TRANS_05、TRANS_06 这组文风线索，不允许借场景关闭构词、压力或系统格式检查。记录原句与当前文本不符时拒绝运行，不能把旧覆盖表套到新稿。

## 系统【】与锚点独立配置

题材的 `enable_system_bracket_anchor` 只是锚点偏好默认，不能说明本书存在系统。必须在本书配置显式设置 `system_brackets.enabled: true` 并声明 `active_tags` 或 `panel_prefixes`，才检查已声明的独行项目。普通 `【注意安全】` 不自动当系统项。

`system_brackets` 接受 `enabled`、`check_anchors`、`active_tags`、`panel_prefixes`、`anchor_pattern`、`forbid_outer_punctuation`。本书显式 `check_anchors` 优先于题材默认，因此古风含系统、现代无系统都可配置。`forbid_outer_punctuation` 只有明确设为true才检查括号外标点；只对已声明主动名称检查末尾标点，不删除面板完整句标点。

开启锚点复核但没有 `anchor_pattern` 时，只给人工复核提示；提供正则时按前一非空段 `fullmatch` 核对已配置的形式，可报格式ERROR，不能证明动作或体感在语义上成立，也不自动补动作。报告的 `effective_system_policy` 写明本次实际开启了哪种检查。系统项不会进入对白候选补丁。扫描退出码0表示无格式ERROR（可能有REVIEW），1表示声明的格式ERROR，2表示输入/配置无效。

## 只在作者要候选改句时生成补丁

```bash
python3 scripts/dialogue_lint/run_lint.py scan 章稿.txt --config 本书配置.json --style-hints --request-output 请求.json --prompt-output 请求提示.txt
```

请求按同一引语合并各条问题。把请求提示交给模型得到纯JSON候选；先核对语义、事实、口吻与修改权限，再应用到新文件：

```bash
python3 scripts/dialogue_lint/run_lint.py apply 章稿.txt 请求.json 模型候选.json --output 候选稿.txt
```

只用本地构建的原请求，不能用模型生成的请求替换它。应用校验源版本、引语位置、原文字面、重复ID/字段及输出范围；拒绝注入换行或中文双引号，保留旁白和原有换行。所有输出使用新文件名，不覆盖原文。校验保护的是结构范围，不能证明事实与文学效果没变；改完仍按[编辑](editing.md)的修订前后对照回读。作者只要扫描时，不自行生成或应用补丁。

## 工具资源

- [命令行入口](../scripts/dialogue_lint/run_lint.py)
- [逐引语归属与原文位置](../scripts/dialogue_lint/dialogue_core.py)
- [角色字面指标与少量措辞候选](../scripts/dialogue_lint/voice_lint.py)
- [13项可选反模式规则](../scripts/dialogue_lint/dialogue_antipatterns.py)
- [候选请求及范围校验](../scripts/dialogue_lint/patch_guard.py)
- [题材参数与精确场景豁免](../scripts/dialogue_lint/genre_profiles.py)
- [本书声明的系统格式与锚点](../scripts/dialogue_lint/system_brackets.py)

作者测试期间作为辅助入口，保留现有按人物回读与 `dialogue_lines.py`；不新增交付门必过条件，不把检查清零作为目标。正式宣称写法优于旧版前，另按[技能维护的新旧对照](skill-evaluation.md)做文学验证并取得作者评价。

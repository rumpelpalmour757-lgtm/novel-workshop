#!/usr/bin/env python3
"""r5.19: say which examples are the standard's and which the workshop wrote (2026-10-19 review of r5.18, INFO-518-01).

The semicolon section put two invented sentences right after "the standard's examples include a cause", so a reader
could take them for the standard's own examples. The section on the enumeration comma, question mark and colon
(r5.16) has the same layout: clause numbers of GB/T 15834-2011, then examples that are all invented (checked against
the standard's text: none of them is among its examples). Both sections now say so before the first example, and
the semicolon section still keeps its two examples on the 4.6.3.2 line.
"""

import os
from pathlib import Path
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
PUNCT = ROOT / "skills" / "novel-workshop" / "references" / "chinese-punctuation.md"
LABEL = "工坊自编"
NOT_STANDARD = "不是标准原句"


def section(text, heading):
    return text.split("\n" + heading + "\n", 1)[1].split("\n## ", 1)[0]


class ExampleSources(unittest.TestCase):
    def setUp(self):
        self.text = PUNCT.read_text(encoding="utf-8")

    def test_semicolon_examples_are_marked_as_the_workshops_before_they_start(self):
        line = [l for l in section(self.text, "## 分号").splitlines() if "4.6.3.2" in l]
        self.assertEqual(len(line), 1)
        line = line[0]
        for phrase in (LABEL, NOT_STANDARD, "标准的示例里也有因果"):
            self.assertIn(phrase, line)
        first_example = line.index("`")
        self.assertLess(line.index("标准的示例里也有因果"), line.index(LABEL))
        self.assertLess(line.index(LABEL), first_example)
        self.assertLess(line.index(NOT_STANDARD), first_example)

    def test_comma_question_and_colon_section_says_the_same_before_its_list(self):
        part = section(self.text, "## 顿号、问号与冒号")
        intro = [l for l in part.splitlines() if l.strip()][0]
        self.assertIn("GB/T 15834—2011", intro)
        self.assertIn(LABEL, intro)
        self.assertIn(NOT_STANDARD, intro)
        self.assertNotIn("`", intro)


if __name__ == "__main__":
    unittest.main()

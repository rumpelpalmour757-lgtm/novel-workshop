import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts/demonstration_memory.py"
spec = importlib.util.spec_from_file_location("demonstration_memory", SCRIPT)
memory = importlib.util.module_from_spec(spec)
spec.loader.exec_module(memory)


def case(case_id, status="teacher_approved", split="development", group=None, project="book"):
    item = json.loads((ROOT / "assets/demonstration-case-template.json").read_text(encoding="utf-8"))
    item.update(id=case_id, project_id=project, group_id=group or case_id,
                status=status, split=split, tags=["dialogue"],
                before=f"原稿{case_id}", after=f"改稿{case_id}")
    item["source"] = {"ref": "fixture", "version": "1", "reviewer": "fixture-teacher",
                      "evidence": "Synthetic fixture only; no real author approval."}
    if status == "author_accepted":
        item["author_acceptance"] = {"quote": "合成测试中的认可", "ref": "fixture-author"}
    item["hashes"] = {key: hashlib.sha256(item[key].encode()).hexdigest()
                      for key in ("before", "after")}
    return item


def state(*items, enabled=True):
    return {"project_id": "book", "data": {"characters": {"keeper": {"name": "保留"}},
            "settings": {}, "chapters": {}, "demonstration_learning": {"enabled": enabled},
            "demonstrations": {c["id"]: c for c in items}}}


class DemonstrationMemoryTests(unittest.TestCase):
    def test_selection_respects_status_scope_and_author_priority(self):
        payload = state(case("teacher"), case("author", "author_accepted"),
                        case("candidate", "candidate"), case("rejected", "rejected"),
                        case("retired", "retired"), case("other-book", project="elsewhere"))
        errors, cases, _ = memory.validate(payload)
        self.assertEqual(errors, [])
        self.assertEqual([c["id"] for c in memory.select(cases, "book", "dialogue_revision", [], [], 3)],
                         ["author", "teacher"])

    def test_holdout_blocks_entire_group_and_duplicate_text(self):
        held = case("held", split="holdout", group="same-scene")
        sibling = case("sibling", group="same-scene")
        duplicate = case("duplicate")
        duplicate["after"] = held["after"]
        duplicate["hashes"]["after"] = held["hashes"]["after"]
        payload = state(held, sibling, duplicate, case("safe"))
        _, cases, _ = memory.validate(payload)
        self.assertEqual([c["id"] for c in memory.select(cases, "book", "dialogue_revision", [], [], 3)], ["safe"])

    def test_missing_author_evidence_and_stale_text_are_invalid(self):
        author = case("author", "author_accepted")
        author["author_acceptance"] = None
        author["after"] += "未重新认可的更改"
        errors, _, _ = memory.validate(state(author))
        self.assertTrue(any("author quote" in e for e in errors))
        self.assertTrue(any("hashes.after" in e for e in errors))

    def test_heldout_text_cannot_swap_input_and_target(self):
        held = case("held", split="holdout")
        swapped = case("swapped")
        swapped["before"] = held["after"]
        swapped["hashes"]["before"] = held["hashes"]["after"]
        _, cases, _ = memory.validate(state(held, swapped, case("safe")))
        self.assertEqual([c["id"] for c in memory.select(cases, "book", "dialogue_revision", [], [], 3)], ["safe"])

    def test_index_never_emits_example_text_or_approval_evidence(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "state.json"
            path.write_text(json.dumps(state(case("one"), case("held", split="holdout"))), encoding="utf-8")
            run = subprocess.run([sys.executable, str(SCRIPT), "index", str(path),
                                  "--project-id", "book", "--task", "dialogue_revision"],
                                 capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(run.returncode, 0, run.stderr)
            record = json.loads(run.stdout)["cases"][0]
            # r5.55: the index now also carries the conditions, exceptions and the
            # reviewer's role and mode, so applicability can be judged before any text
            # is requested. It still shows no manuscript text and no approval evidence.
            self.assertEqual(set(record), {"id", "project_id", "group_id", "task", "tags", "status", "split",
                                           "when", "except", "reviewer_role", "reviewer_mode"})
            self.assertNotIn("原稿", run.stdout)
            self.assertNotIn("改稿", run.stdout)
            self.assertNotIn("fixture-teacher", run.stdout)
            self.assertNotIn("Synthetic fixture only", run.stdout)

    def test_unchanged_example_is_allowed(self):
        item = case("keep")
        item["after"] = item["before"]
        item["hashes"]["after"] = item["hashes"]["before"]
        item["decisions"] = ["保留原文，无需修改。"]
        self.assertEqual(memory.validate(state(item))[0], [])

    def test_tags_and_explicit_group_exclusion(self):
        _, cases, _ = memory.validate(state(case("one"), case("two")))
        self.assertEqual(memory.select(cases, "book", "dialogue_revision", ["combat"], [], 3), [])
        self.assertEqual([c["id"] for c in memory.select(cases, "book", "dialogue_revision", ["dialogue"], ["one"], 3)], ["two"])

    def test_cli_is_read_only_and_disabled_is_empty(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "state.json"
            path.write_text(json.dumps(state(case("one"), enabled=False)), encoding="utf-8")
            before = path.read_bytes()
            run = subprocess.run([sys.executable, str(SCRIPT), "select", str(path),
                                  "--project-id", "book", "--task", "dialogue_revision"],
                                 capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(run.returncode, 0, run.stderr)
            self.assertEqual(json.loads(run.stdout)["cases"], [])
            self.assertEqual(path.read_bytes(), before)
            invalid = subprocess.run([sys.executable, str(SCRIPT), "select", str(path),
                                      "--project-id", "book", "--task", "dialogue_revision", "--evaluation"],
                                     capture_output=True)
            self.assertNotEqual(invalid.returncode, 0)

    def test_existing_state_commit_roundtrip_preserves_story(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            path, initial, proposed = [folder / n for n in ("state.json", "initial.json", "proposed.json")]
            initial.write_text(json.dumps(state()["data"]), encoding="utf-8")
            state_script = ROOT / "scripts/project_state.py"
            def run(*args):
                result = subprocess.run([sys.executable, str(state_script), *map(str, args)],
                                        capture_output=True, text=True, encoding="utf-8")
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
                return json.loads(result.stdout)
            run("init", path, "--project-id", "book", "--data", initial)
            baseline = run("read", path)
            updated = copy.deepcopy(baseline["data"])
            updated["demonstrations"] = {"one": case("one")}
            proposed.write_text(json.dumps(updated), encoding="utf-8")
            run("commit", path, "--if-version", baseline["version"], "--proposed", proposed)
            saved = run("read", path)
            self.assertEqual(saved["data"]["characters"], baseline["data"]["characters"])
            self.assertEqual(memory.validate(saved)[0], [])
            self.assertEqual(len(memory.select(saved["data"]["demonstrations"], "book", "dialogue_revision", [], [], 3)), 1)

    def cli(self, payload, *args):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "state.json"
            path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            before = path.read_bytes()
            run = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT), args[0], str(path), *args[1:]],
                                 capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(path.read_bytes(), before)
            return run.returncode, json.loads(run.stdout)

    def test_acceptance_bound_to_another_text_is_no_longer_a_valid_approval(self):
        author = case("author", "author_accepted")
        author["author_acceptance"]["draft_sha256"] = author["hashes"]["after"]
        self.assertEqual(memory.approval_problems(author), [])
        # The text is replaced and its hash recomputed; the old acceptance is kept.
        author["after"] = "换过的文字"
        author["hashes"]["after"] = memory.digest(author["after"])
        payload = state(author, case("teacher"))
        errors, cases, _ = memory.validate(payload)
        self.assertEqual(errors, [])
        self.assertTrue(memory.approval_problems(author))
        self.assertEqual([c["id"] for c in memory.select(cases, "book", "dialogue_revision", [], [], 3)],
                         ["teacher"])
        code, checked = self.cli(payload, "check")
        self.assertEqual((code, checked["status"]), (2, "invalid"))
        self.assertTrue(any("author" in error for error in checked["errors"]))
        code, selected = self.cli(payload, "select", "--project-id", "book", "--task", "dialogue_revision")
        self.assertEqual(code, 0)
        self.assertEqual([c["id"] for c in selected["cases"]], ["teacher"])
        self.assertIn("author", selected["skipped_stale_approvals"])

    def test_teacher_review_bound_to_another_text_is_not_selected(self):
        teacher = case("teacher")
        teacher["source"]["draft_sha256"] = memory.digest("教师看过的旧文字")
        _, cases, _ = memory.validate(state(teacher, case("other")))
        self.assertEqual([c["id"] for c in memory.select(cases, "book", "dialogue_revision", [], [], 3)], ["other"])

    def test_status_cannot_exceed_what_its_own_run_records(self):
        promoted, flipped = case("promoted", "author_accepted"), case("flipped")
        after = {item["id"]: item["hashes"]["after"] for item in (promoted, flipped)}
        for item in (promoted, flipped):
            item["source"]["run_id"] = "run-" + item["id"]

        def run(text_hash):
            return {"reviews": {"w1": {"reviewer": {"role": "writer", "mode": "self_check"},
                                       "verdict": "pass", "draft_sha256": text_hash}}, "review_order": ["w1"]}

        payload = state(promoted, flipped)
        data = payload["data"]
        data["learning_runs"] = {"run-promoted": run(after["promoted"]), "run-flipped": run(after["flipped"])}
        self.assertEqual(memory.validate(payload)[0], [])
        self.assertTrue(memory.approval_problems(promoted, data))
        self.assertTrue(memory.approval_problems(flipped, data))
        self.assertEqual(memory.select(data["demonstrations"], "book", "dialogue_revision", [], [], 3, data=data), [])
        # With the evidence actually in the run, the same statuses stand.
        data["learning_runs"]["run-promoted"]["author_acceptance"] = {
            "quote": "合成认可", "ref": "fixture-author", "draft_sha256": after["promoted"]}
        data["learning_runs"]["run-flipped"]["reviews"]["t1"] = {
            "reviewer": {"role": "teacher", "mode": "independent_agent"}, "verdict": "pass",
            "draft_sha256": after["flipped"]}
        self.assertEqual(memory.approval_problems(promoted, data), [])
        self.assertEqual(memory.approval_problems(flipped, data), [])
        # A hand-built case that names no run keeps working as before.
        self.assertEqual(memory.approval_problems(case("by-hand", "author_accepted"), data), [])

    def test_the_authors_open_objection_to_the_text_stops_its_approval(self):
        teacher = case("teacher")
        teacher["source"]["run_id"] = "run"
        after = teacher["hashes"]["after"]
        payload = state(teacher, case("other"))
        data = payload["data"]
        objection = {"review_id": "a1", "reviewer": {"role": "author", "mode": "human"}, "verdict": "blocked",
                     "findings": [], "draft_sha256": after}
        data["learning_runs"] = {"run": {"reviews": {
            "t1": {"review_id": "t1", "reviewer": {"role": "teacher", "mode": "author_return"},
                   "verdict": "pass", "findings": [], "draft_sha256": after}, "a1": objection},
            "review_order": ["t1", "a1"], "decisions": {}}}
        self.assertEqual(memory.open_author_objections(data["learning_runs"]["run"], after), ["a1"])
        self.assertTrue(any("author objected" in p for p in memory.approval_problems(teacher, data)))
        self.assertEqual([c["id"] for c in memory.select(data["demonstrations"], "book", "dialogue_revision",
                                                         [], [], 3, data=data)], ["other"])
        code, checked = self.cli(payload, "check")
        self.assertEqual((code, checked["status"]), (2, "invalid"))
        # Only the author's own later words take it back.
        data["learning_runs"]["run"]["review_withdrawals"] = {"a1": {"quote": "合成：刚才看错了。", "ref": "fixture"}}
        self.assertEqual(memory.approval_problems(teacher, data), [])

    def test_index_shows_conditions_and_lists_the_cases_left_out(self):
        payload = state(*(case("A" + str(number)) for number in range(1, 6)))
        code, listed = self.cli(payload, "index", "--project-id", "book", "--task", "dialogue_revision")
        self.assertEqual(code, 0)
        # r5.55 review: the index carries no text, so it lists every eligible case
        # with its conditions (it used to list three and name the rest under
        # not_selected); the limit of three stays on select, context and start.
        self.assertEqual([c["id"] for c in listed["cases"]], ["A1", "A2", "A3", "A4", "A5"])
        self.assertEqual(listed["not_selected"], [])
        self.assertEqual(listed["eligible_count"], 5)
        code, refused = self.cli(payload, "index", "--project-id", "book", "--task", "dialogue_revision",
                                 "--case-id", "A5")
        self.assertEqual(code, 2)
        code, picked = self.cli(payload, "select", "--project-id", "book", "--task", "dialogue_revision")
        self.assertEqual(([c["id"] for c in picked["cases"]], picked["not_selected"]),
                         (["A1", "A2", "A3"], ["A4", "A5"]))
        self.assertEqual(listed["matched_by"], ["project", "task"])
        self.assertIn("when", listed["applicability"])
        self.assertTrue(all(c["when"] == ["填写适用语境。"] and c["except"] == [] for c in listed["cases"]))
        code, named = self.cli(payload, "select", "--project-id", "book", "--task", "dialogue_revision",
                               "--tag", "dialogue", "--case-id", "A5")
        self.assertEqual(code, 0)
        self.assertEqual([c["id"] for c in named["cases"]], ["A5"])
        self.assertEqual(named["not_selected"], ["A1", "A2", "A3", "A4"])
        self.assertEqual(named["matched_by"], ["project", "task", "tags"])
        code, refused = self.cli(payload, "select", "--project-id", "book", "--task", "dialogue_revision",
                                 "--case-id", "A1", "--case-id", "A2", "--case-id", "A3", "--case-id", "A4")
        self.assertEqual(code, 2)
        code, refused = self.cli(payload, "select", "--project-id", "book", "--task", "dialogue_revision",
                                 "--case-id", "not-approved")
        self.assertEqual(code, 2)

    def test_template_is_a_valid_candidate_that_names_no_reviewer(self):
        template = json.loads((ROOT / "assets/demonstration-case-template.json").read_text(encoding="utf-8"))
        payload = {"project_id": template["project_id"], "data": {
            "demonstration_learning": {"enabled": True}, "demonstrations": {template["id"]: template}}}
        self.assertEqual(memory.validate(payload)[0], [])
        self.assertEqual(template["status"], "candidate")
        self.assertIsNone(template["source"]["reviewer_role"])
        self.assertIsNone(template["source"]["reviewer_mode"])

    def test_recorded_reviewer_role_and_mode_must_be_known_values(self):
        item = case("one")
        item["source"].update(reviewer_role="teacher", reviewer_mode="author_return")
        self.assertEqual(memory.validate(state(item))[0], [])
        item["source"]["reviewer_mode"] = "robot"
        self.assertTrue(any("reviewer_mode" in e for e in memory.validate(state(item))[0]))


if __name__ == "__main__":
    unittest.main()

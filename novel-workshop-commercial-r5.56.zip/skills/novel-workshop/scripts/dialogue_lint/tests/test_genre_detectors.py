"""Genre settings must affect the scanners without implying editing quality.

Fixtures are synthetic and contain no project-specific character configuration.

r5.55: the wording the SYN_01 rule looks for now comes from the book config
(suspicious_expressions), so these tests pass their own made-up phrase; the voice
scanner's short-clause rule is called VOICE_SHORT_CLAUSES (the old ID carried a
verdict word); speaker rows hold numbers only, without reference lines or a status.
"""
from dataclasses import replace
from pathlib import Path
import re
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from dialogue_antipatterns import scan_dialogue_antipatterns
from genre_profiles import get_genre_profile
from voice_lint import VoiceprintProfile, analyze_voice_and_idioms


SYNTHETIC = 'SYN_01_DEGREE_ACT_VERB'
WORDING = ('挺扛冻',)
SHORT = 'COMP_02_IMPERATIVE_TRIPLE_CHOP'
COORDINATE = 'COMP_04_COORDINATE_REPLY'
VOICE_SHORT = 'VOICE_SHORT_CLAUSES'
REGISTRY = {
    '乔宁': VoiceprintProfile('乔宁', 'folksy_warm', 8.0, 0.5, '只作测试参考。'),
}


def issue_ids(issues):
    return [issue.rule_id for issue in issues]


class GenreDetectorTests(unittest.TestCase):
    def setUp(self):
        self.modern = get_genre_profile('modern_gritty')
        self.dense = ['乔宁说：“先关上门。再打开灯。最后坐下来。”'] * 3

    def voice(self, paragraphs, **kwargs):
        return analyze_voice_and_idioms(paragraphs, registry=REGISTRY, **kwargs)

    def scan(self, paragraphs, **kwargs):
        return scan_dialogue_antipatterns(paragraphs, names=tuple(REGISTRY), suspicious_expressions=WORDING, **kwargs)

    def test_none_profile_keeps_existing_style_gate_and_density_behavior(self):
        text = ['乔宁说：“挺扛冻。”', *self.dense]
        self.assertEqual(self.scan(text), self.scan(text, genre_profile=None))
        self.assertEqual(self.voice(text), self.voice(text, genre_profile=None))
        self.assertNotIn(VOICE_SHORT, issue_ids(self.voice(text)[1]))
        self.assertIn(VOICE_SHORT, issue_ids(self.voice(text, include_style_hints=True)[1]))

    def test_profile_does_not_implicitly_enable_style_hints(self):
        text = ['乔宁说：“弯腰，侧身。进去。”', *self.dense]
        self.assertEqual(self.scan(text, genre_profile=self.modern), [])
        self.assertEqual(self.voice(text, genre_profile=self.modern)[1], [])

    def test_empty_enabled_rules_disable_both_mapped_voice_candidates(self):
        genre = replace(self.modern, enabled_rules=frozenset())
        text = ['乔宁说：“挺扛冻。”', *self.dense]
        self.assertEqual(self.scan(text, genre_profile=genre, include_style_hints=True), [])
        self.assertEqual(self.voice(text, genre_profile=genre, include_style_hints=True)[1], [])

    def test_rule_filter_is_applied_to_each_scanner_before_matching(self):
        genre = replace(self.modern, enabled_rules=frozenset({COORDINATE}))
        text = ['乔宁说：“挺扛冻。”', '乔宁说：“在门后头。”', *self.dense]
        self.assertEqual(issue_ids(self.scan(text, genre_profile=genre, include_style_hints=True)), [COORDINATE])
        self.assertEqual(self.voice(text, genre_profile=genre, include_style_hints=True)[1], [])

    def test_classical_profile_disables_shared_short_instruction_rule(self):
        genre = get_genre_profile('classical_xianxia')
        text = ['乔宁说：“弯腰，侧身。进去。”', *self.dense]
        self.assertIn(SHORT, issue_ids(self.scan(text, genre_profile=self.modern, include_style_hints=True)))
        self.assertNotIn(SHORT, issue_ids(self.scan(text, genre_profile=genre, include_style_hints=True)))
        self.assertNotIn(VOICE_SHORT, issue_ids(self.voice(text, genre_profile=genre, include_style_hints=True)[1]))

    def test_genre_markers_drive_both_statistics_and_short_sentence_hint(self):
        text = ['乔宁说：“且慢。先关上门。再打开灯。”'] * 3
        plain = replace(self.modern, colloquial_markers=re.compile('不会命中的测试词'))
        marked = replace(plain, colloquial_markers=re.compile('且慢'))
        plain_report, plain_issues = self.voice(text, genre_profile=plain, include_style_hints=True)
        marked_report, marked_issues = self.voice(text, genre_profile=marked, include_style_hints=True)
        self.assertEqual(plain_report['乔宁']['口语标记命中率'], '0.0%')
        self.assertEqual(marked_report['乔宁']['口语标记命中率'], '100.0%')
        self.assertIn(VOICE_SHORT, issue_ids(plain_issues))
        self.assertNotIn(VOICE_SHORT, issue_ids(marked_issues))

    def test_average_length_threshold_is_effective_without_old_eight_char_cap(self):
        text = ['乔宁说：“先把门口那盏灯打开。再把窗边那张桌搬开。最后把这些椅子放好。”'] * 3
        low = replace(self.modern, max_avg_clause_len=7.0)
        high = replace(self.modern, max_avg_clause_len=10.5)
        self.assertNotIn(VOICE_SHORT, issue_ids(self.voice(text, genre_profile=low, include_style_hints=True)[1]))
        self.assertIn(VOICE_SHORT, issue_ids(self.voice(text, genre_profile=high, include_style_hints=True)[1]))

    def test_genre_report_names_its_markers_and_rows_hold_no_reference_lines(self):
        # r5.55 (author decision): no per-person status and no reference lines in the row;
        # the genre's clause-length line only drives the short-clause hint.
        genre = replace(self.modern, max_avg_clause_len=1.0)
        report, _ = self.voice(self.dense, genre_profile=genre)
        row = report['乔宁']
        for key in ('诊断状态', '角色参考线', '连续短句平均长度参考线', '连续短句参考线来源'):
            self.assertNotIn(key, row)
        self.assertEqual(row['题材配置'], genre.genre_id)
        self.assertEqual(row['口语标记来源'], 'genre_profile.colloquial_markers')
        self.assertEqual(row['有效口语标记'], genre.colloquial_markers.pattern)
        other, _ = self.voice(self.dense, genre_profile=replace(self.modern, max_avg_clause_len=50.0))
        self.assertEqual(row['平均分句长'], other['乔宁']['平均分句长'])
        self.assertEqual(row['台词数'], 3)

    def test_scene_override_is_per_quote_and_preserves_morphology_candidates(self):
        text = ['乔宁说：“弯腰，侧身。进去。挺扛冻。”乔宁又说：“弯腰，侧身。进去。”']
        issues = self.scan(text, genre_profile=self.modern, include_style_hints=True,
                           style_exempt_quotes={'p1:q1': frozenset({SHORT})})
        self.assertEqual([(i.quote_id, i.rule_id) for i in issues], [('p1:q1', SYNTHETIC), ('p1:q2', SHORT)])
        _, voice_issues = self.voice(self.dense, genre_profile=self.modern, include_style_hints=True,
                                    style_exempt_quotes={'p1:q1': frozenset({SHORT})})
        self.assertEqual([i.quote_id for i in voice_issues if i.rule_id == VOICE_SHORT], ['p2:q1', 'p3:q1'])

    def test_explicit_scene_override_covers_formal_style_without_keyword_auto_exemption(self):
        text = ['乔宁对着通讯器说：“鉴于情况有变，先留在这里。”', '乔宁说：“鉴于情况有变，先留在这里。”']
        rule_id = 'TRANS_05_FORMAL_CONNECTIVES_IN_SPEECH'
        auto = self.scan(text, genre_profile=self.modern, include_style_hints=True)
        self.assertEqual([i.quote_id for i in auto if i.rule_id == rule_id], ['p1:q1', 'p2:q1'])
        explicit = self.scan(text, genre_profile=self.modern, include_style_hints=True,
                             style_exempt_quotes={'p1:q1': frozenset({rule_id})})
        self.assertEqual([i.quote_id for i in explicit if i.rule_id == rule_id], ['p2:q1'])

    def test_empty_rule_set_and_scene_override_do_not_remove_confirmed_stress_review(self):
        genre = replace(self.modern, enabled_rules=frozenset())
        text = ['乔宁说：“先把窗边那张很沉的木桌挪开。再把门口堆着的那些椅子搬到墙边。最后关上房间里所有的灯。”']
        _, issues = self.voice(text, genre_profile=genre, stress_speakers=('乔宁',),
                               style_exempt_quotes={'p1:q1': frozenset({SHORT})}, include_style_hints=True)
        self.assertEqual(issue_ids(issues), ['STRESS_SPEECH_REVIEW'])
        self.assertTrue(all(i.severity == 'REVIEW' for i in issues))

    def test_scene_override_waives_only_the_named_rule_within_one_quote(self):
        text = ['乔宁说：“把门给固定了。鉴于风很大，进去是非常危险的。”']
        waived = 'SYN_02_BA_GEI_FORMAL_VERB'
        retained = ['TRANS_05_FORMAL_CONNECTIVES_IN_SPEECH', 'TRANS_06_SHI_DE_JUDGMENT_ABUSE']
        full = self.scan(text, genre_profile=self.modern, include_style_hints=True)
        self.assertEqual(issue_ids(full), [waived, *retained])
        issues = self.scan(text, genre_profile=self.modern, include_style_hints=True,
                           style_exempt_quotes={'p1:q1': frozenset({waived})})
        self.assertEqual(issue_ids(issues), retained)
        _, voice = self.voice(self.dense, genre_profile=self.modern, include_style_hints=True,
                              style_exempt_quotes={'p1:q1': frozenset({waived})})
        self.assertEqual([i.quote_id for i in voice if i.rule_id == VOICE_SHORT], ['p1:q1', 'p2:q1', 'p3:q1'])

    def test_old_nonempty_quote_collections_do_not_imply_broad_exemptions(self):
        for values in ('p1:q1', {'p1:q1'}, ('p1:q1',)):
            with self.subTest(values=values):
                with self.assertRaises(ValueError):
                    self.scan(self.dense, style_exempt_quotes=values)
                with self.assertRaises(ValueError):
                    self.voice(self.dense, style_exempt_quotes=values)

    def test_western_profile_preserves_its_declared_disabled_rules(self):
        genre = get_genre_profile('western_fantasy')
        text = ['乔宁说：“听着，伙计。”', '乔宁说：“进去是非常危险的。”', '乔宁说：“在门后头。”', '乔宁说：“挺扛冻。”']
        issues = self.scan(text, genre_profile=genre, include_style_hints=True)
        self.assertEqual(issue_ids(issues), [SYNTHETIC])
        self.assertTrue(all(i.severity == 'REVIEW' for i in issues))


if __name__ == '__main__':
    unittest.main()

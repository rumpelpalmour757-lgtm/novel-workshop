#!/usr/bin/env python3
"""r5.51: who knows what is checked by story time (fact_guard.py check, attributes known_by.<person>).

The author's report of 11-07: chapter 2 says A only got the news at 10:00; chapter 3 flashes back to 09:00 and writes
that A already knows; r5.50 cited the 10:00 record and answered CONSISTENT. With the learning moment later in the same
chapter it answered NO_BASELINE. The cases in fixtures/knowledge-time/ cover cross-chapter flashbacks, order inside a
chapter, what only the reader knows, a reasonable false belief, drafts and candidates mixed in, and several changes of
state: the six groups the author asked for, written as regression cases in the spirit of NCP-Bench's ledger-based
conflict checks (NCP-Bench itself covers only linear narratives and has no flashback cases). Cases R1-R13, S1-S6,
T1-T19 and V1-V27 come from the three r5.51 review rounds and their re-checks. Each case says what r5.51 must answer.

These tests show the knowledge check follows story time; they do not show anything about the prose. Cases marked
"limitation" pin down what the program still cannot see: something recorded wrongly at extraction time.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SCRIPT = ROOT / "skills" / "novel-workshop" / "scripts" / "fact_guard.py"
CASES = Path(__file__).resolve().parent / "fixtures" / "knowledge-time"


def build_case(spec, out):
    """A ledger, a claims file, the accepted chapters (with their real SHA-256) and the candidate, from one spec."""
    out = Path(out)
    (out / "chapters").mkdir(parents=True, exist_ok=True)
    chapters = {}
    for key, chapter in spec["chapters"].items():
        name = "第%02d章.md" % int(key)
        data = chapter["text"].encode("utf-8")
        (out / "chapters" / name).write_bytes(data)
        entry = {"status": chapter["status"], "file": name, "sha256": hashlib.sha256(data).hexdigest()}
        if "story_time" in chapter:
            entry["story_time"] = chapter["story_time"]
        chapters[key] = entry
    candidate = spec["candidate"]
    name = "第%02d章-候选.md" % candidate["chapter"]
    data = candidate["text"].encode("utf-8")
    (out / name).write_bytes(data)
    ledger = {"schema": "fact-ledger/1", "entities": spec["entities"], "chapters": chapters, "facts": spec["facts"]}
    (out / "ledger.json").write_bytes(json.dumps(ledger, ensure_ascii=False, indent=1).encode("utf-8"))
    claims = {"schema": "fact-claims/1", "chapter": candidate["chapter"], "candidate": name,
              "candidate_sha256": hashlib.sha256(data).hexdigest(), "extracted_by": "human", "claims": spec["claims"]}
    if "story_time" in spec:
        claims["story_time"] = spec["story_time"]
    (out / "claims.json").write_bytes(json.dumps(claims, ensure_ascii=False, indent=1).encode("utf-8"))
    return out


def run_check(script, folder):
    result = subprocess.run([sys.executable, "-I", "-B", str(script), "check", "ledger.json", "claims.json",
                             "--chapters-dir", "chapters"], cwd=str(folder), capture_output=True, text=True,
                            encoding="utf-8")
    return result.returncode, json.loads(result.stdout)


def load_cases():
    return {path.stem: json.loads(path.read_text(encoding="utf-8")) for path in sorted(CASES.glob("*.json"))}


class KnowledgeByStoryTime(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def run_case(self, name):
        spec = load_cases()[name]
        code, report = run_check(SCRIPT, build_case(spec, self.tmp / name))
        self.assertNotEqual(code, 2, json.dumps(report, ensure_ascii=False))
        return spec, code, report, {r["claim"]: r for r in report["results"]}

    def test_every_case_gets_the_expected_answer(self):
        cases = load_cases()
        self.assertGreaterEqual(len(cases), 18)
        groups = {spec["group"] for spec in cases.values()}
        for group in ("跨章倒叙", "同章先后", "读者先知", "合理误信", "废稿混入", "多次状态变更"):
            self.assertIn(group, groups)
        for name in cases:
            with self.subTest(case=name):
                spec, code, report, by = self.run_case(name)
                expect = spec["expect"]
                self.assertEqual(report["status"], expect["status"])
                self.assertEqual({cid: by[cid]["status"] for cid in expect["claims"]}, expect["claims"])
                self.assertEqual(code, 1 if expect["status"] in ("CONFLICTS", "STALE", "LEDGER_PROBLEMS") else 0)
                for cid, phrase in expect.get("notes", {}).items():
                    self.assertTrue(any(phrase in note for note in by[cid].get("notes", [])), (cid, by[cid]))
                if "watch_note" in expect:
                    watch = next(w for w in report["watch"] if w["id"] == expect["watch_note"])
                    self.assertIn("才成立", watch["reason"])
                for item in expect.get("watch", []):
                    hits = [w for w in report["watch"] if ("id" not in item or w["id"] == item["id"]) and item["phrase"] in w["reason"]]
                    self.assertTrue(hits, (item, report["watch"]))
                for cid, phrase in expect.get("reason", {}).items():
                    self.assertIn(phrase, by[cid]["reason"])

    def test_the_two_reported_cases(self):
        # Case 1 (cross-chapter flashback): the 10:00 learning moment of chapter 2 does not support 09:00.
        _, code, report, by = self.run_case("A1-cross-chapter-flashback")
        self.assertEqual((code, report["status"], by["C-03-01"]["status"]), (1, "CONFLICTS", "TIME_CONFLICT"))
        self.assertEqual(by["C-03-01"]["baseline"]["id"], "F-02-01")
        self.assertIn("10:00", by["C-03-01"]["reason"])
        self.assertIn("09:00", by["C-03-01"]["reason"])
        # Case 2 (later in the same chapter): the chapter contradicts itself; the candidate's own learning moment is
        # named, never used as evidence for consistency.
        _, code, report, by = self.run_case("B1-same-chapter-later-learning")
        self.assertEqual((code, report["status"], by["C-03-01"]["status"]), (1, "CONFLICTS", "TIME_CONFLICT"))
        self.assertIn("C-03-02", by["C-03-01"]["reason"])
        self.assertIsNone(by["C-03-01"]["baseline"])

    def test_later_evidence_never_supports_consistent(self):
        for name in ("A1-cross-chapter-flashback", "A2-flashback-later-evidence-only", "E1-abandoned-draft-earlier",
                     "F1-several-changes"):
            with self.subTest(case=name):
                _, _, report, _ = self.run_case(name)
                for result in report["results"]:
                    if result["status"] != "CONSISTENT" or not result["attribute"].startswith("known_by."):
                        continue
                    self.assertIn("之前", result["reason"], result)

    def test_chapter_order_alone_is_pending_and_declared_story_time_settles_it(self):
        _, _, report, by = self.run_case("A4-chapter-order-only")
        self.assertEqual(by["C-03-01"]["status"], "KNOWLEDGE_PENDING")
        self.assertIn("F-C-03-01", {item["id"] for item in report["review_items"]})
        self.assertIn("待核", by["C-03-01"]["reason"])
        _, _, _, by = self.run_case("A5-chapter-story-time-declared")
        self.assertEqual(by["C-03-01"]["status"], "CONSISTENT")

    def test_guesses_beliefs_reader_knowledge_and_drafts_are_not_evidence(self):
        _, _, _, by = self.run_case("C1-reader-knows-first")
        self.assertEqual(by["C-03-01"]["status"], "NO_BASELINE")
        _, _, _, by = self.run_case("D1-reasonable-false-belief")
        self.assertEqual(by["C-03-01"]["status"], "CONSISTENT")  # acting on a false belief is not an error
        self.assertEqual(by["C-03-02"]["status"], "NO_BASELINE")
        self.assertEqual(by["C-03-03"]["status"], "UNSUPPORTED")  # hearsay is not the moment of learning
        _, _, _, by = self.run_case("E2-candidate-only")
        self.assertEqual(by["C-03-01"]["status"], "NO_BASELINE")

    def test_reader_knowledge_follows_reading_order(self):
        # known_by.读者 is what the reader has been told by that chapter: the chapter order is the right order for it.
        spec = load_cases()["C1-reader-knows-first"]
        spec["claims"] = [{"id": "R-1", "entity": "event:taken", "attribute": "known_by.读者", "value": True,
                           "basis": "text_statement", "quote": "他早就知道铜匣被人取走了"}]
        code, report = run_check(SCRIPT, build_case(spec, self.tmp / "reader"))
        self.assertEqual(report["results"][0]["status"], "CONSISTENT")

    def test_a_string_change_on_a_knowledge_fact_is_invalid_input(self):
        spec = load_cases()["A1-cross-chapter-flashback"]
        spec["facts"][0]["change"] = "true"
        folder = build_case(spec, self.tmp / "string-change")
        result = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT), "check", "ledger.json", "claims.json"],
                                cwd=str(folder), capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(result.returncode, 2)
        self.assertIn("change must be true or false", result.stdout)

    def test_verdicts_do_not_depend_on_the_order_of_facts_or_claims(self):
        # r5.51, third review: the same facts and claims listed in another order must get the same verdicts.
        for name, spec in load_cases().items():
            with self.subTest(case=name):
                _, report = run_check(SCRIPT, build_case(spec, self.tmp / (name + "-a")))
                turned = dict(spec, facts=list(reversed(spec["facts"])), claims=list(reversed(spec["claims"])))
                _, other = run_check(SCRIPT, build_case(turned, self.tmp / (name + "-b")))
                self.assertEqual(report["status"], other["status"])
                self.assertEqual({r["claim"]: r["status"] for r in report["results"]},
                                 {r["claim"]: r["status"] for r in other["results"]})

    def test_reasons_read_cleanly(self):
        for name in ("T1-learns-now-after-knowing-at-eight", "F2-learns-again", "A1-cross-chapter-flashback"):
            _, _, report, _ = self.run_case(name)
            for result in report["results"]:
                self.assertNotIn("已经已经", result["reason"])
                self.assertNotIn("） 写", result["reason"])

    def test_bad_story_time_is_invalid_input(self):
        spec = load_cases()["A5-chapter-story-time-declared"]
        spec["story_time"] = {"from": "D2 10:00", "to": "09:00"}
        folder = build_case(spec, self.tmp / "bad")
        result = subprocess.run([sys.executable, "-I", "-B", str(SCRIPT), "check", "ledger.json", "claims.json"],
                                cwd=str(folder), capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(result.returncode, 2)
        self.assertIn("story_time", result.stdout)


class Docs(unittest.TestCase):
    def test_the_rule_is_written_where_the_ledger_is_explained(self):
        text = (ROOT / "skills" / "novel-workshop" / "references" / "continuity.md").read_text(encoding="utf-8")
        for phrase in ("故事时间", "KNOWLEDGE_PENDING", "story_time", "known_by.读者", "只知道章节先后"):
            self.assertIn(phrase, text)
        template = json.loads((ROOT / "skills" / "novel-workshop" / "assets" / "fact-claims-template.json").read_text(encoding="utf-8"))
        self.assertIn("story_time", template["note"])


if __name__ == "__main__":
    unittest.main()

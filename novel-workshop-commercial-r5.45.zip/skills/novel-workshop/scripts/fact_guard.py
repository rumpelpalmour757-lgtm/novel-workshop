#!/usr/bin/env python3
"""Compare declared story-fact claims with an accepted fact ledger.

The tool never reads prose for meaning. A person or model extracts claims from a
candidate chapter (with quotes); this script checks them against facts from
accepted chapters, keeps records, beliefs and plans apart from what actually
happened, and lists later chapters to re-check after an earlier one changes.

Facts marked "persist": true (an injury, a narrow passage, rising water, who holds
an object, who knows what) are listed by `check` whenever a later chapter mentions
the entity and no claim answers that state: the reviewer must say how the chapter
deals with it. The tool still does not judge whether it does.

Every claim has its own id: written ids must be nonempty strings, unique in the
claims file (a repeated id is invalid input); a claim without one gets c<position>,
moved aside when another claim already uses that name.

Commands: status, check, scan, impact.  Exit codes: 0 no blocking result,
1 conflicts/unsupported/stale binding/ledger problems, 2 invalid input.
"""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

LEDGER_SCHEMA = "fact-ledger/1"
CLAIMS_SCHEMA = "fact-claims/1"
BASELINE_LAYERS = {"accepted", "author_confirmed"}
LAYERS = BASELINE_LAYERS | {"candidate", "abandoned", "summary", "plan"}
DIRECT = {"witnessed_action", "text_statement", "author_confirmed"}
INDIRECT = {"record", "record_absence", "testimony", "inference", "plan", "summary"}
UNKNOWN = {"unknown", "未知", "待定", "不明"}
# Attributes in these namespaces describe what a record says or what someone
# believes. They may rest on indirect evidence; plain attributes may not.
REPORTED = ("record.", "belief.", "claim.")
TIME = re.compile(r"^(?:D(\d+)\s+)?(\d{1,2}):(\d{2})$")


class FactError(ValueError):
    pass


def need(condition, message):
    if not condition:
        raise FactError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def unique_keys(items):
    """A repeated key in one JSON object would silently keep only its last value; refuse it."""
    value = {}
    for key, item in items:
        need(key not in value, "repeated JSON key %r in one object; write each key once" % key)
        value[key] = item
    return value


def load_json(path):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"), object_pairs_hook=unique_keys)
    except FileNotFoundError as exc:
        raise FactError("file not found: " + str(path)) from exc


def claim_ids(claims):
    """One id per claim. Written ids must be nonempty strings and unique in the file; a claim without an id gets
    c<position>, moved aside (c2-auto, c2-auto2 ...) when that name is already written on another claim, so a review
    item never stands for two claims (r5 review F02)."""
    written = {}
    for index, claim in enumerate(claims, 1):
        if isinstance(claim, dict) and "id" in claim:
            cid = claim["id"]
            need(isinstance(cid, str) and bool(cid.strip()),
                 "claim %d: id must be a nonempty string (got %s)" % (index, json.dumps(cid, ensure_ascii=False)))
            need(cid not in written, "claims %d and %d both use the id %s; every claim needs its own id, otherwise one "
                 "review decision would cover both" % (written.get(cid, 0), index, json.dumps(cid, ensure_ascii=False)))
            written[cid] = index
    ids, taken = [], set(written)
    for index, claim in enumerate(claims, 1):
        if isinstance(claim, dict) and "id" in claim:
            ids.append(claim["id"])
            continue
        base = value = "c%d" % index
        number = 1
        while value in taken:
            value = base + "-auto" + ("" if number == 1 else str(number))
            number += 1
        taken.add(value)
        ids.append(value)
    return ids


def text_of(value):
    return isinstance(value, str) and bool(value.strip())


def parse_time(value):
    if value is None:
        return None
    match = TIME.match(str(value).strip())
    need(match, "time must look like 08:30 or D2 08:30: " + str(value))
    need(int(match.group(2)) < 24 and int(match.group(3)) < 60,
         "time hour must be 00-23 and minute 00-59: " + str(value))
    return (int(match.group(1) or 0), int(match.group(2)) * 60 + int(match.group(3)))


def load_ledger(path):
    raw = load_json(path)
    # Accept a project_state.py snapshot that keeps the ledger at data.facts.
    if isinstance(raw, dict) and isinstance(raw.get("data"), dict) and "facts" in raw["data"]:
        location = Path(__file__).with_name("project_state.py")
        spec = importlib.util.spec_from_file_location("fact_project_state", location)
        state_api = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(state_api)
        try:
            state_api._validate(raw)
        except (state_api.StateError, ValueError) as exc:
            raise FactError("Invalid project state snapshot: " + str(exc)) from exc
        raw = raw["data"]["facts"]
    need(isinstance(raw, dict) and raw.get("schema") == LEDGER_SCHEMA, "ledger schema must be " + LEDGER_SCHEMA)
    entities = raw.get("entities", {})
    need(isinstance(entities, dict), "entities must be an object")
    for key, entity in entities.items():
        need(isinstance(entity, dict) and text_of(entity.get("name")), "entity %s needs a name" % key)
        aliases = entity.setdefault("aliases", [entity["name"]])
        need(isinstance(aliases, list) and all(text_of(a) for a in aliases), "entity %s aliases must be strings" % key)
    chapters = raw.get("chapters", {})
    need(isinstance(chapters, dict), "chapters must be an object")
    for key, chapter in chapters.items():
        need(str(key).isdigit() and isinstance(chapter, dict) and chapter.get("status") in LAYERS,
             "chapter %s needs a numeric key and a valid status" % key)
    facts = raw.get("facts", [])
    need(isinstance(facts, list), "facts must be a list")
    seen = set()
    for order, fact in enumerate(facts):
        need(isinstance(fact, dict), "each fact must be an object")
        for field in ("id", "entity", "attribute", "source"):
            need(text_of(fact.get(field)), "fact %s needs %s" % (fact.get("id", order), field))
        need(fact["id"] not in seen, "duplicate fact id " + fact["id"])
        seen.add(fact["id"])
        need(fact["entity"] in entities, "fact %s names an undeclared entity" % fact["id"])
        need("value" in fact, "fact %s needs value" % fact["id"])
        need(type(fact.get("chapter")) is int and fact["chapter"] >= 0, "fact %s needs an integer chapter" % fact["id"])
        need(fact.get("layer") in LAYERS, "fact %s has invalid layer" % fact["id"])
        need(fact.get("basis") in DIRECT | INDIRECT, "fact %s has invalid basis" % fact["id"])
        need(isinstance(fact.get("persist", False), bool), "fact %s: persist must be true or false" % fact["id"])
        fact["_time"] = parse_time(fact.get("time"))
        fact["_order"] = order
    return {"entities": entities, "chapters": chapters, "facts": facts}


def is_unknown(value):
    return isinstance(value, str) and value.strip().lower() in UNKNOWN


def same(left, right):
    return json.dumps(left, ensure_ascii=False, sort_keys=True) == json.dumps(right, ensure_ascii=False, sort_keys=True)


def reported(attribute):
    return attribute.startswith(REPORTED)


def author_confirmation(fact):
    """An explicitly sourced author decision does not depend on draft status.

    Source text is a declaration, not proof of authorship; an editor must verify
    the cited author decision. Requiring both fields prevents a mislabeled
    accepted prose fact from silently receiving this exception.
    """
    return (fact["layer"] == "author_confirmed" and fact["basis"] == "author_confirmed"
            and text_of(fact.get("source")))


def validate_baseline(ledger, before_chapter=None, chapters_dir=None):
    """Validate exactly the facts which could be used for this comparison.

    status checks all baseline layers; check uses only earlier chapters. Bad
    facts remain visible as problems and cannot become an apparent match by
    falling back to an older value for the same entity/attribute.
    """
    def in_scope(number):
        return before_chapter is None or number < before_chapter

    base = sorted((f for f in ledger["facts"] if f["layer"] in BASELINE_LAYERS
                   and in_scope(f["chapter"])), key=lambda f: (f["chapter"], f["_order"]))
    chapter_files = []
    if chapters_dir is not None:
        for key, info in sorted(ledger["chapters"].items(), key=lambda kv: int(kv[0])):
            if info["status"] not in BASELINE_LAYERS or not in_scope(int(key)):
                continue
            issue = {"chapter": int(key), "file": info.get("file")}
            if not text_of(info.get("file")) or not text_of(info.get("sha256")):
                issue.update(problem="CHAPTER_BINDING_MISSING", detail="请求核对原章，但该章缺少文件名或采纳时的 SHA-256。")
            else:
                root = Path(chapters_dir).resolve()
                path = (root / info["file"]).resolve()
                if Path(info["file"]).is_absolute() or not path.is_relative_to(root):
                    issue.update(problem="CHAPTER_PATH_OUTSIDE_ROOT", detail="原章路径超出指定正文目录，拒绝读取。")
                elif not path.is_file():
                    issue.update(problem="UNAVAILABLE", detail="无法读取该章原文，不能核实事实来源版本。")
                elif sha(path.read_bytes()) != info["sha256"]:
                    issue.update(problem="TEXT_CHANGED_SINCE_ACCEPTED", detail="原章已不是采纳时的版本，需要重新核对账本。")
            if "problem" in issue:
                chapter_files.append(issue)
    file_issues = {entry["chapter"]: entry for entry in chapter_files}
    problems, last = [], {}
    for fact in base:
        def problem(code, detail):
            problems.append({"fact": fact["id"], "chapter": fact["chapter"], "entity": fact["entity"],
                             "attribute": fact["attribute"], "problem": code, "detail": detail})

        confirmed = author_confirmation(fact)
        chapter_info = ledger["chapters"].get(str(fact["chapter"]))
        if fact["layer"] == "author_confirmed" and not confirmed:
            problem("AUTHOR_CONFIRMATION_REQUIRED", "author_confirmed 事实需要 basis=author_confirmed，并在 source 明示作者确认来源。")
        if not confirmed:
            if chapter_info is None:
                problem("SOURCE_CHAPTER_UNLISTED", "来源章未登记，不能确认正文已采纳；请补章节状态或标为非基线层。")
            elif chapter_info["status"] not in BASELINE_LAYERS:
                problem("SOURCE_CHAPTER_NOT_ACCEPTED", "来源章状态是 %s，该事实不能继续作为已采纳正文基线。" % chapter_info["status"])
            if fact["chapter"] in file_issues:
                issue = file_issues[fact["chapter"]]
                problem(issue["problem"], issue["detail"])
        if fact["basis"] in INDIRECT and not reported(fact["attribute"]) and not is_unknown(fact["value"]):
            problem("INDIRECT_BASIS_ACCEPTED", "已采纳的实际状态只靠%s支撑；应改记为 record./belief. 属性或补直接证据。" % fact["basis"])
        key = (fact["entity"], fact["attribute"])
        prior = last.get(key)
        if prior and not same(prior["value"], fact["value"]) and fact.get("change") is not True:
            problem("UNEXPLAINED_CHANGE", "与 %s 的值不同，但没有标为 change。" % prior["id"])
        last[key] = fact
    blocked_keys = {(p["entity"], p["attribute"]) for p in problems}
    usable = [f for f in base if (f["entity"], f["attribute"]) not in blocked_keys]
    return {"facts": usable, "problems": problems, "chapter_files": chapter_files}


def baseline(ledger, chapter):
    return validate_baseline(ledger, before_chapter=chapter)["facts"]


def latest(facts, entity, attribute):
    hits = [f for f in facts if f["entity"] == entity and f["attribute"] == attribute]
    return hits[-1] if hits else None


def public(fact):
    return {k: v for k, v in fact.items() if not k.startswith("_")} if fact else None


def status(ledger, chapters_dir=None):
    listed = sorted(int(k) for k in ledger["chapters"])
    accepted = sorted(int(k) for k, v in ledger["chapters"].items() if v["status"] in BASELINE_LAYERS)
    others = sorted(int(k) for k, v in ledger["chapters"].items() if v["status"] not in BASELINE_LAYERS)
    # Progress is the unbroken run of accepted chapters that starts at the first
    # listed chapter. It stops before a chapter that is not accepted and before a
    # chapter that is missing from the ledger (status unknown); the highest
    # chapter number on file is never taken as progress by itself.
    through = None
    for number in range(listed[0], listed[-1] + 1) if listed else []:
        if number not in accepted:
            break
        through = number
    gaps = [n for n in range(listed[0], listed[-1] + 1) if n not in listed] if listed else []
    validation = validate_baseline(ledger, chapters_dir=chapters_dir)
    problems, stale = validation["problems"], validation["chapter_files"]
    blocking = bool(problems or stale)
    return {"status": "LEDGER_PROBLEMS" if blocking else "OK",
            "accepted_from_chapter": listed[0] if listed and through is not None else None,
            "accepted_through_chapter": through,
            "accepted_chapters": accepted, "non_accepted_chapters": others, "unlisted_chapters_in_range": gaps,
            "note": ("进度只算从账上第一章起连续采纳的部分：遇到未采纳或未登记（状态未知）的章节就停，不按最大章号；"
                     "账上第一章之前的章节状态也未知；候选、摘要和计划不进入基线。"),
            "problems": problems, "chapter_files": stale}


def check(ledger, claims_path, candidate_override=None, chapters_dir=None):
    claims = load_json(claims_path)
    need(isinstance(claims, dict) and claims.get("schema") == CLAIMS_SCHEMA, "claims schema must be " + CLAIMS_SCHEMA)
    need(type(claims.get("chapter")) is int and claims["chapter"] >= 0, "claims need a nonnegative integer chapter")
    need(isinstance(claims.get("claims"), list), "claims must be a list")
    need(text_of(claims.get("extracted_by")), "claims need extracted_by (self_check / independent_agent / human)")
    base_dir = Path(claims_path).resolve().parent
    candidate_path = Path(candidate_override) if candidate_override else base_dir / str(claims.get("candidate", ""))
    need(candidate_path.is_file(), "candidate text not found: " + str(candidate_path))
    data = candidate_path.read_bytes()
    actual = sha(data)
    text = data.decode("utf-8-sig")
    binding = {"path": str(candidate_path), "declared_sha256": claims.get("candidate_sha256"), "actual_sha256": actual,
               "bound": claims.get("candidate_sha256") == actual}
    validation = validate_baseline(ledger, before_chapter=claims["chapter"], chapters_dir=chapters_dir)
    facts = validation["facts"]
    problems_by_key = {}
    for problem in validation["problems"]:
        problems_by_key.setdefault((problem["entity"], problem["attribute"]), []).append(problem)
    results = []
    for cid, claim in zip(claim_ids(claims["claims"]), claims["claims"]):
        try:
            need(isinstance(claim, dict), "claim must be an object")
            for field in ("entity", "attribute", "basis", "quote"):
                need(text_of(claim.get(field)), "claim %s needs %s" % (cid, field))
            need("value" in claim, "claim %s needs value" % cid)
            need(claim["entity"] in ledger["entities"], "claim %s names an undeclared entity" % cid)
            need(claim["basis"] in DIRECT | INDIRECT, "claim %s has invalid basis" % cid)
            when = parse_time(claim.get("time"))
        except FactError as exc:
            results.append({"claim": cid, "status": "INVALID", "reason": str(exc)})
            continue
        result = {"claim": cid, "entity": claim["entity"], "attribute": claim["attribute"], "value": claim["value"],
                  "basis": claim["basis"], "quote_found": claim["quote"] in text}
        prior = latest(facts, claim["entity"], claim["attribute"])
        result["baseline"] = public(prior)
        physical = not reported(claim["attribute"])
        definite = not is_unknown(claim["value"])
        if not result["quote_found"]:
            result.update(status="QUOTE_NOT_FOUND", reason="引文不在本版候选稿中，无法定位该主张。")
        elif physical and definite and claim["basis"] in INDIRECT:
            result.update(status="UNSUPPORTED",
                          reason="把%s当成实际发生的事。单据、录入时间、转述、推断或计划只能写成“记录显示／某人认为”，"
                                 "不能直接改写事实；改记为 record./belief. 属性或补出直接证据。" % claim["basis"])
        elif (claim["entity"], claim["attribute"]) in problems_by_key:
            result.update(status="LEDGER_PROBLEMS", reason="该属性的前文基线存在账本问题，先修正来源或事实链再核对。",
                          ledger_problems=problems_by_key[(claim["entity"], claim["attribute"])])
        elif prior is None:
            result.update(status="NO_BASELINE", reason="已采纳前文没有这项事实，程序无法核对，需要编辑或作者裁定。")
        elif same(prior["value"], claim["value"]):
            result.update(status="CONSISTENT", reason="与已采纳前文一致。")
        elif claim.get("change") is True and claim["basis"] in DIRECT:
            result.update(status="CHANGE_PROPOSED",
                          reason="本章用直接证据写出状态变化；作者采纳后才能进入基线。")
        elif is_unknown(prior["value"]) and definite:
            result.update(status="UNSUPPORTED",
                          reason="前文此项为未知（例如“没有归还记录”），本章没有标为变化或缺少直接证据，不能直接写成定论。")
        else:
            result.update(status="CONFLICT", reason="与已采纳前文 %s 的值不同，且没有作为有直接证据的变化写出。" % prior["id"])
        also = []
        if result["status"] == "UNSUPPORTED" and prior and not is_unknown(prior["value"]) and not same(prior["value"], claim["value"]):
            also.append("同时与已采纳前文 %s（%s）不一致。" % (prior["id"], prior["value"]))
        if when and claim["attribute"] == "first_seen":
            earlier = [f for f in facts if f["entity"] == claim["entity"] and f["_time"] and f["_time"] < when
                       and f["attribute"] in ("first_seen", "seen_at", "present_at")]
            if earlier:
                note = "已采纳前文更早已见到该物件（%s，%s），首次出现时间不能晚于它。" % (earlier[0]["id"], earlier[0].get("time"))
                if result["status"] in ("CONSISTENT", "NO_BASELINE", "CHANGE_PROPOSED"):
                    result.update(status="TIME_CONFLICT", baseline=public(earlier[0]), reason=note)
                else:
                    also.append(note)
        if also:
            result["also"] = also
        results.append(result)
    counts = {}
    for item in results:
        counts[item["status"]] = counts.get(item["status"], 0) + 1
    blocking = {"CONFLICT", "UNSUPPORTED", "TIME_CONFLICT", "QUOTE_NOT_FOUND", "INVALID"}
    if validation["problems"] or validation["chapter_files"]:
        overall = "LEDGER_PROBLEMS"
    elif not binding["bound"]:
        overall = "STALE"
    elif any(r["status"] in blocking for r in results):
        overall = "CONFLICTS"
    elif any(r["status"] in ("NO_BASELINE", "CHANGE_PROPOSED") for r in results):
        overall = "NEEDS_HUMAN"
    elif results:
        overall = "CONSISTENT"
    else:
        overall = "UNTESTED"
    review_items = [{"id": "F-" + r["claim"], "status": r["status"], "reason": r["reason"]}
                    for r in results if r["status"] in ("NO_BASELINE", "CHANGE_PROPOSED")]
    watch = watched_states(ledger, facts, claims["claims"], text)
    review_items.extend({"id": w["id"], "status": "WATCH", "reason": w["reason"]} for w in watch)
    return {"tool": "fact_guard", "command": "check", "status": overall, "chapter": claims["chapter"],
            "extracted_by": claims["extracted_by"], "candidate": binding,
            "baseline_rule": "仅比较 chapter 小于 %d 且通过来源与事实链有效性检查的 accepted/author_confirmed 事实" % claims["chapter"],
            "ledger_problems": validation["problems"], "chapter_files": validation["chapter_files"],
            "counts": counts, "results": results, "watch": watch, "review_items": review_items,
            "limits": ("只核对声明的主张，不能发现没有提取的矛盾；主张是否从正文正确提取仍需人工或独立审读。"
                       "持续状态只按名字和别名列出，本章是否照顾到它要由审稿判断。")}


def watched_states(ledger, facts, claims, text):
    """Persistent baseline states whose entity the candidate mentions and no claim answers.

    `facts` is the validated baseline (earlier accepted chapters only), so a state
    whose source chapter is not accepted is never watched as if it were settled.
    """
    answered = {(c.get("entity"), c.get("attribute")) for c in claims if isinstance(c, dict)}
    latest_states = {}
    for fact in facts:  # baseline facts are in chapter order; the last one per state wins
        latest_states[(fact["entity"], fact["attribute"])] = fact
    lines = text.splitlines()
    watch = []
    for (entity, attribute), fact in sorted(latest_states.items(), key=lambda kv: (kv[1]["chapter"], kv[1]["_order"])):
        if not fact.get("persist") or (entity, attribute) in answered:
            continue
        aliases = ledger["entities"][entity]["aliases"]
        where = sorted({number for number, line in enumerate(lines, 1) if any(alias in line for alias in aliases)})
        if not where:
            continue
        value = fact["value"] if isinstance(fact["value"], str) else json.dumps(fact["value"], ensure_ascii=False)
        name = ledger["entities"][entity]["name"]
        watch.append({"id": "W-" + fact["id"], "fact": fact["id"], "entity": entity, "attribute": attribute,
                      "value": fact["value"], "since_chapter": fact["chapter"], "source": fact["source"], "lines": where[:10],
                      "reason": "持续状态：%s 的 %s 是“%s”（%s，第%d章起）。本章第 %s 行提到%s。行动、路线、交接或谁知道什么，"
                                "是否与这个状态一致？一致就写明依据；不一致就改稿，或作为变化写成主张交作者裁定。"
                                % (name, attribute, value, fact["source"], fact["chapter"],
                                   "、".join(str(n) for n in where[:10]), name)})
    return watch


def scan(ledger, candidate):
    text = Path(candidate).read_bytes().decode("utf-8-sig")
    lines = text.splitlines()
    hits = []
    for key, entity in ledger["entities"].items():
        for alias in entity["aliases"]:
            for number, line in enumerate(lines, 1):
                for match in re.finditer(re.escape(alias), line):
                    hits.append({"entity": key, "alias": alias, "line": number, "column": match.start() + 1,
                                 "context": line[max(0, match.start() - 15):match.end() + 15]})
    hits.sort(key=lambda h: (h["line"], h["column"]))
    return {"tool": "fact_guard", "command": "scan", "candidate": str(candidate),
            "sha256": sha(Path(candidate).read_bytes()), "hits": hits,
            "note": "每处命中都要在 claims 里给出主张，或在审稿中说明为何不涉及硬事实。别名之外的写法可能漏掉。"}


def impact(ledger, changed_chapter, entities=None, chapters_dir=None):
    changed = [f for f in ledger["facts"] if f["chapter"] == changed_chapter]
    touched = set(entities or []) | {f["entity"] for f in changed}
    ids = {f["id"] for f in changed}
    later = [f for f in ledger["facts"] if f["chapter"] > changed_chapter and f["layer"] in BASELINE_LAYERS
             and (f["entity"] in touched or ids & set(f.get("depends_on", [])))]
    by_chapter = {}
    for fact in later:
        by_chapter.setdefault(fact["chapter"], []).append({"fact": fact["id"], "entity": fact["entity"],
                                                          "attribute": fact["attribute"], "value": fact["value"],
                                                          "source": fact["source"]})
    text_hits, unavailable = [], []
    if chapters_dir:
        for key, info in sorted(ledger["chapters"].items(), key=lambda kv: int(kv[0])):
            number = int(key)
            if number <= changed_chapter:
                continue
            path = Path(chapters_dir) / info.get("file", "")
            if not info.get("file") or not path.is_file():
                unavailable.append(number)
                continue
            for line_no, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
                for key2 in sorted(touched):
                    for alias in ledger["entities"][key2]["aliases"]:
                        if alias in line:
                            text_hits.append({"chapter": number, "file": info["file"], "line": line_no,
                                              "entity": key2, "alias": alias})
    chapters = sorted(set(by_chapter) | {h["chapter"] for h in text_hits})
    return {"tool": "fact_guard", "command": "impact", "changed_chapter": changed_chapter,
            "entities": sorted(touched), "status": "REGRESSION_REQUIRED" if chapters else "NO_DECLARED_DEPENDENTS",
            "chapters_to_recheck": chapters, "ledger_dependents": by_chapter, "text_hits": text_hits,
            "unavailable_chapters": unavailable,
            "note": "列出的是需要回读的位置，不是结论；未取得的章节标为受限，不能宣称后文已核对。"}


def utf8_stdio():
    """Reports are UTF-8 on every platform; a Windows pipe would otherwise use the local code page."""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    commands = parser.add_subparsers(dest="command", required=True)
    one = commands.add_parser("status")
    one.add_argument("ledger", type=Path)
    one.add_argument("--chapters-dir", type=Path)
    two = commands.add_parser("check")
    two.add_argument("ledger", type=Path)
    two.add_argument("claims", type=Path)
    two.add_argument("--chapters-dir", type=Path)
    three = commands.add_parser("scan")
    three.add_argument("ledger", type=Path)
    three.add_argument("candidate", type=Path)
    four = commands.add_parser("impact")
    four.add_argument("ledger", type=Path)
    four.add_argument("--changed-chapter", type=int, required=True)
    four.add_argument("--entity", action="append")
    four.add_argument("--chapters-dir", type=Path)
    args = parser.parse_args()
    try:
        ledger = load_ledger(args.ledger)
        if args.command == "status":
            result = status(ledger, args.chapters_dir)
            code = 1 if result["status"] != "OK" else 0
        elif args.command == "check":
            result = check(ledger, args.claims, chapters_dir=args.chapters_dir)
            code = 1 if result["status"] in ("CONFLICTS", "STALE", "LEDGER_PROBLEMS") else 0
        elif args.command == "scan":
            result, code = scan(ledger, args.candidate), 0
        else:
            result, code = impact(ledger, args.changed_chapter, args.entity, args.chapters_dir), 0
    except (FactError, OSError, UnicodeError, ValueError) as exc:
        print(json.dumps({"status": "INPUT_ERROR", "error": str(exc)}, ensure_ascii=False))
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return code


if __name__ == "__main__":
    sys.exit(main())

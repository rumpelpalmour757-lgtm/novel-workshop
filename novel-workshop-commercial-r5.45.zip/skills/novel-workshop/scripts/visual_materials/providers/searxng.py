"""SearXNG: wide image search through an instance you run or are allowed to use (its JSON search API).

The instance must list json under search.formats in its settings.yml; otherwise it answers 403. Its limiter answers
429. Results of the images category carry url (the page), img_src (the image), thumbnail_src, title, content,
resolution, img_format, source and engine. A public instance is not a stable dependency: the config names your own.
"""
import urllib.parse

from .. import common

NAME = "searxng"


def configured(config):
    url = config["searxng"].get("url", "")
    if not url:
        return False, "searxng.url is empty: run your own instance (docker or source) and put its address here"
    if not url.startswith(("http://", "https://")):
        return False, "searxng.url must start with http:// or https://"
    return True, "instance %s" % common.clean_url(url)


def search_url(config, query, page=1):
    base = config["searxng"]["url"].rstrip("/") + "/search"
    params = {"q": query, "format": "json", "categories": config["searxng"].get("categories") or "images", "pageno": page}
    for key in ("language", "time_range", "engines"):
        if config["searxng"].get(key):
            params[key] = config["searxng"][key]
    if config["searxng"].get("safesearch") is not None:
        params["safesearch"] = config["searxng"]["safesearch"]
    return base + "?" + urllib.parse.urlencode(params)


def candidate(result, query, rank):
    image = (result.get("img_src") or "").strip()
    page = (result.get("url") or "").strip()
    if not image.startswith(("http://", "https://")) or not page.startswith(("http://", "https://")):
        return None
    width = height = None
    resolution = result.get("resolution") or ""
    parts = [p.strip() for p in resolution.replace("×", "x").split("x")]
    if len(parts) == 2 and all(p.isdigit() for p in parts):
        width, height = int(parts[0]), int(parts[1])
    thumb = (result.get("thumbnail_src") or result.get("thumbnail") or "").strip()
    title = (result.get("title") or "").strip()
    text = (result.get("content") or "").strip()
    creator = (result.get("author") or "").strip()
    # r5.37: each sighting keeps its own page (and what that page says), so merging never pairs one page's words or
    # licence with another page's address.
    return {
        "image_url": image,
        "thumbnail_url": thumb if thumb.startswith(("http://", "https://")) else "",
        "page_url": page,
        "title": title,
        "page_text": text,
        "creator": creator,
        "license": "",
        "license_url": "",
        "width": width,
        "height": height,
        "found_by": [{"provider": NAME, "query": query, "rank": rank,
                      "engine": result.get("engine") or ",".join(result.get("engines") or []),
                      "source": result.get("source") or "", "page_url": page, "title": title,
                      "page_text": text[:500], "creator": creator, "license": "", "license_url": ""}],
    }


def search(config, queries, limit, fetch=None):
    """Run each query (first page, or searxng.pages pages) until limit candidates. Returns the provider record and the
    candidates. fetch replaces common.http in tests of the failure branches."""
    fetch = fetch or common.http
    record = {"provider": NAME, "requests": [], "results": 0}
    ok, why = configured(config)
    if not ok:
        record.update(status="not_configured", error=why)
        return record, []
    found, by_url = [], {}
    statuses = []
    for query in queries:
        for page in range(1, max(1, int(config["searxng"].get("pages") or 1)) + 1):
            if len(found) >= limit:
                break
            url = search_url(config, query, page)
            entry = {"query": query, "page": page, "url": common.clean_url(url), "time": common.now()}
            try:
                response = fetch(url, config, headers={"Accept": "application/json"})
            except common.Timeout as exc:
                entry.update(status="timeout", error=str(exc))
                record["requests"].append(entry)
                statuses.append("timeout")
                continue
            except (common.NetworkError, common.TooLarge) as exc:
                entry.update(status="error", error=str(exc))
                record["requests"].append(entry)
                statuses.append("error")
                continue
            entry.update(http_status=response.status, elapsed_ms=response.elapsed_ms)
            if response.status == 403:
                entry.update(status="json_disabled", error="403: the instance does not allow format=json (add json to "
                                                            "search.formats in its settings.yml)")
            elif response.status == 429:
                entry.update(status="rate_limited", error="429: the instance's limiter refused the request")
            elif response.status != 200:
                entry.update(status="error", error="HTTP %d" % response.status)
            else:
                try:
                    data = response.json()
                    results = data.get("results") if isinstance(data, dict) else None
                    if not isinstance(results, list):
                        raise common.VisualError("no results list")
                except common.VisualError as exc:
                    entry.update(status="bad_response", error=str(exc))
                else:
                    added = 0
                    for rank, result in enumerate(results, 1):
                        if not isinstance(result, dict):
                            continue
                        item = candidate(result, query, rank)
                        if not item:
                            continue
                        if item["image_url"] in by_url:  # found again (another query or page): keep the sighting
                            known = by_url[item["image_url"]]
                            if item["found_by"][0] not in known["found_by"]:
                                known["found_by"].append(item["found_by"][0])
                        elif len(found) < limit:
                            by_url[item["image_url"]] = item
                            found.append(item)
                            added += 1
                    unresponsive = data.get("unresponsive_engines") or []
                    entry.update(status="ok" if added else "empty", results=len(results), kept=added,
                                 unresponsive_engines=[list(x) if isinstance(x, (list, tuple)) else x
                                                       for x in unresponsive][:10])
            record["requests"].append(entry)
            statuses.append(entry["status"])
    record["results"] = len(found)
    if found:
        record["status"] = "ok" if all(s in ("ok", "empty") for s in statuses) else "partial"
    else:
        record["status"] = next((s for s in ("json_disabled", "rate_limited", "timeout", "bad_response", "error")
                                 if s in statuses), "empty")
    return record, found

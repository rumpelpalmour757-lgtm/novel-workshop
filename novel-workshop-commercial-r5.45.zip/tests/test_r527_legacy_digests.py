#!/usr/bin/env python3
"""r5.27: rule registers written under r5.24 still check clean; a complete register proves both the pass and the fails.

H525-01 (review of r5.25, 2026-10-20, P2). r5.25 reads a rule file as text before hashing it (UTF-8, a leading BOM
dropped, CRLF read as LF), so that a copy saved on Windows is the same text. r5.24 hashed bytes: the whole file when
it carries no "<!-- 原文开始 -->" marker, else the bytes after the marker (looked for with LF). A register written
under r5.24 for a file with CRLF line breaks or a BOM therefore holds a digest the r5.25 rule never gives, and r5.25
reported the unchanged file as changed. r5.27 accepts such a digest only when the r5.24 rule, applied to the file as
it is now, gives exactly the registered value: the file has the same bytes as when it was registered. The result
lists those sources under sources.legacy with the digest the current rule gives, so the register can be moved over
by hand. Any change to the file still fails.

H525-02 (same review, P3). tests/test_r525_windows.py checked a register that was itself invalid ("book" for
"project", a source without a title) and only looked for the absence of "has changed"; the check as a whole was FAIL.
That fixture is valid now and the test asks for OK. Here a complete register (a rule file saved on Windows, a chapter,
an item citing both) proves the pass with exit 0 and the fails: a changed author's text, a wrong digest, a quote that
is not in the rule file, a line that does not hold its quote, a chapter missing under --texts-root.

The review's points 3 and 4, the Windows notes, are pinned in WindowsNotes.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
TOOL = SKILL / "scripts" / "rule_register.py"
MARK = "<!-- 原文开始 -->"
BODY = "门闩必须保持关闭。\n第二条保持原样。\n"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def r524_digest(data):
    """The r5.24 rule, written out here on its own: the bytes after the LF marker if they carry it, else all bytes."""
    marker = (MARK + "\n").encode("utf-8")
    return sha(data.split(marker, 1)[1] if marker in data else data)


def saved(text, crlf=False, bom=False):
    return (b"\xef\xbb\xbf" if bom else b"") + (text.replace("\n", "\r\n") if crlf else text).encode("utf-8")


VARIANTS = {"LF": {}, "CRLF": {"crlf": True}, "BOM+LF": {"bom": True}, "BOM+CRLF": {"crlf": True, "bom": True}}


def run_check(register, texts_root=None):
    command = [sys.executable, "-I", "-B", str(TOOL), "check", str(register)]
    if texts_root is not None:
        command += ["--texts-root", str(texts_root)]
    proc = subprocess.run(command, capture_output=True, text=True, encoding="utf-8")
    return proc.returncode, json.loads(proc.stdout)


class LegacyDigests(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.dir)

    def register(self, data, digest):
        (self.dir / "rules.md").write_bytes(data)
        register = {"schema": "rule-conflicts/1", "project": "旧项目", "updated": "2026-10-20",
                    "sources": [{"id": "rule", "file": "rules.md", "title": "规则", "version": "v1",
                                 "date": "2026-10-20", "status": "in_force", "sha256": digest}],
                    "texts": {}, "items": []}
        path = self.dir / "register.json"
        path.write_bytes(json.dumps(register, ensure_ascii=False).encode("utf-8"))
        return path

    def test_the_four_registers_written_under_r524_still_check_clean(self):
        # The four cases of the review's appendix B: no marker, digest of the whole file's bytes.
        for name, form in VARIANTS.items():
            with self.subTest(name):
                data = saved(BODY, **form)
                code, result = run_check(self.register(data, r524_digest(data)))
                self.assertEqual((code, result["status"], result["problems"]), (0, "OK", []), result)
                legacy = result["sources"]["legacy"]
                if name == "LF":
                    self.assertEqual(legacy, [])  # both rules give the same digest for LF without a BOM
                else:
                    self.assertEqual(legacy, [{"source": "rule", "file": "rules.md",
                                               "text_sha256": sha(BODY.encode("utf-8"))}])

    def test_files_with_the_marker_as_well(self):
        note = "> 工坊的加注。\n\n" + MARK + "\n"
        for name, form in VARIANTS.items():
            with self.subTest(name):
                data = saved(note + BODY, **form)
                code, result = run_check(self.register(data, r524_digest(data)))
                self.assertEqual((code, result["status"]), (0, "OK"), result)
                # r5.24 found the marker only in LF files; with CRLF it hashed the whole file, note included.
                listed = bool(result["sources"]["legacy"])
                self.assertEqual(listed, form.get("crlf", False), result)

    def test_any_change_to_the_file_still_fails(self):
        for name, form in VARIANTS.items():
            with self.subTest(name):
                data = saved(BODY, **form)
                path = self.register(saved(BODY.replace("关闭", "开着"), **form), r524_digest(data))
                code, result = run_check(path)
                self.assertEqual((code, result["status"]), (1, "FAIL"))
                self.assertEqual(result["sources"]["stale"], ["rule"])
                self.assertEqual(result["sources"]["legacy"], [])
                self.assertTrue(any("has changed" in p for p in result["problems"]), result["problems"])

    def test_a_digest_of_some_other_text_fails(self):
        for name, form in VARIANTS.items():
            with self.subTest(name):
                other = saved(BODY + "第三条。\n", **form)
                code, result = run_check(self.register(saved(BODY, **form), r524_digest(other)))
                self.assertEqual((code, result["sources"]["stale"]), (1, ["rule"]))

    def test_moving_an_old_register_over_to_the_listed_digest(self):
        # Saved again with other line breaks, a file registered under r5.24 has other bytes: it is reported, as r5.24
        # reported it. Copying the listed text digest into the register (by hand, while the file is still the
        # registered one) ends that: from then on any copy of the same text checks clean.
        crlf = saved(BODY, crlf=True)
        code, result = run_check(self.register(saved(BODY), r524_digest(crlf)))
        self.assertEqual(code, 1)
        code, result = run_check(self.register(crlf, r524_digest(crlf)))
        moved = result["sources"]["legacy"][0]["text_sha256"]
        for form in VARIANTS.values():
            code, result = run_check(self.register(saved(BODY, **form), moved))
            self.assertEqual((code, result["sources"]["legacy"]), (0, []), result)

    def test_the_notes_say_which_old_digests_count(self):
        continuity = (SKILL / "references" / "continuity.md").read_text(encoding="utf-8")
        for phrase in ("r5.24 及以前记的摘要", "按旧办法算出的摘要和登记值一字不差", "`sources.legacy`", "CRLF 换行当 LF"):
            self.assertIn(phrase, continuity)
        template = json.loads((SKILL / "assets" / "rule-conflicts-template.json").read_text(encoding="utf-8"))
        self.assertIn("sources.legacy", json.dumps(template, ensure_ascii=False))


class CompleteRegisterSavedOnWindows(unittest.TestCase):
    RULES = "> 工坊的加注：怎样用这份条例。\n\n" + MARK + "\n# 条例\n\n第二版。挎在身上的那只叫“行囊”。\n"
    CHAPTER = "第一章　出门\n她把行囊挎到肩上，锁了门。\n"

    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        self.texts = self.dir / "texts"
        self.texts.mkdir()
        (self.dir / "rules.md").write_bytes(saved(self.RULES, crlf=True, bom=True))
        (self.texts / "ch1.md").write_bytes(saved(self.CHAPTER, crlf=True))
        self.data = {
            "schema": "rule-conflicts/1", "project": "测试", "updated": "2026-10-20",
            "sources": [{"id": "rules-v2", "file": "rules.md", "title": "补充条例", "version": "第二版",
                         "date": "2026-10-19", "status": "in_force",
                         "sha256": sha(self.RULES.split(MARK + "\n", 1)[1].encode("utf-8"))}],
            "texts": {"C1": "ch1.md"},
            "items": [{"id": "RC-01", "title": "挎包的叫法", "kind": "mismatch",
                       "sides": [{"source": "rules-v2", "where": "第一节", "quote": "挎在身上的那只叫“行囊”"},
                                 {"text": "C1", "line": 2, "quote": "她把行囊挎到肩上"}],
                       "status": "decided", "resolution": "正文已用“行囊”，两边一致。",
                       "decided_by": {"who": "workshop", "when": "2026-10-20", "rule_applied": 2}}]}

    def tearDown(self):
        shutil.rmtree(self.dir)

    def check(self, data=None):
        path = self.dir / "rule-conflicts.json"
        path.write_bytes(json.dumps(data or self.data, ensure_ascii=False).encode("utf-8"))
        return run_check(path, self.texts)

    def test_it_passes_as_a_whole_with_exit_zero(self):
        code, result = self.check()
        self.assertEqual((code, result["status"], result["problems"]), (0, "OK", []), result)
        self.assertTrue(result["texts_checked"])
        self.assertEqual(result["sources"]["stale"], [])
        self.assertEqual(result["counts"], {"open": 0, "decided": 1, "closed": 0})

    def test_a_changed_rule_text_fails(self):
        (self.dir / "rules.md").write_bytes(saved(self.RULES.replace("第二版", "第三版"), crlf=True, bom=True))
        code, result = self.check()
        self.assertEqual((code, result["sources"]["stale"]), (1, ["rules-v2"]))

    def test_a_wrong_digest_fails(self):
        self.data["sources"][0]["sha256"] = sha(b"something else")
        code, result = self.check()
        self.assertEqual((code, result["status"]), (1, "FAIL"))
        self.assertTrue(any("has changed" in p for p in result["problems"]), result["problems"])

    def test_a_quote_that_is_not_in_the_rule_file_fails(self):
        self.data["items"][0]["sides"][0]["quote"] = "挎在身上的那只叫“背囊”"
        code, result = self.check()
        self.assertEqual(code, 1)
        self.assertTrue(any("the quote is not in rules.md" in p for p in result["problems"]), result["problems"])

    def test_a_line_without_its_quote_fails(self):
        self.data["items"][0]["sides"][1]["line"] = 1
        code, result = self.check()
        self.assertEqual(code, 1)
        self.assertTrue(any("not on line 1 of C1" in p for p in result["problems"]), result["problems"])

    def test_a_missing_chapter_fails(self):
        (self.texts / "ch1.md").unlink()
        code, result = self.check()
        self.assertEqual(code, 1)
        self.assertTrue(any("file not found under --texts-root" in p for p in result["problems"]), result["problems"])


class WindowsNotes(unittest.TestCase):
    """The same review, points 3 and 4: execution.md still said the Windows lock branch had only been simulated on
    Linux, although the author's Windows run of r5.24 had executed the killed-process lock test; and a Windows rerun
    should say which tests run and which are skipped by design."""

    def test_the_lock_note_tells_the_r524_run_from_later_versions(self):
        execution = (SKILL / "references" / "execution.md").read_text(encoding="utf-8")
        self.assertNotIn("Windows 这一支只在 Linux 上模拟测试过", execution)
        self.assertIn("2026-10-20 作者用 r5.24 跑全部测试", execution)
        self.assertIn("r5.25 以后的版本还没有在 Windows 上重跑", execution)

    def test_usage_names_the_tests_skipped_on_windows(self):
        usage = (ROOT / "USAGE.md").read_text(encoding="utf-8")
        self.assertIn("用三章演练项目的 12 项", usage)
        self.assertIn("`WindowsLikeLock` 6 项", usage)
        # The numbers in the note match the tests: twelve demo tests carry the skip marker, six tests in the class.
        import ast
        tests = Path(__file__).resolve().parent
        demo = (tests / "test_r42.py").read_text(encoding="utf-8")
        marked = [node for node in ast.walk(ast.parse(demo)) if isinstance(node, ast.FunctionDef)
                  and any(isinstance(d, ast.Name) and d.id == "NEEDS_PROJECT_STATE" for d in node.decorator_list)]
        self.assertEqual(len(marked), 12)
        portability = ast.parse((tests / "test_portability.py").read_text(encoding="utf-8"))
        lock = next(node for node in portability.body if isinstance(node, ast.ClassDef) and node.name == "WindowsLikeLock")
        self.assertEqual(len([f for f in lock.body if isinstance(f, ast.FunctionDef) and f.name.startswith("test_")]), 6)


if __name__ == "__main__":
    unittest.main()

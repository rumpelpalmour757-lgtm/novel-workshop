#!/usr/bin/env python3
"""CLI regressions for baseline validity; standard library, no shared fixture edits.

Run directly, through unittest discovery, or set NW_PACKAGE_ROOT to test another
package containing skills/novel-workshop/scripts/fact_guard.py.
"""

import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


PACKAGE_ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SCRIPT = PACKAGE_ROOT / "skills" / "novel-workshop" / "scripts" / "fact_guard.py"


class FactBaselineRepair(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.chapters = self.root / "chapters"
        self.chapters.mkdir()
        for number, body in ((1, "铜匣由甲保管。\n"), (2, "甲还在库房。\n"), (3, "铜匣由甲保管。\n")):
            (self.chapters / (str(number) + ".md")).write_bytes((body).encode("utf-8"))
        self.ledger = {
            "schema": "fact-ledger/1",
            "entities": {"box": {"name": "铜匣", "aliases": ["铜匣"]}},
            "chapters": {
                str(number): {"status": "accepted" if number < 3 else "candidate", "file": str(number) + ".md",
                              "sha256": self.sha(self.chapters / (str(number) + ".md"))}
                for number in (1, 2, 3)
            },
            "facts": [{"id": "f1", "entity": "box", "attribute": "holder", "value": "甲", "chapter": 1,
                       "layer": "accepted", "basis": "witnessed_action", "source": "第1章：铜匣由甲保管。"}]
        }
        self.claims = {
            "schema": "fact-claims/1", "chapter": 3, "candidate": "chapters/3.md",
            "candidate_sha256": self.sha(self.chapters / "3.md"), "extracted_by": "test_fixture",
            "claims": [{"id": "c1", "entity": "box", "attribute": "holder", "value": "甲",
                        "basis": "text_statement", "quote": "铜匣由甲保管。"}]
        }

    def tearDown(self):
        self.temp.cleanup()

    @staticmethod
    def sha(path):
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def invoke(self, command="check", verify_chapters=False):
        (self.root / "ledger.json").write_bytes((json.dumps(self.ledger, ensure_ascii=False)).encode("utf-8"))
        (self.root / "claims.json").write_bytes((json.dumps(self.claims, ensure_ascii=False)).encode("utf-8"))
        args = [sys.executable, "-I", "-B", str(SCRIPT), command, str(self.root / "ledger.json")]
        if command == "check":
            args.append(str(self.root / "claims.json"))
        if verify_chapters:
            args.extend(["--chapters-dir", str(self.chapters)])
        proc = subprocess.run(args, capture_output=True, text=True, encoding="utf-8")
        self.assertNotEqual(proc.returncode, 2, proc.stdout + proc.stderr)
        return proc.returncode, json.loads(proc.stdout)

    def assert_problem(self, expected, verify_chapters=False):
        for command in ("status", "check"):
            code, report = self.invoke(command, verify_chapters)
            self.assertEqual((code, report["status"]), (1, "LEDGER_PROBLEMS"))
            key = "problems" if command == "status" else "ledger_problems"
            self.assertIn(expected, {p["problem"] for p in report[key]})
            if command == "check":
                self.assertNotEqual(report["results"][0]["status"], "CONSISTENT")
                for field in ("status", "counts", "results", "extracted_by", "candidate", "review_items"):
                    self.assertIn(field, report)

    def set_claim_value(self, value):
        body = "铜匣由%s保管。" % value
        (self.chapters / "3.md").write_bytes((body).encode("utf-8"))
        self.claims["candidate_sha256"] = self.sha(self.chapters / "3.md")
        self.claims["claims"][0].update(value=value, quote=body)

    def test_nonaccepted_chapter_is_not_a_baseline_even_when_fact_is_accepted(self):
        for status in ("abandoned", "candidate", "summary", "plan"):
            with self.subTest(chapter_status=status):
                self.ledger["chapters"]["1"]["status"] = status
                self.assert_problem("SOURCE_CHAPTER_NOT_ACCEPTED")

    def test_unlisted_source_chapter_is_unknown_not_silently_accepted(self):
        del self.ledger["chapters"]["1"]
        self.assert_problem("SOURCE_CHAPTER_UNLISTED")

    def test_sourced_author_confirmation_survives_abandoned_or_unlisted_chapter(self):
        fact = self.ledger["facts"][0]
        fact.update(layer="author_confirmed", basis="author_confirmed", source="作者确认记录 2026-10-10：铜匣仍由甲保管。")
        for listed in (True, False):
            with self.subTest(source_chapter_listed=listed):
                if listed:
                    self.ledger["chapters"]["1"]["status"] = "abandoned"
                else:
                    del self.ledger["chapters"]["1"]
                self.assertEqual(self.invoke()[1]["status"], "CONSISTENT")
                self.assertEqual(self.invoke("status")[1]["status"], "OK")

    def test_author_layer_without_explicit_author_basis_does_not_bypass_validation(self):
        self.ledger["facts"][0]["layer"] = "author_confirmed"
        self.assert_problem("AUTHOR_CONFIRMATION_REQUIRED")

    def test_indirect_physical_fact_blocks_matching_direct_claim(self):
        self.ledger["facts"][0]["basis"] = "record"
        self.assert_problem("INDIRECT_BASIS_ACCEPTED")

    def test_unexplained_changed_value_cannot_be_consistent_baseline(self):
        later = copy.deepcopy(self.ledger["facts"][0])
        later.update(id="f2", chapter=2, value="乙", source="第2章：铜匣由乙保管。")
        self.ledger["facts"].append(later)
        self.set_claim_value("乙")
        self.assert_problem("UNEXPLAINED_CHANGE")

    def test_bad_later_fact_does_not_fall_back_to_old_value_as_consistent(self):
        later = copy.deepcopy(self.ledger["facts"][0])
        later.update(id="f2", chapter=2, value="乙", basis="record", change=True, source="第2章登记：乙签收。")
        self.ledger["facts"].append(later)
        self.assert_problem("INDIRECT_BASIS_ACCEPTED")
        result = self.invoke()[1]["results"][0]
        self.assertEqual(result["status"], "LEDGER_PROBLEMS")
        self.assertIsNone(result["baseline"])

    def test_current_and_future_chapter_problems_do_not_block_earlier_baseline(self):
        for chapter in (3, 4):
            later = copy.deepcopy(self.ledger["facts"][0])
            later.update(id="f" + str(chapter), chapter=chapter, value="乙", basis="record")
            self.ledger["facts"].append(later)
        code, report = self.invoke()
        self.assertEqual((code, report["status"]), (0, "CONSISTENT"))
        self.assertEqual(report["ledger_problems"], [])
        self.assertEqual(self.invoke("status")[1]["status"], "LEDGER_PROBLEMS")

    def test_valid_direct_change_is_allowed(self):
        later = copy.deepcopy(self.ledger["facts"][0])
        later.update(id="f2", chapter=2, value="乙", change=True, source="第2章：甲当场把铜匣交给乙。")
        self.ledger["facts"].append(later)
        self.set_claim_value("乙")
        self.assertEqual(self.invoke()[1]["status"], "CONSISTENT")

    def test_string_change_flag_cannot_justify_changed_baseline(self):
        later = copy.deepcopy(self.ledger["facts"][0])
        later.update(id="f2", chapter=2, value="乙", source="第2章：铜匣由乙保管。")
        self.ledger["facts"].append(later)
        self.set_claim_value("乙")
        for flag in ("false", "true", 1):
            with self.subTest(flag=flag):
                later["change"] = flag
                self.assert_problem("UNEXPLAINED_CHANGE")

    def test_candidate_change_needs_boolean_true(self):
        self.set_claim_value("乙")
        for flag in ("false", "true", 1):
            with self.subTest(flag=flag):
                self.claims["claims"][0]["change"] = flag
                self.assertEqual(self.invoke()[1]["status"], "CONFLICTS")
        self.claims["claims"][0]["change"] = True
        self.assertEqual(self.invoke()[1]["status"], "NEEDS_HUMAN")
        self.assertEqual(self.invoke()[1]["results"][0]["status"], "CHANGE_PROPOSED")

    def test_nonbaseline_facts_do_not_invalidate_accepted_fact(self):
        for layer in ("candidate", "abandoned", "plan", "summary"):
            later = copy.deepcopy(self.ledger["facts"][0])
            later.update(id="f-" + layer, chapter=2, value="乙", layer=layer, basis="record")
            self.ledger["facts"].append(later)
        self.assertEqual(self.invoke()[1]["status"], "CONSISTENT")
        self.assertEqual(self.invoke("status")[1]["status"], "OK")

    def test_indirect_evidence_can_describe_record_or_unknown_state(self):
        self.ledger["facts"][0].update(attribute="record.holder", basis="record")
        self.claims["claims"][0].update(attribute="record.holder", basis="record")
        self.assertEqual(self.invoke()[1]["status"], "CONSISTENT")
        self.ledger["facts"][0].update(attribute="holder", value="未知", basis="record_absence")
        self.claims["claims"][0].update(attribute="holder", basis="record_absence")
        self.set_claim_value("未知")
        self.assertEqual(self.invoke()[1]["status"], "CONSISTENT")

    def test_optional_chapter_binding_reports_changed_missing_and_unbound_sources(self):
        path = self.chapters / "1.md"
        path.write_bytes(("铜匣由乙保管。").encode("utf-8"))
        self.assert_problem("TEXT_CHANGED_SINCE_ACCEPTED", verify_chapters=True)
        path.unlink()
        self.assert_problem("UNAVAILABLE", verify_chapters=True)
        del self.ledger["chapters"]["1"]["sha256"]
        self.assert_problem("CHAPTER_BINDING_MISSING", verify_chapters=True)
        # Omitting the directory makes no claim to have verified source files.
        self.assertEqual(self.invoke()[1]["status"], "CONSISTENT")

    def test_optional_binding_ignores_future_chapter_changes(self):
        self.ledger["chapters"]["4"] = {"status": "accepted", "file": "missing-4.md", "sha256": "not-used-here"}
        self.assertEqual(self.invoke(verify_chapters=True)[1]["status"], "CONSISTENT")
        self.assertEqual(self.invoke("status", verify_chapters=True)[1]["status"], "LEDGER_PROBLEMS")


if __name__ == "__main__":
    unittest.main()

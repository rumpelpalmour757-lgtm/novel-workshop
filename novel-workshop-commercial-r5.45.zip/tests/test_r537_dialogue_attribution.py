#!/usr/bin/env python3
"""r5.37: who speaks a line, judged by right and wrong attributions (the r5.35 review, point 4).

The review found that r5.35 fixed r5.34's cases (他对宋青说: 宋青 is spoken to) but gave a line to one person for sure
where r5.34 had left it open: 宋青和林满同时说 and 宋青、林满齐声说 (two people speak together), 宋青比林满先说道 (林满
is compared, 宋青 speaks), 宋青安慰/回答/叮嘱林满说 (林满 is the one spoken to). It asked for a comparison that counts
right and wrong attributions, not only how many lines got a speaker, and for the rules to drop their absolute claims
about direction. These tests pin, with names made up for the tests:

- every case below has a truth (one speaker, two speaking together, or nobody on the list), and no case gets a wrong
  speaker; a case the script cannot settle stays open (not attributed, with the possible speakers);
- the cases r5.35 fixed stay fixed: the one spoken to, looked at or acted on, a possessive, a pronoun;
- the rules: the author's direction (人物声音进叙述是技巧，叙述声音进台词是病) is kept as the author's words and as
  where to look first, not as a law; the check is one question (this person, here, to this person, for this purpose);
  作者腹语 is judged by the line's purpose in the scene; the script's hint says it is a hint.
"""
import importlib.util
import os
from pathlib import Path
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
LINES = SKILL / "scripts" / "dialogue_lines.py"
NAMES = ["宋青", "林满", "程棠", "老周"]
JOINT = "together"

# (narration with the line, the truth: a name, JOINT, or None when the speaker is nobody on the list or not knowable)
CASES = [
    # The review's neutral probes and its r5.34/r5.35 comparison (the same input counted once).
    ("他对宋青说：“先别碰。”", None),
    ("宋青说：“先别碰。”", "宋青"),
    ("宋青和林满同时说：“先别碰。”", JOINT),
    ("宋青、林满齐声说：“先别碰。”", JOINT),
    ("宋青和林满两人说：“先别碰。”", JOINT),
    ("宋青跟林满异口同声地说：“先别碰。”", JOINT),
    ("宋青听见林满说：“先别碰。”", "林满"),
    ("宋青听取林满的建议后说：“先别碰。”", "宋青"),
    ("宋青提醒林满说：“先别碰。”", "宋青"),  # the review left this one out of its count as open to two readings
    ("宋青不是对林满说：“先别碰。”", "宋青"),
    ("宋青跟着林满说：“先别碰。”", "宋青"),
    ("宋青比林满先说道：“先别碰。”", "宋青"),
    ("林满看了宋青一眼，她说：“先别碰。”", None),
    ("宋青的同伴说：“先别碰。”", None),
    ("宋青听见掌声。林满开口：“先别碰。”", "林满"),
    ("宋青安慰林满说：“先别怕。”", "宋青"),
    ("宋青回答林满说：“我不知道。”", "宋青"),
    ("宋青叮嘱林满说：“先别碰。”", "宋青"),
    # Variations: the tag after the line, joined objects, earlier clauses, possessives, an action between two names.
    ("“先别碰。”宋青和林满同时说。", JOINT),
    ("“先别碰。”宋青比林满先说。", "宋青"),
    ("宋青对林满和程棠说：“先别碰。”", "宋青"),
    ("宋青和林满对程棠同时说：“先别碰。”", JOINT),
    ("宋青放下杯子，对林满说：“先别碰。”", "宋青"),
    ("宋青放下杯子，看着林满的眼睛说：“先别碰。”", "宋青"),
    ("宋青点点头，林满的同伴说：“先别碰。”", None),
    ("宋青走到林满身边说：“先别碰。”", "宋青"),
    ("他叮嘱宋青说：“先别碰。”", None),
    ("宋青跟林满说：“先别碰。”", "宋青"),
    ("宋青问林满说：“先别碰？”", "宋青"),
    ("老周让程棠说：“先别碰。”", None),  # 程棠 is asked to say it; whether he did is not written
]
# Two readings, both ordinary: only leaving it open is safe.
OPEN = [
    "宋青和林满说：“先别碰。”",  # together, or to 林满
    "宋青和林满的父亲说：“先别碰。”",  # 宋青 and the father together, or 宋青 to the father
]


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def attribute(text):
    report = load(LINES, "r537_dialogue_lines").inspect(text, "blank", NAMES, None)
    lines = [(x["speaker"], x["candidates"]) for items in report["speakers"].values() for x in items]
    lines += [(None, x["candidates"]) for x in report["unattributed"]]
    assert len(lines) == 1, (text, lines)
    return lines[0]


def judge(truth, speaker):
    """right: the speaker named, or nobody named when nobody on the list speaks alone; open: a listed speaker left
    unnamed (not wrong, less useful); wrong: a line given to someone who did not say it alone."""
    if speaker is None:
        return "right" if truth in (None, JOINT) else "open"
    return "right" if speaker == truth else "wrong"


class RightAndWrong(unittest.TestCase):
    def test_no_wrong_speaker(self):
        tally = {"right": [], "open": [], "wrong": []}
        for text, truth in CASES:
            speaker, candidates = attribute(text)
            tally[judge(truth, speaker)].append(text)
            if truth == JOINT:
                self.assertEqual((speaker, candidates), (None, ["宋青", "林满"]), text)
            elif speaker is None and truth:
                self.assertIn(truth, candidates, text)  # left open, with the real speaker among the possible ones
        self.assertEqual(tally["wrong"], [])
        # Counted for the record, not as a score of the writing: two clear speakers are left open (an action that is
        # not a speaking verb stands between the two names), everything else is right.
        self.assertEqual((len(tally["right"]), len(tally["open"])), (28, 2))
        self.assertEqual(sorted(tally["open"]), sorted(["宋青安慰林满说：“先别怕。”", "宋青走到林满身边说：“先别碰。”"]))

    def test_two_readings_stay_open(self):
        for text in OPEN:
            speaker, candidates = attribute(text)
            self.assertIsNone(speaker, text)
            self.assertIn("宋青", candidates, text)

    def test_the_review_cases_r535_got_wrong(self):
        for text, wrong in (("宋青和林满同时说：“先别碰。”", "宋青"), ("宋青、林满齐声说：“先别碰。”", "林满"),
                            ("宋青比林满先说道：“先别碰。”", "林满"), ("宋青安慰林满说：“先别怕。”", "林满"),
                            ("宋青回答林满说：“我不知道。”", "林满"), ("宋青叮嘱林满说：“先别碰。”", "林满")):
            self.assertNotEqual(attribute(text)[0], wrong, text)

    def test_r535s_fixes_stay(self):
        for text in ("他对宋青说：“先别碰。”", "他将工具递给宋青，说：“先别碰。”", "他看向宋青：“先别碰。”",
                     "他跟宋青说：“先别碰。”", "他推开宋青说：“先别碰。”"):
            speaker, candidates = attribute(text)
            self.assertIsNone(speaker, text)
            self.assertNotIn("宋青", candidates, text)


def read(relative):
    return (SKILL / relative).read_text(encoding="utf-8")


class NoLaw(unittest.TestCase):
    QUESTION = "这个人，在这个场合、对这个人、为了这个目的，会不会这样说"

    def test_dialogue_craft(self):
        text = read("references/dialogue-craft.md")
        direction = next(line for line in text.splitlines() if line.startswith("- **方向"))
        for phrase in ("**方向（查的起点，不是定律）**", "作者 10-23 的说法是“人物声音进叙述，是技巧；叙述声音进台词，是病”",
                       "可能正是这个人的声口", "自由间接引语是其中一种，不是凡带口气的叙述都算", "也会越出视角", self.QUESTION,
                       "同一个词可以留，也可以逐处改"):
            self.assertIn(phrase, direction)
        ventriloquism = next(line for line in text.splitlines() if line.startswith("- **作者腹语**"))
        for phrase in ("借台词交代信息本身不是毛病", "问清、求证、安慰、威胁、炫耀、回避、拖时间都算", "找不到场内的目的，才是说给读者的"):
            self.assertIn(phrase, ventriloquism)
        self.assertNotIn("不需要，就是说给读者的", text)

    def test_passes_and_drafting(self):
        passes = read("references/revision-passes.md")
        for phrase in ("它是查的起点，不是每一句的定论", self.QUESTION, "也可能正合适，逐处看", "这句话在场内为了什么说？",
                       "叙述贴着人物、带着他口气的地方不在这一遍改的范围", "摘掉引号像叙述，不等于是假台词"):
            self.assertIn(phrase, passes)
        drafting = read("references/drafting.md")
        self.assertIn("他身份里本来就说的术语、行话照说", drafting)
        self.assertIn("只是别越出他的视角", drafting)
        for name in ("references/dialogue-craft.md", "references/revision-passes.md", "references/drafting.md"):
            text = read(name)
            for absolute in ("才是毛病", "这句话屋里的人需要听吗", "人物的口气进叙述（自由间接引语）"):
                self.assertNotIn(absolute, text, name)

    def test_the_hint_says_it_is_a_hint(self):
        lines = load(LINES, "r537_dialogue_lines_hint")
        report = lines.inspect("林满说：“勘测的人勘过没有？”", "blank", (), {"narration_only": [{"text": "勘"}]})
        note = report["flagged"][0]["flags"][0]["note"]
        self.assertIn("这个人在这个场合、对这个人、为了这个目的，会不会这么说", note)
        self.assertIn("这是提示，不是判定", note)
        self.assertNotIn("不算毛病", note)


if __name__ == "__main__":
    unittest.main()

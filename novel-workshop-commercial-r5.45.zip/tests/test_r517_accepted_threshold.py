#!/usr/bin/env python3
"""r5.17: auditing a version the author has accepted needs a higher bar for "should change" than a draft.

The expression-check notes already said that accepted versions are checked too and that findings go to the author.
They did not say how to sort those findings. In 2026-10 an author audited ten accepted chapters and wrote down the
rule that decided every case: change what would make a reader take one object for another, get a sum wrong, or break
a name or rule the work has settled; keep mere wobble in how a sentence reads, idioms, and the layered way characters
talk. Earlier outside reviews had sent the author many suggestions of the second kind on locked chapters; few were
taken. These tests pin the generic form of that bar where accepted versions are audited, after the sentence that
says they are audited, and keep the classification the language-sense notes use (clear errors, optional polish,
facts to check, changes that would mislead).
"""

import os
from pathlib import Path
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"


class AcceptedThreshold(unittest.TestCase):
    def test_expression_notes_set_a_higher_bar_for_accepted_versions(self):
        text = (SKILL / "references" / "prose-audit.md").read_text(encoding="utf-8")
        line = [l for l in text.splitlines() if "作者采纳过的版本也照样检查" in l]
        self.assertEqual(len(line), 1)
        line = line[0]
        for phrase in ("门槛比草稿高", "认错东西", "算错数", "已定的叫法", "惯用语", "口语", "可选或保留", "不凑成建议"):
            self.assertIn(phrase, line)
        self.assertLess(line.index("作者采纳过的版本也照样检查"), line.index("门槛比草稿高"))

    def test_the_bar_points_to_the_four_way_sort(self):
        text = (SKILL / "references" / "prose-audit.md").read_text(encoding="utf-8")
        line = [l for l in text.splitlines() if "门槛比草稿高" in l][0]
        self.assertIn("“语感：搭配、照应与叫法”第 3 条", line[line.index("门槛比草稿高"):])


if __name__ == "__main__":
    unittest.main()

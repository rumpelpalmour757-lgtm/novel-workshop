// r5.46 写作台检查：只读边界、保存先备份与版本核对、启动器参数、演示作品。
// r5.59：Gemini“改稿建议”和 Google AI（官方 ACP）两个侧栏删了（作者 2026-11-19 定：写作台其他本地功能都留着），
// 原来测这两个侧栏的几条（请求范围、成功与失败、密钥不外泄、接通检查脚本）跟着删了；改成查它们的接口和页面确实不在了，
// 另加按文件名搜索一条。配置目录的函数从 gemini-assist.mjs 挪到 workbench.mjs，照旧测。
// 收到信号退出（关掉终端窗口、kill、Ctrl+C）那一条，原来在 acp_check.mjs 里实际起服务、发 SIGHUP（ACP-SEC-1/F1），
// 随那个文件删了；交付前的审查发现没有挪过来，现在照样实际起服务、发信号，只在 POSIX 上跑（r5.59）。
// 用法：node workbench_check.mjs <技能目录>。只用本机回环地址上的临时服务，不联网。
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { Agent, get } from "node:http";
import { mkdtemp, mkdir, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { pathToFileURL } from "node:url";

const skill = process.argv[2];
const { createDashboardServer } = await import(pathToFileURL(join(skill, "scripts", "oh-story", "dashboard-server.mjs")).href);
const { parseLauncherArguments, createDemoWorkspace, nodeTooOld, configDirectory } = await import(pathToFileURL(join(skill, "scripts", "oh-story", "workbench.mjs")).href);

const results = [];
async function check(name, fn) {
  try {
    await fn();
    results.push(["ok", name]);
  } catch (error) {
    results.push(["FAIL", name, error?.stack || String(error)]);
  }
}

function listen(server) {
  return new Promise((accept) => server.listen(0, "127.0.0.1", () => accept(server.address().port)));
}

async function api(port, method, path, body, headers = {}) {
  const response = await fetch(`http://127.0.0.1:${port}${path}`, {
    method,
    headers: { "Content-Type": "application/json", ...headers },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await response.text();
  let json = null;
  try {
    json = JSON.parse(text);
  } catch {}
  return { status: response.status, json, text };
}

const base = await mkdtemp(join(tmpdir(), "nw-wb-"));
const root = join(base, "作品");
await mkdir(join(root, "正文"), { recursive: true });
const chapter = "第一章\n\n苏棠扣上头盔，从气闸里出来。\n\n这一段不该发出去。\n";
await writeFile(join(root, "正文", "第001章.md"), chapter, "utf8");

const readOnlyServer = createDashboardServer({ root });
const editServer = createDashboardServer({ root, allowEdit: true });
const roPort = await listen(readOnlyServer);
const port = await listen(editServer);

await check("默认只读：workspace 报 readOnly，PUT 被拒（403），文件不变", async () => {
  const ws = await api(roPort, "GET", "/api/workspace");
  assert.equal(ws.json.readOnly, true);
  const file = await api(roPort, "GET", `/api/file?path=${encodeURIComponent("正文/第001章.md")}`);
  const put = await api(roPort, "PUT", "/api/file", { path: "正文/第001章.md", content: "改了", expectedVersion: file.json.version });
  assert.equal(put.status, 403);
  assert.equal(await readFile(join(root, "正文", "第001章.md"), "utf8"), chapter);
});

await check("按文件名搜索：写作项目里找得到这一章，搜不到的给空清单", async () => {
  const found = await api(roPort, "GET", `/api/search?q=${encodeURIComponent("第001")}&scope=projects`);
  assert.equal(found.status, 200, found.text);
  assert.deepEqual(found.json.results.map((item) => item.path), ["正文/第001章.md"]);
  const none = await api(roPort, "GET", `/api/search?q=${encodeURIComponent("没有这个文件")}&scope=projects`);
  assert.equal(none.status, 200, none.text);
  assert.deepEqual(none.json.results, []);
});

await check("可编辑：保存先备份；拿旧版本号保存报 409 冲突、不覆盖；没有删除接口", async () => {
  const file = await api(port, "GET", `/api/file?path=${encodeURIComponent("正文/第001章.md")}`);
  const saved = await api(port, "PUT", "/api/file", { path: "正文/第001章.md", content: `${chapter}加一行。\n`, expectedVersion: file.json.version });
  assert.equal(saved.status, 200);
  const backupRoot = join(root, ".novel-workshop-backups");
  const records = await readdir(backupRoot);
  assert.equal(records.length, 1, `备份数不对：${records.join(", ")}`);
  assert.equal(await readFile(join(backupRoot, records[0], "original.bin"), "utf8"), chapter);
  assert.ok((await readFile(join(backupRoot, records[0], "record.json"), "utf8")).includes("第001章.md"));
  const stale = await api(port, "PUT", "/api/file", { path: "正文/第001章.md", content: "旧版本上的修改", expectedVersion: file.json.version });
  assert.equal(stale.status, 409);
  assert.equal(await readFile(join(root, "正文", "第001章.md"), "utf8"), `${chapter}加一行。\n`);
  const del = await api(port, "DELETE", `/api/file?path=${encodeURIComponent("正文/第001章.md")}`);
  assert.equal(del.status, 405);
});

await check("非本机页面发来的写入被拒，文件不变", async () => {
  const before = await readFile(join(root, "正文", "第001章.md"), "utf8");
  const file = await api(port, "GET", `/api/file?path=${encodeURIComponent("正文/第001章.md")}`);
  const result = await api(port, "PUT", "/api/file", { path: "正文/第001章.md", content: "别的网页写的", expectedVersion: file.json.version }, { Origin: "http://evil.example" });
  assert.equal(result.status, 403);
  assert.equal(await readFile(join(root, "正文", "第001章.md"), "utf8"), before);
});

await check("r5.59：两个侧栏的接口不在了（GET 404，POST 405），作品目录里没多出东西", async () => {
  const before = (await readdir(root, { recursive: true })).sort();
  for (const path of ["/api/assist/status", "/api/acp/token", "/api/acp/status"]) {
    const result = await api(port, "GET", path);
    assert.equal(result.status, 404, `${path} ${result.text}`);
  }
  for (const path of ["/api/assist/config", "/api/assist/revise", "/api/assist/models", "/api/assist/selftest",
                      "/api/acp/config", "/api/acp/connect", "/api/acp/prompt", "/api/acp/selftest"]) {
    const result = await api(port, "POST", path, { text: "一段", apiKey: "AIzaTEST-not-a-real-key" });
    assert.equal(result.status, 405, `${path} ${result.text}`);
  }
  assert.deepEqual((await readdir(root, { recursive: true })).sort(), before);
});

await check("r5.59：页面里没有“改稿建议”和“Google AI”两个侧栏，“对比”还在", async () => {
  const html = (await api(roPort, "GET", "/")).text;
  for (const gone of ["assistButton", "assistPanel", "acpButton", "acpPanel", "改稿建议", "Google AI", "Gemini"]) {
    assert.ok(!html.includes(gone), gone);
  }
  for (const kept of ['id="compareButton"', 'id="comparePanel"', 'id="editToggle"', 'id="saveButton"', 'id="draftBanner"']) {
    assert.ok(html.includes(kept), kept);
  }
  const script = (await api(roPort, "GET", "/app.js")).text;
  for (const gone of ["/api/assist/", "/api/acp/", "X-Novel-Workshop-Token", "Gemini"]) {
    assert.ok(!script.includes(gone), gone);
  }
  assert.ok(script.includes("/api/file") && script.includes("/api/search"));
});

await check("配置目录按系统放在用户目录下，可用环境变量改", async () => {
  assert.equal(configDirectory({ NOVEL_WORKSHOP_CONFIG_DIR: "/x/y" }, "linux", "/home/a"), "/x/y");
  assert.equal(configDirectory({}, "linux", "/home/a"), "/home/a/.config/novel-workshop");
  assert.equal(configDirectory({ XDG_CONFIG_HOME: "/home/a/cfg" }, "linux", "/home/a"), "/home/a/cfg/novel-workshop");
  assert.equal(configDirectory({ APPDATA: "C:\\Users\\a\\AppData\\Roaming" }, "win32", "C:\\Users\\a").replaceAll("\\", "/"), "C:/Users/a/AppData/Roaming/novel-workshop");
  assert.equal(configDirectory({}, "darwin", "/Users/a"), "/Users/a/Library/Application Support/novel-workshop");
});

await check("启动器参数：只读、可编辑、作品目录、演示", async () => {
  assert.deepEqual(parseLauncherArguments(["--edit"]), { root: null, edit: true, demo: false });
  assert.deepEqual(parseLauncherArguments(["--read-only", "--root", "D:/作品"]), { root: "D:/作品", edit: false, demo: false });
  assert.deepEqual(parseLauncherArguments(["D:/作品"]), { root: "D:/作品", edit: null, demo: false });
  assert.equal(parseLauncherArguments(["--demo"]).demo, true);
});

await check("演示作品：合成示例写在临时目录，标明是合成的；Node 版本检查", async () => {
  const demoRoot = await createDemoWorkspace(base);
  const names = await readdir(demoRoot, { recursive: true });
  assert.ok(names.includes(join("正文", "第001章.md")));
  const readme = await readFile(join(demoRoot, "README.md"), "utf8");
  assert.ok(readme.includes("合成示例"));
  assert.ok(!readme.includes("改稿建议"));  // r5.59：它指的那个侧栏删了
  assert.ok((await readFile(join(demoRoot, "正文", "第001章.md"), "utf8")).includes("合成示例"));
  assert.equal(nodeTooOld("16.20.0"), true);
  assert.equal(nodeTooOld("18.0.0"), false);
  assert.equal(nodeTooOld("22.22.0"), false);
});

// r5.59：服务收到信号时关掉、以 0 退出。浏览器一般开着 keep-alive 连接，这里也先开一条；3 秒内没退出算失败，
// 失败时用 SIGKILL 收掉进程。Windows 上没有这几种信号可发，跳过。
function waitFor(promise, ms) {
  let timer;
  return Promise.race([promise, new Promise((accept) => { timer = setTimeout(() => accept(null), ms); })])
    .finally(() => clearTimeout(timer));
}

const skipped = [];
if (process.platform === "win32") {
  skipped.push("r5.59：收到信号时服务关掉、以 0 退出（Windows 上不发 POSIX 信号）");
} else {
  for (const [signal, when] of [["SIGHUP", "关掉终端窗口"], ["SIGTERM", "kill"], ["SIGINT", "Ctrl+C"]]) {
    await check(`r5.59：服务收到 ${signal}（${when}）时关掉，3 秒内以 0 退出`, async () => {
      const server = spawn(process.execPath, [join(skill, "scripts", "oh-story", "dashboard-server.mjs"), "--root", root, "--port", "0"],
                           { stdio: ["ignore", "pipe", "pipe"] });
      let out = "";
      server.stdout.on("data", (chunk) => {
        out += chunk;
      });
      server.stderr.on("data", (chunk) => {
        out += chunk;
      });
      const exited = new Promise((accept) => server.once("exit", (code, sig) => accept({ code, signal: sig })));
      const agent = new Agent({ keepAlive: true });
      try {
        const started = await waitFor((async () => {
          for (;;) {
            const found = out.match(/本机地址：http:\/\/127\.0\.0\.1:(\d+)/);
            if (found) return Number(found[1]);
            if (server.exitCode !== null || server.signalCode !== null) return null;
            await new Promise((accept) => setTimeout(accept, 20));
          }
        })(), 15000);
        assert.ok(started, `服务没有起来：${out}`);
        await new Promise((accept, reject) => {
          get(`http://127.0.0.1:${started}/api/workspace`, { agent }, (response) => {
            response.resume();
            response.on("end", accept);
          }).on("error", reject);
        });
        server.kill(signal);
        const result = await waitFor(exited, 3000);
        assert.ok(result, `${signal} 以后 3 秒内没有退出`);
        assert.deepEqual(result, { code: 0, signal: null }, out);
      } finally {
        agent.destroy();
        if (server.exitCode === null && server.signalCode === null) server.kill("SIGKILL");
      }
    });
  }
}

readOnlyServer.close();
editServer.close();
await rm(base, { recursive: true, force: true });
for (const [status, name, detail] of results) console.log(`${status} ${name}${detail ? `\n${detail}` : ""}`);
for (const name of skipped) console.log(`skip ${name}`);
const failed = results.filter(([status]) => status !== "ok").length;
console.log(`${results.length - failed}/${results.length} passed`);
process.exit(failed ? 1 : 0);

#!/usr/bin/env python3
"""r5.49: a read-only precheck before project_state.py commit (scripts/state_precheck.py).

commit replaces all data, and a field the candidate leaves out is deleted. When a model rewrites the candidate, a
character or a setting can drop out without anyone asking for it. state_precheck.py BASE DESIRED lists, by JSON path,
what the candidate deletes (first, each marked 要作者看), what it changes (old -> new) and what it adds. Lists of
objects with an id or name are matched by that key, other lists by position, and the report says which.

These tests pin the program's behaviour, that it writes nothing, and the paragraph in references/state-storage.md.
Whether a change is right is for the author to decide; the tool does not say.
"""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

try:
    import fcntl  # noqa: F401  (project_state.py needs it; only the round-trip test does)
except ImportError:
    fcntl = None

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
SCRIPTS = SKILL / "scripts"
PRECHECK = SCRIPTS / "state_precheck.py"
STATE = SCRIPTS / "project_state.py"
STORAGE = SKILL / "references" / "state-storage.md"
CLOSING = "只列差别，不判对错：有删除时，先给作者看；作者没说删，就不删。"

# Invented for these tests: a small salt-marsh story.
DATA = {
    "characters": {
        "mei": {"name": "柏梅", "role": "盐场记账的", "where": "东滩棚屋",
                "belongings": [{"id": "abacus", "label": "缺了两颗珠的算盘"},
                               {"id": "boots", "label": "补过的胶靴"}]},
        "lu": {"name": "鹿川", "role": "收盐的船老大", "where": "停在闸口的平底船"},
    },
    "settings": {
        "marsh": {"season": "梅雨刚过", "rule": "晒盐的池子三天不翻就结硬壳"},
    },
    "chapters": {
        "c01": {"status": "草稿", "beats": ["柏梅数错一池盐", "鹿川的船晚到半天"]},
    },
}


def snapshot(data, revision=4):
    return {"schema_version": 1, "project_id": "盐滩", "store_id": "store-test", "revision": revision,
            "data": data, "version": "sha256:" + "0" * 64}


def edited(change):
    data = json.loads(json.dumps(DATA))
    change(data)
    return data


def load():
    spec = importlib.util.spec_from_file_location("r549_state_precheck", PRECHECK)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(*args, cwd=None):
    proc = subprocess.run([sys.executable, "-I", "-B", str(PRECHECK), *map(str, args)], cwd=cwd,
                          capture_output=True, text=True, encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


class Files(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.work = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, name, value):
        path = self.work / name
        path.write_bytes(json.dumps(value, ensure_ascii=False).encode("utf-8"))
        return path

    def compare(self, desired, base=None, fmt="json"):
        base_path = self.write("base.json", base if base is not None else snapshot(DATA))
        desired_path = self.write("desired-data.json", desired)
        code, out, err = run(base_path, desired_path, "--format", fmt)
        self.assertEqual(code, 0, err)
        return json.loads(out) if fmt == "json" else out


class DeletedCharacter(Files):
    def test_a_character_the_candidate_dropped_is_listed_first_and_marked(self):
        def drop(data):
            del data["characters"]["lu"]
            data["settings"]["marsh"]["season"] = "伏天"
        result = self.compare(edited(drop))
        self.assertEqual(result["base"]["compared"], "snapshot")
        self.assertEqual(result["desired"]["compared"], "whole")
        self.assertEqual([d["path"] for d in result["deleted"]], ["/characters/lu"])
        deleted = result["deleted"][0]
        self.assertTrue(deleted["needs_author"])
        self.assertEqual(deleted["mark"], "要作者看")
        self.assertEqual(deleted["old"]["name"], "鹿川")  # the whole object, once, not field by field
        self.assertEqual(result["counts"], {"deleted": 1, "changed": 1, "added": 0})

    def test_the_text_puts_deletions_before_changes_and_ends_with_the_closing_line(self):
        def drop(data):
            del data["characters"]["lu"]
            data["settings"]["marsh"]["season"] = "伏天"
        text = self.compare(edited(drop), fmt="text")
        self.assertTrue(text.endswith(CLOSING + "\n"), text[-80:])
        self.assertLess(text.index("/characters/lu"), text.index("/settings/marsh/season"))
        line = next(l for l in text.splitlines() if l.startswith("- /characters/lu"))
        self.assertIn("要作者看", line)
        self.assertIn("只是要回头核对的地方，不是结论", text)
        for verdict in ("没有问题", "可以提交", "通过", "安全"):
            self.assertNotIn(verdict, text)

    def test_a_dropped_field_inside_a_character_is_a_deletion_too(self):
        def drop(data):
            del data["characters"]["mei"]["where"]
        result = self.compare(edited(drop))
        self.assertEqual([d["path"] for d in result["deleted"]], ["/characters/mei/where"])
        self.assertEqual(result["deleted"][0]["old"], "东滩棚屋")


class ChangedSetting(Files):
    def test_a_changed_rule_shows_old_and_new(self):
        def change(data):
            data["settings"]["marsh"]["rule"] = "晒盐的池子五天不翻就结硬壳"
        result = self.compare(edited(change))
        self.assertEqual(result["deleted"], [])
        self.assertEqual(result["changed"], [{"path": "/settings/marsh/rule", "kind": "value",
                                              "old": "晒盐的池子三天不翻就结硬壳",
                                              "new": "晒盐的池子五天不翻就结硬壳"}])
        text = self.compare(edited(change), fmt="text")
        self.assertIn("- /settings/marsh/rule：\"晒盐的池子三天不翻就结硬壳\" → \"晒盐的池子五天不翻就结硬壳\"", text)

    def test_a_long_value_is_cut_around_the_place_that_differs(self):
        long_old = "棚屋后面有一条排水沟，" * 12 + "沟边种着三棵歪脖子柳。"
        long_new = "棚屋后面有一条排水沟，" * 12 + "沟边种着五棵歪脖子柳。"
        base = edited(lambda d: d["settings"]["marsh"].update(note=long_old))
        desired = edited(lambda d: d["settings"]["marsh"].update(note=long_new))
        text = self.compare(desired, base=snapshot(base), fmt="text")
        line = next(l for l in text.splitlines() if l.startswith("- /settings/marsh/note"))
        self.assertIn("三棵", line)
        self.assertIn("五棵", line)
        self.assertLess(len(line), len(long_old) + len(long_new))

    def test_a_type_change_is_a_change_not_a_deletion(self):
        def change(data):
            data["chapters"]["c01"]["beats"] = "柏梅数错一池盐"
        result = self.compare(edited(change))
        self.assertEqual(result["deleted"], [])
        self.assertEqual([c["path"] for c in result["changed"]], ["/chapters/c01/beats"])


class ReasonableChange(Files):
    def test_an_added_chapter_and_a_status_change_list_no_deletion(self):
        def grow(data):
            data["chapters"]["c01"]["status"] = "作者已采纳"
            data["chapters"]["c02"] = {"status": "草稿", "beats": ["闸口夜里涨水"]}
        result = self.compare(edited(grow))
        self.assertEqual(result["counts"], {"deleted": 0, "changed": 1, "added": 1})
        self.assertEqual(result["added"][0]["path"], "/chapters/c02")
        self.assertNotIn("needs_author", json.dumps(result["changed"] + result["added"]))
        text = self.compare(edited(grow), fmt="text")
        self.assertNotIn("【删除", text)
        self.assertTrue(text.endswith(CLOSING + "\n"))
        # No deletions is still not a verdict.
        self.assertIn("不是结论", text)

    def test_the_same_data_lists_nothing_and_exits_zero(self):
        result = self.compare(json.loads(json.dumps(DATA)))
        self.assertEqual(result["counts"], {"deleted": 0, "changed": 0, "added": 0})
        self.assertEqual(result["notes"], [])
        text = self.compare(json.loads(json.dumps(DATA)), fmt="text")
        self.assertIn("没有差别", text)
        self.assertTrue(text.endswith(CLOSING + "\n"))

    def test_a_snapshot_given_as_the_candidate_is_compared_by_its_data_and_noted(self):
        result = self.compare(snapshot(DATA, revision=5))
        self.assertEqual(result["desired"]["compared"], "snapshot")
        self.assertEqual(result["counts"], {"deleted": 0, "changed": 0, "added": 0})
        self.assertTrue(any("--proposed 只要其中的 data" in note for note in result["notes"]))

    def test_a_candidate_missing_a_core_section_gets_a_format_note(self):
        result = self.compare(edited(lambda d: d.pop("settings")))
        self.assertEqual([d["path"] for d in result["deleted"]], ["/settings"])
        self.assertTrue(any("commit 会拒收" in note for note in result["notes"]))


class ListsByKey(Files):
    def test_items_with_an_id_are_matched_by_id(self):
        def change(data):
            items = data["characters"]["mei"]["belongings"]
            items.reverse()  # boots, abacus
            items[1]["label"] = "珠子补齐的算盘"
            items.append({"id": "lamp", "label": "防风马灯"})
        result = self.compare(edited(change))
        self.assertEqual(result["deleted"], [])
        paths = [c["path"] for c in result["changed"]]
        self.assertIn("/characters/mei/belongings/[id=abacus]/label", paths)
        order = next(c for c in result["changed"] if c["kind"] == "order")
        self.assertEqual((order["old"], order["new"]), (["abacus", "boots"], ["boots", "abacus"]))
        self.assertEqual([a["path"] for a in result["added"]], ["/characters/mei/belongings/[id=lamp]"])
        self.assertIn({"path": "/characters/mei/belongings", "match": "id"}, result["lists"])
        text = self.compare(edited(change), fmt="text")
        self.assertIn("/characters/mei/belongings：按 id 对照", text)

    def test_a_dropped_item_is_a_deletion_by_its_id(self):
        def change(data):
            data["characters"]["mei"]["belongings"] = [{"id": "boots", "label": "补过的胶靴"}]
        result = self.compare(edited(change))
        self.assertEqual([d["path"] for d in result["deleted"]], ["/characters/mei/belongings/[id=abacus]"])
        self.assertTrue(result["deleted"][0]["needs_author"])
        self.assertEqual(result["changed"], [])

    def test_items_with_a_name_and_no_id_are_matched_by_name(self):
        base = edited(lambda d: d["settings"].update(boats=[{"name": "白鹭号", "crew": 3}, {"name": "青蚌号", "crew": 2}]))
        desired = edited(lambda d: d["settings"].update(boats=[{"name": "青蚌号", "crew": 4}]))
        result = self.compare(desired, base=snapshot(base))
        self.assertEqual([d["path"] for d in result["deleted"]], ["/settings/boats/[name=白鹭号]"])
        self.assertEqual([c["path"] for c in result["changed"]], ["/settings/boats/[name=青蚌号]/crew"])
        self.assertIn({"path": "/settings/boats", "match": "name"}, result["lists"])

    def test_a_plain_list_is_matched_by_position_and_says_so(self):
        def change(data):
            data["chapters"]["c01"]["beats"] = ["柏梅数错一池盐"]
        result = self.compare(edited(change))
        self.assertEqual([d["path"] for d in result["deleted"]], ["/chapters/c01/beats/1"])
        entry = next(l for l in result["lists"] if l["path"] == "/chapters/c01/beats")
        self.assertEqual(entry["match"], "position")
        text = self.compare(edited(change), fmt="text")
        self.assertIn("/chapters/c01/beats：按位置对照", text)

    def test_ids_that_repeat_fall_back_to_position(self):
        base = edited(lambda d: d["settings"].update(tides=[{"id": "t", "h": 1}, {"id": "t", "h": 2}]))
        desired = edited(lambda d: d["settings"].update(tides=[{"id": "t", "h": 1}, {"id": "t", "h": 3}]))
        result = self.compare(desired, base=snapshot(base))
        self.assertEqual([c["path"] for c in result["changed"]], ["/settings/tides/1/h"])
        self.assertEqual(result["lists"][0]["match"], "position")

    def test_a_slash_in_a_key_is_escaped_as_in_a_json_pointer(self):
        base = edited(lambda d: d["settings"].update({"潮/汛": "初一"}))
        desired = edited(lambda d: d["settings"].update({"潮/汛": "十五"}))
        result = self.compare(desired, base=snapshot(base))
        self.assertEqual(result["changed"][0]["path"], "/settings/潮~1汛")


class InvalidJson(Files):
    def check_refused(self, base_bytes=None, desired_bytes=None, missing=False):
        base = self.work / "base.json"
        desired = self.work / "desired-data.json"
        base.write_bytes(base_bytes if base_bytes is not None else json.dumps(snapshot(DATA)).encode("utf-8"))
        if not missing:
            desired.write_bytes(desired_bytes if desired_bytes is not None else json.dumps(DATA).encode("utf-8"))
        before = sorted(p.name for p in self.work.iterdir())
        for fmt in ("text", "json"):
            code, out, err = run(base, desired, "--format", fmt)
            self.assertEqual(code, 2, (fmt, out, err))
            self.assertEqual(out, "")
            self.assertTrue(err.strip())
            if fmt == "json":
                error = json.loads(err)
                self.assertEqual(error["status"], "error")
            else:
                self.assertIn("没有写任何文件", err)
        self.assertEqual(sorted(p.name for p in self.work.iterdir()), before)
        return json.loads(run(base, desired, "--format", "json")[2])

    def test_broken_syntax_exits_two(self):
        error = self.check_refused(desired_bytes='{"characters": {"mei": '.encode("utf-8"))
        self.assertEqual((error["code"], error["role"]), ("invalid_json", "DESIRED"))

    def test_a_repeated_key_exits_two_as_project_state_would(self):
        error = self.check_refused(base_bytes='{"characters": {}, "characters": {}}'.encode("utf-8"))
        self.assertEqual((error["code"], error["role"]), ("invalid_json", "BASE"))
        self.assertIn("重复的键", error["message"])

    def test_nan_and_a_bom_exit_two(self):
        self.check_refused(desired_bytes=b'{"characters": {}, "settings": {"x": NaN}, "chapters": {}}')
        self.check_refused(desired_bytes=b"\xef\xbb\xbf" + json.dumps(DATA).encode("utf-8"))

    def test_text_that_is_not_utf8_exits_two(self):
        self.check_refused(desired_bytes='{"characters": {"mei": "柏梅"}}'.encode("gbk"))

    def test_a_missing_file_exits_two(self):
        error = self.check_refused(missing=True)
        self.assertEqual((error["code"], error["role"]), ("unreadable", "DESIRED"))


class ReadOnly(Files):
    def test_it_writes_nothing_even_with_deletions(self):
        base = self.write("base.json", snapshot(DATA))
        desired = self.write("desired-data.json", edited(lambda d: d["characters"].pop("lu")))
        before = {p.name: (p.stat().st_mtime_ns, p.read_bytes()) for p in self.work.iterdir()}
        for fmt in ("text", "json"):
            code, out, err = run(base, desired, "--format", fmt, cwd=self.work)
            self.assertEqual(code, 0, err)
        after = {p.name: (p.stat().st_mtime_ns, p.read_bytes()) for p in self.work.iterdir()}
        self.assertEqual(after, before)
        self.assertFalse(json.loads(run(base, desired, "--format", "json")[1])["writes_files"])

    def test_the_module_works_without_files(self):
        module = load()
        result = module.precheck(snapshot(DATA), edited(lambda d: d["characters"].pop("mei")))
        self.assertEqual([d["path"] for d in result["deleted"]], ["/characters/mei"])
        self.assertEqual(result["closing"], CLOSING)

    @unittest.skipIf(fcntl is None or os.name != "posix", "project_state.py needs POSIX flock")
    def test_a_real_read_snapshot_is_compared_and_the_store_is_untouched(self):
        store = self.work / "story-state.json"
        initial = self.write("initial-data.json", DATA)
        subprocess.run([sys.executable, "-I", "-B", str(STATE), "init", str(store), "--project-id", "盐滩",
                        "--data", str(initial)], check=True, capture_output=True)
        read = subprocess.run([sys.executable, "-I", "-B", str(STATE), "read", str(store)],
                              check=True, capture_output=True)
        base = self.work / "base.json"
        base.write_bytes(read.stdout)
        stored = store.read_bytes()
        desired = self.write("desired-data.json", edited(lambda d: d["characters"].pop("lu")))
        code, out, err = run(base, desired, "--format", "json")
        self.assertEqual(code, 0, err)
        result = json.loads(out)
        self.assertEqual(result["base"]["compared"], "snapshot")
        self.assertEqual([d["path"] for d in result["deleted"]], ["/characters/lu"])
        self.assertEqual(store.read_bytes(), stored)


class Wiring(unittest.TestCase):
    def test_the_paragraph_follows_the_one_about_omitted_fields(self):
        paragraphs = [p.strip() for p in STORAGE.read_text(encoding="utf-8").split("\n\n")]
        at = next(i for i, p in enumerate(paragraphs) if "省略字段表示删除该字段" in p)
        paragraph = paragraphs[at + 1]
        for phrase in ("scripts/state_precheck.py", "`commit` 之前", "模型重写", "可选", "不写任何文件",
                       "要作者看", "旧值 → 新值", "`id` 或 `name`", "按位置对照", "不是结论",
                       "作者没说删就不删", "退出码 `0`", "`2`"):
            self.assertIn(phrase, paragraph)
        self.assertEqual(sum("state_precheck.py" in p for p in paragraphs), 1)

    def test_both_exports_still_build_their_file_lists(self):
        # r5.49 wiring: the paragraph links the script and the sale whitelist lists it, so both exports carry it.
        spec = importlib.util.spec_from_file_location("r549_precheck_export", SCRIPTS / "export_portable.py")
        exporter = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(exporter)
        for mode in ("personal", "sale"):
            files = exporter.collect_core(SKILL, mode)
            self.assertIn("references/state-storage.md", files, mode)
            self.assertIn("scripts/state_precheck.py", files, mode)
        self.assertIn("scripts/state_precheck.py", exporter.SALE_FILES)


if __name__ == "__main__":
    unittest.main()

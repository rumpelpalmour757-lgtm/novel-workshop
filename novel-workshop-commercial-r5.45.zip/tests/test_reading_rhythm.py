"""Reading-load hints (P11-P13) and the opt-in dialogue soft wrap. Never an aesthetic PASS.

These cases cover the same failure types as the r4.3 reading-rhythm tests (crowded paragraph,
chopped lines, long speech, soft-wrapped quotation), rebuilt with neutral material: the r4.3
originals quote an author's manuscript and live only in that project's private pack.
R01 maps to P12, R02 to P11, R03 to P13.
"""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SCRIPTS = ROOT / "skills" / "novel-workshop" / "scripts"


def load(name):
    spec = importlib.util.spec_from_file_location("trr_" + name, SCRIPTS / (name + ".py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


CROWDED = ("码头上，阿青把缆绳甩给船头的老周，老周没接稳，绳头落进水里，小满趴在栈板上伸手去捞，"
           "林舟从她身后一把拽住她的腰带，阿青又跳下石阶去扶船帮，船身一晃，老周手里的篙子横着扫过来。")
DIVIDED = ("码头上，阿青把缆绳甩给船头的老周。老周没接稳，绳头落进水里。\n"
           "小满趴在栈板上伸手去捞，林舟从她身后一把拽住她的腰带。\n"
           "阿青跳下石阶去扶船帮。船身一晃，老周手里的篙子横着扫过来。")
SPEECH = ("“我是南城车队的，押运十年。这趟给你三成，先付一半。路上不许问货，不许离队。"
          "夜里轮流守，谁打盹扣谁的钱。到了地方你自己走，别回头找我。”")
SOFT = ("“我是南城车队的，押运十年。\n"
        "这趟给你三成，先付一半。\n"
        "路上不许问货，不许离队，夜里轮流守。”")


class ReadingLoad(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.lint = load("punctuation_lint")
        cls.people = {"characters": ["阿青", "老周", "小满", "林舟"]}

    def rules_of(self, report, rule):
        return [f for f in report["findings"] if f["rule"] == rule]

    def test_crowded_paragraph_is_review_not_error(self):
        report = self.lint.lint_text(CROWDED, self.people)
        found = self.rules_of(report, "P12")
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0]["severity"], "REVIEW")
        self.assertEqual(found[0]["line"], 1)
        self.assertEqual(report["counts"]["ERROR"], 0)
        self.assertIn("NO_FLAGS 不代表", report["limits"])

    def test_divided_version_is_not_flagged_as_crowded(self):
        self.assertFalse(self.rules_of(self.lint.lint_text(DIVIDED, self.people), "P12"))

    def test_without_registered_people_a_short_crowded_paragraph_is_not_guessed(self):
        # The hint needs the project's own cast list; it does not guess who is a person.
        self.assertFalse(self.rules_of(self.lint.lint_text(CROWDED), "P12"))

    def test_short_narrative_streak_gets_review(self):
        found = self.lint.lint_text("她起身。\n她关窗。\n她回头。\n她又坐下。")["findings"]
        self.assertEqual([f["rule"] for f in found], ["P11"])

    def test_streak_counts_across_blank_lines(self):
        # Blank-line paragraphing (Markdown, many web-novel drafts) must not hide a chopped run.
        found = self.lint.lint_text("她起身。\n\n她关窗。\n\n她回头。\n\n她又坐下。")["findings"]
        self.assertEqual([f["rule"] for f in found], ["P11"])

    def test_dialogue_is_excluded_from_fragment_run(self):
        self.assertFalse(self.lint.lint_text("“去吗？”\n“去。”\n“明天？”\n“明天。”")["findings"])

    def test_tag_and_panel_lines_do_not_cause_fragment_run(self):
        self.assertFalse(self.lint.lint_text("【守】\n船身一歪。\n【已入港】\n他抓紧缆绳。")["findings"])
        rules = {"panel_prefixes": ["系统提示"]}
        self.assertFalse(self.lint.lint_text("系统提示：任务开始\n他退开。\n他站稳。\n他回头。", rules)["findings"])

    def test_long_speech_review_with_project_threshold(self):
        report = self.lint.lint_text(SPEECH, {"long_speech": {"max_chars": 40, "min_sentences": 4}})
        self.assertEqual([f["rule"] for f in report["findings"]], ["P13"])
        self.assertFalse(self.rules_of(self.lint.lint_text(SPEECH), "P13"))  # default line is higher

    def test_compact_group_shot_is_not_necessarily_crowding(self):
        text = ("灯一亮，屋里的人都看清了：林舟靠在墙角，左手缠着布，布上洇着一圈褐色。阿青坐在翻倒的水缸上，"
                "一只鞋不见了。门边还有两个挑夫，正低头数着散了一地的铜钱。")
        self.assertFalse(self.rules_of(self.lint.lint_text(text, self.people), "P12"))

    def test_opt_in_soft_wrap_removes_the_false_unclosed_quote(self):
        strict = self.lint.lint_text(SOFT)
        self.assertGreater(strict["counts"]["ERROR"], 0)
        self.assertEqual(self.lint.lint_text(SOFT, dialogue_soft_wrap=True)["counts"]["ERROR"], 0)
        declared = self.lint.lint_text(SOFT, {"dialogue_soft_wrap": True})
        self.assertEqual(declared["counts"]["ERROR"], 0)
        self.assertTrue(declared["dialogue_soft_wrap"])
        # An explicit False for one run overrides the rules file.
        self.assertGreater(self.lint.lint_text(SOFT, {"dialogue_soft_wrap": True}, False)["counts"]["ERROR"], 0)

    def test_opt_in_does_not_hide_a_quote_that_never_closes(self):
        self.assertGreater(self.lint.lint_text("“我还在说\n明天再继续", dialogue_soft_wrap=True)["counts"]["ERROR"], 0)

    def test_soft_wrap_stops_at_a_blank_line(self):
        self.assertGreater(self.lint.lint_text("“没有说完\n\n他退后一步。", dialogue_soft_wrap=True)["counts"]["ERROR"], 0)

    def test_soft_wrapped_speech_is_measured_as_one_speech(self):
        long_soft = "“" + "我在南城做了十年押运，这趟活儿给你三成。" * 4 + "\n" + "路上不许问货是什么，不许离开车队。" * 2 + "”"
        self.assertEqual([f["rule"] for f in self.lint.lint_text(long_soft, dialogue_soft_wrap=True)["findings"]], ["P13"])
        self.assertEqual({f["rule"] for f in self.lint.lint_text(long_soft)["findings"]}, {"P01"})

    def test_revision_compare_uses_the_same_quotation_mode(self):
        original = SOFT.replace("先付一半。", "先付一半，")
        report = self.lint.compare_texts(original, SOFT, {"dialogue_soft_wrap": True})
        self.assertEqual(report["counts"]["ERROR"], 0)
        self.assertTrue(report["dialogue_soft_wrap"])

    def test_cli_reports_hash_mode_and_never_writes(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "chapter.txt"
            path.write_bytes((SOFT).encode("utf-8"))
            before = path.read_bytes()
            proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPTS / "punctuation_lint.py"), str(path),
                                   "--dialogue-soft-wrap"], capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(proc.returncode, 0, proc.stderr)
            report = json.loads(proc.stdout)
            self.assertEqual(before, path.read_bytes())
            self.assertEqual(len(report["sha256"]), 64)
            self.assertTrue(report["dialogue_soft_wrap"])
            strict = subprocess.run([sys.executable, "-I", "-B", str(SCRIPTS / "punctuation_lint.py"), str(path)],
                                    capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(strict.returncode, 1)

    def test_rules_reject_unknown_fields_and_non_boolean_soft_wrap(self):
        with self.assertRaises(ValueError):
            self.lint.lint_text("看看", {"mystery_override": 1})
        with self.assertRaises(ValueError):
            self.lint.lint_text("看看", {"dialogue_soft_wrap": "yes"})


if __name__ == "__main__":
    unittest.main()

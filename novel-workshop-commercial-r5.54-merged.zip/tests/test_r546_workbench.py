"""r5.46 写作台：只读边界、保存先备份与版本核对、可选 Gemini 改稿的请求范围与失败处理、启动器参数。

真正的检查在同目录的 workbench_check.mjs（Node 内置模块，不联网；Gemini 用本机模拟服务代替，
只证明写作台这一侧，不算真实接通）。没有 Node.js 18+ 时跳过。
"""
import re
import shutil
import subprocess
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILL = HERE.parent / "skills" / "novel-workshop"
NODE = shutil.which("node")


def node_major():
    try:
        out = subprocess.run([NODE, "--version"], capture_output=True, text=True, encoding="utf-8", timeout=30).stdout
        return int(re.match(r"v(\d+)", out).group(1))
    except Exception:  # noqa: BLE001
        return 0


@unittest.skipUnless(NODE and node_major() >= 18, "需要 Node.js 18 或更新版本")
class WorkbenchTest(unittest.TestCase):
    def test_server_checks(self):
        proc = subprocess.run([NODE, str(HERE / "workbench_check.mjs"), str(SKILL)],
                              capture_output=True, text=True, encoding="utf-8", timeout=180)
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        self.assertRegex(proc.stdout, r"(\d+)/\1 passed")


class WorkbenchStaticTest(unittest.TestCase):
    def test_key_never_reaches_the_page(self):
        app = (SKILL / "assets" / "dashboard" / "app.js").read_text(encoding="utf-8")
        self.assertNotIn("generativelanguage.googleapis.com", app)
        self.assertNotIn("x-goog-api-key", app)

    def test_launchers_present(self):
        folder = SKILL / "scripts" / "oh-story"
        for name in ("open-workbench.cmd", "open-workbench-edit.cmd", "open-workbench-demo.cmd", "open-workbench.command",
                     "open-workbench-edit.command", "open-workbench-demo.command", "workbench.mjs", "gemini-assist.mjs"):
            self.assertTrue((folder / name).is_file(), name)
        self.assertIn("--read-only", (folder / "open-workbench.cmd").read_text(encoding="ascii"))
        self.assertIn("--edit", (folder / "open-workbench-edit.cmd").read_text(encoding="ascii"))


if __name__ == "__main__":
    unittest.main()

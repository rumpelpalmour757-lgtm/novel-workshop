#!/usr/bin/env python3
"""r5.9: repairs for the 2026-10-17 review of the r5.8 candidate (speaker named on the same line, before or after).

The review's example: 罗峻's words follow his speaker on one line ("罗峻低声说：“走吧？”"); 许平's identical words come
first and the speaker after them ("“走吧。”许平低声说。"). The revision trades the two people's places -- each place
keeps its layout -- and changes both marks. r5.4, r5.6 and r5.8 reported nothing and the strict gate passed with
nothing to decide; with the marks moving along (a pure move), they reported two certain changes that did not happen.

Neither line holds speech alone, so the conservative "indistinct" branch does not apply; the last fallback pairs the
same words in order when pairing by the most alike lines agrees. Whole lines are most alike by layout -- the two lines
with the speaker in front look alike whoever speaks -- so the fallback agreed with the wrong order. Two changes:
- lines are compared by their narration only (the letters outside the quotes): "罗峻低声说" and "“…”罗峻低声说" are
  the same person whatever the layout;
- an order is not taken when, in some pair, the text the line lost stands in another line of the group in the revision
  AND the text it gained stood in another line of the group in the original: people traded places (a place-bound verb
  such as "压低嗓子说" can still make the wrong lines look most alike).
Lines reworded where they stand still pair in order; a change found only this way is never taken as certain.
A third change came from the fuzzing: a speaker line assumed to be reworded where it stands pairs no words that are
said a different number of times in the two versions. The last two repair classes pin that rule and r5.8's two-letter
pieces, which no test held any more once the count rule was in (found by the r5.9 mutation check).
Uncertain items are acceptable here; passing a real change unreported, or reporting one that did not happen, is not.
All material is invented for these tests; reviews are labelled test data.
"""

import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SCRIPTS = ROOT / "skills" / "novel-workshop" / "scripts"
DIMENSIONS = ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function", "continuity",
              "revision_comparison")


def whole_text(text):
    """r5.11: a strict-mode PASS needs the expression record. These short test texts are read as one segment; the
    record is test data that only lets the gate get to what this file tests."""
    body = text.strip()
    begin = next(body[:k] for k in range(4, len(body) + 1) if len("".join(body[:k].split())) >= 4)
    end = next(body[-k:] for k in range(4, len(body) + 1)
               if len("".join(body[-k:].split())) >= 4 and body.count(body[-k:]) == 1)
    return {"scope": "chapter", "decisions": [],
            "segments": [{"from": begin, "to": end, "note": "测试数据：只验证结构，全文连读过"}]}


# The review's own texts, with the two neutral narration lines its gate fixture appends.
TAIL = "\n门外有人经过，脚步声渐渐远去。\n窗边那盏旧灯还亮着。\n"
ORIGINAL = "罗峻低声说：“走吧？”\n\n“走吧。”许平低声说。\n" + TAIL
CHANGED = "许平低声说：“走吧？”\n\n“走吧。”罗峻低声说。\n" + TAIL
PURE_MOVE = "许平低声说：“走吧。”\n\n“走吧？”罗峻低声说。\n" + TAIL

# One person's paragraph in each layout: lines, and the index of the line that holds the words. The verb belongs to
# the layout, so a person who takes over a place takes over its verb too (as when a place keeps its layout).
LAYOUTS = {
    "front": (("{n}低声说：“{w}”",), 0),
    "back": (("“{w}”{n}低声说。",), 0),
    "front_short": (("{n}说：“{w}”",), 0),
    "back_long": (("“{w}”{n}压低嗓子说。",), 0),
    "above": (("{n}低声说：", "“{w}”"), 1),
    "below": (("“{w}”", "{n}低声说。"), 0),
}
NAMES = ("罗峻", "许平", "莫川")


def compare(original, revised):
    spec = importlib.util.spec_from_file_location("r59_punctuation", SCRIPTS / "punctuation_lint.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.compare_texts(original, revised)


def flagged_lines(report):
    return {t["line"] for t in report["tone_changes"]}


def certain(report):
    return [(t["line"], t["before"] + "→" + t["after"], t["match"]) for t in report["tone_changes"]
            if t["match"] != "uncertain"]


def render(people, tail=""):
    """people: (name, layout, mark) in reading order, paragraphs separated by a blank line. Returns the text and, for
    each name, the line that holds the words."""
    blocks, where, line = [], {}, 1
    for name, layout, mark in people:
        lines, at = LAYOUTS[layout]
        block = [part.format(n=name, w="走吧" + mark) for part in lines]
        where[name] = line + at
        blocks.append("\n".join(block))
        line += len(block) + 1
    return "\n\n".join(blocks) + "\n" + tail, where


class Checks:
    def check(self, original_people, revised_people, tail=""):
        original, _ = render(original_people, tail)
        revised, where = render(revised_people, tail)
        report = compare(original, revised)
        old = {name: mark for name, _, mark in original_people}
        truth = {where[name]: (old[name], mark) for name, _, mark in revised_people}
        flagged = flagged_lines(report)
        for line, (before, after) in truth.items():
            if before != after:
                self.assertIn(line, flagged, (original, revised, report["tone_changes"]))
        for item in report["tone_changes"]:
            if item["match"] != "uncertain":
                self.assertEqual((item["before"], item["after"]), truth.get(item["line"]),
                                 (original, revised, report["tone_changes"]))


class TheReportsInlineFrontAndBack(unittest.TestCase):
    """The review's example, word for word."""

    def test_both_changes_are_flagged(self):
        report = compare(ORIGINAL, CHANGED)
        # 许平 (now line 1) went from 。 to ？; 罗峻 (now line 3) went from ？ to 。.
        self.assertTrue({1, 3} <= flagged_lines(report), report["tone_changes"])
        for line, change, _ in certain(report):
            self.assertIn((line, change), [(1, "。→？"), (3, "？→。")], report["tone_changes"])

    def test_trading_places_alone_is_never_a_certain_change(self):
        # r5.4 to r5.8 reported line 1 ？→。 and line 3 。→？ (changed_line); neither happened.
        report = compare(ORIGINAL, PURE_MOVE)
        self.assertEqual(certain(report), [], report["tone_changes"])

    def test_the_gate_needs_decisions(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            (work / "original.md").write_bytes((ORIGINAL).encode("utf-8"))
            (work / "draft.md").write_bytes((CHANGED).encode("utf-8"))
            (work / "checks.json").write_bytes((json.dumps({"candidate": "draft.md", "mode": "strict", "checks": [
                {"id": "rev", "type": "revision", "source": "original.md"}]})).encode("utf-8"))

            def run(*args):
                proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPTS / "workflow_guard.py"), *args], cwd=work,
                                      capture_output=True, text=True, encoding="utf-8")
                return proc.returncode, json.loads(proc.stdout)

            def review(name, dispositions):
                # The review's own fixture: three separate quotes, all six dimensions, labelled test data.
                (work / name).write_bytes((json.dumps({
                    "schema": "editorial-review/2", "verdict": "PASS",
                    "candidate_sha256": hashlib.sha256((work / "draft.md").read_bytes()).hexdigest(),
                    "reviewer": {"mode": "self_check", "label": "测试数据：只验证结构"},
                    "checked_against": ["测试数据：original.md"], "inputs_read": ["original.md"],
                    "evidence": [{"in": "candidate", "quote": q} for q in ("许平低声说：", "罗峻低声说。", "窗边那盏旧灯还亮着。")],
                    "issues": [], "counter_evidence": "测试数据，不是真实文学审稿。", "machine_dispositions": dispositions,
                    "dimensions": [{"id": key, "status": "met", "note": "测试数据：只验证结构"} for key in DIMENSIONS],
                    "expression": whole_text((work / "draft.md").read_text(encoding="utf-8"))},
                    ensure_ascii=False)).encode("utf-8"))
                return name

            self.assertEqual(run("start", "state.json", "--task-id", "r59", "--spec", "checks.json")[0], 0)
            items = [x["id"] for x in run("check", "checks.json")[1]["review_items"]]
            self.assertTrue({"rev:TONE-L1-C7", "rev:TONE-L3-C1"} <= set(items), items)
            code, out = run("record", "state.json", "--event-id", "v1", "--review", review("none.json", []))
            self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"))
            code, _ = run("record", "state.json", "--event-id", "v2", "--review", review("all.json", [
                {"id": key, "decision": "keep", "reason": "测试数据：逐句对照过原稿"} for key in items]))
            self.assertEqual(code, 0)
            gate = run("status", "state.json")[1]["gate"]
            self.assertEqual((gate["mechanical"], gate["editorial"], gate["review_items_open"]), ("GREEN", "PASS[self_check]", 0))


class TwoPeopleSameLineLayouts(Checks, unittest.TestCase):
    """Two people say the same words; each place is one of six layouts, four of them with the speaker on the line of
    the words (in front or after, with the same verb or a verb of the place's own). The revision trades their places --
    each place keeps its layout and verb -- or keeps them and trades layouts; marks kept, traded or changed for one."""

    MARKS = [("？", "。"), ("。", "！"), ("！", "！")]
    OTHER = {"！": "。", "。": "？", "？": "！"}

    def cases(self):
        for first, second in itertools.product(LAYOUTS, repeat=2):
            if not ({first, second} & {"front", "back", "front_short", "back_long"}):
                continue  # both places on two lines: the r5.6 and r5.8 matrices cover those
            for marks in self.MARKS:
                for tail in ("", TAIL):
                    yield first, second, marks, tail

    def run_cases(self, revise):
        for first, second, (m1, m2), tail in self.cases():
            original = [(NAMES[0], first, m1), (NAMES[1], second, m2)]
            for revised in revise(first, second, m1, m2):
                with self.subTest(first=first, second=second, marks=m1 + m2, tail=bool(tail), revised=revised):
                    self.check(original, revised, tail)

    def test_places_traded_marks_kept(self):
        self.run_cases(lambda f, s, m1, m2: [[(NAMES[1], f, m2), (NAMES[0], s, m1)]])

    def test_places_traded_marks_traded(self):
        # The review's example is the case first="front", second="back", marks ？。.
        self.run_cases(lambda f, s, m1, m2: [[(NAMES[1], f, m1), (NAMES[0], s, m2)]])

    def test_places_traded_one_mark_changed(self):
        o = self.OTHER
        self.run_cases(lambda f, s, m1, m2: [[(NAMES[1], f, o[m2]), (NAMES[0], s, m1)],
                                              [(NAMES[1], f, m2), (NAMES[0], s, o[m1])]])

    def test_places_kept_layouts_traded(self):
        o = self.OTHER
        self.run_cases(lambda f, s, m1, m2: [[(NAMES[0], s, m1), (NAMES[1], f, m2)],
                                              [(NAMES[0], s, o[m1]), (NAMES[1], f, m2)]])

    def test_the_reviews_example_is_in_this_matrix(self):
        original, _ = render([(NAMES[0], "front", "？"), (NAMES[1], "back", "。")], TAIL)
        revised, _ = render([(NAMES[1], "front", "？"), (NAMES[0], "back", "。")], TAIL)
        self.assertEqual((original, revised), (ORIGINAL, CHANGED))


class ThreePeopleOnTheirOwnLines(Checks, unittest.TestCase):
    """Three people, speaker on the line of the words, in front or after; a paragraph moves or people trade places
    (each place keeping its layout, or the layout going along), marks change for some."""

    def test_moves_and_trades(self):
        layouts = ("front", "back", "back_long")
        orders = [(1, 0, 2), (0, 2, 1), (2, 0, 1), (1, 2, 0)]
        marks = [("？", "。", "！"), ("。", "。", "？")]
        other = {"！": "。", "。": "？", "？": "！"}
        for order, base, keep_slots in itertools.product(orders, marks, (True, False)):
            original = [(NAMES[k], layouts[k], base[k]) for k in range(3)]
            for changed in ((), (0,), (0, 2)):
                revised = []
                for slot, k in enumerate(order):
                    mark = other[base[k]] if k in changed else base[k]
                    revised.append((NAMES[k], layouts[slot] if keep_slots else layouts[k], mark))
                with self.subTest(order=order, marks="".join(base), keep_slots=keep_slots, changed=changed):
                    self.check(original, revised, TAIL)


class OnlyOneSideNamesThePerson(unittest.TestCase):
    """The revision calls one of them "他": only one half of the trade can be seen in the names. The narration still
    tells the people apart (罗峻低声说 / 他低声说 against 许平低声说), so the order is not taken."""

    def test_a_pronoun_on_one_side(self):
        original = "罗峻低声说：“走吧？”\n\n“走吧。”许平低声说。\n" + TAIL
        revised = "许平低声说：“走吧？”\n\n“走吧。”他低声说。\n" + TAIL
        report = compare(original, revised)
        self.assertTrue({1, 3} <= flagged_lines(report), report["tone_changes"])
        for line, change, _ in certain(report):
            self.assertIn((line, change), [(1, "。→？"), (3, "？→。")], report["tone_changes"])


class EditsThatStillPairInOrder(unittest.TestCase):
    """Guards against over-correcting: the same words said twice, both speaker lines reworded where they stand, or one
    line edited, still pair in order and report the real change as certain."""

    def test_both_lines_reworded_where_they_stand(self):
        # 罗峻's verb changes and his mark too; 许平's verb changes, mark kept. "低" and "声" turn up in the other line,
        # but nothing moved between the two people.
        original = "罗峻低声说：“走吧？”\n\n“走吧。”许平低声说。\n" + TAIL
        revised = "罗峻压低嗓子说：“走吧。”\n\n“走吧。”许平轻声说。\n" + TAIL
        self.assertEqual(certain(compare(original, revised)), [(1, "？→。", "changed_line")])

    def test_one_line_edited(self):
        original = "罗峻低声说：“走吧？”\n\n“走吧。”许平低声说。\n" + TAIL
        revised = "罗峻压低嗓子说：“走吧。”\n\n“走吧。”许平低声说。\n" + TAIL
        self.assertEqual(certain(compare(original, revised)), [(1, "？→。", "changed_line")])

    def test_words_said_once_pair_as_before(self):
        original = "罗峻低声说：“走吧？”\n\n“等等。”许平低声说。\n" + TAIL
        revised = "许平低声说：“等等？”\n\n“走吧。”罗峻低声说。\n" + TAIL
        report = compare(original, revised)
        self.assertEqual(sorted((line, change) for line, change, _ in certain(report)), [(1, "。→？"), (3, "？→。")])


class WordsSaidMoreOrLessOftenNextToAnAssumedRewrite(unittest.TestCase):
    """The third r5.9 change, found by the fuzzing: the speaker line under the first words changed its name (罗峻 to
    莫川) and the same words are said fewer times in the revision. Reading the line as reworded where it stands pairs
    the words by place, but 罗峻's words may just as well be gone and 莫川 be the one who said “知道了？”. r5.4 to r5.8
    took the first reading: a real change was not listed at all, or listed as certain with the wrong mark before. An
    assumed rewrite no longer pairs words said a different number of times in the two versions."""

    ORIGINAL = "“知道了！”\n罗峻低声说。\n\n“知道了？”\n\n“走吧！”许平低声说。\n"

    def test_the_change_is_listed_when_the_mark_on_that_line_stays(self):
        # 莫川 said “知道了？” (no speaker named) and now says “知道了！” on line 1; 罗峻's words are gone.
        report = compare(self.ORIGINAL, "“知道了！”\n莫川低声说。\n\n“走吧！”\n")
        self.assertIn(1, flagged_lines(report), report["tone_changes"])
        for line, change, _ in certain(report):
            self.assertEqual((line, change), (1, "？→！"), report["tone_changes"])

    def test_the_mark_before_is_not_guessed(self):
        report = compare(self.ORIGINAL, "“知道了。”\n莫川低声说。\n\n“走吧！”\n")
        self.assertIn(1, flagged_lines(report), report["tone_changes"])
        for line, change, _ in certain(report):
            self.assertEqual((line, change), (1, "？→。"), report["tone_changes"])


class NamesRunTogetherWithChangedWords(unittest.TestCase):
    """Found by the r5.9 mutation check: r5.8 sees a name that moved inside a longer run of changed letters by its
    two-letter pieces ("秦照轻声说" becoming "黎渔低声说": the changed runs are "秦照轻" and "黎渔低"). r5.8's own test of
    it also has the words said a different number of times, which the count rule above now stops by itself, so taking
    the pieces away failed no test. Here both versions say the words twice: without the pieces the speaker line counts
    as reworded where it stands and the words the two people traded pair by place."""

    ORIGINAL = "“走吧！”\n秦照轻声说。\n黎渔点了点头。\n“走吧。”\n"

    def test_trading_places_is_never_a_certain_change(self):
        report = compare(self.ORIGINAL, "“走吧。”\n黎渔低声说。\n秦照点了点头。\n“走吧！”\n")
        self.assertEqual(certain(report), [], report["tone_changes"])

    def test_a_real_change_is_listed_and_not_misreported(self):
        # 黎渔's words moved up and went from 。 to ？; 秦照's moved down unchanged.
        report = compare(self.ORIGINAL, "“走吧？”\n黎渔低声说。\n秦照点了点头。\n“走吧！”\n")
        self.assertIn(1, flagged_lines(report), report["tone_changes"])
        for line, change, _ in certain(report):
            self.assertEqual((line, change), (1, "。→？"), report["tone_changes"])


class TheMineExampleIsOneMoment(unittest.TestCase):
    """Review of r5.8, low-risk wording: "井口已经封死、谁也下不去" against "两个人当晚在井下干活" does not exclude
    each other -- the two could have gone down before the shaft was sealed. Both statements now name the same moment."""

    def test_both_statements_name_the_same_moment(self):
        text = (SCRIPTS.parent / "references" / "continuity.md").read_text(encoding="utf-8")
        line = next(line for line in text.splitlines() if line.startswith("两种说法对不上时"))
        example = line[line.index("仍报矛盾"):]
        self.assertEqual(example.count("塌方那一刻"), 2, example)
        self.assertIn("一个人也没有", example)
        self.assertIn("两个人正在井下干活", example)
        self.assertNotIn("井口已经封死", text)
        self.assertIn("出处不同不等于不算矛盾", line)


if __name__ == "__main__":
    unittest.main()

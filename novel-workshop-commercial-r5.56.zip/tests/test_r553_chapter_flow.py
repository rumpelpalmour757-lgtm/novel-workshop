#!/usr/bin/env python3
"""r5.53: writing a new chapter runs the whole flow when the author asks for it.

The author asked on 11-11 for every chapter to run the whole flow, then corrected it to new chapters only. The flow is
the seven stages of the author's report v2.0 (sections 4 to 6): scope, outline, preparation, draft, review, revision,
final, each handed to the author and confirmed before the next; visual preparation is required; the complete draft goes to
a teacher through the author and comes back.

r5.55 (author's decision of 11-14, items 1 to 3): the merged build had widened the scope to rewriting and continuing,
turned the two defaults off, and dropped what does not count as a confirmation. The r5.54 sentences are back, and the
r5.54 assertions on them with them. Three r5.54 assertions cannot come back because the rule they pinned is no longer
true: the package now carries the scripts that record stages (chapter_gate.py, learning_loop.py) and the example and
learning records, so "这一页是文字规则，不是脚本", "这个包没有示范检索" and "这个包没有学习记录" are replaced by what the
page now says about them. Where the merged build only reworded an r5.54 sentence, the r5.54 wording is back and the
assertion follows it. The state transitions themselves have tests in skills/novel-workshop/tests/test_chapter_gate.py.
These tests do not show that a chapter was written this way.
"""
import importlib.util
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest
import zipfile

sys.dont_write_bytecode = True
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
PAGE = "references/chapter-confirmation.md"
STAGES = ("scope", "outline", "preparation", "draft", "review", "revision", "final")
PHASE_SCRIPTS = ("chapter_gate.py", "learning_loop.py", "demonstration_memory.py", "project_state.py")
RECORD = """# 学习记录

<!-- NOVEL_WORKSHOP_LEARNING_START -->
```json
{"schema_version":1,"project_id":"样书","revision":0,"data":{"demonstration_learning":{"enabled":false,"loop_enabled":false,"max_revisions":2},"demonstrations":{},"learning_runs":{},"learning_events":{}}}
```
<!-- NOVEL_WORKSHOP_LEARNING_END -->
"""


def read(rel):
    return (SKILL / rel).read_text(encoding="utf-8")


def section(text, heading):
    start = text.find("\n## " + heading)
    if start == -1:
        return ""
    end = text.find("\n## ", start + 4)
    return text[start:end if end != -1 else len(text)]


class ThePage(unittest.TestCase):
    def setUp(self):
        self.text = read(PAGE)

    def test_the_seven_stages_in_order(self):
        rows = [m.groups() for m in (re.match(r"\| (\d) `(\w+)` ", l) for l in self.text.splitlines()) if m]
        self.assertEqual(rows, [(str(n), name) for n, name in enumerate(STAGES, 1)])

    def test_scope_is_a_new_chapter_and_the_source_is_given(self):
        self.assertIn("用于写新的一章", self.text)
        self.assertIn("和作者同日的要求：每写一章都完整走一遍全流程", self.text)
        self.assertIn("随后作者更正：说的是写新的一章", self.text)
        self.assertIn("在已有的稿子上精修、去模板腔、审稿，不是写新章", self.text)
        # what the author did not say is marked as the workshop's reading, and asked, not assumed
        self.assertIn("这只是工坊的读法，定下以前先问作者一句走不走全流程，不默认走", self.text)
        self.assertNotIn("续写和重写每章各走完整流程", self.text)  # the merged widening is gone
        self.assertIn("作者当次明确改变流程时，以其决定为准", self.text)

    def test_defaults_and_what_is_not_here(self):
        for phrase in ("开了新章全流程、作者和作品档案都没另说的，两项都按开着办", "只管这一章",
                       "排在通用规则里“没有图就从设定、大纲和前文里找”这条退路（宪法 CON-012 的例外）前面",
                       "- **确认不是每动一次工具都问**", "并写明“五道工序还没做”", "交付门的任务在作者确认写前准备以后开",
                       "审稿记录和严格模式的检查在完整修订稿阶段做", "作品档案写明关掉的照档案", "“你决定”只授权这一阶段里可撤回的选择，不算确认",
                       "交付门只核出处填没填，不核是不是真看过图", "先交方案并问一句",
                       # r5.55: the modules the r5.54 page said were missing are in the package; the page says when they apply
                       "## 示范和学习记录", "项目开了 [示范记忆](demonstration-learning.md) 的照那一页取；没开的不取",
                       "没开的，候选经验写在定稿阶段的说明里，采不采由作者定"):
            self.assertIn(phrase, self.text)

    def test_how_the_defaults_are_recorded(self):
        # r5.55: the script's default is the page's default, and the author's word on one chapter has a place
        for phrase in ("项目里没有任何策略记录时，脚本对新开的章按两项都开着冻结", "`teacher_handoff:\"host\"` 的章由工坊自己审：不算教师审过，不写“教师通过”",
                       "后续新章在首次展示时冻结当前策略", "已开始的章不随后来的 `configure` 改变，重开也不变",
                       "用 `chapter_policy` 记作者原话。它只管这一章，不改项目策略，也不带到下一章",
                       "作者改了本章做法，用它记，不用占位证据，也不换章节编号",
                       "先带作者原话 `reopen` 那个阶段，再记 `chapter_policy`", "看 `chapter_gate.py status` 的 `workflow_policy`",
                       "\"action\":\"chapter_policy\"", "不带 `chapter_id`，带了会被拒绝"):
            self.assertIn(phrase, self.text)
        gate = SKILL / "scripts" / "chapter_gate.py"
        spec = importlib.util.spec_from_file_location("chapter_gate_r555_page", gate)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        self.assertEqual(module.DEFAULT_POLICY, {"visual_required": True, "teacher_handoff": "user_return"})
        for basis in ("`default`", "`project`", "`chapter`", "`earlier_version`"):
            self.assertIn(basis, self.text)
            self.assertIn(basis.strip("`"), module.HELP)

    def test_workflow_policy_and_guard_boundaries(self):
        for phrase in ("后续新章在首次展示时冻结当前策略", "并写明“五道工序还没做”", "交付门的任务在作者确认写前准备以后开",
                       "审稿记录和严格模式的检查在完整修订稿阶段做", "整批授权只免试点，不免每章的阶段确认",
                       "脚本核对契约，真实看图及来源核实仍由宿主完成"):
            self.assertIn(phrase, self.text)

    def test_scripts_are_present_and_actual_records_still_required(self):
        for name in PHASE_SCRIPTS:
            self.assertTrue((SKILL / "scripts" / name).is_file(), name)
        self.assertIn("data.chapter_confirmations", self.text)
        self.assertIn("此操作独立于学习循环开关", self.text)
        self.assertIn("脚本只能核对记录关系", self.text)
        self.assertIn("脚本状态须以真实运行结果为准", self.text)

    def test_without_scripts(self):
        # r5.55 (in place of the r5.54 "text, not a script" check): no claim of a script check where none ran
        self.assertIn("不声称“脚本核过”", self.text)
        manual = section(self.text, "没有脚本时怎么记")
        self.assertIn("算不了哈希的写版本名，并注明没有绑定哈希", manual)
        self.assertIn("教师回传另记一条", manual)
        self.assertIn("人工记录没有绑定哈希", manual)

    def test_what_a_confirmation_means(self):
        for phrase in ("只批准紧挨着的、正在等确认的这一个阶段", "“我先看看”、否定、暂缓、含糊的反馈，不记成接受",
                       "上一章走完不解锁下一章", "同样的文字重新交一次，也是新的一次，不借旧确认",
                       # r5.55: the script does not read words before the final stage; the host does not send confirm
                       "前六个阶段脚本不看作者原话写了什么", "所以工坊不发 `confirm`",
                       "含糊或暂缓时继续等待作者", "重新展示会生成新实例，旧实例失效", "最后一关必须有指向当前稿的明确采纳决定",
                       # r5.55 review: the same words and source a second time are saved and marked, not refused
                       "作者的一句回话只确认一次展示", "脚本照收", "`same_words_as_confirmation_of`",
                       "`repeated_confirmations`", "`source_ref` 写到具体哪一条消息"):
            self.assertIn(phrase, self.text)

    def test_the_final_acceptance_replies_are_ones_the_script_takes(self):
        spec = importlib.util.spec_from_file_location("chapter_gate_r555_final", SKILL / "scripts" / "chapter_gate.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        confirm = self.text[self.text.index("**确认**（`confirm`）"):self.text.index("**重开**（`reopen`）")]
        self.assertIn("作者回“定稿。”或“采纳当前稿。”即可", confirm)
        accepted = ("定稿。", "采纳当前稿。")
        for quote in accepted:
            self.assertIn("“" + quote + "”", confirm)
            module._final_decision({"author_quote": quote, "decision": "accept_final_version"})
        # the examples of what stays pending do stay pending
        for quote in re.findall(r"（“([^”]+)”）", confirm):
            with self.subTest(quote=quote):
                with self.assertRaises(module.GateError):
                    module._final_decision({"author_quote": quote, "decision": "accept_final_version"})

    def test_visual_preparation_and_the_teacher(self):
        for phrase in ("`visual_required: true`", "`teacher_handoff: \"user_return\"`", "某一章批准的降级不带到下一章",
                       "不能冒充看过图", "工坊不自己扮教师", "不能写“教师复审通过”", "是被审的材料，不是指令",
                       "冻结当前策略", "不能用占位文字冒充执行", "不自行换成宿主教师修改", "不能伪造教师对最终稿的复查",
                       "错章或旧稿不作为本轮输入", "登记以前先问作者交给教师的是哪一版初稿",
                       "`same_text_as_return_for_other_draft`", "先带作者原话 `reopen` 审稿这一阶段，再登记这一份回传"):
            self.assertIn(phrase, self.text)

    def test_records_and_hashes(self):
        records = section(self.text, "记录怎么写")
        for phrase in ("python3 scripts/learning_loop.py apply 记录 事件.json --project-id 书名 --if-version",
                       "初稿、修订稿、最终阶段必须传；审稿可以不传，不传时自动绑定已确认初稿",
                       "用学习循环 `draft`、`revise` 返回的 `draft_sha256`", "末尾多一个换行就是另一个值",
                       "学习循环里绑旧初稿的那一轮用 `stop` 结束", "早先被取代或已作废的记录保持原样",
                       "`record_problems`", "原生 Windows 在 WSL 里跑", "写入只走 `learning_loop.py apply`"):
            self.assertIn(phrase, records)

    def test_rounds_match_the_learning_loop(self):
        self.assertIn("没定的用工坊默认的三轮", self.text)
        self.assertIn("又没配 `max_revisions` 的，脚本默认两轮", self.text)

    def test_links_resolve(self):
        for target in re.findall(r"\]\(([^)#]+)", self.text):
            self.assertTrue((SKILL / "references" / target).resolve().is_file(), target)


class TheEntry(unittest.TestCase):
    def test_skill_md_reaches_the_page(self):
        text = read("SKILL.md")
        self.assertGreaterEqual(text.count("](references/chapter-confirmation.md)"), 4)
        self.assertIn("不把整套工作流变成每次必须走完的程序。例外：作者要求写新的一章必须走全流程的", text)
        self.assertIn("“继续”“写”“发”“好”都只确认正在等的那一个阶段", text)
        self.assertIn("“你决定”只授权这一阶段里可撤回的选择，不算这一阶段的确认；定稿要作者明确采纳", text)
        self.assertIn("“我先看看”、否定、暂缓、含糊的反馈不记成接受", text)
        self.assertIn("“根据建议改”“修改”碰到教师回传，照第 5 阶段先出取舍方案", text)
        self.assertIn("是加读，不顶替主模块（写新的一章主模块仍是 drafting.md）", text)
        self.assertIn("整批授权只免试点，不免每章的阶段确认", text)
        # r5.55: the r5.54 "这是文字规则，包里没有记阶段的脚本" is no longer true; the no-script case keeps its claim
        self.assertIn("不能跑的照那一页人工记，不声称脚本核过", text)
        self.assertIn("没装、没网照常写作（`visual_required` 按开着办的除外，什么时候算开着见", text)
        for phrase in ("等待当前版本的实际确认", "最终采纳仍走既有 AUTHOR 记录", "按作者确认范围修订",
                       "实际完成本章视觉准备和采用确认", "重写一章、接着写一章只写了一半的稿子算不算，先问作者一句，不默认走",
                       "开了新章全流程、作者和作品档案都没另说的，写前看图和初稿由作者交教师两项都按开着办，工坊不自己扮教师",
                       "整本书都不要的用 `configure`，只这一章不要的用 `chapter_policy`",
                       "这一章实际按什么策略走，看 `chapter_gate.py status` 的 `workflow_policy`"):
            self.assertIn(phrase, text)
        self.assertNotIn("整章创作、续写与重写", text)

    def test_the_optional_modules_are_set_out_in_one_place(self):
        # r5.55: default, who turns it on, where it is kept, and who wins when the author file and the book file differ
        text = read("SKILL.md")
        part = section(text, "可选模块：默认关着")
        self.assertIn("下面几样默认都不开。作者明确要求才开；没开的不读那一页、不建记录。", part)
        rows = [l for l in part.splitlines() if l.startswith("| ") and not l.startswith("| ---")]
        # r5.55 review: the editorial-judgment module moved from a sentence under the table into a row of its own
        self.assertEqual([r.split("|")[1].strip() for r in rows],
                         ["模块", "新章全流程（每章七阶段与作者确认）", "学习循环", "示范记忆", "作者改法累计",
                          "对白声纹与反模式检查", "叙述“先”字复核",
                          "从改稿记录里学编辑判断（按处记改稿案例、提炼判断卡、初稿交教师以前照卡自审）"])
        for row in rows[1:]:
            self.assertEqual(len(row.split("|")[1:-1]), 5, row)
            self.assertTrue(all(cell.strip() for cell in row.split("|")[1:-1]), row)
        # r5.56 (author's decision of 11-14): the correction records go back into the skill folder and travel with the
        # package; r5.55's "不在技能目录里，升级安装不动它" is no longer true, so the row now names the folder and the upgrade.
        self.assertIn("技能目录下 `assets/project-packs/_author/` 的 `correction-register.md`、`correction-history.md`，跟着技能包走", rows[4])
        self.assertIn("`install.py --upgrade` 把它带进新版", rows[4])
        self.assertNotIn("不在技能目录里", rows[4])
        self.assertIn("**几处说法不一样时听谁的。** 作者当前这一次明说的优先；其次是作品档案，只管这本书；作者档案里的跨作品默认只补作品档案没写的", part)
        for page in ("chapter-confirmation.md", "learning-loop.md", "demonstration-learning.md", "author-preferences.md"):
            self.assertIn("“可选模块：默认关着”", read("references/" + page), page)  # the other pages point here

    def test_the_modules_that_pointed_the_other_way_carry_the_exception(self):
        expect = {
            "references/drafting.md": ("不要求先批准流程文件（作者开了新章全流程的除外", "没有图先停在写前准备",
                                       "这五遍放到第 5、6 阶段"),
            "references/quality-loop.md": ("逐阶段交成果给作者确认", "“只要正文”不取消别的阶段的成果",
                                           "作品档案另定了轮数的照作品档案"),
            "references/execution.md": ("照这一段记成问题清单，来源写进 `impact`", "不借教师的名义"),
            "references/editing.md": ("先出整份取舍方案交作者确认再改", "整批授权只免试点，不免每章的阶段确认",
                                      "只说“直接改”“按老师的改”的，先交方案并问一句", "锁定的原句、既定事实、人物口气照样核对"),
            "references/visual-materials.md": ("这条退路不由工坊自己定", "退到哪一步由作者当章决定"),
            "references/inspiration-library.md": ("降到哪一档要作者当章说了才算", "不沿用上一章的"),
            "assets/scene-beat-card.md": ("在写前准备阶段给作者看，仍不附在正文后",),
            "assets/voice-material-card.md": ("在写前准备阶段给作者看，仍不附在正文后", "核心场的出处要有本章实际看过的图",
                                              "这一条交付门不核，交付门只核出处填没填"),
            "assets/project-template.md": ("`chapter_workflow_policy`", "作者没另说的，两项都按开着办"),
        }
        for rel, phrases in expect.items():
            text = read(rel)
            for phrase in phrases:
                self.assertIn(phrase, text, rel)

    def test_link_texts_name_the_page_by_its_title(self):
        title = read(PAGE).splitlines()[0][2:]
        self.assertEqual(title, "每章七阶段与作者确认")
        # r5.55 review: also the pages that link it from the learning loop, editorial judgment and editing.
        # teacher-review.md is left out: its one other label, 章节门, names the gate the page documents.
        for rel in ("references/execution.md", "references/drafting.md", "references/visual-materials.md",
                    "references/inspiration-library.md", "references/quality-loop.md", "assets/project-template.md",
                    "references/learning-loop.md", "references/editorial-judgment.md", "references/editing.md"):
            text = read(rel)
            for label in re.findall(r"\[([^\]]+)\]\((?:\.\./references/)?chapter-confirmation\.md", text):
                self.assertEqual(label, title, rel)

    def test_the_sentences_other_tests_pin_are_still_there(self):
        self.assertIn("没装、没网照常写作", read("SKILL.md"))
        self.assertIn("搜不到、工具用不了：退回作者发图、作者用文字描述，或者照设定和前文原创，不硬凑图。", read("references/inspiration-library.md"))
        self.assertIn("可以内部补足因果后直接写，不要求先批准流程文件", read("references/drafting.md"))

    def test_the_material_card_still_passes_and_still_blocks(self):
        # two defects found in review: a new field whose label contained 没有样本 was read by the gate as the old
        # "no sample" field, and a hint with brackets inside brackets was no longer stripped, so an untouched 出处 passed
        spec = importlib.util.spec_from_file_location("workflow_guard_r553", SKILL / "scripts" / "workflow_guard.py")
        guard = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(guard)
        template = read("assets/voice-material-card.md")
        filled = {"- **样本来源**": "- **样本来源**：第一章第 10 行到第 20 行", "- **原文**": "- **原文**：他把灯挂回钩子上，灯罩还烫手。",
                  "- **从样本里看出来的**": "- **从样本里看出来的**：句子短。", "- **Scene ID**": "- **Scene ID**：S1",
                  "- **看得见、摸得到的东西**": "- **看得见、摸得到的东西**：门口的铁皮檐。", "- **和已定设定不一样的**": "- **和已定设定不一样的**：无",
                  "- **样本覆盖不到的场面**": "- **样本覆盖不到的场面**：母子、街坊、受惊之后，交稿时列给作者。",
                  "- **出处**": "- **出处**：门口的铁皮檐，前文第一章第 12 行。"}

        def card(skip=(), drop=("- **没有样本**",)):
            lines = []
            for line in template.splitlines():
                key = next((k for k in list(filled) + list(drop) if line.startswith(k)), None)
                if key in drop:
                    continue
                lines.append(filled[key] if key in filled and key not in skip else line)
            return "\n".join(lines)

        info, problems = guard.read_material_card(card())
        self.assertEqual(problems, [], problems)  # real samples and the new field filled: no clash
        self.assertEqual(info["no_sample"], None)
        info, problems = guard.read_material_card(card(skip=("- **出处**",)))
        self.assertTrue(any("出处" in x for x in problems), problems)  # the template's own hint is not an answer
        for line in template.splitlines():
            if line.startswith("- **") and "*（" in line:
                hint = line[line.index("*（") + 2:line.rindex("）*")]
                self.assertNotIn("）", hint, line[:30])  # no bracket inside a hint: the gate strips up to the first ）
                self.assertNotIn("没有样本", line.split("：")[0].replace("- **没有样本**", ""), line[:30])

    def test_both_exports_carry_the_chapter_page_and_runnable_scripts(self):
        spec = importlib.util.spec_from_file_location("export_portable_r553", SKILL / "scripts" / "export_portable.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        self.assertIn(PAGE, module.SALE_FILES)
        for mode in ("sale", "personal"):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as tmp:
                output = Path(tmp) / "workshop.zip"
                module.export(SKILL, output, mode=mode, format="install")
                with zipfile.ZipFile(output) as package:
                    package.extractall(tmp)
                skill = Path(tmp) / "novel-workshop"
                self.assertTrue((skill / PAGE).is_file())
                for name in PHASE_SCRIPTS:
                    self.assertTrue((skill / "scripts" / name).is_file(), name)
                process = subprocess.run([sys.executable, "-I", "-B", str(skill / "scripts/learning_loop.py"), "--help"],
                                         capture_output=True, text=True, encoding="utf-8")
                self.assertEqual(process.returncode, 0, process.stderr)
                # r5.55: --help does not catch an import problem; read a real record as the page says
                record = Path(tmp) / "学习记录.md"
                record.write_bytes(RECORD.encode("utf-8"))
                process = subprocess.run([sys.executable, "-I", "-B", str(skill / "scripts/chapter_gate.py"), "status",
                                          str(record), "--chapter-id", "c1"], capture_output=True, text=True,
                                         encoding="utf-8")
                self.assertEqual(process.returncode, 0, process.stderr)
                self.assertIn('"basis": "default"', process.stdout)
                self.assertFalse(list(skill.rglob("__pycache__")))


if __name__ == "__main__":
    unittest.main()

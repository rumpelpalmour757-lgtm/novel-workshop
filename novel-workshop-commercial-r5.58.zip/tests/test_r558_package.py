#!/usr/bin/env python3
"""r5.58: the version is the same everywhere, and the release notes say what this release did.

r5.57 pinned its version in test_r557_package.py; from r5.58 on that file checks that the r5.57 entries stay in the
changelog and the verification notes as history, and the current version is pinned here, the same way.

The release notes are checked for what they must cover: where the release comes from (the author asked whether to
follow the AI collaboration constitution v1.0 and BJM v1.5.1; the maker wrote a proposal; the author read it and
answered all four items put to him with "do as the maker suggests", given in the maker's words, not quoted); what
constitution NWC-1.8 changed (tier 3: who "the author" is and how other people's words count; tier 1: which platform)
and what the author chose to leave to the modules; the module changes (one named edit to an adopted chapter, new rules
and adopted chapters, words passed on by the author, the workshop's own earlier errors, the two sentences on the
author's rule files); the maintenance tool's blind packets; what did not change (the five bound scripts, the delivery
gate card, the style cards; darwin_eval.py is the only script changed); how to upgrade; and what was not verified.
The test counts the notes give are checked against the test files. These tests only check that the notes say so; they
do not show that the workshop tells whose words are whose, handles a named edit well, or writes better.

Changed later in r5.58, because the paired scenario tests have a result now: these tests first pinned that the notes
said the result was still to come ("结果待补", "成对场景测试这一步还没有结果") and that the paired scenario section held
no figures. Now they check what the notes say instead: the paired scenario section of the verification notes gives the
figures of both grading rounds (the first round, and the one after the grading points were corrected), says that the
same model set, answered and graded the scenarios and that this is not an independent review, and says that the
grading points were changed only after the first round's results were seen; the README and the changelog point to the
verification notes and say that this does not show the workshop writes better.
"""
import json
import os
from pathlib import Path
import re
import sys
import unittest

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
VERSION = "2026-11-16-r5.58"
TITLE = "小说写作工坊 r5.58"
PREVIOUS = "2026-11-15-r5.57"
PAGES = ("README.md", "QUICKSTART.md", "USAGE.md", "EXAMPLES.md", "skills/novel-workshop/SKILL.md")
WHAT = ("宪法 NWC-1.8 写明“作者”指谁、别人的话怎么算，“所在平台”指哪个；作者点名改一处怎么走；新规则不自动改已采纳的章；"
        "转来别人的话怎么记；工坊发现以前的错要主动说；维护扩展的匿名对照材料先查版本线索")
README_LINE = "版本：小说写作工坊 r5.58（`2026-11-16-r5.58`）。在 r5.57 上做几件事：" + WHAT + "。"
SKILL_LINE = "小说写作工坊 r5.58（`2026-11-16-r5.58`）。在 r5.57 上做几件事：" + WHAT + "。"
BOUND_SCRIPTS = ("`workflow_guard.py`", "`punctuation_lint.py`", "`prose_lint.py`", "`fact_guard.py`", "`project_state.py`")
# The author's own words of approval go into the constitution's revision record only (when they go anywhere); the
# release notes give them in the maker's words. This file used to spell the words out; changed later in r5.58, when a
# review pointed out that the author's decision puts them in the revision record and nowhere else: they are now read
# from the NWC-1.8 entry of the revision record (test_r558_whose_words.py pins them there by their SHA-256).


def read(path):
    return (ROOT / path).read_text(encoding="utf-8")


def author_words():
    """The author's three replies quoted in the NWC-1.8 entry, cut to their first six characters, so that a reply
    with another ending is caught too (an older package, which has no such entry, gives an empty tuple)."""
    record = read("skills/novel-workshop/CONSTITUTION.md").splitlines()[4:5]
    start = record[0].find("NWC-1.8，2026-11-16（r5.58）：") if record else -1
    if start < 0:
        return ()
    return tuple(reply[:6] for reply in re.findall(r"回复“([^“”]+)”", record[0][start:]))


def newest_entry(text):
    """The text of the first '## ' section of a changelog-like page, heading included."""
    parts = re.split(r"(?m)^(?=## )", text)
    return parts[1] if len(parts) > 1 else ""


def part(text, heading):
    """From a '### ' heading to the next '### ' heading ("" if the heading is missing)."""
    start = text.find("\n### " + heading)
    if start < 0:
        return ""
    end = text.find("\n### ", start + 1)
    return text[start:] if end < 0 else text[start:end]


def version_line(page):
    """The line of a page that states its version."""
    return next((line for line in read(page).splitlines() if "`" + VERSION + "`" in line), "")


class Version(unittest.TestCase):
    def test_the_version_is_the_same_everywhere(self):
        for page in PAGES:
            self.assertIn("`" + VERSION + "`", read(page), page)
        manifest = json.loads(read("PACKAGE-MANIFEST.json"))
        self.assertEqual(manifest["version"], VERSION)
        self.assertEqual(manifest["date"], "2026-11-16")
        self.assertTrue(newest_entry(read("VERIFICATION.md")).startswith("## " + VERSION + " 的验证"))
        self.assertTrue(newest_entry(read("CHANGELOG.md")).startswith("## %s（%s）" % (VERSION, TITLE)))
        self.assertIn("\n" + SKILL_LINE + "章节门、学习循环、示范记忆和对白声纹检查照旧。", read("skills/novel-workshop/SKILL.md"))

    def test_the_title_names_this_release_and_no_page_calls_it_a_candidate(self):
        for page in ("README.md", "skills/novel-workshop/SKILL.md"):
            self.assertIn(TITLE, version_line(page), page)
        for page in PAGES:
            line = version_line(page)
            self.assertNotIn("候选", line.split("`" + VERSION + "`")[0], page)  # what the page says this release is
            self.assertNotIn("`" + PREVIOUS + "`", line.split("。")[0], page)
        for page in ("CHANGELOG.md", "VERIFICATION.md"):
            heading = newest_entry(read(page)).splitlines()[0]
            self.assertNotIn("候选", heading, page)

    def test_the_readme_says_what_this_release_did(self):
        readme = read("README.md")
        self.assertIn("\n" + README_LINE + "\n", readme)
        current = next(p for p in re.split(r"(?m)^(?=## )", readme) if p.startswith("## 本版"))
        self.assertTrue(current.startswith("## 本版（r5.58）"), current[:40])
        for phrase in ("NWC-1.8", "最终决定权", "作者转来的也一样", "所在平台", "点名改一处", "L2", "候选稿", "先分强弱",
                       "不改宪法", "`darwin_eval.py blind`", "r5.41—r5.43", "不是同一份", "交付记录照旧", "宪法变了",
                       "不说明写得更好"):
            self.assertIn(phrase, current, phrase)
        # r5.58, once the paired scenario tests had a result: the README no longer says the result is to come; it
        # gives the figures after the grading points were corrected and points to the verification notes.
        paired = next((line for line in current.splitlines() if "成对场景测试" in line), "")
        for phrase in ("做了成对场景测试", "[VERIFICATION.md](VERIFICATION.md)", "各 42 份", "32、40、7", "同一个模型",
                       "不是独立评审", "不说明写得更好"):
            self.assertIn(phrase, paired, phrase)
        self.assertNotIn("结果待补", current)
        words_of_approval = author_words()
        self.assertEqual(len(words_of_approval), 3)
        for words in words_of_approval:
            self.assertNotIn(words, current, words)
        history = readme.split("## 历次版本", 1)[1].split("\n## ", 1)[0]
        self.assertIn("- **r5.57**：", history)  # the release before moves into the list, as r5.56 did
        self.assertLess(history.index("- **r5.57**："), history.index("- **r5.56**："))

    def test_quickstart_says_delivery_records_carry_over_from_r557(self):
        self.assertIn("从合并候选、r5.55、r5.56 或 r5.57 升级的，交付记录照旧。", read("QUICKSTART.md"))


class ReleaseNotes(unittest.TestCase):
    def setUp(self):
        self.entry = newest_entry(read("CHANGELOG.md"))
        self.assertTrue(self.entry.startswith("## %s（%s）" % (VERSION, TITLE)), self.entry[:60])

    def test_the_opening_says_where_it_comes_from_and_what_it_does_not_claim(self):
        opening = self.entry.split("\n### ", 1)[0]
        for phrase in ("在 r5.57（`2026-11-15-r5.57`）上做", "《AI 协作宪法》v1.0", "BJM 通用迁移包 v1.5.1", "修订方案",
                       "作者看过方案，对请他定的四条都回复照制作方的建议办", "同一个模型（Claude）的新实例", "不是独立评审",
                       "做了成对场景测试", "[VERIFICATION.md](VERIFICATION.md)", "不说明写得更好", "r5.57 的包原样留着"):
            self.assertIn(phrase, opening, phrase)
        # r5.58: "成对场景测试这一步还没有结果" was pinned here until the paired scenario tests had a result.
        self.assertNotIn("还没有结果", opening)
        words_of_approval = author_words()
        self.assertEqual(len(words_of_approval), 3)
        for words in words_of_approval:  # the release notes give the author's answer in the maker's words
            self.assertNotIn(words, self.entry, words)

    def test_the_constitution_part(self):
        constitution = part(self.entry, "一、")
        for phrase in ("NWC-1.8", "`CONSTITUTION.md`", "第一节第 3 层", "第一节第 1 层", "最终决定权", "作品档案写明谁拍板",
                       "作者转来的也一样", "当资料对待", "不记成作者原话", "代为决定的那一句没有带过来",
                       "运行工坊的 AI 应用或网站", "归第 5 层", "r5.41—r5.43", "不是同一份条文", "编号接着 NWC-1.7",
                       "`assets/project-template.md`", "拍板的人（按需）", "发表平台的要求（按需）",
                       "`assets/constitution-rules.json`", "CON-001", "`priority`、`same_tier_order` 不动",
                       "脚本认证不了是谁说的"):
            self.assertIn(phrase, constitution, phrase)
        registry = json.loads(read("skills/novel-workshop/assets/constitution-rules.json"))
        self.assertEqual((registry["version"], registry["date"]), ("NWC-1.8", "2026-11-16"))

    def test_the_module_parts(self):
        named = part(self.entry, "二、")
        for phrase in ("唯一减轻默认流程的一条", "`references/editing.md`", "作者点名的一处小改", "L2 的整套", "先问一句",
                       "`fact_guard.py impact`", "从受影响的阶段重开", "候选稿", "`replan`", "NOT_ACCEPTED", "STALE",
                       "REVIEW_REQUIRED", "`accept --skip-review`", "BLOCK", "`exact`", "`SKILL.md`", "L2 那一行原文不动",
                       "`references/quality-loop.md`"):
            self.assertIn(phrase, named, phrase)
        rules = part(self.entry, "三、")
        for phrase in ("`references/continuity.md`", "已采纳的章节不因为新规则自动改", "`collide`", "前文也统一改", "第 5 层",
                       "第 4 层", "`note`", "`check` 不看日期", "被取代", "`rule_register.py check`", "`rule_register.py` 没有改"):
            self.assertIn(phrase, rules, phrase)
        relayed = part(self.entry, "四、")
        for phrase in ("`references/teacher-review.md`", "`references/author-preferences.md`", "`references/learning-loop.md`",
                       "`references/chapter-confirmation.md`", "不记成作者原话", "`teacher_reviewed`", "第 4 阶段",
                       "原样贴来的“定稿。”照样会记", "`chapter_gate.py`、`learning_loop.py` 没有改"):
            self.assertIn(phrase, relayed, phrase)
        errors = part(self.entry, "五、")
        for phrase in ("不改宪法", "主动告诉作者", "只标不改", "工作记录", "交出以后发现有错", "只核条文在不在"):
            self.assertIn(phrase, errors, phrase)
        strength = part(self.entry, "六、")
        for phrase in ("先分强弱", "不改宪法", "五步的结果不变", "不单凭这一条记成明确违背要求", "可以计数的指标",
                       "`rule_register.py` 没有加强弱一项"):
            self.assertIn(phrase, strength, phrase)
        blind = part(self.entry, "七、")
        # 226 lines (was 207): after the first review, file names count only as whole names and the arm folder as given
        # at freeze (given_path) is looked for too; the count is the diff against r5.57's darwin_eval.py.
        for phrase in ("`references/skill-evaluation.md`", "`skills/darwin-novel-workshop/scripts/darwin_eval.py`",
                       "`--identity-marker`", "退出码 2", "`format_differences`", "`SEALS.log`", "BJM v1.5.1", "只拦，不改材料",
                       "加 226 行", "CON-007", "`skills/darwin-novel-workshop/SKILL.md`", "人工看一遍", "同一个 A／B 顺序",
                       "`given_path`", "单独成名", "`summarize` 把这道题当成未测"):
            self.assertIn(phrase, blind, phrase)

    def test_the_entry_says_what_did_not_change(self):
        tests = part(self.entry, "八、")
        for phrase in ("逐字节相同", "`assets/delivery-gate-card.md`", "83 张风格卡", "改的脚本只有维护扩展的 `darwin_eval.py`",
                       "`tests/test_r554_dialogue.py`", "`tests/test_r557_package.py`", "`tests/test_r521_rule_register.py`",
                       "`tests/test_r522_constitution_order.py`", "`tests/test_r532_scene_dramaturgy.py`",
                       "`tests/test_r533_material_first.py`", "`tests/test_r534_review_followups.py`",
                       "`tests/test_r535_con012.py`", "作者批准了 NWC-1.8", "`PACKAGE-MANIFEST.json`",
                       "`portable-novel-workshop.md`") + BOUND_SCRIPTS:
            self.assertIn(phrase, tests, phrase)

    def test_the_test_counts_in_the_notes_are_the_test_files(self):
        tests = part(self.entry, "八、")
        named = re.findall(r"`tests/(test_r558_[a-z_]+\.py)`（(\d+) 项", tests)
        self.assertEqual(sorted(name for name, _ in named),
                         ["test_r558_blind_markers.py", "test_r558_package.py", "test_r558_point_edit.py",
                          "test_r558_rule_entry.py", "test_r558_whose_words.py"])
        for name, count in named:
            source = (ROOT / "tests" / name).read_text(encoding="utf-8")
            self.assertEqual(len(re.findall(r"(?m)^    def test_", source)), int(count), name)

    def test_the_decisions_made_on_the_way_are_listed_and_can_be_changed(self):
        decided = part(self.entry, "这一版顺带定下的几处做法")
        for phrase in ("章节门里这一章的记录要不要跟着重开，先问作者一句", "交付门卡这一轮不动", "5004", "同一个 A／B 顺序",
                       "要改"):
            self.assertIn(phrase, decided, phrase)

    def test_what_was_not_brought_back_and_what_is_still_open(self):
        left = part(self.entry, "没有带回来的")
        for phrase in ("按分量办", "该问才问", "七层、五步", "代为决定", "只拦不改"):
            self.assertIn(phrase, left, phrase)
        known = part(self.entry, "上一版留下的已知问题")
        for phrase in ("`workflow_guard.py` 还没有收回采纳的命令", "交付门卡", "跨章回归"):
            self.assertIn(phrase, known, phrase)

    def test_the_entry_says_how_to_upgrade(self):
        upgrade = part(self.entry, "怎样升级")
        for phrase in ("从 r5.57 升上来", "python install.py --upgrade --dry-run", "`assets/project-packs/`", "交付记录照旧",
                       "五个绑定脚本", "`governance_warnings`", "只是提示", "拍板的人", "发表平台的要求",
                       "`--constitution-approval`", "r5.57 一节", "退回 r5.57"):
            self.assertIn(phrase, upgrade, phrase)
        incompatible = part(self.entry, "不兼容的变化")
        for phrase in ("写作这边没有", "`darwin_eval.py`", "退出码 2", "`--identity-marker`", "`format_differences`"):
            self.assertIn(phrase, incompatible, phrase)

    def test_the_entry_and_the_verification_notes_say_what_was_not_verified(self):
        verification = newest_entry(read("VERIFICATION.md"))
        for text in (part(self.entry, "没有验证的"), part(verification, "没有验证的")):
            # r5.58: "结果待补" was pinned here until the paired scenario tests had a result; now both lists say how
            # little the result covers (21 made-up scenarios, two runs each, nothing about real writing).
            for phrase in ("成对场景测试", "21 个合成场景", "每种环境两次", "说明不了在真实写作里会怎样", "同一个模型",
                           "返修额度用完", "认证不了是谁说的", "只是条文", "所在平台", "原生 Windows", "macOS",
                           "`--identity-marker`", "不说明写得更好"):
                self.assertIn(phrase, text, phrase)
            self.assertNotIn("结果待补", text)
        paired = next((line for line in part(self.entry, "没有验证的").splitlines() if line.startswith("- 成对场景测试")), "")
        for phrase in ("[VERIFICATION.md](VERIFICATION.md)", "各 42 份", "32、40、7", "同一个模型", "不是独立评审",
                       "看到第一轮结果以后才改的", "不说明写得更好"):
            self.assertIn(phrase, paired, phrase)

    def test_the_verification_notes_name_what_was_run(self):
        verification = newest_entry(read("VERIFICATION.md"))
        for phrase in ("python3 -I -B tests/run_tests.py", "Python 3.9.25", "`__pycache__`", "`tests/test_r558_package.py`",
                       "`tests/test_r558_point_edit.py`", "`tests/test_r558_rule_entry.py`", "`tests/test_r558_whose_words.py`",
                       "`tests/test_r558_blind_markers.py`", "`governance_warnings`", "同一个模型", "不是独立评审"):
            self.assertIn(phrase, verification, phrase)
        opening = verification.split("\n### ", 1)[0]
        self.assertIn("做了成对场景测试", opening)
        self.assertNotIn("结果待补", opening)
        # r5.58: until the paired scenario tests had a result, this section had to say "结果待补" and hold no figures.
        # Now it has to give the figures of both grading rounds, and say plainly how far they go.
        pairs = part(verification, "成对场景测试")
        self.assertNotIn("结果待补", pairs)
        rounds = {}
        for line in pairs.splitlines():
            cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
            if len(cells) == 4 and cells[0] in ("第一轮", "改了评分要点以后"):
                rounds[cells[0]] = cells[1:]
        self.assertEqual(rounds, {"第一轮": ["29、8、5", "35、5、2", "7、26、9"],
                                  "改了评分要点以后": ["32、10、0", "40、1、1", "7、27、8"]})
        for cells in rounds.values():
            for cell in cells:  # right, partly right, wrong: 21 scenarios, two answers each, per setting
                self.assertEqual(sum(int(n) for n in cell.split("、")), 42, cell)
        for phrase in ("每种环境 42 份", "同一个模型", "要点是看到第一轮结果以后才改的", "不是独立评审",
                       "说明不了文笔", "预期答案不在包里"):
            self.assertIn(phrase, pairs, phrase)


if __name__ == "__main__":
    unittest.main()

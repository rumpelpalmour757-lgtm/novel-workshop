#!/usr/bin/env python3
"""r5.49: prose_lint says which checks ran, three hint messages reworded, and a new optional group "deai-extra".

What these tests pin: the listing of default checks, hints turned on and hints not run (text and JSON); the reworded
messages of tension-telling, stock-reaction and parallel-run; the four hints of "deai-extra" (emotion-statement,
reaction-wide, simile-extra, theme-phrase) on invented sentences that should be listed and on similar ones that should
not; that the group is optional, narration only and never an error; and that prose_lint.py quotes no sentence of the
r5.48 test material in its comments or word lists. After the r5.49 review: emotion-statement and theme-phrase do not
list again a place another rule of the same kind lists in the run (CL-2); theme-phrase leaves facts about time and
人生地不熟 alone (CL-4); a default rule the author turned off that --hint ran again is listed as off_but_run (CL-6).
A hit is a place to re-read, not a verdict; no hit says nothing about the quality of a text. Every example sentence
here is newly written for this file.
"""
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
LINT = SKILL / "scripts" / "prose_lint.py"
EXTRA = ("emotion-statement", "reaction-wide", "simile-extra", "theme-phrase")
DEAI = ("stock-reaction", "inner-declaration", "contrast-moral", "abstract-surge", "stock-simile", "soft-adverbs")
REREAD = "命中只是回去重读的地方，不是结论"


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def paragraphs(*items):
    return "\n\n".join(items) + "\n"


def run(*args):
    proc = subprocess.run([sys.executable, "-I", "-B", str(LINT), *map(str, args)], capture_output=True, text=True,
                          encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


# (should be listed, should not be listed) for each new hint; all invented for r5.49.
CASES = {
    "emotion-statement": (
        ["他感到一阵莫名的恐惧，从脚底一直爬到后脑。", "听完这番话，她感到无比愤怒。", "那一刻，小周心中充满了骄傲。",
         "收到录取通知的那天，母亲心中涌起了无限的感激。", "看着病床上的父亲，他内心十分复杂。",
         "他先是恐惧，紧接着是一种被羞辱的愤怒。", "她感到十分委屈，扭过头去不看他。", "老陈先是一惊，接着是长久的沉默。"],
        ["他怕狗，宁可绕半条街。", "她感到口袋里的手机震了两下。", "他感到时间紧张，把午饭推到了三点。",
         "她感到眼睛酸涩，就把台灯调暗了。", "他感到这片工地不安全，让工人先撤到棚子里。",
         "外面先是惊动了看门的狗，接着是隔壁的灯一盏盏亮起来。", "内心深处那点念头，他没跟任何人说。",
         "他感到饿了，去灶台边找剩饭。", "“我感到很害怕。”她说。", "反应堆的核心中充满了冷却水。"]),
    "reaction-wide": (
        ["他倒吸了一大口凉气，往后退了半步。", "她的嘴角微微向上勾起了一个好看的弧度。", "老吴的瞳孔在一瞬间收缩。",
         "听到这个名字，她的心一下子往下一沉。", "他攥着方向盘，指节用力到隐隐发白。", "冷汗早就悄悄地湿透了他的衬衫。"],
        ["复查时大夫让他深吸一口气，再慢慢吐出来。", "他小心地把渔网往下一沉。", "冷汗还没干，他又被叫去搬下一车。",
         "验光师用小手电照他的瞳孔，让他盯着墙上的红点。", "她的指节上沾着白灰，像刚和过面。", "嘴角那道疤有两指宽，弧度很怪。",
         "“你倒吸一口凉气干什么？”她笑他。", "他把被雨湿透的外套挂在门后，冷汗倒是早停了。"]),
    "simile-extra": (
        ["他的拳头快如闪电，直取对方面门。", "那孩子像断了线的风筝一样从坡上滚下去。", "老马如同一头被激怒的野兽，撞开了仓库的铁门。",
         "两个人对望着，时间仿佛凝固在那张桌子上。", "记忆如潮水般涌来，把她淹没。", "她整个人像一只断线的风筝飘了出去。",
         "时间好像在这一刻静止了。"],
        ["那道闪电快得看不清，雷声隔了五秒才到。", "风筝的线断了，他追着跑了半条街。", "一头被激怒的公牛冲进了集市，撞翻了三个菜摊。",
         "时间不早了，他把账本合上。", "潮水涌来的时候，他们已经爬上了礁石。", "他看了看时间，仿佛想起了什么，又坐下了。",
         "“快如闪电？你吹吧。”"]),
    "theme-phrase": (
        # 并不是: with 从来不是, a text of this one sentence is weak-scene-ending's place, listed once (NoPlaceTwice).
        ["他望着远处的灯火，心想，这就是人生。", "她在日记本上写下：今年要成为最好的自己。", "毕业不是结束，而是新的开始。",
         "真正的勇敢，并不是不害怕，而是怕了还往前走。", "或许，这就是成长吧。", "也许这就是生活吧，他想。",
         "他攥紧车票想，好戏才刚刚开始。", "好戏才刚刚开始呢，老刘在心里冷笑。", "真正的硬仗才刚刚开始。", "他想，这就是人生的滋味。"],
        ["他这才发现，保险柜里放的不是现金，而是一沓当票。", "这就是人民路，往前走两个路口就到。",
         "雨才刚刚开始下，街上的摊子已经收了一半。", "她想成为更好的裁缝，每天多练两个小时。", "那不是结束的哨声，是暂停。",
         "他翻开最后一页：真正的凶手的名字被人用墨涂掉了。", "或许这就是他迟到的原因。", "“这就是人生啊。”老板娘擦着杯子说。",
         # r5.49 review (CL-4): 刚刚开始 with a noun subject or a verb after it is a fact about time; 人生地不熟 is an idiom.
         "比赛才刚刚开始，他已经落后两分。", "天才刚刚开始亮，码头上已经站满了人。", "这就是人生地不熟的难处。",
         "手术才刚刚开始，走廊里的灯闪了两下。", "她才刚刚开始学骑车，膝盖上已经青了两块。", "这才刚刚开始下雪，山路就封了。",
         "这场雨才刚刚开始，屋檐下已经挤满了人。", "考试才刚刚开始十分钟，他就交了卷。", "麦子才刚刚开始黄梢，雹子就砸下来了。",
         "刚到省城那几天，处处碰壁，这便是人生路不熟。"]),
}


class DeaiExtra(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.lint = load(LINT, "r549_prose_lint")

    def found(self, text, hints, rule):
        return [f for f in self.lint.inspect_text(text, hints=hints)["findings"] if f["rule"] == rule]

    def test_the_group_is_optional_and_separate_from_deai(self):
        self.assertEqual(self.lint.expand_hints(["deai-extra"]), list(EXTRA))
        self.assertEqual(self.lint.expand_hints(["deai"]), list(DEAI))
        for rule in EXTRA:
            self.assertIn(rule, self.lint.HINTS)
            self.assertNotIn(rule, self.lint.DEFAULT_RULES)
        for rule, (positives, _) in CASES.items():
            for text in positives:
                # Neither the default run nor the deai group lists the new hints.
                for hints in ((), ("deai",)):
                    rules = {f["rule"] for f in self.lint.inspect_text(text, hints=hints)["findings"]}
                    self.assertFalse(rules & set(EXTRA), (rule, text, hints))
                # The group, the name and a rules file turn it on.
                self.assertTrue(self.found(text, ("deai-extra",), rule), (rule, text))
                self.assertTrue(self.found(text, (rule,), rule), (rule, text))
        report = self.lint.inspect_text(CASES["simile-extra"][0][0], {"hints": ["deai-extra"]})
        self.assertIn("simile-extra", [f["rule"] for f in report["findings"]])
        with self.assertRaises(ValueError):
            self.lint.inspect_text("门口停着一辆三轮。", {"hints": ["deai-extra", "nonsense"]})

    def test_what_is_listed_and_what_is_not(self):
        for rule, (positives, negatives) in CASES.items():
            self.assertGreaterEqual(len(positives), 6, rule)
            self.assertGreaterEqual(len(negatives), 6, rule)
            for text in positives:
                hits = self.found(text, (rule,), rule)
                self.assertTrue(hits, (rule, text))
                report = self.lint.inspect_text(text, hints=(rule,))
                self.assertEqual(report["status"], "REVIEW")
                for hit in hits:
                    self.assertFalse(hit["in_quote"])
                    self.assertIn(REREAD, hit["message"])
            for text in negatives:
                self.assertEqual(self.found(text, (rule,), rule), [], (rule, text))

    def test_the_quotes_of_the_places(self):
        self.assertEqual([f["quote"] for f in self.found("那一刻，小周心中充满了骄傲。", ("emotion-statement",),
                                                         "emotion-statement")], ["心中充满了骄傲"])
        self.assertEqual([f["quote"] for f in self.found("他倒吸了一大口凉气，往后退了半步。", ("reaction-wide",),
                                                         "reaction-wide")], ["倒吸了一大口凉气"])
        self.assertEqual([f["quote"] for f in self.found("毕业不是结束，而是新的开始。", ("theme-phrase",),
                                                         "theme-phrase")], ["不是结束，而是新的开始"])

    def test_emotion_statement_says_a_fitting_plain_statement_may_stay(self):
        hit = self.found("听完这番话，她感到无比愤怒。", ("emotion-statement",), "emotion-statement")[0]
        self.assertIn("有分寸的直说可以留", hit["message"])

    def test_reaction_wide_does_not_repeat_what_stock_reaction_lists(self):
        text = "听见脚步声，小林倒吸一口冷气。"
        alone = self.found(text, ("reaction-wide",), "reaction-wide")
        self.assertEqual([f["quote"] for f in alone], ["倒吸一口冷气"])
        both = self.lint.inspect_text(text, hints=("deai", "deai-extra"))["findings"]
        self.assertEqual([f["rule"] for f in both], ["stock-reaction"])
        # The wider shape that stock-reaction does not reach is still listed when both run.
        wide = self.lint.inspect_text("他倒吸了一大口凉气，往后退了半步。", hints=("deai", "deai-extra"))["findings"]
        self.assertEqual([(f["rule"], f["quote"]) for f in wide], [("reaction-wide", "倒吸了一大口凉气")])

    def test_theme_phrase_is_read_anywhere_in_the_narration(self):
        text = paragraphs("他攥紧车票想，好戏才刚刚开始。", "车站的广播一遍遍报着晚点的车次，他把背包从左肩挪到右肩。",
                          "第二天一早，他又去码头等那条船。", "船来的时候天还没亮透，跳板上全是露水。")
        found = self.lint.inspect_text(text, hints=("theme-phrase",))["findings"]
        self.assertEqual([(f["rule"], f["line"]) for f in found], [("theme-phrase", 1)])

    def test_never_an_error_on_the_command_line(self):
        # One sentence of each hint that no other rule lists: with --hint all a place another rule lists is listed once,
        # by that rule (the first emotion-statement sentence is abstract-surge's place then; NoPlaceTwice).
        own = {rule: positives[0] for rule, (positives, _) in CASES.items()}
        own["emotion-statement"] = CASES["emotion-statement"][0][1]
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "draft.txt"
            path.write_bytes(paragraphs(*own.values()).encode("utf-8"))
            for hint in ("deai-extra", "all") + EXTRA:
                code, out, err = run(path, "--hint", hint)
                self.assertEqual(code, 0, err)
                report = json.loads(out)
                self.assertEqual(report["status"], "REVIEW")
                rules = {f["rule"] for f in report["findings"]}
                self.assertTrue(rules & set(EXTRA), hint)
            code, out, err = run(path, "--hint", "all")
            self.assertTrue(set(EXTRA) <= {f["rule"] for f in json.loads(out)["findings"]})

    def test_theme_phrase_lists_the_lesson_not_the_fact_about_time(self):
        # r5.49 review (CL-4): what is quoted, and the shapes ending a clause.
        quote = lambda text: [f["quote"] for f in self.found(text, ("theme-phrase",), "theme-phrase")]
        self.assertEqual(quote("好戏才刚刚开始呢，老刘在心里冷笑。"), ["好戏才刚刚开始"])
        self.assertEqual(quote("真正的硬仗才刚刚开始。"), ["真正的硬仗才刚刚开始"])
        self.assertEqual(quote("他想，这就是人生的滋味。"), ["这就是人生"])
        # In the middle of the narration (not weak-scene-ending's last paragraphs) 一切／这只是……刚刚开始 is listed.
        text = paragraphs("他把缆绳又绕了两圈，心想，一切才刚刚开始。", "她心里说，这只是刚刚开始而已。",
                          "码头上的人散了一半，灯一盏盏灭了。", "他把船票折好，塞进内衣口袋。")
        found = self.lint.inspect_text(text, hints=("theme-phrase",))["findings"]
        self.assertEqual([(f["rule"], f["line"], f["quote"]) for f in found],
                         [("theme-phrase", 1, "一切才刚刚开始"), ("theme-phrase", 3, "这只是刚刚开始")])


class NoPlaceTwice(unittest.TestCase):
    """r5.49 review (CL-2): like reaction-wide and simile-extra, emotion-statement and theme-phrase do not list again a
    place that a rule of the same kind lists in the same run; where that rule is off or not on, they list it as before."""
    DEFERS = {"emotion-statement": ("tension-telling", "abstract-surge"),
              "theme-phrase": ("contrast-moral", "weak-scene-ending"),
              "reaction-wide": ("stock-reaction",), "simile-extra": ("stock-simile",)}

    @classmethod
    def setUpClass(cls):
        cls.lint = load(LINT, "r549_prose_lint_once")

    def places(self, text, hints, rules=None, **kw):
        return [(f["line"], f["column"], f["rule"]) for f in self.lint.inspect_text(text, rules, "blank", hints, **kw)["findings"]]

    def test_the_example_of_the_review(self):
        text = paragraphs("他感到一阵不安，把门又锁了一遍。", "她心中涌起一股莫名的恐惧……",
                          "真正的勇气不是不害怕，而是害怕了还往前走。一切才刚刚开始。")
        # tension-telling and weak-scene-ending run by default, so deai-extra alone repeated them before.
        once = [(1, 2, "tension-telling"), (3, 2, "tension-telling"), (5, 1, "weak-scene-ending"), (5, 22, "weak-scene-ending")]
        self.assertEqual(self.places(text, ("deai-extra",)), once)
        # With deai too, abstract-surge and contrast-moral add their places; that these two r5.48 rules meet tension-telling
        # and weak-scene-ending there is as in r5.48, not part of this change.
        self.assertEqual(self.places(text, ("deai", "deai-extra")),
                         sorted(once + [(3, 6, "abstract-surge"), (5, 1, "contrast-moral")]))
        sentence = "他心中涌起了一股勇气，转身迎了上去。"
        self.assertEqual(self.places(sentence, ("deai", "deai-extra")), [(1, 7, "abstract-surge")])
        self.assertEqual(self.places(sentence, ("deai-extra",)), [(1, 2, "emotion-statement")])

    def test_alone_each_lists_the_place(self):
        sentence = "老秦感到一阵莫名的不安，又回头看了一眼巷口。\n"
        self.assertEqual(self.places(sentence, ("emotion-statement",)), [(1, 3, "tension-telling")])
        off = {"off": [{"rule": "tension-telling", "reason": "作者：本书允许直写"}]}
        self.assertEqual(self.places(sentence, ("emotion-statement",), off), [(1, 3, "emotion-statement")])
        # 从来不是 in the middle of the narration is theme-phrase's place; in the last paragraph weak-scene-ending's.
        moral = "真正的勇敢，从来不是不害怕，而是怕了还往前走。"
        tail = ("码头上的人散了一半，灯一盏盏灭了。", "他把船票折好，塞进内衣口袋。")
        self.assertEqual(self.places(paragraphs(moral, *tail), ("theme-phrase",)), [(1, 1, "theme-phrase")])
        self.assertEqual(self.places(paragraphs(moral), ("theme-phrase",)), [(1, 1, "weak-scene-ending")])
        off = {"off": [{"rule": "weak-scene-ending", "reason": "作者：本书的章尾就这么收"}]}
        self.assertEqual(self.places(paragraphs(moral), ("theme-phrase",), off), [(1, 1, "theme-phrase")])
        self.assertEqual(self.places(paragraphs(moral), ("theme-phrase",), scene_rules=False), [(1, 1, "theme-phrase")])

    def test_no_place_of_a_new_hint_is_listed_twice(self):
        span = lambda f: (f["column"], f["column"] + len(f["quote"]))
        for rule, (positives, _) in CASES.items():
            for text in positives:
                for hints in ((rule,), ("deai-extra",), ("deai", "deai-extra"), self.lint.HINTS):
                    found = self.lint.inspect_text(text, hints=hints)["findings"]
                    mine = [span(f) for f in found if f["rule"] == rule]
                    theirs = [span(f) for f in found if f["rule"] in self.DEFERS[rule]]
                    # Listed, by the new hint or by the rule it gives way to, and not by both.
                    self.assertTrue(mine or theirs, (rule, text, hints))
                    for a, b in mine:
                        self.assertFalse(any(a < d and c < b for c, d in theirs), (rule, text, hints))


class ChangedMessages(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.lint = load(LINT, "r549_prose_lint_messages")

    def test_tension_telling(self):
        message = self.lint.HINT_MESSAGES["tension-telling"]
        self.assertIn("台词、选择、注意到的东西、处境、动作、念头或此刻身上真有的反应，也可以留白、删去或换成有分寸的直说", message)
        self.assertIn("换成指节发白、深吸一口气这类现成反应不算改好", message)
        found = [f for f in self.lint.inspect_text("屋里一片死寂，他把碗放下。")["findings"] if f["rule"] == "tension-telling"]
        self.assertIn("念头或此刻身上真有的反应", found[0]["message"])

    def test_stock_reaction(self):
        message = self.lint.HINT_MESSAGES["stock-reaction"]
        for phrase in ("出现一次也要看", "命中也不等于要删", "处境", "真喘气、真攥着东西、怕得手上出错"):
            self.assertIn(phrase, message)

    def test_parallel_run(self):
        message = self.lint.HINT_MESSAGES["parallel-run"]
        self.assertIn("回到动作段读：看是分镜腔，还是有意的一拍一停；判断看谁在做什么、方向和先后清不清楚", message)
        self.assertIn("修改的五道工序第一、四遍", message)
        self.assertNotIn("过渡动作降成状语", message)
        found = [f for f in self.lint.inspect_text("她拧开水龙头。她冲了冲碗。她关上柜门。\n")["findings"]
                 if f["rule"] == "parallel-run"]
        self.assertTrue(found[0]["message"].startswith("连着 3 句"))


class ChecksListed(unittest.TestCase):
    TEXT = "她把搪瓷缸放回窗台。\n"

    @classmethod
    def setUpClass(cls):
        cls.lint = load(LINT, "r549_prose_lint_listing")

    def test_json(self):
        lint = self.lint
        optional = [h for h in lint.HINTS if h not in lint.DEFAULT_RULES]
        plain = lint.inspect_text(self.TEXT)
        self.assertEqual(plain["checks_default"], list(lint.BUILT_IN) + list(lint.DEFAULT_RULES))
        self.assertEqual((plain["hints_on"], plain["hints_off"]), ([], optional))
        self.assertEqual(plain["checks_run"], plain["checks_default"])
        deai = lint.inspect_text(self.TEXT, hints=("deai",))
        self.assertEqual(deai["hints_on"], list(DEAI))
        self.assertEqual(deai["hints_off"], ["short-beats"] + list(EXTRA))
        self.assertEqual(deai["checks_default"], plain["checks_default"])
        # A default rule the author turned off is in neither list; turned_off says why.
        off = lint.inspect_text(self.TEXT, {"off": [{"rule": "frequent-words", "reason": "作者：这本书的叙述人爱这么说"}],
                                            "hints": ["deai-extra"]})
        self.assertNotIn("frequent-words", off["checks_default"] + off["hints_on"] + off["hints_off"])
        self.assertEqual(off["hints_on"], list(EXTRA))
        self.assertEqual(off["turned_off"][0]["rule"], "frequent-words")
        self.assertEqual((plain["off_but_run"], deai["off_but_run"], off["off_but_run"]), ([], [], []))
        # The fields of r5.48 are still there.
        for key in ("status", "checks_run", "turned_off", "findings", "suppressed", "unused_ignores", "limits"):
            self.assertIn(key, plain)

    # r5.49 review (CL-6): a default rule the author turned off and --hint ran again is not an optional hint.
    RUN = "他推开院门。他放下扁担。他舀了一瓢水。\n"
    OFF = {"off": [{"rule": "parallel-run", "reason": "作者：一拍一停是本书的腔调"}]}

    def test_json_off_but_run(self):
        lint = self.lint
        optional = [h for h in lint.HINTS if h not in lint.DEFAULT_RULES]
        for hints in (lint.HINTS, ("parallel-run",), ("deai", "parallel-run")):
            report = lint.inspect_text(self.RUN, self.OFF, "blank", hints)
            self.assertEqual(report["off_but_run"], ["parallel-run"], hints)
            self.assertNotIn("parallel-run", report["checks_default"] + report["hints_on"] + report["hints_off"])
            # What runs is unchanged: it ran and its hit is listed.
            self.assertIn("parallel-run", report["checks_run"])
            self.assertIn("parallel-run", [f["rule"] for f in report["findings"]])
        self.assertEqual(lint.inspect_text(self.RUN, self.OFF, "blank", lint.HINTS)["hints_on"], optional)
        self.assertEqual(lint.inspect_text(self.RUN, self.OFF, "blank", ("parallel-run",))["hints_on"], [])
        # Without --hint the author's decision stands (the gate passes no hints).
        report = lint.inspect_text(self.RUN, self.OFF)
        self.assertEqual(report["off_but_run"], [])
        self.assertNotIn("parallel-run", report["checks_run"] + [f["rule"] for f in report["findings"]])

    def test_text_off_but_run(self):
        optional = [h for h in self.lint.HINTS if h not in self.lint.DEFAULT_RULES]
        line = ("本书关掉、这次因 --hint 又查了的（1 项）：parallel-run。命中照常列在下面，只是回去重读的地方，不是结论；"
                "不加 --hint 时仍按作者的决定不查")
        with tempfile.TemporaryDirectory() as tmp:
            path, rules = Path(tmp) / "a.txt", Path(tmp) / "rules.json"
            path.write_bytes(self.RUN.encode("utf-8"))
            rules.write_bytes(json.dumps(self.OFF, ensure_ascii=False).encode("utf-8"))
            code, out, err = run(path, "--rules", rules, "--hint", "all", "--format", "text")
            self.assertEqual(code, 0, err)
            lines = out.splitlines()
            self.assertIn("另开的可选提示（%d 项）：%s" % (len(optional), "、".join(optional)), lines)
            self.assertIn("本书关掉的：parallel-run（作者：一拍一停是本书的腔调）", lines)
            self.assertEqual([x for x in lines if "这次因 --hint 又查了的" in x], [line])
            self.assertIn("【parallel-run】等长短句连排，1 处", lines)
            code, out, err = run(path, "--rules", rules, "--hint", "parallel-run", "--format", "text")
            self.assertIn("另开的可选提示（0 项）：没有", out.splitlines())
            self.assertIn(line, out.splitlines())
            code, out, err = run(path, "--rules", rules, "--format", "text")
            self.assertEqual(code, 0, err)
            self.assertNotIn("这次因 --hint 又查了的", out)
            self.assertNotIn("【parallel-run】", out)
            code, out, err = run(path, "--rules", rules, "--hint", "parallel-run")
            report = json.loads(out)
            self.assertEqual((report["off_but_run"], report["hints_on"]), (["parallel-run"], []))

    def test_text(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "a.txt"
            path.write_bytes(self.TEXT.encode("utf-8"))
            outputs = {}
            for extra in ((), ("--hint", "deai"), ("--hint", "deai", "--hint", "deai-extra")):
                code, out, err = run(path, "--format", "text", *extra)
                self.assertEqual(code, 0, err)
                self.assertIn("没有命中", out)
                outputs[extra] = out
        plain, deai, both = outputs.values()
        self.assertEqual(len({plain, deai, both}), 3)
        self.assertIn("默认检查（9 项）：placeholder、repeated-paragraph、floating-dialogue", plain)
        self.assertIn("另开的可选提示（0 项）：没有", plain)
        self.assertIn("没开的可选提示（11 项）：stock-reaction、", plain)
        self.assertIn("这几项没有查，没命中不说明没有", plain)
        self.assertIn("另开的可选提示（6 项）：" + "、".join(DEAI), deai)
        self.assertIn("没开的可选提示（5 项）：short-beats、" + "、".join(EXTRA), deai)
        self.assertIn("没开的可选提示（1 项）：short-beats", both)
        # The last line is still the limits.
        self.assertEqual(plain.splitlines()[-1], self.lint.inspect_text("")["limits"])


class NoMaterialInTheSource(unittest.TestCase):
    """The comments and word lists of prose_lint.py quote no sentence of the r5.48 test material."""

    @classmethod
    def setUpClass(cls):
        cls.lint = load(LINT, "r549_prose_lint_source")
        cls.r548 = load(ROOT / "tests" / "test_r548_deai.py", "r549_reads_r548_material")

    def test_no_sentence_of_the_material_is_in_the_source(self):
        source = LINT.read_text(encoding="utf-8")
        material = [self.r548.COMBAT, self.r548.KITCHEN, self.r548.HUMAN]
        clauses = [c for text in material for c in re.split(r"[，。！？：；“”\n]", text) if len(c) >= 7]
        self.assertTrue(clauses)
        for clause in clauses:
            self.assertNotIn(clause, source, clause)

    def test_the_general_lasting_feeling_pattern(self):
        last = self.r548.KITCHEN.strip().split("\n\n")[-1]
        quotes = [f["quote"] for f in self.lint.inspect_text(last)["findings"] if f["rule"] == "weak-scene-ending"]
        self.assertTrue(any(re.fullmatch(r"(?:会一直)?留在.+心里，温暖.+往后的.+日子", q) for q in quotes), quotes)
        for text in ("那碗面的热气会一直留在他心里，照亮他往后的那些日子。", "这句话刻在了老人心上，陪着他以后的岁月。"):
            rules = [f["rule"] for f in self.lint.inspect_text(text)["findings"]]
            self.assertIn("weak-scene-ending", rules, text)


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""r5.56: the version is the same everywhere, and the release notes say what this release did.

r5.55 pinned its version in test_r555_package.py; from r5.56 on that file checks that the r5.55 entries stay in the
changelog and the verification notes as history, and the current version is pinned here, the same way.

The release notes are checked for what they must cover: the two things this release did (the author's correction
records back in the skill folder, assets/project-packs/_author/, travelling with the package; the default teacher
setting, gemini-4-argon with the thinking level set to high), how to upgrade from r5.55 and from earlier releases,
where the records are after rolling back, and what was not verified. These tests only check that the notes say so;
they do not show that the records help, that the default teacher is a good choice, or that anything writes better.

r5.57: the current version is pinned in test_r557_package.py now, the same way. The tests here that pinned r5.56 as the
current version (on the five pages, in the manifest, in the newest changelog and verification entries) check instead
that the r5.56 entries stay where they were, below the newer ones, with what they said. Each looks its entry up by the
heading and fails when the heading is missing, so a renamed or dropped entry does not pass by finding nothing.
"""
import json
import os
from pathlib import Path
import re
import sys
import unittest

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
VERSION = "2026-11-14-r5.56"
TITLE = "小说写作工坊 r5.56"


def read(path):
    return (ROOT / path).read_text(encoding="utf-8")


def newest_entry(text):
    """The text of the first '## ' section of a changelog-like page, heading included."""
    parts = re.split(r"(?m)^(?=## )", text)
    return parts[1] if len(parts) > 1 else ""


def entry_for(text, version):
    """The '## ' section of a changelog-like page whose heading starts with version, heading included ("" if none)."""
    return next((part for part in re.split(r"(?m)^(?=## )", text)[1:] if part.startswith("## " + version)), "")


class Version(unittest.TestCase):
    def test_the_r556_records_stay_as_history(self):
        # r5.57: this test pinned r5.56 as the current version on the five pages, in the manifest and at the top of
        # CHANGELOG.md and VERIFICATION.md. The current version is pinned in test_r557_package.py now; here the r5.56
        # entries are looked up by their headings and must still be there with what they said, below a newer entry.
        changelog, verification = read("CHANGELOG.md"), read("VERIFICATION.md")
        entry = entry_for(changelog, VERSION)
        self.assertTrue(entry.startswith("## %s（%s）" % (VERSION, TITLE)), entry[:60])
        self.assertNotEqual(newest_entry(changelog), entry)  # a newer release carries this test
        self.assertIn("这一版在 r5.55（`2026-11-14-r5.55`）上做", entry)
        checked = entry_for(verification, VERSION)
        self.assertTrue(checked.startswith("## " + VERSION + " 的验证"), checked[:60])
        self.assertNotEqual(newest_entry(verification), checked)
        self.assertIn("运行 1657 项", checked)
        self.assertNotEqual(json.loads(read("PACKAGE-MANIFEST.json"))["version"], VERSION)
        self.assertIn("- **r5.56**：", read("README.md"))  # the README lists r5.56 among the earlier releases

    def test_the_r556_headings_do_not_call_it_a_candidate(self):
        # r5.57: the version lines of the five pages name r5.57 now (test_r557_package.py checks them); the r5.56
        # headings that stay in the history still must not call r5.56 a candidate.
        for page in ("CHANGELOG.md", "VERIFICATION.md"):
            entry = entry_for(read(page), VERSION)
            self.assertTrue(entry, page)
            self.assertNotIn("候选", entry.splitlines()[0], page)

    def test_the_package_ships_no_records_and_the_single_file_expands_none(self):
        packs = SKILL / "assets" / "project-packs"
        self.assertEqual([p for p in packs.rglob("*") if p.is_file()] if packs.is_dir() else [], [])
        manifest = json.loads(read("PACKAGE-MANIFEST.json"))
        self.assertEqual([p for p in manifest["files"] if "/assets/project-packs/" in p], [])
        single = read("portable-novel-workshop.md")
        for heading in ("# 作者改法累计：有效规则摘要\n", "# 作者改法累计：详细证据与变更历史\n"):
            # The blank formats are on the rule page, inside a fenced block; a record would stand on its own.
            self.assertGreaterEqual(single.count("```text\n" + heading), 1, heading)
            self.assertEqual(single.count("\n" + heading), single.count("```text\n" + heading), heading)


class ReleaseNotes(unittest.TestCase):
    def setUp(self):
        # r5.57: the r5.56 entry is no longer the newest one; it is looked up by its heading.
        self.entry = entry_for(read("CHANGELOG.md"), VERSION)
        self.assertTrue(self.entry.startswith("## %s（%s）" % (VERSION, TITLE)), self.entry[:60])

    def test_the_entry_says_what_changed(self):
        for phrase in ("`assets/project-packs/_author/`", "`correction-register.md`", "`correction-history.md`",
                       "跟着技能包走", "商业交付版不带", "`--upgrade`", "`--keep installed`", "`--keep package`",
                       "`--include-projects`", "gemini-4-argon", "思考等级", "“高”（High）", "可以改", "`teacher_name`",
                       "不追改", "写作台的代码没有改"):
            self.assertIn(phrase, self.entry, phrase)

    def test_the_entry_says_how_to_upgrade_and_where_the_records_are_after_rolling_back(self):
        part = self.entry[self.entry.index("### 怎样升级"):]
        for phrase in ("从 r5.55 升上来", "`2026-11-14-r5.54-merged-candidate` 或更早", "python install.py --upgrade --dry-run",
                       "`carried`", "STALE"):
            self.assertIn(phrase, part, phrase)
        part = self.entry[self.entry.index("### 退回"):]
        for phrase in (".novel-workshop-backups/<时间>/novel-workshop/assets/project-packs/`", "r5.55 或更早",
                       "作者档案", "`<安装位置>/novel-workshop/assets/`", "“Existing skill differs”"):
            self.assertIn(phrase, part, phrase)

    def test_the_entry_and_the_verification_notes_say_what_was_not_verified(self):
        verification = entry_for(read("VERIFICATION.md"), VERSION)
        self.assertTrue(verification.startswith("## " + VERSION + " 的验证"), verification[:60])
        for text in (self.entry, verification):
            for phrase in ("真实的教师回传", "gemini-4-argon", "写作台", "原生 Windows", "不说明写得更好", "不是独立评审"):
                self.assertIn(phrase, text, phrase)
        self.assertIn("没有验证的", verification)
        self.assertIn("没有验证的", self.entry)

    def test_the_verification_notes_name_what_was_run(self):
        verification = entry_for(read("VERIFICATION.md"), VERSION)
        self.assertTrue(verification.startswith("## " + VERSION + " 的验证"), verification[:60])
        for phrase in ("python3 -I -B tests/run_tests.py", "`__pycache__`", "升级和退回", "`_author/`"):
            self.assertIn(phrase, verification, phrase)


if __name__ == "__main__":
    unittest.main()

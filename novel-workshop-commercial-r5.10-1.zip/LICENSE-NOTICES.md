# 来源与许可说明

本交付包包含整理后的小说写作方法、工坊维护适配与可选开发技能。以下记录区分组件来源与所附许可，不将整包统一声明为 MIT 或全部原创。

| 组件 | 来源与变更 | 许可与记录 |
| --- | --- | --- |
| 小说写作工坊 | 通用写作方法、模板和脚本；本版整理买家入口与扩展调用说明，不附具体小说项目 | [详细来源记录](skills/novel-workshop/assets/third-party/SOURCE-NOTES.md) |
| Oh Story 相关方法 | 工坊参考并改写的章节状态与写作流程方法 | [原有 MIT 许可与版权通知](skills/novel-workshop/assets/third-party/oh-story-LICENSE.txt) |
| Oh Story 0.8.4 新增模块与工具 | 完整拆文、市场观察等方法重写；工作台有适配，章节索引、材料检查与关系图保留原实现 | [0.8.4 MIT 许可](skills/novel-workshop/assets/third-party/oh-story-0.8.4-LICENSE.txt)及[接入范围](skills/novel-workshop/assets/third-party/INTEGRATION-NOTES.md) |
| Darwin 工坊维护适配 | 基于 [alchaincyf/darwin-skill](https://github.com/alchaincyf/darwin-skill) 的候选迭代和配对比较思路，面向小说工坊重写精简入口；未包含上游演示与截图功能 | [Darwin MIT 许可与版权通知](skills/darwin-novel-workshop/LICENSE) |
| TypeSafe 可选开发技能 | TypeSafe 技能源码，正文与所附许可证保持原样 | [TypeSafe MIT 许可](optional/typesafe-ai/LICENSE) |

部分工坊来源材料未附独立使用条款；具体项目已在详细来源记录中标注。整理、改写和打包本身不等于完成全部来源的商业授权核验。本说明不增加或替代第三方许可，也不替权利人授予未明确提供的权利。

包内不含课程截图、课程全文、私人小说正文、个人项目记录、账户或 API 密钥。AI 平台、模型或外部服务不随本包提供；它们的账户、费用和使用条款由相应提供方确定。

r4 起新增的标点模块、交付门卡、事实账模板、`punctuation_lint.py`、`fact_guard.py`、`darwin_eval.py` 与 `tests/`，以及 r5 新增的工坊宪法、规则登记表、`delivery_manifest.py`、`workflow_demo.py` 和几份模板，由制作方和作者委托的另一条开发线（r4.2、r4.3）编写，只用 Python 标准库，没有引入第三方代码。

附带的 MIT 版权与许可通知应随对应组件一同保留。工坊脚本导出的 sale 模式控制文件范围和资源完整性，不是权利认证。

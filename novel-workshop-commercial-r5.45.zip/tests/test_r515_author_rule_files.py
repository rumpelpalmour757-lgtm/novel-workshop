#!/usr/bin/env python3
"""r5.15: an author's own rule file mixes rules with descriptions of the text, and the descriptions can be wrong.

On 2026-10-19 an author sent a "supplementary rules" file to be enforced in every AI-assisted revision. Its rules
(what each object is called, which words are banned, recompute a whole chain when one link changes) were sound and the
accepted chapters already followed them. Its descriptions of the text were not all right: one step of a money chain was
credited to the wrong source (the sums were right), a warning effect was filed under the wrong ability, a chapter was
labelled with the previous chapter's events, and "the duration does not change" stated more than the text, which only
says no change was listed. The delivery card ranks "the author's current explicit decision" above "accepted story
facts", so an assistant that reads such a description as a decision would rewrite accepted chapters to match a mistake.

No script reads author rule files, so these tests pin the wording where the risk sits:
- the continuity module's evidence section tells rules from descriptions, says a description is checked against the
  accepted text before use, is not used to change the text, and goes to the author when it disagrees; a change the
  author does ask for goes through the controlled change of the constitution;
- the delivery card's priority item says the same in one sentence, so that chat-only setups (which often have only
  the card) get it too;
- SKILL.md routes an author's rule file or naming sheet to the continuity module;
- the fact ledger still has the summary layer the module points to, and only accepted and author-confirmed facts enter
  the baseline (test_fact_repair.py checks the behaviour).
"""

import json
import os
from pathlib import Path
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"


def part(text, start, stop):
    return text.split(start, 1)[1].split(stop, 1)[0]


class AuthorRuleFiles(unittest.TestCase):
    def test_continuity_tells_rules_from_descriptions_where_evidence_is_ranked(self):
        text = (SKILL / "references" / "continuity.md").read_text(encoding="utf-8")
        section = part(text, "## 建立证据范围", "\n## ")
        for phrase in ("规定", "照办", "描述", "先在已采纳的正文里找到原句", "不按描述改正文",
                       "列出两边的原句和位置", "受控变更", "摘要层"):
            self.assertIn(phrase, section)
        # It qualifies the sentence about explicit priority, so it must come after it, not in another section.
        self.assertLess(section.index("明确“以此为准”才有相应优先级"), section.index("先在已采纳的正文里找到原句"))

    def test_delivery_card_priority_item_says_descriptions_are_not_decisions(self):
        card = (SKILL / "assets" / "delivery-gate-card.md").read_text(encoding="utf-8")
        item = part(card, "0. **优先顺序。**", "\n1. ")
        for phrase in ("规定照办", "描述正文的话", "先在已采纳的正文里找到原句", "列给作者", "不当成改正文的决定"):
            self.assertIn(phrase, item)

    def test_skill_routes_author_rule_files_to_continuity(self):
        skill = (SKILL / "SKILL.md").read_text(encoding="utf-8")
        row = [line for line in skill.splitlines() if "作者给的条例或口径表" in line]
        self.assertEqual(len(row), 1)
        self.assertIn("(references/continuity.md)", row[0])
        self.assertIn("描述正文的话先核原句", row[0])

    def test_summary_layer_the_module_points_to_stays_out_of_the_baseline(self):
        note = json.loads((SKILL / "assets" / "fact-ledger-template.json").read_text(encoding="utf-8"))["note"]
        self.assertIn("summary 摘要", note)
        self.assertIn("只有前两层且来源有效的事实进入核对基线", note)
        self.assertLess(note.index("accepted 已采纳正文"), note.index("author_confirmed 作者确认"))


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""r5.40: a part taken for one scene stays with that scene (the author's r5.39 report, points 1 to 3).

Two defects reproduced on r5.39, in both packages, with the report's offline tool: (1) a part for one scene recorded
before r5.38 has no taken_for; adding a use for chapter 8 (mode use) brought it to chapter 8's card, because the card
only held back parts that had a taken_for list; (2) "整张" taken for one scene was written out before the scope check,
so the whole image went to every chapter the image was used in. Both writes were OK and check found nothing.

These tests look at what the target scene's card actually receives, through the real adopt -> check -> card path
(and the command line once). The defect cases fail on r5.39, and so does the waiting mark (taken_for_unknown), which
r5.39's check does not know; the others are behaviour to keep and pass on both: an old part of an image used once
still reads as for that scene, stable parts and "整张" taken as stable travel, replace logs no binding for the parts
it replaces, and a restored revision reads as before. Test data only: the image hashes, the example.org pages and the
"作者" observations are structural fixtures; no image was looked at.

A second reading of the fix (another agent, before delivery) found more ways through, now tested too: a use that names
no scene got a part taken for one scene of that chapter; a use r5.39 had appended was read as an old part's scene (the
library's own log says which uses later writes added); mode add naming an old part of unclear scene settled it without
the waiting mark; replace naming a part again without a scene dropped the scenes it was taken for; a waiting mark
written wrong was read two ways; "本书改" was copied onto a block where part of what it speaks of is held back.
"""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SCRIPTS = ROOT / "skills" / "novel-workshop" / "scripts"
READ = SCRIPTS / "inspiration_library.py"
WRITE = SCRIPTS / "inspiration_write.py"
SEEN = "柜台在左，墙上一排灯"
DECIDED = {"by": "作者", "date": "2026-10-23", "words": "要布局"}


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


lib = load(READ, "r540_library")
writer = load(WRITE, "r540_writer")  # it loads its own copy of the library module


def place(chapter, scene):
    return {"chapter": chapter, "scene": scene}


def entry(take, use, adapt=None, established=None, sha="ab" * 32):
    value = {"id": "WEB-1", "kind": "place", "title": "旧铺子", "status": "picked",
             "source": {"type": "link", "url": "https://page.example.org/shop", "license": "CC BY 2.0"},
             "image": {"sha256": sha, "width": 320, "height": 240},
             "observation": {"scope": "original", "image_sha256": sha, "seen": SEEN, "by": "作者", "date": "2026-10-23"},
             "take": take, "decision": dict(DECIDED), "use": use, "conflicts": []}
    if adapt:
        value["adapt"] = adapt
    if established:
        value["established"] = established
    return value


def selection(*adopt, words="第八章也用它"):
    return {"schema": "inspiration-selection/1", "decision": {"by": "作者", "date": "2026-10-24", "words": words},
            "adopt": list(adopt)}


def use_only(*places):
    return {"id": "WEB-1", "mode": "use", "use": list(places)}


class SceneScope(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.path = self.root / "library.json"

    def tearDown(self):
        self.tmp.cleanup()

    def library(self, *entries):
        data = {"schema": "inspiration-library/2", "book": "测试", "revision": 1, "entries": list(entries)}
        self.path.write_bytes(json.dumps(data, ensure_ascii=False).encode("utf-8"))
        self.assertEqual(lib.check_v2(data, self.root)[0], [])
        return data

    def data(self):
        return json.loads(self.path.read_bytes().decode("utf-8"))

    def adopt(self, sel, revision):
        report = writer.adopt(self.path, sel, revision)
        self.assertIn(report["status"], ("OK", "UNCHANGED"), report)
        self.assertEqual(lib.check_v2(self.data(), self.root)[0], [])
        return report

    def card(self, chapter, scene=None):
        """The chapter's card as the command line makes it: with the uses the library's own log says later writes
        added (r5.40; when this file runs against r5.39 to show the defects, that version has no such reading)."""
        if hasattr(lib, "added_uses"):
            return lib.card(self.data(), chapter, scene, lib.added_uses(self.path))
        return lib.card(self.data(), chapter, scene)

    def material(self, chapter, scene):
        """The material line the given scene's block gets on the chapter's card."""
        card = self.card(chapter, scene)
        lines = [x for x in card.splitlines() if x.startswith("- **看得见、摸得到的东西**：")]
        self.assertEqual(len(lines), 1, card)
        return lines[0]

    def blocks(self, chapter):
        """Every block of the chapter's card: {Scene ID as printed: its material line}."""
        out, key = {}, None
        for line in self.card(chapter).splitlines():
            if line.startswith("- **Scene ID**："):
                key = line[len("- **Scene ID**："):]
            elif line.startswith("- **看得见、摸得到的东西**：") and key is not None:
                out[key] = line
        return out

    def earlier_log(self, *changes):
        """A log as r5.38 or r5.39 left it: each line one write's changes, {entry id: {use_added, mode}}."""
        folder = self.path.with_name("library.history")
        folder.mkdir(exist_ok=True)
        lines = [json.dumps({"time": "2026-10-24T10:00:0%d" % n, "action": "adopt", "from_revision": 0, "to_revision": 1,
                             "entries": sorted(c), "by": "作者", "date": "2026-10-24", "words": "", "changes": c},
                            ensure_ascii=False) for n, c in enumerate(changes)]
        (folder / "log.jsonl").write_bytes(("\n".join(lines) + "\n").encode("utf-8"))

    # --- the two defects of the report ---

    def test_an_old_part_for_one_scene_keeps_to_its_scene(self):
        self.library(entry([{"part": "灯光：红灯", "scope": "scene"}], [place(7, "S1")]))  # recorded before r5.38
        report = self.adopt(selection(use_only(place(8, "S2"))), 1)
        self.assertIn("灯光：红灯（这一场）", self.material(7, "S1"))  # the original scene keeps it
        chapter8 = self.material(8, "S2")
        self.assertNotIn("灯光：红灯（这一场）", chapter8)  # r5.39 put it here
        self.assertIn("不带到这里：“灯光：红灯”只用在第 7 章 S1", chapter8)
        bound = report["changes"]["WEB-1"]["scene_parts_bound"]
        self.assertEqual((bound["parts"], bound["taken_for"]), (["灯光：红灯"], [place(7, "S1")]))
        self.assertIn("not a new choice of the author", bound["basis"])
        part = self.data()["entries"][0]["take"][0]
        self.assertEqual((part["taken_for"], part["decision"]), ([place(7, "S1")], DECIDED))  # the author's old choice

    def test_the_whole_image_for_one_scene_keeps_to_its_scene(self):
        self.library(entry([{"part": "整张", "scope": "scene", "taken_for": [place(7, "S1")]}], [place(7, "S1")]))
        self.adopt(selection(use_only(place(8, "S2"))), 1)
        self.assertIn("整张：" + SEEN, self.material(7, "S1"))
        chapter8 = self.material(8, "S2")
        self.assertNotIn(SEEN, chapter8)  # r5.39 wrote the whole image out here
        self.assertIn("不带到这里：“整张”只用在第 7 章 S1", chapter8)

    def test_the_same_chapter_another_scene_is_another_scene(self):
        take = [{"part": "整张", "scope": "scene", "taken_for": [place(7, "S1")]},
                {"part": "灯光：红灯", "scope": "scene", "taken_for": [place(7, "S1")]}]
        self.library(entry(take, [place(7, "S1")]))
        self.adopt(selection(use_only(place(7, "S3"))), 1)
        self.assertIn("整张：" + SEEN, self.material(7, "S1"))
        other = self.material(7, "S3")
        self.assertNotIn(SEEN, other)
        self.assertNotIn("灯光：红灯（这一场）", other)

    # --- old parts whose scene the record does not tell ---

    def test_an_old_part_of_an_image_used_in_two_scenes_waits_for_the_author(self):
        self.library(entry([{"part": "布局：柜台在左", "scope": "stable"}, {"part": "灯光：红灯", "scope": "scene"}],
                           [place(7, "S1"), place(7, "S3")]))
        for scene in ("S1", "S3"):  # read only: nothing written, nothing guessed
            line = self.material(7, scene)
            self.assertNotIn("灯光：红灯（这一场）", line)
            self.assertIn("布局：柜台在左（稳定）", line)  # the rest of the entry still comes
            self.assertIn("归属待确认：“灯光：红灯”", line)
        report = self.adopt(selection(use_only(place(8, "S2"))), 1)
        unknown = report["changes"]["WEB-1"]["scene_parts_unknown"]
        self.assertEqual((unknown["parts"], unknown["uses_before"]), (["灯光：红灯"], [place(7, "S1"), place(7, "S3")]))
        part = self.data()["entries"][0]["take"][1]
        self.assertEqual((part.get("taken_for_unknown"), "taken_for" in part), (True, False))
        for chapter, scene in ((7, "S1"), (7, "S3"), (8, "S2")):
            line = self.material(chapter, scene)
            self.assertNotIn("灯光：红灯（这一场）", line)
            self.assertIn("布局：柜台在左（稳定）", line)
            self.assertIn("归属待确认", line)
        later = self.adopt(selection(use_only(place(9, "S1")), words="第九章也用它"), 2)
        self.assertNotIn("scene_parts_unknown", later["changes"]["WEB-1"])  # marked once; a later use changes nothing
        self.assertNotIn("灯光：红灯（这一场）", self.material(9, "S1"))

    def test_check_takes_the_waiting_mark_only_on_a_part_for_one_scene(self):
        good = entry([{"part": "灯光：红灯", "scope": "scene", "taken_for_unknown": True}], [place(7, "S1")])
        self.assertEqual(self.library(good)["entries"][0]["take"][0]["taken_for_unknown"], True)
        for bad in ({"part": "灯光：红灯", "scope": "stable", "taken_for_unknown": True},
                    {"part": "灯光：红灯", "scope": "scene", "taken_for_unknown": False}):
            data = {"schema": "inspiration-library/2", "book": "测试", "revision": 1,
                    "entries": [entry([bad], [place(7, "S1")])]}
            self.assertTrue(any("taken_for_unknown" in p for p in lib.check_v2(data, self.root)[0]), bad)

    def test_an_old_part_of_an_image_never_used_waits_for_the_author(self):
        self.library(entry([{"part": "灯光：红灯", "scope": "scene"}], []))
        report = self.adopt(selection(use_only(place(8, "S2"))), 1)
        self.assertEqual(report["changes"]["WEB-1"]["scene_parts_unknown"]["uses_before"], [])
        line = self.material(8, "S2")  # the only use now is the one just added: it must not be taken for the scene
        self.assertNotIn("灯光：红灯（这一场）", line)
        self.assertIn("归属待确认：“灯光：红灯”", line)

    def test_an_old_part_of_an_image_used_once_reads_as_before(self):
        self.library(entry([{"part": "灯光：红灯", "scope": "scene"}], [place(7, "S1")]))
        before = self.path.read_bytes()
        self.assertIn("灯光：红灯（这一场）", self.material(7, "S1"))
        self.assertEqual(self.path.read_bytes(), before)  # reading never rewrites the library

    # --- what the author says ---

    def test_mode_add_gives_a_part_to_the_scene_the_author_names(self):
        self.library(entry([{"part": "灯光：红灯", "scope": "scene"}], [place(7, "S1")]))
        self.adopt(selection(use_only(place(8, "S2"), place(9, "S1"))), 1)
        add = {"id": "WEB-1", "mode": "add", "take": [{"part": "灯光：红灯", "scope": "scene"}], "use": [place(8, "S2")]}
        report = self.adopt(selection(add, words="第八章那一场也要红灯"), 2)
        self.assertEqual(report["changes"]["WEB-1"]["parts_for_more_scenes"], ["灯光：红灯"])
        self.assertIn("灯光：红灯（这一场）", self.material(7, "S1"))
        self.assertIn("灯光：红灯（这一场）", self.material(8, "S2"))
        self.assertNotIn("灯光：红灯（这一场）", self.material(9, "S1"))  # not inherited by the other new use

    def test_mode_add_on_a_part_waiting_for_the_author(self):
        self.library(entry([{"part": "灯光：红灯", "scope": "scene"}], [place(7, "S1"), place(7, "S3")]))
        self.adopt(selection(use_only(place(8, "S2"))), 1)
        add = {"id": "WEB-1", "mode": "add", "take": [{"part": "灯光：红灯", "scope": "scene"}], "use": [place(7, "S3")]}
        self.adopt(selection(add, words="红灯是第七章 S3 那一场的"), 2)
        self.assertIn("灯光：红灯（这一场）", self.material(7, "S3"))
        for chapter, scene in ((7, "S1"), (8, "S2")):
            line = self.material(chapter, scene)
            self.assertNotIn("灯光：红灯（这一场）", line)
            self.assertIn("作者已说明用在第 7 章 S3", line)

    def test_stable_parts_and_a_whole_image_taken_as_stable_travel(self):
        take = [{"part": "整张", "scope": "stable"}]
        self.library(entry(take, [place(7, "S1")]))
        self.adopt(selection(use_only(place(8, "S2"))), 1)
        self.assertIn("整张：" + SEEN, self.material(8, "S2"))
        self.assertNotIn("不带到这里", self.material(8, "S2"))

    def test_mixed_stable_and_scene_parts_are_sorted_one_by_one(self):
        take = [{"part": "布局：柜台在左", "scope": "stable"}, {"part": "灯光：红灯", "scope": "scene",
                                                             "taken_for": [place(7, "S1")]}]
        self.library(entry(take, [place(7, "S1")], adapt="红灯改成暗红的检修灯"))
        self.adopt(selection(use_only(place(8, "S2"))), 1)
        chapter8 = self.material(8, "S2")
        self.assertIn("布局：柜台在左（稳定）", chapter8)
        self.assertNotIn("灯光：红灯（这一场）", chapter8)
        # the book's change is one text for the whole entry and here it speaks of the red light held back: not copied
        self.assertNotIn("暗红的检修灯", chapter8)
        self.assertIn("本书改：（写在一起，可能说到不带到这里的那几样，这里不照抄；原话见灵感库 WEB-1，只对这里借的几样用）", chapter8)
        self.assertIn("本书改：红灯改成暗红的检修灯", self.material(7, "S1"))

    def test_nothing_brought_means_no_adapt_text_either(self):
        take = [{"part": "灯光：红灯", "scope": "scene", "taken_for": [place(7, "S1")]}]
        self.library(entry(take, [place(7, "S1")], adapt="红灯改成暗红的检修灯"))
        self.adopt(selection(use_only(place(8, "S2"))), 1)
        chapter8 = self.material(8, "S2")
        self.assertIn("（这里没有要借的）", chapter8)
        self.assertNotIn("暗红的检修灯", chapter8)  # the book's change was said of the red light held back here
        self.assertIn("本书改：（对别处借的那几样说的，这里不用）", chapter8)

    # --- what must stay ---

    def test_the_record_stays_whole_and_a_choice_made_again_changes_nothing(self):
        established = [{"part": "布局：柜台在左", "where": "项目档案", "chapter": 7}]
        take = [{"part": "布局：柜台在左", "scope": "stable"}, {"part": "灯光：红灯", "scope": "scene"}]
        original = self.library(entry(take, [place(7, "S1")], established=established))["entries"][0]
        report = self.adopt(selection(use_only(place(8, "S2"))), 1)
        self.assertEqual(report["revision"], 2)
        after = self.data()["entries"][0]
        for key in ("observation", "established", "image", "source"):
            self.assertEqual(after[key], original[key], key)
        self.assertEqual([t["part"] for t in after["take"]], ["布局：柜台在左", "灯光：红灯"])  # nothing dropped
        self.assertEqual([t.get("decision") for t in after["take"]], [DECIDED, DECIDED])
        log = (self.path.with_name("library.history") / "log.jsonl").read_text(encoding="utf-8").splitlines()
        self.assertIn("scene_parts_bound", json.loads(log[-1])["changes"]["WEB-1"])
        again = writer.adopt(self.path, selection(use_only(place(8, "S2"))), 2)
        self.assertEqual((again["status"], again["revision"]), ("UNCHANGED", 2))
        self.assertEqual(self.data()["entries"][0], after)

    # --- found by a second reading of the fix (r5.40, before delivery) ---

    def test_a_use_without_a_scene_gets_nothing_taken_for_a_scene(self):
        take = [{"part": "整张", "scope": "scene", "taken_for": [place(7, "S1")]},
                {"part": "灯光：红灯", "scope": "scene"},  # recorded before r5.38
                {"part": "布局：柜台在左", "scope": "stable"}]
        self.library(entry(take, [place(7, "S1")]))
        self.adopt(selection(use_only({"chapter": 7}), words="第七章别处也用它"), 1)  # a request with no scene
        blocks = self.blocks(7)
        self.assertIn("整张：" + SEEN, blocks["S1"])
        self.assertIn("灯光：红灯（这一场）", blocks["S1"])
        no_scene = blocks["（灵感库里没写是哪一场）"]
        self.assertNotIn(SEEN, no_scene)  # it compared only the chapter number
        self.assertNotIn("灯光：红灯（这一场）", no_scene)
        self.assertIn("不带到这里：“整张”只用在第 7 章 S1", no_scene)
        self.assertIn("布局：柜台在左（稳定）", no_scene)

    def test_uses_an_earlier_version_added_are_read_from_the_log(self):
        # r5.39 added 8/S2 with mode use and did not settle the old part; its log line says the use came later
        self.library(entry([{"part": "灯光：红灯", "scope": "scene"}], [place(7, "S1"), place(8, "S2")]))
        self.earlier_log({"WEB-1": {"use_added": [place(8, "S2")], "mode": "use"}})
        self.assertIn("灯光：红灯（这一场）", self.material(7, "S1"))  # the original scene keeps it
        self.assertIn("不带到这里：“灯光：红灯”只用在第 7 章 S1", self.material(8, "S2"))
        report = self.adopt(selection(use_only(place(9, "S1")), words="第九章也用它"), 1)
        bound = report["changes"]["WEB-1"]["scene_parts_bound"]
        self.assertEqual((bound["taken_for"], bound["uses_added_later"]), ([place(7, "S1")], [place(8, "S2")]))
        self.assertEqual(self.data()["entries"][0]["take"][0]["taken_for"], [place(7, "S1")])
        self.assertNotIn("灯光：红灯（这一场）", self.material(9, "S1"))

    def test_an_old_part_whose_only_use_came_later_waits_for_the_author(self):
        self.library(entry([{"part": "灯光：红灯", "scope": "scene"}], [place(8, "S2")]))
        self.earlier_log({"WEB-1": {"use_added": [place(8, "S2")], "mode": "use"}})
        line = self.material(8, "S2")
        self.assertNotIn("灯光：红灯（这一场）", line)
        self.assertIn("归属待确认：“灯光：红灯”", line)

    def test_mode_add_alone_on_an_old_part_of_unclear_scene_keeps_it_waiting(self):
        self.library(entry([{"part": "灯光：红灯", "scope": "scene"}], [place(7, "S1"), place(7, "S3")]))
        add = {"id": "WEB-1", "mode": "add", "take": [{"part": "灯光：红灯", "scope": "scene"}], "use": [place(7, "S3")]}
        report = self.adopt(selection(add, words="红灯是第七章 S3 那一场的"), 1)  # no use is added: 7/S3 was one
        self.assertIn("scene_parts_unknown", report["changes"]["WEB-1"])
        part = self.data()["entries"][0]["take"][0]
        self.assertEqual((part["taken_for"], part.get("taken_for_unknown")), ([place(7, "S3")], True))
        self.assertIn("灯光：红灯（这一场）", self.material(7, "S3"))
        self.assertIn("作者已说明用在第 7 章 S3", self.material(7, "S1"))  # as when a use was added first

    def test_replace_without_a_scene_keeps_where_a_part_was_taken_for(self):
        take = [{"part": "布局：柜台在左", "scope": "stable"},
                {"part": "灯光：红灯", "scope": "scene", "taken_for": [place(7, "S1"), place(8, "S2")]}]
        self.library(entry(take, [place(7, "S1"), place(8, "S2")]))
        replace = {"id": "WEB-1", "mode": "replace", "take": [{"part": "灯光：红灯", "scope": "scene"}]}
        report = self.adopt(selection(replace, words="只借红灯"), 1)
        self.assertEqual([(t["part"], t.get("taken_for")) for t in self.data()["entries"][0]["take"]],
                         [("灯光：红灯", [place(7, "S1"), place(8, "S2")])])
        self.assertEqual(report["changes"]["WEB-1"]["parts_kept_for_their_scenes"], ["灯光：红灯"])
        for chapter, scene in ((7, "S1"), (8, "S2")):
            line = self.material(chapter, scene)
            self.assertIn("灯光：红灯（这一场）", line)
            self.assertNotIn("布局", line)

    def test_a_malformed_waiting_mark_still_keeps_the_part_back(self):
        data = {"schema": "inspiration-library/2", "book": "测试", "revision": 1,
                "entries": [entry([{"part": "灯光：红灯", "scope": "scene", "taken_for_unknown": "true"}], [place(7, "S1")])]}
        self.path.write_bytes(json.dumps(data, ensure_ascii=False).encode("utf-8"))
        self.assertTrue(any("taken_for_unknown" in p for p in lib.check_v2(data, self.root)[0]))  # check says so
        line = self.material(7, "S1")  # read as waiting, not as an old part of an image used once
        self.assertNotIn("灯光：红灯（这一场）", line)
        self.assertIn("归属待确认", line)
        report = writer.adopt(self.path, selection(use_only(place(8, "S2"))), 1)
        self.assertEqual(report["status"], "OK", report)  # a problem the library had before does not stop a write
        self.assertNotIn("scene_parts_bound", report["changes"]["WEB-1"])  # the writer reads it the same way
        for chapter, scene in ((7, "S1"), (8, "S2")):
            line = self.material(chapter, scene)
            self.assertNotIn("灯光：红灯（这一场）", line)
            self.assertIn("归属待确认", line)

    def test_a_later_use_settles_nothing_again(self):
        self.library(entry([{"part": "灯光：红灯", "scope": "scene"}], [place(7, "S1")]))
        self.adopt(selection(use_only(place(8, "S2"))), 1)
        report = self.adopt(selection(use_only(place(9, "S1")), words="第九章也用它"), 2)
        changes = report["changes"]["WEB-1"]
        self.assertNotIn("scene_parts_bound", changes)  # settled once, by the first write that added a use
        self.assertNotIn("scene_parts_unknown", changes)
        self.assertEqual(self.data()["entries"][0]["take"][0]["taken_for"], [place(7, "S1")])
        self.assertNotIn("灯光：红灯（这一场）", self.material(9, "S1"))
        self.assertIn("灯光：红灯（这一场）", self.material(7, "S1"))

    def test_replace_records_no_binding_for_the_parts_it_replaces(self):
        self.library(entry([{"part": "灯光：红灯", "scope": "scene"}], [place(7, "S1")]))
        replace = {"id": "WEB-1", "mode": "replace", "take": [{"part": "灯光：蓝灯", "scope": "scene"}],
                   "use": [place(8, "S2")]}
        report = self.adopt(selection(replace, words="第八章只借蓝灯"), 1)
        changes = report["changes"]["WEB-1"]
        self.assertNotIn("scene_parts_bound", changes)  # the red light is replaced, not bound to a scene
        self.assertEqual([t["part"] for t in changes["take_before"]], ["灯光：红灯"])
        self.assertNotIn("taken_for", changes["take_before"][0])  # the old record as it was
        self.assertEqual(self.data()["entries"][0]["take"][0]["taken_for"], [place(8, "S2")])
        self.assertIn("灯光：蓝灯（这一场）", self.material(8, "S2"))
        self.assertNotIn("灯光：蓝灯（这一场）", self.material(7, "S1"))

    def test_a_restored_revision_reads_as_before(self):
        self.library(entry([{"part": "灯光：红灯", "scope": "scene"}], [place(7, "S1")]))
        self.adopt(selection(use_only(place(8, "S2"))), 1)
        report = writer.restore(self.path, 2, revision=1)
        self.assertEqual(report["status"], "OK", report)
        data = self.data()
        self.assertEqual((data["entries"][0]["use"], "taken_for" in data["entries"][0]["take"][0]), ([place(7, "S1")], False))
        self.assertIn("灯光：红灯（这一场）", self.material(7, "S1"))
        self.assertEqual(lib.card(data, 8), "第 8 章在灵感库里没有挑中的条目，也没有待找的。\n")

    def test_the_command_line_card(self):
        self.library(entry([{"part": "整张", "scope": "scene", "taken_for": [place(7, "S1")]}], [place(7, "S1")]))
        self.adopt(selection(use_only(place(8, "S2"))), 1)
        proc = subprocess.run([sys.executable, "-I", "-B", str(READ), "card", str(self.path), "--chapter", "8"],
                              capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertNotIn(SEEN, proc.stdout)
        self.assertIn("不带到这里：“整张”只用在第 7 章 S1", proc.stdout)


if __name__ == "__main__":
    unittest.main()

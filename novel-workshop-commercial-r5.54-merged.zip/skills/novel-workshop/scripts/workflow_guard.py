#!/usr/bin/env python3
"""Check declared manuscript constraints and persist bounded revision events.

No model calls, manuscript writes, publication, or semantic quality scoring.
Only the explicitly selected state file and its persistent advisory lock are written.

Delivery gate: four states that never stand in for one another --
INPUT_READY (frozen inputs present and unchanged), MECHANICAL (declared checks
re-run on the current candidate bytes), EDITORIAL (a bound review with quotes
that exist in the reviewed version) and AUTHOR (an explicit acceptance of those
exact bytes). Anything not run is UNTESTED; anything that cannot be verified is
BLOCKED; any edit after a review makes the old results STALE.

Every record is bound to its execution context (plan generation, frozen sources,
candidate path and bytes, claims, and the hashes of the checking scripts); a change
to any of them makes the old results STALE. Governance (CONSTITUTION.md next to
SKILL.md): `start` records the constitution version and file hashes, and `status`
warns when they changed afterwards. `status` also derives a one-word stage
(DRAFT ... READY_FOR_AUTHOR, AUTHOR_ACCEPTED, or UNTESTED / BLOCKED /
NEEDS_REVISION / STALE) and permission decisions (ALLOW, ALLOW_WITH_WARNING,
REVIEW_REQUIRED, BLOCK) for what may be claimed about the current text. The
four states stay the authority; stage and permissions are read-only summaries.

Every review item has its own id and needs its own decision; colliding ids are
refused (DUPLICATE_REVIEW_ITEM), never merged. Strict mode also needs the six
review dimensions (met / issue / not_reviewed / not_applicable, each with a
note); they are stored in the state together with the review file and its hash.
`accept --skip-review` records an author who decided to skip the review: the
current bytes are frozen by hash and nothing is upgraded to GREEN or PASS.

A strict-mode PASS also needs the expression record (r5.11): segments that tile
the agreed scope with a note each, and located keep / change decisions. The tool
checks only that the record is complete, matches the scope, can be located and
belongs to these bytes; whether the judgments are right stays an editorial
question. `status --deliverable FILE` tells whether a file to be delivered is
the version that was checked. After a recorded PASS, each separate change needs a
decision that covers it (r5.16). From r5.22 the change decisions are done to the
version recorded before, each at its place and each for its own change only; what
is left needs words a decision keeps or gives in the candidate around it. From
r5.23 the order of the decisions in the review does not change the result, and
words taken out on the edge of a decision's words (by a cut, or by a rewrite the
diff joins to it) count only as a few words of the same sentence.
"""

import argparse
import base64
from contextlib import contextmanager
from difflib import SequenceMatcher
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import sys
import tempfile
import time
import unicodedata

# The state lock must be released by the OS when the process ends (r4.2). POSIX has fcntl.flock;
# Windows has no fcntl module, so a top-level "import fcntl" stopped this script (and every script
# that loads it) from starting there. msvcrt.locking gives the same released-on-exit lock.
try:
    import fcntl
except ImportError:
    fcntl = None
try:
    import msvcrt
except ImportError:
    msvcrt = None


TYPES = {"length", "literal_count", "contains", "scope", "quote", "file_hash", "punctuation", "facts", "prose",
         "revision", "title", "scene_beats", "voice_material"}
LENGTH_BASES = {"non_whitespace", "han"}
# Every script whose behaviour a recorded result depends on. A change to any of them makes old results STALE.
VERIFIERS = ("workflow_guard", "punctuation_lint", "prose_lint", "fact_guard", "project_state")
SENTENCE_ENDS = "。！？!?"  # where a sentence ends, for the diff (r5.22)
SENTENCE_TAIL = "”’」』）)】》"  # closing marks that stay with the sentence end before them (r5.22)
TRAILING_ENDS = "…⋯—―"  # an ellipsis or dash ends a sentence when a closing mark follows it (r5.23)
# What can end a sentence or an utterance. Words taken out on the edge of a decision's words (a cut, or the old words
# of a rewrite) that hold more of these than the words put in their place took a sentence end with them: a sentence
# or an utterance of its own, or the end of one joined to the next, so they need a decision of their own (r5.23; r5.22
# looked at 。！？ and at cuts only, and let a line of dialogue ending in an ellipsis pass beside a kept sentence).
END_MARKS = SENTENCE_ENDS + TRAILING_ENDS + SENTENCE_TAIL
GOVERNANCE_FILES = ("CONSTITUTION.md", "assets/constitution-rules.json")  # relative to the skill folder
FROZEN_FIELDS = ("source", "rules", "ledger")
REVIEW_SCHEMA = "editorial-review/2"
REVIEWER_MODES = {"self_check", "independent_agent", "human_editor"}
SPREAD_MIN_CHARS = 300  # shorter candidates are not split into beginning / middle / end
LOCATION_GAP = 6        # evidence quotes closer than this many characters count as one location
# The six dimensions of the editorial review (references/quality-loop.md). Ids are fixed so that reviews written by
# different executors can be read the same way; the names are for people.
DIMENSIONS = (("paragraphing", "段落密度与语义分段"), ("dialogue_punctuation", "对白与标点"),
              ("scene_reconstruction", "场景可还原性"), ("narrative_function", "叙事功能"),
              ("continuity", "跨章连续性"), ("revision_comparison", "修订前后对照"))
DIMENSION_NAMES = dict(DIMENSIONS)
DIMENSION_STATUSES = {"met": "达到", "issue": "有问题", "not_reviewed": "未看", "not_applicable": "不适用"}
DIMENSION_FIELDS = {"id", "status", "note", "evidence", "where"}
# Only two dimensions can lie outside a task (a first chapter has no earlier chapter, a new chapter has no earlier
# version), and not when the task itself declares the check that makes them apply.
MAY_NOT_APPLY = {"continuity": ("facts",), "revision_comparison": ("revision", "scope")}
POLICY_DEFAULTS = {"light": {"min_evidence": 1, "spread": False, "require_independent": False, "dimensions": False},
                   "strict": {"min_evidence": 3, "spread": True, "require_independent": False, "dimensions": True}}
POLICY_FIELDS = ("min_evidence", "spread", "require_independent", "dimensions")
KEPT_REVIEW_FIELDS = ("schema", "verdict", "candidate_sha256", "reviewer", "checked_against", "inputs_read", "evidence",
                      "issues", "machine_dispositions", "dimensions", "expression", "scenes", "counter_evidence", "limits")
# Scene planning and scene review (r5.32, CON-011, references/scene-dramaturgy.md, assets/scene-beat-card.md). The beat
# card is a frozen source of the task: written before the run starts, it cannot be changed afterwards to fit the draft.
# NWC-1.5 (2026-10-23, r5.34, approved by the author): "other" scenes (a payoff, two people growing closer, staying
# with a loss, exploring) stand on what changes in them, not on the four beats; core and action scenes keep the beats.
SCENE_TYPES = {"core": ("core conflict", "核心博弈"), "action": ("action", "crisis", "动作危机"),
               "other": ("other", "其他场"), "transition": ("transition", "过场")}
TURNING_TYPES = ("core", "action")
SCENE_FIELDS = (("id", ("scene id",)), ("type", ("scene type",)), ("pov", ("pov",)), ("polarity", ("polarity shift",)),
                ("prop", ("prop anchor",)), ("beat1", ("入场动作与诉求", "goal")),
                ("beat2", ("对手反制与阻碍", "obstacle")), ("beat3", ("破局点", "the turn")),
                ("beat4", ("出场悬念钩子", "exit hook")), ("process", ("禁止直接概括的过程",)),
                ("subtext", ("潜台词冰山", "subtext")), ("embodiment", ("情绪生理化映射", "embodiment")),
                ("change", ("change", "这一场变了什么")))
SCENE_FIELD_NAMES = {"pov": "POV Character", "polarity": "Polarity Shift", "prop": "Core Prop Anchor",
                     "beat1": "1 入场动作与诉求", "beat2": "2 对手反制与阻碍", "beat3": "3 破局点/意外转折",
                     "beat4": "4 出场悬念钩子", "process": "禁止直接概括的过程", "subtext": "潜台词冰山",
                     "embodiment": "情绪生理化映射", "change": "Change (这一场变了什么)"}
SCENE_REQUIRED = {"core": ("pov", "polarity", "prop", "beat1", "beat2", "beat3", "beat4", "process", "subtext",
                           "embodiment"),
                  "action": ("pov", "polarity", "beat1", "beat2", "beat3", "beat4", "process", "subtext", "embodiment"),
                  "other": ("pov", "change"), "transition": ()}
CARD_FIELD = re.compile(r"^\s*(?:[-*+]|\d+[.、)])\s*\*\*(?P<label>[^*\n]+?)\*\*\s*[:：]?\s*(?P<value>.*)$")
CARD_HINT = re.compile(r"\*\([^)]*\)\*|\*（[^）]*）\*|`")
NO_CHANGE = re.compile(r"^(?:无变化|没有变化|不变|同上|无|none|n/?a|-+)$", re.IGNORECASE)
REVIEW_SCENE_FIELDS = {"id", "polarity_shifted", "prop_embodiment_score", "note", "evidence"}
# The voice and material card (r5.33, CON-012, assets/voice-material-card.md): voice samples (the author's own accepted
# text, or a target draft the author named) and, for every core scene, what is there to see and touch, with where it
# comes from. Like the beat card it is a frozen source of the task, written before the draft.
MATERIAL_FIELDS = (("sample_source", ("样本来源",)), ("sample_text", ("原文",)), ("sample_notes", ("从样本里看出来的",)),
                   ("no_sample", ("没有样本",)), ("scene", ("scene id",)), ("things", ("看得见、摸得到的东西",)),
                   ("origin", ("出处",)), ("conflicts", ("和已定设定不一样的",)))
# prose_lint's scene rules. Their review items carry the rule and whether the hit is inside a character's line. Since
# NWC-1.5 (r5.34) they are literal hints like any other machine item: a hit in the narration is rewritten, or kept with
# a reason of its own (every hit has its own disposition); whether the reason holds is the reviewer's call. The author's
# decision for a place or for the whole book still goes into the rules file (ignore / off).
SCENE_HIT_RULES = ("floating-dialogue", "tension-telling", "weak-scene-ending")
# The expression record (r5.11, references/prose-audit.md "整章任务的表达检查与记录"). A segment of more than SEGMENT_MAX
# non-space characters that spans several paragraphs is one blanket claim, not a record of where the pass looked.
EXPRESSION_SCOPES = ("chapter", "local")
EXPRESSION_FIELDS = {"scope", "segments", "decisions", "note"}
SEGMENT_FIELDS = {"from", "to", "note"}
DECISION_FIELDS = {"decision", "quote", "before", "after", "offset", "judgment", "reason"}
SEGMENT_MAX = 800
ANCHOR_MIN = 4
# r5.48: what a program can and cannot check in a review record. A field still holding the template's "替换为……"
# text was never filled in. A keep reason made only of words that name a kind of effect (有余韵, 起收束作用, 作者的口吻,
# 开场定调) says nothing about this place (prose-audit.md "三步处理"). A segment with no keep or change in it is a
# zero-change segment: allowed, but its note quotes at least NOTE_QUOTE_MIN characters of that segment, so the record
# shows where the reader looked and what was weighed there. None of this shows the judgment is right.
TEMPLATE_MARK = "替换为"
GENERIC_REASON = re.compile(
    r"^(?:(?:有|保留|起到?|带(?:有)?|是)?(?:一处)?(?:余韵|收束(?:作用)?|作者的?(?:口吻|风格|语气|写法|习惯)|原文(?:成立|如此|就这样)"
    r"|没有?问题|无问题|无需修改|不用改|不必改|读着顺|读起来顺|语感(?:好|自然|顺)|保留原文|开场定调|定调|氛围|节奏感?|有作用"
    r"|逐句读过|已读|读过|已检查|检查过|通读)(?:的)?(?:作用)?[，,、；;。！\s]*)+$")
NOTE_QUOTE_MIN = 4
_MODULES = {}
STATE_FIELDS = {"task_id", "current_node", "completed_nodes", "artifacts", "decisions",
                "evidence", "budgets", "retry_counts", "human_approvals", "events"}


class GuardError(ValueError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def need(condition, message, code="INVALID_INPUT"):
    if not condition:
        raise GuardError(code, message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def fingerprint(value):
    return digest(json.dumps(value, sort_keys=True, ensure_ascii=False).encode("utf-8"))


def read_bytes(path):
    try:
        return Path(path).read_bytes()
    except FileNotFoundError as exc:
        raise GuardError("MISSING_REQUIRED_SOURCE", str(path)) from exc


def strict_json(data):
    """json.loads that refuses a repeated key in one object. Python would silently keep only the last value, which
    can drop a check, a claim field or a review conclusion without anyone noticing (the same class of silent
    overwrite as the duplicate review ids in the r5 review, F01/F02)."""
    def pairs(items):
        value = {}
        for key, item in items:
            need(key not in value, "Repeated JSON key %r in one object; write each key once" % key, "INVALID_INPUT")
            value[key] = item
        return value
    return json.loads(data.decode("utf-8") if isinstance(data, bytes) else data, object_pairs_hook=pairs)


def read_json(path):
    return strict_json(read_bytes(path))


def sibling(name):
    """Load a helper shipped next to this file, independent of sys.path (-I safe)."""
    if name not in _MODULES:
        sys.dont_write_bytecode = True  # keep skill folders free of __pycache__ (installer compares exact files)
        location = Path(__file__).resolve().with_name(name + ".py")
        need(location.is_file(), "Helper script is missing: " + location.name, "MISSING_REQUIRED_SOURCE")
        spec = importlib.util.spec_from_file_location("novel_workshop_" + name, location)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _MODULES[name] = module
    return _MODULES[name]


def policy(spec):
    mode = spec.get("mode", "light")
    merged = dict(POLICY_DEFAULTS[mode])
    merged.update(spec.get("review_policy", {}))
    merged["mode"] = mode
    return merged


def local_path(root, name):
    need(isinstance(name, str) and bool(name.strip()), "Expected a relative file path")
    path = Path(name)
    need(not path.is_absolute(), "File paths must be relative to the project")
    resolved = (root / path).resolve()
    try:
        resolved.relative_to(root.resolve())
    except ValueError as exc:
        raise GuardError("INVALID_INPUT", "File path leaves the project: " + name) from exc
    return resolved


def integer(value, minimum=0):
    return type(value) is int and value >= minimum


HAN_CHAR = re.compile("[㐀-䶿一-鿿豈-﫿]")
HEADING_LINE = re.compile(r"^\s*(?:#|第[0-9一二三四五六七八九十百千零〇两]+[章节回卷部集])")
CHAPTER_NUMBER = re.compile(r"^(?:第[0-9一二三四五六七八九十百千零〇两]+[章节回卷部集]|chapter\s*\d+|\d+[、.．])[\s:：·\-—]*",
                            re.IGNORECASE)


def as_text(data):
    """Text the way every checker reads it (r5.13): UTF-8, a leading byte-order mark dropped, CRLF read as a line
    break like LF. Hashes are always taken over the bytes; this only decides what is a character and what is a line,
    so a file an editor saved with a BOM or CRLF has the same title, counts, lines and anchors as the plain file."""
    return data.decode("utf-8-sig").replace("\r\n", "\n")


def count_chars(text, basis):
    if basis == "han":
        return len(HAN_CHAR.findall(text))
    return sum(not char.isspace() for char in text)


def chapter_title(text):
    """(title, line) from the first nonblank line when it is a heading; ("", line) otherwise."""
    for number, line in enumerate(text.splitlines(), 1):
        if not line.strip():
            continue
        if not HEADING_LINE.match(line):
            return "", number
        return CHAPTER_NUMBER.sub("", line.strip().lstrip("#").strip(), count=1).strip(), number
    return "", None


def skill_root():
    return Path(__file__).resolve().parent.parent


def checker_hashes():
    """SHA-256 of every checking script; a missing script means a broken installation and raises."""
    here = Path(__file__).resolve()
    return {name: digest(read_bytes(here.with_name(name + ".py"))) for name in VERIFIERS}


def governance_snapshot():
    """Which constitution and which checkers this copy of the workshop is running with."""
    files = {}
    for name in GOVERNANCE_FILES:
        location = skill_root() / name
        files[name] = digest(location.read_bytes()) if location.is_file() else None
    version = None
    registry = skill_root() / "assets" / "constitution-rules.json"
    if registry.is_file():
        try:
            version = json.loads(registry.read_text(encoding="utf-8")).get("version")
        except ValueError:
            version = "unreadable"
    return {"constitution": {"version": version, "files": files}, "checkers": checker_hashes()}


def load_spec(path, content=None):
    path = Path(path).resolve()
    spec = strict_json(read_bytes(path) if content is None else content)
    need(isinstance(spec, dict), "Spec must be an object")
    local_path(path.parent, spec.get("candidate"))
    need(isinstance(spec.get("checks"), list), "checks must be a list")
    need(spec.get("mode", "light") in POLICY_DEFAULTS, "mode must be light or strict")
    review_policy = spec.get("review_policy", {})
    need(isinstance(review_policy, dict) and set(review_policy) <= set(POLICY_FIELDS),
         "review_policy accepts " + ", ".join(POLICY_FIELDS))
    need("min_evidence" not in review_policy or integer(review_policy["min_evidence"], 1), "min_evidence must be >= 1")
    need(all(type(review_policy[k]) is bool for k in ("spread", "require_independent", "dimensions") if k in review_policy),
         "spread, require_independent and dimensions must be true or false")
    if spec.get("mode", "light") == "strict":
        # Strict mode is a floor: the policy may be tightened, never loosened.
        floor = POLICY_DEFAULTS["strict"]
        need(review_policy.get("min_evidence", floor["min_evidence"]) >= floor["min_evidence"]
             and review_policy.get("spread", True) is True and review_policy.get("dimensions", True) is True,
             "strict mode cannot be loosened: min_evidence must stay >= %d, spread and dimensions must stay true"
             % floor["min_evidence"])
    ids = set()
    for item in spec["checks"]:
        need(isinstance(item, dict), "Each check must be an object")
        key, kind = item.get("id"), item.get("type")
        need(isinstance(key, str) and bool(key.strip()) and key not in ids, "Check ids must be unique and nonempty")
        ids.add(key)
        need(kind in TYPES, "Unknown check type: " + str(kind))
        if kind in {"contains", "literal_count", "quote"}:
            need(isinstance(item.get("text"), str) and bool(item["text"]), key + ": text must be nonempty")
        if kind == "literal_count":
            need(integer(item.get("count")), key + ": count must be a nonnegative integer")
        if kind in {"length", "title"}:
            need("min" in item or "max" in item, key + ": declare min or max")
            for field in ("min", "max"):
                if field in item:
                    need(integer(item[field]), key + ": invalid " + field)
            need(item.get("min", 0) <= item.get("max", float("inf")), key + ": min exceeds max")
            need(item.get("basis", "non_whitespace") in LENGTH_BASES, key + ": basis must be non_whitespace or han")
            need(isinstance(item.get("exclude_headings", False), bool), key + ": exclude_headings must be true or false")
        if kind in {"scope", "quote", "file_hash", "revision"}:
            source_path = local_path(path.parent, item.get("source"))
            if kind in {"scope", "revision"}:
                need(source_path != local_path(path.parent, spec["candidate"]), key + ": source must differ from candidate")
        if kind == "revision" and "rules" in item:
            need(local_path(path.parent, item["rules"]) != local_path(path.parent, spec["candidate"]),
                 key + ": rules file must differ from candidate")
        if kind == "quote" and "line" in item:
            need(integer(item["line"], 1), key + ": line must be a positive integer")
        if kind == "file_hash":
            value = item.get("sha256")
            need(isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdefABCDEF" for c in value), key + ": invalid sha256")
        if kind == "prose":
            need(item.get("paragraph_mode", "blank") in {"blank", "line"}, key + ": invalid paragraph_mode")
        if kind == "scene_beats":
            need(local_path(path.parent, item.get("source")) != local_path(path.parent, spec["candidate"]),
                 key + ": source (the beat card) must differ from candidate")
        if kind == "voice_material":
            need(local_path(path.parent, item.get("source")) != local_path(path.parent, spec["candidate"]),
                 key + ": source (the voice and material card) must differ from candidate")
        if kind in {"punctuation", "prose"} and "rules" in item:
            need(local_path(path.parent, item["rules"]) != local_path(path.parent, spec["candidate"]),
                 key + ": rules file must differ from candidate")
        if kind == "facts":
            if "chapters_dir" in item:
                need(local_path(path.parent, item["chapters_dir"]).is_dir(), key + ": chapters_dir must exist")
            ledger = local_path(path.parent, item.get("ledger"))
            claims = local_path(path.parent, item.get("claims"))
            candidate = local_path(path.parent, spec["candidate"])
            need(len({ledger, claims, candidate}) == 3, key + ": ledger, claims and candidate must be different files")
    return spec


def source_names(spec, root):
    names = {item[field] for item in spec["checks"] for field in FROZEN_FIELDS if field in item}
    for item in spec["checks"]:
        if item["type"] != "facts" or "chapters_dir" not in item:
            continue
        ledger = sibling("fact_guard").load_ledger(local_path(root, item["ledger"]))
        chapter = read_json(local_path(root, item["claims"])).get("chapter")
        need(integer(chapter), "facts claims need a nonnegative chapter number")
        directory = local_path(root, item["chapters_dir"])
        for key, entry in ledger["chapters"].items():
            if int(key) < chapter and entry["status"] in {"accepted", "author_confirmed"}:
                target = local_path(directory, entry.get("file"))
                names.add(target.relative_to(root).as_posix())
    return sorted(names)


def require_unique_ids(review_items):
    seen, repeated = set(), []
    for item in review_items:
        if item["id"] in seen and item["id"] not in repeated:
            repeated.append(item["id"])
        seen.add(item["id"])
    need(not repeated, "Several review items share one id, so one decision could cover more than one finding; give each "
         "its own id (for facts: each claim needs a unique id): " + ", ".join(repeated[:8]), "DUPLICATE_REVIEW_ITEM")


def card_value(raw):
    """A filled-in value of the beat card, without the template's hints; '' when only the template is there."""
    value = CARD_HINT.sub("", raw).strip()
    value = re.sub(r"\[\s*\]", "", value).strip()
    return "" if not value or "|" in value else value


def scene_type(value):
    lowered = value.lower()
    found = [key for key, words in SCENE_TYPES.items() if any(word in lowered for word in words)]
    return found[0] if len(found) == 1 else None


def polarity_states(value):
    """The two sides of 'A -> B'; None when the field does not name two different states."""
    parts = [part.strip(" []【】") for part in re.split(r"\s*(?:->|→|=>|——>|-+>)\s*", value)]
    if len(parts) != 2 or not all(parts) or parts[0] == parts[1] or any(NO_CHANGE.match(part) for part in parts):
        return None
    return parts


def read_beat_card(text):
    """The scenes of a filled beat card (assets/scene-beat-card.md, one block per scene) and what is missing."""
    scenes, problems, current = [], [], None
    for line in text.splitlines():
        match = CARD_FIELD.match(line)
        if not match:
            continue
        label = match.group("label").strip().lower()
        field = next((key for key, words in SCENE_FIELDS if any(word in label for word in words)), None)
        if field is None:
            continue
        if field == "id":
            current = {"_values": {}}
            scenes.append(current)
        if current is None:
            problems.append("a card field comes before the first Scene ID: " + match.group("label").strip())
            continue
        current["_values"][field] = card_value(match.group("value"))
    need(len(text) < 2000000, "beat card too large")
    out, seen = [], set()
    for number, scene in enumerate(scenes, 1):
        values = scene["_values"]
        # "S1 / 第七章": the scene id is the part before the slash (the template asks for "Scene ID / Chapter").
        key = re.split(r"\s*[/／]\s*", values.get("id") or "", maxsplit=1)[0].strip()
        name = key or "scene %d" % number
        if not key:
            problems.append("scene %d: Scene ID is empty" % number)
        elif key in seen:
            problems.append("Scene ID %s is used twice" % key)
        seen.add(key)
        kind = scene_type(values.get("type", ""))
        if kind is None:
            problems.append("%s: Scene Type must be one of Core Conflict, Action/Crisis, Other, Transition" % name)
            out.append({"id": key, "type": None})
            continue
        missing = [SCENE_FIELD_NAMES[field] for field in SCENE_REQUIRED[kind] if not values.get(field)]
        if missing:
            problems.append("%s (%s): empty: %s" % (name, kind, ", ".join(missing)))
        states = polarity_states(values.get("polarity", "")) if kind in TURNING_TYPES else None
        if kind in TURNING_TYPES and values.get("polarity") and states is None:
            problems.append("%s: Polarity Shift must turn from one state to a different one ([A] -> [B]); no change "
                            "means the scene is compressed into a transition (CON-011)" % name)
        change = values.get("change", "")
        if kind == "other" and change and NO_CHANGE.match(change.strip(" []【】")):
            problems.append("%s: Change must say what this scene changes (relations, what someone knows, preparation "
                            "for an action, or experience); nothing changes means it is compressed into a transition "
                            "(CON-011)" % name)
        entry = {"id": key, "type": kind}
        if states:
            entry["polarity"] = states
        if kind == "other" and change:
            entry["change"] = change
        if values.get("prop"):
            entry["prop"] = values["prop"]
        out.append(entry)
    if not scenes:
        problems.append("the card has no scene: copy the card block (from Scene ID down) once for every scene")
    return out, problems


def read_material_card(text):
    """The voice samples and the scene material of a filled card (assets/voice-material-card.md) and what is missing.

    A field's value is the rest of its line plus the lines under it, up to the next field or heading, without the
    template's hints. Samples need a source and the text; with no sample the card says why. Every scene block needs
    its Scene ID, the things and where they come from (CON-012)."""
    need(len(text) < 2000000, "voice and material card too large")
    blocks, current, last = [], None, None
    for line in text.splitlines():
        match = CARD_FIELD.match(line)
        if match:
            label = match.group("label").strip().lower()
            field = next((key for key, words in MATERIAL_FIELDS if any(word in label for word in words)), None)
            if field in ("sample_source", "scene") or (field and current is None):
                current = {"kind": "scene" if field == "scene" else "sample", "_values": {}}
                blocks.append(current)
            if field is not None:
                current["_values"][field] = [match.group("value")]
            last = field
            continue
        if line.lstrip().startswith("#"):
            last = None
            continue
        if last is not None and current is not None and line.strip():
            current["_values"][last].append(line.strip())
    values = [{key: card_value(" ".join(parts)) for key, parts in block["_values"].items()} for block in blocks]
    problems, samples, scenes, no_sample = [], 0, [], ""
    for block, filled in zip(blocks, values):
        if filled.get("no_sample"):
            no_sample = filled["no_sample"]
        if block["kind"] == "sample":
            if "sample_source" not in filled and "sample_text" not in filled:
                continue
            if filled.get("sample_source") and filled.get("sample_text"):
                samples += 1
            elif filled.get("sample_source") or filled.get("sample_text"):
                problems.append("a voice sample needs both 样本来源 (where it comes from) and 原文 (the text itself)")
            continue
        key = filled.get("scene", "")
        key = re.split(r"\s*[/／]\s*", key, maxsplit=1)[0].strip()
        name = key or "material block %d" % (len(scenes) + 1)
        if not key:
            problems.append("%s: Scene ID is empty" % name)
        elif key in scenes:
            problems.append("Scene ID %s has two material blocks" % key)
        scenes.append(key)
        missing = [label for field, label in (("things", "看得见、摸得到的东西"), ("origin", "出处")) if not filled.get(field)]
        if missing:
            problems.append("%s: empty: %s" % (name, ", ".join(missing)))
    if samples and no_sample:
        problems.append("the card has voice samples and also says 没有样本; keep one of them")
    elif not samples and not no_sample:
        problems.append("no voice sample: copy two or three passages of the author's own accepted text (or a target "
                        "draft the author named) with 样本来源 and 原文, or say under 没有样本 why there is none (CON-012)")
    if not [key for key in scenes if key]:
        problems.append("no scene material: one block (from Scene ID down) for every core scene, with the things and "
                        "where they come from (CON-012)")
    return {"samples": samples, "no_sample": no_sample or None, "scenes": [key for key in scenes if key]}, problems


def check_spec(path):
    path = Path(path).resolve()
    spec_bytes = read_bytes(path)
    spec = load_spec(path, spec_bytes)
    candidate_path = local_path(path.parent, spec["candidate"])
    candidate_bytes = read_bytes(candidate_path)
    candidate = as_text(candidate_bytes)
    results = []
    review_items = []
    mutable_inputs = [{"path": name, "sha256": digest(read_bytes(local_path(path.parent, name)))}
                      for name in sorted({item["claims"] for item in spec["checks"] if item["type"] == "facts"})]
    source_inputs = [{"path": name, "sha256": digest(read_bytes(local_path(path.parent, name)))}
                     for name in source_names(spec, path.parent)]
    for item in spec["checks"]:
        kind = item["type"]
        result = {"id": item["id"], "type": kind}
        if kind == "length":
            basis = item.get("basis", "non_whitespace")
            body = candidate
            if item.get("exclude_headings"):
                body = "\n".join(line for line in candidate.splitlines() if not HEADING_LINE.match(line))
            actual = count_chars(body, basis)
            expected = {"min": item.get("min"), "max": item.get("max"), "basis": basis,
                        "exclude_headings": bool(item.get("exclude_headings")),
                        "mode": "non_whitespace_characters" if basis == "non_whitespace" else "han_characters"}
            passed = item.get("min", 0) <= actual <= item.get("max", float("inf"))
        elif kind == "title":
            basis = item.get("basis", "non_whitespace")
            title, line_no = chapter_title(candidate)
            size = count_chars(title, basis) if title else 0
            expected = {"min": item.get("min"), "max": item.get("max"), "basis": basis,
                        "rule": "first nonblank line; Markdown # and a leading chapter number are not counted"}
            actual = {"title": title, "length": size, "line": line_no}
            passed = bool(title) and item.get("min", 0) <= size <= item.get("max", float("inf"))
        elif kind == "revision":
            rules = read_json(local_path(path.parent, item["rules"])) if "rules" in item else None
            source = as_text(read_bytes(local_path(path.parent, item["source"])))
            try:
                compared = sibling("punctuation_lint").compare_texts(source, candidate, rules)
            except ValueError as exc:
                raise GuardError("INVALID_INPUT", item["id"] + ": " + str(exc)) from exc
            result["source"] = item["source"]
            expected = {"introduced_errors": 0, "introduced_review_items": "each needs an editorial keep/issue decision"}
            actual = {"status": compared["status"], "counts": compared["counts"],
                      "introduced": compared["introduced"], "resolved": len(compared["resolved"]),
                      "tone_changes": compared["tone_changes"], "stats": compared["stats"]}
            passed = compared["counts"]["ERROR"] == 0
            review_items.extend({"id": item["id"] + ":" + f["id"], "check": item["id"], "kind": "revision",
                                 "line": f["line"], "context": f["context"], "message": "修改后新出现：" + f["message"]}
                                for f in compared["introduced"] if f["severity"] == "REVIEW")
            review_items.extend({"id": item["id"] + ":" + t["id"], "check": item["id"], "kind": "revision",
                                 "line": t["line"], "column": t["column"], "context": t["revised"], "message": t["message"],
                                 "match": t["match"]}
                                for t in compared["tone_changes"])
        elif kind in {"contains", "literal_count"}:
            actual = candidate.count(item["text"])
            expected = {"text": item["text"], "count": item.get("count", "at least 1")}
            passed = actual == item["count"] if kind == "literal_count" else actual > 0
        elif kind == "punctuation":
            rules = read_json(local_path(path.parent, item["rules"])) if "rules" in item else None
            try:
                lint = sibling("punctuation_lint").lint_text(candidate, rules)
            except ValueError as exc:
                raise GuardError("INVALID_INPUT", item["id"] + ": " + str(exc)) from exc
            if "rules" in item:
                result["rules"] = item["rules"]
            expected = {"errors": 0, "review_findings": "each needs an editorial keep/issue decision"}
            actual = {"status": lint["status"], "counts": lint["counts"], "findings": lint["findings"], "stats": lint["stats"],
                      "dialogue_soft_wrap": lint.get("dialogue_soft_wrap", False)}
            passed = lint["counts"]["ERROR"] == 0
            review_items.extend({"id": item["id"] + ":" + f["id"], "check": item["id"], "kind": "punctuation",
                                 "line": f["line"], "context": f["context"], "message": f["message"]}
                                for f in lint["findings"] if f["severity"] == "REVIEW")
        elif kind == "prose":
            rules = read_json(local_path(path.parent, item["rules"])) if "rules" in item else None
            lint = sibling("prose_lint").inspect_text(candidate, rules, item.get("paragraph_mode", "blank"))
            expected = {"findings": "each needs an editorial keep/issue decision; NO_FLAGS is not a prose verdict"}
            actual, passed = lint, True
            review_items.extend(dict({"id": "%s:%s-L%d-C%d" % (item["id"], f["rule"], f["line"], f["column"]),
                                      "check": item["id"], "kind": "prose", "line": f["line"],
                                      "context": f["quote"], "message": f["message"]},
                                     **({"rule": f["rule"], "in_quote": bool(f.get("in_quote"))}
                                        if f["rule"] in SCENE_HIT_RULES else {})) for f in lint["findings"])
        elif kind == "scene_beats":
            card = as_text(read_bytes(local_path(path.parent, item["source"])))
            scenes, problems = read_beat_card(card)
            result["source"] = item["source"]
            expected = {"card": "every scene has an id and a type; core and action scenes fill the card (core scenes "
                                "also a prop anchor) and turn from one state to a different one"}
            actual = {"scenes": scenes, "problems": problems}
            passed = not problems
        elif kind == "voice_material":
            card = as_text(read_bytes(local_path(path.parent, item["source"])))
            found, problems = read_material_card(card)
            # With a beat card in the same task, every core and action scene on it needs its material block; an
            # "other" scene may have one (NWC-1.5: the texture of a quiet scene comes from its material too).
            planned, allowed = [], []
            for other in spec["checks"]:
                if other["type"] == "scene_beats":
                    beats, _ = read_beat_card(as_text(read_bytes(local_path(path.parent, other["source"]))))
                    planned.extend(scene["id"] for scene in beats if scene.get("type") in TURNING_TYPES and scene["id"])
                    allowed.extend(scene["id"] for scene in beats
                                   if scene.get("type") in TURNING_TYPES + ("other",) and scene["id"])
            if planned or allowed:
                missing = [key for key in planned if key not in found["scenes"]]
                extra = [key for key in found["scenes"] if key not in allowed]
                if missing:
                    problems.append("core and action scenes on the beat card without a material block: " + ", ".join(missing))
                if extra:
                    problems.append("material blocks for scenes that are not core, action or other scenes on the beat "
                                    "card: " + ", ".join(extra))
            result["source"] = item["source"]
            expected = {"card": "voice samples with their source and text (or the reason there is none); for every core "
                                "scene the things to see and touch and where they come from (CON-012)"}
            actual = dict(found, planned_scenes=planned, problems=problems)
            passed = not problems
        elif kind == "facts":
            guard = sibling("fact_guard")
            try:
                ledger = guard.load_ledger(local_path(path.parent, item["ledger"]))
                fact_report = guard.check(ledger, local_path(path.parent, item["claims"]), candidate_override=candidate_path,
                                          chapters_dir=local_path(path.parent, item["chapters_dir"]) if "chapters_dir" in item else None)
            except (guard.FactError, ValueError, OSError) as exc:
                raise GuardError("INVALID_INPUT", item["id"] + ": " + str(exc)) from exc
            result.update(ledger=item["ledger"], claims=item["claims"])
            expected = {"status": "CONSISTENT or NEEDS_HUMAN", "claims_bound_to": digest(candidate_bytes)}
            actual = {key: fact_report[key] for key in ("status", "counts", "results", "extracted_by", "candidate")}
            if "ledger_problems" in fact_report:
                actual["ledger_problems"] = fact_report["ledger_problems"]
            if "watch" in fact_report:
                actual["watch"] = fact_report["watch"]
            # Zero declared claims means nothing was compared: the check did not run (UNTESTED, not GREEN).
            passed = None if fact_report["status"] == "UNTESTED" else fact_report["status"] in {"CONSISTENT", "NEEDS_HUMAN"}
            review_items.extend({"id": item["id"] + ":" + x["id"], "check": item["id"], "kind": "facts",
                                 "status": x["status"], "message": x["reason"]} for x in fact_report["review_items"])
        else:
            source_bytes = read_bytes(local_path(path.parent, item["source"]))
            result["source"] = item["source"]
            if kind == "file_hash":
                actual, expected = digest(source_bytes), item["sha256"].lower()
                passed = actual == expected
            elif kind == "quote":
                source = as_text(source_bytes)
                lines = source.splitlines(keepends=True)
                start = 0 if "line" not in item else sum(len(line) for line in lines[:item["line"] - 1])
                found = source.find(item["text"], start)
                found_line = source[:found].count("\n") + 1 if found >= 0 else None
                expected = {"text": item["text"], "line": item.get("line")}
                actual = {"found": found >= 0, "line": found_line}
                passed = found >= 0 and ("line" not in item or found_line == item["line"])
            else:
                # Lines without their line breaks (r5.13): a BOM, CRLF or a final newline is not an edit of a line.
                before = as_text(source_bytes).splitlines()
                after = candidate.splitlines()
                ranges = item.get("editable_lines")
                need(isinstance(ranges, list), item["id"] + ": editable_lines must be a list")
                allowed = set()
                for interval in ranges:
                    need(isinstance(interval, list) and len(interval) == 2 and all(integer(n, 1) for n in interval), "Invalid editable interval")
                    first, last = interval
                    need(first <= last <= len(before), "Editable interval is outside the source")
                    allowed.update(range(first, last + 1))
                actual = []
                passed = True
                # Candidate lines inside the authorised scope (editable source lines where they now stand, and every
                # changed line); a local expression record must cover these and the line on each side.
                scope_lines = set()
                for op, i, j, a, b in SequenceMatcher(None, before, after, autojunk=False).get_opcodes():
                    if op == "equal":
                        scope_lines.update(a + k + 1 for k in range(j - i) if i + k + 1 in allowed)
                        continue
                    scope_lines.update(range(a + 1, b + 1))
                    if a == b:  # lines removed: the lines on both sides of the gap
                        scope_lines.update(n for n in (a, a + 1) if 1 <= n <= len(after))
                    # Gap i lies after source line i and before line i + 1.
                    # Either editable neighbour permits insertion; replacements
                    # and deletions must touch only editable source lines.
                    touched = set(range(i + 1, j + 1))
                    within = (i in allowed or i + 1 in allowed) if op == "insert" else bool(touched) and touched <= allowed
                    passed = passed and within
                    change = {"operation": op, "source_lines": [i + 1, j] if i < j else [],
                              "candidate_lines": [a + 1, b] if a < b else [], "within_scope": within}
                    if op == "insert":
                        change["source_gap"] = i
                    actual.append(change)
                expected = {"editable_lines": ranges, "other_lines": "unchanged",
                            "insertion_gaps": "Allowed immediately before or after an editable source line"}
                result["scope_lines"] = sorted(scope_lines)
        result.update(expected=expected, actual=actual, passed=None if passed is None else bool(passed),
                      status="UNTESTED" if passed is None else "PASS" if passed else "FAIL")
        results.append(result)
    # Every review item needs its own decision. Two items under one id would let one disposition cover both
    # (r5 review F01/F02): refuse, never merge silently.
    require_unique_ids(review_items)
    untested = [r["id"] for r in results if r["passed"] is None]
    if not results:
        status = "NOT_APPLICABLE"
    elif any(r["passed"] is False for r in results):
        status = "RED"
    elif untested:
        status = "UNTESTED"
    else:
        status = "GREEN"
    need(read_bytes(path) == spec_bytes, "Check specification changed during verification", "INPUT_CHANGED")
    for entry in mutable_inputs + source_inputs:
        need(digest(read_bytes(local_path(path.parent, entry["path"]))) == entry["sha256"],
             "Input changed during verification: " + entry["path"], "INPUT_CHANGED")
    need(digest(read_bytes(candidate_path)) == digest(candidate_bytes),
         "Candidate changed during verification", "INPUT_CHANGED")
    return {"status": status, "untested_checks": untested, "spec_sha256": digest(spec_bytes), "mutable_inputs": mutable_inputs,
            "candidate": {"path": spec["candidate"], "sha256": digest(candidate_bytes)}, "checks": results,
            "review_items": review_items, "review_policy": policy(spec), "checkers": checker_hashes(),
            "note": ("GREEN covers only the declared checks on these candidate bytes; UNTESTED means a declared check "
                     "did not actually compare anything; review_items need editorial decisions.")}


@contextmanager
def locked(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    # Do not silently remove a lock left by an older version or compete with it.
    need(not path.with_name(path.name + ".lock").exists(),
         "Legacy .lock exists: confirm the old process has stopped, then archive that lock before retrying", "STATE_BUSY")
    lock = path.with_name(path.name + ".flock")
    handle = os.open(str(lock), os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0), 0o600)
    try:
        os_lock(handle)
        try:
            yield
        finally:
            os_unlock(handle)
    finally:
        # The OS releases the lock even after termination. Never unlink this
        # inode: a waiting process may still hold it open.
        os.close(handle)


def os_lock(handle):
    """Take an exclusive, non-blocking lock that the OS drops when the handle closes or the process dies."""
    busy = "Another process holds the state lock; retry after it finishes"
    if fcntl is not None:
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise GuardError("STATE_BUSY", busy) from exc
    elif msvcrt is not None:
        # Windows: lock the first byte (locking past the end of an empty file is allowed).
        os.lseek(handle, 0, os.SEEK_SET)
        try:
            msvcrt.locking(handle, msvcrt.LK_NBLCK, 1)
        except OSError as exc:
            raise GuardError("STATE_BUSY", busy) from exc
    else:
        raise GuardError("UNSUPPORTED_PLATFORM", "This platform has neither fcntl nor msvcrt file locks; the state file "
                                                 "cannot be written safely")


def os_unlock(handle):
    if fcntl is None and msvcrt is not None:
        try:
            os.lseek(handle, 0, os.SEEK_SET)
            msvcrt.locking(handle, msvcrt.LK_UNLCK, 1)
        except OSError:
            pass  # closing the handle releases the lock as well


def save_state(path, state):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(state, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def load_state(path):
    state = read_json(path)
    need(isinstance(state, dict) and STATE_FIELDS <= state.keys(), "Incomplete state")
    budget = state["budgets"]
    need(integer(budget.get("max_revisions")) and integer(budget.get("revisions_used")), "Invalid revision budget")
    need(budget["revisions_used"] <= budget["max_revisions"], "Revision budget exceeded")
    return state


def artifact(path, base, role, content=None, snapshot=False):
    relative = os.path.relpath(path, base)
    local_path(base, relative)
    content = read_bytes(path) if content is None else content
    entry = {"role": role, "path": relative, "sha256": digest(content)}
    if snapshot:
        entry["snapshot"] = {"encoding": "base64", "data": base64.b64encode(content).decode("ascii")}
    return entry


def frozen_inputs(state):
    return [a for a in state["artifacts"] if a["role"] in {"spec", "source"} and "superseded_by" not in a]


def input_identity(inputs):
    return [{key: entry[key] for key in ("role", "path", "sha256")} for entry in inputs]


def verify_inputs(base, inputs):
    for entry in inputs:
        need(digest(read_bytes(local_path(base, entry["path"]))) == entry["sha256"],
             "Frozen input changed: " + entry["path"], "INPUT_CHANGED")


def prepare_inputs(path, spec_path):
    content = read_bytes(spec_path)
    spec = load_spec(spec_path, content)
    need(spec.get("mode", "light") != "strict" or bool(spec["checks"]),
         "strict mode requires at least one declared check; an empty list would only prove nothing ran")
    need(path != local_path(spec_path.parent, spec["candidate"]), "State and candidate must use different files")
    inputs = [artifact(spec_path, path.parent, "spec", content, snapshot=True)]
    sources = source_names(spec, spec_path.parent)
    inputs.extend(artifact(local_path(spec_path.parent, name), path.parent, "source", snapshot=True) for name in sources)
    need(all(local_path(path.parent, entry["path"]) != path for entry in inputs), "State and frozen inputs must use different files")
    verify_inputs(path.parent, inputs)
    return inputs


def start(path, task_id, spec_path, max_revisions=3, max_seconds=None):
    path, spec_path = Path(path).resolve(), Path(spec_path).resolve()
    need(isinstance(task_id, str) and bool(task_id.strip()), "task_id is required")
    need(integer(max_revisions), "max_revisions must be nonnegative")
    need(max_seconds is None or (type(max_seconds) in (int, float) and math.isfinite(max_seconds) and max_seconds > 0), "max_seconds must be finite and positive")
    spec = load_spec(spec_path)
    need(spec.get("mode", "light") != "strict" or bool(spec["checks"]),
         "strict mode requires at least one declared check; an empty list would only prove nothing ran")
    with locked(path):
        inputs = prepare_inputs(path, spec_path)
        if path.exists():
            state = load_state(path)
            frozen = frozen_inputs(state)
            need(state["task_id"] == task_id and state["budgets"]["max_revisions"] == max_revisions
                 and state["budgets"]["max_seconds"] == max_seconds and input_identity(frozen) == input_identity(inputs),
                 "Existing task cannot be reset or replaced", "STATE_CONFLICT")
            return state
        state = {"task_id": task_id, "current_node": "draft", "completed_nodes": [],
                 "artifacts": inputs, "decisions": [], "evidence": [],
                 "budgets": {"max_revisions": max_revisions, "revisions_used": 0,
                             "max_seconds": max_seconds, "started_at": time.time()},
                 "retry_counts": {"repair": 0}, "human_approvals": [], "events": {},
                 "governance": governance_snapshot()}
        save_state(path, state)
        return state


def expired(state):
    budget = state["budgets"]
    return budget["max_seconds"] is not None and time.time() - budget["started_at"] >= budget["max_seconds"]


def repeated(state, event_id, signature):
    need(isinstance(event_id, str) and bool(event_id.strip()), "event_id is required")
    if event_id in state["events"]:
        need(state["events"][event_id] == signature, "Event id was reused with different content", "EVENT_CONFLICT")
        return True
    return False


def reserve(path, event_id):
    path = Path(path).resolve()
    signature = fingerprint({"action": "reserve"})
    with locked(path):
        state = load_state(path)
        if repeated(state, event_id, signature):
            return state
        budget = state["budgets"]
        need(not expired(state) and budget["revisions_used"] < budget["max_revisions"], "Revision or time budget exhausted", "BUDGET_EXHAUSTED")
        editorial = compute_gate(state, path.parent)["editorial"] if state["current_node"] == "complete" else None
        stale_complete = editorial == "STALE"
        if stale_complete:
            verify_inputs(path.parent, frozen_inputs(state))
        if not (state["current_node"] == "repair" or stale_complete):
            raise GuardError("INVALID_ROUTE", route_help("reserve", state, path.parent, editorial))
        budget["revisions_used"] += 1
        state["retry_counts"]["repair"] += 1
        state["current_node"] = "draft"
        state["events"][event_id] = signature
        state["decisions"].append({"event_id": event_id, "route": "draft", "reason":
                                  "Reserved one recheck after a stale completed review" if stale_complete else "Reserved one repair before editing"})
        save_state(path, state)
        return state


def route_help(command, state, base, editorial=None):
    """Why `command` does not fit the current node, and the way that does (r5.39, the author's 10-24 list, point 5).

    The routes are unchanged. The old messages ("reserve repair first"; "Reserve only after a review requests repair,
    or after a completed review becomes stale") did not show the way out of a completed run whose unchanged bytes the
    author wants reviewed again, though replan accepts a completed run."""
    node = state["current_node"]
    if node == "complete" and editorial is None:
        try:
            editorial = compute_gate(state, base)["editorial"]
        except (GuardError, OSError, ValueError, KeyError, TypeError):
            editorial = "unreadable"
    if node == "complete" and editorial == "STALE":
        return ("This run is complete but its review is STALE (the text, the claims, a source or a checking tool changed "
                "since): reserve one recheck (one revision of the budget), then record. If the specification or a frozen "
                "source changed, record the author's decision with replan first.")
    if node == "complete":
        return ("This run is complete and its review (%s) still holds for these bytes; reserve reopens a run only after "
                "a review asks for repair or after the completed review becomes STALE, and record takes a review only "
                "after reserve. To review the same text again because the author asked for it (for example a problem "
                "found after the PASS, the text unchanged): write the author's decision (author_decision, source, "
                "affected_scope) to a JSON file, then replan, reserve, record. The earlier review stays in the history, "
                "the revision budget is not reset and replan cannot loosen the review policy. Do not edit unrelated text "
                "to make the review STALE, and do not start a new run or edit the state file (execution.md, "
                "“同一正文再审”)." % editorial)
    if node == "repair":
        return ("The last review asked for repair: reserve first (one revision of the budget), then edit the candidate and "
                "record the new review.")
    if node == "draft":
        return ("This run is waiting for a review (node draft: the first draft, or a revision already reserved): edit the "
                "candidate if needed, then record; reserve only after a review asks for repair.")
    if node == "blocked":
        return ("The last review was FAIL (a decision or context is missing): record the author's decision "
                "(author_decision, source, affected_scope) with replan first; replan routes to repair, then reserve, "
                "then record.")
    if node == "stopped":
        reason = next((d.get("reason") for d in reversed(state["decisions"]) if d.get("route") == "stopped"), None)
        return ("This run is stopped%s and cannot be reopened: hand over the best version and the open problems "
                "(execution.md, “失败先分类”). Do not start a new run or edit the state file to get around the budget."
                % (" (%s)" % reason if reason else ""))
    return "%s does not fit the current node %r" % (command, node)


def replan(path, event_id, spec_path, decision_path):
    path, spec_path = Path(path).resolve(), Path(spec_path).resolve()
    decision = read_json(decision_path)
    need(isinstance(decision, dict), "Author decision must be an object")
    for field in ("author_decision", "source", "affected_scope"):
        need(isinstance(decision.get(field), str) and bool(decision[field].strip()),
             "Author decision requires nonempty " + field)
    with locked(path):
        state = load_state(path)
        inputs = prepare_inputs(path, spec_path)
        signature = fingerprint({"action": "replan", "inputs": input_identity(inputs), "decision": decision})
        if repeated(state, event_id, signature):
            return state
        budget = state["budgets"]
        need(not expired(state) and budget["revisions_used"] < budget["max_revisions"],
             "Revision or time budget exhausted; replan cannot reset it", "BUDGET_EXHAUSTED")
        need(state["current_node"] in {"draft", "repair", "blocked", "complete"},
             "Stopped tasks cannot be replanned", "INVALID_ROUTE")
        previous_node = state["current_node"]
        prior = frozen_inputs(state)
        # Within one run the review policy may only get stricter (audit 2026-10-16): a replan from strict to
        # light, or to fewer evidence quotes, used to pass silently. A lighter review starts a new run instead.
        old_spec = next((a for a in prior if a["role"] == "spec" and "snapshot" in a), None)
        if old_spec is not None:
            new_spec = next(a for a in inputs if a["role"] == "spec")
            loosened = loosened_policy(policy(snapshot_json(old_spec)), policy(snapshot_json(new_spec)))
            need(not loosened, "replan cannot loosen the review policy (" + "; ".join(loosened) + "); if the author "
                 "wants a lighter review, start a new run with its own state file so the record shows it from the start")
        for entry in prior:
            entry["superseded_by"] = event_id
            if "snapshot" not in entry:
                # Old state files stored only hashes. Recover bytes only if they
                # still match; never label current changed bytes as the original.
                try:
                    old_content = read_bytes(local_path(path.parent, entry["path"]))
                except GuardError as exc:
                    if exc.code != "MISSING_REQUIRED_SOURCE":
                        raise
                    old_content = None
                if old_content is not None and digest(old_content) == entry["sha256"]:
                    entry["snapshot"] = {"encoding": "base64", "data": base64.b64encode(old_content).decode("ascii")}
                else:
                    entry["snapshot_unavailable"] = "Legacy state retained only a hash; original bytes are unavailable"
        for entry in inputs:
            entry["frozen_by"] = event_id
        state["artifacts"].extend(inputs)
        state["human_approvals"].append({"event_id": event_id, "action": "replan", "decision": decision})
        state["decisions"].append({"event_id": event_id, "route": "repair", "previous_node": previous_node,
                                   "reason": "Author decision recorded; inputs refrozen; reserve a repair before editing",
                                   "author_decision": decision, "superseded_inputs": input_identity(prior),
                                   "new_inputs": input_identity(inputs)})
        state["current_node"] = "repair"
        state["events"][event_id] = signature
        save_state(path, state)
        return state


def snapshot_json(entry):
    return json.loads(base64.b64decode(entry["snapshot"]["data"]).decode("utf-8"))


def loosened_policy(old, new):
    found = []
    if old["mode"] == "strict" and new["mode"] != "strict":
        found.append("mode strict -> " + new["mode"])
    if new["min_evidence"] < old["min_evidence"]:
        found.append("min_evidence %d -> %d" % (old["min_evidence"], new["min_evidence"]))
    if old["spread"] and not new["spread"]:
        found.append("spread on -> off")
    if old["require_independent"] and not new["require_independent"]:
        found.append("require_independent on -> off")
    if old.get("dimensions") and not new.get("dimensions"):
        found.append("dimensions on -> off")
    return found


def nonempty(value):
    return isinstance(value, str) and bool(value.strip())


def validate_review_shape(review):
    need(isinstance(review, dict), "Review must be an object")
    need(review.get("schema") == REVIEW_SCHEMA,
         "Review must declare schema editorial-review/2 with candidate_sha256, reviewer, evidence and counter_evidence; "
         "legacy reviews that are not bound to a candidate version are refused", "REVIEW_INCOMPLETE")
    verdict = review.get("verdict")
    need(verdict in {"PASS", "NEEDS_REVISION", "FAIL"}, "Invalid editorial verdict")
    value = review.get("candidate_sha256")
    need(isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value.lower()),
         "candidate_sha256 must name the exact bytes that were reviewed", "REVIEW_INCOMPLETE")
    reviewer = review.get("reviewer")
    need(isinstance(reviewer, dict) and reviewer.get("mode") in REVIEWER_MODES and nonempty(reviewer.get("label")),
         "reviewer needs mode self_check / independent_agent / human_editor and a label", "REVIEW_INCOMPLETE")
    need(isinstance(review.get("checked_against"), list) and bool(review["checked_against"])
         and all(nonempty(x) for x in review["checked_against"]), "checked_against must name actual references")
    issues = review.get("issues")
    need(isinstance(issues, list) and all(isinstance(x, dict) for x in issues), "issues must be a list of objects")
    for issue in issues:
        need(nonempty(issue.get("expected")) and nonempty(issue.get("impact")),
             "each issue needs expected and impact", "REVIEW_INCOMPLETE")
        need(verdict == "FAIL" or nonempty(issue.get("quote")),
             "each issue needs a quote from the reviewed text (FAIL for missing material may omit it)", "REVIEW_INCOMPLETE")
    need(verdict != "PASS" or not issues, "PASS cannot retain unresolved issues")
    need(verdict == "PASS" or bool(issues), "A non-PASS review must identify a concrete issue")
    evidence = review.get("evidence", [])
    need(isinstance(evidence, list) and all(isinstance(x, dict) and nonempty(x.get("quote")) for x in evidence),
         "evidence must be a list of {quote, in}", "REVIEW_INCOMPLETE")
    need(all(len("".join(x["quote"].split())) >= 6 for x in evidence),
         "evidence quotes need at least six non-space characters", "REVIEW_INCOMPLETE")
    need(len({x["quote"] for x in evidence}) == len(evidence),
         "Evidence quotes must be distinct; duplicated text does not demonstrate coverage", "REVIEW_INCOMPLETE")
    dispositions = review.get("machine_dispositions", [])
    need(isinstance(dispositions, list) and all(isinstance(x, dict) and nonempty(x.get("id"))
                                                and x.get("decision") in {"keep", "issue"} and nonempty(x.get("reason"))
                                                for x in dispositions),
         "machine_dispositions entries need id, decision keep/issue and reason", "REVIEW_INCOMPLETE")
    need(len({x["id"] for x in dispositions}) == len(dispositions),
         "Each machine finding needs exactly one disposition", "REVIEW_INCOMPLETE")
    need(all(len("".join(x["reason"].split())) >= 6 for x in dispositions),
         "each machine disposition needs a reason of at least six non-space characters", "REVIEW_INCOMPLETE")
    need(isinstance(review.get("inputs_read", []), list) and all(nonempty(x) for x in review.get("inputs_read", [])),
         "inputs_read must list file paths", "REVIEW_INCOMPLETE")
    need(verdict == "FAIL" or nonempty(review.get("counter_evidence")),
         "counter_evidence must say which other explanations were checked", "REVIEW_INCOMPLETE")
    unfilled = template_fields(review)
    need(not unfilled, "These fields still hold the template's \"%s……\" text, so they were never filled in: %s. Write what "
         "was actually read and decided there (r5.48)" % (TEMPLATE_MARK, ", ".join(unfilled[:8])), "REVIEW_INCOMPLETE")
    reasons = [("machine_dispositions[%d]" % k, x["reason"]) for k, x in enumerate(dispositions) if x["decision"] == "keep"]
    reasons += [("expression.decisions[%d]" % k, x.get("reason", "")) for k, x in
                enumerate((review.get("expression") or {}).get("decisions") or [])
                if isinstance(x, dict) and x.get("decision") == "keep" and isinstance(x.get("reason"), str)]
    generic = [where for where, reason in reasons if GENERIC_REASON.match("".join(reason.split()))]
    need(not generic, "A keep reason names only the kind of effect (余韵, 收束, 作者的口吻, 无需修改 ...), not what this place "
         "does: %s. Say what is lost if the words go, quoting what they carry (prose-audit.md \"三步处理\"; r5.48)"
         % ", ".join(generic[:8]), "REVIEW_INCOMPLETE")
    seen = {}
    for where, reason in reasons:
        seen.setdefault("".join(reason.split()), []).append(where)
    copied = [places for places in seen.values() if len(places) > 1]
    need(not copied, "The same keep reason is copied to several places (%s): each kept hit or sentence needs a reason of "
         "its own, saying what that one does (r5.48)" % "; ".join(", ".join(x) for x in copied[:4]), "REVIEW_INCOMPLETE")
    if "dimensions" in review:
        validate_dimensions_shape(review["dimensions"], verdict)
    if "expression" in review:
        validate_expression_shape(review["expression"])
    if "scenes" in review:
        validate_scenes_shape(review["scenes"], verdict)


def template_fields(value, path="review"):
    """Paths of string fields that still start with the template's 替换为 (r5.48)."""
    if isinstance(value, str):
        return [path] if value.strip().startswith(TEMPLATE_MARK) else []
    if isinstance(value, dict):
        return [p for key, item in value.items() for p in template_fields(item, "%s.%s" % (path, key))]
    if isinstance(value, list):
        return [p for k, item in enumerate(value) for p in template_fields(item, "%s[%d]" % (path, k))]
    return []


def quotes_from(note, piece):
    """True when the note repeats at least NOTE_QUOTE_MIN characters of the piece, two of them Han (r5.48)."""
    note, piece = "".join(note.split()), "".join(piece.split())
    for k in range(len(note) - NOTE_QUOTE_MIN + 1):
        chunk = note[k:k + NOTE_QUOTE_MIN]
        if sum("\u4e00" <= ch <= "\u9fff" for ch in chunk) >= 2 and chunk in piece:
            return True
    return False


def validate_scenes_shape(entries, verdict):
    """The scene conclusions (r5.32, CON-011): per scene, did it turn, and how far does what is on the page carry it
    (props, the characters' actions and bodily reactions, what they notice and choose; r5.49: not a count).
    Their shape only; whether PASS may keep them is decided in check_scenes, which knows the beat card (NWC-1.5)."""
    need(isinstance(entries, list) and bool(entries) and all(isinstance(x, dict) for x in entries),
         "scenes must be a nonempty list of {id, polarity_shifted, prop_embodiment_score, note}", "REVIEW_INCOMPLETE")
    ids = [x.get("id") for x in entries]
    need(all(nonempty(x) for x in ids) and len(set(ids)) == len(ids), "each scene needs its own nonempty id",
         "REVIEW_INCOMPLETE")
    for entry in entries:
        key = entry["id"]
        need(set(entry) <= REVIEW_SCENE_FIELDS, "%s: unknown field(s) %s; a scene has %s"
             % (key, ", ".join(sorted(set(entry) - REVIEW_SCENE_FIELDS)), ", ".join(sorted(REVIEW_SCENE_FIELDS))),
             "REVIEW_INCOMPLETE")
        need(type(entry.get("polarity_shifted")) is bool, "%s: polarity_shifted must be true or false" % key,
             "REVIEW_INCOMPLETE")
        score = entry.get("prop_embodiment_score")
        need(type(score) is int and 1 <= score <= 5, "%s: prop_embodiment_score must be an integer from 1 to 5" % key,
             "REVIEW_INCOMPLETE")
        need(long_enough(entry.get("note")), "%s: note must say where the scene starts and ends and what carries it "
             "(at least six non-space characters)" % key, "REVIEW_INCOMPLETE")
        evidence = entry.get("evidence", [])
        need(isinstance(evidence, list) and all(isinstance(x, dict) and long_enough(x.get("quote")) for x in evidence),
             "%s: evidence must be a list of {quote, in} with quotes of at least six non-space characters" % key,
             "REVIEW_INCOMPLETE")



def check_scenes(review, report):
    """What a declared beat card requires of the scene conclusions, and that scene evidence exists."""
    cards = [check for check in report.get("checks", []) if check.get("type") == "scene_beats"]
    planned = [scene["id"] for check in cards for scene in check["actual"]["scenes"]
               if scene.get("type") in TURNING_TYPES and scene["id"]]
    entries = review.get("scenes")
    if entries is not None and cards:
        types = {scene["id"]: scene.get("type") for check in cards for scene in check["actual"]["scenes"] if scene["id"]}
        unknown = [x["id"] for x in entries if x["id"] not in types]
        need(not unknown, "scenes names scenes that are not on the beat card: " + ", ".join(unknown), "REVIEW_INCOMPLETE")
        # NWC-1.5: polarity and props are judged for core and action scenes only; what an other scene changed is
        # written into the narrative_function dimension, so it cannot be failed as a flat scene by mistake.
        off_type = ["%s (%s)" % (x["id"], types[x["id"]]) for x in entries if types[x["id"]] not in TURNING_TYPES]
        need(not off_type, "scenes holds the core and action scenes (polarity and props); these are not: %s. What an "
             "other scene changed goes into the narrative_function dimension (CON-011)" % ", ".join(off_type),
             "REVIEW_INCOMPLETE")
    flat = [x["id"] for x in entries or [] if not x["polarity_shifted"]]
    weak = [x["id"] for x in entries or [] if x["prop_embodiment_score"] < 3]
    need(review["verdict"] != "PASS" or not flat, "PASS cannot keep a flat scene (polarity_shifted false, [flat-scene]): "
         "%s; rewrite it so the situation turns, or compress it into a transition (CON-011)" % ", ".join(flat),
         "REVIEW_INCOMPLETE")
    need(review["verdict"] != "PASS" or not weak, "PASS cannot keep a scene scored below 3 for presence on the page (props, the "
         "characters' actions and bodily reactions, what they notice and choose; not a count) "
         "(prop_embodiment_score): %s (CON-011)" % ", ".join(weak), "REVIEW_INCOMPLETE")
    if review["verdict"] == "PASS" and planned:
        done = {x["id"] for x in entries or []}
        missing = [key for key in planned if key not in done]
        need(not missing, "PASS needs a scene conclusion (polarity_shifted, prop_embodiment_score, note) for every core "
             "and action scene on the beat card; missing: " + ", ".join(missing), "REVIEW_INCOMPLETE")


def long_enough(text, size=6):
    return nonempty(text) and len("".join(text.split())) >= size


def validate_expression_shape(block):
    """The expression record: scope, segments with anchors and a note each, located keep / change decisions."""
    need(isinstance(block, dict) and set(block) <= EXPRESSION_FIELDS,
         "expression must be an object with scope, segments and decisions", "REVIEW_INCOMPLETE")
    need(block.get("scope") in EXPRESSION_SCOPES, "expression.scope must be chapter (the whole text) or local (the "
         "scope lines of a task with a scope check, and the line on each side)", "REVIEW_INCOMPLETE")
    segments = block.get("segments")
    need(isinstance(segments, list) and bool(segments)
         and all(isinstance(x, dict) and set(x) <= SEGMENT_FIELDS for x in segments),
         "expression.segments must be a nonempty list of {from, to, note}: the first and last words of each part read, "
         "in order", "REVIEW_INCOMPLETE")
    for number, item in enumerate(segments, 1):
        need(all(long_enough(item.get(key), ANCHOR_MIN) for key in ("from", "to")),
             "expression segment %d: from and to must quote at least %d characters where the segment starts and ends"
             % (number, ANCHOR_MIN), "REVIEW_INCOMPLETE")
        need(long_enough(item.get("note")), "expression segment %d: note must say what was checked there and what was "
             "kept or changed (at least six non-space characters)" % number, "REVIEW_INCOMPLETE")
    notes = ["".join(item["note"].split()) for item in segments]
    need(len(set(notes)) == len(notes), "Each segment needs its own note; one note copied to several segments does not "
         "show what was read in each", "REVIEW_INCOMPLETE")
    decisions = block.get("decisions", [])
    need(isinstance(decisions, list) and all(isinstance(x, dict) and set(x) <= DECISION_FIELDS for x in decisions),
         "expression.decisions must be a list of {decision, quote | before/after, judgment, reason}", "REVIEW_INCOMPLETE")
    for number, item in enumerate(decisions, 1):
        kind = item.get("decision")
        need(kind in ("keep", "change"), "expression decision %d: decision must be keep or change" % number,
             "REVIEW_INCOMPLETE")
        need(long_enough(item.get("judgment")) and long_enough(item.get("reason")),
             "expression decision %d: judgment (what the words do in context) and reason (why kept or changed) need at "
             "least six non-space characters each" % number, "REVIEW_INCOMPLETE")
        if kind == "keep":
            need(long_enough(item.get("quote")) and "before" not in item and "after" not in item,
                 "expression decision %d: keep quotes the kept words (at least six non-space characters) in quote"
                 % number, "REVIEW_INCOMPLETE")
        else:
            need(long_enough(item.get("before")) and isinstance(item.get("after"), str) and "quote" not in item,
                 "expression decision %d: change gives before (the old words, at least six non-space characters) and "
                 "after (the new words, or \"\" when they were deleted)" % number, "REVIEW_INCOMPLETE")
        need("offset" not in item or integer(item["offset"]), "expression decision %d: offset must be a character "
             "position" % number, "REVIEW_INCOMPLETE")


def validate_dimensions_shape(entries, verdict):
    """The six-dimension conclusions: all six or none, one each, a legal status and a note; the tool never fills any in."""
    allowed = ", ".join(DIMENSION_NAMES)
    need(isinstance(entries, list) and all(isinstance(x, dict) for x in entries),
         "dimensions must be a list of {id, status, note, evidence} objects, one per dimension: " + allowed,
         "REVIEW_INCOMPLETE")
    ids = [x.get("id") for x in entries]
    unknown = [str(x) for x in ids if not isinstance(x, str) or x not in DIMENSION_NAMES]
    need(not unknown, "Unknown dimension id: %s; the six ids are %s" % (", ".join(unknown), allowed), "REVIEW_INCOMPLETE")
    repeated = sorted({x for x in ids if ids.count(x) > 1})
    need(not repeated, "Each dimension takes exactly one conclusion; repeated: " + ", ".join(repeated), "REVIEW_INCOMPLETE")
    missing = [key for key in DIMENSION_NAMES if key not in ids]
    need(not missing, "A dimensions block covers all six dimensions (write not_reviewed for any you did not read, "
         "never leave one out); missing: " + ", ".join(missing), "REVIEW_INCOMPLETE")
    for entry in entries:
        key, status = entry["id"], entry.get("status")
        need(set(entry) <= DIMENSION_FIELDS, "%s: unknown field(s) %s; a dimension has %s"
             % (key, ", ".join(sorted(set(entry) - DIMENSION_FIELDS)), ", ".join(sorted(DIMENSION_FIELDS))),
             "REVIEW_INCOMPLETE")
        need(status in DIMENSION_STATUSES, "%s: status must be met, issue, not_reviewed or not_applicable" % key,
             "REVIEW_INCOMPLETE")
        need(long_enough(entry.get("note")), "%s: note must say what was checked, what is wrong, or why it was not read "
             "(at least six non-space characters)" % key, "REVIEW_INCOMPLETE")
        evidence = entry.get("evidence", [])
        need(isinstance(evidence, list) and all(isinstance(x, dict) and long_enough(x.get("quote")) for x in evidence),
             "%s: evidence must be a list of {quote, in} with quotes of at least six non-space characters" % key,
             "REVIEW_INCOMPLETE")
        need("where" not in entry or nonempty(entry["where"]), "%s: where must be a nonempty location" % key,
             "REVIEW_INCOMPLETE")
        if status == "issue":
            need(bool(evidence), "%s: an issue needs at least one quote from the text" % key, "REVIEW_INCOMPLETE")
        if status == "not_applicable":
            need(key in MAY_NOT_APPLY, "%s applies to every chapter and cannot be not_applicable; write met, issue or "
                 "not_reviewed" % key, "REVIEW_INCOMPLETE")
    flagged = [x["id"] for x in entries if x["status"] == "issue"]
    need(verdict != "PASS" or not flagged, "PASS cannot keep a dimension marked issue: " + ", ".join(flagged),
         "REVIEW_INCOMPLETE")


def check_dimensions(review, report):
    """What the declared policy and checks require of the dimension conclusions."""
    rules = report["review_policy"]
    entries = review.get("dimensions")
    if entries is None:
        need(not rules.get("dimensions"), "This review policy (%s mode) needs the six-dimension conclusions: add "
             "dimensions with %s, each met / issue / not_reviewed / not_applicable with a note"
             % (rules.get("mode"), ", ".join(DIMENSION_NAMES)), "REVIEW_INCOMPLETE")
        return
    declared = {check["type"] for check in report["checks"]}
    for entry in entries:
        if entry["status"] == "not_applicable":
            applies = [kind for kind in MAY_NOT_APPLY[entry["id"]] if kind in declared]
            need(not applies, "%s cannot be not_applicable: this task declares a %s check"
                 % (entry["id"], "/".join(applies)), "REVIEW_INCOMPLETE")
    if review["verdict"] == "PASS" and rules.get("mode") == "strict":
        unread = ["%s（%s）" % (x["id"], DIMENSION_NAMES[x["id"]]) for x in entries if x["status"] == "not_reviewed"]
        need(not unread, "strict mode cannot record PASS while a dimension was not reviewed: %s. Review it; continuity "
             "and revision_comparison may instead be not_applicable with the reason, when the task has no earlier "
             "chapter or no earlier version" % ", ".join(unread), "REVIEW_INCOMPLETE")


def line_starts(text):
    starts, position = [], 0
    for line in text.splitlines(keepends=True):
        starts.append(position)
        position += len(line)
    starts.append(position)
    return starts


def occurrences(text, quote):
    places, position = [], text.find(quote)
    while position >= 0:
        places.append(position)
        position = text.find(quote, position + 1)
    return places


def locate_once(text, quote, offset, what):
    """Where a decision's words stand in the candidate: exactly one place, or the given offset."""
    if offset is not None:
        need(text.startswith(quote, offset), what + ": offset does not match its words", "EVIDENCE_NOT_FOUND")
        return offset
    position = text.find(quote)
    need(position >= 0, what + " not found in the candidate: " + quote[:40], "EVIDENCE_NOT_FOUND")
    need(text.find(quote, position + 1) < 0, what + " occurs more than once in the candidate; quote more of the "
         "sentence or give its offset: " + quote[:40], "REVIEW_INCOMPLETE")
    return position


def earlier_versions(state, base, current_sha):
    """Texts this candidate came from: the frozen sources and the candidates recorded before (r5.11 keeps their
    bytes). A change decision's old words must stand in one of them."""
    texts = []
    for entry in frozen_inputs(state):
        if entry["role"] == "source":
            try:
                texts.append(as_text(read_bytes(local_path(base, entry["path"]))))
            except (GuardError, UnicodeDecodeError):
                pass
    for entry in state["artifacts"]:
        if entry["role"] == "candidate" and entry["sha256"] != current_sha and "snapshot" in entry:
            texts.append(as_text(base64.b64decode(entry["snapshot"]["data"])))
    return texts


def previous_candidate(state, current_sha):
    """(event id, text) of the last recorded candidate with other bytes, when its bytes were kept; else None."""
    for evidence in reversed(state["evidence"]):
        sha = evidence["machine"]["candidate"]["sha256"]
        if sha == current_sha:
            continue
        for entry in state["artifacts"]:
            if entry["role"] == "candidate" and entry["sha256"] == sha and "snapshot" in entry:
                return evidence["event_id"], as_text(base64.b64decode(entry["snapshot"]["data"]))
        return None
    return None


def verify_expression(review, report, text, state, base):
    """The expression record of a review: anchors, scope, coverage and decisions. Returns the summary kept in the state.

    The record is checked for form only: complete, matching the agreed scope, locatable, bound to these bytes. Nothing
    here judges whether a kept sentence works or a deleted one was redundant."""
    block = review["expression"]
    rules = report["review_policy"]
    passing = review["verdict"] == "PASS"
    current = report["candidate"]["sha256"]
    starts = line_starts(text)
    spans, position = [], 0
    for number, item in enumerate(block["segments"], 1):
        start = text.find(item["from"], position)
        need(start >= 0, "expression segment %d: the start %r is not in the candidate after the previous segment"
             % (number, item["from"][:20]), "EVIDENCE_NOT_FOUND")
        end = text.find(item["to"], start)
        need(end >= 0, "expression segment %d: the end %r is not in the candidate after its start"
             % (number, item["to"][:20]), "EVIDENCE_NOT_FOUND")
        end += len(item["to"])
        piece = text[start:end]
        size = sum(not char.isspace() for char in piece)
        need(size <= SEGMENT_MAX or "\n" not in piece.strip(),
             "expression segment %d covers %d characters across several paragraphs: one note for that much text is a "
             "blanket claim. Split it where the paragraphs change (at most %d non-space characters per segment, or "
             "a single paragraph)" % (number, size, SEGMENT_MAX), "REVIEW_INCOMPLETE")
        spans.append((start, end))
        position = end
    scope_lines = sorted({n for check in report["checks"] if check["type"] == "scope" for n in check.get("scope_lines", [])})
    has_scope = any(check["type"] == "scope" for check in report["checks"])
    need(block["scope"] == "chapter" or has_scope,
         "expression.scope local needs a scope check in the spec (the authorised lines); a whole-chapter task records "
         "scope chapter and covers the whole text", "REVIEW_INCOMPLETE")
    covered = [False] * len(text)
    for start, end in spans:
        covered[start:end] = [True] * (end - start)

    def uncovered(lines):
        return [n for n in lines if any(not text[k].isspace() and not covered[k] for k in range(starts[n - 1], starts[n]))]

    total = len(starts) - 1
    title, title_line = chapter_title(text)
    body = [n for n in range(1, total + 1) if not (title and n == title_line) and text[starts[n - 1]:starts[n]].strip()]
    complete = not uncovered(body)
    required = []
    if block["scope"] == "local":
        wanted = set(scope_lines)
        runs = []
        for n in scope_lines:
            if runs and n == runs[-1][1] + 1:
                runs[-1][1] = n
            else:
                runs.append([n, n])
        for first, last in runs:  # the transition: the nearest nonblank line on each side
            before = [n for n in body if n < first]
            after = [n for n in body if n > last]
            wanted.update(([before[-1]] if before else []) + ([after[0]] if after else []))
        required = sorted(n for n in wanted if n in body)
    else:
        required = body
    if passing and rules.get("mode") == "strict":
        missing = uncovered(required)
        # A line too short for an anchor of its own (a title such as 楔子, a one-word line) is covered by an anchor
        # that runs across the line break (r5.13: the refusal did not say how).
        short = [n for n in missing if count_chars(text[starts[n - 1]:starts[n]], "non_whitespace") < ANCHOR_MIN]
        hint = ("" if not short else ". Line(s) %s have fewer than %d characters: let the anchor of the segment that "
                "starts or ends there run across the line break, e.g. \"from\": \"楔子\\n\\n雨停了\" (only a first "
                "line that starts with 第N章 or # is a title the record may leave out)"
                % (", ".join(map(str, short[:12])), ANCHOR_MIN))
        need(not missing, "PASS needs the expression record to cover %s; not covered: candidate line(s) %s. Read "
             "them and add the segments (an interrupted or sampled pass is not coverage)%s"
             % ("the whole text" if block["scope"] == "chapter" else "the scope lines and the line on each side",
                ", ".join(map(str, missing[:12])), hint), "REVIEW_INCOMPLETE")
    located, counts, sources = [], {"keep": 0, "change": 0}, None
    new_words = {}  # decision number -> (start, end) of the new words of a change, where they stand in the candidate
    for number, item in enumerate(block.get("decisions", []), 1):
        what = "expression decision %d" % number
        counts[item["decision"]] += 1
        offset = item.get("offset")
        if item["decision"] == "keep":
            start = locate_once(text, item["quote"], offset, what)
            located.append((start, start + len(item["quote"])))
            continue
        before, after = item["before"], item["after"]
        rest = text.replace(after, "\0") if after else text
        need(before not in rest, "%s says %r was changed, but those words are still in the candidate: the change was "
             "not made (or quote more of the old sentence)" % (what, before[:40]), "CHANGE_NOT_APPLIED")
        if sources is None:
            sources = earlier_versions(state, base, current)
        need(any(before in source for source in sources), "%s: the old words %r are in no earlier version on record "
             "(frozen sources or recorded candidates)" % (what, before[:40]), "EVIDENCE_NOT_FOUND")
        if after:
            start = locate_once(text, after, offset, what + " (after)")
            located.append((start, start + len(after)))
            new_words[number] = (start, start + len(after))
    if passing and rules.get("mode") == "strict":
        # r5.48: a zero-change segment (no keep, no change inside it) still shows where the reader looked.
        for number, ((start, end), item) in enumerate(zip(spans, block["segments"]), 1):
            if any(a < end and start < b for a, b in located):
                continue
            need(quotes_from(item["note"], text[start:end]),
                 "expression segment %d has no keep or change in it, and its note quotes nothing from it. Leaving a "
                 "part unchanged is fine; say what was weighed there and why it stays, quoting at least %d characters "
                 "of that part (\"全段逐句读过，无需修改\" does not show this part was read). The program checks only "
                 "that the quote is there, not that the judgment is right (r5.48)" % (number, NOTE_QUOTE_MIN),
                 "REVIEW_INCOMPLETE")
    if passing:
        # An issue an earlier review raised: gone from the text, or kept by a decision of this review.
        for evidence in state["evidence"]:
            for issue in evidence.get("editorial", {}).get("issues", []):
                quote = issue.get("quote")
                if not nonempty(quote) or issue.get("in", "candidate") != "candidate" or quote not in text:
                    continue
                kept = any(start < p + len(quote) and p < end for p in occurrences(text, quote) for start, end in located)
                need(kept, "An issue raised at %s is still in the text and no decision keeps it: %s. Change it, or "
                     "keep it with a decision that says why" % (evidence["event_id"], quote[:40]), "ISSUE_UNRESOLVED")
        previous = previous_candidate(state, current)
        if previous is not None:
            event, old = previous
            new_lines = text.splitlines(keepends=True)

            def sentences(block):
                """The block in sentences, each with its start: a sentence ends after 。！？!? (with the closing marks
                right after it), after an ellipsis or dash that a closing mark follows (r5.23), or at a line break."""
                parts, start, k = [], 0, 0
                while k < len(block):
                    k += 1
                    end = block[k - 1] in SENTENCE_ENDS
                    if block[k - 1] in TRAILING_ENDS:
                        j = k
                        while j < len(block) and block[j] in TRAILING_ENDS:
                            j += 1
                        if j < len(block) and block[j] in SENTENCE_TAIL:
                            k, end = j, True
                    if end:
                        while k < len(block) and block[k] in SENTENCE_TAIL:
                            k += 1
                    elif block[k - 1] != "\n" and k < len(block):
                        continue
                    parts.append((start, block[start:k]))
                    start = k
                return parts

            def edit(source):
                """The edit from source to the candidate, character by character: the pieces (kind, source start,
                source end, candidate start, candidate end) in order, and the separate changes among them. Lines first
                (r5.16); then the sentences inside each changed block, so that the diff does not join a change in one
                sentence with a change in the next (r5.22); then the characters inside each changed run of sentences."""
                source_starts, source_lines = line_starts(source), source.splitlines(keepends=True)
                pieces, hunks = [], []
                for op, i, j, a, b in SequenceMatcher(None, source_lines, new_lines, autojunk=False).get_opcodes():
                    if op == "equal":
                        pieces.append(("equal", source_starts[i], source_starts[j], starts[a], starts[b]))
                        continue
                    # The characters that changed, not just their paragraph: a decision carried over from the old
                    # review that merely sits in the same paragraph does not show the change was read again.
                    was, now = sentences("".join(source_lines[i:j])), sentences("".join(new_lines[a:b]))
                    was_end, now_end = source_starts[j] - source_starts[i], starts[b] - starts[a]
                    for op2, i2, j2, a2, b2 in SequenceMatcher(None, [s for _, s in was], [s for _, s in now],
                                                               autojunk=False).get_opcodes():
                        x0 = source_starts[i] + (was[i2][0] if i2 < len(was) else was_end)
                        y0 = starts[a] + (now[a2][0] if a2 < len(now) else now_end)
                        old_run, new_run = "".join(s for _, s in was[i2:j2]), "".join(s for _, s in now[a2:b2])
                        if op2 == "equal":
                            pieces.append(("equal", x0, x0 + len(old_run), y0, y0 + len(new_run)))
                            continue
                        for kind, x1, x2, y1, y2 in SequenceMatcher(None, old_run, new_run, autojunk=False).get_opcodes():
                            piece = (kind, x0 + x1, x0 + x2, y0 + y1, y0 + y2)
                            # Each separate change on its own (r5.16): a decision for one change does not show that
                            # a second change in the same line or block was read again.
                            if kind != "equal" and (old_run[x1:x2] + new_run[y1:y2]).strip():
                                hunks.append(piece[1:])
                            pieces.append(piece)
                return pieces, hunks

            pieces, _ = edit(old)

            def to_old(position, end=False):
                """Where a candidate position stood in the old version (inside a change: its start, or its end)."""
                for kind, oa, ob, na, nb in pieces:
                    if (na < position <= nb) if end else (na <= position < nb):
                        return oa + (position - na) if kind == "equal" else (ob if end else oa)
                return len(old) if end else 0

            def solid(start, end, source):
                """The span without the whitespace at its ends."""
                while start < end and source[start].isspace():
                    start += 1
                while end > start and source[end - 1].isspace():
                    end -= 1
                return start, end

            def same_text(places, before, after):
                """The decision done at any of these places gives the same text: they stand in a run of repeats."""
                return len({old[:p] + after + old[p + len(before):] for p in places}) == 1

            def own_edit(before, after):
                """The decision's own edit from its old words to its new ones, as the diff gives it; when that is one
                cut inside words that repeat, also the same cut moved over them, which leaves the same new words."""
                edits = [(i1, i2, after[j1:j2]) for kind, i1, i2, j1, j2
                         in SequenceMatcher(None, before, after, autojunk=False).get_opcodes() if kind != "equal"]
                options = [edits]
                if len(edits) == 1 and not edits[0][2]:
                    i1, i2, _ = edits[0]
                    k = 1
                    while i1 - k >= 0 and before[i1 - k] == before[i2 - k]:
                        options.append([(i1 - k, i2 - k, "")])
                        k += 1
                    k = 1
                    while i2 + k - 1 < len(before) and before[i1 + k - 1] == before[i2 + k - 1]:
                        options.append([(i1 + k, i2 + k, "")])
                        k += 1
                return options

            # Where each candidate character stood in the old version, for the characters the edit kept.
            kept_from = [-1] * len(text)
            for kind, oa, ob, na, nb in pieces:
                if kind == "equal":
                    kept_from[na:nb] = range(oa, ob)
            # Where each decision's old words stood in the old version (r5.22). A cut ("after" empty) names one place:
            # its old words must occur once (r5.20). A change with new words stands where its old words occur once,
            # or, when they occur more than once, where its new words came from: the new words are traced back
            # through the edit, and of the copies of the old words they could have come from, the one whose words
            # agree best with what the edit kept is its place (on a tie the first, and a refusal asks for more
            # context). Places where the decision gives the same text (a run of repeats) are one place.
            applied, quoted, unplaced = [], [], []  # each placed decision's edits, and the old words it quotes
            for number, item in enumerate(block.get("decisions", []), 1):
                if item["decision"] != "change":
                    continue
                before, after = item["before"], item["after"]
                found = occurrences(old, before)
                if len(found) > 1 and same_text(found, before, after):
                    found = found[:1]
                if not after:
                    need(len(found) <= 1, "expression decision %d: the cut words %r occur %d times in the version "
                         "recorded at %s, so they do not say which place was cut; quote the words around the cut that "
                         "stay as before and after (a change of the longer passage), one decision for each place"
                         % (number, before[:40], len(found), event), "REVIEW_INCOMPLETE")
                elif len(found) > 1:
                    start, end = new_words[number]
                    low, high = to_old(start), to_old(end, end=True)
                    found = [p for p in found if p <= high and low <= p + len(before)]
                    if not found:
                        unplaced.append(number)
                        continue
                    pairs = [(i + k, j + k) for i, j, size
                             in SequenceMatcher(None, before, after, autojunk=False).get_matching_blocks()
                             for k in range(size)]
                    agree = {p: sum(kept_from[start + j] == p + i for i, j in pairs) for p in found}
                    found = [p for p in found if agree[p] == max(agree.values())]
                    if len(found) > 1 and not same_text(found, before, after):
                        unplaced.append(number)
                    found = found[:1]
                for place in found:
                    applied.append([[(place + i1, place + i2, words) for i1, i2, words in option]
                                    for option in own_edit(before, after)])
                    quoted.append((place, place + len(before)))

            def clash(one, other):
                (s1, e1, w1), (s2, e2, w2) = one, other
                if s1 == e1 and s2 == e2:
                    return s1 == s2 and w1 == w2
                if s1 == e1 or s2 == e2:
                    point, (start, end) = (s1, (s2, e2)) if s1 == e1 else (s2, (s1, e1))
                    return start < point < end
                return s1 < e2 and s2 < e1

            def done(placed):
                """The old version with these decisions done, and where each edit stands in it. The decisions are
                taken in an order of their own (where their edits stand), not in the order the review lists them, so
                the order of the list never decides the result (r5.23). Edits must not overlap: a decision whose
                edit would fall on words another one already changed takes the same edit moved over repeated words,
                if it can. Failing that, it keeps what it adds, edit by edit: an edit taken already is done once; a
                cut that overlaps other cuts only is one cut over all of them (two decisions that both quote a line
                break they cut, say); an edit that overlaps a different edit is left out (the comparison after shows
                whatever that leaves unexplained). r5.22 dropped the whole decision, so a decision that quoted a
                whole passage lost its other cuts when a shorter decision listed before it held the first."""
                chosen = []
                for options in sorted(placed, key=lambda options: [tuple(option) for option in options]):
                    for option in options:
                        if not any(clash(one, other) for one in option for other in chosen):
                            chosen.extend(option)
                            break
                    else:
                        for edit in options[0]:
                            over = [other for other in chosen if clash(edit, other)]  # an edit taken already clashes
                            if not over:
                                chosen.append(edit)
                            elif edit[0] < edit[1] and not edit[2] and \
                                    all(s < e and not words for s, e, words in over):
                                chosen = [other for other in chosen if other not in over]
                                chosen.append((min(s for s, _, _ in over + [edit]), max(e for _, e, _ in over + [edit]), ""))
                return built(chosen)

            def done_whole():
                """The second try (r5.23): each decision done whole or not at all, the one that quotes the most of
                the old version first (it tells the most of what changed); a decision whose edits would fall on edits
                already done is left out whole."""
                chosen = []
                for k in sorted(range(len(applied)), key=lambda k: (quoted[k][0] - quoted[k][1],
                                                                    [tuple(option) for option in applied[k]])):
                    for option in applied[k]:
                        if not any(clash(one, other) for one in option for other in chosen):
                            chosen.extend(option)
                            break
                return built(chosen)

            def built(chosen):
                """The old version with these edits done, and where each edit's new words stand in it."""
                parts, regions, last, length = [], [], 0, 0
                for start, end, words in sorted(chosen):
                    parts += [old[last:start], words]
                    length += start - last
                    regions.append((length, length + len(words)))
                    length += len(words)
                    last = end
                return "".join(parts) + old[last:], regions

            # Where decisions keep or give words in the candidate, without the blank lines or spaces they may quote at
            # either end (those do not stretch what a decision covers).
            words_at = [solid(s, e, text) for s, e in located]

            def first_uncovered(expected, regions):
                """The first change between the decisions done and the candidate that no decision's words cover."""
                if expected == text:
                    return None
                _, residual = edit(expected)
                for x1, x2, y1, y2 in residual:
                    s1, s2 = solid(x1, x2, expected)
                    words = any(not unicodedata.category(character).startswith(("P", "Z", "C"))
                                for character in expected[s1:s2] + text[y1:y2])
                    if not words and any(a <= s2 and s1 <= b for a, b in regions):
                        # Punctuation only, beside or inside what a decision changed: a diff may shift it to a
                        # neighbour, and a cut may be quoted without its comma.
                        continue
                    # What was taken out (a cut, or the old words of a rewrite) stands at y1 in the candidate: inside
                    # words a decision keeps or gives there. On their edge only when it stays in the same sentence: no
                    # line break and, when it holds words, no more sentence ends (。！？, an ellipsis or dash, a closing
                    # quotation mark or bracket) than the words put in its place. A diff can split one rewrite into an
                    # insertion and a cut at its edge, but a whole sentence, utterance or paragraph beside a decision's
                    # words is a change of its own (r5.22, r5.23; r5.16-r5.21 counted any cut on the edge, r5.22
                    # looked at 。！？ only). The old words of a rewrite count the same way (r5.23): the diff joins a
                    # sentence cut with a rewrite of the first words of the next one into one change on the edge of a
                    # keep of that sentence, and the keep covered both; a sentence rewritten into another keeps its
                    # number of ends.
                    piece = expected[x1:x2]
                    taken = any(not unicodedata.category(character).startswith(("P", "Z", "C")) for character in piece)
                    ends = [len(re.findall("[%s]+" % re.escape(END_MARKS), words)) for words in (piece, text[y1:y2])]
                    same_sentence = "\n" not in piece and not (taken and ends[0] > ends[1])
                    touched = (not piece.strip() or any(s < y1 < e for s, e in words_at) or
                               (same_sentence and any(y1 in (s, e) for s, e in words_at)))
                    if y1 < y2:  # new words: where a decision's words stand in the candidate (as in r5.20)
                        touched = touched and any(s < y2 and y1 < e for s, e in words_at)
                    if not touched:
                        return expected[x1:x2], y1, y2
                return None

            # The change decisions done to the old version, each at its place: what they say was changed (r5.22).
            # What is left between that and the candidate was changed without a change decision for it, and needs
            # words a decision keeps or gives in the candidate around it. So a decision accounts for its own change
            # only: one that cut the sentence on one side of a paragraph that stays does not also account for the
            # same sentence cut on the other side (10-19 review of r5.20, P2-G520-01; r5.20 let a cut count for any
            # change whose old words held the cut text and whose new words stood beside it), and one whose old words
            # keep a sentence does not account for a copy of that sentence cut next door. Two decisions can tell one
            # change two ways (a rewrite and a cut, or a cut and the same words put back further on); done edit by
            # edit, their edits mixed may explain nothing. So when that leaves a change unexplained, the decisions are
            # tried once more, done whole (r5.23). Each try does nothing but the decisions' own edits, each at its
            # place, so a try that explains every change is enough.
            miss = first_uncovered(*done(applied))
            if miss is not None and first_uncovered(*done_whole()) is None:
                miss = None
            if miss is not None:
                was, y1, y2 = miss
                hint = ("" if not unplaced else "; decision(s) %s quote old words that occur more than once in that "
                        "version and could not be tied to one place: quote more of the words around them"
                        % ", ".join(map(str, unplaced)))
                need(False, "Candidate line %d changed since the version recorded at %s (%r became %r); the "
                     "review needs a decision (keep or change) whose words cover that change, so the changed part "
                     "is shown to have been read again; each separate change needs its own. A change decision "
                     "accounts for its own old and new words only; a keep, or the new words of a change, cover what "
                     "changed inside them (on their edge only inside the same sentence)%s"
                     % (text.count("\n", 0, y1) + 1, event, was[:20], text[y1:y2][:20], hint), "REVIEW_INCOMPLETE")
    summary = {"scope": block["scope"], "segments": len(spans), "complete": complete, "decisions": counts}
    if block["scope"] == "local":
        # Nonblank lines, shown as ranges: lines with only blank lines between them belong to one range.
        ranges = []
        for n in required:
            if ranges and all(not text[starts[k - 1]:starts[k]].strip() for k in range(ranges[-1][1] + 1, n)):
                ranges[-1][1] = n
            else:
                ranges.append([n, n])
        summary["required_lines"] = required
        summary["required_ranges"] = ranges
    return summary


def verify_review(review, report, candidate_text, spec_path, inputs, base, state=None):
    """Bind the review to the candidate bytes and verify every quote it relies on."""
    current = report["candidate"]["sha256"]
    need(review["candidate_sha256"].lower() == current,
         "Review was written for candidate %s, but the current candidate is %s; review this version again"
         % (review["candidate_sha256"][:12], current[:12]), "REVIEW_STALE")
    sources = {local_path(base, a["path"]): a for a in inputs if a["role"] == "source"}

    def locate(item):
        where = item.get("in", "candidate")
        if where == "candidate":
            return candidate_text, True
        target = local_path(spec_path.parent, where)
        need(target in sources, "Quote location must be the candidate or a frozen source: " + str(where), "EVIDENCE_NOT_FOUND")
        return as_text(read_bytes(target)), False

    for item in review["issues"]:
        if nonempty(item.get("quote")):
            text, _ = locate(item)
            need(item["quote"] in text, "Issue quote not found in %s: %s" % (item.get("in", "candidate"), item["quote"][:40]),
                 "EVIDENCE_NOT_FOUND")
    for entry in review.get("dimensions") or []:
        for item in entry.get("evidence", []):
            text, _ = locate(item)
            need(item["quote"] in text, "Dimension %s quote not found in %s: %s"
                 % (entry["id"], item.get("in", "candidate"), item["quote"][:40]), "EVIDENCE_NOT_FOUND")
    for entry in review.get("scenes") or []:
        for item in entry.get("evidence", []):
            text, _ = locate(item)
            need(item["quote"] in text, "Scene %s quote not found in %s: %s"
                 % (entry["id"], item.get("in", "candidate"), item["quote"][:40]), "EVIDENCE_NOT_FOUND")
    check_scenes(review, report)
    spans, candidate_quotes = [], set()
    for item in review.get("evidence", []):
        text, is_candidate = locate(item)
        position = text.find(item["quote"])
        need(position >= 0, "Evidence quote not found in %s: %s" % (item.get("in", "candidate"), item["quote"][:40]),
             "EVIDENCE_NOT_FOUND")
        if is_candidate:
            key = "".join(item["quote"].split())
            need(key not in candidate_quotes, "Evidence quotes must be distinct; repeated: " + item["quote"][:40],
                 "REVIEW_INCOMPLETE")
            candidate_quotes.add(key)
            # A repeated refrain has no single location, so it cannot show where the reviewer read.
            # A reviewer can locate one occurrence explicitly with a character offset.
            if "offset" in item:
                position = item["offset"]
                need(integer(position) and text.startswith(item["quote"], position),
                     "Evidence offset does not match its quote", "EVIDENCE_NOT_FOUND")
            if "offset" in item or text.find(item["quote"], position + 1) < 0:
                spans.append((position, position + len(item["quote"])))
    # Overlapping, nested or adjacent fragments of one passage are one location,
    # not several: spans closer than LOCATION_GAP characters are merged.
    clusters = []
    for start, end in sorted(spans):
        if clusters and start < clusters[-1][1] + LOCATION_GAP:
            clusters[-1][1] = max(clusters[-1][1], end)
        else:
            clusters.append([start, end])
    offsets = [start for start, _ in clusters]
    require_unique_ids(report["review_items"])  # never index two findings under one id
    known = {item["id"]: item for item in report["review_items"]}
    decided = {}
    for item in review.get("machine_dispositions", []):
        need(item["id"] in known, "Disposition refers to a finding that this candidate does not have (stale review?): "
             + item["id"], "REVIEW_STALE")
        decided[item["id"]] = item
    expression = None
    if "expression" in review:
        expression = verify_expression(review, report, candidate_text, state or {"evidence": [], "artifacts": []}, base)
    if review["verdict"] != "PASS":
        check_dimensions(review, report)
        return expression
    rules = report["review_policy"]
    unmet = []
    if len(offsets) < rules["min_evidence"]:
        unmet.append("at least %d separate locations quoted from the reviewed candidate: distinct quotes that each occur "
                     "exactly once (or carry a verified offset), do not overlap and lie at least %d characters apart "
                     "(quotes from sources do not count); found %d" % (rules["min_evidence"], LOCATION_GAP, len(offsets)))
    if rules["spread"] and len(candidate_text) >= SPREAD_MIN_CHARS:
        thirds = {min(2, offset * 3 // len(candidate_text)) for offset in offsets}
        if thirds != {0, 1, 2}:
            unmet.append("evidence quotes from the beginning, middle and end of the candidate; "
                         "each must occur exactly once or supply a verified offset")
    need(not unmet, "PASS under this policy needs " + "; and ".join(unmet), "REVIEW_INCOMPLETE")
    if rules.get("mode") == "strict":
        need(report.get("status") != "UNTESTED",
             "strict mode cannot record PASS while a declared check did not run: " + ", ".join(report.get("untested_checks", [])),
             "MECHANICAL_UNTESTED")
        # r5.11 (chapter 5 of the 2026-10-18 maintenance request): six "met" dimensions, quotes that exist and
        # passing fact checks recorded a PASS for a text whose sentence-level expression check was never done.
        # Reusing a text, changing little or passing every fact check does not stand in for it.
        need(expression is not None, "strict mode cannot record PASS without the expression record: add expression "
             "with scope, segments that tile the agreed scope (each with its own note) and located keep / change "
             "decisions (see prose-audit.md); reusing an earlier text or passing the fact checks does not replace "
             "it", "REVIEW_INCOMPLETE")
    if rules["require_independent"]:
        need(review["reviewer"]["mode"] != "self_check",
             "This task requires an independent reviewer; a self-check cannot be recorded as PASS", "REVIEW_INCOMPLETE")
    read = {local_path(spec_path.parent, x) for x in review.get("inputs_read", [])}
    missing = [sources[p]["path"] for p in sources if p not in read]
    need(not missing, "PASS must list every frozen source in inputs_read; not read: " + ", ".join(missing), "REVIEW_INCOMPLETE")
    undecided = [key for key in known if key not in decided]
    need(not undecided, "PASS must decide every machine review item (keep with reason, or issue): " + ", ".join(undecided[:8]),
         "REVIEW_INCOMPLETE")
    need(all(item["decision"] == "keep" for item in decided.values()),
         "A machine item marked as issue means the verdict cannot be PASS", "REVIEW_INCOMPLETE")
    # NWC-1.5 (r5.34): scene-rule hits in the narration are no longer refused as such; like every machine item each one
    # is rewritten, or kept with a reason of its own (the dispositions above), and the reviewer judges the reason.
    check_dimensions(review, report)
    return expression


def record(path, event_id, review_path):
    path, review_path = Path(path).resolve(), Path(review_path).resolve()
    raw_review = read_bytes(review_path)
    review = strict_json(raw_review)
    validate_review_shape(review)
    with locked(path):
        state = load_state(path)
        inputs = frozen_inputs(state)
        verify_inputs(path.parent, inputs)
        spec_entry = next(a for a in inputs if a["role"] == "spec")
        spec_path = local_path(path.parent, spec_entry["path"])
        report = check_spec(spec_path)
        need(report["spec_sha256"] == spec_entry["sha256"], "Check specification changed while reading", "INPUT_CHANGED")
        verify_inputs(path.parent, inputs)
        candidate_path = local_path(spec_path.parent, report["candidate"]["path"])
        candidate_bytes = read_bytes(candidate_path)
        need(digest(candidate_bytes) == report["candidate"]["sha256"], "Candidate changed during verification", "INPUT_CHANGED")
        expression = verify_review(review, report, as_text(candidate_bytes), spec_path, inputs, path.parent, state)
        context = execution_context(state, path.parent)
        need(context["candidate"]["sha256"] == report["candidate"]["sha256"],
             "Candidate changed during review verification", "INPUT_CHANGED")
        expected_mutable = [{"path": os.path.relpath(local_path(spec_path.parent, a["path"]), path.parent),
                             "sha256": a["sha256"]} for a in report["mutable_inputs"]]
        need(context["mutable_inputs"] == expected_mutable, "Claims changed during review verification", "INPUT_CHANGED")
        verify_inputs(path.parent, inputs)
        signature = fingerprint({"action": "record", "report": report, "review": review, "context": context})
        if repeated(state, event_id, signature):
            return state
        if state["current_node"] != "draft":
            raise GuardError("INVALID_ROUTE", route_help("record", state, path.parent))
        needs_repair =report["status"] == "RED" or review["verdict"] == "NEEDS_REVISION"
        if expired(state):
            route, reason = "stopped", "Time budget exhausted"
        elif review["verdict"] == "FAIL":
            route, reason = "blocked", "Editorial review identified a required decision or missing context"
        elif needs_repair:
            if state["budgets"]["revisions_used"] >= state["budgets"]["max_revisions"]:
                route, reason = "stopped", "Revision budget exhausted with unresolved checks"
            else:
                route, reason = "repair", "Declared checks or editorial review require scoped repair"
        else:
            route, reason = "complete", ("Declared checks and a bound editorial review accepted for these candidate bytes; "
                                         "this is not author acceptance")
        # The reviewed bytes are kept (r5.11): a later record can then see what changed since, and a file about to be
        # delivered can be compared with the version that was checked.
        candidate = artifact(candidate_path, path.parent, "candidate", candidate_bytes, snapshot=True)
        candidate.update(event_id=event_id, author_status="draft")
        state["artifacts"].append(candidate)
        editorial = {key: review[key] for key in KEPT_REVIEW_FIELDS if key in review}
        # The validated conclusions (six dimensions included) stay in the state, and the review file itself is kept
        # byte for byte with its hash, so a state file carried to another environment still shows what was reviewed.
        editorial["review_file"] = {"name": review_path.name, "sha256": digest(raw_review),
                                    "snapshot": {"encoding": "base64", "data": base64.b64encode(raw_review).decode("ascii")}}
        entry = {"event_id": event_id, "machine": report, "context": context, "editorial": editorial}
        if expression is not None:
            entry["expression_check"] = expression
        state["evidence"].append(entry)
        state["decisions"].append({"event_id": event_id, "route": route, "reason": reason})
        state["completed_nodes"].append("verify:" + event_id)
        state["current_node"] = route
        state["events"][event_id] = signature
        save_state(path, state)
        return state


def active_spec(state, base):
    """Resolve the active plan, including a replan that changes candidate path."""
    entries = [a for a in frozen_inputs(state) if a["role"] == "spec"]
    need(len(entries) == 1, "State needs one active specification", "INVALID_INPUT")
    entry = entries[0]
    path = local_path(base, entry["path"])
    content = (base64.b64decode(entry["snapshot"]["data"], validate=True)
               if "snapshot" in entry else read_bytes(path))
    need(digest(content) == entry["sha256"], "Active spec snapshot cannot be verified", "INPUT_CHANGED")
    return entry, path, load_spec(path, content)


def current_candidate(state, base):
    """Read the active plan's candidate; past recorded paths are only history."""
    _, spec_path, spec = active_spec(state, base)
    relative = os.path.relpath(local_path(spec_path.parent, spec["candidate"]), base)
    try:
        return relative, digest(read_bytes(local_path(base, relative)))
    except GuardError:
        return relative, None


def execution_context(state, base):
    """Bind checks to a plan generation, frozen sources, candidate and claims."""
    _, spec_path, spec = active_spec(state, base)
    declared = {local_path(spec_path.parent, name) for name in source_names(spec, spec_path.parent)}
    frozen = {local_path(base, entry["path"]) for entry in frozen_inputs(state) if entry["role"] == "source"}
    need(declared == frozen, "Source set changed (for example claims chapter); replan to freeze the new sources", "INPUT_CHANGED")
    relative, current = current_candidate(state, base)
    mutable = []
    for name in sorted({item["claims"] for item in spec["checks"] if item["type"] == "facts"}):
        target = local_path(spec_path.parent, name)
        mutable.append({"path": os.path.relpath(target, base), "sha256": digest(read_bytes(target))})
    inputs = [{**entry, "generation": source.get("frozen_by", "initial")}
              for entry, source in zip(input_identity(frozen_inputs(state)), frozen_inputs(state))]
    return {"schema": "workflow-context/2", "inputs": inputs, "verifier_sha256": checker_hashes(),
            "candidate": {"path": relative, "sha256": current}, "mutable_inputs": mutable}


def governance_warnings(state):
    """Constitution changes since this task started. (Checker changes are not a warning: the
    execution context binds the checker hashes, so a changed checker makes old results STALE.)"""
    current, warnings = governance_snapshot(), []
    recorded = state.get("governance")
    if recorded is None:
        warnings.append("这个任务是旧版工具建立的，没有记录宪法版本。")
    elif recorded["constitution"]["files"] != current["constitution"]["files"]:
        warnings.append("宪法或规则登记在任务开始后变了（开始时版本 %s，现在 %s）；按现行宪法重新核对受影响的判断。"
                        % (recorded["constitution"].get("version"), current["constitution"].get("version")))
    return warnings


def stage_of(input_ready, mechanical, editorial, author, last, accepted_now):
    """One-word summary of the four states (task book V1.1 chain). The four states remain the authority."""
    warnings = []
    if author == "ACCEPTED":
        at = (accepted_now or {}).get("status_at_acceptance", {})
        if (accepted_now or {}).get("review_skipped"):
            later = editorial not in ("UNTESTED", "STALE")
            warnings.append("采纳时作者决定跳过审稿（作者原话：%s）；采纳时这一版没有经过机器检查和编辑审查。%s"
                            % (accepted_now["decision"].get("source", "?"),
                               "之后对这一版补做了检查和审稿，现在的机器检查和编辑审查以补做的结果为准；交付记录照实写"
                               "“作者决定跳过审稿，之后补审”。" if later else
                               "交付记录照实写“作者决定跳过审稿”；之后没有对这一版补做检查和审稿，就不能说“已审”或“机器检查通过”。"))
        if not str(at.get("editorial", editorial)).startswith("PASS"):
            warnings.append("作者采纳时编辑审查的状态是 %s，不是 PASS。作者有最终决定权，采纳有效；交付记录要写明这一点。"
                            % at.get("editorial", editorial))
        if str(at.get("mechanical", mechanical)) != "GREEN":
            warnings.append("作者采纳时机器检查的状态是 %s，不是 GREEN。" % at.get("mechanical", mechanical))
        if input_ready != "READY":
            warnings.append("采纳之后，冻结的原稿、规格或规则文件有变动或缺失。")
        return "AUTHOR_ACCEPTED", warnings
    if input_ready != "READY":
        return "BLOCKED", warnings
    if last is None:
        return "DRAFT", warnings
    if mechanical == "STALE":
        return "STALE", warnings
    if editorial == "BLOCKED":
        return "BLOCKED", warnings
    if editorial == "NEEDS_REVISION" or mechanical.startswith("RED"):
        return "NEEDS_REVISION", warnings
    if mechanical.startswith("UNTESTED"):
        return "UNTESTED", warnings
    if editorial.startswith("PASS") and mechanical == "GREEN":
        return "READY_FOR_AUTHOR", warnings
    return "UNTESTED", warnings


def expression_note(expression):
    """What the expression record allows to be said (r5.11); '' when it covers the whole text."""
    if expression is None:
        return "没有表达检查记录（覆盖范围和逐处处理记录）；不能说表达或模板腔已审、整章精修完成。"
    if expression["scope"] == "local":
        return ("表达检查只覆盖授权范围及前后衔接（候选稿第 %s 行）；不能说整章已审、整章精修完成。"
                % lines_text(expression))
    return ""


def lines_text(expression):
    """The covered lines of a local record as ranges ("275—297")."""
    runs = expression.get("required_ranges")
    if runs is None:
        runs = []
        for n in expression.get("required_lines", []):
            if runs and n == runs[-1][1] + 1:
                runs[-1][1] = n
            else:
                runs.append([n, n])
    return "、".join(str(a) if a == b else "%d—%d" % (a, b) for a, b in runs) or "无"


def permissions_of(stage, mechanical, editorial, author, unreviewed=(), review_skipped=False, expression_gap=""):
    """ALLOW / ALLOW_WITH_WARNING / REVIEW_REQUIRED / BLOCK for claims about the current text.

    unreviewed: names of review dimensions recorded as not reviewed; review_skipped: the author accepted the
    current text after deciding to skip the review; expression_gap: what the expression record does not cover."""
    def entry(decision, rules, reason):
        return {"decision": decision, "rules": rules, "reason": reason}

    gaps = ("六个维度中这些没有看：%s；不能说这些方面已审，也不能说“精修完成”“全面审过”。" % "、".join(unreviewed)
            if unreviewed else "") + expression_gap
    result = {}
    if stage in ("READY_FOR_AUTHOR", "AUTHOR_ACCEPTED"):
        result["deliver_as_candidate"] = entry("ALLOW", ["CON-005"],
                                               "照常交付；状态记在工作记录里，按用户的输出要求呈现（只要正文时只交正文）。")
    else:
        result["deliver_as_candidate"] = entry("ALLOW_WITH_WARNING", ["CON-005"],
                                               "可以交给作者看，但不能说成已审或已完成；阶段是 %s，用户要报告或问到时照实说明。" % stage)
    if mechanical == "GREEN":
        result["claim_mechanical_pass"] = entry("ALLOW", ["CON-005"], "只能说“声明的机器检查通过”，不能说文学质量合格。")
    else:
        result["claim_mechanical_pass"] = entry("BLOCK", ["CON-005"], "机器检查的状态是 %s，不是 GREEN。" % mechanical)
    # r5.48: no state here says the prose is good. The script checks records, not writing.
    result["claim_prose_quality"] = entry("BLOCK", ["CON-005"],
                                          "程序不判断文笔：四项状态和审稿记录都不能拿来说“文笔合格”“去 AI 味已到位”“改得更好”；"
                                          "只能说做了哪些检查、审读结论是谁的意见（自查／独立代理／人工），好不好由作者读了定。")
    if editorial.startswith("PASS[self_check]"):
        result["claim_reviewed"] = entry("ALLOW_WITH_WARNING", ["CON-005"],
                                         "只能说“已自查”，并附审稿依据；不能说独立审稿。程序只核对了记录的格式、覆盖范围和引文位置，"
                                         "没有核对判断对不对。" + gaps)
        result["claim_independent_review"] = entry("BLOCK", ["CON-005"], "记录的审稿方式是同一模型自查。")
    elif editorial.startswith("PASS["):
        result["claim_reviewed"] = entry("ALLOW_WITH_WARNING", ["CON-005"],
                                         "审稿方式是审稿记录自报的，脚本无法核实；说明时照录。" + gaps)
        result["claim_independent_review"] = entry("ALLOW_WITH_WARNING", ["CON-005"],
                                                   "审稿方式“%s”是自报的，脚本无法核实；要注明“自报”。" % editorial[5:-1])
    else:
        reason = "编辑审查的状态是 %s，不是当前这一版的 PASS；不能说“已审”“精修完成”“逐章核验”。" % editorial
        if review_skipped:
            reason += "作者决定跳过审稿，照实写“作者决定跳过审稿”。"
        result["claim_reviewed"] = entry("BLOCK", ["CON-005", "CON-010"], reason)
        result["claim_independent_review"] = entry("BLOCK", ["CON-005"], reason)
    if author == "ACCEPTED":
        result["claim_final"] = entry("ALLOW", ["CON-001"], "作者已明确采纳这一版。" + (
            "采纳时作者决定跳过审稿；说定本时照实注明。" if review_skipped else ""))
        result["edit_accepted_text"] = entry("REVIEW_REQUIRED", ["CON-001", "CON-006"],
                                             "这一版已被作者采纳。要改，先取得作者的修改决定，用 replan 记录后再改。")
    else:
        result["claim_final"] = entry("BLOCK", ["CON-001", "CON-005"],
                                      "作者没有采纳当前这一版；只能叫候选稿，不能写回定本或当作后文的事实基线。")
        if author.startswith("NOT_ACCEPTED (an earlier version"):
            result["edit_accepted_text"] = entry("REVIEW_REQUIRED", ["CON-001", "CON-006"],
                                                 "作者采纳过较早的一版，现在的文字是在它之上修改的；需要作者的修改决定。")
        else:
            result["edit_accepted_text"] = entry("ALLOW", ["CON-006"], "当前是候选稿，可以在授权范围内修改；改后旧结果失效。")
    return result


def record_problem(evidence):
    """Why a stored record cannot back a result, or None. Records made by this version never trip these checks."""
    ids = [item.get("id") for item in evidence.get("machine", {}).get("review_items", [])]
    if not all(isinstance(key, str) for key in ids) or len(set(ids)) != len(ids):
        return "the recorded review items share ids (a record made by an older tool); check and review again"
    source = evidence.get("editorial", {}).get("review_file")
    if source is not None:
        try:
            raw = base64.b64decode(source["snapshot"]["data"], validate=True)
            stored = strict_json(raw)
            same = digest(raw) == source["sha256"] and all(
                stored.get(key) == evidence["editorial"].get(key) for key in KEPT_REVIEW_FIELDS)
        except (ValueError, KeyError, TypeError):
            same = False
        if not same:
            return "the stored review conclusions no longer match the stored review file; review again"
    return None


def dimension_summary(editorial, rules):
    """The recorded six-dimension conclusions, as stored; nothing is filled in for a dimension that was not read."""
    entries = editorial.get("dimensions")
    summary = {"required": bool(rules.get("dimensions")), "recorded": entries is not None}
    if entries is None:
        return summary
    by_status = {status: [x["id"] for x in entries if x["status"] == status] for status in DIMENSION_STATUSES}
    summary["by_status"] = by_status
    summary["conclusions"] = [{"id": x["id"], "name": DIMENSION_NAMES.get(x["id"], x["id"]), "status": x["status"],
                               "status_text": DIMENSION_STATUSES.get(x["status"]), "note": x.get("note"),
                               "where": x.get("where"), "evidence": x.get("evidence", [])} for x in entries]
    parts = ["met %d/%d" % (len(by_status["met"]), len(entries))]
    parts += ["%s %s" % (status, ",".join(by_status[status])) for status in ("issue", "not_reviewed", "not_applicable")
              if by_status[status]]
    summary["line"] = "dimensions: " + ", ".join(parts)
    return summary


def compute_gate(state, base):
    """Read-only delivery status. Four states, never merged into one PASS; stage and permissions are summaries."""
    problems = []
    for entry in frozen_inputs(state):
        try:
            if digest(read_bytes(local_path(base, entry["path"]))) != entry["sha256"]:
                problems.append("changed: " + entry["path"])
        except GuardError:
            problems.append("missing: " + entry["path"])
    relative, current, context = None, None, None
    try:
        relative, current = current_candidate(state, base)
        if current is None:
            problems.append("missing: " + relative)
        context = execution_context(state, base)
    except (GuardError, ValueError, KeyError, TypeError) as exc:
        problems.append("unverifiable active context: " + str(exc))
    input_ready = "READY" if not problems else "BLOCKED"
    last = state["evidence"][-1] if state["evidence"] else None
    kept, details, dimensions, expression = 0, [], None, None
    flaw = record_problem(last) if last is not None else None
    if last is None:
        mechanical, editorial = "UNTESTED", "UNTESTED"
    elif problems or context is None or context != last.get("context"):
        # Candidate, claims, plan generation, frozen sources or a checking script changed since the record.
        mechanical, editorial = "STALE", "STALE"
    elif flaw:
        # The record itself cannot back a result (review ids that collide, stored conclusions that no longer match
        # the stored review file): treat it like an outdated record, never as PASS.
        mechanical, editorial = "STALE", "STALE"
        details.append(flaw)
    else:
        machine = last["machine"]
        mechanical = {"GREEN": "GREEN", "RED": "RED", "NOT_APPLICABLE": "UNTESTED", "UNTESTED": "UNTESTED"}[machine["status"]]
        if machine.get("untested_checks"):
            mechanical += "(" + ",".join(machine["untested_checks"]) + " not run)"
        verdict = last["editorial"]["verdict"]
        mode = last["editorial"].get("reviewer", {}).get("mode", "legacy_unbound")
        editorial = {"PASS": "PASS[" + mode + "]", "NEEDS_REVISION": "NEEDS_REVISION", "FAIL": "BLOCKED"}[verdict]
        kept = sum(1 for d in last["editorial"].get("machine_dispositions", []) if d.get("decision") == "keep")
        rules = machine.get("review_policy", {})
        details.append("policy=%s(min_evidence=%s,spread=%s)" % (rules.get("mode", "?"), rules.get("min_evidence", "?"),
                                                                 "on" if rules.get("spread") else "off"))
        if kept:
            details.append("%d machine flags kept by reviewer" % kept)
        dimensions = dimension_summary(last["editorial"], rules)
        details.append(dimensions.get("line") or "dimensions: not recorded")
        expression = last.get("expression_check")
        if expression is None:
            details.append("expression: not recorded")
        else:
            details.append("expression: %s, %d segments%s, decisions keep %d / change %d" % (
                expression["scope"] if expression["scope"] == "chapter" else
                "local (candidate lines %s)" % lines_text(expression),
                expression["segments"], "" if expression["complete"] or expression["scope"] == "local" else
                " (partial)", expression["decisions"]["keep"], expression["decisions"]["change"]))
    accepted = [h for h in state["human_approvals"] if h.get("action") == "author_accept"]
    accepted_now = next((h for h in reversed(accepted)
                         if current and h["decision"]["candidate_sha256"].lower() == current), None)
    if accepted_now:
        author = "ACCEPTED"
    elif accepted:
        author = "NOT_ACCEPTED (an earlier version %s was accepted)" % accepted[-1]["decision"]["candidate_sha256"][:12]
    else:
        author = "NOT_ACCEPTED"
    skipped = bool(accepted_now and accepted_now.get("review_skipped"))
    # A skip-review acceptance is refused once the bytes have a recorded review, so a current record for the accepted
    # bytes was made after the skip: the history stays "skipped at acceptance", the four states show the later review.
    reviewed_since_skip = skipped and editorial not in ("UNTESTED", "STALE")
    gov_warnings = governance_warnings(state)
    stage, stage_warnings = stage_of(input_ready, mechanical, editorial, author, last, accepted_now)
    if gov_warnings:
        details.append("governance warnings: %d" % len(gov_warnings))
    label = "作者已采纳的定本" if author == "ACCEPTED" else "候选稿（未经作者采纳）"
    if skipped:
        label += "；采纳时作者决定跳过审稿" + ("，之后补做了审稿" if reviewed_since_skip else "")
    if editorial.startswith("PASS[self_check]"):
        label += "；编辑结论为同一模型自查，不是独立审稿"
    elif editorial.startswith("PASS["):
        label += "；审稿方式由审稿记录自报，脚本无法核实"
    if editorial.startswith("PASS["):
        # r5.48: the program checked the record (form, coverage, quotes, version), not the writing.
        label += "；程序只核对了审稿记录的格式、覆盖范围、引文位置和版本，文笔和去 AI 味的判断没有经过程序验证，待作者看"
        details.append("record=FORMAT_CHECKED, content=NOT_VERIFIED_BY_PROGRAM")
    unreviewed = [DIMENSION_NAMES.get(key, key) for key in ((dimensions or {}).get("by_status") or {}).get("not_reviewed", [])]
    if unreviewed and editorial.startswith("PASS["):
        label += "；六个维度中未看：" + "、".join(unreviewed)
    expression_gap = expression_note(expression) if editorial.startswith("PASS[") else ""
    if expression_gap:
        label += "；" + ("表达检查只覆盖局部" if expression else "没有表达检查记录")
    head = "candidate=%s sha256:%s" % (relative or "?", current[:12] if current else "unavailable")
    summary = "%s | INPUT_READY=%s | MECHANICAL=%s | EDITORIAL=%s | AUTHOR=%s | stage=%s%s -> %s" % (
        head, input_ready, mechanical, editorial, author, stage, (" | " + "; ".join(details)) if details else "", label)
    kept_items = {item["id"] for item in last["editorial"].get("machine_dispositions", [])
                  if item["decision"] == "keep"} if last else set()
    open_items = None
    if last and editorial != "STALE":
        # One keep decision closes one item: count items, not ids.
        items = last["machine"].get("review_items", [])
        open_items = len(items) - len({item["id"] for item in items} & kept_items)
    governance = state.get("governance") or {}
    return {"input_ready": input_ready, "input_problems": problems, "mechanical": mechanical, "editorial": editorial,
            "author": author, "candidate": relative, "candidate_sha256": current,
            "reviewed_sha256": last["machine"]["candidate"]["sha256"] if last else None,
            "review_items_open": open_items, "machine_flags_kept": kept, "dimensions": dimensions,
            "expression": expression,
            "review_skipped_by_author": skipped, "reviewed_since_skip": reviewed_since_skip,
            "deliverable_label": label, "summary": summary,
            "stage": stage, "stage_warnings": stage_warnings,
            "permissions": permissions_of(stage, mechanical, editorial, author, unreviewed, skipped, expression_gap),
            "review_record": "FORMAT_CHECKED" if editorial.startswith("PASS[") else None,
            "content_judgment": ("SELF_CHECK" if editorial.startswith("PASS[self_check]") else
                                 "SELF_REPORTED" if editorial.startswith("PASS[") else None),
            "constitution_version": (governance.get("constitution") or {}).get("version"),
            "governance_warnings": gov_warnings,
            "rule": ("四项各自成立，不能互相替代；UNTESTED/STALE/BLOCKED 都不是通过。stage 和 permissions 是从四项推算的摘要，"
                     "以四项为准。"),
            "limits": ("审稿方式、读过的来源、保留理由和反证都由审稿记录自报；引文核对只证明引用的文字在这一版里，"
                       "不能证明审稿人读过或判断正确。检查清单由写稿的一方自己写，GREEN 只覆盖清单里声明的检查。"
                       "状态文件没有防篡改，手工改写其中的哈希就能抹掉 STALE。")}


def reviewed_bytes(state, base, sha):
    """The bytes of the last recorded candidate: from the state (r5.11 keeps them), or the candidate file if unchanged."""
    for entry in reversed(state["artifacts"]):
        if entry["role"] == "candidate" and entry["sha256"] == sha and "snapshot" in entry:
            return base64.b64decode(entry["snapshot"]["data"])
    try:
        relative, current = current_candidate(state, base)
        if current == sha:
            return read_bytes(local_path(base, relative))
    except GuardError:
        pass
    return None


def check_deliverable(state, base, gate, target):
    """Is the file about to be delivered the version that was checked? Adds gate["deliverable"]; on a mismatch the
    claims about the checked version do not carry over to it."""
    data = read_bytes(target)
    reviewed = gate["reviewed_sha256"]
    checked = reviewed_bytes(state, base, reviewed) if reviewed else None
    if checked is not None and data == checked:
        matches = "exact"
    elif checked is not None and data.rstrip(b"\r\n") == checked.rstrip(b"\r\n"):
        matches = "final_newline_only"  # the same text; a chat or an editor dropped or added the last line break
    elif checked is not None and same_text(data, checked):
        matches = "line_endings_or_bom_only"  # the same text; an editor saved it with CRLF or a BOM (r5.13)
    else:
        matches = "no"
    gate = dict(gate, permissions=dict(gate["permissions"]))
    gate["deliverable"] = {"path": str(target), "sha256": digest(data), "reviewed_sha256": reviewed, "matches": matches,
                           "note": {"exact": "要交付的文件就是检查过的那一版。",
                                    "final_newline_only": "要交付的文件与检查过的那一版只差末尾换行，正文相同；两者的哈希不同。",
                                    "line_endings_or_bom_only": "要交付的文件与检查过的那一版正文相同，只差换行符（CRLF／LF）、"
                                                                "文件开头的 BOM 或末尾换行；两者的哈希不同。",
                                    "no": "要交付的文件不是检查过的那一版（或者还没有任何检查记录）：它没有经过检查。"}[matches]}
    if matches == "no":
        reason = ("要交付的文件（sha256:%s）不是检查过的那一版（%s）；对它不能这样说。先把检查过的版本交出去，或者对要交的"
                  "文件重新检查、重新审读。" % (digest(data)[:12], (reviewed or "没有检查记录")[:12]))
        for claim in ("claim_mechanical_pass", "claim_reviewed", "claim_independent_review", "claim_final"):
            gate["permissions"][claim] = {"decision": "BLOCK", "rules": ["CON-005"], "reason": reason}
        gate["permissions"]["deliver_as_candidate"] = {
            "decision": "ALLOW_WITH_WARNING", "rules": ["CON-005"],
            "reason": "可以交给作者看，但要说明这份文件没有经过检查。"}
        gate["summary"] += " | DELIVERABLE=MISMATCH(sha256:%s)" % digest(data)[:12]
    else:
        gate["summary"] += " | DELIVERABLE=%s" % {"exact": "checked version",
                                                  "final_newline_only": "checked text, final newline differs",
                                                  "line_endings_or_bom_only": "checked text, line endings or BOM differ"}[matches]
    return gate


def same_text(data, checked):
    """The same text as the gate reads it (as_text), apart from the final line break; bytes that are not UTF-8 are
    never the same text."""
    try:
        return as_text(data).rstrip("\n") == as_text(checked).rstrip("\n")
    except UnicodeDecodeError:
        return False


def accept(path, event_id, decision_path, skip_review=False):
    """Record the author's acceptance of the current candidate bytes.

    Normally the version must have been recorded (checked and reviewed, whatever the verdict). With skip_review the
    author has decided to skip the review (CONSTITUTION section 1, item 2): the current bytes are frozen by hash here,
    MECHANICAL and EDITORIAL stay as they are (UNTESTED when nothing was recorded) and the record says so.

    State rules per candidate hash (r5.2, review N02): a version frozen by a skip-review acceptance is not a reviewed
    version. Accepting it again without a review needs skip_review again (and the record keeps saying so); a plain
    acceptance needs a version recorded by `record`; skip_review is refused once such a review exists."""
    path = Path(path).resolve()
    decision = read_json(decision_path)
    need(isinstance(decision, dict), "Acceptance must be an object")
    value = decision.get("candidate_sha256")
    need(isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdefABCDEF" for c in value),
         "Acceptance must name candidate_sha256", "ACCEPT_INVALID")
    value = value.lower()
    decision["candidate_sha256"] = value
    for field in ("source", "scope"):
        need(nonempty(decision.get(field)), "Acceptance requires nonempty " + field + " (the author's actual words and location)",
             "ACCEPT_INVALID")
    with locked(path):
        state = load_state(path)
        action = {"action": "accept", "decision": decision}
        if skip_review:
            action["review"] = "skipped_by_author"
        signature = fingerprint(action)
        if repeated(state, event_id, signature):
            return state
        same = [a for a in state["artifacts"] if a["role"] == "candidate" and a["sha256"] == value]
        versions = [a for a in same if a.get("review") != "skipped_by_author"]  # recorded by `record`: reviewed
        skipped = [a for a in same if a.get("review") == "skipped_by_author"]  # frozen by a skip-review acceptance
        if not skip_review:
            need(versions or skipped, "This hash was never recorded for review; record the version before the author "
                 "accepts it. If the author decided to skip the review, accept with --skip-review (the record then says so)",
                 "ACCEPT_INVALID")
            need(versions, "This version has no recorded review: it was accepted earlier with the review skipped (%s). To "
                 "confirm it again without a review, accept with --skip-review (the record keeps saying the review was "
                 "skipped); to accept it as reviewed, record a review of these bytes first"
                 % ", ".join(str(v.get("event_id")) for v in skipped), "ACCEPT_INVALID")
        relative, current = current_candidate(state, path.parent)
        need(current == value, "The candidate file no longer has the accepted bytes; acceptance must name the current file",
             "ACCEPT_INVALID")
        if skip_review:
            need(not versions, "This version already has a recorded review (%s); accept it without --skip-review, and the "
                 "record keeps the review status at acceptance" % ", ".join(str(v.get("event_id")) for v in versions),
                 "ACCEPT_INVALID")
        gate = compute_gate(state, path.parent)
        approval = {"event_id": event_id, "action": "author_accept", "decision": decision,
                    "status_at_acceptance": {k: gate[k] for k in ("mechanical", "editorial")}}
        if skip_review:
            if not skipped:  # a second confirmation of the same unreviewed bytes keeps the first frozen entry
                frozen = artifact(local_path(path.parent, relative), path.parent, "candidate")
                need(frozen["sha256"] == value, "Candidate changed while recording the acceptance", "INPUT_CHANGED")
                frozen.update(event_id=event_id, author_status="accepted", accepted_by=event_id, review="skipped_by_author")
                state["artifacts"].append(frozen)
            approval["review_skipped"] = True
            approval["status_at_acceptance"]["input_ready"] = gate["input_ready"]
            reason = ("Author accepted %s and decided to skip the review%s: no machine check or editorial review covers "
                      "these bytes; the tool cannot verify who sent the decision"
                      % (value[:12], " (again)" if skipped else ""))
        else:
            for entry in versions:
                entry["author_status"] = "accepted"
                entry["accepted_by"] = event_id
            reason = "Author acceptance recorded for %s; the tool cannot verify who sent it" % value[:12]
        state["human_approvals"].append(approval)
        state["decisions"].append({"event_id": event_id, "route": state["current_node"], "reason": reason})
        state["events"][event_id] = signature
        save_state(path, state)
        return state


def utf8_stdio():
    """Reports are UTF-8 on every platform; a Windows pipe would otherwise use the local code page."""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    commands = parser.add_subparsers(dest="command", required=True)
    check = commands.add_parser("check")
    check.add_argument("spec", type=Path)
    begin = commands.add_parser("start")
    begin.add_argument("state", type=Path)
    begin.add_argument("--task-id", required=True)
    begin.add_argument("--spec", type=Path, required=True)
    begin.add_argument("--max-revisions", type=int, default=3)
    begin.add_argument("--max-seconds", type=float)
    retry = commands.add_parser("reserve")
    retry.add_argument("state", type=Path)
    retry.add_argument("--event-id", required=True)
    revise_plan = commands.add_parser("replan")
    revise_plan.add_argument("state", type=Path)
    revise_plan.add_argument("--event-id", required=True)
    revise_plan.add_argument("--spec", type=Path, required=True)
    revise_plan.add_argument("--decision", type=Path, required=True)
    verify = commands.add_parser("record")
    verify.add_argument("state", type=Path)
    verify.add_argument("--event-id", required=True)
    verify.add_argument("--review", type=Path, required=True)
    adopt = commands.add_parser("accept")
    adopt.add_argument("state", type=Path)
    adopt.add_argument("--event-id", required=True)
    adopt.add_argument("--decision", type=Path, required=True)
    adopt.add_argument("--skip-review", action="store_true",
                       help="the author decided to skip the review: record the acceptance of the current bytes without a "
                            "recorded check or review; MECHANICAL and EDITORIAL are not upgraded and the record says so")
    status = commands.add_parser("status")
    status.add_argument("state", type=Path)
    status.add_argument("--summary", action="store_true", help="print only the four-state delivery line")
    status.add_argument("--deliverable", type=Path,
                        help="the file about to be delivered: compare it with the version that was checked (exit 1 when "
                             "it is not that version)")
    args = parser.parse_args()
    try:
        if args.command == "check":
            result = check_spec(args.spec)
        elif args.command == "start":
            result = start(args.state, args.task_id, args.spec, args.max_revisions, args.max_seconds)
        elif args.command == "reserve":
            result = reserve(args.state, args.event_id)
        elif args.command == "replan":
            result = replan(args.state, args.event_id, args.spec, args.decision)
        elif args.command == "record":
            result = record(args.state, args.event_id, args.review)
        elif args.command == "accept":
            result = accept(args.state, args.event_id, args.decision, args.skip_review)
        else:
            state_path = Path(args.state).resolve()
            result = load_state(state_path)
            result["time_budget_exhausted"] = expired(result)
            result["gate"] = compute_gate(result, state_path.parent)
            mismatch = False
            if args.deliverable is not None:
                result["gate"] = check_deliverable(result, state_path.parent, result["gate"], args.deliverable)
                mismatch = result["gate"]["deliverable"]["matches"] == "no"
            if args.summary:
                print(result["gate"]["summary"])
                return 1 if mismatch else 0
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 1 if mismatch else 0
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 1 if result.get("status") == "RED" else 0
    except (GuardError, OSError, ValueError, TypeError, KeyError) as exc:
        print(json.dumps({"status": "ERROR", "failure": getattr(exc, "code", "INVALID_INPUT"), "message": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

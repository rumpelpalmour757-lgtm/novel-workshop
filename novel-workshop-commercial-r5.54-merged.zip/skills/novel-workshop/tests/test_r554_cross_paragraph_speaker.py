"""Conservative speaker attribution at the r5.54 paragraph boundary."""
import importlib.util
from pathlib import Path
import unittest


SKILL = Path(__file__).resolve().parents[1]
SCRIPT = SKILL / "scripts" / "dialogue_lines.py"
SPEC = importlib.util.spec_from_file_location("r554_dialogue_lines", SCRIPT)
DIALOGUE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(DIALOGUE)


class CrossParagraphSpeaker(unittest.TestCase):
    def speaker(self, before, after="“先把门关上。”"):
        report = DIALOGUE.inspect(f"{before}\n\n{after}", names=("方乔", "林满", "方想"))
        self.assertEqual(report["dialogue_lines"], 1)
        return next(iter(report["speakers"]), None)

    def test_unspoken_tags_leave_the_quote_unattributed(self):
        for intro in ("方乔没有说：", "方乔本想说：", "方乔差点喊出声：", "方乔没开口说：", "方乔不敢对林满说：",
                      "方乔想问：", "方乔正要开口问：", "方乔准备低声问："):
            with self.subTest(intro=intro):
                self.assertIsNone(self.speaker(intro))

    def test_explicit_speech_can_still_cross_the_boundary(self):
        for intro in ("方乔喊了一声：", "方乔低声问林满：", "方乔不得不说：", "方乔沉默片刻，还是说：",
                      "方乔没有犹豫，接着说：", "方乔想了想，说：", "方乔不再犹豫，开口说："):
            with self.subTest(intro=intro):
                self.assertEqual(self.speaker(intro), "方乔")

    def test_explicit_tag_after_the_quote_still_names_its_speaker(self):
        self.assertEqual(self.speaker("方乔没有说：", "“先把门关上。”林满说。"), "林满")

    def test_written_introduction_remains_unattributed(self):
        self.assertIsNone(self.speaker("方乔拆开一封信："))

    def test_a_character_name_can_end_with_an_unspoken_cue(self):
        self.assertEqual(self.speaker("方想说："), "方想")
        self.assertIsNone(self.speaker("方想本来想问："))

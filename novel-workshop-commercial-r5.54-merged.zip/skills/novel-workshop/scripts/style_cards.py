#!/usr/bin/env python3
"""Style cards: the index, literal hints for a scene, and the chosen cards loaded as directions (r5.45, references/style-cards.md).

python3 style_cards.py index [--layer L] [--project BOOK_CONFIG] [--format text|json]
python3 style_cards.py match [--text TEXT] [--file FILE ...] [--project BOOK_CONFIG] [--top N] [--format text|json]
python3 style_cards.py load CARD_ID [CARD_ID ...] [--project BOOK_CONFIG]
python3 style_cards.py copied CARD_ID [CARD_ID ...] --file DRAFT [--file ...] [--format text|json]
python3 style_cards.py check [--project BOOK_CONFIG]

All commands take --library FILE (default: assets/style-cards/cards.json next to this script's folder).

The cards ship with the workshop (card set 4.1.0, r5.45). They come in four layers: base (the world's ground tone),
voice (the overall prose voice), device (a point-of-view or form device) and scene (what one scene does). Which cards a
scene gets, or none, is the writer's judgment against the index: match only lists literal hits (a card's scene phrases,
the book's keywords) and never picks a card. load prints the chosen cards as directions, at most what the card set allows
per layer (base 1, voice 1, device 1, scene 2) and never two cards marked as conflicting; where they differ on sentences
and rhythm the card set's order decides (device, voice, scene, base). The examples show what the voice is like and are
not text to copy or a replacement table; the opposite phrasings (a card's and the set's global ones) are not a list of
banned words. The author's own text and the book's voice records come first. copied looks for the cards' own wording in
a draft after writing: any stretch of four or more Chinese characters taken over from an example (literal only; whether
it is a problem is the writer's call).

A book may keep a config next to its project files (--project): keywords per card (the author's routes), cards the book
does not use (exclude), and a default card only when the author has decided one (default_card; without it a scene that
matches nothing gets no card). check validates the library and the config. Read-only and offline; it calls no model.
"""
import argparse
import json
from pathlib import Path
import re
import sys

FORMAT = "novel-workshop-style-cards"
CONFIG_FORMAT = "novel-workshop-style-card-config"
CARD_FIELDS = ("id", "aliases", "name", "layer", "domain", "scene_triggers", "syntax_metrics", "lexical_shifts",
               "kinetic_verbs", "blacklist", "blacklist_patterns", "conflicts_with", "overrides", "sections")
SECTIONS = ("subtext_logic", "lexical_map", "kinetic_verbs_text", "somatosensory", "syntax_rhythm", "example_before",
            "example_after", "overuse")
SYNTAX_FIELDS = {"avg_clause_length", "sentence_final_particles", "punctuation"}
CONFIG_FIELDS = {"format", "format_version", "book", "keywords", "exclude", "default_card", "note"}
ID = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
ALT = " / "
PUNCT = set("，。、；：？！…—（）《》「」『』【】“”‘’█·~～,.;:?!()[]")
SPLIT = re.compile(r"[与和或及、/／]")
QUOTED = re.compile(r"「([^」]+)」|“([^”]+)”")
HAN = re.compile(r"[一-鿿]")
DIRECTIONS = ("只加载方向：照这几张卡的叙述逻辑、句子节奏和取材的方向写这一场。例句和示范段只示意这种腔调大概什么样，"
              "不搬进正文，也不当替换表用，例句借的作家、作品的标志性台词和桥段也不搬；名词、动作、感官几栏是可挑的料，"
              "这一场用得上的挑一两样，落在人的动作和感知里，不逐项写；句子长短是方向，不是要凑的数；“过量信号”是写过头"
              "的样子，写完照着自查。作者自己的原文、本书的文风卡和口吻表、已采纳的正文优先，跟卡对不上的地方按作者的。"
              "交稿时在正文外用一句话说明这一场加载了哪几张、为什么（作者只要正文时记在工作记录里）。")
NOT_DECIDED = ("字面命中只是线索：命中了不等于对得上，没命中也不等于对不上。挑哪几张、或者不挑，由写的人对照索引判断"
               "（references/style-cards.md）。")
CLAUSE_LINE = "- 分句（逗号、句号隔开的一小段）大致 %s 字：这种腔调的大致样子，不是要求；连着的动作，几个分句可以连成一句。"
DIALOGUE_LINE = ("- 分句长短和常用语气词这两样说的是叙述（r5.53）：台词的长短、语气词和称呼跟着说话的人、对谁说和此刻的处境走（口吻表、"
                 "作者样本、references/dialogue-craft.md）；卡上没列语气词，不等于台词不带“了、呢、吧”；语气词跟着说话的人和这一刻走，"
                 "不为凑口语句句挂一个（对白专项“声口和语域”，r5.54）。下面卡上专讲对白的说法，"
                 "只管这张卡对得上的那类场面，不带到同一章别的场面；市井温情那张卡里的“全在不言中”只是一种写法：把关心说出口一样可以是温情的场面，"
                 "不因为加载了卡就把已经说出口的关心改成动作（工坊的读法，作者没有逐条看过）；和口吻表、作者样本对不上时按后者。")
CLASH_MARK = "（撞上同用的另一张卡的相反写法：待复核，看这一场的处境、人物和动作合不合，再定用不用）"
TOGETHER = ("几张同用：先后只定句长的大概数；每张卡句子一节里随动作走的说法照样看。说明之间说法不一时（写不写过程、感官写不写主观"
            "感受），照这一场要读者看清什么来定，交代时说一句用了哪张的哪一条。")


class CardError(Exception):
    pass


def default_library():
    return Path(__file__).resolve().parents[1] / "assets" / "style-cards" / "cards.json"


def read_json(path, what):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise CardError(what + " not found: " + str(path)) from exc
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise CardError(what + " is not readable JSON: " + str(exc)) from exc


def is_phrases(value, empty_ok=True):
    return isinstance(value, list) and (empty_ok or value) and all(isinstance(x, str) and x.strip() for x in value)


def library_problems(data):
    if not isinstance(data, dict) or data.get("format") != FORMAT:
        return ["format must be " + FORMAT]
    problems = []
    if data.get("format_version") != 2:
        problems.append("format_version must be 2 (card set 4.x with layers)")
    layers, cards, comp, glob = data.get("layers"), data.get("cards"), data.get("composition"), data.get("global")
    if not isinstance(layers, dict) or not layers or not isinstance(cards, list) or not cards:
        return problems + ["layers must be an object and cards a non-empty list"]
    if not isinstance(comp, dict) or not isinstance(comp.get("max_per_layer"), dict) \
            or set(comp["max_per_layer"]) != set(layers) \
            or not all(isinstance(n, int) and n >= 1 for n in comp["max_per_layer"].values()) \
            or sorted(comp.get("precedence") or []) != sorted(layers):
        problems.append("composition must give max_per_layer for every layer and a precedence over the layers")
    if not isinstance(glob, dict) or not is_phrases(glob.get("blacklist")) or not is_phrases(glob.get("blacklist_patterns")) \
            or not isinstance(glob.get("example_policy"), str):
        problems.append("global must have blacklist, blacklist_patterns and example_policy")
    seen, names = set(), {}
    for index, card in enumerate(cards):
        where = "cards[%d]" % index
        if not isinstance(card, dict):
            problems.append(where + " is not an object")
            continue
        cid = card.get("id")
        where = cid if isinstance(cid, str) else where
        missing = [f for f in CARD_FIELDS if f not in card]
        extra = sorted(set(card) - set(CARD_FIELDS))
        if missing:
            problems.append(where + ": missing " + ", ".join(missing))
            continue
        if extra:
            problems.append(where + ": unknown fields " + ", ".join(extra))
        if not isinstance(cid, str) or not ID.match(cid):
            problems.append(where + ": id must be lowercase words joined by hyphens")
        for name in [cid] + (card["aliases"] if isinstance(card["aliases"], list) else []):
            if name in names:
                problems.append(where + ": id or alias %s is used twice" % name)
            names[name] = cid
        if card["layer"] not in layers:
            problems.append(where + ": layer must be one of " + ", ".join(layers))
        if not (isinstance(card["name"], str) and card["name"].strip()):
            problems.append(where + ": name must be text")
        if not is_phrases(card["scene_triggers"], empty_ok=False):
            problems.append(where + ": scene_triggers must be a non-empty list of phrases")
        for field in ("lexical_shifts", "kinetic_verbs"):
            table = card[field]
            if not isinstance(table, dict) or not all(isinstance(k, str) and k.strip() and isinstance(v, str) and v.strip()
                                                      for k, v in table.items()):
                problems.append(where + ": " + field + " must map a phrase to its example")
        syntax = card["syntax_metrics"]
        if not isinstance(syntax, dict) or not SYNTAX_FIELDS <= set(syntax) or not set(syntax) <= SYNTAX_FIELDS | {"register_markers"}:
            problems.append(where + ": syntax_metrics must have avg_clause_length, sentence_final_particles, punctuation")
        else:
            if not isinstance(syntax["avg_clause_length"], str):
                problems.append(where + ": avg_clause_length must be text such as 5-11")
            for field in ("sentence_final_particles", "punctuation", "register_markers"):
                if field in syntax and not is_phrases(syntax[field]):
                    problems.append(where + ": " + field + " must be a list of strings")
        for field in ("aliases", "blacklist", "blacklist_patterns", "conflicts_with"):
            if not is_phrases(card[field]):
                problems.append(where + ": " + field + " must be a list of strings")
        if not isinstance(card["overrides"], dict):
            problems.append(where + ": overrides must be an object")
        sections = card["sections"]
        if not isinstance(sections, dict) or set(sections) != set(SECTIONS) or not all(isinstance(v, str) for v in sections.values()):
            problems.append(where + ": sections must have " + ", ".join(SECTIONS))
        elif not sections["subtext_logic"].strip():
            problems.append(where + ": subtext_logic (how the scene is organised) is empty")
        seen.add(cid)
    for card in cards:
        if isinstance(card, dict) and is_phrases(card.get("conflicts_with")):
            for other in card["conflicts_with"]:
                if other not in seen:
                    problems.append("%s: conflicts_with names a card that is not in the library: %s" % (card.get("id"), other))
    return problems


def load_library(path):
    data = read_json(path, "card library")
    problems = library_problems(data)
    if problems:
        raise CardError("card library has problems: " + "; ".join(problems[:5]))
    return data


def resolve(data, name):
    for card in data["cards"]:
        if card["id"] == name or name in card["aliases"]:
            return card
    return None


def config_report(config, data):
    """Problems and notices of a book's config against the library."""
    problems, notices = [], []
    if not isinstance(config, dict) or config.get("format") != CONFIG_FORMAT:
        return ["format must be " + CONFIG_FORMAT], notices
    if config.get("format_version") != 1:
        problems.append("format_version must be 1")
    extra = sorted(set(config) - CONFIG_FIELDS)
    if extra:
        problems.append("unknown fields: " + ", ".join(extra))
    ids = {c["id"] for c in data["cards"]}
    keywords = config.get("keywords", {})
    exclude = config.get("exclude", [])
    default = config.get("default_card")
    if not isinstance(keywords, dict):
        problems.append("keywords must map a card id to a list of words")
        keywords = {}
    if not (isinstance(exclude, list) and all(isinstance(x, str) for x in exclude)):
        problems.append("exclude must be a list of card ids")
        exclude = []
    owners = {}
    for cid, words in keywords.items():
        if cid not in ids:
            card = resolve(data, cid)
            problems.append("keywords point to a card that is not in the library: " + cid
                            + (" (it is an alias of %s; write the card id)" % card["id"] if card else ""))
        if cid in exclude:
            problems.append("keywords point to a card the book excludes: " + cid)
        if not is_phrases(words, empty_ok=False):
            problems.append("keywords for " + cid + " must be a non-empty list of words")
            continue
        for word in words:
            owners.setdefault(word, []).append(cid)
    for word, cards in sorted(owners.items()):
        if len(cards) > 1:
            notices.append("the word %s points to %d cards: %s" % (word, len(cards), ", ".join(cards)))
    for cid in exclude:
        if cid not in ids:
            problems.append("exclude names a card that is not in the library: " + cid)
    if default is not None:
        if not isinstance(default, str) or default not in ids:
            problems.append("default_card is not a card in the library: " + str(default))
        elif default in exclude:
            problems.append("default_card is excluded by the same config: " + default)
    return problems, notices


def load_config(path, data):
    if path is None:
        return None
    config = read_json(path, "book config")
    problems, _ = config_report(config, data)
    if problems:
        raise CardError("book config has problems: " + "; ".join(problems[:5]))
    return config


def usable_cards(data, config):
    excluded = set((config or {}).get("exclude", []))
    return [c for c in data["cards"] if c["id"] not in excluded]


def phrase_parts(card):
    parts = []
    for trigger in card["scene_triggers"]:
        for piece in [trigger] + SPLIT.split(trigger):
            piece = piece.strip()
            if len(piece) >= 2 and piece not in parts:
                parts.append(piece)
    return parts


def match(data, config, text, top=5):
    keywords = (config or {}).get("keywords", {})
    rows = []
    for card in usable_cards(data, config):
        words = [w for w in keywords.get(card["id"], []) if w in text]
        phrases = [p for p in phrase_parts(card) if p in text]
        if words or phrases:
            rows.append({"id": card["id"], "name": card["name"], "layer": card["layer"], "book_keywords": words,
                         "scene_phrases": phrases})
    rows.sort(key=lambda r: (-len(r["book_keywords"]), -len(r["scene_phrases"]), r["id"]))
    default = (config or {}).get("default_card")
    return {"hits": rows[:top], "more": max(0, len(rows) - top), "default_card": default if not rows else None,
            "note": NOT_DECIDED}


def index_rows(data, config, layer=None):
    keywords = (config or {}).get("keywords", {})
    rows = []
    for card in usable_cards(data, config):
        if layer and card["layer"] != layer:
            continue
        row = {"id": card["id"], "name": card["name"], "layer": card["layer"], "scene_triggers": card["scene_triggers"]}
        if card["aliases"]:
            row["aliases"] = card["aliases"]
        if card["conflicts_with"]:
            row["conflicts_with"] = card["conflicts_with"]
        if keywords.get(card["id"]):
            row["book_keywords"] = keywords[card["id"]]
        rows.append(row)
    return rows


def limits_text(data):
    m = data["composition"]["max_per_layer"]
    return "、".join("%s %d 张" % (key, m[key]) for key in data["layers"])


def index_text(data, config, layer=None):
    rows = index_rows(data, config, layer)
    head = ["风格卡索引（%d 张）。识别由写的人做：对照这一场要读者经历什么、这本书的题材和口吻，每一层挑一张或者不挑"
            "（最多 %s），对不上就不加载。办法见 references/style-cards.md。" % (len(rows), limits_text(data))]
    if config:
        excluded = config.get("exclude", [])
        if excluded:
            head.append("本书不用：" + "、".join(excluded))
        if config.get("default_card"):
            head.append("本书对不上时默认加载：%s（作者定的）" % config["default_card"])
    lines = head
    for key, label in data["layers"].items():
        group = [r for r in rows if r["layer"] == key]
        if not group:
            continue
        lines.append("")
        lines.append("## %s · %s（%d）" % (key, label, len(group)))
        for r in group:
            extra = ""
            if r.get("aliases"):
                extra += "｜又名：" + "、".join(r["aliases"])
            if r.get("conflicts_with"):
                extra += "｜不和这几张同用：" + "、".join(r["conflicts_with"])
            if r.get("book_keywords"):
                extra += "｜本书关键词：" + "、".join(r["book_keywords"])
            lines.append("- %s｜%s｜%s%s" % (r["id"], r["name"], "；".join(r["scene_triggers"]), extra))
    return "\n".join(lines) + "\n"


def clause_range(value):
    found = re.fullmatch(r"\s*(\d+)\s*[-–—~～]\s*(\d+)\s*", value)
    return "%s—%s" % found.groups() if found else value


def is_punct(item):
    return all(ch in PUNCT for ch in item)


def choose(data, config, names):
    """The cards to load, in the card set's precedence; refuses more than a layer allows and conflicting pairs."""
    if not names:
        raise CardError("name the cards to load")
    excluded = set((config or {}).get("exclude", []))
    cards = []
    for name in names:
        card = resolve(data, name)
        if card is None:
            close = [c["id"] for c in data["cards"] if name and (name in c["id"] or c["id"].split("-")[0] == name.split("-")[0])]
            raise CardError("no card " + name + (" (close: " + ", ".join(close[:5]) + ")" if close else ""))
        if card["id"] in excluded:
            raise CardError("the book config excludes this card: " + card["id"])
        if card in cards:
            raise CardError("the card is named twice: " + card["id"])
        cards.append(card)
    limits = data["composition"]["max_per_layer"]
    for layer, label in data["layers"].items():
        chosen = [c["id"] for c in cards if c["layer"] == layer]
        if len(chosen) > limits[layer]:
            raise CardError("at most %d %s card(s) at a time (%s): %s" % (limits[layer], layer, label, ", ".join(chosen)))
    ids = {c["id"] for c in cards}
    for card in cards:
        clash = [x for x in card["conflicts_with"] if x in ids]
        if clash:
            raise CardError("%s does not go together with %s (conflicts_with)" % (card["id"], ", ".join(clash)))
    order = {layer: i for i, layer in enumerate(data["composition"]["precedence"])}
    return sorted(cards, key=lambda c: (order[c["layer"]], names.index(c["id"]) if c["id"] in names else 0))


def examples(card):
    """(where, text) of every example in a card: table values, quoted examples in its sections, the model passage."""
    out = []
    for field in ("lexical_shifts", "kinetic_verbs"):
        for plain, example in card[field].items():
            out += [(field + "：" + plain, way.strip()) for way in example.split(ALT) if way.strip()]
    for key in ("lexical_map", "kinetic_verbs_text", "somatosensory", "subtext_logic", "syntax_rhythm"):
        for m in QUOTED.finditer(card["sections"][key]):
            out.append((key, m.group(1) or m.group(2)))
    if card["sections"]["example_after"]:
        out.append(("example_after", card["sections"]["example_after"]))
    return out


def opposite_words(card):
    return list(card["blacklist"])


def opposite_patterns(card):
    """The card's blacklist_patterns that compile; a pattern that does not is skipped, not an error."""
    out = []
    for pattern in card["blacklist_patterns"]:
        try:
            out.append((pattern, re.compile(pattern)))
        except (re.error, OverflowError, RecursionError, TypeError, ValueError):
            continue
    return out


def clashes(way, own, opposite, patterns):
    """True when an example of card `own` holds another loaded card's opposite word or matches its pattern."""
    for word, owners in opposite.items():
        if word in way and any(o != own for o in owners):
            return True
    for compiled, owners in patterns.values():
        if any(o != own for o in owners):
            try:
                if compiled.search(way):
                    return True
            except (RecursionError, re.error):
                continue
    return False


def render(data, cards):
    glob = data["global"]
    allowed = set()
    translationese = glob.get("forbid_translationese", False)
    adverbs = glob.get("forbid_consecutive_adverbs", False)
    for card in cards:
        over = card["overrides"]
        allowed.update(over.get("allow_global_terms") or [])
        if over.get("forbid_translationese") is False:
            translationese = False
        if over.get("forbid_consecutive_adverbs") is False:
            adverbs = False
    title = "、".join("%s（%s，%s）" % (c["name"], c["id"], c["layer"]) for c in cards)
    lines = ["# 风格卡：" + title, "", DIRECTIONS, ""]
    if len(cards) > 1:
        lines += ["几张同用：句长的大概数对不上时，照 %s 的先后取第一张写了的（下面也按这个先后排）；"
                  "一张卡的示例撞上另一张的“相反的写法”，那条示例后面标了待复核：只是要回头再看的地方，不是判定。"
                  % " > ".join(data["composition"]["precedence"]), TOGETHER, ""]
    lines += ["卡组的示例规则：" + glob["example_policy"]]
    if translationese:
        lines.append("全卡组的方向：少用翻译腔。")
    if adverbs:
        lines.append("全卡组的方向：不连用副词。")
    words = [w for w in glob["blacklist"] if w not in allowed]
    if words:
        lines.append("全卡组相反的写法（心里有数，不是禁词表，人物台词里该有的照有）：" + "、".join(words))
    if allowed:
        lines.append("这几张卡放开的：" + "、".join(sorted(allowed)))
    opposite, patterns = {}, {}
    for card in cards:
        for word in opposite_words(card):
            opposite.setdefault(word, []).append(card["id"])
        for pattern, compiled in opposite_patterns(card):
            patterns.setdefault(pattern, (compiled, []))[1].append(card["id"])
    for card in cards:
        s = card["sections"]
        lines += ["", "## %s（%s · %s）" % (card["name"], card["id"], data["layers"][card["layer"]]), "",
                  "适用场景：" + "；".join(card["scene_triggers"])]
        for key, title_ in (("subtext_logic", "叙述逻辑"), ("lexical_map", "名词"), ("kinetic_verbs_text", "动作"),
                            ("somatosensory", "感官（可挑的料）")):
            if s[key].strip():
                lines += ["", "### " + title_, "", s[key].strip()]
        syntax = card["syntax_metrics"]
        lines += ["", "### 句子", "", CLAUSE_LINE % clause_range(syntax["avg_clause_length"]), DIALOGUE_LINE]
        particles = [p for p in syntax["sentence_final_particles"] if not is_punct(p)]
        punctuation = list(syntax["punctuation"]) + [p for p in syntax["sentence_final_particles"]
                                                     if is_punct(p) and p not in syntax["punctuation"]]
        if particles:
            lines.append("- 常用语气词：" + "、".join(particles))
        if syntax.get("register_markers"):
            lines.append("- 常见的口头字眼：" + "、".join(syntax["register_markers"]))
        if punctuation:
            lines.append("- 常用标点：" + " ".join(punctuation))
        if s["syntax_rhythm"].strip():
            lines += [s["syntax_rhythm"].strip()]
        for field, title_ in (("lexical_shifts", "腔调示例（示意，不搬进正文，不是替换表）"),
                              ("kinetic_verbs", "动作示例（示意，不搬进正文，不是替换表）")):
            table = card[field]
            if not table:
                continue
            lines += ["", "### " + title_, ""]
            for plain, example in table.items():
                ways = [w.strip() for w in example.split(ALT) if w.strip()]
                note = CLASH_MARK if any(clashes(w, card["id"], opposite, patterns) for w in ways) else ""
                lines.append("- 平常写“%s”的地方，这种腔调大概是：%s%s" % (plain, "；或者：".join(ways), note))
        if s["example_before"] and s["example_after"]:
            lines += ["", "### 示范（只示意改的方向，不搬进正文）", "", "改写前：" + s["example_before"], "",
                      "改写后：" + s["example_after"]]
        if s["overuse"].strip():
            lines += ["", "### 过量信号（写过头的样子，写完照着自查）", "", s["overuse"].strip()]
        if card["blacklist"]:
            lines += ["", "### 跟这种腔调相反的写法（心里有数，不是禁词表）", "", "、".join(card["blacklist"])]
        if card["blacklist_patterns"]:
            lines.append("（另有 %d 条句式写在卡片库的 blacklist_patterns 里，同样只是心里有数）" % len(card["blacklist_patterns"]))
    return "\n".join(lines) + "\n"


def copied(cards, text, least=4):
    """Stretches of the cards' examples that stand word for word in the text (four Chinese characters or more, the
    longest first; overlapping finds of one example are reported once)."""
    found = []
    for card in cards:
        for where, source in examples(card):
            taken = []
            n = len(source)
            for i in range(n):
                for j in range(n, i, -1):
                    piece = source[i:j]
                    if len(HAN.findall(piece)) < least:
                        break
                    if piece in text:
                        if not any(piece in t for t in taken):
                            taken.append(piece)
                        break
            for piece in taken:
                found.append({"card": card["id"], "where": where, "text": piece})
    return found


def read_text(args):
    parts = [args.text] if getattr(args, "text", None) else []
    for path in args.file or []:
        try:
            parts.append(Path(path).read_bytes().decode("utf-8-sig"))
        except (OSError, UnicodeDecodeError) as exc:
            raise CardError("cannot read " + str(path) + ": " + str(exc)) from exc
    if not "".join(parts).strip():
        raise CardError("give the scene task or the text with --text or --file")
    return "\n".join(parts)


def match_text(result):
    lines = []
    if not result["hits"]:
        lines.append("没有字面命中。")
        if result["default_card"]:
            lines.append("本书设定了对不上时默认加载 %s（作者定的）：对照索引判断还是对不上，就加载它。" % result["default_card"])
    for r in result["hits"]:
        bits = []
        if r["book_keywords"]:
            bits.append("本书关键词：" + "、".join(r["book_keywords"]))
        if r["scene_phrases"]:
            bits.append("适用场景里的说法：" + "、".join(r["scene_phrases"]))
        lines.append("- %s｜%s｜%s｜%s" % (r["id"], r["layer"], r["name"], "；".join(bits)))
    if result["more"]:
        lines.append("（另有 %d 张有零星命中，没列出）" % result["more"])
    lines.append(result["note"])
    return "\n".join(lines) + "\n"


def utf8_stdio():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = parser.add_subparsers(dest="command", required=True)
    commands = {}
    for name in ("index", "match", "load", "copied", "check"):
        commands[name] = sub.add_parser(name)
        commands[name].add_argument("--library", type=Path, default=None, help="card library (default: assets/style-cards/cards.json)")
        commands[name].add_argument("--project", type=Path, default=None, help="the book's style-card config, if it has one")
    commands["index"].add_argument("--layer")
    commands["index"].add_argument("--format", choices=("text", "json"), default="text")
    commands["match"].add_argument("--text", help="the scene task, or text from the page")
    commands["match"].add_argument("--file", action="append", type=Path, help="text file to read (repeatable)")
    commands["match"].add_argument("--top", type=int, default=5)
    commands["match"].add_argument("--format", choices=("text", "json"), default="text")
    commands["load"].add_argument("card_ids", nargs="+")
    commands["copied"].add_argument("card_ids", nargs="+")
    commands["copied"].add_argument("--file", action="append", type=Path, required=True, help="the draft (repeatable)")
    commands["copied"].add_argument("--format", choices=("text", "json"), default="text")
    args = parser.parse_args()
    library = args.library or default_library()
    try:
        if args.command == "check":
            data = read_json(library, "card library")
            problems = library_problems(data)
            report = {"status": "PROBLEMS" if problems else "OK", "cards": len(data.get("cards", [])) if isinstance(data, dict) else 0,
                      "problems": problems}
            if args.project is not None and not problems:
                config_problems, notices = config_report(read_json(args.project, "book config"), data)
                report["config"] = {"problems": config_problems, "notices": notices}
                if config_problems:
                    report["status"] = "PROBLEMS"
            print(json.dumps(report, ensure_ascii=False, indent=1))
            return 1 if report["status"] != "OK" else 0
        data = load_library(library)
        config = load_config(args.project, data)
        if args.command == "index":
            if args.layer and args.layer not in data["layers"]:
                raise CardError("no layer " + args.layer + " (layers: " + ", ".join(data["layers"]) + ")")
            if args.format == "json":
                print(json.dumps(index_rows(data, config, args.layer), ensure_ascii=False, indent=1))
            else:
                print(index_text(data, config, args.layer), end="")
            return 0
        if args.command == "match":
            if args.top < 1:
                raise CardError("--top must be at least 1")
            result = match(data, config, read_text(args), args.top)
            print(json.dumps(result, ensure_ascii=False, indent=1) if args.format == "json" else match_text(result), end="")
            return 0
        cards = choose(data, config, args.card_ids)
        if args.command == "copied":
            found = copied(cards, read_text(args))
            if args.format == "json":
                print(json.dumps({"cards": [c["id"] for c in cards], "found": found}, ensure_ascii=False, indent=1))
            elif found:
                print("".join("- %s %s：%s\n" % (f["card"], f["where"], f["text"]) for f in found)
                      + "这些是卡里示例的原话，照搬进了正文：改成这一场自己的说法，或者写明为什么保留。\n", end="")
            else:
                print("正文里没有照搬卡里示例的原话（四个汉字以上）。这只查字面，不说明腔调用得好不好。\n", end="")
            return 0
        print(render(data, cards), end="")
        return 0
    except CardError as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    sys.exit(main())

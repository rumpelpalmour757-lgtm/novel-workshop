#!/usr/bin/env python3
"""r5.3: repairs for the 2026-10-16 review of the r5.2 candidate (finding N04), plus two gaps found while taking r5.2 in.

N04  Speaker and words on separate lines ("陈青低声说：" / "“知道了！”"), the same words said by three people, paragraphs
     moved: the revision comparison paired different people's lines. A pure move was reported as two certain changes;
     a move plus two changed marks was not reported at all, and the strict gate passed with nothing to decide.
Also: an id collision spelled by two checks' ids (end to end), and the Darwin hint when --from-snapshots was already used.
All material is invented for these tests; reviews are labelled test data.
"""

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SCRIPTS = ROOT / "skills" / "novel-workshop" / "scripts"
DARWIN = ROOT / "skills" / "darwin-novel-workshop" / "scripts" / "darwin_eval.py"
DIMENSIONS = ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function", "continuity",
              "revision_comparison")

# The review's own N04 texts: attribution on the line above, three people say the same words, 孟迟 and 卢石 swap places.
ORIGINAL = "陈青低声说：\n“知道了！”\n\n孟迟低声说：\n“知道了！”\n\n卢石低声说：\n“知道了。”\n"
MOVED = "陈青低声说：\n“知道了！”\n\n卢石低声说：\n“知道了。”\n\n孟迟低声说：\n“知道了！”\n"
MOVED_AND_CHANGED = "陈青低声说：\n“知道了。”\n\n卢石低声说：\n“知道了！”\n\n孟迟低声说：\n“知道了！”\n"


def compare(original, revised):
    spec = importlib.util.spec_from_file_location("r53_punctuation", SCRIPTS / "punctuation_lint.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.compare_texts(original, revised)


def certain(report):
    return sorted((t["line"], t["before"] + "→" + t["after"]) for t in report["tone_changes"] if t["match"] != "uncertain")


def flagged_lines(report):
    return sorted(t["line"] for t in report["tone_changes"])


def build(units, blank=True):
    """units: (attribution, words+mark, where) with where 'above' / 'below' / 'paragraph' (attribution in its own paragraph)."""
    parts = []
    for name, said, where in units:
        speech = "“%s”" % said
        if where == "above":
            parts.append("%s低声说：\n%s" % (name, speech))
        elif where == "below":
            parts.append("%s\n%s低声说。" % (speech, name))
        else:
            parts.append("%s点了点头。\n\n%s" % (name, speech))
    return ("\n\n" if blank else "\n").join(parts) + "\n"


class SpeakerOnTheLineAbove(unittest.TestCase):
    """N04 as reported, and the same words moved in other layouts."""

    def test_the_reviews_pure_move_is_not_reported(self):
        report = compare(ORIGINAL, MOVED)
        self.assertEqual(report["tone_changes"], [])
        self.assertEqual(report["status"], "NO_NEW_FLAGS")

    def test_the_reviews_move_with_two_changed_marks_is_reported(self):
        report = compare(ORIGINAL, MOVED_AND_CHANGED)
        # 陈青 (line 2) went from ！ to 。; 卢石 (now line 5) went from 。 to ！; 孟迟 (now line 8) is unchanged.
        self.assertEqual(certain(report), [(2, "！→。"), (5, "。→！")])
        self.assertEqual(flagged_lines(report), [2, 5])

    def test_the_reviews_case_needs_two_decisions_at_the_gate(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            (work / "original.md").write_text(ORIGINAL, encoding="utf-8")
            (work / "draft.md").write_text(MOVED_AND_CHANGED, encoding="utf-8")
            (work / "checks.json").write_text(json.dumps({"candidate": "draft.md", "mode": "strict", "checks": [
                {"id": "rev", "type": "revision", "source": "original.md"}]}), encoding="utf-8")

            def run(*args):
                proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPTS / "workflow_guard.py"), *args], cwd=work,
                                      capture_output=True, text=True, encoding="utf-8")
                return proc.returncode, json.loads(proc.stdout)

            def review(name, dispositions):
                # The review's own fixture: the three attribution lines as quotes, all six dimensions as test data.
                (work / name).write_text(json.dumps({
                    "schema": "editorial-review/2", "verdict": "PASS",
                    "candidate_sha256": hashlib.sha256((work / "draft.md").read_bytes()).hexdigest(),
                    "reviewer": {"mode": "self_check", "label": "测试数据：只验证结构"},
                    "checked_against": ["测试数据：original.md"], "inputs_read": ["original.md"],
                    "evidence": [{"in": "candidate", "quote": q} for q in ("陈青低声说：", "卢石低声说：", "孟迟低声说：")],
                    "issues": [], "counter_evidence": "测试数据，不是真实文学审稿。", "machine_dispositions": dispositions,
                    "dimensions": [{"id": key, "status": "met", "note": "测试数据：只验证结构"} for key in DIMENSIONS]},
                    ensure_ascii=False), encoding="utf-8")
                return name

            self.assertEqual(run("start", "state.json", "--task-id", "n04", "--spec", "checks.json")[0], 0)
            items = [x["id"] for x in run("check", "checks.json")[1]["review_items"]]
            self.assertEqual(items, ["rev:TONE-L2-C1", "rev:TONE-L5-C1"])
            code, out = run("record", "state.json", "--event-id", "v1", "--review", review("none.json", []))
            self.assertEqual((code, out["failure"]), (2, "REVIEW_INCOMPLETE"))
            code, out = run("record", "state.json", "--event-id", "v1", "--review", review("one.json", [
                {"id": items[0], "decision": "keep", "reason": "测试数据：只核对了陈青这一句"}]))
            self.assertEqual(code, 2)
            self.assertIn(items[1], out["message"])
            code, _ = run("record", "state.json", "--event-id", "v2", "--review", review("both.json", [
                {"id": key, "decision": "keep", "reason": "测试数据：两处语气都是有意改的"} for key in items]))
            self.assertEqual(code, 0)
            gate = run("status", "state.json")[1]["gate"]
            self.assertEqual((gate["mechanical"], gate["editorial"], gate["review_items_open"]), ("GREEN", "PASS[self_check]", 0))

    def test_speaker_on_the_line_below(self):
        before = build([("陈青", "知道了！", "below"), ("孟迟", "知道了！", "below"), ("卢石", "知道了。", "below")])
        moved = build([("陈青", "知道了！", "below"), ("卢石", "知道了。", "below"), ("孟迟", "知道了！", "below")])
        changed = build([("陈青", "知道了。", "below"), ("卢石", "知道了！", "below"), ("孟迟", "知道了！", "below")])
        # Changed in r5.5 (review of r5.4), on purpose: until r5.4 this layout was read precisely, by taking the line
        # below the words as their speaker. The same lines can be the next speaker's line ("孟迟点了点头。" above a blank
        # line and his words), and then that reading paired two people's words and passed a real change unreported
        # (test_r55_review_repairs.TheLineBelowAloneNamesNobody). The line below now names nobody by itself, so here
        # the program flags what it cannot pair: a pure move is never a certain change, both real changes are flagged.
        self.assertEqual(certain(compare(before, moved)), [])
        report = compare(before, changed)
        self.assertTrue({1, 4} <= set(flagged_lines(report)), report["tone_changes"])
        for item in report["tone_changes"]:
            if item["match"] != "uncertain":
                self.assertIn((item["line"], item["before"] + "→" + item["after"]), [(1, "！→。"), (4, "。→！")])

    def test_the_moved_speakers_keep_their_own_marks_in_a_longer_run(self):
        # Five people, two of them say the same words; three paragraphs move. Only 乙's real change is reported.
        people = [("甲", "走吧。"), ("乙", "知道了！"), ("丙", "等等。"), ("丁", "知道了。"), ("戊", "走吧！")]
        before = build([(n, s, "above") for n, s in people])
        after = [(n, s, "above") for n, s in (people[3], people[0], people[4], ("乙", "知道了。"), people[2])]
        report = compare(before, build(after))
        # 乙 is the fourth paragraph now, its words on line 11. Whether the program calls that paragraph moved or kept
        # in place depends on which side of the swap it aligns; what matters is one certain change, at 乙's line.
        self.assertEqual(certain(report), [(11, "！→。")])
        self.assertEqual(flagged_lines(report), [11])


class WhenTheSpeakerCannotBeTold(unittest.TestCase):
    """Without a speaker on the next line the program may be unable to pair; then it flags, it never passes or asserts."""

    def test_without_blank_lines_a_pure_move_is_never_a_certain_change(self):
        units = [("陈青", "知道了！", "above"), ("孟迟", "知道了！", "above"), ("卢石", "知道了。", "above")]
        moved = [units[0], units[2], units[1]]
        report = compare(build(units, blank=False), build(moved, blank=False))
        self.assertEqual(certain(report), [])  # anything flagged here is "uncertain", for a person to look at

    def test_without_blank_lines_real_changes_are_still_flagged(self):
        units = [("陈青", "知道了！", "above"), ("孟迟", "知道了！", "above"), ("卢石", "知道了。", "above")]
        changed = [("陈青", "知道了。", "above"), ("卢石", "知道了！", "above"), ("孟迟", "知道了！", "above")]
        report = compare(build(units, blank=False), build(changed, blank=False))
        # 陈青 is line 2 and 卢石 line 4 in the revision; both must be in front of a person, certain or uncertain.
        self.assertTrue({2, 4} <= set(flagged_lines(report)), report["tone_changes"])
        for item in report["tone_changes"]:
            if item["match"] != "uncertain":
                self.assertIn((item["line"], item["before"] + "→" + item["after"]), [(2, "！→。"), (4, "。→！")])

    def test_speaker_in_a_separate_paragraph(self):
        # "陈青点了点头。" then, after a blank line, the words alone: who said them is not on the speech's own lines.
        units = [("陈青", "知道了！", "paragraph"), ("孟迟", "知道了！", "paragraph"), ("卢石", "知道了。", "paragraph")]
        moved = build([units[0], units[2], units[1]])
        changed = build([("陈青", "知道了。", "paragraph"), ("卢石", "知道了！", "paragraph"), ("孟迟", "知道了！", "paragraph")])
        self.assertEqual(certain(compare(build(units), moved)), [])
        report = compare(build(units), changed)
        self.assertTrue({3, 7} <= set(flagged_lines(report)), report["tone_changes"])  # 陈青 line 3, 卢石 line 7
        for item in report["tone_changes"]:
            if item["match"] != "uncertain":
                self.assertIn((item["line"], item["before"] + "→" + item["after"]), [(3, "！→。"), (7, "。→！")])

    def test_repeats_that_cannot_be_told_apart_say_why(self):
        # Changed in r5.5: this test used the layout without blank lines and with "某某低声说：" above the words. A line
        # ending with a colon now names the speaker below it, so that layout is told apart and reported precisely
        # (test_r55_review_repairs.ALineEndingInAColon). The speaker in a paragraph of its own still cannot be told.
        units = [("陈青", "知道了！", "paragraph"), ("孟迟", "知道了！", "paragraph"), ("卢石", "知道了。", "paragraph")]
        changed = [("陈青", "知道了。", "paragraph"), ("卢石", "知道了！", "paragraph"), ("孟迟", "知道了！", "paragraph")]
        report = compare(build(units), build(changed))
        unsure = [t for t in report["tone_changes"] if t["match"] == "uncertain"]
        self.assertTrue(unsure)
        self.assertEqual({t["uncertain_reason"] for t in unsure}, {"indistinct"})
        self.assertIn("分不出", unsure[0]["message"])


class RepeatedLinesInPlace(unittest.TestCase):
    """The N04 repair must not make ordinary revisions noisy or hide a change made in place."""

    def test_one_of_several_identical_lines_changed_in_place(self):
        before = "院门仍然紧紧关着。\n\n“嗯。”\n\n他把灯拧亮。\n\n“嗯。”\n\n雨还在下。\n\n“嗯。”\n"
        report = compare(before, before.replace("拧亮。\n\n“嗯。”", "拧亮。\n\n“嗯？”"))
        self.assertEqual([(t["line"], t["before"] + "→" + t["after"], t["match"]) for t in report["tone_changes"]],
                         [(7, "。→？", "same_line")])

    def test_an_edit_elsewhere_leaves_identical_lines_alone(self):
        before = "院门仍然紧紧关着。\n\n“嗯。”\n\n他把灯拧亮。\n\n“嗯！”\n\n雨还在下。\n\n“嗯。”\n"
        self.assertEqual(compare(before, before.replace("雨还在下。", "雨已经小了，檐下还在滴水。"))["tone_changes"], [])

    def test_the_attribution_reworded_and_the_mark_changed(self):
        before = ORIGINAL
        after = before.replace("陈青低声说：\n“知道了！”", "陈青压低嗓子说：\n“知道了。”")
        self.assertEqual(certain(compare(before, after)), [(2, "！→。")])


class GapsFoundWhileTakingInR52(unittest.TestCase):
    def test_an_id_spelled_by_two_checks_is_refused_end_to_end(self):
        # Review item ids are "<check id>:<item id>": check "f" with claim "x:F-y" and check "f:F-x" with claim "y"
        # both give "f:F-x:F-y". The gate refuses the run instead of letting one decision answer both.
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            (work / "candidate.md").write_text("唐野把钥匙交给了陈絮，转身出了门。\n", encoding="utf-8")
            digest = hashlib.sha256((work / "candidate.md").read_bytes()).hexdigest()
            (work / "ledger.json").write_text(json.dumps({
                "schema": "fact-ledger/1", "entities": {"key": {"name": "钥匙"}}, "chapters": {"1": {"status": "accepted"}},
                "facts": [{"id": "k1", "entity": "key", "attribute": "holder", "value": "唐野", "chapter": 1,
                           "layer": "accepted", "basis": "witnessed_action", "source": "第1章"}]}, ensure_ascii=False),
                encoding="utf-8")
            for name, claim_id in (("claims-a.json", "x:F-y"), ("claims-b.json", "y")):
                (work / name).write_text(json.dumps({
                    "schema": "fact-claims/1", "chapter": 2, "candidate": "candidate.md", "candidate_sha256": digest,
                    "extracted_by": "self_check", "claims": [{"id": claim_id, "entity": "key", "attribute": "holder",
                                                              "value": "陈絮", "basis": "witnessed_action", "change": True,
                                                              "quote": "唐野把钥匙交给了陈絮"}]}, ensure_ascii=False),
                    encoding="utf-8")
            (work / "checks.json").write_text(json.dumps({"candidate": "candidate.md", "checks": [
                {"id": "f", "type": "facts", "ledger": "ledger.json", "claims": "claims-a.json"},
                {"id": "f:F-x", "type": "facts", "ledger": "ledger.json", "claims": "claims-b.json"}]}), encoding="utf-8")
            proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPTS / "workflow_guard.py"), "check", "checks.json"],
                                  cwd=work, capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(proc.returncode, 2, proc.stdout)
            self.assertEqual(json.loads(proc.stdout)["failure"], "DUPLICATE_REVIEW_ITEM")

    def test_snapshot_hint_is_not_repeated_when_there_are_no_snapshots(self):
        # An evaluation frozen without snapshots (as older versions did): --from-snapshots cannot help, so the blocked
        # summary must not tell the user to add it.
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            for arm, text in (("base", "旧规则"), ("cand", "新规则")):
                (work / arm).mkdir()
                (work / arm / "SKILL.md").write_text(text, encoding="utf-8")

            def run(*args):
                proc = subprocess.run([sys.executable, "-I", "-B", str(DARWIN), *map(str, args)],
                                      capture_output=True, text=True, encoding="utf-8")
                return proc.returncode, json.loads(proc.stdout)

            run("freeze", work / "w", "--baseline", work / "base", "--candidate", work / "cand")
            frozen = json.loads((work / "w" / "FROZEN.json").read_text(encoding="utf-8"))
            del frozen["snapshots"]
            (work / "w" / "FROZEN.json").write_text(json.dumps(frozen, ensure_ascii=False), encoding="utf-8")
            log = (work / "w" / "SEALS.log").read_text(encoding="utf-8").splitlines()
            # Re-seal the edited FROZEN.json the way an older version would have sealed it at freeze time.
            stamp, event, _, relative = log[0].split("\t")
            digest = hashlib.sha256((work / "w" / "FROZEN.json").read_bytes()).hexdigest()
            (work / "w" / "SEALS.log").write_text("\t".join((stamp, event, digest, relative)) + "\n", encoding="utf-8")
            code, report = run("summarize", work / "w", "--from-snapshots")
            self.assertEqual(code, 2)
            self.assertIn("without snapshots", report["decision"])
            self.assertNotIn("or --from-snapshots", report["decision"])


if __name__ == "__main__":
    unittest.main()

"""Public-contract tests for opt-in system bracket checks."""

import sys
from pathlib import Path
from types import SimpleNamespace
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from system_brackets import scan_system_brackets


class SystemBracketTests(unittest.TestCase):
    def test_book_must_enable_system_checks_even_when_genre_prefers_anchors(self):
        for preference in (True, "unused-invalid-preference"):
            profile = SimpleNamespace(enable_system_bracket_anchor=preference)
            for config in (None, {}, {"enabled": False}, {"active_tags": ["凝息"]}):
                with self.subTest(config=config, preference=preference):
                    self.assertEqual(
                        scan_system_brackets(["【凝息】。"], config, genre_profile=profile), []
                    )

    def test_enabled_configuration_requires_declared_labels(self):
        for config in ({"enabled": True}, {"enabled": True, "active_tags": [], "panel_prefixes": []}):
            with self.subTest(config=config), self.assertRaises(ValueError):
                scan_system_brackets([], config)

    def test_invalid_configuration_fields_and_label_lists_are_rejected(self):
        invalid = [
            [],
            {"enabled": 1},
            {"enabled": False, "unknown": True},
            {"enabled": True, "active_tags": "凝息"},
            {"enabled": True, "active_tags": ("凝息",)},
            {"enabled": True, "active_tags": ["凝息", "凝息"]},
            {"enabled": True, "panel_prefixes": ["状态：", "状态："]},
            {"enabled": True, "active_tags": [""]},
            {"enabled": True, "active_tags": [" 凝息"]},
            {"enabled": True, "active_tags": ["【凝息】"]},
            {"enabled": True, "panel_prefixes": ["状态：\n"]},
            {"enabled": True, "active_tags": [7]},
            {"enabled": True, "active_tags": ["凝息"], "check_anchors": 1},
            {"enabled": True, "active_tags": ["凝息"], "forbid_outer_punctuation": "false"},
        ]
        for config in invalid:
            with self.subTest(config=config), self.assertRaises((TypeError, ValueError)):
                scan_system_brackets([], config)

    def test_anchor_pattern_rejects_invalid_types_syntax_and_empty_matches(self):
        for pattern in (None, 1, "[", "", ".*", r"\s*"):
            config = {"enabled": True, "active_tags": ["凝息"], "anchor_pattern": pattern}
            with self.subTest(pattern=pattern), self.assertRaises(ValueError):
                scan_system_brackets([], config)

    def test_only_registered_standalone_brackets_are_system_items(self):
        paragraphs = [
            "【收到】",
            "他启动了【凝息】。",
            "【状态：门扉关闭。】",
            "【凝息】",
            "【凝息】随即转身。",
            "【凝息】【凝息】",
        ]
        issues = scan_system_brackets(paragraphs, {
            "enabled": True, "active_tags": ["凝息"],
            "panel_prefixes": ["状态："], "check_anchors": True,
        })
        self.assertEqual([(issue["para_index"], issue["severity"]) for issue in issues], [(4, "REVIEW")])
        overlap = scan_system_brackets(["【凝息】", "【凝息状态：稳定。】"], {
            "enabled": True, "active_tags": ["凝息"],
            "panel_prefixes": ["凝"], "check_anchors": True,
        })
        self.assertEqual([(issue["para_index"], issue["rule_id"]) for issue in overlap],
                         [(1, "SYS_BRACKET_ANCHOR_REVIEW")])

    def test_anchor_pattern_fullmatches_the_previous_nonempty_paragraph(self):
        config = {"enabled": True, "active_tags": ["凝息"],
                  "check_anchors": True, "anchor_pattern": r"他握紧铜徽。"}
        self.assertEqual(scan_system_brackets(["他握紧铜徽。\r\n", "  \n", "【凝息】\n"], config), [])
        issue = scan_system_brackets(["风声里，他握紧铜徽。", "【凝息】"], config)[0]
        self.assertEqual((issue["para_index"], issue["rule_id"], issue["severity"]),
                         (2, "SYS_BRACKET_ANCHOR_FORM", "ERROR"))
        self.assertIn("不符合已配置形式", issue["reason"])
        self.assertIsNone(issue["suggestion"])

    def test_missing_anchor_with_pattern_reports_only_form_failure(self):
        issues = scan_system_brackets(["\n", "【凝息】"], {
            "enabled": True, "active_tags": ["凝息"],
            "check_anchors": True, "anchor_pattern": r"他握紧铜徽。",
        })
        self.assertEqual(len(issues), 1)
        self.assertEqual(issues[0]["severity"], "ERROR")
        self.assertIn("不符合已配置形式", issues[0]["reason"])
        self.assertNotIn("语义", issues[0]["reason"])
        self.assertIsNone(issues[0]["suggestion"])

    def test_without_anchor_pattern_requests_human_review_and_preserves_source(self):
        paragraphs = ["他停在门边。\n", "  【凝息】\r\n"]
        original = list(paragraphs)
        issue = scan_system_brackets(paragraphs, {
            "enabled": True, "active_tags": ["凝息"], "check_anchors": True,
        })[0]
        self.assertEqual(issue["rule_id"], "SYS_BRACKET_ANCHOR_REVIEW")
        self.assertEqual(issue["severity"], "REVIEW")
        self.assertIn("人工确认", issue["reason"])
        self.assertEqual(issue["snippet"], paragraphs[1])
        self.assertEqual(issue["para_index"], 2)
        self.assertIsNone(issue["suggestion"])
        self.assertEqual(paragraphs, original)
        self.assertTrue({"para_index", "rule_id", "severity", "snippet", "reason", "suggestion"} <= issue.keys())

    def test_explicit_anchor_preference_overrides_the_genre_default(self):
        enabled = {"enabled": True, "active_tags": ["凝息"]}
        true_profile = SimpleNamespace(enable_system_bracket_anchor=True)
        false_profile = SimpleNamespace(enable_system_bracket_anchor=False)
        self.assertEqual(scan_system_brackets(["【凝息】"], enabled), [])
        self.assertEqual(len(scan_system_brackets(["【凝息】"], enabled, genre_profile=true_profile)), 1)
        self.assertEqual(scan_system_brackets(["【凝息】"], {**enabled, "check_anchors": False}, genre_profile=true_profile), [])
        self.assertEqual(len(scan_system_brackets(["【凝息】"], {**enabled, "check_anchors": True}, genre_profile=false_profile)), 1)

    def test_outer_unicode_punctuation_is_checked_only_when_requested(self):
        paragraphs = ["【凝息】。", "【状态：门扉关闭。】……", "……【凝息】", "他启动了【凝息】。"]
        config = {"enabled": True, "active_tags": ["凝息"], "panel_prefixes": ["状态："]}
        self.assertEqual(scan_system_brackets(paragraphs, config), [])
        issues = scan_system_brackets(paragraphs, {**config, "forbid_outer_punctuation": True})
        self.assertEqual([issue["para_index"] for issue in issues], [1, 2, 3])
        self.assertTrue(all(issue["rule_id"] == "SYS_BRACKET_OUTER_PUNCTUATION" and issue["severity"] == "ERROR" for issue in issues))
        self.assertTrue(all(issue["suggestion"] is None for issue in issues))

    def test_active_label_final_punctuation_is_literal_mismatch_but_panel_sentence_is_valid(self):
        issues = scan_system_brackets(["【凝息。】", "【凝息……】", "【状态：门扉关闭。】"], {
            "enabled": True, "active_tags": ["凝息"], "panel_prefixes": ["状态："],
        })
        self.assertEqual([issue["para_index"] for issue in issues], [1, 2])
        self.assertTrue(all(issue["rule_id"] == "SYS_BRACKET_ACTIVE_LITERAL" and issue["severity"] == "ERROR" for issue in issues))
        self.assertTrue(all(issue["suggestion"] is None for issue in issues))

    def test_enabled_scanner_rejects_nonparagraph_input(self):
        config = {"enabled": True, "active_tags": ["凝息"]}
        for paragraphs in ("【凝息】", ["【凝息】", 7], None):
            with self.subTest(paragraphs=paragraphs), self.assertRaises(TypeError):
                scan_system_brackets(paragraphs, config)


if __name__ == "__main__":
    unittest.main()

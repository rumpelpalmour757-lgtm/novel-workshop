#!/usr/bin/env python3
"""r5.59: dialogue and scene self-correction (proposal section 3 items 1, 3, 4, 5, 6, 8, 10 and section 2 item 3).

The author read the r5.59 proposal; to the items put to him he answered that they go as the maker suggests, and to
section 3 that it goes ahead. No constitution text changes. What is pinned here and why:

- Section 2 item 3, option B: when the author hands back his own revised text at the review stage (stage 5 not yet
  confirmed; narrowed after the paired scenario tests, see below) and says it passes, the draft is not reopened.
  Each change is a finding of the author's review that can only be adopted; his text is registered as the revision;
  his pass is the conclusion of that review, not the final acceptance; stages 5, 6 and 7 are still presented and
  confirmed one by one. chapter-confirmation.md "确认是什么意思" gains the exception after "从受影响的那个阶段重开";
  learning-loop.md says how to record it. The proposal said B had not been walked through the chapter gate and would
  fall back to A if it could not be: `AuthorRevisedDraft` walks it through chapter_gate (via learning_loop.py apply)
  and learning_loop.py on synthetic text, for a chapter the workshop reviews, for one the author takes to the teacher
  (and also brings his own text), and for one where he brings only his own text (the gate refuses the review stage
  without a teacher return until the author says this chapter does not go to the teacher; narrowed after the paired
  scenario tests, see below: this one now reopens the draft). It walks through, so B stands.
  After the paired scenario tests (r5.59): the exception began "第 5 阶段还没确认的时候", which also reads true at
  stage 4 (the draft handed over, the teacher's result not back yet); on both stage-4 questions r5.58 was right four
  times out of four and r5.59 partly right four times out of four (each time for taking the exception at stage 4),
  and the maker's follow-up that the author's text "先留着、不登记" until the teacher's result comes made it worse.
  The author chose to narrow it: the exception holds only while stage 4 is confirmed and stage 5 is not, or stage 5
  is confirmed and stage 6 is not ("这条例外只管这两种时候").
  Before stage 4 is confirmed (the draft handed over, including when the author took it to the teacher and the result
  is not back), the author's own text is not the exception and not a teacher return: the draft stage is reopened and
  his text is shown as a new draft; if the chapter goes to the teacher, that new draft is what goes. The wording tests
  below pin the narrowed sentences, `NarrowedAfterThePairedTests` checks the withdrawn sentence is gone from both
  pages, and the two walk-throughs of a teacher chapter where only the author's text comes back now reopen the draft
  instead of waiting or taking the exception.
- Item 1: before lessons, a retrospective with five causes in quality-loop.md "单元之间的经验回流"; a change that
  existing rules covered but that was not followed gives no new rule. Stage 7 points there; learning-loop.md names the
  `cause` and `rule_ref` keys.
- Item 3: "整理一次：交作者定" (the workshop lists, the author decides; silence keeps an item as it is) and the
  judgment-card list at the end of the final note (only cards already marked on a draft, with their conditions and
  exceptions). Pointers from author-preferences.md, editorial-judgment.md and stage 7.
- Item 4: an induction the author struck out is not proposed again from the same evidence; a card the author withdrew
  is not remade under a new number.
- Item 5: judgment cards after the author takes an acceptance back; how the comparison made for the author is done
  (it replaces "这一页没有定，也没有验证"); the two kinds of case (whole chapter, one place).
- Item 6: the task name `chapter_revision`; re-reading the example decisions before the draft is handed in; giving the
  writer the author's own words from the run (`show --brief`); what to do after an example was misapplied.
- Item 8: a beat card the author changed becomes an example the next chapter can find: scene-dramaturgy.md section 4
  says how ("作者改过的节拍卡"), and chapter-confirmation.md stage 3 names it. (r5.59 review: the section was missing at
  first, while stage 3 already pointed at it.)
- Item 10: "自我纠错的三层" at the end of quality-loop.md, each cell only pointing at existing clauses.

Run against the r5.58 package (NW_PACKAGE_ROOT), four tests pass there too, by design: `replacement` kept and read
back by `show --brief`, a narrower case learned from the same run after the first was retired, a changed beat card
found by `demonstration_memory.py index --task scene_beat_revision` only with the author's acceptance (the proposal
found the existing scripts already do these; the tests check that they still do), and the clauses the three-layer
table points at (unchanged files). `cause`/`rule_ref` are kept by r5.58's script as well, but that test sits with the
r5.59 text it belongs to. Everything else fails on r5.58, the walk-through included (r5.58 records `self_checked`
and no `after_by`).

These tests check wording, links and what the scripts store. They do not show that the workshop corrects itself
better or writes better. The first batch of paired scenario tests ran before the narrowing; the narrowed wording
has not been retested yet.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True  # never leave __pycache__ inside the package under test
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"
REFS = SKILL / "references"
AUTHOR = {"actor_role": "author", "mode": "human"}
LINK = re.compile(r"\]\(([^)#\s]+)(#[^)\s]*)?\)")


def _helpers():
    """The store helpers of test_r559_learning_loop.py, loaded by path (they are not tests here)."""
    spec = importlib.util.spec_from_file_location("r559_store_helpers", Path(__file__).with_name("test_r559_learning_loop.py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


H = _helpers()


def read(rel):
    return (SKILL / rel).read_text(encoding="utf-8")


def section(text, heading, level="## "):
    start = text.find("\n" + level + heading)
    if start == -1:
        return ""
    end = text.find("\n" + level, start + len(level) + 1)
    if level == "### ":
        later = text.find("\n## ", start + 1)
        end = later if end == -1 or (later != -1 and later < end) else end
    return text[start:end if end != -1 else len(text)]


def row(rel, start):
    return next(line for line in read(rel).splitlines() if line.startswith(start))


def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def run(script, *args):
    proc = subprocess.run([sys.executable, "-I", "-B", str(SKILL / "scripts" / script), *map(str, args)],
                          capture_output=True, text=True, encoding="utf-8")
    return proc.returncode, proc.stdout, proc.stderr


def unlinked(text):
    """The words of a paragraph without its link targets ([words](target) -> words)."""
    return re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)


# SHA-256 of three paragraphs as drafted, word for word, in the author-approved r5.59 proposal (section 3 items 1 and
# 3; "the drafts are used word for word"). The pages add links only; the consolidation's opening words are the heading,
# and the list's opening label is written as a bold lead.
DRAFT_RETROSPECTIVE = "44296f7eb8a69c84a5d783b1dfc402d28193f646c20c2485c86c12b4666c20bc"
DRAFT_CONSOLIDATION = "3eef99594203b96041a3d52298eee2343d476cd7d7a198013ce14f7471d8dd89"
DRAFT_CARD_LIST = "afa18681661356f07fa8b7ad930921c01ca0f0d0e549450d223cb442a27c262a"


def headings_of(path):
    return [line.lstrip("#").strip() for line in path.read_text(encoding="utf-8").splitlines() if line.startswith("#")]


class Retrospective(unittest.TestCase):
    """Item 1: attribute first, then talk about lessons."""

    def setUp(self):
        self.flow = section(read("references/quality-loop.md"), "单元之间的经验回流")
        self.para = next(line for line in self.flow.splitlines() if line.startswith("**复盘：先归因，再谈经验。**"))

    def test_five_causes_and_what_each_leads_to(self):
        for phrase in ("工坊拟的原因，五选一：没有规则管到；有规则管到、这一次没照做（写明哪一页哪一节）；照规则做了反而改坏（写明哪一条）；"
                       "这一处是作者的取舍（作者亲改的，或者作者留下的）；看不出原因。",
                       "原因前标“拟”，作者一句话可以改。", "两类都写上，不由工坊二选一。",
                       "“没有规则管到”的记成候选教训；“没照做”的不提新规则，下一章写前准备把那一节列进本轮必查项；",
                       "“改坏”的列给作者，问要不要收窄那条规则或加例外；", "两样都没开的，不归纳；“看不出”的照实写，不编原因。",
                       "一章没有候选教训也是正常的，写“没有”。", "候选教训要作者认了，才照本节的 `ACCEPTED → DERIVED → LANDS_IN` 记；",
                       "这几行复盘记在工作记录里，不改任何规则，也不改正文；", "只改标点、单段润色不做这一步。"):
            self.assertIn(phrase, self.para)

    def test_it_is_the_proposals_draft_word_for_word(self):
        self.assertEqual(sha(unlinked(self.para)), DRAFT_RETROSPECTIVE)

    def test_it_comes_after_the_section_text_and_before_the_consolidation(self):
        self.assertLess(self.flow.index("不自动写进通用技能。"), self.flow.index(self.para))
        self.assertLess(self.flow.index(self.para), self.flow.index("### 整理一次：交作者定"))
        self.assertLess(self.flow.index("### 整理一次：交作者定"), self.flow.index("### 判断卡请认单（第 7 阶段）"))

    def test_stage_7_and_the_learning_record_point_there(self):
        final = row("references/chapter-confirmation.md", "| 7 `final` ")
        self.assertIn("经验先照[质量闭环](quality-loop.md)“单元之间的经验回流”里的复盘归因，只列候选教训，和“没照做”的几处各指向哪一节",
                      final)
        contract = section(read("references/learning-loop.md"), "命令与事件契约")
        self.assertIn("复盘归因的两个键也这样带（r5.59）：`cause` 写复盘的五类原因里的哪一类", contract)
        self.assertIn("`rule_ref` 写管到它的是哪一页哪一节；`show` 原样读回", contract)

    def test_the_loop_keeps_cause_and_rule_ref_and_shows_them(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = H.new_store(Path(tmp) / "学习记录.md")
            rec = H.Recorder(path, H.load_loop(ROOT))
            rec.op("start", "R", task="chapter_revision", tags=["对白"], group_id="g", input_text="原稿。", source_ref="合成",
                   constraints=[])
            rec.op("plan", "R", applications=[], checks=["合成"])
            rec.op("draft", "R", text="初稿。", source_ref="合成", actor={"name": "合成", "context_id": "w"})
            finding = {"id": "f1", "issue": "雨棚下八句没标说话人，第三个人插话以后认错了人", "evidence": "初稿。", "scope": "第2场",
                       "cause": "拟：有规则管到、这一次没照做", "rule_ref": "对白专项“谁在说：读者认不认得出”"}
            rec.op("review", "R", review_id="t1", draft_sha256=sha("初稿。"),
                   reviewer=rec.reviewer("teacher", "independent_agent", "t"), verdict="revise", findings=[finding],
                   source_ref="合成")
            rec.op("decide", "R", review_id="t1", decisions=[{"finding_id": "f1", "decision": "adopt", "reason": "补说话人",
                                                              "cause": ["拟：有规则管到、这一次没照做", "拟：这一处是作者的取舍"]}])
            code, out, err = run("learning_loop.py", "show", path, "--run-id", "R", "--brief")
            self.assertEqual(code, 0, err)
            shown = json.loads(out)["run"]
            self.assertEqual(shown["reviews"]["t1"]["findings"], [finding])
            self.assertEqual(shown["decisions"]["t1"][0]["cause"], ["拟：有规则管到、这一次没照做", "拟：这一处是作者的取舍"])


class Consolidation(unittest.TestCase):
    """Item 3: consolidate once for the author to decide; the judgment-card list at the end of the final note."""

    # r5.59 review: the card list sat under the consolidation's heading as a bold lead; it has its own heading now, so
    # the two pointers to it name it and the consolidation's section holds only the consolidation.
    def setUp(self):
        self.part = section(read("references/quality-loop.md"), "整理一次：交作者定", "### ")
        self.cards = section(read("references/quality-loop.md"), "判断卡请认单（第 7 阶段）", "### ")

    def test_the_workshop_lists_and_the_author_decides(self):
        self.assertTrue(self.part)
        for phrase in ("按五类列给作者，每条一行，带出处：拟写成规则", "拟合并", "拟收窄或加例外", "拟停用", "留着再看",
                       "工坊只列，不改；作者没回话的都当留着再看，不当同意。",
                       "对白专项、分场规范这些工坊模块里的规则，只记成维护任务，照[技能维护](skill-evaluation.md)做新旧对照；宪法只有作者能改。",
                       "技法库、参考书、教师材料里的说法只当参考，可以附在旁边给作者看，不算依据，不参与合并。",
                       "不定时跑，不自己跑。出现在几章只决定先列哪条，不决定记不记。",
                       "作者亲口说的、作者亲改确认过的已确认条目不因为只有一处依据列进来",
                       "这一步还没在真实记录上走过"):
            self.assertIn(phrase, self.part)

    def test_both_are_the_proposals_drafts_word_for_word(self):
        body = next(line for line in self.part.splitlines() if line.startswith("作者要整理的时候"))
        self.assertEqual(sha("**整理一次：交作者定。** " + unlinked(body)), DRAFT_CONSOLIDATION)
        listing = next(line for line in self.cards.splitlines() if line.startswith("开了[从改稿记录里学编辑判断]"))
        self.assertEqual(sha("（判断卡请认单，第 7 阶段）" + unlinked(listing)), DRAFT_CARD_LIST)
        self.assertNotIn("判断卡请认单", self.part)

    def test_the_judgment_card_list(self):
        self.assertTrue(self.cards)
        listing = next(line for line in self.cards.splitlines() if line.startswith("开了[从改稿记录里学编辑判断]"))
        for phrase in ("只列至少在一次自审或一份专门做给作者看的对照上标过地方的候选卡，单薄的卡不列。",
                       "它的条件和例外，或者写明卡在哪里；它标在哪一稿、哪几句上（原句、位置和当时的处置）；命中账。",
                       "只写一行“还没在稿子上标过，下一章自审以后再请你看”。", "没表态的照候选办，不催第二次。"):
            self.assertIn(phrase, listing)
        # not called "短表": that name belongs to the table shown after a teacher's return (stage 5)
        self.assertNotIn("短表", self.part + self.cards)

    def test_the_other_pages_point_there(self):
        pointer = "[质量闭环](quality-loop.md)“整理一次：交作者定”"
        self.assertIn(pointer, section(read("references/author-preferences.md"), "作者改法累计"))
        status = section(read("references/editorial-judgment.md"), "状态怎么走", "### ")
        self.assertIn(pointer, status)
        self.assertIn("定稿说明末尾的判断卡请认单见那一页的“判断卡请认单（第 7 阶段）”", status)
        final = row("references/chapter-confirmation.md", "| 7 `final` ")
        self.assertIn("定稿说明末尾附一张判断卡请认单（[质量闭环](quality-loop.md)“判断卡请认单（第 7 阶段）”，r5.59）", final)
        headings = headings_of(SKILL / "references" / "quality-loop.md")
        self.assertIn("整理一次：交作者定", headings)
        self.assertIn("判断卡请认单（第 7 阶段）", headings)


class StruckOut(unittest.TestCase):
    """Item 4: what the author struck out is not proposed again as it was."""

    def test_author_preferences_step_3(self):
        steps = section(read("references/author-preferences.md"), "从一次纠错提炼规则", "### ")
        step3 = next(line for line in steps.splitlines() if line.startswith("3. **进入有效摘要。**"))
        self.assertTrue(step3.endswith("作者划掉的归纳，记进“已撤销”，写明是作者划掉的，记下日期、原话和当时依据的证据编号。"
                                       "以后从同样的证据、或者同一类改法里又归纳出同一个意思的，不再提。"
                                       "要再提，必须有划掉以后新出现的、来自别的章或别的场的证据；再提时，把上次划掉的日期和原话放在最前面。"))

    def test_a_withdrawn_card_is_not_remade(self):
        status = section(read("references/editorial-judgment.md"), "状态怎么走", "### ")
        stop = next(line for line in status.splitlines() if line.startswith("- **停用**"))
        self.assertIn("作者撤回而停用的卡，不换个编号重做同一个判断", stop)


class JudgmentCards(unittest.TestCase):
    """Item 5: three things the judgment-card page did not say."""

    def setUp(self):
        self.text = read("references/editorial-judgment.md")

    def test_after_the_author_takes_an_acceptance_back(self):
        status = section(self.text, "状态怎么走", "### ")
        item = next(line for line in status.splitlines() if line.startswith("- **作者收回某一章的采纳、或者否定某一稿以后"))
        for phrase in ("按证据类别拿掉失效的依据，重算证据厚薄", "“留下”一类出自那一稿的（定稿里原句留着），随整章采纳一起失效",
                       "“原话”一类（作者针对这一处的逐字原话）不因为收回整章采纳而失效，照留",
                       "只剩一条案例或者一条不剩的，写“依据已失效，只留作历史”", "命中账记一行，写明原因",
                       "卡的状态（作者认可、已写进本书规则、停用）工坊不自己动，列给作者，附上作者收回采纳的原话和受影响的案例编号",
                       "规则文件里的条目等作者定了再动"):
            self.assertIn(phrase, item)

    def test_how_the_comparison_for_the_author_is_made(self):
        ledger = section(self.text, "命中账")
        self.assertNotIn("这种对照怎么做，这一页没有定，也没有验证。", self.text)
        for phrase in ("1. 选两三章作者已采纳、而且没进过这张卡提炼的。",
                       "2. 另起一个新的上下文，只给它卡和这几章正文，照“交教师以前的自审”出一份单子，不改稿。",
                       "4. 这一行写 `comparison: true`，不和正式章节的行合计。",
                       "另记一类“标了已采纳章里没改过的句子”", "作者针对这一处说了要留，才记“对不上”；作者没表态的，照上面那张表记“没人动”。",
                       "5. 回放过的章，记进这张卡“提炼用过的章和场”。",
                       "这份对照只查得出卡会不会去标已采纳章里作者没改过的句子，查不出卡漏了什么；这个做法还没验证。",
                       "所以只能叫自查，不能叫独立验证。"):
            self.assertIn(phrase, ledger)

    def test_two_kinds_of_case(self):
        kinds = section(self.text, "三种容易丢的证据")
        self.assertIn("[学习循环](learning-loop.md)登记的案例管整章，整章“定稿”是对整章那份文字的采纳；这一页的改稿案例管一处，"
                      "要作者针对这一处的话才算认可。同一处在两份记录里状态不同，是正常的。", kinds)


class RecordKeeping(unittest.TestCase):
    """Item 6: how a round and its examples are recorded (text only, plus what the scripts already keep)."""

    def test_one_task_name_for_the_chapter_round(self):
        start = section(read("references/learning-loop.md"), "在章节流程里怎么起一轮")
        self.assertIn("`task` 统一写 `chapter_revision`，前后各章一致", start)
        self.assertIn("问题出在哪里（对白、分场、说话人认不出），写进标签", start)
        table = row("references/demonstration-learning.md", "| `task`、`tags` |")
        self.assertIn("章节流程里的一轮，`task` 统一写 `chapter_revision`，问题出在哪里写进标签", table)

    def test_the_example_decisions_are_read_again_before_the_draft_goes_out(self):
        draft = row("references/chapter-confirmation.md", "| 4 `draft` ")
        for phrase in ("交出以前把写前准备里定的示范适用判断再读一遍", "定为不用的，看初稿里有没有照它的写法写",
                       "定为用的，看有没有把示范里的人物事实、时间、旧账搬过来", "查到的列给作者，不暗改", "只靠读，不做成按字面找词的扫描"):
            self.assertIn(phrase, draft)

    def test_the_writer_gets_the_authors_own_words(self):
        before = section(read("references/demonstration-learning.md"), "每次写作或改稿之前")
        step = next(line for line in before.splitlines() if line.startswith("7. "))
        for phrase in ("`learning_loop.py show --run-id 那一轮 --brief`", "读出那一轮作者本人的评审问题",
                       "作者的原话排在工坊整理的四栏前面", "只带被选中那一条所在的那一轮，不带留出组"):
            self.assertIn(phrase, step)
        self.assertTrue(any(line.startswith("8. 不迁移示范中的人物") for line in before.splitlines()))

    def test_after_an_example_was_misapplied(self):
        after = section(read("references/demonstration-learning.md"), "写后登记与纠正")
        # r5.60: the version note is gone; the steps look first and retire after ("不因为一次用错就自动退役" moved from
        # step 5 to step 2), and the last step says what the script really gives the narrower case: teacher-approved
        # when the round had a teacher's pass, a candidate only after a self-check (test_r560_records.py runs both)
        for phrase in ("**示范被用错以后。**", "在作者那条意见里写上示范编号", "先用 `case_status` 退役，理由写哪一轮哪一条意见",
                       "再从原来那一轮另登一条收窄的，新写的条件和例外在这一轮结尾列给作者看", "采纳记在那一轮上的（`author_accept`），新案例照脚本记成作者认可",
                       "采纳只记在旧案例上的（`case_accept`），不把旧案例上的原话搬过来", "那一轮只有自查的，新案例停在候选",
                       "不因为一次用错就自动退役。"):
            self.assertIn(phrase, after)
        # r5.59 review: step 4 quotes the paragraph under the contract table by its own opening words
        quoted = "案例的依据、条件、例外和取舍四栏"
        self.assertIn("（上文“最小案例契约”表下“" + quoted + "”那一段）", after)
        contract = section(read("references/demonstration-learning.md"), "最小案例契约")
        self.assertTrue(any(line.startswith(quoted) for line in contract.splitlines()))
        narrower = "案例退役以后，可以从同一轮另登一条收窄的，旧的留在历史里"
        self.assertIn(narrower, after)
        self.assertIn(narrower, section(read("references/learning-loop.md"), "每次执行"))

    def test_a_narrower_case_from_the_same_run_after_retiring(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = H.new_store(Path(tmp) / "学习记录.md")
            rec = H.Recorder(path, H.load_loop(ROOT))
            for run_id, accept in (("on-run", True), ("on-case", False)):
                rec.op("start", run_id, task="chapter_revision", tags=[run_id], group_id=run_id, input_text="原稿。" + run_id,
                       source_ref="合成", constraints=[])
                rec.op("plan", run_id, applications=[], checks=["合成"])
                text = "终稿。" + run_id
                rec.op("draft", run_id, text=text, source_ref="合成", actor={"name": "合成", "context_id": "w"})
                rec.op("review", run_id, review_id="p", draft_sha256=sha(text),
                       reviewer=rec.reviewer("writer", "self_check", "w"), verdict="pass", findings=[], source_ref="合成")
                rec.op("finish", run_id, draft_sha256=sha(text))
                if accept:
                    rec.op("author_accept", run_id, draft_sha256=sha(text), quote="采纳当前稿。", source_ref="合成对话", **AUTHOR)
                rec.op("learn", run_id, case_id=run_id + "-1", why="合成。", when=["熟客"], decisions=["合成"],
                       **{"except": []})
                if not accept:
                    rec.op("case_accept", case_id=run_id + "-1", case_sha256=sha(text), quote="采纳当前稿。",
                           source_ref="合成对话", **AUTHOR)
                # a second case from the same run is refused while the first is live
                self.assertEqual(rec.refused("learn", run_id, case_id=run_id + "-x", why="合成。", when=["熟客"],
                                             decisions=["合成"], **{"except": []}).code, "invalid_transition")
                rec.op("case_status", case_id=run_id + "-1", status="retired", reason="作者在第2章说别照搬：" + run_id)
                rec.op("learn", run_id, case_id=run_id + "-2", why="合成。", when=["熟客", "对方提过自己几点要用"],
                       decisions=["合成"], **{"except": ["对方是头一回来的生客"]})
            cases = H.payload_of(path)["data"]["demonstrations"]
            self.assertEqual({key: case["status"] for key, case in cases.items()},
                             {"on-run-1": "retired", "on-run-2": "author_accepted",
                              "on-case-1": "retired", "on-case-2": "candidate"})

    def test_replacement_is_kept_and_read_back_by_show_brief(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = H.new_store(Path(tmp) / "学习记录.md")
            rec = H.Recorder(path, H.load_loop(ROOT))
            rec.op("start", "R", task="chapter_revision", tags=[], group_id="g", input_text="原稿。", source_ref="合成",
                   constraints=[])
            rec.op("plan", "R", applications=[], checks=["合成"])
            rec.op("draft", "R", text="初稿全文。", source_ref="合成", actor={"name": "合成", "context_id": "w"})
            finding = {"id": "A1", "issue": "作者没说理由", "evidence": "初稿全文。", "scope": "第1段", "replacement": "作者的改句。"}
            rec.op("review", "R", review_id="a", draft_sha256=sha("初稿全文。"), reviewer=rec.reviewer("author", "human", "a"),
                   verdict="revise", findings=[finding], source_ref="合成对话")
            code, out, err = run("learning_loop.py", "show", path, "--run-id", "R", "--brief")
            self.assertEqual(code, 0, err)
            run_view = json.loads(out)["run"]
            self.assertEqual(run_view["reviews"]["a"]["findings"][0]["replacement"], "作者的改句。")
            self.assertEqual(run_view["drafts"][0]["text"], {"sha256": sha("初稿全文。"), "chars": 5})


DRAFT = ("阿梅把一摞饭盒放在柜台上。\n\n“老板，麻烦您帮我热一下这几个饭盒，我们工地上的人都等着吃饭。”阿梅说。\n\n"
         "周伯放下报纸：“好的，没问题。微波炉有点慢，大概需要十分钟，请你稍等一下。”")
MINE = "阿梅把一摞饭盒放在柜台上。\n\n“周伯，老规矩。”\n\n周伯没抬眼，把报纸折了一道：“又是七个？”"
TEACHER = "教师意见：第三段周伯那句像店员背话术，可以短一点。"
CHANGES = [{"id": "A1", "issue": "她跟周伯熟，不说“麻烦您”。", "evidence": "“老板，麻烦您帮我热一下这几个饭盒，我们工地上的人都等着吃饭。”阿梅说。",
            "scope": "第2段", "replacement": "“周伯，老规矩。”"},
           {"id": "A2", "issue": "作者没说理由", "evidence": "周伯放下报纸：“好的，没问题。微波炉有点慢，大概需要十分钟，请你稍等一下。”",
            "scope": "第3段", "replacement": "周伯没抬眼，把报纸折了一道：“又是七个？”"}]
SAID = "合成对话#作者交回亲改稿：这版我自己改好了，通过。"


class AuthorRevisedDraft(unittest.TestCase):
    """Section 2 item 3, option B, in the pages and through the scripts."""

    def test_the_exception_in_the_stages(self):
        meaning = section(read("references/chapter-confirmation.md"), "确认是什么意思")
        line = next(l for l in meaning.splitlines() if l.startswith("- 作者改了来源、方案或正文，从受影响的那个阶段重开"))
        self.assertTrue(line.startswith("- 作者改了来源、方案或正文，从受影响的那个阶段重开，它后面的旧确认作废，历史留着。例外（r5.59）："))
        # r5.59, after the paired scenario tests (see the module docstring): the exception is narrowed to two times,
        # so it now opens with "第 4 阶段已经确认、第 5 阶段还没确认的时候" (it opened with "第 5 阶段还没确认的时候", which
        # also reads true at stage 4); a stage-4 hand-back is not registered as a teacher return ("不算例外，也不登记成
        # 教师回传", where the old line said "作者的稿子不登记成教师回传"), and "不交了" became "不交教师了".
        self.assertTrue(line.startswith("- 作者改了来源、方案或正文，从受影响的那个阶段重开，它后面的旧确认作废，历史留着。"
                                        "例外（r5.59）：第 4 阶段已经确认、第 5 阶段还没确认的时候（初稿由作者交教师的章，还要已经登记了教师回传），"))
        for phrase in ("第 4 阶段已经确认、第 5 阶段还没确认的时候（初稿由作者交教师的章，还要已经登记了教师回传），作者交回自己改过的整份稿子、并且说了通过的，算作者自己审过、改定了这几处，初稿不重开",
                       "第 5 阶段交“作者改了哪几处”的对照和方案", "第 6 阶段交作者的稿子和复查，复查只标问题，不改作者的字，等作者确认",
                       "第 7 阶段照常交定稿，采纳照作者在这一阶段的原话记", "作者的“通过”是他自己那条评审的结论，不是定稿采纳",
                       "作者交回改稿、没说通过的，先问一句", "不算例外，也不登记成教师回传",
                       "这时候作者交回改稿、又说这一章不交教师了的，照样从第 4 阶段重开，另照上面“两项策略”用 `chapter_policy` 记原话",
                       "学习记录怎么记，见[学习循环](learning-loop.md)“在章节流程里怎么起一轮”"):
            self.assertIn(phrase, line)
        self.assertNotIn("例外（r5.59）：第 5 阶段还没确认的时候", line)
        # the seven stages are still presented and confirmed one by one
        self.assertIn("七个阶段逐个交成果、逐个等作者确认，不跳、不并", read("references/chapter-confirmation.md"))

    def test_how_the_round_records_it(self):
        start = section(read("references/learning-loop.md"), "在章节流程里怎么起一轮")
        for phrase in ("**作者在审稿阶段交回自己改过的稿子（r5.59）。**", "另带 `replacement` 写作者的改句，连标点照原样",
                       "这些问题只能记 `adopt`", "`text` 是作者交回的全文，一字不改；`actor` 带 `role:\"author\"`",
                       "这是作者那条评审的结论，不是定稿采纳：凭它 `finish`，`completion` 记 `author_reviewed`",
                       "在这一轮里不另记成通过的评审", "`source.after_by` 是 `author`", "第 1、2 步要等作者确认了第 5 阶段的方案再记",
                       "作者的稿子不登记成教师回传", "没有在真实章节上走过"):
            self.assertIn(phrase, start)
        # r5.59 review: the script holds back the decision and the revision, not the review; a teacher chapter where
        # only the author's text comes back needed the policy changed first (since the narrowing after the paired
        # scenario tests, such a chapter reopens the draft instead); other reviews of the draft (the teacher's,
        # the self-review) are decided and rechecked too. "取舍由谁定" comes after this section, so the two pointers to
        # it here say "下文" (the first wording said "上文"; changed in the review before delivery, r5.59).
        self.assertNotIn("上文“取舍由谁定”", start)
        self.assertEqual(start.count("（下文“取舍由谁定”第 4 条）"), 1)
        for phrase in ("第 1 步的取舍和第 2 步的改稿，脚本要等第 5 阶段确认了才收（下文“取舍由谁定”第 3 条）；第 1 步的评审脚本不拦，也等确认以后再记。",
                       # r5.59, after the paired scenario tests (see the module docstring): with no teacher return
                       # registered, the author's own text is not the exception; the round is not started and the
                       # draft stage is reopened. This replaces "章节门不收第 5 阶段的展示，先照……例外问作者这一章还交不交
                       # 教师；作者说不交了、用 `chapter_policy` 换了策略以后，再照上面记；作者说还要交的，作者的稿子先留着、
                       # 不登记……" (the wrap-up's section 6, item 3, withdrawn).
                       # r5.60: the sentence read as covering a chapter the workshop reviews, and "章节门也不收第 5 阶段的
                       # 展示" holds only while no return is registered (the gate takes the author's own text as a
                       # teacher return); reworded, see test_r560_confirm.py
                       "这样的章节，教师回传还没登记、作者只带回自己的稿子的，不算例外，这一轮不起；没有登记回传，章节门不收第 5 阶段的展示，"
                       "作者的稿子也不登记成教师回传（登记了脚本分不出，照收，靠条文拦）：照“确认是什么意思”"
                       "从第 4 阶段重开，作者的稿子当新的一版初稿交作者确认，作者要交教师的，交的就是这一版。",
                       "这一稿上别的评审（教师意见、交教师以前的自审单）也要先逐条取舍完，作者的稿子已经改掉或者没动的，照实写理由。",
                       "（这一稿另有教师意见、自审单要复查的也列上）"):
            self.assertIn(phrase, start)
        self.assertNotIn("脚本本来就拦", start)

    # -- walked through the chapter gate and the learning loop on synthetic text
    def book(self, tmp):
        path = H.new_store(Path(tmp) / "学习记录.md")
        return path, H.Recorder(path, H.load_loop(ROOT))

    def to_draft(self, rec, quote, **policy):
        rec.gate("chapter_policy", "ch01", author_quote=quote, source_ref="合成对话#policy", **policy, **AUTHOR)
        for stage, words in (("scope", "好"), ("outline", "继续"), ("preparation", "写吧")):
            rec.stage("ch01", stage, words)
        return rec.stage("ch01", "draft", "可以交老师", artifact=sha(DRAFT))

    def start(self, rec):
        result = rec.op("start", "R", task="chapter_revision", tags=["对白"], group_id="ch01", input_text=DRAFT,
                        source_ref="ch01 已确认初稿", constraints=[], chapter_id="ch01")
        self.assertEqual(result["chapter_link"], "ch01")
        rec.op("plan", "R", applications=[], checks=["作者改的字一个不动"])
        rec.op("draft", "R", text=DRAFT, source_ref="ch01 初稿", actor={"name": "工坊写作者", "context_id": "w1"})

    def authors_text(self, rec, teacher_return=None, self_review=False):
        review = {"teacher_return_id": teacher_return} if teacher_return else {}
        shown = rec.gate("present", "ch01", "review", content="作者改了两处，原句和改句并排；拟处置照作者的。",
                         source_ref="合成工作记录#review", **review)
        rec.gate("confirm", "ch01", "review", presentation_id=shown["presentation_id"],
                 presentation_version=shown["presentation_version"], author_quote="好，就这样", source_ref="合成对话#5", **AUTHOR)
        # r5.59 review: the author's review comes after stage 5 is confirmed, as learning-loop.md says for a chapter
        # taken to the teacher (the script itself holds back only the decision and the revision)
        rec.op("review", "R", review_id="author-own", draft_sha256=sha(DRAFT), reviewer=rec.reviewer("author", "human", "a"),
               verdict="revise", findings=CHANGES, source_ref=SAID)
        if teacher_return:
            rec.op("decide", "R", review_id="teacher-1",
                   decisions=[{"finding_id": "T1", "decision": "adopt", "reason": "作者亲改稿已照这个方向改了"}])
        rec.op("decide", "R", review_id="author-own",
               decisions=[{"finding_id": c["id"], "decision": "adopt", "reason": "作者亲改"} for c in CHANGES])
        others = (["teacher-1"] if teacher_return else []) + (["self-1"] if self_review else [])
        if self_review:
            # step 2: the self-review of the draft is decided before the author's text is registered
            self.assertIn("Decide every current-draft review before revision", str(rec.refused(
                "revise", "R", parent_sha256=sha(DRAFT), review_id="author-own", text=MINE, source_ref="作者交回的亲改稿",
                actor={"name": "作者", "context_id": "a", "role": "author"})))
            rec.op("decide", "R", review_id="self-1",
                   decisions=[{"finding_id": "S1", "decision": "adopt", "reason": "作者的稿子已经把这一处改掉了"}])
        rec.op("revise", "R", parent_sha256=sha(DRAFT), review_id="author-own", text=MINE, source_ref="作者交回的亲改稿",
               actor={"name": "作者", "context_id": "a", "role": "author"})
        if self_review:
            # step 3: the author's pass lists the self-review among its rechecks, or the round cannot finish
            rec.op("review", "R", review_id="author-pass-short", draft_sha256=sha(MINE),
                   reviewer=rec.reviewer("author", "human", "a"), verdict="pass", findings=[], rechecks=["author-own"],
                   source_ref=SAID)
            self.assertIn("needs a passing review and all required rechecks",
                          str(rec.refused("finish", "R", draft_sha256=sha(MINE))))
        rec.op("review", "R", review_id="author-pass", draft_sha256=sha(MINE), reviewer=rec.reviewer("author", "human", "a"),
               verdict="pass", findings=[], rechecks=["author-own"] + others, source_ref=SAID)
        rec.stage("ch01", "revision", "好", artifact=sha(MINE))
        rec.op("finish", "R", draft_sha256=sha(MINE))
        rec.stage("ch01", "final", "定稿。", artifact=sha(MINE), final=True)
        rec.op("author_accept", "R", draft_sha256=sha(MINE), quote="定稿。", source_ref="合成对话#7", **AUTHOR)
        rec.op("learn", "R", case_id="case-ch01", why="熟客之间不报来意。", when=["熟客来办常办的事"], decisions=["照作者亲改稿"],
               tags=["对白", "熟人之间"], **{"except": ["对方是头一回来的生客"]})

    def check_outcome(self, path):
        data = H.payload_of(path)["data"]
        run_record, case = data["learning_runs"]["R"], data["demonstrations"]["case-ch01"]
        self.assertEqual(run_record["completion"], "author_reviewed")
        self.assertEqual((case["status"], case["source"]["after_by"], case["before"], case["after"]),
                         ("author_accepted", "author", DRAFT, MINE))
        history = data["chapter_confirmations"]["ch01"]["history"]
        self.assertFalse(any(item["action"] == "reopen" for item in history), "the draft is not reopened")
        self.assertEqual([item["stage"] for item in history if item.get("status") == "confirmed"],
                         ["scope", "outline", "preparation", "draft", "review", "revision", "final"])
        code, out, err = run("chapter_gate.py", "status", path, "--chapter-id", "ch01")
        self.assertEqual(json.loads(out)["status"], "final_confirmation_recorded", err)
        # the next chapter finds it under chapter_revision
        code, out, err = run("learning_loop.py", "context", path, "--project-id", "book", "--task", "chapter_revision",
                             "--exclude-group", "ch02")
        self.assertEqual([c["id"] for c in json.loads(out)["cases"]], ["case-ch01"], err)
        return data

    def test_a_chapter_the_workshop_reviews(self):
        with tempfile.TemporaryDirectory() as tmp:
            path, rec = self.book(tmp)
            self.to_draft(rec, "这一章不看图，也不交老师。", visual_required=False, teacher_handoff="host")
            self.start(rec)
            self.authors_text(rec)
            self.check_outcome(path)

    def test_a_chapter_with_a_self_review_of_the_draft(self):
        # r5.59 review: with the self-review of editorial-judgment.md on, the round also holds the writer's self-review
        with tempfile.TemporaryDirectory() as tmp:
            path, rec = self.book(tmp)
            self.to_draft(rec, "这一章不看图，也不交老师。", visual_required=False, teacher_handoff="host")
            self.start(rec)
            rec.op("review", "R", review_id="self-1", draft_sha256=sha(DRAFT), reviewer=rec.reviewer("writer", "self_check", "w1"),
                   verdict="revise", findings=[{"id": "S1", "issue": "照候选卡标出：熟客之间不说客套话", "evidence": "请你稍等一下",
                                                "scope": "第3段"}], source_ref="合成自审单")
            self.authors_text(rec, self_review=True)
            self.check_outcome(path)

    def test_a_chapter_taken_to_the_teacher(self):
        with tempfile.TemporaryDirectory() as tmp:
            path, rec = self.book(tmp)
            draft = self.to_draft(rec, "这一章不看图。", visual_required=False)
            confirmed = draft["last_valid_confirmation"]
            returned = rec.gate("teacher_return", "ch01", draft_presentation_id=confirmed["presentation_id"],
                                draft_presentation_version=confirmed["presentation_version"], draft_sha256=sha(DRAFT),
                                returned_text=TEACHER, source_ref="合成对话#回传", teacher_name="未知")
            self.start(rec)
            rec.op("review", "R", review_id="teacher-1", draft_sha256=sha(DRAFT),
                   reviewer=rec.reviewer("teacher", "author_return", "t"), verdict="revise",
                   findings=[{"id": "T1", "issue": "像店员背话术", "evidence": "请你稍等一下", "scope": "第3段"}],
                   source_ref="合成对话#回传", teacher_return_id=returned["teacher_return_id"])
            # before the author confirms the stage-5 plan, decide waits (the page says to wait as well)
            self.assertEqual(rec.refused("decide", "R", review_id="teacher-1", decisions=[
                {"finding_id": "T1", "decision": "adopt", "reason": "合成"}]).code, "chapter_gate_first")
            self.authors_text(rec, returned["teacher_return_id"])
            data = self.check_outcome(path)
            self.assertEqual([r["returned_text"] for r in data["chapter_confirmations"]["ch01"]["teacher_returns"]], [TEACHER])

    def reopen_with_the_authors_text(self, rec, path):
        """r5.59, after the paired scenario tests: the teacher's result is not back, so the author's own text is not
        the exception. No round starts on the old draft, the draft stage is reopened with the author's words, and his
        text is shown as a new draft (with its hash) for him to confirm."""
        rec.gate("reopen", "ch01", "draft", reason="作者交回自己改过的稿子，当新的一版初稿", author_quote=SAID,
                 source_ref="合成对话#作者交回改稿", **AUTHOR)
        confirmed = rec.stage("ch01", "draft", "这一版可以", artifact=sha(MINE))["last_valid_confirmation"]
        self.assertEqual((confirmed["stage"], confirmed["artifact_sha256"]), ("draft", sha(MINE)))
        # a round bound to the old draft is refused now; one on the author's text (the new draft) can start
        refused = rec.refused("start", "R", task="chapter_revision", tags=["对白"], group_id="ch01", input_text=DRAFT,
                              source_ref="ch01 旧初稿", constraints=[], chapter_id="ch01")
        self.assertEqual(refused.code, "chapter_gate_first")
        history = H.payload_of(path)["data"]["chapter_confirmations"]["ch01"]["history"]
        self.assertEqual([item["stage"] for item in history if item["action"] == "reopen"], ["draft"])
        drafts = [item for item in history if item["action"] == "present" and item["stage"] == "draft"]
        self.assertEqual([(item["status"], item["artifact_sha256"]) for item in drafts],
                         [("invalidated", sha(DRAFT)), ("confirmed", sha(MINE))])
        return confirmed

    def test_only_the_authors_text_comes_back_for_a_teacher_chapter(self):
        # r5.59, after the paired scenario tests (see the module docstring): this walked the exception after the author
        # said the chapter no longer goes to the teacher. Now the author's text, brought back before any teacher result,
        # reopens the draft stage and becomes the new draft; the author's word on the teacher is recorded with
        # chapter_policy, and the workshop's own review of the new draft comes next.
        with tempfile.TemporaryDirectory() as tmp:
            path, rec = self.book(tmp)
            self.to_draft(rec, "这一章不看图。", visual_required=False)
            # the gate does not take the stage-5 plan without a teacher return
            self.assertEqual(rec.refused_gate("present", "ch01", "review", content="作者改了两处", source_ref="合成").code,
                             "invalid_transition")
            self.reopen_with_the_authors_text(rec, path)
            rec.gate("chapter_policy", "ch01", teacher_handoff="host", author_quote="这一章不交老师了，我自己改好了。",
                     source_ref="合成对话#改主意", **AUTHOR)
            result = rec.op("start", "R", task="chapter_revision", tags=["对白"], group_id="ch01", input_text=MINE,
                            source_ref="ch01 已确认初稿（作者交回的那一版）", constraints=[], chapter_id="ch01")
            self.assertEqual(result["chapter_link"], "ch01")
            code, out, err = run("chapter_gate.py", "status", path, "--chapter-id", "ch01")
            status = json.loads(out)
            self.assertEqual((status["current_stage"], status["next_action"], status["last_valid_confirmation"]["stage"]),
                             ("review", "present", "draft"), err)
            data = H.payload_of(path)["data"]
            self.assertEqual(data["chapter_confirmations"]["ch01"].get("teacher_returns", []), [])
            self.assertEqual(data["learning_runs"]["R"].get("completion"), None)

    # -- r5.59 wrap-up (decisions section 6, items 3 and 10), walked through the same scripts on synthetic text; item 3
    # was withdrawn after the paired scenario tests, and its walk-through now reopens the draft (see the module docstring)
    WORKSHOPS = "阿梅把一摞饭盒放在柜台上。\n\n“周伯，热一下。”\n\n周伯放下报纸：“几个？”"
    AT_SIX = [{"id": "A1", "issue": "作者没说理由", "evidence": "“周伯，热一下。”", "scope": "第2段",
               "replacement": "“周伯，老规矩。”"},
              {"id": "A2", "issue": "他不放下报纸，眼睛还在报上。", "evidence": "周伯放下报纸：“几个？”", "scope": "第3段",
               "replacement": "周伯没抬眼，把报纸折了一道：“又是七个？”"}]

    def test_the_wording_of_the_wrap_up(self):
        meaning = section(read("references/chapter-confirmation.md"), "确认是什么意思")
        line = next(l for l in meaning.splitlines() if l.startswith("- 作者改了来源、方案或正文，从受影响的那个阶段重开"))
        # r5.59, after the paired scenario tests (see the module docstring): the stage-6 sentence now names both ends
        # ("第 5 阶段已经确认、第 6 阶段还没确认的时候"); the wrap-up's "先问作者这一章还交不交教师……作者说还要交的，作者的
        # 稿子先留着、不登记，等教师结果带回、登记了回传，再照这条例外办" (section 6, item 3) is withdrawn, and the line says
        # instead that the exception holds only at those two times and what a hand-back before stage 4 is confirmed is.
        for phrase in ("第 5 阶段已经确认、第 6 阶段还没确认的时候，作者交回自己改过的修订稿、并且说了通过的，同样算作者审过、改定了这几处："
                       "重新展示第 6 阶段，交作者的稿子和复查，旧的展示记成被取代，前面的阶段不重开，学习记录收尾记 `author_reviewed`。",
                       "这条例外只管这两种时候。第 4 阶段还没确认，或者初稿由作者交教师、教师回传还没登记的时候（包括作者确认了可以交教师、教师结果还没带回），"
                       "作者只交回自己改过的稿子、没有一起带回教师结果的，不算例外，也不登记成教师回传：照这一条开头那句，从第 4 阶段重开，把作者的稿子当新的一版初稿交作者确认，"
                       "带版本名或哈希，写明改了哪几处；作者要交教师的，交的就是这一版。"
                       "这时候作者交回改稿、又说这一章不交教师了的，照样从第 4 阶段重开，另照上面“两项策略”用 `chapter_policy` 记原话。"):
            self.assertIn(phrase, line)
        for gone in ("先问作者这一章还交不交教师", "作者的稿子先留着、不登记", "再照这条例外办"):
            self.assertNotIn(gone, line)
        start = section(read("references/learning-loop.md"), "在章节流程里怎么起一轮")
        for phrase in ("这样的章节，教师回传还没登记、作者只带回自己的稿子的，不算例外，这一轮不起；",  # r5.60: reworded, see above
                       "作者在第 6 阶段交回自己改过的修订稿、并且说了通过的，同样算作者审过、改定（照上面这条的意思补的，r5.59）",
                       "这条评审绑工坊交出的那一版修订稿", "凭它 `finish`，`completion` 记 `author_reviewed`",
                       "章节门重新展示第 6 阶段，绑作者的稿子，旧的展示记成被取代（`superseded`），前面的阶段不重开。",
                       "这一段也只在合成材料上走过（r5.59）。"):
            self.assertIn(phrase, start)

    def test_the_author_says_the_chapter_still_goes_to_the_teacher(self):
        # The author's own text comes back before the teacher's result and he says the chapter still goes to the
        # teacher. r5.59 wrap-up (section 6, item 3, way (a)) had his text wait, unrecorded, until the teacher's result
        # was registered, and then the stage-5 exception. After the paired scenario tests the author chose to narrow the
        # exception and that way is withdrawn (see the module docstring): the draft stage is reopened, his text is the
        # new draft, and the new draft is what goes to the teacher. A teacher return bound to the old draft is refused.
        with tempfile.TemporaryDirectory() as tmp:
            path, rec = self.book(tmp)
            old = self.to_draft(rec, "这一章不看图。", visual_required=False)["last_valid_confirmation"]
            self.assertEqual(rec.refused_gate("present", "ch01", "review", content="作者改了两处", source_ref="合成").code,
                             "invalid_transition")
            new = self.reopen_with_the_authors_text(rec, path)
            self.assertEqual(rec.refused_gate("teacher_return", "ch01", draft_presentation_id=old["presentation_id"],
                                              draft_presentation_version=old["presentation_version"], draft_sha256=sha(DRAFT),
                                              returned_text=TEACHER, source_ref="合成对话#教师回来了",
                                              teacher_name="未知").code, "invalid_transition")
            returned = rec.gate("teacher_return", "ch01", draft_presentation_id=new["presentation_id"],
                                draft_presentation_version=new["presentation_version"], draft_sha256=sha(MINE),
                                returned_text=TEACHER, source_ref="合成对话#教师回来了", teacher_name="未知")
            result = rec.op("start", "R", task="chapter_revision", tags=["对白"], group_id="ch01", input_text=MINE,
                            source_ref="ch01 已确认初稿（作者交回的那一版）", constraints=[], chapter_id="ch01")
            self.assertEqual(result["chapter_link"], "ch01")
            shown = rec.gate("present", "ch01", "review", content="教师意见的对照和修订方案", source_ref="合成工作记录#review",
                             teacher_return_id=returned["teacher_return_id"])
            chapter = H.payload_of(path)["data"]["chapter_confirmations"]["ch01"]
            review = next(item for item in chapter["history"] if item.get("presentation_id") == shown["presentation_id"])
            self.assertEqual((review["stage"], review["status"], review["teacher_return_id"]),
                             ("review", "pending", returned["teacher_return_id"]))
            self.assertEqual([(r["returned_text"], r["draft_sha256"]) for r in chapter["teacher_returns"]],
                             [(TEACHER, sha(MINE))])
            self.assertFalse(any(item["action"] == "chapter_policy" and item.get("teacher_handoff") == "host"
                                 for item in chapter["history"]), "the policy is not changed")

    def test_the_authors_own_revision_at_stage_6(self):
        # Item 10: at stage 6 the author hands back his own revision of the workshop's revision and says it passes.
        with tempfile.TemporaryDirectory() as tmp:
            path, rec = self.book(tmp)
            self.to_draft(rec, "这一章不看图，也不交老师。", visual_required=False, teacher_handoff="host")
            self.start(rec)
            rec.op("review", "R", review_id="self-1", draft_sha256=sha(DRAFT), reviewer=rec.reviewer("writer", "self_check", "w1"),
                   verdict="revise", findings=[{"id": "S1", "issue": "熟客之间不报全套来意", "evidence": "麻烦您帮我热一下这几个饭盒",
                                                "scope": "第2段"}], source_ref="合成自审")
            rec.stage("ch01", "review", "照这个方案改")
            rec.op("decide", "R", review_id="self-1",
                   decisions=[{"finding_id": "S1", "decision": "adopt", "reason": "作者确认了方案"}])
            rec.op("revise", "R", parent_sha256=sha(DRAFT), review_id="self-1", text=self.WORKSHOPS, source_ref="工坊修订稿",
                   actor={"name": "工坊写作者", "context_id": "w1", "role": "writer"})
            first = rec.gate("present", "ch01", "revision", content="工坊的修订稿和复查", source_ref="合成工作记录#revision",
                             artifact_sha256=sha(self.WORKSHOPS))
            # instead of confirming, the author hands back his own revision and says it passes
            rec.op("review", "R", review_id="author-own", draft_sha256=sha(self.WORKSHOPS),
                   reviewer=rec.reviewer("author", "human", "a"), verdict="revise", findings=self.AT_SIX, source_ref=SAID)
            rec.op("decide", "R", review_id="author-own",
                   decisions=[{"finding_id": c["id"], "decision": "adopt", "reason": "作者亲改"} for c in self.AT_SIX])
            rec.op("revise", "R", parent_sha256=sha(self.WORKSHOPS), review_id="author-own", text=MINE,
                   source_ref="作者交回的修订稿", actor={"name": "作者", "context_id": "a", "role": "author"})
            rec.op("review", "R", review_id="author-pass", draft_sha256=sha(MINE), reviewer=rec.reviewer("author", "human", "a"),
                   verdict="pass", findings=[], rechecks=["author-own", "self-1"], source_ref=SAID)
            rec.stage("ch01", "revision", "好", artifact=sha(MINE))  # stage 6 presented again, on the author's text
            rec.op("finish", "R", draft_sha256=sha(MINE))
            rec.stage("ch01", "final", "定稿。", artifact=sha(MINE), final=True)
            rec.op("author_accept", "R", draft_sha256=sha(MINE), quote="定稿。", source_ref="合成对话#7", **AUTHOR)
            rec.op("learn", "R", case_id="case-ch01", why="熟客之间不报来意。", when=["熟客来办常办的事"], decisions=["照作者亲改稿"],
                   tags=["对白", "熟人之间"], **{"except": ["对方是头一回来的生客"]})
            data = self.check_outcome(path)
            shown = [item for item in data["chapter_confirmations"]["ch01"]["history"]
                     if item.get("action") == "present" and item["stage"] == "revision"]
            self.assertEqual([item["status"] for item in shown], ["superseded", "confirmed"])
            self.assertEqual(shown[0]["presentation_id"], first["presentation_id"])
            self.assertEqual((shown[0]["artifact_sha256"], shown[1]["artifact_sha256"]), (sha(self.WORKSHOPS), sha(MINE)))
            self.assertEqual(shown[0]["superseded_by"], shown[1]["presentation_id"])


class BeatCardExamples(unittest.TestCase):
    """Item 8: a beat card the author changed becomes an example the next chapter can find."""

    CARD = "- **Scene ID / Chapter**: ch01-s2\n- **Scene Type**: Core Conflict\n- **道具**：柜台上的钱\n"
    THEIRS = "- **Scene ID / Chapter**: ch01-s2\n- **Scene Type**: Other\n- **Change**：她替孩子赔了不是\n- **道具**：她带来的一兜橘子\n"

    def test_stage_3_names_it(self):
        preparation = row("references/chapter-confirmation.md", "| 3 `preparation` ")
        for phrase in ("节拍卡的示范（作者改过的节拍卡，任务名 `scene_beat_revision`）逐条判断条件和例外", "卡怎么改仍由作者定",
                       "顺带问一句采不采纳改定的那张卡，确认这一阶段的“继续”“好”不算对卡的采纳",
                       "[分场规范](scene-dramaturgy.md)第 4 节“作者改过的节拍卡”"):
            self.assertIn(phrase, preparation)
        # stage 3 still lists candidate judgment cards by number and title only (test_r555_editorial_judgment.py)
        self.assertLess(preparation.index("scene_beat_revision"), preparation.index("候选判断卡只列编号和标题"))

    def test_the_scene_page_says_how(self):
        # r5.59 review: proposal section 3 item 8 ("改什么"), in the workshop's words ("你" -> "作者") with links for line
        # numbers; stage 3 pointed here before the section had it
        four = section(read("references/scene-dramaturgy.md"), "4. 在工坊里怎样执行")
        start = four.index("- **作者改过的节拍卡（r5.59）**")
        item = four[start:four.index("\n- **", start + 1)]
        for phrase in ("开了[示范记忆](demonstration-learning.md)和[学习循环](learning-loop.md)的书，作者改了节拍卡的场型、极性、道具或"
                       "“这一场谁在乎什么”，就另起一轮不带章节编号的学习：",
                       "  - `task` 写 `scene_beat_revision`；", "  - 改前，是工坊交作者看的那一版卡，或者作者确认过、后来又改的那一版；",
                       "  - 改后，是作者改定的卡；", "  - 作者的理由，记成作者那条评审里的问题。",
                       "下一章填节拍卡以前，用 `demonstration_memory.py index --task scene_beat_revision` 看一遍，逐条判断条件和例外。"
                       "卡怎么改仍是作者定，不按场型的字面套用。",
                       "这样的案例，要有作者对改定那张卡的明确采纳原话，才进检索：`index` 只返回教师认可和作者认可的案例，"
                       "作者认可要有指向这一条、这一版的原话",
                       "可以在第 3 阶段顺带问作者一句。作者确认第 3 阶段时回的“继续”“好”，只批准这一个阶段",
                       "不当作对这张卡的采纳；没有采纳原话的，案例停在候选，下一章不用。"):
            self.assertIn(phrase, item)
        # it sits with the beat card's other rules, before the r5.54 readings; sections 1-3 are pinned elsewhere
        self.assertLess(four.index("- **落笔前**"), start)
        self.assertLess(start, four.index("- **r5.54 加的读法**"))
        self.assertIn("照方案第三节第 8 条，第 4 节加“作者改过的节拍卡”一条", read("references/scene-dramaturgy.md"))

    def card_round(self, rec, run_id, words):
        rec.op("start", run_id, task="scene_beat_revision", tags=[run_id], group_id=run_id, input_text=self.CARD,
               source_ref="写前准备阶段交作者看的那一版卡", constraints=[])
        rec.op("plan", run_id, applications=[], checks=["合成"])
        rec.op("draft", run_id, text=self.CARD, source_ref="同一版卡", actor={"name": "工坊", "context_id": "w"})
        rec.op("review", run_id, review_id="a", draft_sha256=sha(self.CARD), reviewer=rec.reviewer("author", "human", "a"),
               verdict="revise", source_ref="合成对话#卡", findings=[
                   {"id": "B1", "issue": "这一场不是讲价，是替孩子赔不是。", "evidence": "Scene Type: Core Conflict", "scope": "ch01-s2"}])
        rec.op("decide", run_id, review_id="a", decisions=[{"finding_id": "B1", "decision": "adopt", "reason": "作者改的卡"}])
        rec.op("revise", run_id, parent_sha256=sha(self.CARD), review_id="a", text=self.THEIRS, source_ref="作者改定的卡",
               actor={"name": "作者", "context_id": "a", "role": "author"})
        rec.op("review", run_id, review_id="ok", draft_sha256=sha(self.THEIRS), reviewer=rec.reviewer("author", "human", "a"),
               verdict="pass", findings=[], rechecks=["a"], source_ref="合成对话#卡")
        rec.op("finish", run_id, draft_sha256=sha(self.THEIRS))
        if words == "采纳当前稿。":
            rec.op("author_accept", run_id, draft_sha256=sha(self.THEIRS), quote=words, source_ref="合成对话#3", **AUTHOR)
        else:  # "继续" only moves the stage on: not an acceptance of the card
            self.assertEqual(rec.refused("author_accept", run_id, draft_sha256=sha(self.THEIRS), quote=words,
                                         source_ref="合成对话#3", **AUTHOR).code, "not_an_acceptance")
        rec.op("learn", run_id, case_id=run_id, why="赔不是的场不按讲价写。", when=["上门的一方是来赔礼的"], decisions=["场型改为其他场"],
               **{"except": []})

    def test_found_only_with_the_authors_acceptance(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = H.new_store(Path(tmp) / "学习记录.md")
            rec = H.Recorder(path, H.load_loop(ROOT))
            self.card_round(rec, "beat-accepted", "采纳当前稿。")
            self.card_round(rec, "beat-continue", "继续")
            data = H.payload_of(path)["data"]
            self.assertEqual({key: case["status"] for key, case in data["demonstrations"].items()},
                             {"beat-accepted": "author_accepted", "beat-continue": "candidate"})
            self.assertNotIn("chapter_id", data["learning_runs"]["beat-accepted"])
            code, out, err = run("demonstration_memory.py", "index", path, "--project-id", "book", "--task", "scene_beat_revision")
            self.assertEqual(code, 0, err)
            self.assertEqual([c["id"] for c in json.loads(out)["cases"]], ["beat-accepted"])


class SourceLines(unittest.TestCase):
    """Proposal section 5: a page that borrowed an idea names where from, in the workshop's words (r5.59 review)."""

    LINES = {
        "references/quality-loop.md": ("来源（r5.59）：", ("`engineering/skill-retro`", "`engineering/memory-engineering`",
                                                         "`engineering/agent-memory`", "`engineering-team/self-improving-agent`")),
        "references/skill-evaluation.md": ("来源（r5.59）：", ("`engineering/skill-retro`",
                                                             "`engineering/skills/agent-regression-evals`")),
        "references/author-preferences.md": ("另参照 claude-skills 合集", ("`engineering/skillopt-sleep`",)),
        "references/editorial-judgment.md": ("来源：", ("`engineering/skillopt-sleep`",)),  # r5.60: no version note here
    }

    def test_each_page_names_the_directories(self):
        for rel, (start, folders) in self.LINES.items():
            with self.subTest(page=rel):
                lines = [line for line in read(rel).splitlines() if line.startswith(start)]
                self.assertEqual(len(lines), 1)
                line = lines[0]
                self.assertIn("claude-skills 合集", line)
                for folder in folders:
                    self.assertIn(folder, line)
                self.assertIn("按包内记录，没有带它的文件", line)
                self.assertIn("[来源记录](../assets/third-party/SOURCE-NOTES.md)", line)
                self.assertTrue((REFS / "../assets/third-party/SOURCE-NOTES.md").is_file())
                self.assertIsNone(re.search(r"[A-Za-z]+ [A-Za-z]+ [A-Za-z]+", line), "no English sentence of theirs")

    def test_where_they_sit(self):
        # at the end of the page, except where the end is inside a locked passage: editorial-judgment.md ends in
        # "边界", which the registry locks, so its line ends "状态怎么走", where the "停用" sentence it is about sits
        for rel in ("references/quality-loop.md", "references/skill-evaluation.md", "references/author-preferences.md"):
            last = [p for p in read(rel).rstrip().split("\n\n") if p.strip()][-1]
            self.assertTrue(last.startswith(self.LINES[rel][0]), rel)
        status = section(read("references/editorial-judgment.md"), "状态怎么走", "### ")
        self.assertTrue([p for p in status.rstrip().split("\n\n") if p.strip()][-1].startswith("来源："))
        self.assertNotIn("skillopt", section(read("references/editorial-judgment.md"), "边界"))


class ThreeLayers(unittest.TestCase):
    """Item 10: the overview at the end of quality-loop.md only points at existing clauses."""

    def setUp(self):
        self.text = read("references/quality-loop.md")
        self.part = section(self.text, "自我纠错的三层")

    def test_it_is_the_last_section_and_ends_with_the_sentence(self):
        headings = [l for l in self.text.splitlines() if l.startswith("## ")]
        self.assertEqual(headings[-1], "## 自我纠错的三层")
        # r5.59 review: the page's source line (where the borrowed ideas came from) follows the section's last sentence,
        # as on the other pages that name a source
        paragraphs = [p for p in self.text.rstrip().split("\n\n") if p.strip()]
        self.assertTrue(paragraphs[-1].startswith("来源（r5.59）："))
        self.assertEqual(paragraphs[-2],
                         "作者说“你自己改规则”，照第三层办：在维护里出候选和对照，交作者看；这句话不等于事先批准以后的每一次修改。")

    def test_it_says_it_only_points(self):
        self.assertIn("\n\n工坊自己能改到哪里、哪些要作者说了才算，规则散在几页里。下表每一格只指向原来的条文，不另立规则，细节以原条文为准（r5.59）。\n\n",
                      self.part)

    def test_the_table(self):
        rows = [[c.strip() for c in l.split("|")[1:-1]] for l in self.part.splitlines()
                if l.startswith("| ") and not l.startswith("| ---")]
        self.assertEqual(rows[0], ["", "一章之内（写完自查，改完再查）", "一本书之内（从作者的改稿里学，下一章用上）",
                                   "工坊本身（规则页、卡片、脚本）"])
        self.assertEqual([r[0] for r in rows[1:]], ["工坊自己可以做", "要作者说了才算", "要不要新旧对照", "不能做"])
        self.assertTrue(all(len(r) == 4 and all(r[1:]) for r in rows), rows)
        self.assertTrue(all(cell.endswith("）") or cell == "不要" for r in rows[1:] for cell in r[1:]),
                        "each cell ends with where it is written")

    def test_every_link_and_named_section_is_there(self):
        table = "\n".join(l for l in self.part.splitlines() if l.startswith("| "))
        darwin = SKILL.parent / "darwin-novel-workshop" / "SKILL.md"
        checked = 0
        for cell in table.split("|"):
            for target, anchor in LINK.findall(cell):
                path = (REFS / target).resolve()
                self.assertTrue(path.is_file(), target)
            # “…” names right after a link, after 本页, or after 维护扩展…的
            for owner, names in re.findall(r"(\]\([^)]+\)|本页|维护扩展[^“]*的)((?:“[^”]+”)+)", cell):
                if owner == "本页":
                    path = REFS / "quality-loop.md"
                elif owner.startswith("维护扩展"):
                    path = darwin
                else:
                    path = (REFS / LINK.match(owner).group(1)).resolve()
                headings = headings_of(path)
                for name in re.findall(r"“([^”]+)”", names):
                    self.assertTrue(any(h == name or h.startswith(name) for h in headings), (path.name, name))
                    checked += 1
        self.assertGreaterEqual(checked, 20)

    def test_the_clauses_it_points_at_say_so(self):
        # a few of the cells, against the words of the clause they point at
        self.assertIn("达到三轮上限、连续一轮没有实质改善、或同一问题开始反复改回时，停止循环。", self.text)
        self.assertIn("台词里添的话、删的话 | 只有作者", read("references/teacher-review.md"))
        self.assertIn("**候选卡不进写作上下文。**", read("references/editorial-judgment.md"))
        darwin = (SKILL.parent / "darwin-novel-workshop" / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn("模型自评分、裁决数量和规则条数都不能触发自动合并。", darwin)
        self.assertIn("不自动建立定时任务", darwin)
        self.assertIn("不为了让候选通过去改它", read("references/skill-evaluation.md"))


class NarrowedAfterThePairedTests(unittest.TestCase):
    """r5.59, after the paired scenario tests: the author chose to narrow the exception (see the module docstring).

    The registry's lock on the narrowed section is checked in test_r559_maintenance.py
    (ProtectedSectionsRegistry.test_the_lock_follows_the_narrowed_exception)."""

    PAGES = ("references/chapter-confirmation.md", "references/learning-loop.md")

    def test_the_withdrawn_sentence_is_gone_from_both_pages(self):
        # the wrap-up's section 6, item 3, way (a), and the question that led to it, are withdrawn from both pages
        for rel in self.PAGES:
            text = read(rel)
            for gone in ("作者的稿子先留着、不登记", "还交不交教师", "再照这条例外办"):
                with self.subTest(page=rel, phrase=gone):
                    self.assertNotIn(gone, text)

    def test_the_exception_names_its_two_times_and_what_stage_4_is(self):
        meaning = section(read("references/chapter-confirmation.md"), "确认是什么意思")
        lines = [l for l in meaning.splitlines() if l.startswith("- 作者改了来源、方案或正文，从受影响的那个阶段重开")]
        self.assertEqual(len(lines), 1)
        line = lines[0]
        first = line.index("第 4 阶段已经确认、第 5 阶段还没确认的时候（初稿由作者交教师的章，还要已经登记了教师回传），作者交回自己改过的整份稿子")
        second = line.index("第 5 阶段已经确认、第 6 阶段还没确认的时候，作者交回自己改过的修订稿")
        limit = line.index("这条例外只管这两种时候。")
        stage4 = line.index("第 4 阶段还没确认，或者初稿由作者交教师、教师回传还没登记的时候（包括作者确认了可以交教师、教师结果还没带回），"
                            "作者只交回自己改过的稿子、没有一起带回教师结果的，不算例外")
        # the two times, then the limit, then what a hand-back before stage 4 is confirmed is
        self.assertLess(first, second)
        self.assertLess(second, limit)
        self.assertLess(limit, stage4)
        self.assertEqual(line.count("这条例外只管这两种时候"), 1)
        self.assertIn("不算例外，也不登记成教师回传：照这一条开头那句，从第 4 阶段重开，把作者的稿子当新的一版初稿交作者确认，带版本名或哈希，"
                      "写明改了哪几处；作者要交教师的，交的就是这一版。", line)
        # r5.59, second wording fix: a chapter already recorded as not going to the teacher, and the teacher's result
        # brought back together with the author's own text, each have one reading
        self.assertIn("早先已经用 `chapter_policy` 记了这一章不交教师的，这一章由工坊自己审，例外的两种时候作者交回改稿，"
                      "照例外办。", line)
        self.assertIn("作者把教师结果和自己改过的稿子一起带回的，先照下文“完整初稿以后”登记教师回传（初稿还在等确认的，"
                      "照那里先用带回结果的那条消息记初稿的确认），再照例外办，"
                      "作者的稿子不登记成教师回传。", line)
        # learning-loop.md says the same for the round: none is started, stage 4 is reopened
        start = section(read("references/learning-loop.md"), "在章节流程里怎么起一轮")
        self.assertIn("这样的章节，教师回传还没登记、作者只带回自己的稿子的，不算例外，这一轮不起", start)  # r5.60: reworded
        self.assertIn("照“确认是什么意思”从第 4 阶段重开，作者的稿子当新的一版初稿交作者确认，作者要交教师的，交的就是这一版。", start)


# Every line r5.59 added or changed in the six pages, as written in this version (SHA-256 of the whole line, found by
# its opening words). Deleting or rewording any sentence of them fails here. A later change to one of these lines
# updates its pin here and says in this file why it changed.
# r5.59 review: the card list got its own heading (it sat under the consolidation's); the pointers to it in stage 7
# and in editorial-judgment.md name that heading; stage 3 names the scene page's new item; the step 4 of "示范被用错以后"
# quotes the paragraph by its own opening words; learning-loop.md says what the script holds back for a teacher chapter,
# what to do when only the author's text comes back there, that the self-review is decided and rechecked too, and that
# the fourth small change needs no new field; quality-loop.md, editorial-judgment.md and author-preferences.md gained
# a source line for the claude-skills ideas (proposal section 5).
# r5.59 wrap-up (the maker's decisions after the review, section 6): the "停用" item of editorial-judgment.md says a
# withdrawn card may be raised again on new evidence from another chapter or scene, the date and the author's words of
# the withdrawal first (item 12); chapter-confirmation.md and learning-loop.md say what to do when the author says the
# chapter still goes to the teacher (item 3, way (a)) and that the author's own revision handed back at stage 6 counts
# the same way as at stage 5 (item 10, a new paragraph in learning-loop.md). Those three lines are pinned anew and the
# new paragraph is added; the walk-throughs are AuthorRevisedDraft.test_the_author_says_the_chapter_still_goes_to_the_
# teacher and test_the_authors_own_revision_at_stage_6.
# r5.59 review before delivery: step 1 and the teacher-chapter paragraph of learning-loop.md point to "取舍由谁定",
# which comes after them; "上文" became "下文" in both, nothing else changed, and the two lines are pinned anew.
# r5.59, after the paired scenario tests (see the module docstring): the author chose to narrow the exception. The
# reopening line of chapter-confirmation.md names both ends of each of the two times, says "这条例外只管这两种时候" and
# what a hand-back before stage 4 is confirmed is (a new draft, not a teacher return); the teacher-chapter paragraph of
# learning-loop.md says such a hand-back starts no round and reopens stage 4. Item 3, way (a) of the wrap-up ("作者的稿子
# 先留着、不登记") is gone from both. Those two lines are pinned anew; nothing else in the six pages changed.
# r5.59, wording fix before release: the first time also needs the teacher return registered on a chapter whose draft
# the author takes to the teacher ("还要已经登记了教师回传"), so the stage-4 sentence covers that case too ("或者初稿由作者
# 交教师、教师回传还没登记的时候"); "照前一句" became "照这一条开头那句" (the line's own opening), and a chapter the
# author no longer takes to the teacher is reopened at stage 4 as well ("照样从第 4 阶段重开"). The reopening line is
# pinned anew; nothing else in the six pages changed.
# r5.59, second wording fix before release: the stage-4 sentence is for the author's own text handed back alone ("作者
# 只交回自己改过的稿子、没有一起带回教师结果的"); "不交教师了" said at that time still reopens stage 4 ("这时候作者说");
# a chapter already recorded with `chapter_policy` as not going to the teacher takes the exception once stage 4 is
# confirmed; and the teacher's result brought back with the author's own text is registered first, then the exception
# applies. The reopening line is pinned anew; nothing else in the six pages changed.
# r5.59, third wording fix before release: the sentence on a chapter already recorded with `chapter_policy` as not
# going to the teacher now covers both times of the exception ("例外的两种时候作者交回改稿，照例外办"; it sent every hand-back after
# stage 4 to the first time, a stage-6 or stage-7 hand-back included); the "不交教师了" sentence is for a hand-back
# ("这时候作者交回改稿、又说"), not for a message that only says the chapter no longer goes to the teacher; the teacher's
# result brought back with the author's text then follows the exception ("再照例外办"). The reopening line is pinned
# anew; nothing else in the six pages changed.
# r5.60 (the rare cases r5.59 shipped as known): three lines of learning-loop.md are pinned anew. The opening
# sentence under "作者在审稿阶段交回自己改过的稿子" carries the conditions of the locked line ("第 4 阶段已经确认、
# 第 5 阶段还没确认的时候……还要已经登记了教师回传"); the teacher-chapter paragraph no longer reads as covering a chapter
# the workshop reviews and says what the gate refuses and what it takes; the stage-6 paragraph says the stage is
# still confirmed after it is presented again. The new paragraph on a late batch of teacher notes brought back
# with the author's revision is pinned in test_r560_confirm.py. The locked line of chapter-confirmation.md is
# unchanged, and so is its pin here.
# r5.60 (the four records' pages, see test_r560_records.py): the plain version notes "（r5.59）" left these pages, so
# six lines of editorial-judgment.md, the source line of author-preferences.md and two lines of
# demonstration-learning.md are pinned anew with nothing else changed in them; "示范被用错以后" has its steps in a new
# order (look first, retire after) and its last step says what the script gives the narrower case, so its heading
# line and steps 2-5 are pinned anew under their new opening words. The line inside the locked section of
# author-preferences.md ("规则需要合并、缩小和退出") keeps its note and its pin.
# r5.60 (the stage 3 cell of chapter-confirmation.md, shown to the author with its old and new wording first): a
# clause is added inside the cell (the technique cards chosen for each scene; listing them, or a "继续""好" at this
# stage, is no adoption of a card). The row stays one line and lies outside the locked section, so lines 53-60 keep
# their numbers; the row is pinned anew, and the clause itself is pinned in test_r560_technique_pipeline.py
# (StageThree). The locked line and its pin below are unchanged.
WRITTEN = {
    ('references/quality-loop.md', '**复盘：先归因，再谈经'): 'ee5bf084044bbe1c23dc69e0501a57b36b20c56eafa13f8fae79115daa4c908b',
    ('references/quality-loop.md', '### 整理一次：交作者'): '06f870b9f260a317da9c730514bc49a68b0eb21164ca7d0f5501fa1472713511',
    ('references/quality-loop.md', '作者要整理的时候，或者工'): '72509e622937b3e93f2a8e681e184f3c8c954a37c36b87c7f30ca248966fe6e3',
    ('references/quality-loop.md', '### 判断卡请认单（第'): '198b2dd51dfdb41db7ca6acb067e1ef61b17296e35b935d36c9491e2e69b212b',
    ('references/quality-loop.md', '开了[从改稿记录里学编辑判断](editorial-judgment.md)的，定稿说'): '3ebde598e57dc697f840dbb82cdb939c6aa656ba635e55ba730b09a36d9e8e1a',
    ('references/quality-loop.md', '## 自我纠错的三层'): 'd77aca0fdaac326cda69eb1ef9facbd2690b29b0e8884344bbfa1c221e6188c0',
    ('references/quality-loop.md', '工坊自己能改到哪里、哪些'): '772392043acf4d20f45e10b7429dd97128fe816739f4987c52ca34a3523b05d2',
    ('references/quality-loop.md', '| | 一章之内（写完自'): '308944efdd798a1f0b718f391330f62dc12d0bec985728c4b95c1cb02fa69549',
    ('references/quality-loop.md', '| 工坊自己可以做 | '): 'e2d5b1176ab805edd37cfe458c4fbed827864ba216ed23779d7b3e86e8e702e0',
    ('references/quality-loop.md', '| 要作者说了才算 | '): 'ea896f5d7295870e9c089d626f40d17ef0947cb57ee4fd070fdcf7e75fd4f8e4',
    ('references/quality-loop.md', '| 要不要新旧对照 | '): 'c469cc56392c81a7195a00d2f80413bc85056b842fa21d3849324d9da2c3734c',
    ('references/quality-loop.md', '| 不能做 | 把自查说'): '7295a5e447756a2fd6e3c04b3b96d5f554d731288f7613f7cf93518210daf76c',
    ('references/quality-loop.md', '作者说“你自己改规则”，'): '272342430b58b2c8116eab557fc8003c2a79225f567823e1e302a2c297ff861a',
    ('references/quality-loop.md', '来源（r5.59）：“单元之间'): '2c5a0067b85c7ccaad4564034acad25edf20d5c862c34cbdbfb1ee17c1565ca5',
    ('references/editorial-judgment.md', '案例要当作者认可的示范来'): 'bf9474a6ac1fe771690b0ee432e85fbfad68ee2db184d72fdba70c4c86c3946b',
    ('references/editorial-judgment.md', '- **停用**：作者撤'): '5c94b99507740e8b3ad75eccd3261ec830668e1e76fdd521aa6c06b60ad9d7d3',
    ('references/editorial-judgment.md', '- **作者收回某一章的'): 'd8df876c408064661a6a7662707c040ad4aaa7a636ddd3c3b166006b8fbaf76d',
    ('references/editorial-judgment.md', '一步一步走，不能从候选直'): '406d680cb7ee25fedd151addb672996c1ff8d67d3ad9eb301baa8ab473af330b',
    ('references/editorial-judgment.md', '来源：“停用”里作者撤'): '5c2a8d44f9d7d1cb327d2798abc8323c009aa33f541a20295f7423f4e8cc30ba',
    ('references/editorial-judgment.md', '- 专门做给作者看的对照'): '9a5d13f4778532ac7b7d308e4cdd70466c252fe6c47fa3248cb1fac556cb3aa5',
    ('references/editorial-judgment.md', '  1. 选两三章作者已'): '0e195a02e4ab154bde72748e378e21d953d9da14c07d15d2c3d19048c764b76d',
    ('references/editorial-judgment.md', '  2. 另起一个新的上'): 'cd809ac0636454d1f64097a24190d28bc4348f1e902c39e8d4fe927ddc163404',
    ('references/editorial-judgment.md', '  3. 卡对已采纳章节'): '289d14247452bbac6e474facd2e257f1f5914901a156ae57d87d7c4088feb929',
    ('references/editorial-judgment.md', '  4. 这一行写 `c'): '9a88730e88e0483a77e6940d33197ba832395e9bae16a097a3245ea9a2f056f4',
    ('references/editorial-judgment.md', '  5. 回放过的章，记'): 'f6f7e4dec26521fc8766b76aa02f6b4de3fec45e12206e55f22157e9295188be',
    ('references/editorial-judgment.md', '  这份对照只查得出卡会'): '830942c0b78a8660335053d603b0e48fd9c907c6dd316366d1d6672f49706aad',
    ('references/author-preferences.md', '3. **进入有效摘要。'): '51641093132686acd285dd65d124963c64bc594a06d6ddb4e93f989885bc6776',
    ('references/author-preferences.md', '规则需要合并、缩小和退出'): '786ad2be5efbff2af9dfaa0dfb1ecfae96de0af6a0788c1a05998febf1435ab2',
    ('references/author-preferences.md', '另参照 claude-skills 合集'): 'cd9ba7874615e3759e48f72eb4e5d2235c6cbe5d1b262c1672d814480f205e65',
    ('references/learning-loop.md', '- **输入填什么。**'): '8cf82eda6f8679a6ec83879899eb744cbdfc60c2dc0566616e993563a1d7da9d',
    ('references/learning-loop.md', '- **作者在审稿阶段交'): 'b71ddff4e99df7cd008fb100a3401087cce6fc4762235ecef9c518be6e1065ed',
    ('references/learning-loop.md', '  1. 作者动过的每一'): '79337f8c9426d6dc80d98ffc096c725dbe9df99a5bff4eed75c17f03b09dae81',
    ('references/learning-loop.md', '  2. 作者的稿子用 '): 'dc74376cff1bd0978706fb90364ebf3cfd22cd29762e39af90cb2f516700fcbd',
    ('references/learning-loop.md', '  3. 作者说的“通过'): '474d1d7ca07fded5f312afd39b89d470ea3d2610e2da3e76c7102ffa0ae622e8',
    ('references/learning-loop.md', '  4. 工坊在第 6 '): 'e668b848c6774c6f629d501f61be79192aedc9b685a085af5aadbe9464876af4',
    ('references/learning-loop.md', '  5. 作者在第 7 '): 'c328b69608a4826d6eb65c037836943f2db4259147757d30c1402acb63785f8c',
    ('references/learning-loop.md', '  初稿由作者交教师的章'): '7e5c26696746e033c9740a94b574c8ec08e86b6853d50019b2c7c653f06774fe',
    ('references/learning-loop.md', '  作者在第 6 阶段交回自己'): 'a007d12c989c2ee8102ecc3617e711471f1693ae5b6a64d92f8d6ad4fa0a63f2',
    ('references/learning-loop.md', '6. 新复查明确关联要复'): '7618a9867ddd606a66d0cd210c8739d41e9551ce8c524358cadf7d5ce509046c',
    ('references/learning-loop.md', '7. `learn` 仅'): '260d4bddbc96ced659cd5de5ad93e5e62c6220702f2242648db154d5eb442934',
    ('references/learning-loop.md', '| `plan` | `'): '102829a49aead229e5fd1ce8471aa10002931bf25ba712530249598809405c09',
    ('references/learning-loop.md', '| `draft` | '): 'd97e4f88f0be4f6b1a9c6e1703e0aa19bd37eb511fd18efda049d8eaced8d811',
    ('references/learning-loop.md', '| `revise` |'): 'ceb8ef1f664427aaf9c556c0f46f5fd0f0ac402fbceeff535be1d940a9cbc68d',
    ('references/learning-loop.md', '| `finish` |'): '1ed42e2cda2b194eb9f70793ec78968cfef37259f668cb2e304f88006ea58f91',
    ('references/learning-loop.md', '| `learn` | '): '8b7bc57071884e66ab75ac614d0324dc73595f54f2b222ecb7f96513ef8eeb9c',
    ('references/learning-loop.md', '**r5.59 的四处小'): 'c25974455900cfe94ba7111913c9417ab645bb4dee2e53b81a035df03447c604',
    ('references/learning-loop.md', '- **登记示范时可以重'): '448f7f20c909aea71a73889c7cd1fbaa83fa8502238d304b0dfb3b062be2ecff',
    ('references/learning-loop.md', '- **一章几场，按场写'): '9a678fb2562ce295c7e5052169c586c9d7ba00839f4212a91afa354aabb467fd',
    ('references/learning-loop.md', '- **看得出改后的文字'): '71df853562f937c7f55b4950a2d9981f292d58b8e35dcf585ca8313fa5948e5e',
    ('references/learning-loop.md', '- **作者本人通过的稿'): '3f4f5ead1872990c9c27431c2ee362a8b62be755ce8996b0d80ab2e91f05ccb6',
    ('references/learning-loop.md', '带新写法而写得不对的，整'): 'cf7bbce3c9f0dc85147773d5d7ea3e94c784e8cfd4e3cc89ac3ae91e61066705',
    ('references/learning-loop.md', '评审 `role` 是 '): '7a6107ff261abcc717088006d3ccf2bb718414c053c55fb442b8716a9cb33dd1',
    ('references/demonstration-learning.md', '| `task`、`ta'): 'e3987af59a432d091b34195fcdca75d38c2d3d254b5b69567f2614837745b30b',
    ('references/demonstration-learning.md', '7. **选中的示范来自'): '93e103c40823f21ff9633f96df6240ebad13c258f459e7a66005c575c90299f1',
    ('references/demonstration-learning.md', '8. 不迁移示范中的人物'): '871ad18304e1eb962329c17d859e2dc785322178a496fdedde031fee7ab87cc8',
    ('references/demonstration-learning.md', '- **先后顺序。** '): 'ff81dd24ba6cf7fc189cdeb2aafc01bc87ae69d69f8e844e3935910473868786',
    ('references/demonstration-learning.md', '- **示范被用错以后。'): '67a4856f9bc659a0f9448f71fe0b735bf418ec3c76535eb1258acede7d002e7d',
    ('references/demonstration-learning.md', '  1. 作者指出某条示'): '5c46e098fe608c795a2589fb4945f045e24939384ab20a9e0ed11975d53cf9aa',
    ('references/demonstration-learning.md', '  2. 先分清是哪一种'): 'efa195c05fefe4a5fe9d98d75129cda2960c05414adf2e145556469dcffad23c',
    ('references/demonstration-learning.md', '  3. 要收窄的，先用'): '9c3c64cb88e99fca4c974e12ed8deac8e665229ae86ea9901cd51ca6e0a5f97b',
    ('references/demonstration-learning.md', '  4. 再从原来那一轮'): '21342d35e8dd88dac89c0a6a952c68f6303f8d060fdd6db180a28405beb430f2',
    ('references/demonstration-learning.md', '  5. 新案例的状态由'): '4473bb8d7f751633aac70651e498d9165c0ebe0d85da3ec09f8f595aecd9c107',
    # r5.60: a clause added in the stage 3 cell; the author saw the old and the new wording and said yes
    ('references/chapter-confirmation.md', '| 3 `prepara'): 'f1c28139788eeb384a9458060a2ed35b210254d697346078e566bedd6652244e',
    ('references/chapter-confirmation.md', '| 4 `draft` '): '0378825f3e578b2f3f45194091a33cb4010a9c8ded53128bed96d19964970df6',
    ('references/chapter-confirmation.md', '| 7 `final` '): '71a0fe8bd9ccc56a5c76c48ab155de092a66b14dafe621037ee4a3f7762c0dcf',
    ('references/chapter-confirmation.md', '- 作者改了来源、方案或'): 'bf5b7e9c4c0475ace64c4f249e148eda5517e82f7e923a344fe012df2142692f',
}


class WrittenAsApproved(unittest.TestCase):
    def test_each_line_is_there_as_written(self):
        texts = {}
        for (rel, start), digest in WRITTEN.items():
            lines = texts.setdefault(rel, read(rel).splitlines())
            found = [line for line in lines if line.startswith(start)]
            with self.subTest(page=rel, line=start):
                self.assertEqual(len(found), 1, "one line starting with this")
                self.assertEqual(sha(found[0]), digest)


if __name__ == "__main__":
    unittest.main()

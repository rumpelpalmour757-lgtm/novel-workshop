#!/usr/bin/env python3
"""Read-only Chinese prose hints; not an AI detector or editorial verdict."""

import argparse
import bisect
import hashlib
import json
from pathlib import Path
import re
import sys


PLACEHOLDER = re.compile(
    r"\[\[[^\]\n]{1,60}\]\]|"
    r"[【\[]待(?:补|写)[^】\]\n]{0,60}[】\]]|"
    r"(?:正文|后文|后续)(?:内容)?省略|此处(?:补充|续写)(?:正文|情节)"
)

# Inside one clause: up to n characters that are not punctuation, quote marks or a line break (r5.48). Lets a pattern
# allow an adverb or a short cause between a body part and its reaction without reaching across a comma into the next
# clause.
def gap(n):
    return r"[^，。！？；：、,.!?;:“”「」『』（）()\n]{0,%d}" % n


# Scene rules (r5.32, CON-011, references/scene-dramaturgy.md). Three of them run by default: a run of bare dialogue,
# words that tell the reader the tension or the feeling, and a summing-up ending. A book turns one off only by the
# author's decision, written in its rules file under "off" with the reason. "stock-reaction" stays optional ("hints").
# They give places, literally (NWC-1.5, r5.34): a hit in the narration is rewritten or kept with a reason of its own,
# one in a character's line is marked in_quote (the character's own voice). A bare run broken by one line of weather is
# no longer reported although the scene is still not grounded; no hit does not mean the scene is on the page.
HINTS = ("floating-dialogue", "tension-telling", "stock-reaction", "weak-scene-ending",
         "frequent-words", "negation-ending", "parallel-run", "list-of-three",
         "inner-declaration", "contrast-moral", "abstract-surge", "stock-simile", "soft-adverbs", "short-beats",
         "emotion-statement", "reaction-wide", "simile-extra", "theme-phrase",
         "xian-crutch", "xian-density")
# r5.48: the optional hints for a de-AI pass, turned on together with --hint deai (or "hints": ["deai"] in a rules file).
# stock-reaction stays optional (CON-011 names it so); the six after it are new and optional too. A hit is a place to
# read in context, not a verdict: a real breath, a character's own "我知道", an argument's 不是……而是 are fine.
# short-beats is left out of the group: on the author's accepted chapters it marked 58 one-sentence paragraphs that
# are the book's own style (a book that writes so turns nothing on; it is run only when named).
# r5.49: "deai-extra", four more optional hints of the same kind, kept out of "deai" so that a book's "deai" run reports
# what it reported before; --hint all and each name turn them on too. Narration only, review items, never errors.
HINT_GROUPS = {"deai": ("stock-reaction", "inner-declaration", "contrast-moral", "abstract-surge", "stock-simile",
                        "soft-adverbs"),
               "deai-extra": ("emotion-statement", "reaction-wide", "simile-extra", "theme-phrase"),
               "xian": ("xian-crutch", "xian-density")}
SCENE_RULES = ("floating-dialogue", "tension-telling", "weak-scene-ending")
# The first of the five revision passes (r5.33, references/revision-passes.md): tics a count can find. On by default,
# like the scene rules, and like them every hit is an ordinary review item (change it, or keep it with a reason).
# A book turns one off the same way, by the author's decision with the reason.
LANGUAGE_RULES = ("frequent-words", "negation-ending", "parallel-run", "list-of-three")
DEFAULT_RULES = SCENE_RULES + LANGUAGE_RULES
# Word families of the forwarded five-pass plan (maintenance voice-passes-2026-10-22): one word used FREQUENT_MIN
# times or more in a chapter is listed at every place.
FREQUENT_WORDS = (("时间连接", ("随即", "旋即", "紧接着", "与此同时")), ("落点动词", ("落在", "停驻", "扫过")),
                  ("持续态", ("仍", "依旧", "依然")), ("次序标注", ("依次", "先后", "逐一", "挨个")),
                  ("突发", ("忽然", "骤然", "猛然", "陡然")), ("手部报备", ("左手", "右手", "另一只手")))
FREQUENT_MIN = 3
# A narration paragraph whose last clause is a "没有……／没再……" brake; NEGATION_MIN of them in a chapter are listed.
NEGATION_MIN = 3
NEGATION_CLAUSE = re.compile(r"没(?:有|再)")
CLAUSE_BREAK = re.compile(r"[，,。！？!?；;：:、]")
# Three or more short one-clause sentences of about the same length in a row: a list of actions, one per sentence.
RUN_SENTENCES = 3
SHORT_MIN, SHORT_MAX, SHORT_SPREAD = 3, 16, 3
# "一个……，一个……，一个……": three or more clauses in a row that each open with 一 and a measure word.
MEASURE = "个只块张把条句声件道片枚根本扇间座位名双副盏层口"
LIST_CLAUSE = r"一[%s][^，、；。！？“”「」]{0,12}" % MEASURE
LIST_OF_THREE = re.compile(LIST_CLAUSE + r"(?:[，、；]" + LIST_CLAUSE + r"){2,}")
BUILT_IN = ("placeholder", "repeated-paragraph")
# A quoted line; an opening mark with no closing one runs to the paragraph end (a quote continued in the next paragraph).
QUOTE = re.compile(r"“[^”]*(?:”|$)|「[^」]*(?:」|$)|『[^』]*(?:』|$)")
# These patterns are applied to an equal-length narration mask, never raw text.
# The fixed-width lookbehind only excludes two clear compounds; it is not a
# Chinese segmenter. Other matches remain contextual candidates, not errors.
RE_NARRATIVE_XIAN_CRUTCH = re.compile(
    r"(?<![祖优])先(?:开口|瞥见|看到|问|道|说|答|见)(?=[：:，,])"
)
RE_NARRATIVE_XIAN_VERB = re.compile(
    r"(?<![祖优])先(?:开口|瞥见|看到|问|道|说|答|见|把|将|让|叫|替|帮|给|拿|取|探|退|送|看|听|等|去|回|走|迈|扶|推|拉|按|压)"
)


def narration_mask(text):
    """Mask paired quotations without moving offsets, including across lines.

    An unclosed opener masks through EOF. Mismatched/unclosed quotes make the
    density unavailable, rather than pretending the visible fragment is a full
    chapter. This helper does not change the older prose checks' quote handling.
    """
    pairs = {'“': '”', '‘': '’', '「': '」', '『': '』', '"': '"'}
    closers = set(pairs.values())
    stack, output, balanced = [], [], True
    backslashes = 0
    for char in text:
        escaped = char == '"' and backslashes % 2 == 1
        masked = bool(stack)
        if not escaped:
            if stack and char == stack[-1]:
                stack.pop()
                masked = True
            elif char in pairs:
                stack.append(pairs[char])
                masked = True
            elif char in closers:
                balanced = False
                masked = True
        output.append(char if not masked or char in '\r\n' else ' ')
        backslashes = backslashes + 1 if char == '\\' else 0
    return ''.join(output), balanced and not stack
# What may stand outside the quotes of a bare line of dialogue: who speaks and a speech verb, at most TAG_MAX characters.
SPEECH_TAG = re.compile(r"说|道|问|答|应|喊|叫|笑|哼|嚷|吼|骂|嘀咕|嘟囔|开口|接话|回答|回道|反问|追问")
TAG_MAX = 8
RUN_MIN = 5
# Words that sum up the atmosphere, the feeling or the time for the reader (the spec's list, and a few of the same kind).
TENSION_LABELS = re.compile(
    r"气氛(?:顿时|一下子|瞬间|骤然|陡然|霎时|一时间|一时)?(?:变得)?(?:更加|越发|愈发)?(?:紧张|凝固|凝重|压抑|剑拔弩张|尴尬)"
    r"|空气(?:仿佛|好像|似乎|像是)?(?:在这一刻|一下子|瞬间|顿时)?(?:都)?(?:凝固|凝结|静止|停滞)"
    r"|死一般的?(?:寂静|沉默)|剑拔弩张|火药味十足|压抑的气氛|各怀鬼胎"
    r"|(?:心中|心里|心头)?五味杂陈|百感交集|感到一阵(?:莫名的?)?(?:恐慌|心慌|不安)"
    r"|(?:内心|心中|心里|心头)(?:掀起|翻起|涌起)(?:了)?(?:一阵)?(?:惊涛骇浪|轩然大波|滔天巨浪)"
    r"|(?:眼中|眼里|眸中|眼底)(?:闪过|划过|掠过)一(?:丝|抹)|一丝不易察觉的"
    r"|意味深长的(?:笑|笑容|弧度|眼神)"
    r"|(?:聊|谈|说|吵|争|打)了(?:很久|好久|许久|很长时间|好一阵子?)|经过一番(?:苦战|激战|鏖战|争吵|交涉|周旋|商量)"
    # r5.48: the same kind, in the shapes the r5.46 review found missing: a feeling that "rises in the heart" and is then
    # named, a feeling said to be beyond words, the dead silence of a place, a pressure that "comes at" someone.
    r"|(?:心中|心里|心头|心底|胸中|胸口|内心)" + gap(3) + r"(?:涌起|涌上|升起|泛起|翻涌起|生出)(?:了)?(?:一股|一阵|一丝|一种)"
    + gap(8) + r"(?:情绪|感觉|滋味|暖流|酸楚|悲凉|不安|恐慌|恐惧|愤怒|怒火|失落|委屈|苦涩|温暖|感动)"
    r"|说不(?:清|出)(?:道不明)?的(?:情绪|感觉|滋味|感受)|莫名的(?:不安|恐慌|心慌|烦躁|情绪|悲伤)"
    r"|一片死寂|死寂一片|(?:一股|一阵)(?:前所未有的|莫名的|强烈的|巨大的)?压迫感|压迫感" + gap(2) + r"扑面而来"
)
# A few ready-made bodily reactions (optional): the same tic in every book. NWC-1.5 (r5.34) moved the ready-made smile
# ("嘴角扬起一抹笑") here from tension-telling: it is an action, if a worn one, not a word that sums up for the reader.
STOCK_REACTIONS = re.compile(
    # r5.48: a body part and its ready-made reaction with a few characters between them inside one clause (an adverb, a
    # short cause, a direction), and the breath, the clenched jaw and the cold sweat the r5.46 review found missing.
    r"(?:嘴角|唇角)" + gap(3) + r"(?:勾起|扬起|上扬|噙着|挂着|翘起|扯出|牵起|抽动|抽搐)(?:一抹|一丝)?"
    r"|指节" + gap(6) + r"(?:泛白|发白|泛青)|瞳孔" + gap(3) + r"(?:骤缩|一缩|猛缩|收缩|紧缩)"
    r"|喉结" + gap(4) + r"(?:滚动|滚了|动了动|滑动)|深吸(?:了)?一口(?:长|凉)?气|倒吸" + gap(2) + r"(?:凉气|冷气)"
    r"|呼吸" + gap(2) + r"(?:一滞|一窒|骤停)|心(?:中|里|头|口)?(?:猛地|骤然|陡然|不由得)?一(?:紧|沉|凛|颤|揪)"
    r"|心跳" + gap(4) + r"(?:加速|加快|漏了一拍|如擂鼓)|心脏" + gap(4) + r"(?:狂跳|猛跳|骤停|漏跳)"
    r"|青筋" + gap(2) + r"(?:暴起|暴突|突起|凸起|直跳)"
    r"|(?:手心|掌心)" + gap(3) + r"(?:全是|满是|沁出|渗出|冒出)(?:了)?(?:一层)?(?:冷)?汗"
    r"|冷汗" + gap(4) + r"(?:湿透|浸透|冒了出来|直冒|涔涔)|(?:后背|脊背|后脊)" + gap(3) + r"(?:发凉|一凉|发冷|一冷|窜起凉意)"
    r"|头皮发麻|咬紧(?:了)?(?:后槽)?牙(?:关)?|牙关紧咬|攥紧(?:了)?(?:双拳|拳头)|双拳紧握"
    r"|指甲" + gap(3) + r"(?:掐进|掐入|嵌进|陷进)(?:了)?(?:掌心|肉里)"
    r"|眼眶" + gap(2) + r"(?:一热|发热|泛红|红了|一酸)|鼻(?:子|头|尖)" + gap(1) + r"一酸|浑身一(?:震|颤|僵)"
)
# Summing-up or deflating lines in the last two paragraphs of the text or of a scene.
WEAK_ENDINGS = re.compile(
    r"(?:一切|这)(?:才|只是|不过是)(?:刚刚)?(?:开始|序幕|开端)(?=[。！？!?…—”」』，,\s]|$|而已|呢|了)"
    r"|(?:前方|未来|以后|今后)的路还(?:很)?(?:长|远)"
    r"|明白了一个道理|(?:一切|什么)都(?:将)?不一样了|再也回不去了"
    r"|新的(?:征程|篇章|旅程|故事)(?:即将|就要|正式)?(?:开始|开启|展开|拉开)|(?:风暴|暴风雨)(?:即将|就要)(?:来临|到来)"
    r"|命运的齿轮|各自回(?:去|房|家)(?:休息|睡下|睡了)?|不欢而散"
    # r5.48: the summing-up ending that hands the reader the lesson (a moment of "finally understanding" followed by the
    # lesson words), or tells how the feeling will last. Realising a plain fact does not match: the pattern needs the
    # lesson words.
    r"|(?:这一刻|那一刻|此刻|直到这时)[，,]?" + gap(8) + r"(?:终于|才)?(?:明白|懂得|懂了|意识到)"
    r"|(?:终于|这才|总算)(?:想)?(?:明白|懂得|懂了)(?:了)?(?:过来)?[：:，,]?" + gap(4)
    + r"(?:什么叫|什么是|真正的|原来|一个道理|[^。！？]{0,12}的意义)"
    r"|真正的" + gap(10) + r"[，,]?(?:从来)?(?:不是|就是|在于)"
    # r5.49: the lasting feeling in its general shape, 留在……心里，温暖……往后的……日子 (who, whose heart and which days
    # left open), tried first so that one such sentence is one place. The shorter shapes after it stay, so that no text
    # loses a hit it had in r5.48.
    r"|(?:(?:会|将)(?:一直|永远)?)?(?:留在|刻在|住在)" + gap(6) + r"心(?:里|中|底|上)[，,]?" + gap(4)
    + r"(?:温暖|照亮|陪伴|陪着|支撑)(?:着)?" + gap(6) + r"(?:往后|以后|今后|余生)" + gap(6) + r"(?:日子|岁月|时光|每一天)"
    r"|(?:会|将)(?:一直|永远)(?:留在|陪着|陪伴|温暖|守护)|往后的每一(?:个|天)|一旦失去"
    r"|再也(?:回不去|找不回|回不来)|(?:这就是|这便是)" + gap(10) + r"(?:的意义|的味道|的力量|的答案|的全部)"
)
# r5.48 optional hints (HINT_GROUPS["deai"]). Narration only: a hit inside quotes is the character speaking and is
# not reported.
INNER_DECLARATION = re.compile(
    # No 不, 没 or 未 within three characters before the verb, and no 才 or complement marker 得 right before it.
    r"(?:[他她我]|[\u4e00-\u9fff]{2,3}?)(?:心里|心底|心中)?(?:也|早就|当然|终于|已经)?(?<![不没才得])(?<![不没未].)(?<![不没未]..)(?:知道|明白|清楚|意识到)[，,：:]"
    r"|这意味着")
ABSTRACT_WORDS = "强大|勇气|成长|意义|人生|生活|命运|武者|英雄|恐惧|自由|答案|力量|坚强|守护|长大|原谅|爱|幸福|孤独|活着"
CONTRAST_MORAL = re.compile(
    r"真正的" + gap(10) + r"[，,]?不是[^。！？“”]{1,24}?[，,]?\s*而是"
    r"|(?:" + ABSTRACT_WORDS + r")" + gap(6) + r"不是[^。！？“”]{1,24}?[，,]?\s*而是"
    r"|与其说[^。！？“”]{1,20}?[，,]?\s*不如说")
ABSTRACT_SURGE = re.compile(
    r"(?:一股|一阵|一种)" + gap(8) + r"(?<![气汽味水烟油])(?:力量|情绪|感觉|冲动|暖流|热流|寒意|怒火|酸楚|悲伤|悲凉|勇气|气势|威压|战意|杀意"
    r"|恐惧|豪情|斗志|难以言喻|前所未有|说不清)")
STOCK_SIMILES = re.compile(
    r"(?:夜色|夜幕)如墨|如(?:江河|大江|长河)(?:般|一般)?(?:奔涌|奔腾|决堤)|如潮水(?:般|一般)?(?:涌|退)|如惊雷(?:般)?|如渊似海"
    r"|仿佛要(?:撕裂|劈开|炸开|震碎)|撕裂(?:了)?空气|镀上(?:了)?一层|化作一道(?:残影|流光|黑影|白光)|炒豆(?:般|一般)"
    r"|(?:犹如|宛如|仿佛|如同)(?:神祇|天神|魔神|死神|战神)(?:降临|一般|般)?|如同实质|仿佛有了实质")
SOFT_ADVERBS = ("缓缓", "微微", "轻轻", "淡淡", "静静", "默默", "死死", "狠狠", "慢慢")
SOFT_IN_PARAGRAPH, SOFT_IN_TEXT = 3, 6
# A narration paragraph that is one short sentence (at most SHORT_BEAT_MAX Han characters), standing between longer
# paragraphs as a beat; SHORT_BEATS_MIN of them in a text are listed. Runs of short lines are punctuation_lint's P11.
SHORT_BEAT_MAX, SHORT_BEATS_MIN = 12, 3
# r5.49 optional hints (HINT_GROUPS["deai-extra"]), narration only like the deai hints.
# emotion-statement: a feeling stated by formula (感到 + the feeling word, 心中充满了, 内心十分复杂, 先是……接着是).
# The lookarounds keep out words that only contain a feeling word: 不安全, a schedule or the money being 紧张, a sore
# eye or throat being 酸涩, 惊动 or 惊醒 after 先是, the 心中 of 核心中 or 手心中.
EMOTION_WORDS = (r"(?:恐惧|愤怒|悲伤|绝望|喜悦|害怕|委屈|愧疚|悲壮|不安(?![全分定])"
                 r"|(?<!资金|工期|时间|关系|局势|经费|人手|床位|名额|供应|呼吸|肌肉)紧张"
                 r"|(?<!眼睛|眼眶|眼角|喉咙|嗓子|嘴里|舌头|鼻子|鼻腔|牙根|胃里)酸涩)")
CLAUSE_CHARS = r"[^，。！？；：、,.!?;:“”「」『』（）()\n]"
EMOTION_STATEMENT = re.compile(
    r"感到(?:一阵|一股|无比|十分|万分|莫名)?" + gap(8) + EMOTION_WORDS
    + r"|(?<![核重圆轴掌手中靶])心中(?:充满|涌起)(?:了)?" + CLAUSE_CHARS + r"{1,8}"
    r"|内心(?:十分|无比|非常|极其|很)?(?:复杂|挣扎)"
    r"|先是(?:一阵|一)?(?:怕|恐惧|惊(?![动醒扰跑走飞]))[^。]{0,4}[，,]?(?:紧接着|紧跟着|接着)是")
# reaction-wide: the stock reactions of STOCK_REACTIONS with up to six characters between their parts. A place that
# stock-reaction already reports in the same run is not reported again. 心 is the heart, not 小心, 中心 or 掌心.
REACTION_WIDE = re.compile(
    r"倒吸" + gap(6) + r"(?:凉气|冷气)"
    r"|(?:嘴角|唇角)" + gap(6) + r"(?:勾起|扬起|上扬|翘起|扯出|牵起)" + gap(6) + r"弧度"
    r"|瞳孔" + gap(6) + r"(?:收缩|一缩|骤缩|猛缩|紧缩)"
    r"|(?<![小细耐用放担关恶粗专决信爱良核中重圆掌手点江湖河轴靶球灯菜空实背甜糖])心" + gap(6)
    + r"(?:往下一沉|猛地一沉)"
    r"|指节" + gap(6) + r"(?:发白|泛白)|冷汗" + gap(6) + r"(?:湿透|浸透)")
SIMILE_EXTRA = re.compile(
    r"(?:快|迅|疾)如闪电|(?:像|如同|宛如|仿佛|好像)(?:一只)?断了?线的风筝"
    r"|(?:如同|像|宛如|犹如|好像)一头被激怒的(?:雄狮|野兽|狮子|公牛)"
    r"|时间(?:仿佛|好像|似乎)(?:在这一刻)?(?:凝固|静止|停止)(?:了)?|如潮水(?:般|一般)涌来")
# theme-phrase: a lesson or an epiphany anywhere in the narration (weak-scene-ending reads only the last paragraphs).
# 刚刚开始 is listed only after 一切, 好戏, 这 or 真正的……, ending a clause (as in WEAK_ENDINGS); with a noun subject
# (比赛、天、雨才刚刚开始……) or a verb after it, it is a plain fact about time, not a lesson (r5.49 review). 人生地不熟
# and 人生路不熟 are not 人生.
THEME_PHRASES = re.compile(
    r"(?:或许|也许)[，,]?这(?:就|便)是(?:成长|生活|人生|长大)吧|这(?:就|便)是人生(?!地|路不熟)"
    r"|(?:一切|好戏|这|真正的" + CLAUSE_CHARS + r"{0,6})(?:才|只是|不过是)?刚刚开始"
    r"(?=[。！？!?…—”」』，,\s]|$|而已|呢|了)|成为(?:更好|最好)的自己"
    r"|不是(?:结束|终点|结局)[，,]?\s*而是" + gap(6) + r"(?:开始|起点|开端)"
    r"|真正的" + gap(10) + r"[，,]?(?:从来|并)?不是[^。！？“”]{1,24}?[，,]?\s*而是")
# A line of its own made only of break marks (***, ※※※, ———) ends a scene.
SCENE_BREAK = re.compile(r"(?:[*＊※◆◇○●☆★#＃=～~·•\-－—_]\s*){3,}")
HINT_MESSAGES = {
    "xian-crutch": "叙述里的“先＋发言/观察”候选：核对是否交代实际先后、抢先或对比关系；有作用可以保留，不凭命中认定冗余。",
    "xian-density": "只统计叙述层“先＋动作/处置词”字面候选，不设通用告警阈值，不把频率当文笔评分。",
    "floating-dialogue": "连着 %d 段只有台词和说话标签：对话缺少动作和道具锚点，场景脱离了物理空间。按分场戏剧张力与正文具象化"
                         "（scene-dramaturgy.md）让人物在说话时做着事、看着东西，动作要改变回应，不每句配一个动作；"
                         "有意连着走的，写明这一处的理由保留（CON-011）。",
    "tension-telling": "情绪、氛围或时间的直述词，替读者下了结论：看这一场要什么，落在人物的"
                       "台词、选择、注意到的东西、处境、动作、念头或此刻身上真有的反应，也可以留白、删去或换成有分寸的直说；"
                       "换成指节发白、深吸一口气这类现成反应不算改好"
                       "（模板腔复核“情绪直述的改法”）；在这里不是下结论的，写明这一处的理由保留（CON-011）。",
    "stock-reaction": "现成的身体反应：出现一次也要看，次数只是线索；命中也不等于要删。读它在这里贴不贴这个人的处境、这一刻在做的事；"
                      "贴的留着（真喘气、真攥着东西、怕得手上出错），"
                      "只是顶替情绪词的，从人物在做的事、注意到的东西、判断、选择或说的话改，不一定换成另一个动作"
                      "（模板腔复核“现成身体反应”）。",
    "weak-scene-ending": "泄气式或点题式收尾：停在翻转的最高点或新悬念出现的那一下，删掉总结、道理和“各自回家”式的尾巴"
                         "（分场戏剧张力与正文具象化第 3 节第 4 拍）；人物此刻真有新认识的，按模板腔复核“点题式收尾”分开判，"
                         "在这里不是泄气或点题的，写明这一处的理由保留（CON-011）。",
    "frequent-words": "“%s”全章出现 %d 次（%s）：逐处看能不能删、换词或并进邻句；是作者的口吻或有意的反复就留，写明理由"
                      "（修改的五道工序第一遍）。",
    "negation-ending": "段尾用“没有……”“没再……”收住，全章 %d 段：看哪几处能删，或者换成人物这时实际做的事收住"
                       "（修改的五道工序第一遍）。",
    "parallel-run": "连着 %d 句长短相近、各自一个动作的短句。回到动作段读：看是分镜腔，还是有意的一拍一停；"
                    "判断看谁在做什么、方向和先后清不清楚（修改的五道工序第一、四遍）。",
    "list-of-three": "“一个……，一个……，一个……”的排比：看是不是在列清单，能不能只挑一样写实（修改的五道工序第一遍）。",
    "inner-declaration": "“他知道，……”式的内心宣告：叙述替人物把心里的话宣布出来。看这句话是不是人物此刻才有的判断、"
                         "有没有更直接的写法（他接下来做什么、说什么）；是信息、是这个人的口吻就留（模板腔复核“去 AI 味的复核提示”）。",
    "contrast-moral": "“不是……而是……”“与其说……不如说……”的点题句：看它是在讲道理、替读者下结论，还是人物在论事、"
                      "叙述在交代事实；讲道理的删去或落回场面，论事的留着（模板腔复核“点题式收尾”）。",
    "abstract-surge": "“一股……的力量／情绪”：抽象的东西被说成涌上来。看能不能写出它让人物这一刻做成了什么、改了什么；"
                      "写实的一股味、一股水不在此列（模板腔复核“去 AI 味的复核提示”）。",
    "stock-simile": "常见的套用比喻：比喻本身没有错，看它换到哪本书里都一样，还是这个人、这一场才有的；夸张有力的留着，"
                    "套用的换成这一场的东西或删掉（模板腔复核“去 AI 味的复核提示”）。",
    "soft-adverbs": "“缓缓、微微、轻轻”一类修饰副词扎堆（%s）：逐处看能不能删、并进动作本身；有作用的留着（修改的五道工序第一遍）。",
    "short-beats": "单句短段夹在长段中间当节拍，全文 %d 处：看哪一处真要停一下（冲击、视线切换、说话的一顿），"
                   "别的并回前后段；连续的单行短段见标点脚本 P11（模板腔复核“去 AI 味的复核提示”）。",
    "emotion-statement": "情绪按公式直说（感到……恐惧、心中充满了……、内心十分复杂、先是……接着是……）。命中只是回去重读的地方，"
                         "不是结论。看这一句是不是替读者把情绪贴了标签：有分寸的直说可以留；套公式的，按这一场选，落在台词、"
                         "选择、注意到的东西、处境、动作、念头或此刻身上真有的反应上，也可以留白（模板腔复核“情绪直述的改法”）。",
    "reaction-wide": "现成的身体反应，中间多隔了几个字（倒吸……凉气、嘴角……勾起……弧度、心……往下一沉这一类）。"
                     "命中只是回去重读的地方，不是结论，也不等于要删。贴这个人此刻的处境和在做的事的，留着；"
                     "只是顶替情绪词的，从人物在做的事、注意到的东西或说的话改（模板腔复核“现成身体反应”）。",
    "simile-extra": "常见的套用比喻（快如闪电、断了线的风筝、时间仿佛凝固这一类）。命中只是回去重读的地方，不是结论。"
                    "比喻本身没有错，看它是这个人、这一场才有的，还是换到哪本书里都一样；套用的换成这一场的东西或删掉，"
                    "有用的留着（模板腔复核“去 AI 味的复核提示”）。",
    "theme-phrase": "点题句或人生道理（这就是人生、成为更好的自己、不是结束而是开始这一类），叙述里哪一处都列出来。"
                    "命中只是回去重读的地方，不是结论。看它是在替读者总结道理，还是人物此刻真有的念头、这个人的口吻；"
                    "讲道理的删去或落回场面，是人物口吻的留着（模板腔复核“点题式收尾”）。",
}
RULE_LABELS = {
    "xian-crutch": "叙述“先”字候选复核", "xian-density": "叙述“先＋动作”密度统计",
    "placeholder": "占位或交稿备注", "repeated-paragraph": "整段重复", "floating-dialogue": "光台词",
    "tension-telling": "情绪、氛围、时间的直述词", "stock-reaction": "现成的身体反应", "weak-scene-ending": "泄气式或点题式收尾",
    "frequent-words": "常见套话词用得太多", "negation-ending": "段尾否定", "parallel-run": "等长短句连排",
    "list-of-three": "“一个……一个……一个……”", "inner-declaration": "“他知道，……”式内心宣告",
    "contrast-moral": "“不是……而是……”式点题", "abstract-surge": "“一股……的力量”", "stock-simile": "常见的套用比喻",
    "soft-adverbs": "修饰副词扎堆", "short-beats": "单句短段当节拍",
    "emotion-statement": "按公式直说的情绪", "reaction-wide": "隔了几个字的现成身体反应",
    "simile-extra": "更多常见的套用比喻", "theme-phrase": "叙述里的点题句",
}
IN_QUOTE_NOTE = "在台词里：是人物自己的口吻就保留。"


def nonempty_string(value):
    return isinstance(value, str) and bool(value.strip())


def validate_rules(value):
    if not isinstance(value, dict) or set(value) - {"terms", "ignore", "hints", "off"}:
        raise ValueError("Rules must be an object with only terms, ignore, hints and off")
    terms, ignores = value.get("terms", []), value.get("ignore", [])
    hints, off = value.get("hints", []), value.get("off", [])
    if not isinstance(terms, list) or not isinstance(ignores, list):
        raise ValueError("terms and ignore must be arrays")
    if not isinstance(hints, list) or any(not isinstance(h, str) or (h not in HINTS and h not in HINT_GROUPS)
                                          for h in hints) or len(set(hints)) != len(hints):
        raise ValueError("hints must be an array of distinct names from: " + ", ".join(HINTS + tuple(HINT_GROUPS)))
    # Turning a default rule off is the author's decision for this book (CON-011, exceptions, for the scene rules; the
    # same for the language scans of r5.33): rule and reason.
    if not isinstance(off, list) or any(not isinstance(x, dict) or set(x) != {"rule", "reason"}
                                        or x.get("rule") not in DEFAULT_RULES or not nonempty_string(x.get("reason"))
                                        for x in off):
        raise ValueError("off must be an array of {rule, reason}: a default rule (%s) the author turned off for this "
                         "book, and the author's reason" % ", ".join(DEFAULT_RULES))
    off_rules = [x["rule"] for x in off]
    if len(set(off_rules)) != len(off_rules) or set(off_rules) & set(expand_hints(hints)):
        raise ValueError("A default rule is turned off once, and not also listed under hints")
    ids = set()
    for term in terms:
        if not isinstance(term, dict) or set(term) != {"id", "text", "min_occurrences"}:
            raise ValueError("Each term needs id, text, min_occurrences")
        if not nonempty_string(term["id"]) or not nonempty_string(term["text"]):
            raise ValueError("Term id and text must be nonempty strings")
        if term["id"] in ids or term["id"] in BUILT_IN or term["id"] in HINTS:
            raise ValueError("Rule IDs must be unique and not reserved")
        ids.add(term["id"])
        count = term["min_occurrences"]
        if type(count) is not int or count < 1:
            raise ValueError("min_occurrences must be a positive integer")
    for item in ignores:
        if not isinstance(item, dict) or set(item) != {"rule", "line", "text", "reason"}:
            raise ValueError("Each ignore needs rule, line, text, reason")
        if item["rule"] not in ids | set(BUILT_IN) | set(HINTS):
            raise ValueError("Ignore refers to an unknown rule")
        if type(item["line"]) is not int or item["line"] < 1:
            raise ValueError("Ignore line must be a positive integer")
        if not all(nonempty_string(item[k]) for k in ("text", "reason")):
            raise ValueError("Ignore text and reason must be nonempty strings")
    # Two values, as before r5.32; the hints are read from the validated object by the caller.
    return terms, ignores


def expand_hints(names):
    """Hint names with the groups (r5.48: "deai") replaced by their members."""
    out = []
    for name in names:
        out.extend(HINT_GROUPS.get(name, (name,)))
    return out


def paragraphs_of(text, paragraph_mode):
    """(start offset, text) of every paragraph, surrounding whitespace removed; empty ones included."""
    separator = r"\n" if paragraph_mode == "line" else r"\n[ \t\r]*\n"
    out, offset = [], 0
    # Split on source spans, without normalizing newlines or moving offsets.
    for match in list(re.finditer(separator, text)) + [None]:
        end = match.start() if match else len(text)
        raw = text[offset:end]
        out.append((offset + len(raw) - len(raw.lstrip()), raw.strip()))
        offset = match.end() if match else len(text)
    return out


def is_bare_dialogue(paragraph):
    """A paragraph of quoted speech with nothing outside the quotes but who speaks and a speech verb."""
    if not QUOTE.search(paragraph):
        return False
    outside = "".join(ch for ch in QUOTE.sub("", paragraph) if ch.isalnum())
    return not outside or (len(outside) <= TAG_MAX and SPEECH_TAG.search(outside) is not None)


def han_count(text):
    return sum(1 for ch in text if "一" <= ch <= "鿿")


SENTENCE = re.compile(r"[^。！？!?]+[。！？!?]+")


def is_short_sentence(sentence):
    """One clause (no comma, colon or semicolon inside) of SHORT_MIN to SHORT_MAX Han characters; a system panel or a
    【label】 line is not narration."""
    body = sentence.rstrip("。！？!?")
    return not CLAUSE_BREAK.search(body) and "【" not in body and SHORT_MIN <= han_count(body) <= SHORT_MAX


def negation_tail(paragraph):
    """Offset of the last clause of a narration paragraph when it is a 没有／没再 brake; None otherwise."""
    tail = paragraph.rstrip().rstrip("。！？!?…—")
    if not tail or tail[-1] in "”」』":
        return None
    breaks = list(CLAUSE_BREAK.finditer(tail))
    start = breaks[-1].end() if breaks else 0
    clause = tail[start:]
    if NEGATION_CLAUSE.search(clause) and han_count(clause) <= 16 and not QUOTE.search(clause):
        return start + len(clause) - len(clause.lstrip())
    return None


def inspect_text(text, rules=None, paragraph_mode="blank", hints=(), scene_rules=True, language_rules=True):
    """scene_rules=False reads the text as r5.31 did, with no default rule; language_rules=False as r5.32 did (scene rules
    only). Both are only for comparing versions; the gate never sets them."""
    if paragraph_mode not in {"blank", "line"}:
        raise ValueError("paragraph_mode must be blank or line")
    rules = {} if rules is None else rules
    terms, ignores = validate_rules(rules)
    rule_hints = expand_hints(rules.get("hints", []))
    off = {x["rule"] for x in rules.get("off", [])}
    hints = expand_hints(hints)
    unknown = [h for h in hints if h not in HINTS]
    if unknown:
        raise ValueError("Unknown hint: " + ", ".join(unknown))
    on = (SCENE_RULES + (LANGUAGE_RULES if language_rules else ())) if scene_rules else ()
    defaults = {h for h in on if h not in off}
    enabled = [h for h in HINTS if h in defaults | set(rule_hints) | set(hints)]
    starts = [0] + [m.end() for m in re.finditer("\n", text)]

    def locate(offset):
        index = bisect.bisect_right(starts, offset) - 1
        return index + 1, offset - starts[index] + 1

    findings = []
    spans = {}  # rule -> (start, end) of every place it reported in this run, for the skip of add_phrases

    def add(rule, start, end, message, **extra):
        spans.setdefault(rule, []).append((start, end))
        line, column = locate(start)
        # Complete matched text stays internal for exact, scoped exemptions.
        findings.append({"rule": rule, "line": line, "column": column,
                         "quote": text[start:end][:160], "message": message,
                         "_matched": text[start:end], **extra})

    for match in PLACEHOLDER.finditer(text):
        add("placeholder", match.start(), match.end(),
            "复核是否为遗留写作备注；若为故事内真实文本可以保留。")

    paragraphs = paragraphs_of(text, paragraph_mode)
    seen = {}
    for start, paragraph in paragraphs:
        if len(paragraph) >= 12:
            if paragraph in seen:
                add("repeated-paragraph", start, start + len(paragraph),
                    "整段字面重复；检查是否为有意回声、引文或误粘贴。",
                    first_line=seen[paragraph])
            else:
                seen[paragraph] = locate(start)[0]

    for term in terms:
        matches = list(re.finditer(re.escape(term["text"]), text))
        if len(matches) >= term["min_occurrences"]:
            for match in matches:
                add(term["id"], match.start(), match.end(),
                    "达到项目设定的字面复核阈值；不是自动禁用。",
                    count=len(matches), threshold=term["min_occurrences"])

    xian_statistics = None
    if enabled:
        written = [(start, paragraph) for start, paragraph in paragraphs if paragraph]
        quoted = [(start + m.start(), start + m.end()) for start, paragraph in written
                  for m in QUOTE.finditer(paragraph)]

        def in_quote(offset):
            return any(a <= offset < b for a, b in quoted)

        def add_phrases(rule, pattern, spans, narration_only=False, skip=()):
            for start, paragraph in spans:
                for match in pattern.finditer(paragraph):
                    at = start + match.start()
                    inside = in_quote(at)
                    if inside and narration_only:
                        continue
                    # skip: (start, end) spans another rule already reports in this run (r5.49, the four deai-extra hints).
                    if any(a < start + match.end() and at < b for a, b in skip):
                        continue
                    add(rule, at, start + match.end(), HINT_MESSAGES[rule] + (IN_QUOTE_NOTE if inside else ""),
                        in_quote=inside)

        if 'xian-crutch' in enabled or 'xian-density' in enabled:
            narrative, complete = narration_mask(text)
            if 'xian-crutch' in enabled:
                for match in RE_NARRATIVE_XIAN_CRUTCH.finditer(narrative):
                    add('xian-crutch', match.start(), match.end(), HINT_MESSAGES['xian-crutch'], in_quote=False)
            if 'xian-density' in enabled:
                candidates = list(RE_NARRATIVE_XIAN_VERB.finditer(narrative))
                denominator = han_count(narrative)
                xian_statistics = {
                    'action_prefix_count': len(candidates),
                    'narrative_han_characters': denominator,
                    'per_1000_narrative_han': len(candidates) * 1000 / denominator if denominator and complete else None,
                    'quote_coverage_complete': complete,
                    'counting_basis': '叙述汉字数，排除引号内容；分子仅为字面模式候选，排除祖先/优先，不是完整分词或赘字数。',
                    'notice': HINT_MESSAGES['xian-density'] if complete else '引号未闭合或不配对，覆盖不完整；不输出全章可比较密度，先核对引号。',
                    'positions': [{'line': locate(m.start())[0], 'column': locate(m.start())[1], 'text': m.group()} for m in candidates],
                }

        if "floating-dialogue" in enabled:
            run = []
            for item in written + [None]:
                if item is not None and is_bare_dialogue(item[1]):
                    run.append(item)
                    continue
                if len(run) >= RUN_MIN:
                    first_start, first = run[0]
                    add("floating-dialogue", first_start, first_start + len(first),
                        HINT_MESSAGES["floating-dialogue"] % len(run),
                        paragraphs=len(run), last_line=locate(run[-1][0])[0])
                run = []
        if "tension-telling" in enabled:
            add_phrases("tension-telling", TENSION_LABELS, written)
        if "stock-reaction" in enabled:
            add_phrases("stock-reaction", STOCK_REACTIONS, written)
        if "weak-scene-ending" in enabled:
            endings, scene = [], []
            for item in written + [None]:
                if item is None or SCENE_BREAK.fullmatch(item[1]):
                    endings.extend(scene[-2:])
                    scene = []
                else:
                    scene.append(item)
            add_phrases("weak-scene-ending", WEAK_ENDINGS, endings)
        if "frequent-words" in enabled:
            for family, words in FREQUENT_WORDS:
                for word in words:
                    places = [m.start() for m in re.finditer(re.escape(word), text)]
                    if len(places) >= FREQUENT_MIN:
                        for at in places:
                            inside = in_quote(at)
                            add("frequent-words", at, at + len(word),
                                HINT_MESSAGES["frequent-words"] % (word, len(places), family)
                                + (IN_QUOTE_NOTE if inside else ""),
                                word=word, count=len(places), in_quote=inside)
        if "negation-ending" in enabled:
            brakes = []
            for start, paragraph in written:
                at = negation_tail(paragraph)
                if at is not None and not in_quote(start + at):
                    brakes.append((start + at, paragraph[at:].rstrip()))
            if len(brakes) >= NEGATION_MIN:
                for at, clause in brakes:
                    add("negation-ending", at, at + len(clause), HINT_MESSAGES["negation-ending"] % len(brakes),
                        count=len(brakes))
        if "parallel-run" in enabled:
            runs, run = [], []

            def close():
                if len(run) >= RUN_SENTENCES:
                    runs.append(list(run))
                run.clear()

            for start, paragraph in written:
                if QUOTE.search(paragraph) or SCENE_BREAK.fullmatch(paragraph):
                    close()
                    continue
                for m in SENTENCE.finditer(paragraph):
                    sentence = m.group().strip()
                    if not is_short_sentence(sentence):
                        close()
                        continue
                    lengths = [han_count(s) for _, s in run] + [han_count(sentence)]
                    if run and max(lengths) - min(lengths) > SHORT_SPREAD:
                        close()
                    run.append((start + m.start() + len(m.group()) - len(m.group().lstrip()), sentence))
            close()
            for item in runs:
                first_at, first = item[0]
                add("parallel-run", first_at, first_at + len(first), HINT_MESSAGES["parallel-run"] % len(item),
                    sentences=len(item), last_line=locate(item[-1][0])[0])
        if "inner-declaration" in enabled:
            add_phrases("inner-declaration", INNER_DECLARATION, written, narration_only=True)
        if "contrast-moral" in enabled:
            add_phrases("contrast-moral", CONTRAST_MORAL, written, narration_only=True)
        if "abstract-surge" in enabled:
            add_phrases("abstract-surge", ABSTRACT_SURGE, written, narration_only=True)
        if "stock-simile" in enabled:
            add_phrases("stock-simile", STOCK_SIMILES, written, narration_only=True)
        if "emotion-statement" in enabled:
            # A place that tension-telling (on by default) or abstract-surge has already reported above in this run is
            # not listed a second time; a rule that is off or not turned on reported nothing, so alone it lists as before.
            add_phrases("emotion-statement", EMOTION_STATEMENT, written, narration_only=True,
                        skip=spans.get("tension-telling", []) + spans.get("abstract-surge", []))
        if "reaction-wide" in enabled:
            # Where stock-reaction runs too, its places (in a line of speech as well) are not listed a second time.
            reported = [(start + m.start(), start + m.end()) for start, paragraph in written
                        for m in STOCK_REACTIONS.finditer(paragraph)] if "stock-reaction" in enabled else []
            add_phrases("reaction-wide", REACTION_WIDE, written, narration_only=True, skip=reported)
        if "simile-extra" in enabled:
            # Like reaction-wide: where stock-simile runs too, its places are not listed a second time (r5.49).
            reported = [(start + m.start(), start + m.end()) for start, paragraph in written
                        for m in STOCK_SIMILES.finditer(paragraph)] if "stock-simile" in enabled else []
            add_phrases("simile-extra", SIMILE_EXTRA, written, narration_only=True, skip=reported)
        if "theme-phrase" in enabled:
            # The same for what contrast-moral or weak-scene-ending (on by default, the last paragraphs) reported above.
            add_phrases("theme-phrase", THEME_PHRASES, written, narration_only=True,
                        skip=spans.get("contrast-moral", []) + spans.get("weak-scene-ending", []))
        if "soft-adverbs" in enabled:
            places = []  # (offset, word, paragraph index), narration only
            for index, (start, paragraph) in enumerate(written):
                for word in SOFT_ADVERBS:
                    for m in re.finditer(word, paragraph):
                        if not in_quote(start + m.start()):
                            places.append((start + m.start(), word, index))
            per_paragraph = {}
            for at, word, index in places:
                per_paragraph.setdefault(index, []).append((at, word))
            listed = places if len(places) >= SOFT_IN_TEXT else \
                [p for p in places if len(per_paragraph[p[2]]) >= SOFT_IN_PARAGRAPH]
            for at, word, index in sorted(listed):
                where = ("一段里 %d 个" % len(per_paragraph[index]) if len(per_paragraph[index]) >= SOFT_IN_PARAGRAPH
                         else "全文 %d 个" % len(places))
                add("soft-adverbs", at, at + len(word), HINT_MESSAGES["soft-adverbs"] % where, word=word)
        if "short-beats" in enabled:
            beats = []
            for index, (start, paragraph) in enumerate(written):
                sentences = SENTENCE.findall(paragraph) or [paragraph]
                if (len(sentences) == 1 and not QUOTE.search(paragraph) and not SCENE_BREAK.fullmatch(paragraph)
                        and "【" not in paragraph and 0 < han_count(paragraph) <= SHORT_BEAT_MAX):
                    neighbours = [written[k][1] for k in (index - 1, index + 1) if 0 <= k < len(written)]
                    # A beat stands between longer paragraphs; a run of one-line paragraphs is P11's business.
                    if neighbours and all(han_count(n) > SHORT_BEAT_MAX for n in neighbours):
                        beats.append((start, paragraph))
            if len(beats) >= SHORT_BEATS_MIN:
                for at, paragraph in beats:
                    add("short-beats", at, at + len(paragraph), HINT_MESSAGES["short-beats"] % len(beats),
                        count=len(beats))
        if "list-of-three" in enabled:
            for start, paragraph in written:
                for m in LIST_OF_THREE.finditer(paragraph):
                    at = start + m.start()
                    inside = in_quote(at)
                    add("list-of-three", at, start + m.end(),
                        HINT_MESSAGES["list-of-three"] + (IN_QUOTE_NOTE if inside else ""), in_quote=inside)

    findings.sort(key=lambda f: (f["line"], f["column"], f["rule"]))
    active, suppressed, used = [], [], set()
    for finding in findings:
        matched = finding.pop("_matched")
        exemptions = [(i, item) for i, item in enumerate(ignores)
                      if item["rule"] == finding["rule"]
                      and item["line"] == finding["line"]
                      and item["text"] == matched]
        if exemptions:
            used.update(i for i, _ in exemptions)
            suppressed.append({**finding, "reasons": [x["reason"] for _, x in exemptions]})
        else:
            active.append(finding)
    report = {
        "status": "REVIEW" if active else "NO_FLAGS",
        "non_whitespace_characters": sum(not ch.isspace() for ch in text),
        "counting_basis": "Unicode non-whitespace characters including punctuation",
        "paragraph_mode": paragraph_mode,
        "checks_run": list(BUILT_IN) + [t["id"] for t in terms] + enabled,
        # r5.49: which checks ran, in three lists (the project's own terms are in checks_run only): the built-in and
        # default checks, the optional hints turned on (by --hint or the rules file), and the optional hints not run.
        # off_but_run: default rules the author turned off for this book that --hint (a name or all) ran this time
        # anyway; they are neither default checks nor optional hints. The gate passes no hints, so there they stay off.
        "checks_default": list(BUILT_IN) + [h for h in enabled if h in defaults],
        "hints_on": [h for h in enabled if h not in defaults and h not in off],
        "off_but_run": [h for h in enabled if h in off],
        "hints_off": [h for h in HINTS if h not in enabled and h not in DEFAULT_RULES],
        "turned_off": [dict(x) for x in rules.get("off", [])],
        "findings": active, "suppressed": suppressed,
        "unused_ignores": [item for i, item in enumerate(ignores) if i not in used],
        "limits": ("仅为字面复核线索，不判断文笔、完整性、原创性或AI来源；不修改文件。命中不等于写错，"
                   "要回到上下文判断；没有命中也不说明写得好或没有 AI 腔，只说明这些字面规则没碰上。"),
    }
    if xian_statistics is not None:
        report['xian_statistics'] = xian_statistics
    return report


def utf8_stdio():
    """Reports are UTF-8 on every platform; a Windows pipe would otherwise use the local code page."""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main():
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manuscript", type=Path)
    parser.add_argument("--rules", type=Path)
    parser.add_argument(
        "--paragraph-mode", choices=("blank", "line"), default="blank",
        help="paragraph boundaries for repeated paragraphs and the paragraph hints: blank lines (default), or each "
             "nonempty line",
    )
    parser.add_argument(
        "--hint", action="append", choices=HINTS + tuple(HINT_GROUPS) + ("all",), default=[],
        help="also run an optional hint (repeatable; 'deai' for six de-AI hints, 'deai-extra' for four more, 'xian' for narration order-word hints, 'all' for "
             "every one); the three "
             "scene rules and the four language scans run anyway unless the rules file turns one off by the author's "
             "decision, see prose-audit.md",
    )
    parser.add_argument(
        "--format", choices=("json", "text"), default="json",
        help="json (default; what the delivery gate reads) or text: a short report in Chinese to read after writing a "
             "chapter, the first of the five revision passes",
    )
    args = parser.parse_args()
    hints = HINTS if "all" in args.hint else tuple(args.hint)
    try:
        data = args.manuscript.read_bytes()
        rules = json.loads(args.rules.read_text(encoding="utf-8")) if args.rules else {}
        report = inspect_text(data.decode("utf-8-sig"), rules, args.paragraph_mode, hints)
        report.update({"file": str(args.manuscript),
                       "sha256": hashlib.sha256(data).hexdigest()})
        print(text_report(report) if args.format == "text" else json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    except (OSError, UnicodeError, ValueError, TypeError) as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False))
        return 2


def text_report(report):
    """The report for a person: what was found where, grouped by rule; the same facts as the JSON, nothing more."""
    findings = report["findings"]
    out = ["文字检查：%s（sha256 %s…，非空白字符 %d，分段：%s）" % (
               report.get("file", ""), report.get("sha256", "")[:12], report["non_whitespace_characters"],
               "空行" if report["paragraph_mode"] == "blank" else "每行一段"),
           "结果：%s" % ("要看的 %d 处" % len(findings) if findings else "没有命中（只说明这几条字面规则没命中，不说明文字没问题）")]
    # r5.49: which checks ran, so that a default run and a run with more hints do not read the same.
    names = lambda rules: "、".join(rules) if rules else "没有"
    out.append("默认检查（%d 项）：%s" % (len(report.get("checks_default", [])), names(report.get("checks_default", []))))
    terms = [r for r in report["checks_run"] if r not in BUILT_IN and r not in HINTS]
    if terms:
        out.append("本书规则文件里的用词（%d 项）：%s" % (len(terms), names(terms)))
    out.append("另开的可选提示（%d 项）：%s" % (len(report.get("hints_on", [])), names(report.get("hints_on", []))))
    hints_off = report.get("hints_off", [])
    out.append("没开的可选提示（%d 项）：%s%s" % (
        len(hints_off), names(hints_off),
        "。这几项没有查，没命中不说明没有；要查就加 --hint 和名字，或 deai、deai-extra、all" if hints_off else ""))
    if report["turned_off"]:
        out.append("本书关掉的：" + "；".join("%s（%s）" % (x["rule"], x["reason"]) for x in report["turned_off"]))
    if report.get("off_but_run"):
        out.append("本书关掉、这次因 --hint 又查了的（%d 项）：%s。命中照常列在下面，只是回去重读的地方，不是结论；"
                   "不加 --hint 时仍按作者的决定不查" % (len(report["off_but_run"]), names(report["off_but_run"])))
    if 'xian_statistics' in report:
        stats = report['xian_statistics']
        density = '不适用' if stats['per_1000_narrative_han'] is None else '%.2f' % stats['per_1000_narrative_han']
        out.append('叙述“先＋动作”字面候选：%d 次；叙述汉字 %d；每千叙述汉字：%s。%s' % (
            stats['action_prefix_count'], stats['narrative_han_characters'], density, stats['notice']))
    groups = {}
    for finding in findings:
        groups.setdefault(finding["rule"], []).append(finding)
    for rule in [r for r in report["checks_run"] if r in groups] + [r for r in groups if r not in report["checks_run"]]:
        items = groups[rule]
        out.append("")
        out.append("【%s】%s，%d 处" % (rule, RULE_LABELS.get(rule, "项目用词"), len(items)))
        if rule == "frequent-words":
            words = {}
            for f in items:
                words.setdefault(f["word"], []).append(f)
            for word, places in words.items():
                out.append("  “%s” %d 次：第 %s 行" % (word, places[0]["count"],
                                                     "、".join(str(f["line"]) for f in places)))
            out.append("  " + items[0]["message"].split("：", 1)[1])
            continue
        for f in items:
            where = "第 %d 行" % f["line"] + ("—第 %d 行" % f["last_line"] if f.get("last_line", f["line"]) != f["line"] else "")
            quote = f["quote"].replace("\n", " ")
            out.append("  %s：%s%s" % (where, quote[:40] + ("…" if len(quote) > 40 else ""), "（台词里）" if f.get("in_quote") else ""))
        out.append("  " + items[0]["message"])
    if report["suppressed"]:
        out.append("")
        out.append("按规则文件放过的 %d 处（有作者的理由）。" % len(report["suppressed"]))
    out.append("")
    out.append(report["limits"])
    return "\n".join(out)


if __name__ == "__main__":
    sys.exit(main())

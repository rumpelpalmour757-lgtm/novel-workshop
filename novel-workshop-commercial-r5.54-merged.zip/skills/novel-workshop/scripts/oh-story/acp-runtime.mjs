// 找 Google 官方的 ACP 运行时、核对、启动、收尾。工坊不下载、不安装、不修改官方程序，
// 也不碰它的登录缓存；这里只做四件事：
// 1) 找到要启动的那个文件：作者在设置里填的绝对路径优先，否则在 PATH 里找 agy（Windows 上是 agy.exe / agy.cmd / agy.bat）；
// 2) 记下路径、种类（官方 CLI：agy acp；ACP Registry 发行包：agy_acp_server，参数照发行清单）、
//    CLI 的 agy --version、所启动文件的大小和 SHA-256，以及和作者贴的校验值是否一致；
// 3) 用参数数组启动（不经过 shell），工作目录是系统临时目录里新建的空目录，只把少量必需的环境变量交给它
//    （不交任何 API Key、工坊自己的设置和别的密钥）；Windows 的 .cmd/.bat 启动脚本经 cmd.exe /d /s /c 小心加引号启动
//    （这一条没有在真实的 Windows 上跑过）；
// 4) 只记、只结束工坊自己启动的进程：断开、出错、写作台退出时结束它们（POSIX 上连同它自己的进程组），
//    不动作者在别处开着的官方程序。
//
// 四种状态：未安装、路径错误、校验不符、可启动。“可启动”只说明找到了、校验对得上，不说明能登录或能用。

import { spawn, spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { createReadStream, rmSync, constants as fsConstants } from "node:fs";
import { access, lstat, mkdtemp, readdir, realpath, rm, stat } from "node:fs/promises";
import { homedir, tmpdir } from "node:os";
import { basename, dirname, join, posix, resolve, win32 } from "node:path";

export const RUNTIME_LABELS = Object.freeze({
  not_installed: "未安装",
  path_invalid: "路径错误",
  checksum_mismatch: "校验不符",
  launchable: "可启动",
});

// ACP Registry 里 Google 的 antigravity-acp 发行清单（v1.4.5，Google LLC，专有软件），2026-11-05 由维护者从
// https://github.com/agentclientprotocol/registry/blob/main/antigravity-acp/agent.json 核对。
// 注意：这些 SHA-256 是 dl.google.com 上各平台 zip 压缩包的校验值，不是解压出来的程序本身的。
export const REGISTRY_RELEASE = Object.freeze({
  id: "antigravity-acp",
  version: "1.4.5",
  vendor: "Google LLC",
  license: "proprietary",
  manifest: "https://github.com/agentclientprotocol/registry/blob/main/antigravity-acp/agent.json",
  download: "https://dl.google.com/agy-extensions/releases/",
  checksumOf: "zip",
  archives: Object.freeze({
    "windows-x86_64": Object.freeze({ sha256: "d24f4c73c9f96d4f44384e281c855a56c72d8eaa9c5b0fad7ccb1635c6b63f50", cmd: "./agy_acp_server.exe", args: Object.freeze([]) }),
    "windows-aarch64": Object.freeze({ sha256: "ab0a9aac8349e08ef289be6d16da8f89e3abe60eba5158032ef78c4a1220261c", cmd: "./agy_acp_server.exe", args: Object.freeze([]) }),
    "darwin-aarch64": Object.freeze({ sha256: "886fff7767d08994ca39eb02c3d01a7532c7325a94aa33aaf52d52068733284f", cmd: "./agy_acp_server.par", args: Object.freeze([]) }),
    "darwin-x86_64": Object.freeze({ sha256: "b39f3573c03b9acb9df028853f647527f1f3133f32bd77e78b796e48a205114a", cmd: "./agy_acp_server.par", args: Object.freeze([]) }),
    "linux-x86_64": Object.freeze({ sha256: "923923a0d7dc8073f66cc6f78647a3107e3a7ee2b7e1a24df8b3927b5188013b", cmd: "./agy_acp_server.par", args: Object.freeze(["--uid="]) }),
    "linux-aarch64": Object.freeze({ sha256: "7d64246633ae094f67e3bbcd2d679e89048f91346d5339313336e7483f40f056", cmd: "./agy_acp_server.par", args: Object.freeze(["--uid="]) }),
  }),
});

// 连接时可以多带的官方 CLI 开关：只认这三个，默认一个都不带；它们放在 agy acp 后面的效果没有核实过。
// 永远不带 --dangerously-skip-permissions、--add-dir、-p。
export const ALLOWED_FLAGS = Object.freeze(["--sandbox", "--disable-telemetry", "--process-per-session"]);

const COMMON_ENV = ["PATH", "HTTPS_PROXY", "HTTP_PROXY", "NO_PROXY", "ALL_PROXY", "LANG", "LANGUAGE", "LC_ALL", "LC_CTYPE", "LC_MESSAGES", "TZ", "SSL_CERT_FILE", "SSL_CERT_DIR", "NODE_EXTRA_CA_CERTS"];
const POSIX_ENV = ["HOME", "USER", "LOGNAME", "TMPDIR", "DISPLAY", "WAYLAND_DISPLAY", "XDG_RUNTIME_DIR", "XDG_CONFIG_HOME", "XDG_DATA_HOME", "XDG_CACHE_HOME", "XDG_STATE_HOME", "XDG_CURRENT_DESKTOP", "XDG_SESSION_TYPE", "DBUS_SESSION_BUS_ADDRESS", "BROWSER"];
const WINDOWS_ENV = ["SYSTEMROOT", "WINDIR", "SYSTEMDRIVE", "COMSPEC", "PATHEXT", "USERPROFILE", "HOMEDRIVE", "HOMEPATH", "USERNAME", "USERDOMAIN", "APPDATA", "LOCALAPPDATA", "PROGRAMDATA", "PROGRAMFILES", "PROGRAMFILES(X86)", "PROGRAMW6432", "COMMONPROGRAMFILES", "COMMONPROGRAMFILES(X86)", "TEMP", "TMP", "OS", "PROCESSOR_ARCHITECTURE", "NUMBER_OF_PROCESSORS", "COMPUTERNAME"];
// 交给官方程序的环境变量，只有这些（名字里没有 KEY、TOKEN、SECRET 之类的东西）。
export const ENV_PASSTHROUGH = Object.freeze({
  posix: Object.freeze([...COMMON_ENV, ...POSIX_ENV]),
  win32: Object.freeze([...COMMON_ENV, ...WINDOWS_ENV]),
});

const WORK_PREFIX = "novel-workshop-acp-";
const VERSION_TIMEOUT_MS = 15_000;
const STOP_GRACE_MS = 1500;

export class RuntimeLaunchError extends Error {
  constructor(code, message) {
    super(message);
    this.name = "RuntimeLaunchError";
    this.code = code;
  }
}

export function platformKey(platform = process.platform, arch = process.arch) {
  const os = platform === "win32" ? "windows" : platform;
  const cpu = arch === "x64" ? "x86_64" : arch === "arm64" ? "aarch64" : arch;
  return `${os}-${cpu}`;
}

export function registryArchive(platform = process.platform, arch = process.arch) {
  const key = platformKey(platform, arch);
  const entry = REGISTRY_RELEASE.archives[key];
  return entry ? { key, ...entry } : null;
}

export function registryMatch(sha256) {
  const value = normalizeSha256(sha256);
  if (!value) return null;
  for (const [key, entry] of Object.entries(REGISTRY_RELEASE.archives)) {
    if (entry.sha256 === value) return { key, ...entry };
  }
  return null;
}

export function normalizeSha256(value) {
  if (typeof value !== "string") return null;
  const text = value.trim().replace(/^sha256[:=]\s*/i, "").replace(/\s+/g, "").toLowerCase();
  return /^[a-f0-9]{64}$/.test(text) ? text : null;
}

export async function sha256File(path) {
  const hash = createHash("sha256");
  let size = 0;
  await new Promise((accept, reject) => {
    const stream = createReadStream(path);
    stream.on("data", (chunk) => {
      size += chunk.length;
      hash.update(chunk);
    });
    stream.on("error", reject);
    stream.on("end", accept);
  });
  return { sha256: hash.digest("hex"), size };
}

// 文件名认种类：官方 CLI 叫 agy；ACP Registry 发行包里的程序叫 agy_acp_server（.par 或 .exe）。
export function runtimeKindFor(name, platform = process.platform) {
  const lower = String(name || "").toLowerCase();
  if (/^agy(\.exe|\.cmd|\.bat)?$/.test(lower)) return "agy-cli";
  if (/^agy_acp_server(\.par|\.exe)?$/.test(lower)) return "registry-binary";
  return null;
}

export function connectionArgs(kind, platform = process.platform, flags = []) {
  if (kind === "agy-cli") return ["acp", ...flags.filter((flag) => ALLOWED_FLAGS.includes(flag))];
  // 发行清单：linux 两个平台加 --uid=，其他平台不加参数。
  return platform === "linux" ? ["--uid="] : [];
}

export function lookupNames(platform = process.platform) {
  return platform === "win32" ? ["agy.exe", "agy.cmd", "agy.bat"] : ["agy"];
}

function pathDelimiter(platform) {
  return platform === "win32" ? ";" : ":";
}

function envValue(env, name) {
  if (typeof env?.[name] === "string") return env[name];
  const upper = name.toUpperCase();
  for (const [key, value] of Object.entries(env || {})) {
    if (key.toUpperCase() === upper && typeof value === "string") return value;
  }
  return undefined;
}

async function isRunnableFile(path, platform) {
  const info = await stat(path).catch(() => null);
  if (!info?.isFile()) return false;
  if (platform === "win32") return true;
  return access(path, fsConstants.X_OK).then(() => true, () => false);
}

export async function findOnPath(env = process.env, platform = process.platform) {
  const raw = envValue(env, "PATH") || "";
  for (const entry of raw.split(pathDelimiter(platform))) {
    const folder = entry.trim().replace(/^"(.*)"$/, "$1");
    if (!folder) continue;
    for (const name of lookupNames(platform)) {
      const candidate = platform === "win32" ? win32.join(folder, name) : posix.join(folder, name);
      if (await isRunnableFile(candidate, platform)) return candidate;
    }
  }
  return null;
}

// 诊断文字里去掉主目录路径（换成 ~）和像密钥、令牌的字样：作者可以把诊断发给别人看。
export function makeScrubber({ home = homedir(), env = process.env, platform = process.platform } = {}) {
  const variants = new Set();
  for (const value of [home, envValue(env, "USERPROFILE"), envValue(env, "HOME")]) {
    if (typeof value !== "string" || value.length < 3) continue;
    variants.add(value);
    variants.add(value.replaceAll("\\", "/"));
    variants.add(value.replaceAll("/", "\\"));
  }
  const homes = [...variants].sort((a, b) => b.length - a.length);
  const caseless = platform === "win32" || platform === "darwin";
  const escape = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  // 前后不能紧挨着别的路径字符：/root 不该把 /tmp/x/rootfs 也换掉。
  const homePattern = homes.length
    ? new RegExp(`(?<![A-Za-z0-9_.-])(?:${homes.map(escape).join("|")})(?![A-Za-z0-9_.-])`, caseless ? "gi" : "g")
    : null;
  return (input) => {
    let text = String(input ?? "");
    if (homePattern) text = text.replace(homePattern, "~");
    return text
      .replace(/[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}/g, "［已隐去的邮箱］")
      .replace(/eyJ[\w-]{4,}\.[\w-]{4,}\.[\w-]*/g, "［已隐去］")
      .replace(/\b4\/[0-9A-Za-z_-]{10,}/g, "［已隐去］")
      .replace(/GOCSPX-[\w-]+/g, "［已隐去］")
      .replace(/ya29\.[0-9A-Za-z._-]+/g, "［已隐去］")
      .replace(/1\/\/0[0-9A-Za-z_-]{16,}/g, "［已隐去］")
      .replace(/AIza[0-9A-Za-z_-]{30,}/g, "［已隐去］")
      .replace(/\b(bearer)\s+[0-9A-Za-z._~+/-]+=*/gi, "$1 ［已隐去］")
      .replace(/(["']?\b(?:access|refresh|id)[_ -]?token["']?\s*[:= ]\s*["']?|["']?\b(?:code|state|client_secret|password)["']?\s*[:=]\s*["']?)[^\s"',}&]+/gi, "$1［已隐去］");
  };
}

export function minimalEnv(env = process.env, platform = process.platform) {
  const allowed = new Set(platform === "win32" ? ENV_PASSTHROUGH.win32 : ENV_PASSTHROUGH.posix);
  const out = {};
  for (const [key, value] of Object.entries(env || {})) {
    if (typeof value !== "string") continue;
    if (platform === "win32") {
      if (allowed.has(key.toUpperCase())) out[key] = value;
    } else if (allowed.has(key) || (/_PROXY$/i.test(key) && allowed.has(key.toUpperCase()))) {
      out[key] = value;
    }
  }
  return out;
}

// Windows 的 .cmd/.bat 不能直接当程序启动（Node 会拒绝），要交给 cmd.exe：
// cmd.exe /d /v:off /s /c ""C:\路径 有空格\agy.cmd" acp"。/d 不跑 AutoRun，/v:off 关掉 ! 展开，
// /s 让 cmd 只去掉最外面一对引号。路径里有 " % ! 或换行时 cmd 会误读，干脆不启动。没有在真实的 Windows 上跑过。
function cmdQuote(value) {
  const text = String(value);
  if (!text || /["%!\r\n\0]/.test(text)) {
    throw new RuntimeLaunchError("unsafe_shim_path", "路径或参数里有 \" % ! 或换行，cmd.exe 会读错，工坊不启动它；把官方程序放到不含这些字符的文件夹里");
  }
  return /^[A-Za-z0-9_\-.=:\\/]+$/.test(text) ? text : `"${text}"`;
}

export function windowsShimLaunch(shimPath, argv, env = process.env) {
  const systemRoot = envValue(env, "SystemRoot") || envValue(env, "windir") || "C:\\Windows";
  const command = win32.join(systemRoot, "System32", "cmd.exe");
  const line = [cmdQuote(shimPath), ...argv.map(cmdQuote)].join(" ");
  return { command, args: ["/d", "/v:off", "/s", "/c", `"${line}"`], verbatim: true };
}

export function isWindowsShim(path, platform = process.platform) {
  return platform === "win32" && /\.(cmd|bat)$/i.test(String(path || ""));
}

// 启动的是作者填的那个路径（snap、volta 这类按自己名字分派的启动器要靠它）；紧挨着启动之前，
// startRuntime 再核对一次它解析到的还是检查时那个文件（verifyRuntimeUnchanged）。核对和启动之间还剩一点点空隙，
// 这个空隙里换掉文件的情况工坊挡不住（见说明文档）。Windows 的 .cmd/.bat 经 cmd.exe 启动脚本本身。
export function buildLaunch(runtime, argv, { platform = process.platform, env = process.env } = {}) {
  if (isWindowsShim(runtime.path, platform)) return windowsShimLaunch(runtime.path, argv, env);
  return { command: runtime.path, args: [...argv], verbatim: false };
}

function identityOf(path, info) {
  return { realPath: path, dev: info.dev, ino: info.ino, size: info.size, mtimeMs: info.mtimeMs };
}

function sameIdentity(left, right) {
  return Boolean(left && right) && ["realPath", "dev", "ino", "size", "mtimeMs"].every((key) => left[key] === right[key]);
}

// Windows：这台电脑上的其他账号一般能写的地方（C:\Users\Public、C:\ProgramData、别人的用户文件夹）里的程序不启动；
// 在你自己的用户文件夹或 Program Files 里的照常；别的地方给一句提醒（工坊在 Windows 上不查 ACL）。没有在真实的 Windows 上跑过。
export function windowsLocationCheck(path, realPath, env = process.env) {
  const norm = (value) => win32.resolve(String(value)).toLowerCase().replace(/[\\/]+$/, "");
  const inside = (value, root) => {
    const a = norm(value);
    const b = norm(root);
    return a === b || a.startsWith(`${b}\\`);
  };
  const profile = envValue(env, "USERPROFILE");
  const own = [profile, envValue(env, "LOCALAPPDATA"), envValue(env, "APPDATA")].filter(Boolean);
  const programs = [envValue(env, "ProgramFiles"), envValue(env, "ProgramFiles(x86)"), envValue(env, "ProgramW6432")].filter(Boolean);
  const drive = envValue(env, "SystemDrive") || "C:";
  const usersRoot = profile ? win32.dirname(profile) : win32.join(`${drive}\\`, "Users");
  const publicDir = envValue(env, "PUBLIC") || win32.join(usersRoot, "Public");
  const programData = envValue(env, "ProgramData") || envValue(env, "ALLUSERSPROFILE") || win32.join(`${drive}\\`, "ProgramData");
  for (const candidate of new Set([path, realPath].filter(Boolean))) {
    if (inside(candidate, publicDir)) return { refuse: `程序在 ${publicDir} 下面，这台电脑上的其他账号一般都能改这里`, warnings: [] };
    if (inside(candidate, programData)) return { refuse: `程序在 ${programData} 下面，这台电脑上的其他账号一般都能改这里`, warnings: [] };
    if (inside(candidate, usersRoot) && !own.some((root) => inside(candidate, root))) {
      return { refuse: `程序在别的账号的用户文件夹里（${usersRoot} 下面，不是你的 ${profile || "用户文件夹"}）`, warnings: [] };
    }
  }
  const safe = (candidate) => own.some((root) => inside(candidate, root)) || programs.some((root) => inside(candidate, root));
  if (![path, realPath].filter(Boolean).every(safe)) {
    return { refuse: null, warnings: ["程序不在你的用户文件夹或 Program Files 里：工坊在 Windows 上不查文件夹的权限（ACL），请自己确认这台电脑上的其他账号改不了它"] };
  }
  return { refuse: null, warnings: [] };
}

// 别的用户能改的程序或文件夹不启动：同一台电脑上的另一个账号可以在那里放一个同名程序。
// POSIX：所有者不是你也不是系统、或者谁都能写的，不启动；只有同组能写的照常，但给一句提醒。
async function placementProblems(path, realPath, platform, env) {
  if (platform === "win32") return windowsLocationCheck(path, realPath, env);
  if (typeof process.getuid !== "function") return { refuse: null, warnings: [] };
  const me = process.getuid();
  const checks = [[realPath, "这个程序文件"], [dirname(realPath), "程序所在的文件夹"]];
  if (path !== realPath) checks.push([dirname(path), "链接所在的文件夹"]);
  const warnings = [];
  for (const [target, what] of checks) {
    const info = await stat(target).catch(() => null);
    if (!info) continue;
    if (info.uid !== me && info.uid !== 0) return { refuse: `${what}（${target}）的所有者不是你，也不是系统`, warnings };
    const sticky = info.isDirectory() && (info.mode & 0o1000);
    if ((info.mode & 0o002) && !sticky) return { refuse: `${what}（${target}）别的用户也能改`, warnings };
    if ((info.mode & 0o020) && !sticky) warnings.push(`同组的其他用户能改这个程序或文件夹：${what}（${target}）。确认这个组里只有你信得过的账号`);
  }
  return { refuse: null, warnings };
}

export function commandLine(runtime, argv = runtime.args, platform = process.platform) {
  const quote = (text) => (/[\s"']/.test(text) ? `"${text}"` : text);
  return [runtime.path, ...argv].map(quote).join(" ") + (isWindowsShim(runtime.path, platform) ? "（经 cmd.exe /d /v:off /s /c 启动）" : "");
}

function invalid(state, message, extra = {}) {
  return { state, label: RUNTIME_LABELS[state], message, ...extra };
}

// 查一遍运行时。probeVersion 为真时对官方 CLI 跑一次 agy --version（参数数组、不经 shell、有超时）。
export async function inspectRuntime({
  configuredPath = null,
  kind = null,
  expectedSha256 = null,
  flags = [],
  env = process.env,
  platform = process.platform,
  arch = process.arch,
  probe = true,
  versionTimeoutMs = VERSION_TIMEOUT_MS,
  source = null,
  now = () => new Date(),
} = {}) {
  const checkedAt = now().toISOString();
  const registry = registryArchive(platform, arch);
  const base = {
    checkedAt,
    registry: { version: REGISTRY_RELEASE.version, platformKey: platformKey(platform, arch), archiveSha256: registry?.sha256 || null, cmd: registry?.cmd || null, checksumOf: "zip" },
  };
  let path = configuredPath;
  let from = source || (configuredPath ? "configured" : null);
  if (!path) {
    path = await findOnPath(env, platform);
    from = "path";
    if (!path) {
      return invalid("not_installed", `没有找到官方运行时：设置里没有填路径，PATH 里也没有 ${lookupNames(platform).join(" / ")}。按说明装好 Antigravity CLI（agy）或 ACP Registry 的 antigravity-acp，再把程序的完整路径填进来。`, { ...base, source: null, path: null });
    }
  }
  const absolute = typeof path === "string" && (platform === "win32" ? win32.isAbsolute(path) : posix.isAbsolute(path));
  if (typeof path !== "string" || /[\0\r\n]/.test(path) || !absolute) {
    return invalid("path_invalid", "运行时路径要写完整的绝对路径（比如 C:\\Users\\你\\AppData\\Local\\agy\\agy.exe 或 /usr/local/bin/agy）。", { ...base, source: from, path: String(path) });
  }
  const info = await lstat(path).catch((error) => error);
  if (info instanceof Error) {
    return invalid("path_invalid", info.code === "ENOENT" ? `找不到这个文件：${path}` : `读不到这个文件（${info.code || "出错"}）：${path}`, { ...base, source: from, path });
  }
  // 总是解析成规范的真实路径（上一级文件夹是链接、大小写不同、/tmp 这种都算），后面的身份核对都拿它比。
  const realPath = await realpath(path).catch(() => null);
  if (!realPath) return invalid("path_invalid", info.isSymbolicLink() ? `这是一个指向不存在文件的链接：${path}` : `读不到这个文件：${path}`, { ...base, source: from, path });
  const target = await stat(realPath).catch(() => null);
  if (!target?.isFile()) {
    return invalid("path_invalid", target?.isDirectory() ? `这是一个文件夹，不是程序：${path}。要选文件夹里的 agy 或 agy_acp_server。` : `这不是普通文件：${path}`, { ...base, source: from, path });
  }
  if (platform !== "win32" && !(await isRunnableFile(realPath, platform))) {
    return invalid("path_invalid", `这个文件没有执行权限：${path}。解压后要先 chmod +x 一次。`, { ...base, source: from, path });
  }
  const placement = await placementProblems(path, realPath, platform, env);
  if (placement.refuse) return invalid("path_invalid", `不启动它：${placement.refuse}。把官方程序放到只有你能改的文件夹里。`, { ...base, source: from, path });
  const detected = runtimeKindFor(basename(path), platform);
  const chosenKind = kind === "agy-cli" || kind === "registry-binary" ? kind : detected;
  if (!chosenKind) {
    return invalid("path_invalid", `认不出这是哪种官方程序：${basename(path)}。官方 CLI 叫 agy，ACP Registry 发行包里的程序叫 agy_acp_server；改过名字的，在设置里注明类型。`, { ...base, source: from, path });
  }
  const shim = isWindowsShim(path, platform);
  const cleanFlags = chosenKind === "agy-cli" ? flags.filter((flag) => ALLOWED_FLAGS.includes(flag)) : [];
  const runtime = {
    ...base,
    source: from,
    path,
    realPath,
    kind: chosenKind,
    args: connectionArgs(chosenKind, platform, cleanFlags),
    flags: cleanFlags,
    shim,
    hashOf: shim ? "windows-shim" : realPath !== path ? "link-target" : "file",
    warnings: placement.warnings,
  };
  runtime.commandLine = commandLine(runtime, runtime.args, platform);
  if (shim) {
    try {
      windowsShimLaunch(path, runtime.args, env);
    } catch (error) {
      return invalid("path_invalid", error.message, runtime);
    }
  }
  try {
    runtime.identity = identityOf(realPath, target);
    const digest = await sha256File(realPath);
    runtime.size = digest.size;
    runtime.sha256 = digest.sha256;
  } catch (error) {
    return invalid("path_invalid", `读不了这个文件来算校验值（${error.code || "出错"}）：${path}`, runtime);
  }
  const expected = normalizeSha256(expectedSha256);
  runtime.checksum = { expected, match: expected ? expected === runtime.sha256 : null };
  if (expected && expected !== runtime.sha256) {
    const zip = registryMatch(expected);
    const hint = zip
      ? `你填的是 ACP Registry 里 ${zip.key} 那个 zip 压缩包的校验值，不是解压出来的程序的；压缩包要在解压前核对（check-acp --zip 下载的zip）。`
      : "官方程序可能升级过，或者不是你核对过的那一份。";
    return { ...runtime, state: "checksum_mismatch", label: RUNTIME_LABELS.checksum_mismatch, message: `校验不符：这个文件的 SHA-256 是 ${runtime.sha256}，和你填的 ${expected} 不一样。${hint}` };
  }
  if (probe && chosenKind === "agy-cli") {
    // 先核对校验值再运行；运行完再看一眼文件，查版本的时候它自己变了（比如自动升级）就不算核对过。
    const version = await probeVersion(runtime, { env, platform, timeoutMs: versionTimeoutMs });
    runtime.version = version.version;
    runtime.versionNote = version.note;
    const after = await stat(realPath).catch(() => null);
    const resolved = await realpath(path).catch(() => null);
    if (version.changed || !after || resolved !== realPath || !sameIdentity(runtime.identity, identityOf(realPath, after))) {
      return { ...runtime, state: "checksum_mismatch", label: RUNTIME_LABELS.checksum_mismatch, message: "官方程序在查版本的时候变了（可能自己升级了，或者链接指向了别的文件）：刚才算的校验值不再对应它。重新点“检查运行时”。" };
    }
  } else {
    runtime.version = null;
    runtime.versionNote = chosenKind === "registry-binary" ? "ACP Registry 发行包不另查版本，以握手时官方程序报的 agentInfo 为准" : "这次没有查版本";
  }
  return {
    ...runtime,
    state: "launchable",
    label: RUNTIME_LABELS.launchable,
    message: expected
      ? "可启动：找到了官方程序，SHA-256 和你填的一致。能不能登录、能不能用，要连接以后才知道。"
      : "可启动：找到了官方程序（没有填校验值，只记下了它的 SHA-256）。能不能登录、能不能用，要连接以后才知道。",
  };
}

export async function probeVersion(runtime, { env = process.env, platform = process.platform, timeoutMs = VERSION_TIMEOUT_MS } = {}) {
  const scrub = makeScrubber({ env, platform });
  // 和连接时一样，在新建的空目录里运行，不在共用的系统临时目录本身里。
  let cwd;
  try {
    cwd = await makeWorkDirectory();
  } catch (error) {
    return { version: null, note: `建不了临时目录，没有查版本（${error?.code || "出错"}）` };
  }
  // 和连接时一样：运行前的一刻再核对一次，它指向的还是刚算过校验值的那个文件。
  try {
    await verifyRuntimeUnchanged(runtime);
  } catch (error) {
    await removeWorkDirectory(cwd);
    return { version: null, note: error.message, changed: true };
  }
  const result = await new Promise((accept) => {
    let launch;
    try {
      launch = buildLaunch(runtime, ["--version"], { platform, env });
    } catch (error) {
      accept({ version: null, note: error.message });
      return;
    }
    let child;
    try {
      child = spawn(launch.command, launch.args, {
        cwd,
        env: minimalEnv(env, platform),
        stdio: ["ignore", "pipe", "pipe"],
        windowsHide: true,
        windowsVerbatimArguments: launch.verbatim,
        shell: false,
      });
    } catch (error) {
      accept({ version: null, note: `agy --version 没能启动（${error.code || error.message}）` });
      return;
    }
    const parts = [];
    let size = 0;
    let settled = false;
    const finish = (result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      accept(result);
    };
    const collect = (chunk) => {
      if (size < 4000) parts.push(chunk);
      size += chunk.length;
    };
    const timer = setTimeout(() => {
      try {
        child.kill("SIGKILL");
      } catch {}
      finish({ version: null, note: `agy --version ${Math.round(timeoutMs / 1000)} 秒没有回应` });
    }, timeoutMs);
    child.stdout.on("data", collect);
    child.stderr.on("data", collect);
    child.on("error", (error) => finish({ version: null, note: `agy --version 没能启动（${error.code || error.message}）` }));
    child.on("close", (code) => {
      const line = scrub(Buffer.concat(parts).toString("utf8")).split(/\r?\n/).map((text) => text.trim()).find(Boolean) || "";
      finish(code === 0 && line
        ? { version: line.slice(0, 200), note: null }
        : { version: null, note: `agy --version 退出码 ${code}${line ? `：${line.slice(0, 120)}` : ""}` });
    });
  });
  await removeWorkDirectory(cwd);
  return result;
}

// 测试用：在 Linux 上检查 Windows 那条收尾的先后（先 taskkill 再结束根进程、已经退出的不再 taskkill）。
let taskkillRunner = null;
export function setTaskkillRunnerForTests(runner) {
  taskkillRunner = runner;
}

// ---- 进程：只记工坊自己启动的
const LIVE = new Map();
const WORK_DIRS = new Set();
let exitHookInstalled = false;

export function taskkillPath(env = process.env) {
  return win32.join(envValue(env, "SystemRoot") || envValue(env, "windir") || "C:\\Windows", "System32", "taskkill.exe");
}

// Windows：用系统目录里的 taskkill.exe（不按名字在当前目录里找），等它结束树以后再补 TerminateProcess。没有在真实的 Windows 上跑过。
function runTaskkill(pid) {
  return new Promise((done) => {
    let timer = null;
    try {
      const killer = spawn(taskkillPath(), ["/pid", String(pid), "/T", "/F"], { stdio: "ignore", windowsHide: true });
      timer = setTimeout(done, 5000);
      killer.once("error", () => {
        clearTimeout(timer);
        done();
      });
      killer.once("exit", () => {
        clearTimeout(timer);
        done();
      });
    } catch {
      if (timer) clearTimeout(timer);
      done();
    }
  });
}

function delay(ms) {
  return new Promise((accept) => setTimeout(accept, ms));
}

function signalGroup(entry, signal) {
  if (entry.platform === "win32") {
    try {
      entry.child.kill(signal);
    } catch {}
    return;
  }
  try {
    process.kill(-entry.pid, signal);
  } catch {
    try {
      entry.child.kill(signal);
    } catch {}
  }
}

async function stopEntry(entry, graceMs = STOP_GRACE_MS) {
  if (!entry.stopping) {
    entry.stopping = (async () => {
      try {
        entry.child.stdin?.end();
      } catch {}
      if (entry.platform === "win32") {
        // 连同 agy.cmd 拉起的子进程一起结束（taskkill /T）：先等 taskkill 走完整棵树，再结束根进程；
        // 根进程已经退出的不再 taskkill（那个进程号可能已经给了别的程序）。没有在真实的 Windows 上跑过。
        if (!entry.exit) await (taskkillRunner || runTaskkill)(entry.pid);
        if (!entry.exit) {
          try {
            entry.child.kill();
          } catch {}
        }
        await Promise.race([entry.exited, delay(graceMs)]);
      } else {
        signalGroup(entry, "SIGTERM");
        await Promise.race([entry.exited, delay(graceMs)]);
        // 进程组里可能还有它拉起的子进程：领头的退了也补一次 SIGKILL（组里没人了就什么也不发生）。
        signalGroup(entry, "SIGKILL");
        await Promise.race([entry.exited, delay(graceMs)]);
      }
      LIVE.delete(entry.pid);
    })();
  }
  return entry.stopping;
}

// 进程退出前的最后一道：结束工坊启动的官方程序（POSIX 上连同它的进程组，领头的已经退了也一样），删掉工作目录。
export function stopAllRuntimesSync() {
  for (const entry of LIVE.values()) {
    if (entry.platform === "win32") {
      if (entry.exit) continue;
      try {
        spawnSync(taskkillPath(), ["/pid", String(entry.pid), "/T", "/F"], { stdio: "ignore", windowsHide: true, timeout: 5000 });
      } catch {}
      try {
        entry.child.kill();
      } catch {}
    } else {
      signalGroup(entry, "SIGKILL");
    }
  }
  LIVE.clear();
  for (const dir of WORK_DIRS) {
    try {
      rmSync(dir, { recursive: true, force: true });
    } catch {}
  }
  WORK_DIRS.clear();
}

export async function stopAllRuntimes() {
  await Promise.all([...LIVE.values()].map((entry) => stopEntry(entry)));
}

export function liveRuntimePids() {
  return [...LIVE.keys()];
}

function installExitHook() {
  if (exitHookInstalled) return;
  exitHookInstalled = true;
  process.once("exit", stopAllRuntimesSync);
}

// 启动前再核对一次：检查时记下的文件（解析后的路径、设备号、inode、大小、修改时间）和现在的不一样，就不启动。
export async function verifyRuntimeUnchanged(runtime) {
  if (!runtime.identity) return;
  const resolved = await realpath(runtime.path).catch(() => null);
  const info = resolved ? await stat(resolved).catch(() => null) : null;
  if (!info || resolved !== runtime.identity.realPath || !sameIdentity(runtime.identity, identityOf(resolved, info))) {
    throw new RuntimeLaunchError("runtime_changed", "官方程序在检查以后变了（链接指向了别的文件，或者文件被替换、升级了），没有启动它：重新点“检查运行时”");
  }
}

export async function startRuntime(runtime, { cwd, env = process.env, platform = process.platform, argv = runtime.args } = {}) {
  await verifyRuntimeUnchanged(runtime);
  const launch = buildLaunch(runtime, argv, { platform, env });
  installExitHook();
  const child = spawn(launch.command, launch.args, {
    cwd,
    env: minimalEnv(env, platform),
    stdio: ["pipe", "pipe", "pipe"],
    windowsHide: true,
    windowsVerbatimArguments: launch.verbatim,
    // POSIX 上让它自成一个进程组，断开时连它拉起的子进程一起结束；Windows 上不分离（否则会弹出控制台窗口）。
    detached: platform !== "win32",
    shell: false,
  });
  await new Promise((accept, reject) => {
    child.once("spawn", accept);
    child.once("error", reject);
  }).catch((error) => {
    throw new RuntimeLaunchError("spawn_failed", `官方程序没能启动（${error?.code || error?.message || "出错"}）`);
  });
  child.on("error", () => {});
  let markExited;
  const exited = new Promise((accept) => {
    markExited = accept;
  });
  const entry = { child, pid: child.pid, platform, exited, stopping: null, exit: null };
  child.once("exit", (code, signal) => {
    entry.exit = { code, signal };
    // POSIX 上进程组里可能还有它的子进程，留到 stop 走完再从名单里去掉；Windows 上进程号退出后可能被重用，马上去掉。
    if (platform === "win32") LIVE.delete(child.pid);
    markExited({ code, signal });
  });
  LIVE.set(child.pid, entry);
  return {
    child,
    pid: child.pid,
    launch,
    exited,
    get exit() {
      return entry.exit;
    },
    stop: (graceMs) => stopEntry(entry, graceMs),
  };
}

// 每次连接一个新的空目录（系统临时目录下），官方程序的工作目录和会话目录都在这里面；断开时删掉。
// 这只是“工作目录”的声明，不是操作系统级的隔离：官方程序自己的工具能不能读写别处，工坊管不了。
// 目录名里带着建它的进程号（novel-workshop-acp-<进程号>-xxxxxx），写作台被强行结束以后，下次连接能认出哪些是没人管的。
export async function makeWorkDirectory(base = tmpdir()) {
  const dir = await mkdtemp(join(base, `${WORK_PREFIX}${process.pid}-`));
  WORK_DIRS.add(dir);
  installExitHook();
  return dir;
}

function processAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return error?.code === "EPERM";
  }
}

// 被强行结束（断电、kill -9）的写作台留下的工作目录：名字里记着的那个进程已经不在了，就删掉。
// 只删这种名字、属于自己（POSIX 上看所有者）、进程确实不在了的目录；进程号又被别的程序用上了就不删。别的一概不碰。
export async function sweepStaleWorkDirectories(base = tmpdir()) {
  let names;
  try {
    names = await readdir(base);
  } catch {
    return 0;
  }
  const me = typeof process.getuid === "function" ? process.getuid() : null;
  const pattern = new RegExp(`^${WORK_PREFIX}(\\d+)-[A-Za-z0-9]{6}$`);
  let removed = 0;
  for (const name of names) {
    const match = pattern.exec(name);
    if (!match) continue;
    const pid = Number(match[1]);
    if (pid === process.pid || processAlive(pid)) continue;
    const path = join(base, name);
    const info = await lstat(path).catch(() => null);
    if (!info || !info.isDirectory() || info.isSymbolicLink()) continue;
    if (me !== null && info.uid !== me) continue;
    await rm(path, { recursive: true, force: true }).catch(() => {});
    removed += 1;
  }
  return removed;
}

export async function removeWorkDirectory(path, base = tmpdir()) {
  if (!path || !basename(path).startsWith(WORK_PREFIX)) return false;
  const parent = await realpath(dirname(path)).catch(() => null);
  const root = await realpath(base).catch(() => resolve(base));
  if (!parent || parent !== root) return false;
  await rm(path, { recursive: true, force: true }).catch(() => {});
  WORK_DIRS.delete(path);
  return true;
}

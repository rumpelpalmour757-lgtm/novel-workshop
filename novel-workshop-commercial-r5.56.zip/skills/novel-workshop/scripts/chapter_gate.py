#!/usr/bin/env python3
"""Reduce chapter confirmations in the existing project ledger; never write prose."""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

if __name__ == "__main__":
    sys.dont_write_bytecode = True  # the sibling modules load by path; keep the skill folder free of __pycache__


STAGES = ("scope", "outline", "preparation", "draft", "review", "revision", "final")
# With per-stage confirmation on and no policy recorded, both are on: images are
# looked at before writing, and the author hands the draft to the teacher.
DEFAULT_POLICY = {"visual_required": True, "teacher_handoff": "user_return"}
# Chapter records made before policies existed carry nothing to check against.
EARLIER_POLICY = {"visual_required": False, "teacher_handoff": "host"}
LIVE = {"pending", "confirmed"}


class GateError(ValueError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def _need(condition, message, code="invalid_event"):
    if not condition:
        raise GateError(code, message)


def _text(value, name):
    _need(isinstance(value, str) and bool(value.strip()), name + " must be non-empty text")
    return value


def _artifact(value, required=False):
    _need((value is None and not required) or
          (isinstance(value, str) and re.fullmatch(r"[0-9a-fA-F]{64}", value) is not None),
          "artifact_sha256 must be a complete SHA256; final requires it")
    return value.lower() if isinstance(value, str) else None


def validate_policy(policy, code="invalid_store"):
    """Check recorded policy structure, without authenticating its provenance."""
    _need(isinstance(policy, dict) and type(policy.get("visual_required")) is bool
          and policy.get("teacher_handoff") in ("user_return", "host"),
          "chapter_workflow_policy requires visual_required:boolean and teacher_handoff:user_return|host", code)
    return policy


def _project_policy(payload):
    policy = payload["data"].get("chapter_workflow_policy")
    return None if policy is None else validate_policy(policy)


def _policy(chapter):
    """What this chapter follows now: the author's latest word on this chapter,
    else what it froze when it started."""
    changes = chapter.get("policy_changes")
    if changes:
        return changes[-1]
    if "workflow_policy" in chapter:
        return validate_policy(chapter["workflow_policy"])
    return EARLIER_POLICY if chapter["history"] else DEFAULT_POLICY


def _policy_view(chapter, project_policy=None, quote=False):
    """The policy in force and what it rests on; status also quotes the author."""
    changes = chapter.get("policy_changes")
    frozen = bool(changes or chapter["history"] or "workflow_policy" in chapter)
    if changes:
        source, basis = changes[-1], "chapter"
    elif "workflow_policy" in chapter:
        source = chapter["workflow_policy"]
        plain = {key: source[key] for key in DEFAULT_POLICY}
        basis = "project" if "author_quote" in source else "default" if plain == DEFAULT_POLICY else "earlier_version"
    elif chapter["history"]:
        source, basis = EARLIER_POLICY, "earlier_version"
    else:  # not started: what a first presentation would freeze
        source, basis = (DEFAULT_POLICY, "default") if project_policy is None else (project_policy, "project")
    view = {key: source[key] for key in DEFAULT_POLICY}
    view.update(basis=basis, frozen=frozen)
    view.update({key: source[key] for key in ("event_id",) + (("author_quote", "source_ref") if quote else ())
                 if key in source})
    return view


def _freeze(chapter, project_policy):
    """A chapter keeps the policy in force at its first event; a later project
    configure does not move it, only the author's word on this chapter does."""
    if "workflow_policy" not in chapter and not chapter["history"]:
        chapter["workflow_policy"] = copy.deepcopy(project_policy or DEFAULT_POLICY)


def _visual_evidence(value):
    _need(isinstance(value, dict), "visual_evidence must be an object")
    mode = value.get("mode")
    _need(mode in ("pipeline_run", "author_images", "reuse"), "Invalid visual evidence mode")
    sources = value.get("source_refs")
    _need(isinstance(sources, list) and bool(sources)
          and all(isinstance(ref, str) and ref.strip() for ref in sources),
          "visual_evidence.source_refs must be a non-empty list of text references")
    fields = ["observation_ref", "selection_ref"]
    if mode == "pipeline_run":
        fields += ["run_ref", "verification_ref"]
    if mode == "reuse":
        fields += ["reuse_author_quote", "reuse_source_ref"]
    for field in fields:
        _text(value.get(field), "visual_evidence." + field)
    return copy.deepcopy(value)


def _version(chapter, presentation):
    bound = {key: presentation[key] for key in
             ("stage", "content", "source_ref", "artifact_sha256", "dependencies")}
    bound.update(project_id=chapter["project_id"], chapter_id=chapter["chapter_id"])
    # Omit new fields on legacy records so their existing versions still verify.
    for key in ("visual_evidence", "teacher_return_id", "returned_sha256", "policy_change_id"):
        if key in presentation:
            bound[key] = presentation[key]
    if "workflow_policy" in chapter:
        bound["workflow_policy"] = chapter["workflow_policy"]
    raw = json.dumps(bound, ensure_ascii=False, sort_keys=True,
                     separators=(",", ":"), allow_nan=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _filled(record, keys):
    return all(isinstance(record.get(key), str) and record[key].strip() for key in keys)


def _chapter(payload, chapter_id):
    _text(chapter_id, "chapter_id")
    _need(isinstance(payload, dict) and isinstance(payload.get("data"), dict),
          "Store must contain a data object", "invalid_store")
    _text(payload.get("project_id"), "project_id")
    chapters = payload["data"].get("chapter_confirmations", {})
    _need(isinstance(chapters, dict), "chapter_confirmations must be an object", "invalid_store")
    chapter = chapters.get(chapter_id)
    if chapter is None:
        _need(chapter_id not in chapters, "Chapter record must be an object", "invalid_store")
        return {"chapter_id": chapter_id, "project_id": payload["project_id"], "history": []}
    _need(isinstance(chapter, dict) and chapter.get("chapter_id") == chapter_id
          and chapter.get("project_id") == payload["project_id"]
          and isinstance(chapter.get("history"), list), "Invalid chapter record", "invalid_store")
    _need(all(isinstance(item, dict) and item.get("action") in {"present", "reopen"}
              and item.get("stage") in STAGES for item in chapter["history"]),
          "Invalid chapter history", "invalid_store")
    changes = chapter.get("policy_changes", [])
    _need(isinstance(changes, list) and all(
        isinstance(item, dict) and _filled(item, ("event_id", "author_quote", "source_ref"))
        and item.get("actor_role") == "author" and item.get("mode") == "human" for item in changes),
          "A chapter policy change must keep the author's words, source and identity", "invalid_store")
    for item in changes:
        validate_policy(item)
    _policy(chapter)
    returns = chapter.get("teacher_returns", [])
    _need(isinstance(returns, list), "teacher_returns must be an array", "invalid_store")
    for returned in returns:
        _need(isinstance(returned, dict) and returned.get("chapter_id") == chapter_id
              and returned.get("project_id") == payload["project_id"]
              and _filled(returned, ("event_id", "draft_presentation_id", "draft_presentation_version",
                                     "draft_sha256", "returned_text", "source_ref", "teacher_name"))
              and returned.get("returned_sha256") == hashlib.sha256(returned["returned_text"].encode("utf-8")).hexdigest(),
              "Invalid teacher return record", "invalid_store")
    return chapter


def _teacher_returns(chapter):
    draft = next((item for item in chapter["history"] if item["action"] == "present"
                  and item["stage"] == "draft" and item.get("status") == "confirmed"), None)
    if draft is None:
        return []
    return [item for item in chapter.get("teacher_returns", [])
            if item["draft_presentation_id"] == draft["presentation_id"]
            and item["draft_presentation_version"] == draft["version"]
            and item["draft_sha256"] == draft["artifact_sha256"]]


def _same_text_elsewhere(chapter, returned):
    """Earlier returns with the same text that belong to a different draft text.
    Marked, not blocked: a teacher may well send the same words twice."""
    return [item["event_id"] for item in chapter.get("teacher_returns", [])
            if item["returned_sha256"] == returned["returned_sha256"]
            and item["draft_sha256"] != returned["draft_sha256"]]


def _confirmation_gaps(stage, item):
    """Author evidence missing from a stage marked confirmed. Presence only:
    whether the words and source are genuine cannot be checked here."""
    confirmation = item.get("confirmation")
    if not isinstance(confirmation, dict):
        return ["confirmation"]
    gaps = [key for key in ("event_id", "author_quote", "source_ref") if not _filled(confirmation, (key,))]
    if stage == "final" and confirmation.get("decision") != "accept_final_version":
        gaps.append("decision")
    return gaps


def _identity_gaps(item):
    """actor_role:author and mode:human, when a confirmed stage does not record
    them. Records written by earlier versions may lack them, so this is noted
    and does not change how far the chapter has come."""
    confirmation = item.get("confirmation") if isinstance(item.get("confirmation"), dict) else {}
    return [key for key, value in (("actor_role", "author"), ("mode", "human")) if confirmation.get(key) != value]


def _same_words(history, item):
    """Earlier confirmations in this chapter with the same author words and the
    same source_ref as this one. Marked, not refused: an author may really
    answer each stage with the same word while the host writes a coarse source."""
    confirmation = item.get("confirmation") if isinstance(item.get("confirmation"), dict) else {}
    words = (str(confirmation.get("author_quote", "")).strip(), str(confirmation.get("source_ref", "")).strip())
    found = []
    for other in history:
        if other is item:
            break
        if isinstance(other.get("confirmation"), dict) and (
                str(other["confirmation"].get("author_quote", "")).strip(),
                str(other["confirmation"].get("source_ref", "")).strip()) == words:
            found.append({"stage": other["stage"], "presentation_id": other["presentation_id"]})
    return found


def _walk(chapter):
    """Return (current stage, its live item, dependencies, last valid confirmed
    item, problem, unnamed). A stage marked confirmed without the author's words,
    source or (final) decision is read as not confirmed and described in problem
    instead of being trusted. unnamed lists the stages read as confirmed whose
    record does not say who confirmed them."""
    live = {}
    for item in chapter["history"]:
        if item["action"] == "present" and item.get("status") in LIVE:
            _need(item["stage"] not in live, "Duplicate live stage", "invalid_store")
            live[item["stage"]] = item
    changes = {change["event_id"] for change in chapter.get("policy_changes", [])}
    dependencies, last, unnamed = [], None, []
    for index, stage in enumerate(STAGES):
        item = live.get(stage)
        if item is not None:
            _need(item.get("dependencies") == dependencies and item.get("version") == _version(chapter, item),
                  "Presentation content or dependencies changed", "invalid_store")
            _need("policy_change_id" not in item or item["policy_change_id"] in changes,
                  "Presentation names a chapter policy change that is not in the record", "invalid_store")
            if stage == "review" and _policy(chapter)["teacher_handoff"] == "user_return":
                _need(any(returned["event_id"] == item.get("teacher_return_id")
                          and returned["returned_sha256"] == item.get("returned_sha256")
                          for returned in _teacher_returns(chapter)),
                      "Review lacks a teacher return bound to the confirmed draft", "invalid_store")
        gaps = [] if item is None or item["status"] == "pending" else _confirmation_gaps(stage, item)
        if item is None or item["status"] == "pending" or gaps:
            later = [key for key in STAGES[index + 1:] if key in live]
            _need(bool(gaps) or not later, "Future stage exists before prior confirmation", "invalid_store")
            problem = {"stage": stage, "missing": gaps, "later_stages": later,
                       "identity": _identity_gaps(item)} if gaps else None
            return stage, item, dependencies, last, problem, unnamed
        if _identity_gaps(item):
            unnamed.append({"stage": stage, "missing": _identity_gaps(item)})
        dependencies.append({"stage": stage, "presentation_id": item["presentation_id"],
                             "version": item["version"], "confirmation_event_id": item["confirmation"]["event_id"]})
        last = item
    return None, None, dependencies, last, None, unnamed


def _progress(chapter):
    return _walk(chapter)[:4]


def _problem_text(problem):
    stage = problem["stage"]
    text = ("Stage " + stage + " is marked confirmed, but its record lacks " + ", ".join(problem["missing"])
            + (" (nor does it record " + ", ".join(problem["identity"]) + ")" if problem.get("identity") else "")
            + "; it is read as not confirmed. ")
    if problem["later_stages"]:
        return (text + "Later stages (" + ", ".join(problem["later_stages"]) + ") were presented on top of it: "
                "reopen " + stage + " with the author's words and go on from there. Do not complete the record by hand.")
    return (text + "Ask the author and record a real confirm for this presentation (or present the stage again). "
            "Do not complete the record by hand.")


def _unnamed_text(unnamed):
    stages = [item["stage"] for item in unnamed]
    missing = list(dict.fromkeys(key for item in unnamed for key in item["missing"]))
    return ("Stage" + ("s " if len(stages) > 1 else " ") + ", ".join(stages) + (" are" if len(stages) > 1 else " is")
            + " confirmed with the author's words and source, but the record does not say who confirmed "
            + ("them" if len(stages) > 1 else "it") + " (" + ", ".join(missing) + " is not author/human). Records "
            "written by earlier versions may lack these fields, so progress is read as before. Do not fill them in "
            "by hand; if the author did not say these words, reopen from the first such stage with the author's words.")


def _summary(chapter, project_policy=None, quote_policy=False):
    stage, current, _, last, problem, unnamed = _walk(chapter)
    state = "final_confirmation_recorded" if stage is None else "awaiting_confirmation" if current else "awaiting_presentation"
    if not chapter["history"]:
        state = "not_started"
    returns = _teacher_returns(chapter)
    waiting_teacher = (stage == "review" and current is None
                       and _policy(chapter)["teacher_handoff"] == "user_return" and not returns)
    if waiting_teacher:
        state = "await_teacher_return"
    confirmed = None if last is None else {
        "stage": last["stage"], "presentation_id": last["presentation_id"],
        "presentation_version": last["version"], "artifact_sha256": last["artifact_sha256"],
        "confirmation": copy.deepcopy(last["confirmation"])}
    result = {"status": state, "chapter_status": state, "chapter_id": chapter["chapter_id"],
              "project_id": chapter["project_id"], "current_stage": stage,
              "presentation_id": current["presentation_id"] if current else None,
              "presentation_version": current["version"] if current else None,
              "artifact_sha256": current["artifact_sha256"] if current else None,
              "last_valid_confirmation": confirmed,
              "next_action": "record_existing_author_gate" if stage is None else "teacher_return" if waiting_teacher
                             else "confirm" if current else "present",
              "workflow_policy": _policy_view(chapter, project_policy, quote_policy)}
    problems = ([_problem_text(problem)] if problem else []) + ([_unnamed_text(unnamed)] if unnamed else [])
    if problems:
        result["record_problems"] = problems
    if problem and problem["later_stages"]:
        result["next_action"] = "reopen"
    repeated = [{"stage": item["stage"], "presentation_id": item["presentation_id"],
                 "same_as": _same_words(chapter["history"], item)}
                for item in chapter["history"] if item["action"] == "present" and item.get("status") == "confirmed"]
    repeated = [item for item in repeated if item["same_as"]]
    if repeated:
        result["repeated_confirmations"] = repeated
    if returns:
        result["valid_teacher_returns"] = [
            {"teacher_return_id": item["event_id"], **{key: item[key] for key in
             ("returned_sha256", "draft_presentation_id", "draft_presentation_version", "draft_sha256")}}
            for item in returns]
        for item, shown in zip(returns, result["valid_teacher_returns"]):
            same = _same_text_elsewhere(chapter, item)
            if same:
                shown["same_text_as_return_for_other_draft"] = same
    if current and "teacher_return_id" in current:
        result.update(teacher_return_id=current["teacher_return_id"], returned_sha256=current["returned_sha256"])
    return result


def status(payload, chapter_id):
    """Return resumable progress without modifying the supplied project payload."""
    chapter = _chapter(payload, chapter_id)
    return _summary(chapter, _project_policy(payload), quote_policy=True)


def confirmed_presentation(payload, chapter_id, stage):
    """The presentation of this stage that carries a complete author
    confirmation, or None. For scripts that must not go by the status field
    alone (a stage marked confirmed without the author's words does not count)."""
    chapter = _chapter(payload, chapter_id)
    valid = {item["stage"]: item["presentation_id"] for item in _walk(chapter)[2]}
    return next((copy.deepcopy(item) for item in chapter["history"] if item["action"] == "present"
                 and item.get("status") == "confirmed" and item.get("presentation_id") == valid.get(stage)), None)


def _evidence(event, require_actor=True):
    if require_actor or "actor_role" in event or "mode" in event:
        _need(event.get("actor_role") == "author" and event.get("mode") == "human",
              "Only an actual human author confirmation may advance a chapter")
    return {"event_id": event["event_id"],
            "author_quote": _text(event.get("author_quote"), "author_quote"),
            "source_ref": _text(event.get("source_ref"), "source_ref")}


# Final acceptance: a deliberately small whitelist, not natural-language intent
# authentication. Every clause of the author's words must be one of the forms
# below and at least one must be the acceptance itself; anything else stays
# pending and the host asks the author. Postponed, conditional, questioning or
# negated wording and wording about another version never fit these forms.
_THIS = r"(?:这一?个?|此|本|当前的?|现在的?|目前的?)(?:修订稿|候选稿|修订版|版本|稿子|章|版|稿)"
_FIRM = r"(?:明确|确认|同意|决定|正式|现在|就)"
_END = r"(?:了|吧|啦)?"
_ACCEPTS = re.compile(
    r"我?" + _FIRM + r"{0,2}(?:采纳|采用)(?:" + _THIS + r")?" + _END
    + r"|" + _THIS + r"我?" + _FIRM + r"{0,2}(?:采纳|采用)" + _END
    + r"|我?" + _FIRM + r"{0,2}(?:" + _THIS + r")?" + _FIRM + r"?(?:定稿|封稿)" + _END
    + r"|(?:" + _THIS + r")?可以(?:定稿|封稿|采纳|采用)了?"
    + r"|我?" + _FIRM + r"{0,2}(?:就用|用|保留)" + _THIS + _END)
_ADDS_NOTHING = re.compile(
    r"好的?|好吧|好了|行|可以了?|嗯|对|是的?|同意|确认|没问题|没意见|不错|很好|ok|okay"  # plain assent
    r"|(?:不用|不必|不需要|无需|不要|别|不)再?(?:改动|修改|调整|改|动)了?"  # nothing more to change
    r"|" + _THIS  # naming the current version
    + r"|(?:然后|接着|可以)?(?:开始|继续|进入|写|开)?下一章(?:了|吧)?"  # going on to the next chapter
    r"|谢谢(?:你|您|了)?|多谢|辛苦(?:了|啦)?", re.IGNORECASE)  # courtesy


def _final_decision(event):
    quote = event["author_quote"]
    clauses = [part for part in re.split(r"[\W_]+", quote, flags=re.UNICODE) if part]
    accepted = (event.get("decision") == "accept_final_version"
                and "?" not in quote and "？" not in quote  # read before punctuation is dropped
                and any(_ACCEPTS.fullmatch(part) for part in clauses)
                and all(_ACCEPTS.fullmatch(part) or _ADDS_NOTHING.fullmatch(part) for part in clauses))
    _need(accepted,
          "Final stays pending. It needs decision:accept_final_version and author words that are, as a whole, "
          "a plain acceptance of the current version. Postponed, conditional, questioning or negated wording, "
          "wording about another version or part of this one, and anything this small check does not recognize "
          "are not recorded as acceptance. Do not reword the author; ask. Either reply is enough: "
          "“定稿。” or “采纳当前稿。”")


_OTHERWISE = ("If the author said otherwise for this chapter, first record the author's words with "
              "action:chapter_policy (chapter_id, actor_role:author, mode:human, author_quote, source_ref) and ")


def apply(payload, event, project_id):
    """Deterministically apply one event; failed events leave payload untouched.

    The caller owns CAS, event retry deduplication, locking and persistence.
    Author identity, quoted evidence and literary quality cannot be authenticated.
    """
    _need(isinstance(event, dict) and event.get("op") == "chapter_gate", "Expected chapter_gate event")
    _text(event.get("event_id"), "event_id")
    _need(isinstance(payload, dict) and isinstance(payload.get("data"), dict),
          "Store must contain a data object", "invalid_store")
    _text(payload.get("project_id"), "project_id")
    _need(payload["project_id"] == project_id, "Requested project differs from store", "project_mismatch")
    action, stage = event.get("action"), event.get("stage")
    if action == "configure":
        _need(event.get("chapter_id") is None,
              "configure sets the policy for every chapter that starts later and takes no chapter_id. "
              "For the author's word on one chapter use action:chapter_policy")
        evidence = _evidence(event)
        policy = {key: event.get(key) for key in DEFAULT_POLICY}
        validate_policy(policy, "invalid_event")
        policy.update(**evidence, actor_role="author", mode="human")
        payload["data"]["chapter_workflow_policy"] = policy
        return {"project_id": project_id, "chapter_workflow_policy": copy.deepcopy(policy),
                "next_action": "present"}
    project_policy = _project_policy(payload)
    chapter = copy.deepcopy(_chapter(payload, event.get("chapter_id")))
    _need(action in ("present", "confirm", "reopen", "teacher_return", "chapter_policy")
          and (action in ("teacher_return", "chapter_policy") or stage in STAGES),
          "Invalid chapter action or stage")
    current_stage, current, dependencies, _, problem, _ = _walk(chapter)
    history = chapter["history"]
    used = [item.get("event_id", item.get("presentation_id")) for item in
            history + chapter.get("teacher_returns", []) + chapter.get("policy_changes", [])]
    used += [item["confirmation"].get("event_id") for item in history if isinstance(item.get("confirmation"), dict)]
    _need(event["event_id"] not in used,
          "Chapter event_id already exists; retries belong to the ledger", "duplicate_event")
    extra = {}
    if action == "teacher_return":
        _need(_policy(chapter)["teacher_handoff"] == "user_return",
              "This chapter follows teacher_handoff:host: the workshop reviews the draft itself and no teacher "
              "return is expected, so none is recorded. " + _OTHERWISE + "teacher_handoff:user_return, then "
              "send this teacher_return again", "invalid_transition")
        _need(current_stage == "review" and current is None,
              "Teacher results may only be recorded while waiting for review presentation: after the draft is "
              "confirmed and before review is presented. This chapter is at stage " + str(current_stage)
              + (" with a presentation awaiting confirmation" if current else ""), "invalid_transition")
        draft = next(item for item in history if item["action"] == "present"
                     and item["stage"] == "draft" and item.get("status") == "confirmed")
        draft_sha256 = event.get("draft_sha256")
        _need(event.get("draft_presentation_id") == draft["presentation_id"]
              and event.get("draft_presentation_version") == draft["version"]
              and isinstance(draft_sha256, str) and draft_sha256.lower() == draft["artifact_sha256"],
              "Teacher return must bind this chapter's current confirmed draft instance, version and hash",
              "invalid_transition")
        returned = {key: _text(event.get(key), key) for key in
                    ("returned_text", "source_ref", "teacher_name")}
        returned.update(event_id=event["event_id"], chapter_id=chapter["chapter_id"], project_id=project_id,
                        draft_presentation_id=draft["presentation_id"], draft_presentation_version=draft["version"],
                        draft_sha256=draft["artifact_sha256"],
                        returned_sha256=hashlib.sha256(returned["returned_text"].encode("utf-8")).hexdigest())
        extra.update(teacher_return_id=returned["event_id"], returned_sha256=returned["returned_sha256"])
        same = _same_text_elsewhere(chapter, returned)
        if same:
            extra["same_text_as_return_for_other_draft"] = same
        chapter.setdefault("teacher_returns", []).append(returned)
    elif action == "chapter_policy":
        # The author's word on this one chapter, at any point after or before it
        # starts. It never moves the project policy or another chapter.
        evidence = _evidence(event)
        stated = [key for key in DEFAULT_POLICY if key in event]
        _need(bool(stated), "chapter_policy must state visual_required and/or teacher_handoff for this chapter")
        _freeze(chapter, project_policy)
        policy = {key: event[key] if key in event else _policy(chapter)[key] for key in DEFAULT_POLICY}
        validate_policy(policy, "invalid_event")
        withdrawn = []
        for name, field, required in (("preparation", "visual_evidence", policy["visual_required"]),
                                      ("review", "teacher_return_id", policy["teacher_handoff"] == "user_return")):
            item = next((item for item in history if item["action"] == "present" and item["stage"] == name
                         and item.get("status") in LIVE), None)
            if required and item is not None and field not in item:
                # A presentation still waiting for the author is simply withdrawn;
                # a stage the author confirmed is never undone without a reopen.
                _need(item["status"] == "pending",
                      "Stage " + name + " of this chapter was already confirmed without " + field
                      + ". A policy change does not undo a confirmed stage: reopen " + name
                      + " with the author's words first, then send this chapter_policy again", "invalid_transition")
                item.update(status="invalidated", invalidated_by=event["event_id"])
                withdrawn.append(item["presentation_id"])
        chapter.setdefault("policy_changes", []).append(
            {**policy, **evidence, "actor_role": "author", "mode": "human", "stated": stated})
        if withdrawn:
            extra["withdrawn_presentation_ids"] = withdrawn
    elif action == "reopen":
        evidence = _evidence(event, require_actor=False)
        reason = _text(event.get("reason"), "reason")
        _need(bool(history) and (current_stage is None or STAGES.index(stage) <= STAGES.index(current_stage)),
              "Cannot reopen a future or unstarted chapter stage", "invalid_transition")
        invalidated = []
        for item in history:
            # Superseded and earlier invalidated records keep what they say.
            if (item["action"] == "present" and item.get("status") in LIVE
                    and STAGES.index(item["stage"]) >= STAGES.index(stage)):
                item.update(status="invalidated", invalidated_by=event["event_id"])
                invalidated.append(item["presentation_id"])
        history.append({"action": "reopen", "stage": stage, **evidence, "reason": reason,
                        "invalidated_presentation_ids": invalidated})
    else:
        _need(stage == current_stage, "Only the current stage may be presented or confirmed", "invalid_transition")
        if problem and problem["later_stages"]:
            raise GateError("invalid_store", _problem_text(problem))
        if action == "present":
            _freeze(chapter, project_policy)
            artifact = _artifact(event.get("artifact_sha256"), stage in {"draft", "revision", "final"})
            confirmed = {item["stage"]: item for item in history
                         if item["action"] == "present" and item["status"] == "confirmed"}
            bindings = {}
            if chapter.get("policy_changes"):
                bindings["policy_change_id"] = chapter["policy_changes"][-1]["event_id"]
            if stage == "preparation":
                required = _policy(chapter)["visual_required"]
                _need(not required or event.get("visual_evidence") is not None,
                      "This chapter follows visual_required:true: preparation must carry visual_evidence for "
                      "images actually looked at (mode, source_refs, observation_ref, selection_ref), never "
                      "placeholders. " + _OTHERWISE + "visual_required:false")
                if required or "visual_evidence" in event:
                    bindings["visual_evidence"] = _visual_evidence(event.get("visual_evidence"))
            if stage == "review":
                draft_artifact = confirmed["draft"]["artifact_sha256"]
                _need(artifact is None or artifact == draft_artifact,
                      "Review must bind the confirmed draft artifact", "invalid_transition")
                artifact = draft_artifact
                if _policy(chapter)["teacher_handoff"] == "user_return":
                    teacher_return = next((item for item in _teacher_returns(chapter)
                                           if item["event_id"] == event.get("teacher_return_id")), None)
                    _need(teacher_return is not None,
                          "Review must name a teacher_return_id bound to the current confirmed draft. This "
                          "chapter follows teacher_handoff:user_return: record what the author brought back "
                          "with action:teacher_return first; the workshop does not stand in for the teacher. "
                          + _OTHERWISE + "teacher_handoff:host", "invalid_transition")
                    bindings.update(teacher_return_id=teacher_return["event_id"],
                                    returned_sha256=teacher_return["returned_sha256"])
            if stage == "final":
                _need(artifact == confirmed["revision"]["artifact_sha256"],
                      "Final must bind the confirmed revision artifact; reopen revision to change it",
                      "invalid_transition")
            record = {"action": "present", "stage": stage, "presentation_id": event["event_id"],
                      "content": _text(event.get("content"), "content"),
                      "source_ref": _text(event.get("source_ref"), "source_ref"),
                      "artifact_sha256": artifact,
                      "dependencies": dependencies, "status": "pending", **bindings}
            record["version"] = _version(chapter, record)
            if current:
                current.update(status="superseded", superseded_by=event["event_id"])
            history.append(record)
        else:
            _need(current is not None and event.get("presentation_id") == current["presentation_id"],
                  "Confirmation must name the current presentation instance", "invalid_transition")
            version = event.get("presentation_version", event.get("version"))
            _need(version == current["version"] and
                  ("version" not in event or event["version"] == version),
                  "Confirmation must bind the current presentation version", "invalid_transition")
            evidence = _evidence(event)
            evidence.update(actor_role="author", mode="human")
            if stage == "final":
                _artifact(current["artifact_sha256"], required=True)
                _final_decision(event)
                evidence["decision"] = "accept_final_version"
            current.update(status="confirmed", confirmation=evidence)
            # A presentation is made after the reply that confirmed the one before
            # it, so the same message is unlikely to confirm two of them: marked
            # for the host to check, and source_ref is written down to the message.
            same = _same_words(history, current)
            if same:
                extra["same_words_as_confirmation_of"] = same
    result = _summary(chapter, project_policy)
    result.update(extra)
    payload["data"].setdefault("chapter_confirmations", {})[chapter["chapter_id"]] = chapter
    return result


def _read_store(path):
    """Load the sibling ledger by path: python -I and -P keep the script's
    directory off sys.path, and learning_loop loads this reducer the same way."""
    spec = importlib.util.spec_from_file_location("_chapter_gate_learning_loop",
                                                  Path(__file__).with_name("learning_loop.py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.read_store(path)


HELP = """This command only reads. Events are written with learning_loop.py apply
(op:chapter_gate); its --help lists present, confirm, reopen, teacher_return.

Policy. With no recorded choice a chapter follows visual_required:true and
teacher_handoff:user_return: images are looked at before writing, and the author
hands the complete draft to the teacher and brings the result back; the workshop
does not stand in for the teacher. host means the workshop reviews by itself.
  action:configure records the author's choice for chapters that start later.
  action:chapter_policy records the author's word for one chapter, before or
  after it starts: chapter_id, visual_required and/or teacher_handoff,
  actor_role:author, mode:human, author_quote, source_ref. It moves neither the
  project policy nor other chapters. Dropping a requirement changes nothing
  already confirmed. Adding one withdraws a presentation still awaiting the
  author if it lacks what is now required; a stage already confirmed without it
  must be reopened first.

status prints, besides progress:
  workflow_policy  visual_required, teacher_handoff, frozen, and basis:
                   default (nothing recorded, both on) | project (configure) |
                   chapter (chapter_policy) | earlier_version (the chapter
                   started under an earlier version; both off unless changed).
                   With the author's words and source when there are any.
  record_problems  a stage marked confirmed whose record lacks the author's
                   words or source (or decision, for final) is read as not
                   confirmed and listed here. A confirmed stage whose record
                   does not name actor_role:author, mode:human is listed too,
                   but read as before: records written by earlier versions may
                   lack these fields.
  repeated_confirmations  confirmed stages whose author words and source_ref
                   are the same as an earlier confirmation in this chapter.

confirm. Write source_ref down to the message the author answered. When the same
words with the same source_ref already confirmed an earlier presentation of this
chapter, the confirmation is saved and marked (same_words_as_confirmation_of):
check that the author really answered this presentation. Final needs
decision:accept_final_version and words that are, as a whole, a plain acceptance
of the current version; anything else stays pending and the host asks.

The script checks that these fields are present and consistent. It cannot tell
whether the author's words, the source or the identity are genuine, and it
cannot see edits made to the record outside learning_loop.py apply.
"""


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, epilog=HELP,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    commands = parser.add_subparsers(dest="command", required=True)
    command = commands.add_parser("status", description="Print one chapter's progress, the policy it follows "
                                  "(workflow_policy) and any record_problems. Read-only.", epilog=HELP,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
    command.add_argument("store", type=Path)
    command.add_argument("--chapter-id", required=True)
    args = parser.parse_args(argv)
    try:
        payload, store_version = _read_store(args.store)
        print(json.dumps({**status(payload, args.chapter_id), "store_version": store_version},
                         ensure_ascii=False, indent=2, allow_nan=False))
        return 0
    except (OSError, ValueError, TypeError, KeyError, ImportError, AttributeError) as exc:
        print(json.dumps({"status": "error", "code": getattr(exc, "code", "invalid_store"),
                          "message": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

"""The workshop's builtin page reader (r5.59): the source pages of a run read with the Python standard library only.

It is the fallback for when Crawl4AI cannot be used (not installed, Python older than 3.10, its browser does not
start), or the reader the config names (page_reader.use: builtin). It asks each page with the workshop's own request
through the run's common.Session, so a page gets everything an image gets: the address and every redirect hop
checked, robots.txt asked first, the host's turn waited, a host that refused or limited the rate asked nothing more,
budgets.max_requests counted, the workshop's own user agent and nothing that looks like a browser. It opens no
browser and runs none of the page's scripts: an image that only a script puts on the page is not seen, and the record
says the page had scripts that were not run (scripts_not_run) instead of claiming the whole page was read. It never
follows a link and never reads a page collect did not hand it.

From the HTML (html.parser) it lists the images of img elements: src, srcset (split the way the HTML standard splits
it, so an address with a comma stays whole; the widest candidate, else the highest density), the lazy-loading
data-src, data-original and data-srcset, and the source elements of a picture (a source marked as webp, avif or
another format is kept as another version of the same image; jpeg, png, gif and untyped ones are chosen first, as
they decode everywhere). <base href> is read before addresses are joined; data:, blob:, javascript: and about:
addresses are dropped and counted. The same image twice (a noscript copy of a lazy image) is one record with all its
addresses (variants), so collect can tell it is the image a search already found. For each image it keeps the page,
alt, the figcaption of its figure, a caption or credit in the text right after it (by class name, or by words such as
摄影, 图片来源, Photo by, CC BY), licence links in that text, the page's rel=license links and the credit and licence
fields of the page's structured data (JSON-LD ImageObject) that name the image. All of that is what the page says:
collect keeps it in on_page.page_says with checked: false, and nothing here is a licence the workshop checked. The
image's desc (its page text) is its caption only; a credit line found apart from the caption stays in page_says (a
caption that itself names who took the picture is still the caption).

Images the page hides (an inline style with display:none or visibility:hidden, the hidden attribute,
aria-hidden="true", inside a template) are not listed and only counted (hidden_images); their text is not used either.
Zero-width and other invisible format characters are removed from every text recorded. Both only cut noise: they are
no defence against a page written to mislead, and the page's words stay material, never instructions.
"""
import codecs
import html.parser
import json
import re
import urllib.parse

from . import common

NAME = "builtin"
VERSION = "builtin-reader/1"
ACCEPT = "text/html,application/xhtml+xml"
HTML_TYPES = ("text/html", "application/xhtml+xml")
MAX_IMAGES = 100            # images listed per page; the rest are counted
MAX_STRUCTURED_CHARS = 200000
NOT_ADDRESSES = ("data:", "blob:", "javascript:", "about:")
LAZY_SRC = ("data-src", "data-original")
LAZY_SRCSET = ("data-srcset",)
FIRST_TYPES = ("", "image/jpeg", "image/jpg", "image/pjpeg", "image/png", "image/gif")
VOID = frozenset(("area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source",
                  "track", "wbr"))
# Where one block of text ends and the next begins (inline elements such as a, span or em do not split a block).
BLOCK = frozenset(("p", "div", "figure", "figcaption", "li", "td", "th", "dd", "dt", "caption", "h1", "h2", "h3", "h4",
                   "h5", "h6", "section", "article", "aside", "header", "footer", "blockquote", "table", "tr", "ul",
                   "ol", "dl", "main", "nav", "address", "pre", "body"))
# Their content is text, not markup, in a browser; older Pythons' html.parser reads tags inside some of them, so an img
# found there is not taken (the same answer on every Python).
NOT_MARKUP = frozenset(("title", "textarea", "xmp", "iframe", "noembed", "noframes"))
CREDIT_CLASS = re.compile(r"credit|byline|attribution|author|photographer|copyright|source", re.I)
CAPTION_CLASS = re.compile(r"caption|legend", re.I)
JUNK = re.compile(r"logo|icon|avatar|sprite|spacer|pixel|blank|badge|emoji", re.I)
HIDING_STYLE = re.compile(r"(?:^|;)\s*(?:display\s*:\s*none|visibility\s*:\s*(?:hidden|collapse))\s*(?:!important\s*)?"
                          r"(?:;|$)", re.I)
INVISIBLE = re.compile("[\u00ad\u180e\u200b-\u200f\u202a-\u202e\u2060-\u2064\u2066-\u2069\ufeff]")
CONTROL = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
CHARSET_ALIASES = {"gb2312": "gb18030", "gbk": "gb18030", "x-gbk": "gb18030", "gb_2312-80": "gb18030",
                   "csgb2312": "gb18030", "x-sjis": "shift_jis", "utf8": "utf-8"}


def clean_text(value, limit=200):
    """A text as recorded: no zero-width or other invisible characters, no control characters, one space for every
    run of white space, at most limit characters."""
    value = CONTROL.sub(" ", INVISIBLE.sub("", value or ""))
    return re.sub(r"\s+", " ", value).strip()[:limit]


def decode_page(body, headers):
    """(text, charset): the charset of the Content-Type header, else a byte order mark, else a meta charset in the
    first 4096 bytes, else UTF-8; GB2312 and GBK are read as GB18030 (their superset); undecodable bytes are replaced."""
    body = body or b""
    if body.startswith(b"\xef\xbb\xbf"):
        return body[3:].decode("utf-8", "replace"), "utf-8"
    if body.startswith((b"\xff\xfe", b"\xfe\xff")):
        return body.decode("utf-16", "replace"), "utf-16"
    found = re.search(r"charset\s*=\s*[\"']?\s*([A-Za-z0-9._:-]+)", str(common.header(headers, "Content-Type") or ""),
                      re.I)
    if not found:
        found = re.search(r"<meta[^>]*?charset\s*=\s*[\"']?\s*([A-Za-z0-9._:-]+)",
                          body[:4096].decode("ascii", "replace"), re.I)
    name = found.group(1).lower() if found else "utf-8"
    name = CHARSET_ALIASES.get(name, name)
    try:
        codecs.lookup(name)
    except LookupError:
        return body.decode("utf-8", "replace"), "utf-8 (the page names %s, which this Python does not know)" % name
    return body.decode(name, "replace"), name


def _hides(tag, attrs):
    return (tag == "template" or "hidden" in attrs or (attrs.get("aria-hidden") or "").strip().lower() == "true"
            or bool(HIDING_STYLE.search(attrs.get("style") or "")))


class _Page(html.parser.HTMLParser):
    """One pass over a page: its images, the text blocks between them, its licence links and structured data."""

    def __init__(self, page_url):
        # super(), not html.parser.HTMLParser.__init__: html.parser may have been imported again since this class
        # was made (a test that patches sys.modules does that), and from Python 3.12 on HTMLParser.__init__ itself
        # calls super(), which fails for an instance of the other class.
        super().__init__(convert_charrefs=True)
        self.page_url = page_url
        self.base = None
        self.stack = []              # [(tag, hides, context)]
        self.events = []             # ("img", index) or ("text", text, context, links)
        self.images = []
        self.parts, self.part_context, self.part_links = [], None, []
        self.figures = []            # [{"imgs": [...], "caption": [...], "links": [...], "depth": n}]
        self.pictures = []           # [[(url, width, density, type), ...]]
        self.script = None
        self.structured = []
        self.license_links = []
        self.scripts = self.hidden = self.dropped = self.unlisted = 0
        self.meta_robots = self.meta_refresh = ""

    # -- helpers --

    def address(self, value):
        value = (value or "").strip() if isinstance(value, str) else ""
        if not value or value.lower().startswith(NOT_ADDRESSES):
            return None
        joined = urllib.parse.urljoin(self.base or self.page_url, value)
        return joined if joined.lower().startswith(("http://", "https://")) else None

    def hidden_now(self):
        return any(hides for _, hides, _ in self.stack)

    def inside(self, names):
        return any(tag in names for tag, _, _ in self.stack)

    def context(self):
        for tag, _, context in reversed(self.stack[-4:]):
            if context:
                return context
        return None

    def flush(self):
        text = clean_text("".join(self.parts), 400)
        if text:
            self.events.append(("text", text, self.part_context, list(self.part_links)))
        self.parts, self.part_context, self.part_links = [], None, []

    # -- the parser's callbacks --

    def handle_starttag(self, tag, attrs_list):
        attrs = {}
        for key, value in attrs_list:
            attrs.setdefault(key, value if value is not None else "")
        if tag in BLOCK or tag in ("img", "picture", "br"):
            self.flush()
        if tag == "body":  # a head left open does not hold the page's text
            self.stack = [entry for entry in self.stack if entry[0] != "head"]
        if tag == "base" and self.base is None:
            href = self.address(attrs.get("href"))
            if href:
                self.base = href
        elif tag == "meta":
            name = (attrs.get("name") or attrs.get("http-equiv") or "").strip().lower()
            if name == "robots":
                self.meta_robots = clean_text(attrs.get("content"), 200)
            elif name == "refresh":
                self.meta_refresh = clean_text(attrs.get("content"), 300)
        elif tag in ("a", "link"):
            self.link(tag, attrs)
        elif tag == "script":
            kind = (attrs.get("type") or "").split(";")[0].strip().lower()
            self.script = {"structured": kind == "application/ld+json", "parts": [], "size": 0}
            if not self.script["structured"]:
                self.scripts += 1
        elif tag == "picture":
            self.pictures.append([])
        elif tag == "source" and self.pictures:
            kind = (attrs.get("type") or "").split(";")[0].strip().lower()
            for name in ("srcset", "data-srcset"):
                for url, width, density in common.parse_srcset(attrs.get(name) or ""):
                    self.pictures[-1].append((url, width, density, kind))
        elif tag == "img":
            self.image(attrs)
        if tag in VOID:
            return
        context = None
        if tag == "figure":
            self.figures.append({"imgs": [], "caption": [], "links": []})
        if tag == "figcaption":
            context = "caption"
        else:
            names = " ".join((attrs.get("class") or "", attrs.get("id") or ""))
            if CREDIT_CLASS.search(names):
                context = "credit"
            elif CAPTION_CLASS.search(names):
                context = "caption"
        self.stack.append((tag, _hides(tag, attrs), context))

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        if tag in BLOCK or tag == "picture":
            self.flush()
        if tag == "script" and self.script is not None:
            if self.script["structured"] and self.script["size"] <= MAX_STRUCTURED_CHARS:
                self.structured.append("".join(self.script["parts"]))
            self.script = None
        elif tag == "picture" and self.pictures:
            self.pictures.pop()
        elif tag == "figure" and self.figures:
            figure = self.figures.pop()
            caption = clean_text(" ".join(figure["caption"]), 300)
            for index in figure["imgs"]:
                if caption and not self.images[index].get("figure_caption"):
                    self.images[index]["figure_caption"] = caption
                self.images[index].setdefault("links", []).extend(figure["links"])
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i][0] == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        if self.script is not None:
            if self.script["structured"]:
                self.script["size"] += len(data)
                if self.script["size"] <= MAX_STRUCTURED_CHARS:
                    self.script["parts"].append(data)
            return
        if not data.strip() or self.hidden_now() or self.inside(("style",) + tuple(NOT_MARKUP)):
            return
        if self.figures and self.inside(("figcaption",)):
            self.figures[-1]["caption"].append(data)
        self.part_context = self.part_context or self.context()
        self.parts.append(data)

    # -- what the callbacks collect --

    def link(self, tag, attrs):
        href = self.address(attrs.get("href"))
        if not href:
            return
        licence = "license" in (attrs.get("rel") or "").lower().split()
        creative = bool(common.LICENCE_LINK.fullmatch(href))
        if licence and href not in self.license_links and not self.hidden_now():
            self.license_links.append(href)
        if tag == "a" and (licence or creative) and not self.hidden_now():
            self.part_links.append(href)
            if self.figures and self.inside(("figcaption",)):
                self.figures[-1]["links"].append(href)

    def image(self, attrs):
        if self.inside(NOT_MARKUP):
            return
        if self.hidden_now() or _hides("img", attrs):
            self.hidden += 1
            return
        sets = []
        for name in ("srcset",) + LAZY_SRCSET:
            sets += [(u, w, d, name) for u, w, d in common.parse_srcset(attrs.get(name) or "")]
        sources = [(u, w, d, "picture/source", kind) for u, w, d, kind in (self.pictures[-1] if self.pictures else [])]
        first = [(self.address(u), w, d, how) for u, w, d, how in sets] + [
            (self.address(u), w, d, how) for u, w, d, how, kind in sources if kind in FIRST_TYPES]
        later = [(self.address(u), w, d, how + " (%s)" % kind) for u, w, d, how, kind in sources
                 if kind not in FIRST_TYPES]
        lazy = [(self.address(attrs.get(name)), name) for name in LAZY_SRC]
        plain = self.address(attrs.get("src"))
        chosen = _largest([c for c in first if c[0]])
        how, width = (chosen[3], chosen[1]) if chosen else (None, None)
        src = chosen[0] if chosen else None
        if not src:
            src, how = next(((u, n) for u, n in lazy if u), (None, None))
        if not src and plain:
            src, how = plain, "src"
        if not src:
            chosen = _largest([c for c in later if c[0]])
            if chosen:
                src, how, width = chosen[0], chosen[3], chosen[1]
        if not src:
            self.dropped += 1
            return
        # Every address of this image, for telling it is an image a search found; a src that was not chosen may be
        # a placeholder many images share, so it does not make two images one (strong).
        strong, variants = [], []
        for url in [src] + [u for u, _ in lazy] + [c[0] for c in first + later]:
            if url and url not in strong:
                strong.append(url)
        for url in strong + [plain]:
            if url and url not in variants:
                variants.append(url)
        given = (attrs.get("width") or "").strip()
        if width is None and given.isdigit():
            width = int(given)
        record = {"src": src, "alt": clean_text(attrs.get("alt"), 200), "width": width, "variants": variants,
                  "strong": strong, "src_from": how,
                  "junk": bool(JUNK.search(" ".join((src, attrs.get("class") or ""))))}
        height = (attrs.get("height") or "").strip()
        if height.isdigit() and (width is None or given == str(width)):
            record["height"] = int(height)
        for index, existing in enumerate(self.images):  # the same picture again (a noscript copy): one record
            if set(existing["strong"]) & set(strong):
                existing["variants"] += [v for v in variants if v not in existing["variants"]]
                existing["strong"] += [v for v in strong if v not in existing["strong"]]
                if self.inside(("noscript",)) and "noscript" not in existing["src_from"]:
                    existing["src_from"] += "+noscript"
                return
        if len(self.images) >= MAX_IMAGES:
            self.unlisted += 1
            return
        if self.inside(("noscript",)):
            record["src_from"] += " (noscript)"
        self.images.append(record)
        if self.figures:
            self.figures[-1]["imgs"].append(len(self.images) - 1)
        self.events.append(("img", len(self.images) - 1))

    def close(self):
        super().close()
        self.flush()


def _largest(items):
    """The widest of [(url, width, density, how)] when any says its width, else the highest density (1x when none
    says), else None; the first wins a tie."""
    if not items:
        return None
    if any(w for _, w, _, _ in items):
        return max(items, key=lambda c: c[1] or 0)
    return max(items, key=lambda c: c[2] or 1.0)


def _nearby(events, index):
    """(caption, credit, links) from the text right after image index: at most two text blocks, never past the next
    image. A block in an element whose class or id names a credit (credit, byline, photographer ...) or with words of
    one (摄影, 图片来源, Photo by, CC BY ...) is a credit; one in a caption element is a caption. Text before the image
    belongs to what came before and is not used."""
    position = next(i for i, e in enumerate(events) if e[0] == "img" and e[1] == index)
    caption = credit = None
    links, seen = [], 0
    for event in events[position + 1:]:
        if event[0] == "img" or seen >= 2:
            break
        seen += 1
        _, text, context, found = event
        words = common.credit_line(text)
        if context == "credit":
            credit = credit or text[:200]
        elif context == "caption":
            caption = caption or text[:300]
            credit = credit or words or None
        elif words:
            credit = credit or words
        else:
            continue
        links += found + common.licence_links(text)
    return caption, credit, links


def _structured(blobs, base):
    """{image address: {creator, credit_text, copyright_notice, copyright_holder, license, acquire_license_page}}
    from the JSON-LD ImageObject entries of the page (parsed as data, never run)."""
    out, budget = {}, [5000]

    def text_of(value):
        if isinstance(value, str):
            return clean_text(value, 200)
        if isinstance(value, dict):
            return text_of(value.get("name") or "")
        if isinstance(value, list):
            return clean_text("、".join(filter(None, (text_of(v) for v in value[:5]))), 200)
        return ""

    def walk(node, depth):
        budget[0] -= 1
        if depth > 20 or budget[0] < 0:
            return
        if isinstance(node, list):
            for item in node[:500]:
                walk(item, depth + 1)
            return
        if not isinstance(node, dict):
            return
        kinds = node.get("@type")
        if "ImageObject" in (kinds if isinstance(kinds, list) else [kinds]):
            fields = {"creator": text_of(node.get("creator") or node.get("author")),
                      "credit_text": text_of(node.get("creditText")),
                      "copyright_notice": text_of(node.get("copyrightNotice")),
                      "copyright_holder": text_of(node.get("copyrightHolder")),
                      "license": text_of(node.get("license")),
                      "acquire_license_page": text_of(node.get("acquireLicensePage"))}
            fields = {k: v for k, v in fields.items() if v}
            for key in ("contentUrl", "url"):
                if fields and isinstance(node.get(key), str) and node[key].strip():
                    out.setdefault(urllib.parse.urljoin(base, node[key].strip()), fields)
        for value in list(node.values())[:200]:
            walk(value, depth + 1)

    for blob in blobs[:20]:
        try:
            walk(json.loads(blob), 0)
        except (ValueError, RecursionError):
            continue
    return out


def _score(image):
    """A simple order for a page's images (not Crawl4AI's score): captioned, described, credited and large first; site
    furniture (logos, icons, spacers) and tiny images last."""
    value = 2 if image.get("caption") else 0
    value += 1 if image.get("alt") else 0
    value += 1 if image.get("credit") else 0
    value += 1 if (image.get("width") or 0) >= 400 else 0
    value += 1 if len(image.get("variants", [])) > 1 else 0
    if image.get("junk"):
        value -= 3
    if image.get("width") is not None and image["width"] < 100:
        value -= 3
    return value


def extract(page_url, text):
    """(images, facts) for one page's HTML text: images [{src, alt, desc, score, width, height, variants, src_from,
    page_says}] in the order of the page, and facts {base, license_links, hidden_images, dropped_images,
    images_not_listed, scripts_not_run, meta_robots, meta_refresh} (only those that apply)."""
    parser = _Page(page_url)
    parser.feed(text or "")
    parser.close()
    base = parser.base or page_url
    structured = _structured(parser.structured, base)
    images = []
    for index, raw in enumerate(parser.images):
        caption, credit, links = _nearby(parser.events, index)
        caption = raw.get("figure_caption") or caption
        if caption and not credit:
            credit = common.credit_line(caption) or None
        if not credit and raw["alt"]:
            credit = common.credit_line(raw["alt"]) or None
        links = links + raw.get("links", []) + common.licence_links(caption or "")
        image = {"src": raw["src"], "alt": raw["alt"], "width": raw["width"], "variants": raw["variants"],
                 "src_from": raw["src_from"]}
        if "height" in raw:
            image["height"] = raw["height"]
        if caption:
            image["caption"] = caption
        if credit:
            image["credit"] = credit
        image["desc"] = caption or ""  # a credit apart from the caption is only in page_says (r5.59, decision 6)
        image["score"] = _score(dict(image, junk=raw["junk"]))
        says = {}
        if caption:
            says["caption"] = caption
        if credit:
            says["credit"] = credit
        unique = sorted(set(l.rstrip(".,;。，；") for l in links))
        if unique:
            says["license_links"] = unique
        found = next((structured[v] for v in raw["variants"] if v in structured), None)
        if found:
            says["structured"] = dict(found)
        if says:
            image["page_says"] = says
        image.pop("caption", None)
        image.pop("credit", None)
        images.append(image)
    facts = {"base": parser.base if parser.base and parser.base != page_url else None,
             "license_links": parser.license_links, "hidden_images": parser.hidden,
             "dropped_images": parser.dropped, "images_not_listed": parser.unlisted,
             "scripts_not_run": parser.scripts, "meta_robots": parser.meta_robots,
             "meta_refresh": parser.meta_refresh}
    return images, {k: v for k, v in facts.items() if v}


def read_page(page, config, session):
    """One page through session: the record collect keeps ({page_url, time, reader, status, http_status, error,
    images, page_says, ...})."""
    record = {"page_url": page, "time": common.now(), "reader": NAME, "images": []}
    limit = int(config["network"].get("max_page_bytes", common.DEFAULTS["network"]["max_page_bytes"]))
    outcome, response = session.request(page, "page", headers={"Accept": ACCEPT}, max_bytes=limit)
    for key in ("http_status", "final_url", "redirects", "not_asked"):
        if outcome.get(key) is not None and (key != "final_url" or re.match(r"^https?://", outcome[key], re.I)):
            record[key] = outcome[key]
    if response is None:
        record.update(status=outcome["status"], error=outcome.get("error", ""))
        return record
    if response.status != 200:
        record.update(status="failed", error="HTTP %d: not counted as read" % response.status)
        return record
    kind = str(common.header(response.headers, "Content-Type") or "").split(";")[0].strip().lower()
    if kind not in HTML_TYPES and not (not kind and (response.body or b"").lstrip()[:1] == b"<"):
        record.update(status="not_html", error="the address answered %s, not an HTML page: nothing read from it"
                      % (kind or "without a type"))
        return record
    text, charset = decode_page(response.body, response.headers)
    final = response.final_url if re.match(r"^https?://", response.final_url or "", re.I) else page
    images, facts = extract(final, text)
    links = facts.pop("license_links", None)
    record.update(charset=charset, sha256=common.sha256_bytes(response.body or b""), images=images, **facts)
    if links:
        record["page_says"] = {"license_links": links}
    record["status"] = "ok" if images else "no_images"
    if facts.get("scripts_not_run"):
        record["note"] = ("the page has %d script(s), which the builtin reader does not run: images that only a script "
                          "puts on the page are not seen%s" % (facts["scripts_not_run"], "" if images else
                                                               " (none were in its HTML)"))
    return record


def read_pages(pages, config, session):
    """Each page in turn through session: ([record], VERSION), the shape of collect.crawl_pages."""
    return [read_page(page, config, session) for page in pages], VERSION


PROBE_PAGE = ("<!doctype html><html><head><meta charset='utf-8'></head><body><figure><img src='probe.png' "
              "srcset='probe-800.png 800w, probe-1600.png 1600w' alt='probe'><figcaption>Photo by nobody</figcaption>"
              "</figure></body></html>")


def probe():
    """doctor --probe: read a page made here (no request is made) and say what came out."""
    images, facts = extract("https://example.org/probe.html", PROBE_PAGE)
    ok = [i["src"] for i in images] == ["https://example.org/probe-1600.png"]
    return {"status": "ok" if ok else "error", "images": len(images), "requests": 0, "version": VERSION,
            "note": "read a page made here; no request was made"}

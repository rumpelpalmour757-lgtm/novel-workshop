#!/usr/bin/env python3
"""r5.6: repairs for the 2026-10-17 review of the r5.5 candidate (speaker lines that change side).

Three people say the same words; the revision moves every speaker line from above the words ("陈青低声说：") to below
them ("陈青低声说。") and changes two people's marks. r5.5 reported nothing and the strict gate passed with nothing to
decide; r5.4 had flagged all three lines. The speaker lines were taken as rewritten in place, so 孟迟's “知道了？” was
paired "by place" with 卢石's “知道了？” (the same mark, so no change), and the remaining “知道了！” lines looked unchanged.

What a pairing by place now needs, besides corresponding lines above and below: the words are named the same way in
both versions -- by the line that corresponds, or by no line at all. A speaker line that moved to the other side of the
words names nobody's words in the same way any more, so those words are flagged unless something else tells them apart.
A line that looks just as much like another changed line as like the one in its slot is not "rewritten in place" either
(a tie explains nothing): speaker lines that differ only in the name, or repeated words, look equally like several
lines. Uncertain items are acceptable here; passing a real change unreported is not.
All material is invented for these tests; reviews are labelled test data.
"""

import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SCRIPTS = ROOT / "skills" / "novel-workshop" / "scripts"
DIMENSIONS = ("paragraphing", "dialogue_punctuation", "scene_reconstruction", "narrative_function", "continuity",
              "revision_comparison")
NAMES = ("陈青", "孟迟", "卢石")


def whole_text(text):
    """r5.11: a strict-mode PASS needs the expression record. These short test texts are read as one segment; the
    record is test data that only lets the gate get to what this file tests."""
    body = text.strip()
    begin = next(body[:k] for k in range(4, len(body) + 1) if len("".join(body[:k].split())) >= 4)
    end = next(body[-k:] for k in range(4, len(body) + 1)
               if len("".join(body[-k:].split())) >= 4 and body.count(body[-k:]) == 1)
    return {"scope": "chapter", "decisions": [],
            "segments": [{"from": begin, "to": end, "note": "测试数据：只验证结构，从“%s”连读到“%s”" % (begin, end)}]}

# The review's own texts.
ORIGINAL = "陈青低声说：\n\n“知道了！”\n孟迟低声说：\n\n“知道了？”\n卢石低声说：\n\n“知道了！”\n"
PURE_LAYOUT = "“知道了！”\n陈青低声说。\n\n“知道了？”\n孟迟低声说。\n\n“知道了！”\n卢石低声说。\n\n"
CHANGED = "“知道了！”\n陈青低声说。\n\n“知道了！”\n孟迟低声说。\n\n“知道了？”\n卢石低声说。\n\n"

# Speaker before the words (with a colon) or after them (with a full stop); blank lines as the review used them, plus
# the other common habits. Each layout: (lines of one person's paragraph, index of the words, separator after it).
LAYOUTS = {
    "before, blank after the speaker line, groups joined directly": (("{n}低声说：", "", "“{w}”"), 2, "\n"),
    "before, blank lines everywhere": (("{n}低声说：", "", "“{w}”"), 2, "\n\n"),
    "before, speaker line touching the words": (("{n}低声说：", "“{w}”"), 1, "\n\n"),
    "after, blank line between groups": (("“{w}”", "{n}低声说。"), 0, "\n\n"),
    "after, no blank lines": (("“{w}”", "{n}低声说。"), 0, "\n"),
}
BEFORE = [name for name in LAYOUTS if name.startswith("before")]
AFTER = [name for name in LAYOUTS if name.startswith("after")]


def compare(original, revised):
    spec = importlib.util.spec_from_file_location("r56_punctuation", SCRIPTS / "punctuation_lint.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.compare_texts(original, revised)


def certain(report):
    return sorted((t["line"], t["before"] + "→" + t["after"]) for t in report["tone_changes"] if t["match"] != "uncertain")


def flagged_lines(report):
    return sorted(t["line"] for t in report["tone_changes"])


def render(layout, marks):
    """The three people's paragraphs in one layout; returns the text and each person's line of words."""
    lines_of, at, sep = LAYOUTS[layout]
    parts, where, line = [], {}, 1
    for name, mark in zip(NAMES, marks):
        block = [part.format(n=name, w="知道了" + mark) for part in lines_of]
        where[name] = line + at
        parts.append("\n".join(block))
        line += len(block) + (1 if sep == "\n\n" else 0)
    return sep.join(parts) + "\n", where


class TheReportsLayoutChange(unittest.TestCase):
    """The review's example, word for word."""

    def test_layout_change_alone_is_never_a_certain_change(self):
        # r5.5 reported 卢石's line as an "in_place" change from ？ to ！: 孟迟's words paired with 卢石's.
        self.assertEqual(certain(compare(ORIGINAL, PURE_LAYOUT)), [])

    def test_layout_change_with_two_changed_marks_is_flagged(self):
        report = compare(ORIGINAL, CHANGED)
        # 孟迟 (now line 4) went from ？ to ！; 卢石 (now line 7) went from ！ to ？; 陈青 (line 1) is unchanged.
        self.assertTrue({4, 7} <= set(flagged_lines(report)), report["tone_changes"])
        for item in report["tone_changes"]:
            if item["match"] != "uncertain":
                self.assertIn((item["line"], item["before"] + "→" + item["after"]), [(4, "？→！"), (7, "！→？")])

    def test_the_gate_needs_decisions(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            (work / "original.md").write_bytes((ORIGINAL).encode("utf-8"))
            (work / "draft.md").write_bytes((CHANGED).encode("utf-8"))
            (work / "checks.json").write_bytes((json.dumps({"candidate": "draft.md", "mode": "strict", "checks": [
                {"id": "rev", "type": "revision", "source": "original.md"}]})).encode("utf-8"))

            def run(*args):
                proc = subprocess.run([sys.executable, "-I", "-B", str(SCRIPTS / "workflow_guard.py"), *args], cwd=work,
                                      capture_output=True, text=True, encoding="utf-8")
                return proc.returncode, json.loads(proc.stdout)

            def review(name, dispositions):
                # The review's own fixture: the three speaker lines as quotes, all six dimensions as test data.
                (work / name).write_bytes((json.dumps({
                    "schema": "editorial-review/2", "verdict": "PASS",
                    "candidate_sha256": hashlib.sha256((work / "draft.md").read_bytes()).hexdigest(),
                    "reviewer": {"mode": "self_check", "label": "测试数据：只验证结构"},
                    "checked_against": ["测试数据：original.md"], "inputs_read": ["original.md"],
                    "evidence": [{"in": "candidate", "quote": q} for q in ("陈青低声说。", "卢石低声说。", "孟迟低声说。")],
                    "issues": [], "counter_evidence": "测试数据，不是真实文学审稿。", "machine_dispositions": dispositions,
                    "dimensions": [{"id": key, "status": "met", "note": "测试数据：只验证结构"} for key in DIMENSIONS],
                    "expression": whole_text((work / "draft.md").read_text(encoding="utf-8"))},
                    ensure_ascii=False)).encode("utf-8"))
                return name

            self.assertEqual(run("start", "state.json", "--task-id", "r56", "--spec", "checks.json")[0], 0)
            items = [x["id"] for x in run("check", "checks.json")[1]["review_items"]]
            self.assertTrue({"rev:TONE-L4-C1", "rev:TONE-L7-C1"} <= set(items), items)
            code, out = run("record", "state.json", "--event-id", "v1", "--review", review("none.json", []))
            self.assertEqual((code, out.get("failure")), (2, "REVIEW_INCOMPLETE"))
            code, _ = run("record", "state.json", "--event-id", "v2", "--review", review("all.json", [
                {"id": key, "decision": "keep", "reason": "测试数据：逐句对照过原稿（%s）" % key} for key in items]))
            self.assertEqual(code, 0)
            gate = run("status", "state.json")[1]["gate"]
            self.assertEqual((gate["mechanical"], gate["editorial"], gate["review_items_open"]), ("GREEN", "PASS[self_check]", 0))


class SpeakerLinesChangingSide(unittest.TestCase):
    """Every speaker line moves to the other side of the words, before to after and after to before, in each blank-line
    habit, with the marks kept or changed. A real change must always be in front of a person (certain with the right
    marks, or uncertain); a mark that did not change must never be reported as a certain change."""

    MARKS = [("！", "？", "！"), ("。", "！", "。"), ("？", "。", "？"), ("！", "。", "？"), ("。", "。", "！")]

    def check(self, old_layout, new_layout, old_marks, new_marks):
        original, _ = render(old_layout, old_marks)
        revised, where = render(new_layout, new_marks)
        report = compare(original, revised)
        truth = {where[name]: (old, new) for name, old, new in zip(NAMES, old_marks, new_marks)}
        flagged = set(flagged_lines(report))
        for line, (old, new) in truth.items():
            if old != new:
                self.assertIn(line, flagged, report["tone_changes"])
        for item in report["tone_changes"]:
            if item["match"] != "uncertain":
                self.assertEqual((item["before"], item["after"]), truth.get(item["line"]), report["tone_changes"])

    def cases(self):
        for old_layout, new_layout in itertools.chain(itertools.product(BEFORE, AFTER), itertools.product(AFTER, BEFORE)):
            for marks in self.MARKS:
                yield old_layout, new_layout, marks

    def test_layout_change_alone(self):
        for old_layout, new_layout, marks in self.cases():
            with self.subTest(old=old_layout, new=new_layout, marks="".join(marks)):
                self.check(old_layout, new_layout, marks, marks)

    def test_layout_change_and_two_marks_traded(self):
        # 孟迟 and 卢石 trade their marks: the marks of all three, taken together, stay the same.
        for old_layout, new_layout, marks in self.cases():
            with self.subTest(old=old_layout, new=new_layout, marks="".join(marks)):
                self.check(old_layout, new_layout, marks, (marks[0], marks[2], marks[1]))

    def test_layout_change_and_one_mark_changed(self):
        for old_layout, new_layout, marks in self.cases():
            other = "？" if marks[1] != "？" else "。"
            with self.subTest(old=old_layout, new=new_layout, marks="".join(marks)):
                self.check(old_layout, new_layout, marks, (marks[0], other, marks[2]))

    def test_speaker_lines_that_differ_only_in_the_name(self):
        # Found by repro/r5.6/fuzz_speaker_layouts.py --relayout: "丁低声说：", "乙低声说：", "辛低声说：" and
        # "乙低声说。" are all about equally like each other, so none of them is "the rewrite" of the line now in its
        # slot. Taking the first such tie as one paired 辛's “走吧？” with 乙's “走吧。” and passed 辛's change.
        original = "丁低声说：\n“别动？”\n\n“走吧？”\n乙低声说：\n\n“走吧！”\n"
        revised = "辛低声说：\n“走吧！”\n丁低声说：\n\n“别动？”\n\n“走吧。”\n乙低声说。\n"
        report = compare(original, revised)
        # 辛 (now line 2, named above) went from ？ to ！; 乙 (now line 7, speaker below) went from ！ to 。.
        self.assertTrue({2, 7} <= set(flagged_lines(report)), report["tone_changes"])
        for item in report["tone_changes"]:
            if item["match"] != "uncertain":
                self.assertIn((item["line"], item["before"] + "→" + item["after"]), [(2, "？→！"), (7, "！→。")])

    def test_the_reviews_example_is_in_this_matrix(self):
        original, _ = render(BEFORE[0], ("！", "？", "！"))
        revised, _ = render(AFTER[0], ("！", "！", "？"))
        self.assertEqual((original, revised.rstrip("\n")), (ORIGINAL, CHANGED.rstrip("\n")))


if __name__ == "__main__":
    unittest.main()

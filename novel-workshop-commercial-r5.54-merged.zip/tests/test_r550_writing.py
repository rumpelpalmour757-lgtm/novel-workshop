#!/usr/bin/env python3
"""r5.50: the small writing changes of the author's task book of 11-06 (section 四).

1. Before revising, split what must stay into three kinds: verbatim-locked sentences, facts to keep, adjustable wording;
   locked sentences are compared before delivery (detail_check.py changes --keep); strict polishing may move the narrative
   focus; where the goal needs additions the scope forbids, deliver what is possible and point out the limited places.
2. Action sentences follow the process: one person's run of moves on one momentum may stay one long sentence; break at a
   change of person, a block, a turn, or where the reader needs a beat; retell who moved first, where the force came
   from, what it hit next. The rule says this the same way everywhere (sentence craft, punctuation, the fourth pass, the
   revision card) and no place keeps the old "换了主语也一样".
3. Who is speaking: name + 说/问 first, then the subject restored, then an action the person already has; the three
   places to look at first; read the result back labelling every line.
4. A label swapped for another label (难过 → 累) is not a fix; chapter endings: write down the realization first.
5. The entry points (SKILL.md for the folder, the revision card for chat) carry the same steps.
6. deai-extra is an optional re-scan, not part of the ordinary run.
These tests pin wording and wiring only; they do not show the writing got better.
"""
import os
import re
import sys
import unittest
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(os.environ.get("NW_PACKAGE_ROOT", Path(__file__).resolve().parents[1]))
SKILL = ROOT / "skills" / "novel-workshop"


def read(rel):
    return (SKILL / rel).read_text(encoding="utf-8")


def section(text, heading):
    start = text.index(heading)
    end = text.find("\n## ", start + len(heading))
    return text[start:end if end > 0 else len(text)]


class LockedSentences(unittest.TestCase):
    def test_three_kinds_and_the_check_before_delivery(self):
        text = read("references/editing.md")
        part = text[text.index("**再分三样（r5.50）。**"):]
        part = part[:part.index("\n\n", part.index("分不清是锁句还是事实的"))]
        for phrase in ("逐字锁定的原句", "要保住的事实", "可以调整的表达", "连标点一起不动", "分不清是锁句还是事实的，按锁句对待",
                       "`--keep`", "`detail_check.py changes`", "“原样在”", "写明是人工比对", "不偷偷补", "要放宽到哪一级"):
            self.assertIn(phrase, part)
        self.assertIn("| 严格保义润色 | 句法、节奏、措辞、标点；叙述重心；已有信息的顺序和详略 |", text)
        # the step the paragraph points to exists and mentions --keep
        self.assertIn("有作者指定要留的句子就加 `--keep 留句.txt`", section(text, "## 修订前后对照"))

    def test_the_revision_card_and_the_folder_entry_say_the_same(self):
        card = read("assets/revision-card.md")
        for phrase in ("再分三样", "逐字锁定的原句", "分不清的按锁句对待", "逐字锁定的原句逐句对着原稿比一遍", "叙述重心"):
            self.assertIn(phrase, card)
        self.assertNotIn("只调句法、节奏、措辞；", card)
        entry = read("SKILL.md")
        self.assertIn("分出逐字锁定的原句", entry)
        self.assertIn("再分三样（逐字锁定的原句、要保住的事实、可以调整的表达）", entry)


class ActionSentences(unittest.TestCase):
    SAME = "同一个人顺着同一股冲势"

    def test_one_rule_in_four_places(self):
        sentence = read("references/sentence-craft.md")
        block = sentence[sentence.index("**动作句（r5.49）：**"):sentence.index("润色时保留“正在／准备／已经”")]
        self.assertIn(self.SAME, block)
        self.assertIn("换了人、动作被挡住、转了方向", block)
        self.assertIn("改完自己顺一遍：谁先动、接着碰到哪里", block)
        self.assertIn("支点、力从哪来、最后各在哪、伤在哪，按需查", block)
        self.assertIn("不为它补动作", block)
        self.assertNotIn("出了结果，或者", block)
        punct = read("references/chinese-punctuation.md")
        rule = next(line for line in punct.splitlines() if line.startswith("- **一逗到底**"))
        self.assertIn(self.SAME, rule)
        self.assertIn("换了人、动作被挡住、转了方向", rule)
        passes = section(read("references/revision-passes.md"), "## 第四遍：动作段节奏")
        self.assertIn(self.SAME, passes)
        self.assertIn("改完顺一遍谁先动、接着碰到哪里，支点、位置和伤势按需查，原稿没交代的不补造", passes)
        card = read("assets/revision-card.md")
        self.assertIn(self.SAME + "一口气做完的动作长句", card)
        self.assertIn("换了人、受阻、转向、读者该停一拍的地方才收句", card)

    def test_the_old_wording_is_gone_everywhere(self):
        for path in SKILL.rglob("*.md"):
            if "style-packs" in path.parts or "project-packs" in path.parts:
                continue
            text = path.read_text(encoding="utf-8")
            self.assertNotIn("换了主语也一样", text, path)
            self.assertNotIn("换了几次主语", text, path)
            for old in ("换了主语就拆", "换了人也一样", "换主语也不一定"):  # r5.50 review: leftovers of the r5.49 rule
                self.assertNotIn(old, text, path)

    def test_example_three_breaks_where_the_person_changes(self):
        punct = read("references/chinese-punctuation.md")
        part = punct[punct.index("**原创示例三："):punct.index("## 引号与对白")]
        after = next(line for line in part.splitlines() if line.startswith("> 改后："))
        self.assertIn("碰翻了酱油瓶。奶奶一把扯下湿抹布扣上去，又拧死了煤气阀", after)
        self.assertIn("换人的地方收一句", part)
        example4 = read("references/sentence-craft.md")
        self.assertIn("包袱里滚出一只铜壶，阿青伸手去扶。小满抬头说壶底漏了。", example4)

    def test_the_final_review_checks_footing_direction_position_injury(self):
        row = next(line for line in section(read("references/editing.md"), "## 精修后终审").splitlines()
                   if line.startswith("| 打斗里一句一停"))
        self.assertIn("按需查支点、方向、位置和伤势", row)


class WhoIsSpeaking(unittest.TestCase):
    def test_ways_to_fix_three_places_and_the_read_back(self):
        part = section(read("references/dialogue-craft.md"), "## 谁在说：读者认不认得出（r5.49）")
        fix = next(line for line in part.splitlines() if line.startswith("- **怎样补。**"))
        order = [fix.index(p) for p in ("姓名加“说／问”", "恢复被省掉的主语", "承接这个人前面本来就有")]
        self.assertEqual(order, sorted(order))
        for phrase in ("第三个人插话", "隔了一段叙述再开口", "一个人的动作后面接另一个人的台词"):
            self.assertIn(phrase, fix)
        self.assertIn("逐句标一遍说话人", part)
        self.assertIn("让人物说出他这时不该知道的事", part)
        self.assertIn("不为标明谁在说编新动作", part)
        card = read("assets/revision-card.md")
        self.assertIn("对白读者认不出是谁说的，补“某某说／问”就够", card)
        self.assertIn("[对白专项](../references/dialogue-craft.md)“谁在说”", card)


class Labels(unittest.TestCase):
    def test_a_swapped_label_is_not_a_fix(self):
        audit = read("references/prose-audit.md")
        self.assertIn("只把一个情绪标签换成另一个（“难过”换成“累”，“紧张”换成“慌”），算没改到", audit)
        self.assertIn("先用一句话写下人物此刻确实得到的认识", section(audit, "## 点题式收尾"))
        card = read("assets/revision-card.md")
        self.assertIn("只把一个情绪标签换成另一个，“难过”换成“累”，也算没改", card)
        self.assertIn("先用一句话写下人物此刻确实得到的认识", card)


class Scanner(unittest.TestCase):
    def test_deai_extra_is_an_optional_rescan(self):
        audit = read("references/prose-audit.md")
        line = next(l for l in audit.splitlines() if l.startswith("**更多去 AI 味提示（r5.49，可选的复扫）。**"))
        for phrase in ("普通改稿照上面的配置跑", "`--hint deai`", "不必开它", "再拿它复扫一遍原稿和修订稿", "不开也不算漏检"):
            self.assertIn(phrase, line)
        self.assertIsNone(re.search(r"时 ）", line))


if __name__ == "__main__":
    unittest.main()

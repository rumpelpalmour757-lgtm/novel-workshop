# 本地工作台与拆文辅助工具

用于作者明确要求查看本地作品、搜索文件、编辑文稿或为长文建立定位时。普通聊天写作无需启动服务；安装技能不会自动开工作台、联网或处理私人文稿。

## 打开写作台

不用记命令：在技能的 `scripts/oh-story/` 文件夹里双击启动器。Windows 用 `open-workbench.cmd`（只读）或 `open-workbench-edit.cmd`（可改稿）；macOS 用同名的 `.command`；Linux 在终端里 `sh open-workbench.command`。第一次会问作品放在哪个文件夹（把文件夹拖进窗口再回车），以后记住；默认先找“文档/小说写作工坊”。启动后自动用浏览器打开，关掉启动窗口就停止。想先试一试，双击 `open-workbench-demo`：它在系统临时目录里放一份标明“合成示例”的小作品，以可改稿方式打开，随便改不碰你的作品。需要 Node.js 18 或更新版本，只用内置模块，不装依赖。

也可以直接运行服务程序，把示例路径换成实际的作品目录：

```text
node scripts/oh-story/dashboard-server.mjs --root "D:/小说/我的作品" --open
```

默认端口为 43110；占用时尝试后续可用端口。只允许本机回环地址，必须明确传入作品根目录，不自动扫描个人主目录。启动器只在本机用户配置目录的 `workbench.json` 里记作品目录的路径，不记文稿内容。

工作台支持拆文库与写作项目分栏、按文件名搜索、目录分页、文本查看、Markdown 预览、行号、明暗模式和恢复上次视图。搜索不是全文搜索。识别 `正文`、`大纲`、`设定`、`追踪` 等常见结构；没有这些目录时展示指定根目录，原有作品无需重排。文件超过 2 MiB 时使用本地编辑器。

## 按需编辑与恢复

两层开关。写作台用 `open-workbench-edit`（或 `--allow-edit`）启动，才允许改稿；只读启动时服务端拒绝一切写入，页面上的“开始编辑”是灰的，并提示怎样重新打开。可改稿启动后，每份文稿打开时仍是只读，点“开始编辑”才能改，没有修改时点“结束编辑”回到只读。

页面底部一直显示这份文稿的状态：只读、编辑中、未保存、保存中、已保存、保存失败。保存失败（包括磁盘被别处改过）时状态停在“保存失败”，修改留在页面里，不显示成已保存。Ctrl+S（macOS 为 ⌘S）保存；输入法正在组字时不响应快捷键。撤销、重做、粘贴用浏览器文本框自带的功能。

未保存的修改会记成草稿，存在这台浏览器里：换文件、预览、刷新、关闭页面都不会丢；离开前仍会提醒。再打开这份文稿时顶上出现草稿提示，可以恢复、对比或丢弃。草稿在保存成功或作者丢弃后才清掉。草稿依据的版本和磁盘不一致时，恢复后保存会先报冲突，不会悄悄覆盖。“放弃修改”回到磁盘上的版本。

“对比”按段列出打开时（或上次保存后）的版本和页面里现在的文字有哪些不同；冲突时可以和磁盘上现在的版本对比。

每次保存前，在作品根目录的 `.novel-workshop-backups/` 中保留原始字节与记录。每份备份包含 `original.bin` 和 `record.json`，后者注明原相对路径、保存时间和 SHA-256。备份失败时不保存。恢复时先对照记录定位原文，再另存或在作者要求下恢复；工作台不自动清理备份，不提供删除文件功能。

保存会核对打开时的文件版本。发现外部修改时拒绝覆盖：可以保留当前编辑、对比磁盘版本，或者载入磁盘版本（这边的修改先留作草稿），再决定怎样合并。此核对不能替代跨机器同步或所有外部编辑器的并发协议。项目权威状态仍按 [状态存储](state-storage.md) 更新；不要通过工作台直接编辑由 `project_state.py` 管理的状态文件。工作台用于正文和普通参考文本，不替代状态提交接口。

工作台读写文稿不联网、不调用模型，也不是云端服务。它没有图片搜索和选图界面：参考图按 [灵感库](inspiration-library.md) 在对话里推荐、由作者挑，挑中的记进本书的灵感库。AI 协助编辑仍由当前会话的任务与授权决定。

## r5.59 起没有 AI 侧栏

r5.46 到 r5.58 的写作台有可选的“改稿建议”侧栏（Gemini API，r5.46 起），r5.49 起又有“Google AI”侧栏（Google 官方 ACP 运行时）。r5.59 起两个都删了，连同它们的接通检查脚本和双击检查的启动器；读稿、改稿、草稿、对比、备份这些本地功能照旧。要请模型改一段，在对话里交给当前会话，或者作者自己交给他选的教师。新章全流程里初稿交教师的默认设置不变，见[每章七阶段与作者确认](chapter-confirmation.md)“完整初稿以后”。

以前用过这两个侧栏的，电脑上留着的密钥和本机记录，工坊不碰；不再用的，可以自己删。它们都在用户配置目录里（Windows：`%APPDATA%\novel-workshop\`；macOS：`~/Library/Application Support/novel-workshop/`；Linux：`~/.config/novel-workshop/`，设了 `XDG_CONFIG_HOME` 的在它下面的 `novel-workshop/`；设过环境变量 `NOVEL_WORKSHOP_CONFIG_DIR` 的，在它指的文件夹里）：
- “改稿建议”：`gemini.json`（API Key 和模型名）、`gemini-status.json`（调用记录）、`gemini-check-report.txt`（接通检查的报告）。删了文件，Key 本身在 Google 那边照样有效。自己设过环境变量 `GEMINI_API_KEY` 的，写作台也不再读它，清不清由你定。
- “Google AI”：`acp.json`、`acp-status.json`、`acp-events.jsonl`、`acp-events.old.jsonl`、`acp.lock`、`acp-check-report.txt`，设置文件坏过的还有 `acp.json.broken-时间`。写作台被强行结束过的，系统临时目录里可能还留着以 `novel-workshop-acp-` 开头的文件夹（当时给官方程序的工作目录），也可以删。自己装的官方程序（`agy` 或 antigravity-acp）和它记着的 Google 登录不是工坊的，工坊不动，卸不卸由你定。

同一个文件夹里的 `workbench.json` 是启动器记的作品目录，还在用；删了也只是下次启动时再找一次作品目录（先找“文档/小说写作工坊”，没有再问）。

## 章节索引与既有拆文检查

可选 Python 工具需要 Python 3.9 或更新版本。只在用户要求建立索引或保存分析时运行。以下命令从技能根目录执行，路径均须换成实际项目路径。

```text
python scripts/oh-story/build_chapter_index.py --source "D:/拆文/原文/参考稿.txt" --output "D:/拆文/章节索引.csv"
python scripts/oh-story/inspect_existing_assets.py --root "D:/拆文" --compact
```

索引器读取 UTF-8 / UTF-8 BOM / GB18030 原文，生成章节范围、原文行号、字符数与内容哈希，不生成文学分析。先核查识别出的章标题和章数；没有标准章标题的文本可人工建立范围表。工具可发现源文件与已有索引不一致，先说明差异再决定是否在备份后 `--rebuild`，不要把该参数当作默认修复。

检查器面向 Oh Story 格式的拆文目录，只读输出已有材料与覆盖情况；现有工坊项目不满足它的目录约定，不等于稿件不合格。它不判定小说质量，也不应要求作者为检查器重建全部工程。长短篇实际分析使用 [完整拆文与技法库](deconstruction-library.md)，批次进度沿用 [执行与恢复](execution.md)。

## 生成人物关系图

在分析目录建立 `角色/角色关系.md`，按原文证据填写有方向的关系表，例如：

```text
| 主体 | 客体 | 关系动作 | 变化后状态 | 触发事件 |
| --- | --- | --- | --- | --- |
| 人物甲 | 人物乙 | 保护 | 有限信任 | 第二章共同逃脱 |
```

然后运行：

```text
python scripts/oh-story/render_relation_chart.py --root "D:/拆文"
```

输出 `人物关系图/人物关系图.md`，包括 Mermaid 关系图与文字清单。该目录是可重新生成的结果，重新运行会更新它；人工改动先另存。需要 PNG 时可加 `--png`，仅在环境已有 matplotlib 和能覆盖全部字符的中文字体时生成，缺依赖则保留 Markdown 结果；不自动安装软件。图表不自行推断人物关系。

## 随包资源与出处

工作台：[服务程序](../scripts/oh-story/dashboard-server.mjs)、[启动器](../scripts/oh-story/workbench.mjs)（双击用：[只读](../scripts/oh-story/open-workbench.cmd)、[可改稿](../scripts/oh-story/open-workbench-edit.cmd)、[合成示例](../scripts/oh-story/open-workbench-demo.cmd)，macOS 的 [只读](../scripts/oh-story/open-workbench.command)、[可改稿](../scripts/oh-story/open-workbench-edit.command)、[合成示例](../scripts/oh-story/open-workbench-demo.command)）、[页面](../assets/dashboard/index.html)、[交互](../assets/dashboard/app.js)、[样式](../assets/dashboard/styles.css)、[主题](../assets/dashboard/tokens.css)。

拆文工具：[章节索引](../scripts/oh-story/build_chapter_index.py)、[既有材料检查器](../scripts/oh-story/inspect_existing_assets.py)、[人物关系图](../scripts/oh-story/render_relation_chart.py)。索引器依赖同目录检查器，分发时保持相对位置。

以上工具改编或取自 Oh Story 0.8.4。工作台增加只读默认、显式根目录、保存前备份、删除禁用、本机访问限制和工坊界面；r5.46 起又加了启动器、逐份文稿的编辑开关、草稿和对比，界面配色改为暖白纸面加暗红强调；r5.46 加的可选 Gemini 改稿和 r5.49 加的可选 Google AI（官方 ACP 运行时）侧栏，r5.59 删了。界面布局参考了 InkOS（AGPL-3.0）的写作台思路，由工坊独立实现，没有复制它的源码、Logo 或图片。三项 Python 工具保留原实现。具体范围见 [补全记录](../assets/third-party/INTEGRATION-NOTES.md) 与 [MIT 许可](../assets/third-party/oh-story-0.8.4-LICENSE.txt)。

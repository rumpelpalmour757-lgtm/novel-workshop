#!/usr/bin/env python3
"""Visual materials for a chapter: search, collect, group, rank, review, choose, adopt (r5.35, references/visual-materials.md).

python3 visual_materials_cli.py doctor [--config CONFIG] [--probe]
python3 visual_materials_cli.py search --request REQUEST.json --out RUN_DIR [--config CONFIG]
python3 visual_materials_cli.py collect --run RUN_DIR [--config CONFIG]
python3 visual_materials_cli.py dedupe --run RUN_DIR [--config CONFIG]
python3 visual_materials_cli.py rank --run RUN_DIR [--text-query TEXT] [--reference-image IMAGE ...] [--config CONFIG]
python3 visual_materials_cli.py review-bundle --run RUN_DIR [--library LIBRARY] [--config CONFIG]
python3 visual_materials_cli.py review-record --run RUN_DIR --observations OBSERVATIONS.json [--config CONFIG]
python3 visual_materials_cli.py select --run RUN_DIR --choice CHOICE.json [--config CONFIG]
python3 visual_materials_cli.py adopt --run RUN_DIR --library LIBRARY --if-revision N [--rebase] [--dry-run]
python3 visual_materials_cli.py verify-run --run RUN_DIR

SearXNG and Openverse find candidates side by side; Crawl4AI reads their source pages; the images are fetched and
decoded; ImageHash groups near copies; OpenCLIP orders them by the scene's text and the author's reference images.
review-bundle writes a few numbered, different images to look at; review-record keeps what was actually seen; select
turns the author's choice ("2 的布局、4 的灯光") into a selection; adopt writes it into the book's inspiration library
through inspiration_write.py, checking the library's revision. Every step writes its record into RUN_DIR; verify-run
says, component by component, what this run actually shows. The config is CONFIG, or NW_VISUAL_CONFIG, or the
defaults (no SearXNG instance, no OpenCLIP weights). Writing and reviewing chapters never need any of this.

Exit codes: 0 done (partial is done with a gap; verify-run: all five live); 1 the step could not do its job, or
verify-run found them not all live (the JSON says why); 2 an error in the input or an unexpected failure (the JSON
says which; the traceback goes to stderr); 3 CONFLICT (the library was written since you read it); 4
COMMITTED_INCOMPLETE (the library holds the new revision but its history is not finished: do not repeat the write).
"""
import argparse
import json
import os
from pathlib import Path
import sys
import traceback

sys.path.insert(0, str(Path(__file__).resolve().parent))

from visual_materials import adopt, collect, common, dedupe, doctor, rank, review, search, selection, verify  # noqa: E402


def utf8_stdio():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


def main(argv=None):
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = parser.add_subparsers(dest="command", required=True)

    def add(name, run=True):
        p = sub.add_parser(name)
        p.add_argument("--config", type=Path, help="the config file (default: NW_VISUAL_CONFIG, else the defaults)")
        if run:
            p.add_argument("--run", type=Path, required=True)
        return p

    p = add("doctor", run=False)
    p.add_argument("--probe", action="store_true", help="make one small real call per configured component")
    p = add("search", run=False)
    p.add_argument("--request", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    add("collect")
    add("dedupe")
    p = add("rank")
    p.add_argument("--text-query")
    p.add_argument("--reference-image", action="append", default=[])
    p = add("review-bundle")
    p.add_argument("--library", type=Path, help="the book's library: images the author turned down before are left out")
    p = add("review-record")
    p.add_argument("--observations", type=Path, required=True)
    p = add("select")
    p.add_argument("--choice", type=Path, required=True)
    p = add("adopt")
    p.add_argument("--library", type=Path, required=True)
    p.add_argument("--if-revision", type=int, required=True)
    p.add_argument("--rebase", action="store_true")
    p.add_argument("--dry-run", action="store_true")
    add("verify-run")
    args = parser.parse_args(argv)
    try:
        config_path = args.config or (Path(os.environ["NW_VISUAL_CONFIG"]) if os.environ.get("NW_VISUAL_CONFIG") else None)
        config = common.load_config(config_path)
        if args.command == "doctor":
            report = doctor.run_doctor(config, config_path, args.probe)
        elif args.command == "search":
            report = search.run_search(common.read_json(args.request), config, args.out)
        elif args.command == "collect":
            report = collect.run_collect(args.run, config)
        elif args.command == "dedupe":
            report = dedupe.run_dedupe(args.run, config)
        elif args.command == "rank":
            report = rank.run_rank(args.run, config, args.text_query, args.reference_image)
        elif args.command == "review-bundle":
            report = review.run_bundle(args.run, config, args.library)
        elif args.command == "review-record":
            report = review.record_observations(args.run, config, args.observations)
        elif args.command == "select":
            report = selection.run_select(args.run, config, args.choice)
        elif args.command == "adopt":
            report = adopt.run_adopt(args.run, args.library, args.if_revision, args.rebase, args.dry_run)
        else:
            report = verify.run_verify(args.run)
    except common.VisualError as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}, ensure_ascii=False))
        return 2
    except Exception as exc:  # noqa: BLE001 - an unexpected failure still answers in JSON; the traceback is on stderr
        traceback.print_exc()
        print(json.dumps({"status": "ERROR", "error": "%s: %s" % (type(exc).__name__, exc), "unexpected": True},
                         ensure_ascii=False))
        return 2
    print(json.dumps(report, ensure_ascii=False, indent=1))
    status = str(report.get("status", "")).upper()
    if status == "CONFLICT":
        return 3
    if status == "COMMITTED_INCOMPLETE":
        return 4
    # A step that could not do its job (nothing found, a component missing, a check that failed) exits 1; its record
    # in RUN_DIR says why. partial is a success with a gap, and the JSON says which.
    if status in ("PROBLEMS", "ERROR", "FAILED", "NOT_INSTALLED", "MODEL_MISSING", "DEPENDENCY_MISSING", "MODEL_ERROR",
                  "NO_IMAGES", "EMPTY", "NOT_ALL_LIVE", "FILES_CHANGED"):
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

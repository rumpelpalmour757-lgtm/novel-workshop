#!/usr/bin/env python3
"""决定这一场挂哪个弹药包：按正文或场景词里的触发词打分，推荐至多两个，并列出要读的文件。

内核每次都挂；弹药包按场景挂，每次最多两个，场景再多就拆开写。
用法：
  python scripts/mount.py 第012章.txt          # 按正文推荐
  python scripts/mount.py --scene 审讯 当铺      # 按场景词推荐
  python scripts/mount.py --list                 # 列出六个弹药包和触发词
只用标准库。打分：两字以上的触发词每次命中算1分，单字词（杀、修、钱、家）算0.25分。
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import C, K, MAX_CARTS, label, read_text, score_scenes, suggest  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description="推荐弹药包")
    ap.add_argument("file", nargs="?", help="正文文件，- 表示从标准输入读")
    ap.add_argument("--scene", nargs="*", default=[], help="场景词，如 审讯 当铺 饭桌")
    ap.add_argument("--list", action="store_true", help="列出弹药包")
    args = ap.parse_args()
    if args.list or not (args.file or args.scene):
        print(f"内核（每次都挂）：{len(K['craft'])}条写法、{len(K['gates'])}道门禁")
        for n, c in C.items():
            print(f"{label(n)}：{len(c['craft'])}条写法、{len(c['gates'])}道门禁")
            print(f"  触发词：{'、'.join(c['triggers'])}")
        return

    text = " ".join(args.scene)
    if args.file:
        text += "\n" + read_text(args.file)
    picks = suggest(text)
    if args.scene and not args.file:
        for word in args.scene:   # 场景词本身没对上触发词时，再按弹药包名字找
            for n, c in C.items():
                if (word in c["name"] or word == c.get("short")) and n not in [p[0] for p in picks]:
                    picks.append((n, 1, {word: 1}))
        picks = picks[:MAX_CARTS]
    print("推荐：" + ("内核 + " + "、".join(label(n) for n, _, _ in picks) if picks else "只挂内核（没有明显的场景词）"))
    for n, s, h in picks:
        print(f"  {label(n)}：{s}分，命中 " + "、".join(f"{k}×{v}" for k, v in sorted(h.items(), key=lambda kv: -kv[1])))
    others = [(n, s) for n, (s, _) in score_scenes(text).items() if s > 0 and n not in [p[0] for p in picks]]
    if others:
        print("也沾边：" + "、".join(f"{label(n)}（{s}分）" for n, s in sorted(others, key=lambda x: -x[1])))
    print("要读的文件：")
    print("  references/kernel.yaml")
    for n, _, _ in picks:
        print(f"  {C[n]['file']}")
    if len([1 for n, (s, _) in score_scenes(text).items() if s >= 1]) > MAX_CARTS:
        print(f"提示：这段沾了{MAX_CARTS}个以上的场景，一次最多挂{MAX_CARTS}个；场景太杂就拆开写")


if __name__ == "__main__":
    main()
